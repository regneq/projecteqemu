#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "LoginServer.h"
#include "zoneserver.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];
extern ZSList zoneserver_list;
extern LoginServer* loginserver;

Client::Client(int32 in_ip, int16 in_port, int in_send_socket)
{
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;

	timeout_timer = new Timer(CLIENT_TIMEOUT);
	
	account_id = 0;

	packet_manager.SetDebugLevel(0);
	strcpy(zone_name, ZONE_NAME); // TODO: Starting zone should not be hardcoded
	char_name[0] = 0;
	WaitingForBootup = false;
}

Client::~Client()
{
}

void Client::ReceiveData(uchar* buf, int len)
{
	timeout_timer->Start();
	packet_manager.ParceEQPacket(len, buf);
}

void Client::SendCharInfo()
{
	APPLAYER *outapp;
	outapp = new APPLAYER;
	outapp->opcode = OP_SendCharInfo;
	outapp->pBuffer = new uchar[1120];//1112];
	outapp->size	= 1120;//1112;

	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(account_id, cs_struct);

	packet_manager.MakeEQPacket(outapp);
	delete outapp;
}

bool Client::Process()
{
	bool sendguilds = true;
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(app = packet_manager.OutQueue.pop())
	{
		switch(app->opcode)
		{
		case 0:
		break;
		case OP_SendLoginInfo:
		{

			// Quagmire - max len for name is 18, pass 15
			char name[19] = "";
			char password[16] = "";

			strncpy(name, (char*)app->pBuffer, 18);
			if (app->size < strlen(name)+2)
				return false;
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 15);

//cerr << "u='" << name << "', p='" << password << "'" << endl;
			if (strncasecmp(name, "LS#", 3) == 0) {
				LSAuth_Struct* lsa = 0;
				if (lsa = loginserver->CheckAuth(atoi(&name[3]), password)) {
//cout << "Client from LS: id=" << lsa->lsaccount_id << ", n=" << lsa->name << ", k=" << lsa->key << endl;
					account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
					if (account_id == 0) {
						database.CreateAccount(lsa->name, "", 0, lsa->lsaccount_id);
						account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
						if (account_id == 0) {
							// TODO: Find out how to tell the client wrong username/password
							cerr << "Error adding local account for LS login: '" << lsa->name << "', duplicate name?" << endl;
							return false;
						}
					}
					sendguilds = lsa->firstconnect;
					lsa->firstconnect = false;
//					loginserver->RemoveAuth(lsa->lsaccount_id);
//cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << ", k=" << password << endl;
					cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << endl;
				}
				else {
					// TODO: Find out how to tell the client wrong username/password
//cerr << "Bad/expired session key: " << name << ", k=" << password << endl;
					cerr << "Bad/expired session key: " << name << endl;
					return false;
				}
			}
			else if (strlen(password) <= 1) {
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Login without a password" << endl;
				return false;
			}
			else {
				account_id = database.CheckLogin(name,password);
				if (account_id == 0)
				{
					// TODO: Find out how to tell the client wrong username/password
					struct in_addr	in;
					in.s_addr = ip;
					cerr << inet_ntoa(in) << ": Wrong name/pass: name='" << name << "'" << endl;
					return false;
				}
cout << "Logged in: Local: " << name << endl;
			}

			APPLAYER *outapp;

			outapp = new APPLAYER;
			outapp->opcode = 0x0710;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			outapp = new APPLAYER;
			outapp->opcode = 0x0180;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			// Quagmire - Enabling expansions. Pretty sure this is bitwise
			outapp = new APPLAYER;
			outapp->opcode = OP_ExpansionInfo;
			outapp->size = 4;
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			outapp->pBuffer[0] = 7;
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			if (sendguilds) {
cout << "Sending list of guilds" << endl;
				// Quagmire - tring to send list of guilds
				outapp = new APPLAYER;
				outapp->opcode = OP_GuildsList;
				outapp->size = sizeof(GuildsList_Struct);
		   		outapp->pBuffer = new uchar[outapp->size];
				memset(outapp->pBuffer, 0, outapp->size);
				GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

				for (int i=0; i < 512; i++) {
					gl->Guilds[i].guildID = 0xFFFFFFFF;
					gl->Guilds[i].unknown1[0] = 0xFF;
					gl->Guilds[i].unknown1[1] = 0xFF;
					gl->Guilds[i].unknown1[2] = 0xFF;
					gl->Guilds[i].unknown1[3] = 0xFF;
					gl->Guilds[i].exists = 0;
					gl->Guilds[i].unknown3[0] = 0xFF;
					gl->Guilds[i].unknown3[1] = 0xFF;
					gl->Guilds[i].unknown3[2] = 0xFF;
					gl->Guilds[i].unknown3[3] = 0xFF;
					if (guilds[i].databaseID != 0) {
						gl->Guilds[i].guildID = i;
						strcpy(gl->Guilds[i].name, guilds[i].name);
						gl->Guilds[i].exists = 1;
					}
				}
				
				packet_manager.MakeEQPacket(outapp);
				delete outapp;
			}

			// We are logging in and want to see character select
			SendCharInfo();
		    break;
		}
		case 0x8B20: //Name approval
		{
			if (account_id == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				return false;
			}
		    char name[16];
		    strncpy(name,(char*)app->pBuffer,16);
		    uchar race = app->pBuffer[32];
		    uchar clas = app->pBuffer[36];

		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0x8B20;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.CheckNameFilter(name)) {
				outapp->pBuffer[0] = 0;
			}
			else if (database.ReserveName(account_id, name)) {
				outapp->pBuffer[0] = 1;
			}
			else {
				outapp->pBuffer[0] = 0;
			}
			packet_manager.MakeEQPacket(outapp);
			delete outapp;
		    break;			
		}
		case 0x4920: //Char create
		{
			if (account_id == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				return false;
			}
			// TODO: Sanity check in data

		    char name[16];
		    strncpy(name,(char*)app->pBuffer,16);

			int16 gender = app->pBuffer[50];
			int16 race = app->pBuffer[52];
			int16 class_ = app->pBuffer[54];
			int8 face = app->pBuffer[68];
			int8 str = app->pBuffer[119];
			int8 sta = app->pBuffer[120];
			int8 cha = app->pBuffer[121];
			int8 dex = app->pBuffer[122];
			int8 int_ = app->pBuffer[123];
			int8 agi = app->pBuffer[124];
			int8 wis = app->pBuffer[125]; // TODO: Find out where deity,face and starting location is located

			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			{
				// TODO Can we tell the client this failed?
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp;
				outapp = new APPLAYER;
				outapp->opcode = 0x8B20;
		   		outapp->pBuffer = new uchar[1];
		   		outapp->size = 1;
				outapp->pBuffer[0] = 0;
				packet_manager.MakeEQPacket(outapp);
				delete outapp;
				return false;
			}

			cout << "Char create:" << name << endl;
/*
			cout << "str" << (int)str << " ";
			cout << "sta" << (int)sta << " ";
			cout << "agi" << (int)agi << " ";
			cout << "dex" << (int)dex << " ";
			cout << "wis" << (int)wis << " ";
			cout << "int" << (int)int_ << " ";
			cout << "cha" << (int)cha << " ";
			cout << "gender" << gender << " ";
			cout << "race" << race << " ";
			cout << "class" << class_ << endl;
*/
			SendCharInfo();

		    break;
		}
		case 0x180: // Enter world
		{
			if (account_id == 0)
			{
				cerr << "Enter world with no logged in account" << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}
            strncpy(char_name,(char*)app->pBuffer,16);

			// Make sure this account owns this character
			if (database.GetAccountIDByChar(char_name) != account_id)
			{
				cerr << "This account does not own this character" << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}

			PlayerProfile_Struct pp;
			if (!database.GetPlayerProfile(account_id, char_name, &pp))
			{
				cerr << "Could not get PlayerProfile for " << char_name << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}
			if (!database.GetSafePoints(pp.current_zone)) {
				// This is to save people in an invalid zone, once it's removed from the DB
				strcpy(pp.current_zone, "arena");
				pp.x = 1050;
				pp.y = -50;
				pp.z = 3.2;
				database.SetPlayerProfile(account_id, char_name, &pp);
			}
			strcpy(zone_name, pp.current_zone);


			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0xdd21; // This is message of the day?
			char tmp[500];
			if (database.GetVariable("MOTD", tmp, 500)) {
				outapp->size = strlen(tmp)+1;
				outapp->pBuffer = new uchar[outapp->size];
				strcpy((char*)outapp->pBuffer, tmp);
			} else {
				outapp->size = 59;
				outapp->pBuffer = new uchar[59];
				strcpy((char*)outapp->pBuffer, "Welcome to EQ Emu(tm)!");
			}
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			EnterWorld();
			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
			SendCharInfo();
			return false;
			}
			SendCharInfo();
			break;
		}
		case 0x3521:
		case 0x3921:
			cout << Timer::GetCurrentTime() << " Unkown opcode:" << (int)app->opcode;
			cout << " size:" << app->size << endl;
			break;		
		default:
		{
			cout << Timer::GetCurrentTime() << " Unkown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app->pBuffer, app->size);
			break;
		}
		}

		delete app;
	}    
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
	while(p = packet_manager.SendQueue.pop())
	{
		// Disgrace: for windows compile
		#ifndef WIN32
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, (const char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif
		

		delete[] p;
	}
	/************ Processing finished ************/

	// Agz: Had to move this to the end of the function instead
	if (!packet_manager.CheckActive())
	{
		cout << "Client disconnected" << endl;
		return false;
	}
    if (timeout_timer->Check())
    {
		cout << "Client timeout" << endl;
		return false;
    }
	packet_manager.CheckTimers();

	return true;
}

void Client::EnterWorld(bool TryBootup) {
	int16 zone_port;
	char zone_address[255];

	ZoneServer* zs = zoneserver_list.FindByName(zone_name);
	if (zs)
		zs->TriggerBootup();
	else {
		if (TryBootup) {
			cout << "Attempting autobootup of '" << zone_name << "' for " << char_name << endl;
			if (!zoneserver_list.TriggerBootup(zone_name)) {
				cout << "Error: No zoneserver to bootup '" << zone_name << "' for " << char_name << endl;
				packet_manager.Close();
				QueuePacket(0);
			}
			WaitingForBootup = true;
			return;
		}
		else {
			cout << "Error: Zone not found '" << zone_name << "' for '" << char_name << "'" << endl;
			packet_manager.Close();
			QueuePacket(0);
			return;
		}
	}

	WaitingForBootup = false;
	cout << "Enter world: " << char_name << ": " << zone_name << endl;
	database.SetAuthentication(account_id, char_name, zone_name, ip);

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ZoneServerInfo;//0x0480;
	outapp->pBuffer = new uchar[130];
	outapp->size = 130;
//	strcpy((char*) outapp->pBuffer,     zone_address);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	strcpy((char*)&outapp->pBuffer[75], zone_name);
	int16 *temp = (int16*)&outapp->pBuffer[128];
//	*temp = ntohs(zone_port);
	*temp = ntohs(zs->GetCPort());

	QueuePacket(outapp);
	delete outapp;
}

void Client::QueuePacket(APPLAYER* app) {
	packet_manager.MakeEQPacket(app);
}

ClientList::ClientList() {
#ifdef WIN32
	InitializeCriticalSection(&CSListLock);
#else
/*	pthread_mutexattr_t attr;
	pthread_mutexattr_init(&attr);
	pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutex_init(&CSListLock, &attr);
	pthread_mutexattr_destroy(&attr);*/
	pthread_mutex_t CSListLock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
	pthread_mutex_lock(&CSListLock);
	pthread_mutex_unlock(&CSListLock);
#endif
}

ClientList::~ClientList() {
#ifdef WIN32
	DeleteCriticalSection(&CSListLock);
#else
//	pthread_mutex_destroy(&CSListLock);
#endif
}

void ClientList::Add(Client* client)
{
	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	list.Insert(client);
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			#ifdef WIN32
				LeaveCriticalSection(&CSListLock);
			#else
				pthread_mutex_unlock(&CSListLock);
			#endif
			return iterator.GetData();
		}
		iterator.Advance();
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
	return 0;
}

void ClientList::Process()
{
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << ntohs((int16)(iterator.GetData()->GetPort())) << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

void ClientList::ZoneBootup(char* zonename) {
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsWaitingForBootup() && strcasecmp(iterator.GetData()->GetZoneName(), zonename) == 0) {
			iterator.GetData()->EnterWorld(false);
		}
		iterator.Advance();
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

