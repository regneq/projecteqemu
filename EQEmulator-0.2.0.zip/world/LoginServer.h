#ifndef LOGINSERVER_H
#define LOGINSERVER_H

#include "../common/servertalk.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"

#include "../common/eq_packet_structs.h"

#define LOGIN_PORT 5999
#ifdef WIN32
	void LoginServerLoop(void *tmp);
	void AutoInitLoginServer(void *tmp);
#else
	void *LoginServerLoop(void *tmp);
	void *AutoInitLoginServer(void *tmp);
#endif
bool InitLoginServer();

struct LSAuth_Struct {
	int32	lsaccount_id;
	char	name[18];
	char	key[15];
	bool	stale;
	bool	inuse;
	bool	firstconnect;
};

class LoginServer {
public:
	LoginServer(int32 ip, int16 port, int in_send_socket);
    ~LoginServer();

	bool Process();
	bool ReceiveData();
	void SendPacket(ServerPacket* pack);

	void SendInfo();
	void SendStatus();

	int32 GetIP()    { return ip; }
	int16 GetPort()    { return port; }

	void AddAuth(LSAuth_Struct* newauth);
	LSAuth_Struct* CheckAuth(int32 in_lsaccount_id, char* key);
	bool RemoveAuth(int32 in_lsaccount_id);
	void CheckStale();
private:
#ifdef WIN32
	CRITICAL_SECTION CSAuthListLock;
#else
	pthread_mutex_t CSAuthListLock;
#endif
	int32 ip;
	int16 port;

	int send_socket;

	MyQueue<ServerPacket> ServerOutQueue;
	MyQueue<SPackSendQueue> ServerSendQueue;

	Timer* timeout_timer;
	Timer* statusupdate_timer;
	Timer* staleauth_timer;

	LinkedList<LSAuth_Struct*> auth_list;
};
#endif
