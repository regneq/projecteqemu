/*
Below are the blob structures for zone state dumping to the database
-Quagmire

create table zone_state_dump (zonename varchar(16) not null primary key, spawn2_count int unsigned not null default 0, 
npc_count int unsigned not null default 0, npcloot_count int unsigned not null default 0, gmspawntype_count int unsigned not null default 0, 
spawn2 mediumblob, npcs mediumblob, npc_loot mediumblob, gmspawntype mediumblob, time timestamp(14));
*/

#ifndef ZONEDUMP_H
#define ZONEDUMP_H

#pragma pack(1)

struct ZSDump_Spawn2 {
	int32	spawn2_id;
	int32	time_left;
};

struct ZSDump_NPC {
	int32			spawn2_dump_index;
	int32			gmspawntype_index;
	int32			npctype_id;
	sint32			cur_hp;
	bool			corpse;
	int32			decay_time_left;
//	needatype		buffs;		// decided not to save these, would be hard because if expired them on bootup, wouldnt take into account the npcai refreshing them, etc
	sint16			x;
	sint16			y;
	sint16			z;
	int8			heading;
	uint32			copper;
	uint32			silver;
	uint32			gold;
	uint32			platinum;
};

struct ZSDump_NPC_Loot {
	int32	npc_dump_index;
	int16	itemid;
	sint8	charges;
	sint16	equipSlot;
};

/*
Below are the blob structures for saving player corpses to the database
-Quagmire

create table player_corpses (id int(11) unsigned not null primary key, charid int(11) unsigned not null, 
zonename varchar(16) not null index, data blob not null, time timestamp(14);
*/

struct DBPlayerCorpse_Struct {
	int16	itemid;
	sint8	charges;
	bool	looted;
};

#pragma pack()

#endif

