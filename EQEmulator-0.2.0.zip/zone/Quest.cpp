#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#define snprintf	_snprintf
#else
	#include "unix.h"
#endif

#include "quest.h"

pquest_entry	Quest::m_pQuests;
int				Quest::m_nQuests;

Quest::Quest()
{
	m_pQuests = NULL;
	m_nQuests = 0;
}

Quest::~Quest()
{
	for( int i=0;i<m_nQuests;i++ )
	{
		delete m_pQuests[ i ].m_pQuestName;
		delete m_pQuests[ i ].m_pQuestText;
		delete m_pQuests[ i ].m_pQuestEnd;
	}
	delete[] m_pQuests;
}

bool Quest::Open( class Database * database, char* zonename )
{
char *			query = 0;
int					buf_len = 256;
int					chars = -1;
MYSQL_RES *	result;
MYSQL_ROW		row;

	query = new char[ buf_len ];
	sprintf( query, "SELECT name, text, end, npcID, questobject, priceobject, cash, exp FROM quest WHERE zone='%s'", zonename );

	if( !mysql_query( &database->mysql, query ) )
	{
		delete[] query;
		result = mysql_store_result( &database->mysql );
		if( result )
		{
			m_nQuests = mysql_num_rows( result );
			if( m_nQuests )
			{
			int l_cnt = 0;
				m_pQuests = new quest_entry[ m_nQuests ];
				row	= mysql_fetch_row( result ); // Extrae una linea
				while( row )
				{
					m_pQuests[ l_cnt ].m_pQuestName = new char[ strlen( row[0] )+1 ];
					strcpy( m_pQuests[ l_cnt ].m_pQuestName, row[0] );
					m_pQuests[ l_cnt ].m_pQuestText = new char[ strlen( row[1] )+1 ];
					strcpy( m_pQuests[ l_cnt ].m_pQuestText, row[1] );
					m_pQuests[ l_cnt ].m_pQuestEnd = new char[ strlen( row[2] )+1 ];
					strcpy( m_pQuests[ l_cnt ].m_pQuestEnd, row[2] );
					
					m_pQuests[ l_cnt ].m_iNpcId				= atoi( row[3] );
					m_pQuests[ l_cnt ].m_iQuestObject	= atoi( row[4] );
					m_pQuests[ l_cnt ].m_iQuestPrice	= atoi( row[5] );
					m_pQuests[ l_cnt ].m_iQuestCash		= atoi( row[6] );
					m_pQuests[ l_cnt ].m_iQuestExp		= atoi( row[7] );
					cerr << "Quests '" << m_pQuests[ l_cnt ].m_pQuestName << "' , NPCID " << m_pQuests[ l_cnt ].m_iNpcId << endl;
					l_cnt++;
					row	= mysql_fetch_row( result ); 
				}
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}
	cerr << "Error in Quests::Open query '" << query << "' " << mysql_error(&database->mysql) << endl;
	delete[] query;

return false;
}

pquest_entry	Quest::Test( int NpcId, int QuestObject )
{
	for( int i=0;i<m_nQuests;i++ )
		if( m_pQuests[ i ].m_iNpcId == NpcId &&  m_pQuests[ i ].m_iQuestObject	== QuestObject )
			return &m_pQuests[ i ];
return NULL;
}