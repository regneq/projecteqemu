#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <iomanip.h>
#include <time.h>
#include <stdlib.h>

#ifdef BUILD_FOR_WINDOWS
	#include <process.h>
	#include <windows.h>
	#include <winsock.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp	_stricmp

#else // Pyro: fix for linux
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <pthread.h>
	#include <errno.h>
	#include <unistd.h>

	#include "../common/unix.h"

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1
	extern int errno;
#endif

#include "../common/servertalk.h"
#include "worldserver.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "mob.h"
#include "zone.h"
#include "client.h"
#include "entity.h"
#include "net.h"

extern Database database;
extern EntityList    entity_list;
extern Zone* zone;
extern void CatchSignal(int);
extern WorldServer* worldserver;
extern NetConnection net;
extern GuildRanks_Struct guilds[512];

bool AttemptingConnect = false;

WorldServer::WorldServer(int32 in_ip, int16 in_port, int in_send_socket)
{
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	timeout_timer = new Timer(SERVER_TIMEOUT);
}

WorldServer::~WorldServer()
{
	if (zone != 0)
		entity_list.ChannelMessageFromWorld(0, 0, 6, 0, 0, "WARNING: World server connection lost");
	shutdown(send_socket, 0x01);
	shutdown(send_socket, 0x00);
#ifdef BUILD_FOR_WINDOWS
	closesocket(send_socket);
#else
	close(send_socket);
#endif
/*
	if (zone == 0) {
// If zoneserver is in sleep mode, exit program since without
// the worldserver connection, there's no possibility of a
// #zonebootup getting through (until i put in autoreconnect code)
		cout << "AutoShutdown: ~WorldServer: zone == 0" << endl;
		CatchSignal(2);
	}
*/
}

void WorldServer::SetZone(char* zonename) {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_SetZone;
	pack->size = strlen(zonename) + 1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	memcpy(pack->pBuffer, zonename, strlen(zonename));
	SendPacket(pack);
	delete pack;
}

void WorldServer::SetConnectInfo() {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_SetConnectInfo;
	pack->size = sizeof(ServerConnectInfo);
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerConnectInfo* sci = (ServerConnectInfo*) pack->pBuffer;
	sci->port = net.GetZonePort();
	strcpy(sci->address, net.GetZoneAddress());
	SendPacket(pack);
	delete pack;
}

bool WorldServer::Process()
{
	if (this == 0) return true;
#ifdef BUILD_FOR_WINDOWS
    SOCKADDR_IN to;
#else
    struct sockaddr_in to;
#endif

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	ServerPacket *pack = 0;
	while(pack = ServerOutQueue.pop())
	{
		switch(pack->opcode) {
		case 0:
		break;
		case ServerOP_KeepAlive: {
			// ignore this
			break;
		}
		case ServerOP_ChannelMessage:
		{
			if (zone == 0) break;
			ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;
			if (scm->deliverto[0] == 0) {
				entity_list.ChannelMessageFromWorld(scm->from, scm->to, scm->chan_num, scm->guilddbid, scm->language, scm->message);
			}
			else {
				Client* client;
				client = entity_list.GetClientByName(scm->deliverto);
				if (client != 0) {
					if (client->Connected()) {
						client->ChannelMessageSend(scm->from, scm->to, scm->chan_num, scm->language, scm->message);
						if (!scm->noreply) {
							// if it's a tell, echo back so it shows up
							scm->noreply = true;
							scm->chan_num = 14;
							memset(scm->deliverto, 0, sizeof(scm->deliverto));
							strcpy(scm->deliverto, scm->from);
							SendPacket(pack);
						}
					}
				}
			}
			break;
		}
		case ServerOP_EmoteMessage: {
			if (zone == 0) break;
			ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
			if (sem->to[0] != 0) {
				if (strcasecmp(sem->to, zone->GetShortName()) == 0)
					entity_list.Message(sem->guilddbid, sem->type, sem->message);
				else {
					Client* client = entity_list.GetClientByName(sem->to);
					if (client != 0)
						client->Message(sem->type, sem->message);
				}
			}
			else
				entity_list.Message(sem->guilddbid, sem->type, sem->message);
			break;
		}
		case ServerOP_ShutdownAll: {
			entity_list.Save();
			CatchSignal(2);
			break;
		}
		case ServerOP_ZoneShutdown: {
			// Annouce the change to the world
			if (zone == 0) {
				SetZone("");
			}
			else {
				worldserver->SendEmoteMessage(0, 0, 15, "Zone shutdown: %s", zone->GetLongName());

				ServerZoneStateChange_struct* zst = (ServerZoneStateChange_struct *) pack->pBuffer;
				cout << "Zone shutdown by " << zst->adminname << endl;
				ZoneShutdown();
			}
			break;
		}
		case ServerOP_ZoneBootup: {
			ServerZoneStateChange_struct* zst = (ServerZoneStateChange_struct *) pack->pBuffer;
			if (zone != 0) {
				SetZone(zone->GetShortName());
				if (strcasecmp(zst->zonename, zone->GetShortName()) == 0) {
					// This packet also doubles as "incomming client" notification, lets not shut down before they get here
					zone->StartShutdownTimer(AUTHENTICATION_TIMEOUT * 1000);
				}
				else {
					worldserver->SendEmoteMessage(zst->adminname, 0, 0, "Zone bootup failed: Already running '%s'", zone->GetShortName());
				}
				break;
			}

			if (zst->adminname[0] != 0)
				cout << "Zone bootup by " << zst->adminname << endl;

			if (!(ZoneBootup(zst->zonename))) {
				worldserver->SendEmoteMessage(zst->adminname, 0, 0, "Zone bootup failed");
			}
// Moved annoucement to ZoneBootup() - Quagmire
//			else
//				worldserver->SendEmoteMessage(0, 0, 15, "Zone bootup: %s", zone->GetLongName());
			break;
		}
		case ServerOP_ZonePlayer: {
			ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(szp->name);
			if (client != 0) {
				if (strcasecmp(szp->adminname, szp->name) == 0)
					client->Message(0, "Zoning to: %s", szp->zone);
				else {
					worldserver->SendEmoteMessage(szp->adminname, 0, 0, "Summoning %s to %s %1.1f, %1.1f, %1.1f", szp->name, szp->zone, szp->x_pos, szp->y_pos, szp->z_pos);
				}
				client->MovePC(szp->zone, szp->x_pos, szp->y_pos, szp->z_pos, szp->ignorerestrictions);
			}
			break;
		}
		case ServerOP_KickPlayer: {
			ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(skp->name);
			if (client != 0) {
				client->Kick();
				if (zone != 0)
					worldserver->SendEmoteMessage(skp->adminname, 0, 0, "Kick: %s: kicking %s", zone->GetShortName(), skp->name);
				else
					worldserver->SendEmoteMessage(skp->adminname, 0, 0, "Kick: zoneserver: kicking %s", skp->name);
			}
			break;
		}
		case ServerOP_RefreshGuild: {
			if (pack->size == 5) {
				int32 guildeqid = 0;
				memcpy(&guildeqid, pack->pBuffer, 4);
				database.GetGuildRanks(guildeqid, &guilds[guildeqid]);
				if (pack->pBuffer[4] == 1) {
					APPLAYER* outapp = new APPLAYER;
					outapp->opcode = OP_GuildUpdate;
	   				outapp->size = 64;
					outapp->pBuffer = new uchar[outapp->size];
					memset(outapp->pBuffer, 0, outapp->size);
					GuildUpdate_Struct* gu = (GuildUpdate_Struct*) outapp->pBuffer;
					gu->guildID = guildeqid;
					gu->entry.guildID = guildeqid;
					if (guilds[guildeqid].databaseID == 0) {
						gu->entry.exists = 0; // = 0x01 if exists, 0x00 on empty
					}
					else {
						strcpy(gu->entry.name, guilds[guildeqid].name);
						gu->entry.exists = 1; // = 0x01 if exists, 0x00 on empty
					}
					gu->entry.unknown1[0] = 0xFF;
					gu->entry.unknown1[1] = 0xFF;
					gu->entry.unknown1[2] = 0xFF;
					gu->entry.unknown1[3] = 0xFF;
					gu->entry.unknown3[0] = 0xFF;
					gu->entry.unknown3[1] = 0xFF;
					gu->entry.unknown3[2] = 0xFF;
					gu->entry.unknown3[3] = 0xFF;

					entity_list.QueueClients(0, outapp, false);
					delete outapp;
				}
			}
			else
				cout << "Wrong size: ServerOP_RefreshGuild. size=" << pack->size << endl;
			break;
		}
		case ServerOP_GuildLeader: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (client->GuildRank() != 0)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is not rank 0.", client->GetName());
			else {
				if (database.SetGuildLeader(sgc->guilddbid, client->AccountID())) {
					worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s is now the leader of your guild.", client->GetName());
					ServerPacket* pack2 = new ServerPacket;
					pack2->opcode = ServerOP_RefreshGuild;
					pack2->size = 4;
					pack2->pBuffer = new uchar[pack->size];
					memcpy(pack2->pBuffer, &sgc->guildeqid, 4);
					worldserver->SendPacket(pack2);
					delete pack2;
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Guild leadership transfer failed.");
			}
			break;
		}
		case ServerOP_GuildInvite: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (!guilds[sgc->guildeqid].rank[sgc->fromrank].invite)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to inite.");
			else if (client->GuildDBID() != 0)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is already in another guild.", client->GetName());
			else if (client->PendingGuildInvite != 0 && !(client->PendingGuildInvite == sgc->guilddbid))
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s has another pending guild invite.", client->GetName());
			else {
				client->PendingGuildInvite = sgc->guilddbid;
				APPLAYER* outapp = new APPLAYER;
				outapp->opcode = OP_GuildInvite;
				outapp->size = sizeof(GuildCommand_Struct);
				outapp->pBuffer = new uchar[outapp->size];
				memset(outapp->pBuffer, 0, outapp->size);
				GuildCommand_Struct* gc = (GuildCommand_Struct*) outapp->pBuffer;
				gc->guildeqid = sgc->guildeqid;
				strcpy(gc->othername, sgc->target);
				strcpy(gc->myname, sgc->from);
				client->QueuePacket(outapp);
/*				
				if (client->SetGuild(sgc->guilddbid, GUILD_MAX_RANK))
					worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has joined the guild. Rank: %s.", client->GetName(), guilds[sgc->guildeqid].rank[GUILD_MAX_RANK].rankname);
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Guild invite failed.");
*/
			}
			break;
		}
		case ServerOP_GuildRemove: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if ((!guilds[sgc->guildeqid].rank[sgc->fromrank].remove) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to remove.");
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (client->GuildRank() <= sgc->fromrank && !(sgc->fromaccountid == guilds[sgc->guildeqid].leader) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s's rank is too high for you to remove them.", client->GetName());
			else {
				if (client->SetGuild(0, GUILD_MAX_RANK)) {
					if (strcasecmp(sgc->from, sgc->target) == 0)
						worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has left the guild.", client->GetName());
					else {
						worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been removed from the guild by %s.", client->GetName(), sgc->from);
						client->Message(MT_Guild, "You have been removed from the guild by %s.", sgc->from);
					}
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Guild remove failed.");
			}
			break;
		}
		case ServerOP_GuildPromote: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if ((!guilds[sgc->guildeqid].rank[sgc->fromrank].promote) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to promote.");
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s isnt in your guild.", client->GetName());
			else if (client->GuildRank() <= sgc->newrank)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is already rank %i.", client->GetName(), client->GuildRank());
			else if (sgc->newrank <= sgc->fromrank && sgc->fromaccountid != guilds[sgc->guildeqid].leader)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You cannot promote people to a greater or equal rank than yourself.");
			else {
				if (client->SetGuild(sgc->guilddbid, sgc->newrank)) {
					worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been promoted to %s by %s.", client->GetName(), guilds[sgc->guildeqid].rank[sgc->newrank].rankname, sgc->from);
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Guild promote failed");
			}
			break;
		}
		case ServerOP_GuildDemote: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (!guilds[sgc->guildeqid].rank[sgc->fromrank].demote)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to demote.");
			else if (client->GuildRank() >= sgc->newrank)
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "%s is already rank %i.", client->GetName(), client->GuildRank());
			else if (sgc->newrank <= sgc->fromrank && sgc->fromaccountid != guilds[sgc->guildeqid].leader && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver->SendEmoteMessage(sgc->from, 0, 0, "You cannot demote people with a greater or equal rank than yourself.");
			else {
				if (client->SetGuild(sgc->guilddbid, sgc->newrank)) {
					worldserver->SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been demoted to %s by %s.", client->GetName(), guilds[sgc->guildeqid].rank[sgc->newrank].rankname, sgc->from);
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Guild demote failed");
			}
			break;
		}
		case ServerOP_GuildGMSet: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);
			if (client != 0) {
				if (client->GuildDBID() == 0 || sgc->guilddbid == 0) {
					if (!client->SetGuild(sgc->guilddbid, GUILD_MAX_RANK))
						worldserver->SendEmoteMessage(sgc->from, 0, 0, "Error: Guild #%i not found", sgc->guilddbid);
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Error: %s is already in a guild", sgc->target);
			}
			break;
		}
		case ServerOP_GuildGMSetRank: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);
			if (client != 0) {
				if (client->GuildDBID() != 0) {
					if (!client->SetGuild(client->GuildDBID(), sgc->newrank))
						worldserver->SendEmoteMessage(sgc->from, 0, 0, "Error: SetRank failed.", sgc->guilddbid);
				}
				else
					worldserver->SendEmoteMessage(sgc->from, 0, 0, "Error: %s is not in a guild", sgc->target);
			}
			break;
		}
		case ServerOP_FlagUpdate: {
			Client* client = entity_list.GetClientByAccID(database.GetAccountIDByName((char*) pack->pBuffer));
			if (client != 0) {
				client->UpdateAdmin();
			}
			break;
		}
		default:
		{
			cout << " Unknown ZSopcode:" << (int)pack->opcode;
			cout << " size:" << pack->size << endl;
DumpPacket(pack->pBuffer, pack->size);
			break;
		}
		}

		delete pack;
	}

	/************ Get first send packet on queue and send it! ************/
	SPackSendQueue* p = 0;    
	int status = 0;
	uchar* buf = 0;
	int16 size = 0;
	while(p = ServerSendQueue.pop())
	{
//		cout << "Worldserver packet sent: OPcode=" << p->opcode << " size=" << p->size << endl;

#ifdef BUILD_FOR_WINDOWS
		status = send(send_socket, (const char *) p->buffer, p->size, 0);
#else
		status = send(send_socket, p->buffer, p->size, 0);
#endif
		delete p->buffer;
		delete p;
		if (status == SOCKET_ERROR) {
#ifdef BUILD_FOR_WINDOWS
    		cout << "Worldserver send(): status=" << status  << ", Errorcode: " << WSAGetLastError() << endl;
#else
    		cout << "Worldserver send(): status=" << status  << ", Errorcode: " << strerror(errno) << endl;
#endif
			return false;
		}
	}
	/************ Processing finished ************/
    if (timeout_timer->Check())
    {
		// Keepalive packet doesnt actually do anything
		// just makes sure that send() still works, if not connection is dead
		pack = new ServerPacket;
		pack->opcode = ServerOP_KeepAlive;
		pack->size = 0;
		SendPacket(pack);
		delete pack;
    }

	return true;
}

void WorldServer::SendPacket(ServerPacket* pack) {
	SPackSendQueue* spsq = new SPackSendQueue;
	spsq->buffer = new uchar[pack->size + 4];
	if (pack->pBuffer != 0 && pack->size != 0)
		memcpy((char *) &spsq->buffer[4], (char *) pack->pBuffer, pack->size);
	memcpy((char *) &spsq->buffer[0], (char *) &pack->opcode, 2);
	spsq->size = pack->size+4;
	memcpy((char *) &spsq->buffer[2], (char *) &spsq->size, 2);
	ServerSendQueue.push(spsq);
}

void WorldServer::SendChannelMessage(Client* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->size = sizeof(ServerChannelMessage_Struct) + strlen(buffer) + 1;
	pack->pBuffer = new uchar[pack->size];
    memset(pack->pBuffer, 0, pack->size);
	ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;

	pack->opcode = ServerOP_ChannelMessage;
	if (from == 0)
		strcpy(scm->from, "ZServer");
	else {
		strcpy(scm->from, from->GetName());
		scm->fromadmin = from->Admin();
	}
	if (to == 0)
		scm->to[0] = 0;
	else {
		strcpy(scm->to, to);
		strcpy(scm->deliverto, to);
	}
	scm->chan_num = chan_num;
	scm->guilddbid = guilddbid;
	scm->language = language;
	scm->messagesize = strlen(buffer)+1;
	strcpy(&scm->message[0], buffer);

	SendPacket(pack);
	delete pack;
}


bool WorldServer::ReceiveData() {
    uchar		buffer[10240];
	
    int			status;
    unsigned short	port;

    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

#ifdef BUILD_FOR_WINDOWS
    status = recvfrom(send_socket, (char *) &buffer, sizeof(buffer), 0, (struct sockaddr*) &from, (int *) &fromlen);
#else
    status = recvfrom(send_socket, (char *) &buffer, sizeof(buffer), 0, (struct sockaddr*) &from, &fromlen);
#endif

    if (status > 1)
    {
		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

//cout << "TCPData from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << " length: " << status << endl;
//DumpPacket(buffer, status);

		timeout_timer->Start();
		int16 base = 0;
		int16 size = 0;
		while (base < status) {
			size = 4;
			if ((status - base) < 4)
				cout << "ZoneServer: packet too short for processing" << endl;
			else {
				ServerPacket* pack = new ServerPacket;
				memcpy((char*) &size, (char*) &buffer[base + 2], 2);

				memcpy((char*) &pack->opcode, (char*) &buffer[base + 0], 2);
				pack->size = size - 4;
				if (size > 4) {
					pack->pBuffer = new uchar[pack->size];
					memcpy((char*) pack->pBuffer, (char*) &buffer[base + 4], pack->size);
				} else
					pack->pBuffer = 0;
//cout << "Packet from worldserver: OPcode=0x" << hex << setw(4) << setfill('0') << pack->opcode << dec << " size=" << pack->size << endl;
				ServerOutQueue.push(pack);
			}
			base += size;
		}
    } else if (status == SOCKET_ERROR) {
#ifdef BUILD_FOR_WINDOWS
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
#else
		if (!(errno == EWOULDBLOCK)) {
#endif
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Worldserver connection lost: " << inet_ntoa(in) << ":" << GetPort() << endl;
			return false;
		}
	}
	return true;
}

void WorldServer::SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);
	
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_EmoteMessage;
	pack->size = sizeof(ServerEmoteMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
	sem->type = type;
	if (to != 0)
		strcpy(sem->to, to);
	sem->guilddbid = to_guilddbid;
	sem->messagesize = strlen(buffer);
	strcpy(sem->message, buffer);
	SendPacket(pack);
}

// this should always be called in a new thread
#ifdef BUILD_FOR_WINDOWS
	void ClientInitWorldServer(void *tmp) {
#else
	void *ClientInitWorldServer(void *tmp) {
#endif
	Client* client = (Client*) tmp;
	if (worldserver != 0) {
		client->ChannelMessageSend(0, 0, 7, 0, "Already connected to worldserver");
		if (zone != 0)
			entity_list.UpdateWho();
	}
	else if (AttemptingConnect)
		client->ChannelMessageSend(0, 0, 7, 0, "Already attempting to connect to worldserver");
	else {
		client->ChannelMessageSend(0, 0, 7, 0, "Attempting to connect to worldserver...");
		if (!InitWorldServer()) {
			client->ChannelMessageSend(0, 0, 7, 0, "Worldserver connect failed");
			worldserver=0;
		} else {
			client->ChannelMessageSend(0, 0, 7, 0, "Worldserver connect succeeded");
		}
	}
#ifndef BUILD_FOR_WINDOWS
	return false;
#endif
}

// this should always be called in a new thread
#ifdef BUILD_FOR_WINDOWS
	void AutoInitWorldServer(void *tmp) {
#else
	void *AutoInitWorldServer(void *tmp) {
#endif
	if (worldserver == 0 && (!AttemptingConnect)) {
		if (!InitWorldServer()) {
			cout << "Worldserver autoreconnect... failed." << endl;
		} else {
			cout << "Worldserver autoreconnect... succeess." << endl;
		}
	}
#ifndef BUILD_FOR_WINDOWS
	return false;
#endif
}

bool InitWorldServer(bool DoTimer) {
	if (AttemptingConnect) {
		cout << "Error: InitWorldServer() while already attempting connect" << endl;
		return false;
	}
	AttemptingConnect = true;
#ifdef BUILD_FOR_WINDOWS
	SOCKET tmpsock = INVALID_SOCKET;
#else
	int tmpsock = INVALID_SOCKET;
#endif
	unsigned long nonblocking = 1;
    struct sockaddr_in	server_sin;
    struct in_addr	in;
#ifdef BUILD_FOR_WINDOWS
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;
	PHOSTENT phostent = NULL;

	WSAStartup (version, &wsadata);
#else
	struct hostent *phostent = NULL;
#endif

	if ((tmpsock = socket (AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)	{
#ifdef BUILD_FOR_WINDOWS
		cout << "WorldServer connect: Allocating socket failed. Error: " << WSAGetLastError();
#else
		cout << "WorldServer connect: Allocating socket failed. Error: " << strerror(errno);
#endif
		AttemptingConnect = false;
		return false;
	}


	server_sin.sin_family = AF_INET;

	if ((phostent = gethostbyname(net.GetWorldAddress())) == NULL) {
#ifdef BUILD_FOR_WINDOWS
		cout << "Unable to get the host name. Error: " << WSAGetLastError();
	    closesocket(tmpsock);
#else
		cout << "Unable to get the host name. Error: " << strerror(errno);
	    close(tmpsock);
#endif
		AttemptingConnect = false;
		return false;
	}
#ifdef BUILD_FOR_WINDOWS
	memcpy ((char FAR *)&(server_sin.sin_addr), phostent->h_addr, phostent->h_length);
#else
	memcpy ((char*)&(server_sin.sin_addr), phostent->h_addr, phostent->h_length);
#endif
	server_sin.sin_port = htons(PORT);

	// Establish a connection to the server socket.
#ifdef BUILD_FOR_WINDOWS
	if (connect (tmpsock, (PSOCKADDR) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		cout << "WorldServer connect: Connecting to the server failed. Error: " << WSAGetLastError() << endl;
		closesocket(tmpsock);
#else
	if (connect (tmpsock, (struct sockaddr *) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		cout << "WorldServer connect: Connecting to the server failed. Error: " << strerror(errno) << endl;
		close(tmpsock);
#endif
		AttemptingConnect = false;
		return false;
	}	
#ifdef BUILD_FOR_WINDOWS
	ioctlsocket (tmpsock, FIONBIO, &nonblocking);
#else
	fcntl(tmpsock, F_SETFL, O_NONBLOCK);
#endif

// had to put a mini-receivedata here to handel switching the TCP
// connection to Zoneserver mode when enabled console commands
	int status = 0;
	uchar buffer[1024];
	memset(buffer, 0, sizeof(buffer));
	Timer con_timeout(15000);
	con_timeout.Start();
	while (1) {
		if (DoTimer)
			Timer::SetCurrentTime();
		status = recv(tmpsock, (char*) buffer, sizeof(buffer), 0);
		if (status >= 1) {
//DumpPacket(buffer, status);
			if (strncmp((char*) buffer, "Username: ", 10) == 0) {
				send(tmpsock, "*ZONESERVER*\r\n", 14, 0);
			}
			else if (strncmp((char*) buffer, "ZoneServer Mode", 15) == 0 || strncmp((char*) buffer, "*ZONESERVER*\r\nZoneServer Mode", 29) == 0) {
				// Connection successful
				break;
			}
			else if (strncmp((char*) buffer, "Not Authorized.", 15) == 0 || strncmp((char*) buffer, "*ZONESERVER*\r\nNot Authorized.", 29) == 0) {
				// Connection failed. Worldserver said get lost
#ifdef BUILD_FOR_WINDOWS
				closesocket(tmpsock);
#else
				close(tmpsock);
#endif
				AttemptingConnect = false;
				return false;
			}
			else if (strncmp((char*) buffer, "*ZONESERVER*\r\n", 14) == 0) {
				// Catch the echo, wait for next packet
			}
			else {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Unexpected response." << endl;
DumpPacket(buffer, status);
#ifdef BUILD_FOR_WINDOWS
				closesocket(tmpsock);
#else
				close(tmpsock);
#endif
				AttemptingConnect = false;
				return false;
			}
		}
		else if (status == SOCKET_ERROR) {
#ifdef BUILD_FOR_WINDOWS
			if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Error: " << WSAGetLastError() << endl;
				closesocket(tmpsock);
#else // Pyro: fix for linux
			if (!(errno == EWOULDBLOCK)) {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Error: " << strerror(errno) << endl;
				close(tmpsock);
#endif
				AttemptingConnect = false;
				return false;
			}
		}
		if (con_timeout.Check()) {
			cout << "WorldServer connect: Connecting to the server failed: switch stage. Time out." << endl;
#ifdef BUILD_FOR_WINDOWS
			closesocket(tmpsock);
#else
			close(tmpsock);
#endif
			AttemptingConnect = false;
			return false;
		}
		Sleep(1);
	}


	in.s_addr = server_sin.sin_addr.s_addr;
	cout << "Connected to worldserver: " << inet_ntoa(in) << ":" << ntohs(server_sin.sin_port) << endl;
	worldserver = new WorldServer(in.s_addr, ntohs(server_sin.sin_port), tmpsock);
	AttemptingConnect = false;
#ifdef BUILD_FOR_WINDOWS
	_beginthread(WorldServerLoop, 0, NULL);
#else
	pthread_t thread;
	pthread_create(&thread, NULL, WorldServerLoop, NULL);
#endif
	return true;
}

// this should always be called in a new thread
#ifdef BUILD_FOR_WINDOWS
	void WorldServerLoop(void *tmp) {
#else
	void *WorldServerLoop(void *tmp) {
#endif
	srand(time(NULL));
	worldserver->SetConnectInfo();
	if (zone != 0) {
		worldserver->SetZone(zone->GetShortName());
		entity_list.UpdateWho();
		worldserver->SendEmoteMessage(0, 0, 15, "Zone connect: %s", zone->GetLongName());
	}
	while(worldserver != 0) {
		if (!(worldserver->ReceiveData() && worldserver->Process())) {
			delete worldserver;
			worldserver=0;
		}
		Sleep(1);
	}
#ifndef BUILD_FOR_WINDOWS
	return 0;
#endif
}
