// This class will split up a string smartly at the div character (default is space)
// Seperator.arg[i] is a copy of the string chopped at the divs
// Seperator.argplus[i] is a pointer to the original string so it doesnt end at the div

// Written by Quagmire
#ifndef SEPERATOR_H
#define SEPERATOR_H
#define arglen 100
#define argnum 10		// Not including 0

class Seperator
{
public:
	Seperator(char* message, char div = ' ') {
		int i;
		for (i=0; i <= argnum; i++) {
			memset(arg[i], 0, sizeof(arg[i]));
			argplus[i] = arg[i];
		}

		int len = strlen(message);
		int a = 0, s = 0, l = 0;
		bool inarg = (!(message[0] == div));
		argplus[0] = message;
		for (i=0; i <= len; i++) {
			if (inarg) {
				if (message[i] == div) {
					l = i-s;
					if (l >= (arglen-1))
						l = (arglen-1);
					memcpy(arg[a], argplus[a], l);
					memset(&arg[a][l], 0, 1);
					a++;
					inarg = false;
				}
			}
			else {
				s = i;
				argplus[a] = &message[i];
				if (!(message[i] == div)) {
					inarg = true;
				}
			}
			if (a > argnum)
				break;
		}
		if (inarg)
			memcpy(arg[a], argplus[a], (i-s) - 1);
	}
	~Seperator() {}
	char arg[argnum+1][arglen];
	char* argplus[argnum+1];
	bool IsNumber(int num) {
		return IsNumber(arg[num]);
	}
	static bool IsNumber(char* check) {
		bool SeenDec = false;
		int len = strlen(check);
		if (len == 0) {
			return false;
		}
		int i;
		for (i = 0; i < len; i++) {
			if (check[i] < '0' || check[i] > '9') {
				if (check[i] == '.' && !SeenDec) {
					SeenDec = true;
				}
				else if (i == 0 && (check[i] == '-' || check[i] == '+') && !check[i+1] == 0) {
					// this is ok, do nothin
				}
				else {
					return false;
				}
			}
		}
		return true;
	}
};

#endif
