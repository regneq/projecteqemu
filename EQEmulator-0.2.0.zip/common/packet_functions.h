#ifndef PACKET_FUNCTIONS_H
#define PACKET_FUNCTIONS_H

void SetEQChecksum(uchar* in_data, int32 in_length);
void EncryptProfilePacket(APPLAYER* app);
void EncryptSpawnPacket(APPLAYER* app);
int DeflatePacket(unsigned char* in_data, int in_length, unsigned char* out_data, int max_out_length);

#endif
