#ifndef EQ_SOPCODES_H
#define EQ_SOPCODES_H

#define EQEMU_VERSION	"0.2.0"

#pragma pack(1)

#define SERVER_TIMEOUT	60000	// how often keepalive gets sent
#define INTERSERVER_TIMER					90000
#define LoginServer_StatusUpdateInterval	15000
#define LoginServer_AuthStale				60000
#define AUTHCHANGE_TIMEOUT					900	// in seconds

#define ServerOP_KeepAlive			0x0001	// packet to test if port is still open
#define ServerOP_ChannelMessage		0x0002	// broadcast/guildsay
#define ServerOP_SetZone			0x0003	// client -> server zoneinfo
#define ServerOP_ShutdownAll		0x0004	// exit(0);
#define ServerOP_ZoneShutdown		0x0005	// unload all data, goto sleep mode
#define ServerOP_ZoneBootup			0x0006	// come out of sleep mode and load zone specified
#define ServerOP_ZoneStatus			0x0007	// Shows status of all zones
#define ServerOP_SetConnectInfo		0x0008	// Tells server address and port #
#define ServerOP_EmoteMessage		0x0009	// Worldfarts
#define ServerOP_ClientList			0x000A	// Update worldserver's client list, for #whos
#define ServerOP_Who				0x000B	// #who
#define ServerOP_ZonePlayer			0x000C  // #zone, or #summon
#define ServerOP_KickPlayer			0x000D  // #kick
#define ServerOP_RefreshGuild		0x000E	// Notice to all zoneservers to refresh their guild cache for ID# in packet
#define ServerOP_GuildKickAll		0x000F	// Remove all clients from this guild
#define ServerOP_GuildInvite		0x0010
#define ServerOP_GuildRemove		0x0011
#define ServerOP_GuildPromote		0x0012
#define ServerOP_GuildDemote		0x0013
#define ServerOP_GuildLeader		0x0014
#define ServerOP_GuildGMSet			0x0015
#define ServerOP_GuildGMSetRank		0x0016
#define ServerOP_FlagUpdate			0x0018	// GM Flag updated for character, refresh the memory cache

#define ServerOP_LSInfo				0x1000
#define ServerOP_LSStatus			0x1001
#define ServerOP_LSClientAuth		0x1002
#define ServerOP_LSBadVersion		0x1003
#define ServerOP_LSBadPassword		0x1004
#define ServerOP_SystemwideMessage	0x1005

#include "../common/timer.h"

/************ PACKET RELATED STRUCT ************/
class ServerPacket
{
public:
	~ServerPacket() { if (pBuffer !=0) delete[] pBuffer; }
	ServerPacket() { size = 0; opcode = 0; pBuffer = 0; }
	int16  size;
	int16  opcode;
	uchar* pBuffer;
/*	ServerPacket* CopyPacket() {
		ServerPacket *pack = new ServerPacket;
		pack->opcode = this->opcode;
		pack->size = this->size;
		pack->pBuffer = new uchar[pack->size];
		memcpy(pack->pBuffer, this->pBuffer, pack->size);
		return pack;
	}*/
};

struct SPackSendQueue {
	int16 size;
	uchar* buffer;
};

struct ServerZoneStateChange_struct {
	int32 ZoneServerID;
	char adminname[30];
	char zonename[15];
};

struct ServerChannelMessage_Struct {
	char  deliverto[23];
	char  to[23];
	char  from[23];
	int8 fromadmin;
	bool  noreply;
	int16 chan_num;
	int32 guilddbid;
	int16  language;
	int16 messagesize;
	char  message[0];
};

struct ServerEmoteMessage_Struct {
	char to[23];
	int32 guilddbid;
	int32 type;
	int16 messagesize;
	char message[0];
};

struct ServerClientList_Struct {
	bool remove;
	char zone[30];
	int8 Admin;
	char name[30];
	int32 AccountID;
	char AccountName[30];
	int8 race;
	int8 class_;
	int8 level;
	int8 anon;
	bool tellsoff;
	int32 guilddbid;
	int32 guildeqid;
};

struct ServerZonePlayer_Struct {
	char	adminname[30];
	bool	ignorerestrictions;
	char	name[30];
	char	zone[15];
    float	x_pos;
    float	y_pos;
    float	z_pos;
};

struct ServerKickPlayer_Struct {
	char adminname[30];
	char name[30];
	int32 AccountID;
};

struct ServerGuildCommand_Struct {
	int32 guilddbid;
	int32 guildeqid;
	char from[30];
	int8 fromrank;
	int32 fromaccountid;
	char target[30];
	int8 newrank;
	int8 admin;
};

struct ServerLSInfo_Struct {
	char	name[201];		// name the worldserver wants
	char	address[250];	// DNS address of the server
	char	account[31];	// account name for the worldserver
	char	password[31];	// password for the name
	char	version[25];	// server's version #
	int8	servertype;		// 0=world, 1=chat
};

struct ServerLSStatus_Struct {
	sint32 status;
};

struct ServerLSClientAuth {
	int32	lsaccount_id;	// ID# in login server's db
	char	name[30];		// username in login server's db
	char	key[30];		// the Key the client will present
	int8	lsadmin;		// login server admin level
};

struct ServerSystemwideMessage {
	int32	lsaccount_id;
	char	key[30];		// sessionID key for verification
	int32	type;
	char	message[0];
};

struct ServerConnectInfo {
	char	address[250];
	int16	port;
};

#pragma pack()

#endif
