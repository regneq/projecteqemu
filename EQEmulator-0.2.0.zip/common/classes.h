#ifndef CLASSES_CH
#define CLASSES_CH

#define WARRIOR      1
#define CLERIC       2
#define PALADIN      3
#define RANGER       4
#define SHADOWKNIGHT 5
#define DRUID        6
#define MONK         7
#define BARD         8
#define ROGUE        9
#define SHAMAN      10
#define NECROMANCER 11
#define WIZARD      12
#define MAGICIAN    13
#define ENCHANTER   14
#define BEASTLORD   15

char* GetClassName(int8 class_);

#endif

