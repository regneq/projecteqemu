#ifndef DATABASE_H
#define DATABASE_H

#define AUTHENTICATION_TIMEOUT 60

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#endif

#include <mysql.h>

#include "types.h"
#include "linked_list.h"
#include "eq_packet_structs.h"
#include "../common/guilds.h"
#include "../zone/faction.h"
#include "../zone/loottable.h"

//class Spawn;
class Spawn2;
class SpawnGroupList;
struct ZonePoint;

#pragma pack(1)

struct NPCType
{
    char    name[30];
    char    lastname[20];

    sint32  cur_hp;
    sint32  max_hp;

    int8    gender;
    int8    race;
    int8    class_;
    int8    deity;
    int8    level;
	int32   npc_id; // rembrant, Dec. 20, 2001
	int8    skills[74]; // socket 12-29-01
	int8	texture;
	int8	helmtexture;
	int32	loottable_id;

    int8    light;
    int8    equipment[9];

	int16	AC;
	int16	Mana;
	int16	ATK;
	int8	STR;
	int8	STA;
	int8	DEX;
	int8	AGI;
	int8	INT;
	int8	WIS;
	int8	CHA;
	sint16	MR;
	sint16	FR;
	sint16	CR;
	sint16	PR;
	sint16	DR;
};

#pragma pack()

// Added By Hogie 
// INSERT into variables (varname,value) values('decaytime [minlevel] [maxlevel]','[number of seconds]');
// IE: decaytime 1 54 = Levels 1 through 54
//     decaytime 55 100 = Levels 55 through 100
// It will always put the LAST time for the level (I think) from the Database
struct npcDecayTimes_Struct {
	int16 minlvl;
	int16 maxlvl;
	int32 seconds;
};
// Added By Hogie -- End

class Database
{
public:
	#ifdef WIN32
		Database();
	#else
		Database(const char* host, const char* user, const char* passwd, const char* database);
	#endif
	~Database();

	bool	GetDecayTimes(npcDecayTimes_Struct* npcCorpseDecayTimes);
//	bool	PopulateZoneLists(char* zone_name, NPCType* &npc_type_array, uint32 &max_npc_type, LinkedList<Spawn*>& spawn_list, LinkedList<ZonePoint*>& zone_point_list, LinkedList<Spawn2*> &spawn2_list, SpawnGroupList* spawn_group_list);
	bool	PopulateZoneLists(char* zone_name, LinkedList<ZonePoint*>* zone_point_list, SpawnGroupList* spawn_group_list);
	bool	PopulateZoneSpawnList(char* zone_name, LinkedList<Spawn2*> &spawn2_list, int32 repopdelay = 0);
	Spawn2*	LoadSpawn2(LinkedList<Spawn2*> &spawn2_list, int32 spawn2id, int32 timeleft);
	bool	DumpZoneState();
	sint8	LoadZoneState(char* zonename, LinkedList<Spawn2*>& spawn2_list);
	bool	GetZoneLongName(char* short_name, char** long_name, char* file_name = 0);
	bool	RegisterZoneServer(char* name, char* address, int16 port);
	bool	UnregisterZoneServer(char* address, int16 port);
	void	ClearZoneServerTable();
	bool	GetZoneServer(char* name);
	bool	GetZoneServer(char* name, char* address, int16* port);
	int32	GetAuthentication(char* char_name, char* zone_name, int32 ip);
	bool	SetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool	GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool	ClearAuthentication(int32 account_id);

	int32	CheckLogin(char* name, char* password);
	int8	CheckStatus(int32 account_id);
	int32	CheckZoneWeather(char* zonename);
	int32	SetZoneWeather(char* zonename, char* weather);
	bool	CreateAccount(char* name, char* password, int8 status, int32 lsaccount_id = 0);
	int32	DeleteAccount(char* name);
	bool	SetGMFlag(char* name, int8 status);
	bool	CheckZoneserverAuth(char* ipaddr);

	void	GetCharSelectInfo(int32 account_id, CharacterSelect_Struct*);
	bool	GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);
	bool	SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);

	bool	CheckNameFilter(char* name);
	bool	AddToNameFilter(char* name);
	bool	ReserveName(int32 account_id, char* name);
	bool	CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis, int8 face);
	bool	DeleteCharacter(char* name);
	
	int32	GetAccountIDByChar(char* charname);
	int32	GetAccountIDByName(char* accname);
	void	GetAccountName(int32 accountid, char* name);
	void	GetCharacterInfo(char* name, int32* charid, int32* guilddbid, int8* guildrank);

	bool	GetVariable(char* varname, char* varvalue, int16 varvalue_len);
	bool	SetVariable(char* varname, char* varvalue);
	bool	LoadGuilds(GuildRanks_Struct* guilds);
	bool	GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr);
	int32	GetGuildEQID(int32 guilddbid);
	bool	SetGuild(int32 charid, int32 guilddbid, int8 guildrank);
	int32	GetFreeGuildEQID();
	int32	CreateGuild(char* name, int32 leader);
	bool	DeleteGuild(int32 guilddbid);
	bool	RenameGuild(int32 guilddbid, char* name);
	bool	EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl);
	int32	GetGuildDBIDbyLeader(int32 leader);
	bool	SetGuildLeader(int32 guilddbid, int32 leader);
	bool	SetGuildMOTD(int32 guilddbid, char* motd);
	bool	GetGuildMOTD(int32 guilddbid, char* motd);

	bool	GetSafePoints(char* short_name, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0, int8* minstatus = 0, int8* minlevel = 0);
	bool	LoadItems();
	bool	LoadNPCTypes();
	Item_Struct*	GetItem(uint32 id);
	NPCType*		GetNPCType(uint32 id);

	sint32	GetCharacterFactionLevel(int32 char_id, int32 faction_id); // rembrant, needed for factions Dec, 16 2001
	bool	GetNPCFactionList(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetNPCPrimaryFaction(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetFactionData(FactionMods* fd, sint32 class_mod, sint32 race_mod, sint32 deity_mod, int32 faction_id); //rembrant, needed for factions Dec, 16 2001
	bool	GetFactionName(int32 faction_id, char* name); // rembrant, needed for factions Dec, 16 2001
	bool	SetCharacterFactionLevel(int32 char_id, int32 faction_id, sint32 value); // rembrant, needed for factions Dec, 16 2001

	int32	GetAccountIDFromLSID(int32 lsaccount_id);

	bool	SetLSAuthChange(int32 account_id, char* ip);
	bool	UpdateLSAccountAuth(int32 account_id, int8* auth);
	int32	GetLSAuthentication(int8* auth);
	int32	GetLSAuthChange(char* ip);
	bool	ClearLSAuthChange();
	bool	RemoveLSAuthChange(int32 account_id);
	bool	GetLSAccountInfo(int32 account_id, char* name, int8* lsadmin);
	sint8	CheckWorldAuth(char* account, char* password, int32* account_id, int32* admin_id, bool* GreenName);
	bool	UpdateWorldName(int32 accountid, char* name);
	void	LoadWorldList();

	void	ping();
	MYSQL	mysql;

	uint32			max_item;
	Item_Struct**	item_array;
	uint32			max_npc_type;
	NPCType**		npc_type_array;

	void AddLootTableToNPC(int32 loottable_id, ItemList* itemlist, int32* copper, int32* silver, int32* gold, int32* plat);
private:
	void AddLootDropToNPC(int32 lootdrop_id, ItemList* itemlist);
};
#endif

