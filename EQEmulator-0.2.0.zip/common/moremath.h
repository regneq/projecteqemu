signed char sign(signed int tmp);
