/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef WORLDSERVER_H
#define WORLDSERVER_H

#include "../common/servertalk.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/packet_functions.h"
#include "../common/eq_packet_structs.h"
#include "../common/Mutex.h"
#include "mob.h"

const int PORT = 9000;
#ifdef WIN32
	void WorldServerLoop(void *tmp);
#else
	void *WorldServerLoop(void *tmp);
#endif

#define WSCS_Construction	0
#define WSCS_Ready			1
#define WSCS_Connecting		2
#define WSCS_Authenticating	3
#define WSCS_Connected		100
#define WSCS_Disconnecting	200

class WorldServer {
public:
	WorldServer();
    ~WorldServer();

	bool Init();
	void Process();
	bool ReceiveData();
	bool SendPacket(ServerPacket* pack);
	bool SendChannelMessage(Client* from, const char* to, int8 chan_num, int32 guilddbid, int8 language, const char* message, ...);
	bool SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...);
	void SetZone(const char* zone);
	void SetConnectInfo();
	bool RezzPlayer(APPLAYER* rpack,int32 rezzexp, int16 opcode);
	int32	GetIP()		{ return ip; }
	int16	GetPort()	{ return port; }
	int8	GetState();
	void	SetState(int8 in_state);
	bool	Connected()	{ return (GetState() == WSCS_Connected); }

	bool	SendPacketQueue(bool block = false);
	bool	Connect(bool FromInit = false);
	void	Disconnect();
	int16	GetErrorNumber()	{return adverrornum;}
	Timer*	ReconnectTimer;
private:
	int32 ip;
	int16 port;
#ifdef WIN32
	SOCKET send_socket;
#else
	int send_socket;
#endif
	int8 connection_state;
	uchar*	recvbuf;
	int32	recvbuf_size;
	int32	recvbuf_used;
	int16	adverrornum;
	MyQueue<ServerPacket>	ServerRecvQueue;
	MyQueue<SPackSendQueue>	ServerSendQueue;
	SPackSendQueue*			ServerSendQueuePop(bool block = false);
	ServerPacket*			ServerRecvQueuePop(bool block = false);

	Timer* timeout_timer;

	Mutex MQueueLock;
	Mutex MStateLock;
};
#endif

