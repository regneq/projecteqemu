#ifndef HATELIST_H
#define HATELIST_H

struct hl_struct
{
  Mob *ent;
  sint32 damage, hate;
  struct hl_struct *prev, *next;
};

class HateList
{
public:
  HateList();
  ~HateList();
  
  void Add(Mob *ent, sint32 in_dam=0, sint32 in_hate=0xffffffff);
  void RemoveEnt(Mob *ent);
  struct hl_struct *Find(Mob *ent);
  void Wipe();

  void DoFactionHits(int32 ncp_id);
  sint32 GetEntHate(Mob *ent);

  Mob *GetTop();
  Mob *GetRandom();
  
  void Whipe() { Wipe (); }

private:
  struct hl_struct *list;
};

#endif
