[ EQEmu readme 3.12 ] 

  > requirements
    
   >  a brain ( ask your parents if they drank while you were in the womb )
   >  being literate ( ask your 2nd grade teacher )
   >  mySQL 3.23 ++ ( www.mysql.com )
   >  EQEmu-03.12-Win32 ( www.eqemu.net )

> note: read the whole thing before you start complaining
        > this only shows you how to do a CLEAN install of EQEMu ( it assumes that you have not installed mysql / EQEMu before )



 > Step 1
     >> mySQL setup


> go to www.mysql.com and download the latest version of mySQL from there site, i assume you are using 3.23 but it should work with 3.23 and up.
http://www.mysql.com/downloads/mysql-3.23.html

> after the install go to c:\mysql\bin\ and open winmysqladmin.exe, it should prompt you to create a user / pass ( remember this becuase you need to use the login later on in the install )

> after you set up the user / pass go to c:\mysql\bin\ and open mysql.exe

> type this in the command prompt (type it exactly how you see it here) ;

create database eq;

( this creates a database named eq )

> example output
Your MySQL connection id is 6146 to server version: 3.23.36-log

Type 'help;' or '\h' for help. Type '\c' to clear the buffer

mysql> create database eq;
Query OK, 1 row affected (0.00 sec)



 > Step 2
     >> EQEMu Setup


> go to www.eqemu.net and grab the latest release ( i assume your using eqemu-03.12-win32 )

> unzip all the files to c:\eqemu\

> open db.ini and change the username / password that you made in Step 1

> example setup

[Database]
host=localhost
user=myusername     		<= change this
password=mypassword 		<= change this
database=eq

> save and close the file and open LoginServer.ini

> example setup
 
[LoginServer]
loginserver=eqlogin1.eqemu.net
loginserver2=eqlogin2.eqemu.net
loginport=5999
loginport2=5999
worldname=EverQuest Emu Server Name 	<= change this to name of server you want ( LEAVE OUT THE WORD SERVER )
locked=false
account=
password=
worldaddress=123.123.123.123		<= change this to your ip or the ip that world.exe will be runing on

[WorldServer]
Defaultstatus=0				<= set the default status lvl of new users on the server
Unavailzone=arena			<= set zone that people are sent to if no zone servers are free / open 

[LoginConfig]
ServerMode=Standalone
ServerPort=5999
UplinkAddress=
UplinkPort=
UplinkAccount=
UplinkPassword=

> save and close the file

> open boot5zones.bat

> example setup

@echo off
start zone . 123.123.123.123 7995 123.123.123.123 <= First set of ip is the machine runing the zone server 
start zone . 123.123.123.123 7996 123.123.123.123    Second set of ip is the machine runing world server
start zone . 123.123.123.123 7997 123.123.123.123
start zone . 123.123.123.123 7998 123.123.123.123
start zone . 123.123.123.123 7999 123.123.123.123
exit
cls



 > Step 3
     >> EQEMu Database Setup


> copy db.sql from c:\eqemu\ to c:\mysql\bin\

> open mysql.exe

> type this in exactly

source db.sql;


 > Step 4
     >> Runing EQEMu 

> start up world.exe ( let it load, at this point if there are any errors look at the faq in this readme )
> start up boot5zones.bat ( this will load up 5 zone servers )
> guess what your server is set up yAY!!


		
>>>>>>>>> EQEMu Faq <<<<<<<<<

>> if you recieve a Database error or Access Denied error 
 > open mysql.exe ( c:\mysql\bin\ )
 > type this

GRANT ALL PRIVILEGES ON *.* to '%'@localhost IDENTIFIED BY '%';

>> no more that i can think of right now 
 >> post on forums if you encounter any other things that can be fixed


 >> about 

  > readme: khuong
  > EQEMu Dev Team
  > www.eqemu.net / http://forums.eqemu.net
