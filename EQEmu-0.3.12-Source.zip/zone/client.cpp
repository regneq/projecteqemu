/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>


// Disgrace: for windows compile
#ifdef WIN32
#include <windows.h>
#include <winsock.h>
#include <process.h>

#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include "../common/unix.h"
#endif

#include "../common/version.h"
#include "client.h"
#include "groups.h"
#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "../common/database.h"
#include "spdat.h"
#include "../common/packet_functions.h"
#include "PlayerCorpse.h"
#include "petitions.h"
#include "../common/serverinfo.h"

extern Database database;
extern EntityList entity_list;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern GuildRanks_Struct guilds[512];
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern int32 numclients;
extern PetitionList petition_list;

Client::Client(EQNetworkConnection* ieqnc)
: Mob("No name",	// name
	  "",	// lastname
	  0,	// curhp
	  0,	// maxhp
	  0,	// gender
	  0,	// race
	  0,	// class
	  0,	// deity
	  0,	// level
	  0,	// npctypeid
	  0,	// skills
	  0,	// size
	  0.46,	// walkspeed
	  0.7,	// runspeed
	  0,	// heading
	  0,	// x
	  0,	// y
	  0,	// z
	  0,	// light
	  0,	// equip
	  0xFF,	// texture
	  0xFF,	// helmtexture
	  0,	// ac
	  0,	// atk
	  0,	// str
	  0,	// sta
	  0,	// dex
	  0,	// agi
	  0,	// int
	  0,	// wis
	  0,	// cha
	  0xff,	// Luclin Hair Colour
	  0xff,	// Luclin Beard
	  0xff,	// Luclin Eye1
	  0xff,	// Luclin Eye2
	  0xff,	// Luclin Hair Style
	  0xff,	// Luclin title
	  0xff,// Luclin Face
	  1, // fixedz
	  0, // standart text1
	  0 // standart text2
	  )	
{
	this->berserk = false;
	this->dead = false;
	eqnc = ieqnc;
	ip = eqnc->GetrIP();
	port = ntohs(eqnc->GetrPort());
	client_state = CLIENT_CONNECTING1;
	account_id = 0;
	admin = 0;
	strcpy(account_name, "");
	tellsoff = false;
	gmhideme = false;
	LFG = false;
	playeraction = 0;
	target = 0;
	auto_attack = false;
	PendingGuildInvite = 0;
	zonesummon_x = -2;
	zonesummon_y = -2;
	zonesummon_z = -2;
	zonesummon_ignorerestrictions = false;
	casting_spell_id = 0;
	npcflag = false;
	npclevel = 0;
	
	position_timer = new Timer(500);
	position_timer->Disable();
	position_timer_counter = 0;
	pLastUpdate = 0;
	// Kaiyodo - initialise haste variable
	HastePercentage = 0;
	
	IsSettingGuildDoor = false;
	isgrouped = false;
	delaytimer = false;
	pendingrezzexp = 0;
	numclients++;
	UpdateWindowTitle();
}

Client::~Client() {
	if (this->isgrouped && entity_list.GetGroupByClient(this) != 0)	
		entity_list.GetGroupByClient(this)->DelMember(this,true);
	eqnc->Free();
	UpdateWho(true);
	Save(); // This fails when database destructor is called first on shutdown
	delete position_timer;
	numclients--;
	UpdateWindowTitle();
}

bool Client::Save() {
	if (Connected()) {
		pp.x = x_pos;
		pp.y = y_pos;
		pp.z = z_pos/10;
		pp.heading = heading;
		if (GetHP() <= 0) {
			if (GetMaxHP() > 30000)
				pp.cur_hp = 30000;
			else
				pp.cur_hp = GetMaxHP();
		}
		else if (GetHP() > 30000)
			pp.cur_hp = 30000;
		else
			pp.cur_hp = GetHP();
		pp.mana = cur_mana;
		
		for (int i=0; i<15; i++) {
			if (buffs[i].spellid <= SPDAT_RECORDS) {
				pp.buffs[i].spellid = buffs[i].spellid;
				pp.buffs[i].duration = buffs[i].ticsremaining;
				pp.buffs[i].level = buffs[i].casterlevel;
			}
			else {
				pp.buffs[i].spellid = 0xFFFF;
				pp.buffs[i].duration = 0;
				pp.buffs[i].level = 0;
			}
		}
		if (!database.SetPlayerProfile(account_id, name, &pp)) {
			cerr << "Failed to update player profile" << endl;
			return false;
		}
	}
	return true;
}

void Client::QueuePacket(APPLAYER* app, bool ack_req) {	
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size >= 31500) {
			cout << "WARNING: abnormal packet size. n='" << this->GetName() << "', o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	if(eqnc) eqnc->QueuePacket(app, ack_req);
}

void Client::ChannelMessageReceived(int8 chan_num, int8 language, const char* message, const char* targetname) {
	//	cout << "Channel:" << (int)chan_num << " " << message << endl;
	switch(chan_num)
	{
	case 0: //GuildChat
		{
			if (guilddbid == 0 || guildeqid >= 512)
				Message(0, "Error: You arent in a guild.");
			else if (!guilds[guildeqid].rank[guildrank].speakgu)
				Message(0, "Error: You dont have permission to speak to the guild.");
			else if (!worldserver.SendChannelMessage(this, targetname, chan_num, guilddbid, language, message))
				Message(0, "Error: World server disconnected");
			break;
		}
		
	case 2: //GroupChat
		{
			Group* group = entity_list.GetGroupByMob(this);
			if (this->isgrouped && group != 0)	
			{
				group->GroupMessage(this,(char*)message);
			}
			break;
		}
		
	case 3: // Shout
	case 4: // Auction
		{
			entity_list.ChannelMessage(this, chan_num, language, message);
			break;
		}
		
	case 5: // OOC
		{
			if (!worldserver.SendChannelMessage(this, 0, 5, 0, language, message))
				Message(0, "Error: World server disconnected");
			break;
		}
		
	case 6: // Broadcast
	case 11: // GMSay
		{
			if (!(admin >= 80))
				Message(0, "Error: Only GMs can use this channel");
			else if (!worldserver.SendChannelMessage(this, targetname, chan_num, 0, language, message))
				Message(0, "Error: World server disconnected");
			break;
		}
		
	case 7: // Tell
		{
			if(!worldserver.SendChannelMessage(this, targetname, chan_num, 0, language, message))
				Message(0, "Error: World server disconnected");
			break;
		}
		
	case 8:
		{
			if(message[0] != '#')
			{
				entity_list.ChannelMessage(this, chan_num, language, message);
				if (target != 0 && target->IsNPC()) {
					if (DistNoRootNoZ(target) <= 200) {
						if(target->CastToNPC()->IsInteractive())
							target->CastToNPC()->InteractiveChat(chan_num,language,message,targetname,this);
						CheckQuests(zone->GetShortName(), message, target->GetNPCTypeID());
					}
				}
				break;
			}
			Seperator sep(message);
			char command[200];
			snprintf(command, 200, "%s", sep.arg[0]);
			command[0] = '!';
			int32 cmdlevel = database.CommandRequirement(command);
			
			if ((strcasecmp(sep.arg[0], "#level") == 0) && CheckAccess(cmdlevel, 10))
			{
				if (target == 0 && admin >= 100) {
					Message(0, "Error: #Level: No target");
				}
				else if (sep.arg[1][0] == 0) {
					Message(0, "Usage: #level x");
				}
				else {
					int16 level = atoi(sep.arg[1]);
					if (level > 0 && (level <= 65 || (level <= 100 && admin >= 100) || (level <= 255 && admin >= 200))) {
						if (admin >= 100)
							target->SetLevel(level, true);
						else
							this->SetLevel(level, true);
					}
					else {
						Message(0, "Error: #Level: Invalid Level");
					}
				}
			}
			
			else if (!strcasecmp(sep.arg[0], "#interrupt"))
			{
				int16 ci_message=0x01b7, ci_color=0x0121;
				if(sep.arg[1][0])
					ci_message=atoi(sep.arg[1]);
				if(sep.arg[2][0])
					ci_color=atoi(sep.arg[2]);
				this->InterruptSpell(ci_message, ci_color);
			}
			else if (strcasecmp(sep.arg[0], "#d1") == 0) {
				APPLAYER app;
				app.opcode = OP_Action;
				app.size = sizeof(Action_Struct);
				app.pBuffer = new uchar[app.size];
				memset(app.pBuffer, 0, app.size);
				Action_Struct* a = (Action_Struct*)app.pBuffer;
				adverrorinfo = 412;
				a->target = GetID();
				a->source = this->GetID();
				a->type = atoi(sep.arg[1]);
				a->spell = atoi(sep.arg[2]);
				a->damage = atoi(sep.arg[3]);
				app.priority = 1;
				entity_list.QueueCloseClients(this, &app);
			}
			else if (strcasecmp(sep.arg[0], "#damage") == 0 && CheckAccess(cmdlevel, 100)) {
				long type=0xffff;
				if (target==0) {
					Message(0, "Error: #Damage: No Target.");
				}
				else if (!sep.IsNumber(1)) {
					Message(0, "Usage: #damage x.");		
					
				}
				else {
					sint32 nkdmg = atoi(sep.arg[1]);
					if (!sep.IsNumber(2)) {
						type=0xffff;
					}
					type=atol(sep.arg[2]);
					if (nkdmg > 2100000000)
						Message(0, "Enter a value less then 2,100,000,000.");
					else
						target->Damage(this, nkdmg, type);
				}
			}
			else if (strcasecmp(sep.arg[0], "#heal") == 0 && CheckAccess(cmdlevel, 10)) {
				if (target==0) {
					Message(0, "Error: #Heal: No Target.");
				} else {
					target->Heal();
				}
			}
			else if (strcasecmp(sep.arg[0], "#npcspecialattk") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target==0 || target->IsClient() || strlen(sep.arg[1]) <= 0 || strlen(sep.arg[2]) <= 0) {
					Message(0, "Proper use: #npcspecialattk *flagchar* *permtag* (Flagchar is A-N, permtag is 1 = True, 0 = False).");
				} else {
					target->CastToNPC()->NPCSpecialAttacks(sep.arg[1],atoi(sep.arg[2]));
					Message(0, "NPC Special Attack set.");
				}
			}
			else if (strcasecmp(sep.arg[0], "#kill") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target==0) {
					Message(0, "Error: #Kill: No target.");
				} else {
					if ((!target->IsClient()) || target->CastToClient()->Admin() <= this->Admin())
						target->Kill();
				}
			}
			else if(strncasecmp(message,"#timeofday",9) == 0 && CheckAccess(cmdlevel, 80)) { // image - Redone by Scruffy
				//yyyy mm dd hh mm local
				if(sep.arg[2][0]==0 && !sep.IsNumber(1))
				{
					char timeMessage[255];
					time_t timeCurrent = time(NULL);
					TimeOfDay_Struct eqTime;
					zone->zone_time.getEQTimeOfDay( timeCurrent, &eqTime);
					if ( eqTime.hour >= 0 && eqTime.minute >= 0 )
					{
						sprintf(timeMessage,"EQTime [%02d:%s%d %s]",
							(eqTime.hour % 12) == 0 ? 12 : (eqTime.hour % 12),
							(eqTime.minute < 10) ? "0" : "",
							eqTime.minute,
							(eqTime.hour >= 12) ? "pm" : "am"
							);
						Message(13, "It is now %s", timeMessage);
						//cout << timeMessage << endl;
					}
					Message(13, "Help: #timeofday HH [MM]");
					
				}
				else
				{
					if(!sep.IsNumber(2))
					{
						sep.arg[2]="00";
					}
					Message(13, "Setting world time to %s:%s...", sep.arg[1], sep.arg[2]);
					zone->SetTime(atoi(sep.arg[1]), atoi(sep.arg[2]));
				}
				
			}
			else if (strcasecmp(sep.arg[0], "#date")==0 && CheckAccess(cmdlevel, 80)) {
				//yyyy mm dd hh mm local
				if((sep.arg[3][0]==0 || !sep.IsNumber(1) || !sep.IsNumber(2) || !sep.IsNumber(3)))
				{
					char timeMessage[255];
					time_t timeCurrent = time(NULL);
					TimeOfDay_Struct eqTime;
					zone->zone_time.getEQTimeOfDay( timeCurrent, &eqTime);
					if ( eqTime.hour >= 0 && eqTime.minute >= 0 )
					{
						sprintf(timeMessage,"EQTime [%02d:%s%d %s]",
							(eqTime.hour % 12) == 0 ? 12 : (eqTime.hour % 12),
							(eqTime.minute < 10) ? "0" : "",
							eqTime.minute,
							(eqTime.hour >= 12) ? "pm" : "am"
							);
						Message(13, "It is now %s", timeMessage);
						//cout << timeMessage << endl;
					}
					Message(13, "Help: #date yyyy mm dd [HH MM]");
					
				}
				else
				{
					if(!sep.IsNumber(4))
					{
						sep.arg[4]="24";
					}
					if(!sep.IsNumber(5))
					{
						sep.arg[5]="00";
					}
					Message(13, "Setting world time to %s-%s-%s %s:%s...", sep.arg[1], sep.arg[2], sep.arg[3], sep.arg[4], sep.arg[5]);
					zone->SetDate(atoi(sep.arg[1]), atoi(sep.arg[2]), atoi(sep.arg[3]), atoi(sep.arg[4]), atoi(sep.arg[5]));
				}
			}
			else if (strcasecmp(sep.arg[0], "#synctod")==0 && CheckAccess(cmdlevel, 80)) {
				Message(13, "Updating Time/Date for all clients in zone...");
				APPLAYER* outapp = new APPLAYER;
				outapp = new APPLAYER;
				outapp->opcode = OP_TimeOfDay;
				outapp->size = sizeof(TimeOfDay_Struct);
				outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer,0,outapp->size); // no memset = BAD -kathgar
				TimeOfDay_Struct* tod = (TimeOfDay_Struct*)outapp->pBuffer;
				zone->zone_time.getEQTimeOfDay(time(0), tod);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
			// Kaiyodo - #haste command to set client attack speed. Takes a percentage (100 = twice normal attack speed)
			else if (strcasecmp(sep.arg[0], "#haste")==0 && CheckAccess(cmdlevel, 100))
			{
				if(sep.arg[1][0] != 0)
				{
					int16 Haste = atoi(sep.arg[1]);
					if(Haste > 85)
						Haste = 85;
					
					SetHaste(Haste);
					// SetAttackTimer must be called to make this take effect, so player needs to change
					// the primary weapon.
					Message(0, "Haste set to %d%% - Need to re-equip primary weapon before it takes effect", Haste);
				}
				else
				{
					Message(0, "Usage: #haste x");
				}
			}
			else if(strcasecmp(sep.arg[0],"#weather") == 0 && CheckAccess(cmdlevel, 80)) {
				if (!(sep.arg[1][0] == '0' || sep.arg[1][0] == '1' || sep.arg[1][0] == '2' || sep.arg[1][0] == '3')) {
					Message(0, "Usage: #weather <0/1/2/3> - Off/Rain/Snow/Manual.");
				}
				else if(zone->zone_weather == 0) { 
					if(sep.arg[1][0] == '3')	{ // Put in modifications here because it had a very good chance at screwing up the client's weather system if rain was sent during snow -T7
						if(sep.arg[2][0] != 0 && sep.arg[3][0] != 0) { 
							Message(0, "Sending weather packet... TYPE=%s, INTENSITY=%s", sep.arg[2], sep.arg[3]);
							zone->zone_weather = atoi(sep.arg[2]);
							APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
							outapp->pBuffer[0] = atoi(sep.arg[2]);
							outapp->pBuffer[4] = atoi(sep.arg[3]); // This number changes in the packets, intensity?
							entity_list.QueueClients(this, outapp);
							delete outapp;
						}
						else {
							Message(0, "Manual Usage: #weather 3 <type> <intensity>");
						}
					}
					else if(sep.arg[1][0] == '2')	{
						entity_list.Message(0, 0, "Snowflakes begin to fall from the sky.");
						zone->zone_weather = 2;
						APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
						outapp->pBuffer[0] = 0x01;
						outapp->pBuffer[4] = 0x02; // This number changes in the packets, intensity?
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
					else if(sep.arg[1][0] == '1')	{
						entity_list.Message(0, 0, "Raindrops begin to fall from the sky.");
						zone->zone_weather = 1;
						APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
						outapp->pBuffer[4] = 0x01; // This is how it's done in Fear, and you can see a decent distance with it at this value
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
				}
				else	{
					if(zone->zone_weather == 1)	{ // Doing this because if you have rain/snow on, you can only turn one off.
						entity_list.Message(0, 0, "The sky clears as the rain ceases to fall.");
						zone->zone_weather = 0;
						APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
						// To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
					else if(zone->zone_weather == 2)	{
						entity_list.Message(0, 0, "The sky clears as the snow stops falling.");
						zone->zone_weather = 0;
						APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
						// To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
						outapp->pBuffer[0] = 0x01; // Snow has it's own shutoff packet
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
					else {
						entity_list.Message(0, 0, "The sky clears.");
						zone->zone_weather = 0;
						APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
						// To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
				}
			}	
			/*	else if (strcasecmp(sep.arg[0], "#filters") == 0)
			{
			if(strlen(sep.arg[1]) == 0)
			{
			Message(0,"#filters command allows you to filter some things to avoid lag");
			Message(0,"#filters clientattack (None/Self/Group) (Allows you to filter client attacks except for self or group)");
			Message(0,"#filters npcattack (None/Group/AllMiss/All) (Allows filtering of attacks, group ignores all attacks but group, allmiss ignores all misses, all ignores all attacks but self)");
			Message(0,"#filters clientcast (None/Self/All) (Allows you to filter client casting, self ignores all casts but towards you, all ignores all beginning casts including self)");
			Message(0,"#filters npccast (None/Self/All) (Allows you to filter npcs casting, self ignores all casts but towards you, all ignores all beginning casts including self)");
			return;
			}
			
			  if (strcasecmp(sep.arg[1], "clientattack") == 0)
			  {
			  if (strcasecmp(sep.arg[2], "none") == 0)
			  ssfs.clientattackfilters = 0;
			  if (strcasecmp(sep.arg[2], "self") == 0)
			  ssfs.clientattackfilters = 1;
			  if (strcasecmp(sep.arg[2], "group") == 0)
			  ssfs.clientattackfilters = 2;
			  
				if(strlen(sep.arg[2]) > 0)
				Message(0,"ServerFilter set.");
				}
				if (strcasecmp(sep.arg[1], "npcattack") == 0)
				{
				if (strcasecmp(sep.arg[2], "none") == 0)
				ssfs.npcattackfilters = 0;
				if (strcasecmp(sep.arg[2], "allmiss") == 0)
				ssfs.npcattackfilters = 1;
				if (strcasecmp(sep.arg[2], "all") == 0)
				ssfs.npcattackfilters = 2;
				if (strcasecmp(sep.arg[2], "group") == 0)
				ssfs.npcattackfilters = 3;
				
				  if(strlen(sep.arg[2]) > 0)
				  Message(0,"ServerFilter set.");
				  }
				  
					
					  if (strcasecmp(sep.arg[1], "clientcast") == 0)
					  {
					  if (strcasecmp(sep.arg[2], "none") == 0)
					  ssfs.clientcastfilters = 0;
					  if (strcasecmp(sep.arg[2], "self") == 0)
					  ssfs.clientcastfilters = 2;
					  if (strcasecmp(sep.arg[2], "all") == 0)
					  ssfs.clientcastfilters = 1;
					  
						if(strlen(sep.arg[2]) > 0)
						Message(0,"ServerFilter set.");
						}
						
						  if (strcasecmp(sep.arg[1], "npccast") == 0)
						  {
						  if (strcasecmp(sep.arg[2], "none") == 0)
						  ssfs.npccastfilters = 0;
						  if (strcasecmp(sep.arg[2], "self") == 0)
						  ssfs.npccastfilters = 2;
						  if (strcasecmp(sep.arg[2], "all") == 0)
						  ssfs.npccastfilters = 1;
						  
							if(strlen(sep.arg[2]) > 0)
							Message(0,"ServerFilter set.");
							}
							
							  database.SetServerFilters(AccountName(),&ssfs);
		}*/
		else if (strcasecmp(sep.arg[0], "#version") == 0)
		{
			Message(0, "Current version information.");
			Message(0, "  %s", CURRENT_ZONE_VERSION);
			Message(0, "  Compiled on: %s at %s", COMPILE_DATE, COMPILE_TIME);
			Message(0, "  Last modified on: %s", LAST_MODIFIED);
		}
		else if (strcasecmp(sep.arg[0], "#face") == 0)	{
			APPLAYER* outapp = new APPLAYER(OP_Illusion, sizeof(Illusion_Struct));
			Illusion_Struct* is = (Illusion_Struct*) outapp->pBuffer;
			is->spawnid = GetID();
			is->race = GetBaseRace();
			is->gender = GetBaseGender();
			is->texture = 0x00;
			is->helmtexture = 0x00;
			is->haircolor = 0x00;
			is->beardcolor = GetFace();
			is->eyecolor1 = 0xFF;
			is->eyecolor2 = 0xFF;
			is->hairstyle = 0xFF;
			is->title = 0xFF;
			is->luclinface = 0xFF;
			entity_list.QueueClients(this, outapp);
			delete outapp;
		}
		else if (strcasecmp(sep.arg[0], "#serverinfo") == 0 && CheckAccess(cmdlevel, 201)) {
			if(strlen(sep.arg[1]) == 0)
			{
				Message(13,"Options: #serverinfo <xx> (os)");
				break;
			}
			if (strcasecmp(sep.arg[1], "os") == 0 && admin >=201) {
#ifdef WIN32
				GetOS();
				char intbuffer [sizeof(unsigned long)];
				Message(0, "Operating system information.");
				Message(0, "  %s", Ver_name);
				Message(0, "  Build number: %s", ultoa(Ver_build, intbuffer, 10));
				Message(0, "  Minor version: %s", ultoa(Ver_min, intbuffer, 10));
				Message(0, "  Major version: %s", ultoa(Ver_maj, intbuffer, 10));
				Message(0, "  Platform Id: %s", ultoa(Ver_pid, intbuffer, 10));
#else
				char os_string[100];
				Message(0, "Operating system information.");
				Message(0, "  %s", GetOS(os_string));
#endif
			}
			else {
				Message(0, "Usage: #serverinfo <type>");
				Message(0, "  OS - Operating system information.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#shutdown")==0 && CheckAccess(cmdlevel, 200))
		{
			CatchSignal(2);
		}
		else if (strcasecmp(sep.arg[0], "#help") == 0) {
			if (!(strcasecmp(sep.arg[1], "normal") == 0 
				|| strcasecmp(sep.arg[1], "privuser") == 0 || strcasecmp(sep.arg[1], "pu") == 0
				|| strcasecmp(sep.arg[1], "vprivuser") == 0 || strcasecmp(sep.arg[1], "vpu") == 0
				|| strcasecmp(sep.arg[1], "questtroupe") == 0 || strcasecmp(sep.arg[1], "qt") == 0
				|| strcasecmp(sep.arg[1], "gm") == 0
				|| strcasecmp(sep.arg[1], "leadgm") == 0 || strcasecmp(sep.arg[1], "lgm") == 0
				|| strcasecmp(sep.arg[1], "debug") == 0
				|| strcasecmp(sep.arg[1], "serverop") == 0 || strcasecmp(sep.arg[1], "sop") == 0
				|| strcasecmp(sep.arg[1], "all") == 0)) {
				Message(0, "Usage: #help <helpfile>");
				Message(0, "  Normal - Normal EQEmu commands.");
				if(admin >= 10)	{	Message(0, "  Privuser - Privileged user commands."); }
				if(admin >= 20)	{	Message(0, "  vPrivuser - Very privileged user commands."); }
				if(admin >= 80)	{	Message(0, "  QuestTroupe - QuestTroupe commands."); }
				if(admin >= 100)	{	Message(0, "  GM - Game master commands."); }
				if(admin >= 150)	{	Message(0, "  LeadGM - Lead GM commands."); }
				if(admin >= 200)	{	Message(0, "  ServerOP - Server operator commands."); }
				if(admin >= 201)	{	Message(0, "  Debug - Debugging commands."); }
			}
			if (strcasecmp(sep.arg[1], "normal") == 0 || strcasecmp(sep.arg[1], "all") == 0)
			{
				Message(0, "EQEMu Commands:");
				Message(0, "  #itemsearch [id] - Searches item database.");
				Message(0, "  #summonitem [id] - Summons an item.");
				Message(0, "  #loc - Shows you your current location.");
				Message(0, "  #goto  [x,y,z] - Warps you to specified coordinates.");
				Message(0, "  #zone [zonename] - Zones to safepoint in the specified zone.");
				Message(0, "  #zonestatus - Shows what zones are up.");
				Message(0, "  #guild - Guild commands (type for more info)");
				Message(0, "  #showstats - Shows what the server thinks your stats are.");
				//Message(0, "  #filters - Allows for you to make the server filter out some information (can reduce lag).");
			}
			if ((strcasecmp(sep.arg[1], "privuser") == 0 || strcasecmp(sep.arg[1], "pu") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 10)
			{
				Message(0, "EQEMu Priviliged User Commands:");
				Message(0, "  #level [id] - Sets your target\'s level.");
				Message(0, "  #heal - (PC only) Completely heals your target.");
				Message(0, "  #mana - (PC only) Replenishes your target\'s mana.");
				Message(0, "  #spawn - Used to spawn NPCs");
				Message(0, "  #dbspawn [npctypeid] - Spawns an NPC type from the database.");
				Message(0, "  #texture [texture] [helmtexture]	(0-255, 255 for show equipment)");
				Message(0, "  #gender [0-2] - (0=male, 1=female, 2=neuter)");
				Message(0, "  #npctypespawn [npctype]");
			}
			if ((strcasecmp(sep.arg[1], "vprivuser") == 0 || strcasecmp(sep.arg[1], "vpu") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 20)
			{
				Message(0, "EQEMu Very Priviliged User Commands:");
				Message(0, "  #size [size] - Sets your targets size.");
				Message(0, "  #findspell [spellname] - Searches the spell database for [spellname]");
				Message(0, "  #castspell [id] - Casts a spell, use #findspell to determine the id number.");
				Message(0, "  #setskill [skill num (0-73)] [number (0-255)] - Sets the targeted player's skill to number.");
				Message(0, "  #setallskill [0-255] - Sets all of the targeted player's skills to number.");
				Message(0, "  #flymode - Allows you to move freely on the z axis.");
				Message(0, "  #race [0-329]  (0 for back to normal)");
				Message(0, "  #makepet - Makes a custom pet, #makepet for details.");
			}
			if ((strcasecmp(sep.arg[1], "questtroupe") == 0 || strcasecmp(sep.arg[1], "qt") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 80) 
			{
				Message(0, "EQEMu Quest Troupe Commands:");
				Message(0, "  #npcloot [show/money/add/remove] [itemid/all/money: pp gp sp cp] - Adjusts the loot the targeted npc is carrying.");
				Message(0, "  #npcstats - Shows the stats of the targetted NPC.");
				Message(0, "  #zheader [zone name/none] - Change the sky/fog/etc. of the current zone.");
				Message(0, "  #zsky [sky number] - Changes the sky of the current zone.");
				Message(0, "  #zcolor [red] [green] [blue] - Changes the fog colour of the current zone.");
				Message(0, "  #zstats - Shows the zone header data for the current zone.");
				Message(0, "  #timeofday - Sets the date to Monday, Janurary 1st, 1 at the specified time.");
				Message(0, "  #date - Sets the time to the specified date.");
				Message(0, "  #weather <0/1/2> - Off/Rain/Snow.");
				Message(0, "  #permaclass <classnum> - Changes your class.");
				Message(0, "  #permarace <racenum> - Changes your race.");
				Message(0, "  #permagender <0/1/2> - Changes your gender.");
				Message(0, "  #emote - Sends an emotish message, type for syntax.");
				Message(0, "  #invul [1/0] - Makes the targeted player invulnerable to attack");
				Message(0, "  #hideme [0/1]	- Removes you from the spawn list.");
				Message(0, "  #npccast [targetname] [spellid] - Makes the targeted NPC cast on [targetname].");
				Message(0, "  #zclip [min clip] [max clip] - Changes the clipping plane of the current zone.");
			}
			if ((strcasecmp(sep.arg[1], "gm") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 100)
			{
				Message(0, "EQEMu GM Commands:");
				Message(0, "  #kill - Kills your selected target.");
				Message(0, "  #damage [id] - Inflicts damage upon target.");
				Message(0, "  #setxp - Sets the target\'s experience.");
				Message(0, "  /broadcast [text] - Sends a broadcast message.");
				Message(0, "  /pr [text] - Sends text over GMSAY.");
				Message(0, "  /lastname - Sets a player's lastname.");
				Message(0, "  /name - Sets a player's name");
				Message(0, "  #depop - Depops targeted NPC.");
				Message(0, "  #depopzone - Depops the zone.");
				Message(0, "  #npcspecialattk - Allows you to set the special attack flags by selecting the NPC.");
				Message(0, "  #repop [delay] - Repops the zone, optional delay in seconds.");
				Message(0, "  #zuwcoords [number] - Changes the underworld coordinates of the current zone.");
				Message(0, "  #zsafecoords [x] [y] [z] - Changes the safe coordinates of the current zone.");
				Message(0, "  #listnpcs - Lists all the NPCs currently spawned in the zone.");
				Message(0, "  #listnpccorpses - Lists all NPC corpses in the zone.");
				Message(0, "  #listplayercorpses - Lists all player corpses in the zone.");
				Message(0, "  #deletenpccorpses - Deletes all NPC corpses in the zone.");
				Message(0, "  #showbuffs - Shows the buffs on your current target.");
				Message(0, "  #nukebuffs - Dispells your current target.");
				Message(0, "  #freeze - Freezes your current target.");
				Message(0, "  #unfreeze	- Unfreezes your current target.");
				Message(0, "  #pvp [on|off] - Toggles your player killer flag.");
				Message(0, "  #gm [on|off] - Toggles your GM flag.");
				Message(0, "  #gmspeed [on|off] - Toggles GMSpeed Hack (Zone for it to take affect).");
				Message(0, "  #movechar [charname] [zonename] - Moves a Character To a New Zone (If they are offline).");
			}
			if ((strcasecmp(sep.arg[1], "leadgm") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 150)
			{
				Message(0, "EQEMu Lead-GM Commands:");
				Message(0, "  #summon [charname] - Summons a player to you.");
				Message(0, "  #attack [charname] - Make targetted npc attack [charname].");
				Message(0, "  #kick [charname] - Kicks player off of the server.");
				Message(0, "  #zoneshutdown [ZoneID | ZoneName] - Shuts down the zoneserver.");
				Message(0, "  #zonebootup [ZoneID] [ZoneName] - Boots [ZoneName] on the zoneserver specified.");
				Message(0, "  #deletecorpse - Deletes the targeted player\'s corpse.");
				Message(0, "  #DeletePlayerCorpses - Deletes all player corpses in the zone.");
				Message(0, "  #motd [New MoTD Message] - Changes the server's MOTD.");
				Message(0, "  #lock - Locks the world server.");
				Message(0, "  #unlock - Unlocks or unlocks the server.");
			}
			if ((strcasecmp(sep.arg[1], "serverop") == 0 || strcasecmp(sep.arg[1], "sop") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 200)
			{
				Message(0, "EQEMu ServerOperator Commands:");
				Message(0, "  #shutdown - Shuts down the server.");
				Message(0, "  #worldshutdown - Shuts down the worldserver and all zones.");
				Message(0, "  #flag [status] [name] - Flags an account with GM status.");
				Message(0, "  #delacct [name] - Deletes an EQEmu account.");
				Message(0, "  #zsave [file name] - Save the current zone header to ./cfg/<filename>.cfg");
				Message(0, "  #dbspawn2 [spawngroup] [respawn] [variance]");
			}
			if ((strcasecmp(sep.arg[1], "debug") == 0 || strcasecmp(sep.arg[1], "all") == 0) && admin >= 201)
			{
				Message(0, "EQEMu Debug Commands:");
				Message(0, "  #version - Shows information about the zone executable.");
				Message(0, "  #serverinfo [type] - Shows information about the server, #serverinfo for details.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#setxp") == 0 && CheckAccess(cmdlevel, 100))
		{
			if (sep.IsNumber(1)) {
				if (atoi(sep.arg[1]) > 9999999)
					Message(0, "Error: SetXP: Value too high.");
				else
					AddEXP (atoi(sep.arg[1]));
			}
			else
				Message(0, "Usage: #setxp number");
		}
		else if (strcasecmp(sep.arg[0], "#name") == 0 && CheckAccess(cmdlevel, 100))
		{	
			if(strlen(sep.arg[1]) == 0 || strlen(sep.arg[2]) == 0)
			{
				Message(13, "Enter a name.");
				break;
			}
			Client* client = entity_list.GetClientByName(sep.arg[1]);
			
			if(client == 0)
			{
				Message(13, "Invalid client.  Must be in the same zone.");
			}
			else 
				client->ChangeFirstName(sep.arg[1],sep.arg[2],GetName());
		}
		else if (strcasecmp(sep.arg[0], "#lastname") == 0 && CheckAccess(cmdlevel, 100))
		{
			if(strlen(sep.arg[1]) <= 70)
				Client::ChangeLastName(sep.arg[1]);
			
			else
				Message(0, "Usage: #lastname <lastname> where <lastname> is less than 70 long");
		}
		else if (strcasecmp(sep.arg[0], "#summonitem") == 0 && CheckAccess(cmdlevel, 0))
		{
			if (!sep.IsNumber(1)) {
				Message(0, "Usage: #summonitem x , x is an item number");
			}
			else {
				int16 itemid = atoi(sep.arg[1]);
				if (admin < 100 && ((itemid >= 32768) || (itemid >= 19900 && itemid <= 19943) || (itemid >= 27181 && itemid <= 27194) || (itemid >= 31910 && itemid <= 31957) ||(itemid >= 31814 && itemid <= 31815) || (itemid >= 19917 && itemid <= 19928) || (itemid >= 11500 && itemid <= 11535) || (itemid == 32759 && admin < 200) || (itemid >= 32740 && itemid <= 32760))) {
					Message(0, "This item is a GM item and cannot be summoned by your status.");
				}
				else {
					if (sep.IsNumber(2)) {
						SummonItem(itemid, atoi(sep.arg[2]));
					}
					else {
						SummonItem(itemid);
					}
				}
			}
		}
		else if ((strcasecmp(sep.arg[0], "#itemsearch") == 0 || strcasecmp(sep.arg[0], "#search") == 0 || strcasecmp(sep.arg[0], "#finditem") == 0) && CheckAccess(cmdlevel, 0)) {
			if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #itemsearch item OR #search item");
			} else {
				FindItem(sep.argplus[1]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#spawn") == 0 && CheckAccess(cmdlevel, 10)) { // Image's Spawn Code -- Rewrite by Scruffy
			//			cout << "Spawning:" << endl; 
			//Well it needs a name!!! 
			NPC* npc = NPC::SpawnNPC(sep.argplus[1], GetX(), GetY(), GetZ()/10, GetHeading(), this);
			if (npc) { 
				// Disgrace: add some loot to it!
				npc->AddCash();
				int itemcount = (rand()%5) + 1;
				for (int counter=0; counter<itemcount; counter++)
				{
				/*	const Item_Struct* item = 0;
				while (item == 0)
				item = database.GetItem(rand() % 33000);
				
					npc->AddItem(item, 0, 0);*/
				}
			}
			else { 
				Message(0, "Format: #spawn name race level material hp gender class priweapon secweapon merchantid - spawns a npc those parameters.");
				Message(0, "Name Format: NPCFirstname_NPCLastname - All numbers in a name are stripped and \"_\" characters become a space.");
				Message(0, "Note: Using \"-\" for gender will autoselect the gender for the race. Using \"-\" for HP will use the calculated maximum HP.");
			} 
		}
		else if (strcasecmp(sep.arg[0], "#delacct") == 0 && CheckAccess(cmdlevel, 200))
		{
			if(sep.arg[1][0] == 0) {
				Message(0, "Format: #delacct accountname");
			} else {
				if (database.DeleteAccount(name) == 0)
					Message(0, "Unable to delete account.");
				else
					Message(0, "The account was deleted."); 
			}
		}
		else if (strcasecmp(sep.arg[0], "#loc") == 0)
		{
			if (target != 0 && CheckAccess(cmdlevel, 100)) {
				Message(0, "%s's Location (XYZ): %1.1f, %1.1f, %1.1f; heading=%1.1f", target->GetName(), target->GetX(), target->GetY(), target->GetZ(), target->GetHeading());
			}
			else {
				Message(0, "Current Location (XYZ): %1.1f, %1.1f, %1.1f; heading=%1.1f", x_pos, y_pos, z_pos, GetHeading());
			}
		}
		else if (strcasecmp(sep.arg[0], "#size") == 0 && CheckAccess(cmdlevel, 20))	{
			if (!sep.IsNumber(1))
				Message(0, "Usage: #size [0 - 255]");
			else {
				float newsize = atof(sep.arg[1]);
				if (newsize > 255)
					Message(0, "Error: #size: Size can not be greater than 255.");
				else if (newsize < 0)
					Message(0, "Error: #size: Size can not be less than 0.");
				else {
					if (target)
						target->ChangeSize(newsize);
					else
						this->ChangeSize(newsize);
				}
			}
		}
		
		else if (strcasecmp(sep.arg[0], "#goto") == 0) // Pyro's goto function
		{
			if (sep.arg[1][0] == 0 && target != 0) {
				MovePC((char*) 0, target->GetX(), target->GetY(), target->GetZ());
			}
			else if (!(sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3))) {
				Message(0, "Usage: #goto [x y z].");
			}
			else {
				MovePC((char*) 0, atof(sep.arg[1]), atof(sep.arg[2]), atof(sep.arg[3]));
			}
		}
		else if (strcasecmp(sep.arg[0], "#worldshutdown") == 0 && CheckAccess(cmdlevel, 200)) {
			// GM command to shutdown world server and all zone servers
			if (worldserver.Connected()) {
				worldserver.SendEmoteMessage(0,0,15,"<SYSTEMWIDE MESSAGE>:SYSTEM MSG:World coming down, everyone log out now.");
				Message(0, "Sending shutdown packet");
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ShutdownAll;
				pack->size=0;
				worldserver.SendPacket(pack);
				delete pack;
			}
			else
				Message(0, "Error: World server disconnected");
		}
		else if (strcasecmp(sep.arg[0], "#chat") == 0 && CheckAccess(cmdlevel, 200)) {
			// sends any channel message to all zoneservers
			// Dev debug command, for learing channums
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #chat channum message");
			else {
				if (!worldserver.SendChannelMessage(0, 0, (uint8) atoi(sep.arg[1]), 0, 0, sep.argplus[2]))
					Message(0, "Error: World server disconnected");
			}
		}
		else if (strcasecmp(sep.arg[0], "#appearance") == 0 && CheckAccess(cmdlevel, 150)) {
			// sends any appearance packet
			// Dev debug command, for appearance types
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #appearance type value");
			else {
				if (target != 0) {
					target->SendAppearancePacket(atoi(sep.arg[1]), atoi(sep.arg[2]));
					Message(0, "Sending appearance packet: target=%s, type=%s, value=%s", target->GetName(), sep.arg[1], sep.arg[2]);
				}
				else {
					this->SendAppearancePacket(atoi(sep.arg[1]), atoi(sep.arg[2]));
					Message(0, "Sending appearance packet: target=self, type=%s, value=%s", sep.arg[1], sep.arg[2]);
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#zoneshutdown") == 0 && CheckAccess(cmdlevel, 150)) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #zoneshutdown zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneShutdown;
				strcpy(s->adminname, this->GetName());
				if (sep.arg[1][0] >= '0' && sep.arg[1][0] <= '9')
					s->ZoneServerID = atoi(sep.arg[1]);
				else
					s->zoneid = database.GetZoneID(sep.arg[1]);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonebootup") == 0 && CheckAccess(cmdlevel, 150)) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else if (sep.arg[2][0] == 0) {
				Message(0, "Usage: #zonebootup ZoneServerID# zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneBootup;
				s->ZoneServerID = atoi(sep.arg[1]);
				strcpy(s->adminname, this->GetName());
				s->zoneid = database.GetZoneID(sep.arg[2]);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonestatus") == 0) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				pack->opcode = ServerOP_ZoneStatus;
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char *) &pack->pBuffer[1], this->GetName());
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#emote") == 0 && CheckAccess(cmdlevel, 80)) {
			if (sep.arg[3][0] == 0)
				Message(0, "Usage: #emote [name | world | zone] type# message");
			else {
				if (strcasecmp(sep.arg[1], "zone") == 0)
					entity_list.Message(0, atoi(sep.arg[2]), sep.argplus[3]);
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else if (strcasecmp(sep.arg[1], "world") == 0)
					worldserver.SendEmoteMessage(0, 0, atoi(sep.arg[2]), sep.argplus[3]);
				else
					worldserver.SendEmoteMessage(sep.arg[1], 0, atoi(sep.arg[2]), sep.argplus[3]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#zone") == 0) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #zone [zonename]");
			else {
				if (strcasecmp(sep.arg[1], zone->GetShortName()) == 0)
				{
					//YXZ format because EQEmu coord system is messed up.
					MovePC(sep.arg[1], zone->safe_y(), zone->safe_x(), zone->safe_z());
				}
				else
					if((strcasecmp(sep.arg[1], "cshome")==0) && (admin <100))
					{Message(0,"Only GMs and above can goto that zone."); }
					else
						MovePC(sep.arg[1], -1, -1, -1);
			}
		}
		/*EDIT*/
		else if (strcasecmp(sep.arg[0], "#summon") == 0 && admin >= 100) {
			/*EEND*/
			/* ORIGINAL CODE
			else if (strcasecmp(sep.arg[0], "#summon") == 0 && CheckAccess(cmdlevel, 100)) {
			*/
			if (sep.arg[1][0] == 0) {
				if (target != 0 && target->IsNPC()) {
					target->CastToNPC()->GMMove(x_pos, y_pos, z_pos, heading);
				}
				else if (admin >= 150)
					Message(0, "Usage: #summon [charname]");
				else
					Message(0, "You need a NPC target for this command");
			}
			else if (admin >= 150) {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					Message(0, "Summoning %s to %1.1f, %1.1f, %1.1f", sep.arg[1], this->x_pos, this->y_pos, this->z_pos);
					client->MovePC((char*) 0, this->x_pos, this->y_pos, this->z_pos, true, true);
				}
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_ZonePlayer;
					pack->size = sizeof(ServerZonePlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
					strcpy(szp->adminname, this->GetName());
					szp->adminrank = this->Admin();
					szp->ignorerestrictions = true;
					strcpy(szp->name, sep.arg[1]);
					strcpy(szp->zone, zone->GetShortName());
					szp->x_pos = x_pos;
					szp->y_pos = y_pos;
					szp->z_pos = z_pos;
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#kick") == 0 && CheckAccess(cmdlevel, 150)) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #kick [charname]");
			else {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					if (client->Admin() <= this->Admin()) {
						client->Message(0, "You have been kicked by %s",this->GetName());
						client->Kick();
						this->Message(0, "Kick: local: kicking %s", sep.arg[1]);
					}
				}
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_KickPlayer;
					pack->size = sizeof(ServerKickPlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
					strcpy(skp->adminname, this->GetName());
					strcpy(skp->name, sep.arg[1]);
					skp->adminrank = this->Admin();
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#guild") == 0 || strcasecmp(sep.arg[0], "#guilds") == 0) {
			GuildCommand(&sep);
		}
		else if (strcasecmp(sep.arg[0], "#flag") == 0)
		{
			if(sep.arg[2][0] == 0 || !CheckAccess(cmdlevel, 200)) {
				this->UpdateAdmin();
				Message(0, "Refreshed your admin flag from DB.");
			}
			else if (!sep.IsNumber(1) || atoi(sep.arg[1]) < -2 || atoi(sep.arg[1]) > 255 || strlen(sep.arg[2]) == 0)
				Message(0, "Usage: #flag [status] [acctname] (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
			else {
				if (atoi(sep.arg[1]) > admin)
					Message(0, "You cannot set people's status to higher than your own");
				else if (!database.SetGMFlag(sep.argplus[2], atoi(sep.arg[1])))
					Message(0, "Unable to set GM Flag.");
				else if (atoi(sep.arg[1]) < 0 && admin < 100)
					Message(0, "You have too low of status to suspend/ban");
				else {
					Message(0, "Set GM Flag on account.");
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_FlagUpdate;
					pack->size = strlen(sep.argplus[2]) + 1;
					pack->pBuffer = new uchar[pack->size];
					memset(pack->pBuffer, 0, pack->size);
					strcpy((char*) pack->pBuffer, sep.argplus[2]);
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#eitem") == 0 &&  CheckAccess(cmdlevel, 250)) {
#ifndef SHAREMEM
			Message(0, "Error: Function doesnt work in ShareMem mode");
#else
			char hehe[255];
			if (strstr(sep.arg[2],"classes")) {
				snprintf(hehe,255,"%s %s",sep.arg[3],strstr(message,sep.arg[3]));
			}
			else {
				strcpy(hehe,sep.arg[3]);
			}
			database.SetItemAtt(sep.arg[2],hehe,atoi(sep.arg[1]));
#endif
		}
		//Disgrace: a make due function to give you almost full mana (almost accurately..)
		else if (strcasecmp(sep.arg[0], "#mana") == 0 && CheckAccess(cmdlevel, 10))
		{
			if (target == 0)
				this->SetMana(30000);
			else
				target->SetMana(30000);
		}
		else if (strcasecmp(sep.arg[0], "#npcloot") == 0 && CheckAccess(cmdlevel, 80)) {
			if (target == 0)
				Message(0, "Error: No target");
			// #npcloot show
			else if (strcasecmp(sep.arg[1], "show") == 0) {
				if (target->IsNPC())
					target->CastToNPC()->QueryLoot(this);
				else if (target->IsCorpse())
					target->CastToCorpse()->QueryLoot(this);
				else
					Message(0, "Error: Target's type doesnt have loot");
			}
			// These 2 types are *BAD* for the next few commands
			else if (target->IsClient() || target->IsCorpse())
				Message(0, "Error: Invalid target type, try a NPC =).");
			// #npcloot add
			else if (strcasecmp(sep.arg[1], "add") == 0) {
				// #npcloot add item
				if (target->IsNPC() && sep.IsNumber(2)) {
					int32 item = atoi(sep.arg[2]);
					if (database.GetItem(item)) {
						target->CastToNPC()->AddItem(item, 0, 0);
						Message(0, "Added item(%i) to the %s's loot.", item, target->GetName());
					}
					else
						Message(0, "Error: #npcloot add: Item(%i) does not exist!", item);
				}
				else if (!sep.IsNumber(2))
					Message(0, "Error: #npcloot add: Itemid must be a number.");
				else
					Message(0, "Error: #npcloot add: This is not a valid target.");
			}
			// #npcloot remove
			else if (strcasecmp(sep.arg[1], "remove") == 0) {
				//#npcloot remove all
				if (strcasecmp(sep.arg[2], "all") == 0)
					Message(0, "Error: #npcloot remove all: Not yet implemented.");
				//#npcloot remove itemid
				else {
					if(target->IsNPC() && sep.IsNumber(2)) {
						int32 item = atoi(sep.arg[2]);
						target->CastToNPC()->RemoveItem(item);
						Message(0, "Removed item(%i) from the %s's loot.", item, target->GetName());
					}
					else if (!sep.IsNumber(2))					
						Message(0, "Error: #npcloot remove: Item must be a number.");
					else
						Message(0, "Error: #npcloot remove: This is not a valid target.");
				}
			}
			// #npcloot money
			else if (strcasecmp(sep.arg[1], "money") == 0) {
				if (target->IsNPC() && sep.IsNumber(2) && sep.IsNumber(3) && sep.IsNumber(4) && sep.IsNumber(5)) {
					if ((atoi(sep.arg[2]) < 34465 && atoi(sep.arg[2]) >= 0) && (atoi(sep.arg[3]) < 34465 && atoi(sep.arg[3]) >= 0) && (atoi(sep.arg[4]) < 34465 && atoi(sep.arg[4]) >= 0) && (atoi(sep.arg[5]) < 34465 && atoi(sep.arg[5]) >= 0)) {
						target->CastToNPC()->AddCash(atoi(sep.arg[5]), atoi(sep.arg[4]), atoi(sep.arg[3]), atoi(sep.arg[2]));
						Message(0, "Set %i Platinum, %i Gold, %i Silver, and %i Copper as %s's money.", atoi(sep.arg[2]), atoi(sep.arg[3]), atoi(sep.arg[4]), atoi(sep.arg[5]), target->GetName());
					}
					else
						Message(0, "Error: #npcloot money: Values must be between 0-34465.");
				}
				else
					Message(0, "Usage: #npcloot money platinum gold silver copper");
			}
			else
				Message(0, "Usage: #npcloot [show/money/add/remove] [itemid/all/money: pp gp sp cp]");
		}
		else if (strcasecmp(sep.arg[0], "#npcstats") == 0 && CheckAccess(cmdlevel, 80)) {
			if (target == 0)
				Message(0, "ERROR: No target!");
			else if (!target->IsNPC())
				Message(0, "ERROR: Target is not a NPC!");
			else {
				Message(0, "NPC Stats:");
				Message(0, "  Name: %s",target->GetName()); 
				//Message(0, "  Last Name: %s",sep.arg[2]); 
				Message(0, "  Race: %i",target->GetRace());  
				Message(0, "  Level: %i",target->GetLevel());
				Message(0, "  Material: %i",target->GetTexture());
				Message(0, "  Class: %i",target->GetClass());
				Message(0, "  Current HP: %i", target->GetHP());
				Message(0, "  Max HP: %i", target->GetMaxHP());
				//Message(0, "Weapon Item Number: %s",target->GetWeapNo()); 
				Message(0, "  Gender: %i",target->GetGender()); 
				target->CastToNPC()->QueryLoot(this);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#FindSpell") == 0 || strcasecmp(sep.arg[0], "#spfind") == 0) && CheckAccess(cmdlevel, 20)) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #FindSpell [spellname]");
			else if (!spells_loaded)
				Message(0, "Spells not loaded");
			else if (Seperator::IsNumber(sep.argplus[1])) {
				int spellid = atoi(sep.argplus[1]);
				if (spellid <= 0 || spellid >= SPDAT_RECORDS) {
					Message(0, "Error: Number out of range");
				}
				else {
					Message(0, "  %i: %s", spellid, spells[spellid].name);
				}
			}
			else {
				int count=0;
				//int iSearchLen = strlen(sep.argplus[1])+1;
				char sName[64];
				char sCriteria[65];
				strncpy(sCriteria, sep.argplus[1], 64);
				strupr(sCriteria);
				for (int i = 0; i < SPDAT_RECORDS; i++)
				{
					if (spells[i].name[0] != 0) {
						strcpy(sName, spells[i].name);
						
						strupr(sName);
						char* pdest = strstr(sName, sCriteria);
						if ((pdest != NULL) && (count <=20)) {
							Message(0, "  %i: %s", i, spells[i].name);
							count++;
						}
						else if (count > 20)
							break;
					}
				}
				if (count > 20)
					Message(0, "20 spells found... max reached.");
				else
					Message(0, "%i spells found.", count);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#CastSpell") == 0 || strcasecmp(sep.arg[0], "#Cast") == 0) && CheckAccess(cmdlevel, 20)) {
			if (!sep.IsNumber(1))
				Message(0, "Usage: #CastSpell spellid");
			else { 
				
				int16 spellid = atoi(sep.arg[1]);
				if ((spellid == 982 || spellid == 905 || spellid == 2079 || spellid == 1218 || spellid == 819 || spellid >= 780 && spellid <= 785 || spellid >= 1200 && spellid <= 1205 || spellid == 1923 || spellid ==1924) && admin < 100)
				{ Message(13, "Unable to cast spell."); break; }
				if (spellid >= SPDAT_RECORDS)
					Message(0, "Error: #CastSpell: Arguement out of range");
				else {
					if (target == 0)
						if(admin>=100)
							CastSpell(spellid, 0, 10, 0);
						else
							CastSpell(spellid, 0, 10);
						else
							if(admin>=100)
								CastSpell(spellid, target->GetID(), 10, 0);
							else
								CastSpell(spellid, target->GetID(), 10);
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#memspell") == 0 && CheckAccess(cmdlevel, 100)) {
			if (!(sep.IsNumber(1) && sep.IsNumber(2)))
				Message(0, "Usage: #MemSpell slotid spellid");
			else { 
				int16 slotid = atoi(sep.arg[1]) - 1;
				int16 spellid = atoi(sep.arg[2]);
#if WIN32
				if (slotid < 0 || slotid >= 8) {
#else
					if (slotid >=8) {
#endif
						Message(0, "Error: #MemSpell: Arguement out of range");
					}
					else if (spellid >= SPDAT_RECORDS)
						Message(0, "Error: #MemSpell: Arguement out of range");
					else {
						pp.spell_memory[slotid] = spellid; 
						Message(0, "Spell slot changed, it'll be there when you relog.");
					}
				}
			}
			else if ((strcasecmp(sep.arg[0], "#invul") == 0 || strcasecmp(sep.arg[0], "#invulnerable") == 0) && CheckAccess(cmdlevel, 80)) {
				Client* client = this;
				if (target) {
					if (target->IsClient())
						client = target->CastToClient();
				}
				if (sep.arg[1][0] == '1') {
					client->Message(0, "You are now invulnerable from attack.");
					client->invulnerable = true;
				}
				else if (sep.arg[1][0] == '0') {
					client->Message(0, "You are no longer invulnerable from attack.");
					client->invulnerable = false;
				}
				else
					Message(0, "Usage: #invulnerable [1/0]");
			}
			else if (strcasecmp(sep.arg[0], "#setskill") == 0 && CheckAccess(cmdlevel, 20)) {
				if (target == 0) {
					Message(0, "Error: #setskill: No target.");
				}
				else if (!sep.IsNumber(1) || atoi(sep.arg[1]) < 0 || atoi(sep.arg[1]) > 73) {
					Message(0, "Usage: #setskill skill x ");
					Message(0, "       skill = 0 to 73");
					Message(0, "       x = 0 to 255");
					Message(0, "NOTE: skill values greater than 250 may cause the skill to become unusable on the client.");
				}
				else if (!sep.IsNumber(2) || atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > 255) {
					Message(0, "Usage: #setskill skill x ");
					Message(0, "       skill = 0 to 73");
					Message(0, "       x = 0 to 255");
				}
				else {
					//pp.skills[atoi(sep.arg[1])] = (int8)atoi(sep.arg[2]);
					cout << "Setting " << target->GetName() << " skill " << sep.arg[1] << " to " << sep.arg[2] << endl;
					int skill_num = atoi(sep.arg[1]);
					int8 skill_id = (int8)atoi(sep.arg[2]);
					target->SetSkill(skill_num, skill_id);
				}
			}
			else if ((strcasecmp(sep.arg[0], "#setallskill") == 0 || strcasecmp(sep.arg[0], "#setskillall") == 0) && CheckAccess(cmdlevel, 20)) {
				if (target == 0) {
					Message(0, "Error: #setallskill: No target.");
				}
				else if (!sep.IsNumber(1) || atoi(sep.arg[1]) < 0 || atoi(sep.arg[1]) > 252) {
					Message(0, "Usage: #setskill value ");
					Message(0, "       value = 0 to 252");
				}
				else {
					//pp.skills[atoi(sep.arg[1])] = (int8)atoi(sep.arg[2]);
					cout << "Setting ALL of " << target->GetName() << "'s skills to " << sep.arg[1] << endl;
					int8 skill_id = atoi(sep.arg[1]);
					for(int skill_num=0;skill_num<74;skill_num++){
						target->SetSkill(skill_num, skill_id);
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#save") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target == 0)
					Message(0, "Error: no target");
				else if (!target->IsClient())
					Message(0, "Error: target not a client");
				else if	(target->CastToClient()->Save())
					Message(0, "%s successfully saved.", target->GetName());
				else
					Message(0, "Manual save for %s failed.", target->GetName());
			}
			else if (strcasecmp(sep.arg[0], "#showstats") == 0) {
				if (target != 0 && CheckAccess(cmdlevel, 100))
					target->ShowStats(this);
				else
					this->ShowStats(this);
			}
			else if (strcasecmp(sep.arg[0], "#iteminfo") == 0) {
				const Item_Struct* item = database.GetItem(pp.inventory[0]);
				if (item == 0)
					Message(0, "Error: You need an item on your cursor for this command");
				else {
					Message(0, "ID: %i Name: %s", item->item_nr, item->name);
					Message(0, "  Lore: %s  ND: %i  NS: %i  Type: %i", item->lore, item->nodrop, item->nosave, item->type);
					Message(0, "  IDF: %s  Size: %i  Weight: %i  Flag: %04x  icon_nr: %i  Cost: %i", item->idfile, item->size, item->weight, (int16) item->flag, (int16) item->icon_nr, item->cost);
					if (item->type == 0x02)
						Message(0, "  This item is a Book: %s", item->book.file);
					else {
						if (item->type == 0x01)
							Message(0, "  This item is a container with %i slots", item->container.numSlots);			
						Message(0, "  Magic: %i  SpellID0: %i  Level0: %i  Charges: %i", item->common.magic, item->common.spellId0, item->common.level0, item->common.charges);
						Message(0, "  SpellId: %i  Level: %i  EffectType: 0x%02x  CastTime: %.2f", item->common.spellId, item->common.level, (int8) item->common.effecttype, (double) item->common.casttime/1000);
						Message(0, "  Material: 0x02%x  Color: 0x%08x", item->common.material, item->common.color);
						
						/* TODO: FIX THE UNKNOWNS THAT ARE DISPLAYED!!!
						Message(0, "  U0187: 0x%02x%02x  U0192: 0x%02x  U0198: 0x%02x%02x  U0204: 0x%02x%02x  U0210: 0x%02x%02x  U0214: 0x%02x%02x%02x", item->common.unknown0187[0], item->common.unknown0187[1], item->common.unknown0192, item->common.unknown0198[0], item->common.unknown0198[1], item->common.unknown0204[0], item->common.unknown0204[1], item->common.unknown0210[0], item->common.unknown0210[1], (int8) item->common.normal.unknown0214[0], (int8) item->common.normal.unknown0214[1], (int8) item->common.normal.unknown0214[2]);
						Message(0, "  U0222[0-9]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0222[0], (int8) item->common.unknown0222[1], (int8) item->common.unknown0222[2], (int8) item->common.unknown0222[3], (int8) item->common.unknown0222[4], (int8) item->common.unknown0222[5], (int8) item->common.unknown0222[6], (int8) item->common.unknown0222[7], (int8) item->common.unknown0222[8], (int8) item->common.unknown0222[9]);
						Message(0, "  U0236[ 0-15]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[0], (int8) item->common.unknown0236[1], (int8) item->common.unknown0236[2], (int8) item->common.unknown0236[3], (int8) item->common.unknown0236[4], (int8) item->common.unknown0236[5], (int8) item->common.unknown0236[6], (int8) item->common.unknown0236[7], (int8) item->common.unknown0236[8], (int8) item->common.unknown0236[9], (int8) item->common.unknown0236[10], (int8) item->common.unknown0236[11], (int8) item->common.unknown0236[12], (int8) item->common.unknown0236[13], (int8) item->common.unknown0236[14], (int8) item->common.unknown0236[15]);
						Message(0, "  U0236[16-31]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[16], (int8) item->common.unknown0236[17], (int8) item->common.unknown0236[18], (int8) item->common.unknown0236[19], (int8) item->common.unknown0236[20], (int8) item->common.unknown0236[21], (int8) item->common.unknown0236[22], (int8) item->common.unknown0236[23], (int8) item->common.unknown0236[24], (int8) item->common.unknown0236[25], (int8) item->common.unknown0236[26], (int8) item->common.unknown0236[27], (int8) item->common.unknown0236[28], (int8) item->common.unknown0236[29], (int8) item->common.unknown0236[30], (int8) item->common.unknown0236[31]);
						Message(0, "  U0236[32-47]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[32], (int8) item->common.unknown0236[33], (int8) item->common.unknown0236[34], (int8) item->common.unknown0236[35], (int8) item->common.unknown0236[36], (int8) item->common.unknown0236[37], (int8) item->common.unknown0236[38], (int8) item->common.unknown0236[39], (int8) item->common.unknown0236[40], (int8) item->common.unknown0236[41], (int8) item->common.unknown0236[42], (int8) item->common.unknown0236[43], (int8) item->common.unknown0236[44], (int8) item->common.unknown0236[45], (int8) item->common.unknown0236[46], (int8) item->common.unknown0236[47]);
						Message(0, "  U0236[48-55]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[48], (int8) item->common.unknown0236[49], (int8) item->common.unknown0236[50], (int8) item->common.unknown0236[51], (int8) item->common.unknown0236[52], (int8) item->common.unknown0236[53], (int8) item->common.unknown0236[54], (int8) item->common.unknown0236[55]);
						*/
					}
					/* TODO: FIX THE UNKNOWNS THAT ARE DISPLAYED!!!
					Message(0, "  U0103[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[0], (int8) item->unknown0103[1], (int8) item->unknown0103[2], (int8) item->unknown0103[3], (int8) item->unknown0103[4], (int8) item->unknown0103[5], (int8) item->unknown0103[6], (int8) item->unknown0103[7], (int8) item->unknown0103[8], (int8) item->unknown0103[9], (int8) item->unknown0103[10], (int8) item->unknown0103[11]);
					Message(0, "  U0103[12-21]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[12], (int8) item->unknown0103[13], (int8) item->unknown0103[14], (int8) item->unknown0103[15], (int8) item->unknown0103[16], (int8) item->unknown0103[17], (int8) item->unknown0103[18], (int8) item->unknown0103[19], (int8) item->unknown0103[20], (int8) item->unknown0103[21]);
					Message(0, "  U0144[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[0], (int8) item->unknown0144[1], (int8) item->unknown0144[2], (int8) item->unknown0144[3], (int8) item->unknown0144[4], (int8) item->unknown0144[5], (int8) item->unknown0144[6], (int8) item->unknown0144[7], (int8) item->unknown0144[8], (int8) item->unknown0144[9], (int8) item->unknown0144[10], (int8) item->unknown0144[11]);
					Message(0, "  U0144[12-23]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[12], (int8) item->unknown0144[13], (int8) item->unknown0144[14], (int8) item->unknown0144[15], (int8) item->unknown0144[16], (int8) item->unknown0144[17], (int8) item->unknown0144[18], (int8) item->unknown0144[19], (int8) item->unknown0144[20], (int8) item->unknown0144[21], (int8) item->unknown0144[22], (int8) item->unknown0144[23]);
					Message(0, "  U0144[24-27]: 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[24], (int8) item->unknown0144[25], (int8) item->unknown0144[26], (int8) item->unknown0144[27]);
					*/
				}
			}
			else if (strcasecmp(sep.arg[0], "#Depop") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target == 0 || !(target->IsNPC() || target->IsNPCCorpse()))
					Message(0, "You must have a NPC target for this command. (maybe you meant #depopzone?)");
				else {
					Message(0, "Depoping '%s'.", target->GetName());
					target->Depop();
				}
			}
			else if (strcasecmp(sep.arg[0], "#DepopCorpses") == 0 && CheckAccess(cmdlevel, 100)) {
				entity_list.DepopCorpses();
				Message(0, "NPC corpses depoped.");
			}
			else if (strcasecmp(sep.arg[0], "#DepopZone") == 0 && CheckAccess(cmdlevel, 100)) {
				zone->Depop();
				Message(0, "Zone depoped.");
			}
			else if (strcasecmp(sep.arg[0], "#Repop") == 0 && CheckAccess(cmdlevel, 100)) {
				if (sep.IsNumber(1)) {
					zone->Repop(atoi(sep.arg[1])*1000);
					Message(0, "Zone depoped. Repop in %i seconds", atoi(sep.arg[1]));
				}
				else {
					zone->Repop();
					Message(0, "Zone depoped. Repoping now.");
				}
			}
			else if (strcasecmp(sep.arg[0], "#spawnstatus") == 0 && CheckAccess(cmdlevel, 100)) {
				zone->SpawnStatus(this);
			}
			else if (strcasecmp(sep.arg[0], "#listNPCs") == 0 && CheckAccess(cmdlevel, 100)) {
				if (strcasecmp(sep.arg[1], "all") == 0)
					entity_list.ListNPCs(this,sep.arg[1],sep.arg[2],0);
				else if(sep.IsNumber(1) && sep.IsNumber(2))
					entity_list.ListNPCs(this,sep.arg[1],sep.arg[2],2);
				else if(sep.arg[1][0] != 0)
					entity_list.ListNPCs(this,sep.arg[1],sep.arg[2],1);
				else {
					Message(0, "Usage of #listnpcs:");
					Message(0, "#listnpcs [#] [#] (Each number would search by ID, ex. #listnpcs 1 30, searches 1-30)");
					Message(0, "#listnpcs [name] (Would search for a npc with [name])");
				}
			}
			else if (strcasecmp(sep.arg[0], "#listNPCCorpses") == 0 && CheckAccess(cmdlevel, 100)) {
				entity_list.ListNPCCorpses(this);
			}
			else if (strcasecmp(sep.arg[0], "#listPlayerCorpses") == 0 && CheckAccess(cmdlevel, 100)) {
				entity_list.ListPlayerCorpses(this);
			}
			else if (strcasecmp(sep.arg[0], "#deleteNPCCorpses") == 0 && CheckAccess(cmdlevel, 100)) {
				sint32 tmp = entity_list.DeleteNPCCorpses();
				if (tmp >= 0)
					Message(0, "%i corpses deleted.", tmp);
				else
					Message(0, "DeletePlayerCorpses Error #%i", tmp);
			}
			else if (strcasecmp(sep.arg[0], "#deletePlayerCorpses") == 0 && CheckAccess(cmdlevel, 150)) {
				sint32 tmp = entity_list.DeletePlayerCorpses();
				if (tmp >= 0)
					Message(0, "%i corpses deleted.", tmp);
				else
					Message(0, "DeletePlayerCorpses Error #%i", tmp);
			}
			else if (strcasecmp(sep.arg[0], "#doanim") == 0) {
				if (!sep.IsNumber(1)) {
					Message(0, "Usage: #DoAnim [number]");
				}
				else {
					if (admin >= 100) {
						if (target == 0)
							Message(0, "Error: You need a target.");
						else
							target->DoAnim(atoi(sep.arg[1]));
					}
					else
						DoAnim(atoi(sep.arg[1]));
				}
			}
			else if (strcasecmp(sep.arg[0], "#showbuffs") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target == 0)
					this->ShowBuffs(this);
				else
					target->ShowBuffs(this);
			}
			else if (strcasecmp(sep.arg[0], "#nukebuffs") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target == 0)
					this->BuffFade(0xFFFe);
				else
					target->BuffFade(0xFFFe);
			}
			else if (strcasecmp(sep.arg[0], "#hideme") == 0 && CheckAccess(cmdlevel, 80)) {
				if ((sep.arg[1][0] != '0' && sep.arg[1][0] != '1') || sep.arg[1][1] != 0)
					Message(0, "Usage: #hideme [0/1]");
				else {
					gmhideme = atoi(sep.arg[1]);
					if (gmhideme) {
						APPLAYER app;
						CreateDespawnPacket(&app);
						entity_list.QueueClientsStatus(this, &app, true, 0, admin-1);
						entity_list.RemoveFromTargets(this);
						Message(13, "Removing you from spawn lists.");
					}
					else {
						APPLAYER app;
						CreateSpawnPacket(&app);
						entity_list.QueueClientsStatus(this, &app, true, 0, admin-1);
						Message(13, "Adding you back to spawn lists.");
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#deletecorpse") == 0 && CheckAccess(cmdlevel, 150)) {
				if (target == 0 || !target->IsPlayerCorpse())
					Message(0, "Error: Target the player corpse you wish to delete");
				else {
					Message(0, "Deleting %s.", target->GetName());
					target->CastToCorpse()->Delete();
				}
			}
			else if (strcasecmp(sep.arg[0], "#sendzonespawns") == 0 && CheckAccess(cmdlevel, 200)) {
				entity_list.SendZoneSpawns(this);
			}
			else if (strcasecmp(sep.arg[0], "#flymode") == 0 && CheckAccess(cmdlevel, 20)) {
				if (strlen(sep.arg[1]) == 1 && !(sep.arg[1][0] == '0' || sep.arg[1][0] == '1' || sep.arg[1][0] == '2')) {
					Message(0, "#flymode [0/1/2]");
				}
				else {
					if (target == 0 || !target->IsClient() || admin < 100) {
						this->SendAppearancePacket(19, atoi(sep.arg[1]));
						if (sep.arg[1][0] == '1')
							Message(0, "Turning Flymode ON");
						else if (sep.arg[1][0] == '2')
							Message(0, "Turning Flymode LEV");
						else
							Message(0, "Turning Flymode OFF");
					}
					else {
						target->SendAppearancePacket(19, atoi(sep.arg[1]));
						if (sep.arg[1][0] == '1')
							Message(0, "Turning %s's Flymode ON", target->GetName());
						else if (sep.arg[1][0] == '2')
							Message(0, "Turning %s's Flymode LEV", target->GetName());
						else
							Message(0, "Turning %s's Flymode OFF", target->GetName());
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#race") == 0 && CheckAccess(cmdlevel, 20)) {
				if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 329) {
					if ((target) && admin >= 100)
						target->SendIllusionPacket(atoi(sep.arg[1]));
					else
						this->SendIllusionPacket(atoi(sep.arg[1]));
				}
				else
					Message(0, "Usage: #race [0-329]  (0 for back to normal)");
			}
			else if (strcasecmp(sep.arg[0], "#texture") == 0 && CheckAccess(cmdlevel, 10)) {
				if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 255) {
					int tmp;
					if (sep.IsNumber(2) && atoi(sep.arg[2]) >= 0 && atoi(sep.arg[2]) <= 255) {
						tmp = atoi(sep.arg[2]);
					}
					else if (atoi(sep.arg[1]) == 255) {
						tmp = atoi(sep.arg[1]);
					}
					else if ((GetRace() > 0 && GetRace() <= 12) || GetRace() == 128 || GetRace() == 130)
						tmp = 0;
					else
						tmp = atoi(sep.arg[1]);
					
					if ((target) && admin >= 100)
						target->SendIllusionPacket(target->GetRace(), 0xFF, atoi(sep.arg[1]), tmp);
					else
						this->SendIllusionPacket(this->GetRace(), 0xFF, atoi(sep.arg[1]), tmp);
				}
				else
					Message(0, "Usage: #texture [texture] [helmtexture]  (0-255, 255 for show equipment)");
			}
			else if (strcasecmp(sep.arg[0], "#gender") == 0 && CheckAccess(cmdlevel, 10)) {
				if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 2) {
					gender = atoi(sep.arg[1]);
					if ((target) && admin >= 100)
						target->SendIllusionPacket(target->GetRace(), gender);
					else
						this->SendIllusionPacket(this->GetRace(), gender);
				}
				else
					Message(0, "Usage: #gender [0-2]  (0=male, 1=female, 2=neuter)");
			}
			else if (strcasecmp(sep.arg[0], "#zheader")==0 && CheckAccess(cmdlevel, 80)) {
				// sends zhdr packet
				if(sep.arg[1][0]==0) {
					Message(0, "Usage: #zheader <zone name>");
					Message(0, "NOTE: Use \"none\" for zone name to use default header.");
				}
				else {
					if (strcasecmp(sep.argplus[1], "none") == 0) {
						Message(0, "Loading default zone header");
						zone->LoadZoneCFG(0);
					}
					else {
						if (zone->LoadZoneCFG(sep.argplus[1], true))
							Message(0, "Successfully loaded zone header: %s.cfg", sep.argplus[1]);
						else
							Message(0, "Failed to load zone header: %s.cfg", sep.argplus[1]);
					}
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
				
			}
			else if(strcasecmp(sep.arg[0], "#zsky") == 0 && CheckAccess(cmdlevel, 80)) {
				// modifys and resends zhdr packet
				if(sep.arg[1][0]==0)
					Message(0, "Usage: #zsky <sky type>");
				else if(atoi(sep.arg[1])<0||atoi(sep.arg[1])>255)
					Message(0, "ERROR: Sky type can not be less than 0 or greater than 255!");
				else {
					zone->newzone_data.sky = atoi(sep.arg[1]);
					
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else if((strcasecmp(sep.arg[0], "#zcolor") == 0 || strcasecmp(sep.arg[0], "#zcolour") == 0) && CheckAccess(cmdlevel, 80)) {
				// modifys and resends zhdr packet
				if(sep.arg[3][0]==0)
					Message(0, "Usage: #zcolor <red> <green> <blue>");
				else if(atoi(sep.arg[1])<0||atoi(sep.arg[1])>255)
					Message(0, "ERROR: Red can not be less than 0 or greater than 255!");
				else if(atoi(sep.arg[2])<0||atoi(sep.arg[2])>255)
					Message(0, "ERROR: Green can not be less than 0 or greater than 255!");
				else if(atoi(sep.arg[3])<0||atoi(sep.arg[3])>255)
					Message(0, "ERROR: Blue can not be less than 0 or greater than 255!");
				else {
					for(int z=1;z<13;z++) {
						if(z<5)
							zone->newzone_data.unknown230[z] = atoi(sep.arg[1]);
						if(z>4 && z<9)
							zone->newzone_data.unknown230[z] = atoi(sep.arg[2]);
						if(z>8)
							zone->newzone_data.unknown230[z] = atoi(sep.arg[3]);
					}
					
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else if(strcasecmp(sep.arg[0], "#zuwcoords") == 0 && CheckAccess(cmdlevel, 100)) {
				// modifys and resends zhdr packet
				if(sep.arg[1][0]==0)
					Message(0, "Usage: #zuwcoords <under world coords>");
				else {
					zone->newzone_data.underworld = atof(sep.arg[1]);
					//				float newdata = atof(sep.arg[1]);
					//				memcpy(&zone->zone_header_data[130], &newdata, sizeof(float));
					
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else if(strcasecmp(sep.arg[0], "#zsafecoords") == 0 && CheckAccess(cmdlevel, 100)) {
				// modifys and resends zhdr packet
				if(sep.arg[3][0]==0)
					Message(0, "Usage: #zsafecoords <safe x> <safe y> <safe z>");
				else {
					zone->newzone_data.safe_x = atof(sep.arg[1]);
					zone->newzone_data.safe_y = atof(sep.arg[2]);
					zone->newzone_data.safe_z = atof(sep.arg[3]);
					//				float newdatax = atof(sep.arg[1]);
					//				float newdatay = atof(sep.arg[2]);
					//				float newdataz = atof(sep.arg[3]);
					//				memcpy(&zone->zone_header_data[114], &newdatax, sizeof(float));
					//				memcpy(&zone->zone_header_data[118], &newdatay, sizeof(float));
					//				memcpy(&zone->zone_header_data[122], &newdataz, sizeof(float));
					//				zone->SetSafeCoords();
					
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else if(strcasecmp(sep.arg[0], "#zclip") == 0 && CheckAccess(cmdlevel, 80)) {
				// modifys and resends zhdr packet
				if(sep.arg[2][0]==0)
					Message(0, "Usage: #zclip <min clip> <max clip>");
				else if(atoi(sep.arg[1])<=0)
					Message(0, "ERROR: Min clip can not be zero or less!");
				else if(atoi(sep.arg[2])<=0)
					Message(0, "ERROR: Max clip can not be zero or less!");
				else if(atoi(sep.arg[1])>atoi(sep.arg[2]))
					Message(0, "ERROR: Min clip is greater than max clip!");
				else {
					zone->newzone_data.minclip = atof(sep.arg[1]);
					zone->newzone_data.maxclip = atof(sep.arg[2]);
					//				float newdatamin = atof(sep.arg[1]);
					//				float newdatamax = atof(sep.arg[2]);
					//				memcpy(&zone->zone_header_data[134], &newdatamin, sizeof(float));
					//				memcpy(&zone->zone_header_data[138], &newdatamax, sizeof(float));
					
					APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else if(strcasecmp(sep.arg[0], "#zsave") == 0 && CheckAccess(cmdlevel, 200)) {
				// modifys and resends zhdr packet
				if(sep.arg[1][0]==0)
					Message(0, "Usage: #zsave <file name>");
				else {
					zone->SaveZoneCFG(sep.argplus[1]);
				}
			}
			else if (strcasecmp(sep.arg[0], "#npccast") == 0 && CheckAccess(cmdlevel, 80)) {
				if (target && target->IsNPC() && sep.arg[1] != 0 && sep.IsNumber(2)) {
					Mob* spelltar = entity_list.GetMob(sep.arg[1]);
					if (spelltar) {
						target->CastSpell(atoi(sep.arg[2]), spelltar->GetID());
					}
					else {
						Message(0, "Error: %s not found", sep.arg[1]);
					}
				}
				else {
					Message(0, "Usage: (needs NPC targeted) #npccast targetname spellid");
				}
			}
			else if (strcasecmp(sep.arg[0], "#dbspawn2") == 0 && CheckAccess(cmdlevel, 200)) // Image's Spawn Code -- Rewrite by Scruffy
			{
				if (sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3)) {
					cout << "Spawning: Database spawn" << endl; 
					database.CreateSpawn2(atoi(sep.arg[1]), zone->GetShortName(), heading, x_pos, y_pos, z_pos, atoi(sep.arg[2]), atoi(sep.arg[3]));
				}
				else {
					Message(0, "Usage: #dbspawn2 spawngroup respawn variance");
				}
			}
			else if (strcasecmp(sep.arg[0], "#npctypespawn") == 0 && CheckAccess(cmdlevel, 10))
			{
				if (sep.IsNumber(1)) {
					const NPCType* tmp = 0;
					if ((tmp = database.GetNPCType(atoi(sep.arg[1]))))
					{
						//					tmp->fixedZ = 1;
						NPC* npc = new NPC(tmp, 0, x_pos, y_pos, z_pos/10, heading);
						entity_list.AddNPC(npc); 
					}
					else
						Message(0, "NPC Type %i not found", atoi(sep.arg[1])); 
				}
				else {
					Message(0, "Usage: #dbspawn npctypeid");
				}
			}
			else if (strcasecmp(sep.arg[0], "#attack") == 0 && CheckAccess(cmdlevel, 150)) {
				
				if (target && target->IsNPC() && sep.arg[1] != 0) {
					Mob* sictar = entity_list.GetMob(sep.argplus[1]);
					if (sictar) {
						target->CastToNPC()->AddToHateList(sictar, 0, 100000);
					}
					else {
						Message(0, "Error: %s not found", sep.arg[1]);
					}
				}
				else {
					Message(0, "Usage: (needs NPC targeted) #attack targetname");
				}
			}
			else if (strcasecmp(sep.arg[0], "#zstats") == 0 && CheckAccess(cmdlevel, 80)) {
				Message(0, "Zone Header Data:");
				Message(0, "Sky Type: %i", zone->newzone_data.sky);
				Message(0, "Sky Colour: Red: %i; Blue: %i; Green %i", zone->newzone_data.unknown230[1], zone->newzone_data.unknown230[5], zone->newzone_data.unknown230[9]);
				Message(0, "Safe Coords: %f, %f, %f", zone->newzone_data.safe_x, zone->newzone_data.safe_y, zone->newzone_data.safe_z);
				Message(0, "Underworld Coords: %f", zone->newzone_data.underworld);
				Message(0, "Clip Plane: %f - %f", zone->newzone_data.minclip, zone->newzone_data.maxclip);
			}
			else if (strcasecmp(sep.arg[0], "#lock") == 0 && CheckAccess(cmdlevel, 150)) {
				ServerPacket* outpack = new ServerPacket(ServerOP_Lock, sizeof(ServerLock_Struct));
				ServerLock_Struct* lss = (ServerLock_Struct*) outpack->pBuffer;
				strcpy(lss->myname, this->GetName());
				lss->mode = 1;
				worldserver.SendPacket(outpack);
				delete outpack;
			}
			else if (strcasecmp(sep.arg[0], "#unlock") == 0 && CheckAccess(cmdlevel, 150)) {
				ServerPacket* outpack = new ServerPacket(ServerOP_Lock, sizeof(ServerLock_Struct));
				ServerLock_Struct* lss = (ServerLock_Struct*) outpack->pBuffer;
				strcpy(lss->myname, this->GetName());
				lss->mode = 0;
				worldserver.SendPacket(outpack);
				delete outpack;
			}
			else if (strcasecmp(sep.arg[0], "#motd") == 0 && CheckAccess(cmdlevel, 150)) {
				ServerPacket* outpack = new ServerPacket(ServerOP_Motd, sizeof(ServerMotd_Struct));
				ServerMotd_Struct* mss = (ServerMotd_Struct*) outpack->pBuffer;
				strcpy(mss->myname, this->GetName());
				strcpy(mss->motd, sep.argplus[1]);
				worldserver.SendPacket(outpack);
				delete outpack;
			}
			else if (strcasecmp(sep.arg[0], "#uptime") == 0) {
				if (!worldserver.Connected()) {
					Message(0, "Error: World server disconnected");
				}
				else if (sep.IsNumber(1) && atoi(sep.arg[1]) > 0) {
					ServerPacket* pack = new ServerPacket(ServerOP_Uptime, sizeof(ServerUptime_Struct));
					ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
					strcpy(sus->adminname, this->GetName());
					sus->zoneserverid = atoi(sep.arg[1]);
					worldserver.SendPacket(pack);
					delete pack;
				}
				else {
					ServerPacket* pack = new ServerPacket(ServerOP_Uptime, sizeof(ServerUptime_Struct));
					ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
					strcpy(sus->adminname, this->GetName());
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
			else if (strcasecmp(sep.arg[0],"#makepet") == 0 && CheckAccess(cmdlevel, 20)) {
				if (!(sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3) && sep.IsNumber(4))) {
					Message(0, "Usage: #makepet level class race texture");
				}
				else {
					this->MakePet(atoi(sep.arg[1]), atoi(sep.arg[2]), atoi(sep.arg[3]), atoi(sep.arg[4]));
				}
			}
			else if (strcasecmp(sep.arg[0],"#crashtest") == 0 && CheckAccess(cmdlevel, 201)) {
				this->Message(0,"Alright, now we get an GPF ;) ");
				char* gpf;
				gpf = 0;
				memcpy(gpf,"Ready to crash",30);
			}
			else if (strcasecmp(sep.arg[0], "#ShowPetSpell") == 0 && CheckAccess(cmdlevel, 250)) {
				if (sep.arg[1][0] == 0)
					Message(0, "Usage: #ShowPetSpells [petsummonstring]");
				else if (!spells_loaded)
					Message(0, "Spells not loaded");
				else if (Seperator::IsNumber(sep.argplus[1])) {
					int spellid = atoi(sep.argplus[1]);
					if (spellid <= 0 || spellid >= SPDAT_RECORDS) {
						Message(0, "Error: Number out of range");
					}
					else {
						Message(0, "  %i: %s, %s", spellid, spells[spellid].teleport_zone, spells[spellid].name);
					}
				}
				else {
					int count=0;
					//int iSearchLen = strlen(sep.argplus[1])+1;
					char sName[64];
					char sCriteria[65];
					strncpy(sCriteria, sep.argplus[1], 64);
					strupr(sCriteria);
					for (int i = 0; i < SPDAT_RECORDS; i++)
					{
						if (spells[i].name[0] != 0 && (spells[i].effectid[0] == SE_SummonPet || spells[i].effectid[0] == SE_NecPet)) {
							strcpy(sName, spells[i].teleport_zone);
							
							strupr(sName);
							char* pdest = strstr(sName, sCriteria);
							if ((pdest != NULL) && (count <=20)) {
								Message(0, "  %i: %s, %s", i, spells[i].teleport_zone, spells[i].name);
								count++;
							}
							else if (count > 20)
								break;
						}
					}
					if (count > 20)
						Message(0, "20 spells found... max reached.");
					else
						Message(0, "%i spells found.", count);
				}
			}
			else if (strcasecmp(sep.arg[0], "#freeze") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target != 0) {
					target->SendAppearancePacket(14, 102);
				}
				else {
					Message(0, "ERROR: Freeze requires a target.");
				}
			}
			else if (strcasecmp(sep.arg[0], "#unfreeze") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target != 0) {
					target->SendAppearancePacket(14, 100);
				}
				else {
					Message(0, "ERROR: Unfreeze requires a target.");
				}
			}
			else if (strcasecmp(sep.arg[0], "#pvp") == 0 && CheckAccess(cmdlevel, 100)) {
				if (target != 0 && sep.arg[1] != NULL) {
					if (target->IsClient()) {	
						if (strcasecmp(sep.arg[1], "on") == 0)
							target->CastToClient()->SetPVP(true);
						else if (strcasecmp(sep.arg[1], "off") == 0)
							target->CastToClient()->SetPVP(false);
						else
							Message(0, "Usage: #pvp [on/off]");
					}
					else
						Message(0, "Error: #pvp: Invalid target type.");
				}
				else
					Message(0, "Error: #pvp: No target selected.");
			}
			else if (strcasecmp(sep.arg[0], "#permaclass")==0 && CheckAccess(cmdlevel, 80)) {
				if(sep.arg[1][0]==0) {
					Message(0,"FORMAT: #permaclass <classnum>");
				}
				/*else if(target==0) {
				Message(0, "ERROR: Class requires a target.");
			}*/
				else if (target==0){
					Message(0, "Setting your class...Sending you to char select.");
					cout << "Class change request.. Class requested: " << sep.arg[1] << endl;
					pp.class_=atoi(sep.arg[1]);
					Kick();
					pp.class_=atoi(sep.arg[1]);
					Save();
				}
				else if( !target->IsClient())
					Message(0,"Target is not a client.");
				else 
				{
					Message(0, "Setting &s's class...Sending them to char select.",target->CastToClient()->GetName());
					target->CastToClient()->pp.class_=atoi(sep.arg[1]);
					target->CastToClient()->Kick();
					target->CastToClient()->pp.class_=atoi(sep.arg[1]);
					target->CastToClient()->Save();
				}
			}
			else if (strcasecmp(sep.arg[0], "#scribespells")==0 ) {
				if(sep.arg[1][0]==0) {
					Message(0,"FORMAT: #scribespells <level>");
				}
				if((atoi(sep.arg[1]) < 1) || (atoi(sep.arg[1]) > 65))
					Message(0,"ERROR: Enter a level between 1 and 65 inclusive."); 
				else {
					Message(0, "Scribing spells to spellbook");
					cout << "Scribing spells up to level: " << sep.arg[1][0] << endl;
					int bookcount =0;
					for (int i = 0; i < SPDAT_RECORDS; i++)
					{
						if ((spells[i].classes[pp.class_-1] <=atoi(sep.arg[1])) && !(spells[i].classes[0]<= atoi(sep.arg[1])) && (spells[i].skill != 52)) 
						{
							if(bookcount <=255)
							{
								pp.spell_book[bookcount]=i;
								bookcount++;
							}
						}
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#permarace")==0 && CheckAccess(cmdlevel, 80)) {
				if(sep.arg[1][0]==0) {
					Message(0,"FORMAT: #permarace <racenum>");
					Message(0,"NOTE: Not all models are global. If a model is not global, it will appear as a human on character select and in zones without the model.");
				}
				/*else if(target==0) {
				Message(0, "ERROR: Permarace requires a target.");
			}*/
				else if (target==0){
					
					Message(0, "Setting your race...Sending you to char select.");
					cout << "Permanant race change request.. Race requested: " << sep.arg[1] << endl;
					int8 tmp = Mob::GetDefaultGender(atoi(sep.arg[1]), pp.gender); 
					pp.race=atoi(sep.arg[1]);
					pp.gender=tmp;
					Kick();
					pp.race=atoi(sep.arg[1]);
					pp.gender=tmp;
					Save();
				}
				else if( !target->IsClient())
					Message(0,"Target is not a client.");
				else 
				{
					int8 tmp = Mob::GetDefaultGender(atoi(sep.arg[1]), pp.gender);
					Message(0, "Setting &s's race...Sending them to char select.",target->CastToClient()->GetName());
					target->CastToClient()->pp.race=atoi(sep.arg[1]);
					target->CastToClient()->pp.gender=tmp;
					target->CastToClient()->Kick();
					target->CastToClient()->pp.race=atoi(sep.arg[1]);
					target->CastToClient()->pp.gender=tmp;
					target->CastToClient()->Save();
				}
				
			}
			else if (strcasecmp(sep.arg[0], "#permagender")==0 && CheckAccess(cmdlevel, 80)) {
				if(sep.arg[1][0]==0) {
					Message(0,"FORMAT: #permagender <gendernum>");
					Message(0,"Gender Numbers: 0=Male, 2=Female, 3=Neuter");
				}
				/*else if(target==0) {
				Message(0, "ERROR: Permagender requires a target.");
			}*/
				else {
					Message(0, "Setting your gender...Sending you to char select.");
					cout << "Permanant gender change request.. Gender requested: " << sep.arg[1] << endl;
					pp.gender=atoi(sep.arg[1]);
					Kick();
					pp.gender=atoi(sep.arg[1]);
					Save();
				}
			}
			else if (strcasecmp(sep.arg[0], "#gm") == 0 && CheckAccess(cmdlevel, 100)) {
				if ((target != 0) && (target->IsClient())) {
					if(strcasecmp(sep.arg[1], "on") == 0 || atoi(sep.arg[1]) == 1) {
						if(admin < 100 && target != this)
						{
							Message(13,"You have too low of status, cannot set another to GM status");
							break;
						}
						target->CastToClient()->SetGM(true);
						Message(13, "%s is now a GM!", target->CastToClient()->GetName());
					}
					else if(strcasecmp(sep.arg[1], "off") == 0 || atoi(sep.arg[1]) == 0) {
						target->CastToClient()->SetGM(false);
						Message(13, "%s is no longer a GM!", target->CastToClient()->GetName());
					}
					else {
						Message(0, "Usage: #gm [on|off]");
					}
				}
				else {
					if(strcasecmp(sep.arg[1], "on") == 0) {
						SetGM(true);
					}
					else if(strcasecmp(sep.arg[1], "off") == 0) {
						SetGM(false);
					}
					else {
						Message(0, "Usage: #gm [on|off]");
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#gmspeed") == 0 && CheckAccess(cmdlevel, 100)) {
				if (strcasecmp(sep.arg[1], "on") == 0) {
					database.SetGMSpeed(AccountID(), 1);
					Message(0, "GMSpeed On");
				}
				else if (strcasecmp(sep.arg[1], "off") == 0) {
					database.SetGMSpeed(AccountID(), 0);
					Message(0, "GMSpeed Off");
				}
				else {
					Message(0, "Usage: #gmspeed [on|off]");
				}
			}
			else if (strcasecmp(sep.arg[0], "#movechar") == 0 && CheckAccess(cmdlevel, 100)) {
				if(sep.arg[1][0]==0 || sep.arg[2][0] == 0)
					Message(0, "Usage: #movechar [charactername] [zonename]");
				else {
					if (!database.CheckUsedName((char*) sep.arg[1]))
						if (!database.MoveCharacterToZone((char*) sep.arg[1], (char*) sep.arg[2]))
							Message(0, "Character Move Failed!");
						else
							Message(0, "Character has been moved.");
						else
							Message(0, "Character Does Not Exist");
				}
			}
			else if (strcasecmp(sep.arg[0], "#title") == 0 && CheckAccess(cmdlevel, 100)) {
				if (sep.arg[1][0]==0)
					Message(0, "Usage: #title  [0-3]");
				else {
					if (GetTarget() == 0 || GetTarget() == this) {
						if (atoi(sep.arg[1]) >= 0 || atoi(sep.arg[1]) <= 3) {
							this->pp.title = atoi(sep.arg[1]);
							this->Save();
							Message(0,"Updated your Title.");
						}
						else 
							Message(0, "You need to use a number between 0 and 3!");
					}
					else {
						if (GetTarget()->IsClient()) {
							GetTarget()->CastToClient()->ChangeTitle((int8) atoi(sep.arg[1]));
							GetTarget()->CastToClient()->Save();
							Message(0, "Updated %s's Title", GetTarget()->GetName());
						}
						else 
							Message(0, "You must target a valid Player Character For this action.");
					}
				}
			}
			else if (strcasecmp(sep.arg[0], "#spellinfo") == 0 && CheckAccess(cmdlevel, 100))
			{
				if(sep.arg[1][0]==0)
					Message(0, "Usage: #spellinfo [spell_id]");
				else
				{
					short int spell_id=atoi(sep.arg[1]);
					struct SPDat_Spell_Struct *s=&spells[spell_id];
					Message(0, "Spell info for spell #%d:", spell_id);
					Message(0, "  name: %s", s->name);
					Message(0, "  player_1: %s", s->player_1);
					Message(0, "  teleport_zone: %s", s->teleport_zone);
					Message(0, "  you_cast: %s", s->you_cast);
					Message(0, "  other_casts: %s", s->other_casts);
					Message(0, "  cast_on_you: %s", s->cast_on_you);
					Message(0, "  spell_fades: %s", s->spell_fades);
					Message(0, "  range: %f", s->range);
					Message(0, "  aoerange: %f", s->aoerange);
					Message(0, "  pushback: %f", s->pushback);
					Message(0, "  pushup: %f", s->pushup);
					Message(0, "  cast_time: %d", s->cast_time);
					Message(0, "  recovery_time: %d", s->recovery_time);
					Message(0, "  recast_time: %d", s->recast_time);
					Message(0, "  buffdurationformula: %d", s->buffdurationformula);
					Message(0, "  buffduration: %d", s->buffduration);
					Message(0, "  ImpactDuration: %d", s->ImpactDuration);
					Message(0, "  mana: %d", s->mana);
					Message(0, "  base[12]: %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", s->base[0], s->base[1], s->base[2], s->base[3], s->base[4], s->base[5], s->base[6], s->base[7], s->base[8], s->base[9], s->base[10], s->base[11]);
					Message(0, "  max[12]: %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", s->max[0], s->max[1], s->max[2], s->max[3], s->max[4], s->max[5], s->max[6], s->max[7], s->max[8], s->max[9], s->max[10], s->max[11]);
					Message(0, "  icon: %d", s->icon);
					Message(0, "  memicon: %d", s->memicon);
					Message(0, "  components[4]: %d, %d, %d, %d", s->components[0], s->components[1], s->components[2], s->components[3]);
					Message(0, "  component_counts[4]: %d, %d, %d, %d", s->component_counts[0], s->component_counts[1], s->component_counts[2], s->component_counts[3]);
					Message(0, "  NoexpendReagent[4]: %d, %d, %d, %d", s->NoexpendReagent[0], s->NoexpendReagent[1], s->NoexpendReagent[2], s->NoexpendReagent[3]);
					Message(0, "  formula[12]: %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", s->formula[0], s->formula[1], s->formula[2], s->formula[3], s->formula[4], s->formula[5], s->formula[6], s->formula[7], s->formula[8], s->formula[9], s->formula[10], s->formula[11]);
					Message(0, "  LightType: %d", s->LightType);
					Message(0, "  goodEffect: %d", s->goodEffect);
					Message(0, "  Activated: %d", s->Activated);
					Message(0, "  resisttype: %d", s->resisttype);
					Message(0, "  effectid[12]: %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", s->effectid[0], s->effectid[1], s->effectid[2], s->effectid[3], s->effectid[4], s->effectid[5], s->effectid[6], s->effectid[7], s->effectid[8], s->effectid[9], s->effectid[10], s->effectid[11]);
					Message(0, "  targettype: %d", s->targettype);
					Message(0, "  basediff: %d", s->basediff);
					Message(0, "  skill: %d", s->skill);
					Message(0, "  zonetype: %d", s->zonetype);
					Message(0, "  EnvironmentType: %d", s->EnvironmentType);
					Message(0, "  TimeOfDay: %d", s->TimeOfDay);
					Message(0, "  classes[15]: %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", 
						s->classes[0], s->classes[1], s->classes[2], s->classes[3], s->classes[4], 
						s->classes[5], s->classes[6], s->classes[7], s->classes[8], s->classes[9], 
						s->classes[10], s->classes[11], s->classes[12], s->classes[13], s->classes[14]);
					Message(0, "  CastingAnim: %d", s->CastingAnim);
					Message(0, "  TargetAnim: %d", s->TargetAnim);
					Message(0, "  SpellAffectIndex: %d", s->SpellAffectIndex);
					Message(0, "  Spacing2[5]: %d, %d, %d, %d, %d", s->Spacing2[0], s->Spacing2[1], s->Spacing2[2], s->Spacing2[3], s->Spacing2[4]);
				}
			}
			else if (strcasecmp(sep.arg[0], "#copychar") == 0 && CheckAccess(cmdlevel, 200)) {
				if(sep.arg[1][0]==0 || sep.arg[2][0] == 0 || sep.arg[3][0] == 0)
					Message(0, "Usage: #copychar [character name] [new character] [new account id]");
				//CheckUsedName.... TRUE=No Char, FALSE=Char/Error
				//If there is no source...
				else if (database.CheckUsedName((char*) sep.arg[1])) {
					Message(0, "Source character not found!");
				}
				else {
					//If there is a name is not used....
					if (database.CheckUsedName((char*) sep.arg[2]) )
						if (!database.CopyCharacter((char*) sep.arg[1], (char*) sep.arg[2], atoi(sep.arg[3])))
							Message(0, "Character copy operation failed!");
						else
							Message(0, "Character copy complete.");
						else
							Message(0, "Target character already exists!");
				}
			}
			else if (strcasecmp(sep.arg[0], "#datarate") == 0) {
				if (sep.arg[1][0] == 0) {
					Message(0, "Datarate: %1.1f", eqnc->GetDataRate());
					if (admin >= 201) {
						Message(0, "Dataflow: %d", eqnc->GetDataFlow());
					}
				}
				else if (sep.IsNumber(1) && atof(sep.arg[1]) > 0 && atof(sep.arg[1]) <= 25) {
					eqnc->SetDataRate(atof(sep.arg[1]));
					Message(0, "Datarate: %1.1f", eqnc->GetDataRate());
				}
				else {
					Message(0, "Usage: #DataRate [new data rate in kb/sec]");
				}
			}
			else if (strcasecmp(sep.arg[0], "#dmg1") == 0) {
				APPLAYER app;
				app.opcode = OP_Action;
				app.size = sizeof(Action_Struct);
				app.pBuffer = new uchar[app.size];
				memset(app.pBuffer, 0, app.size);
				Action_Struct* a = (Action_Struct*)app.pBuffer;
				adverrorinfo = 412;
				a->target = target->GetID();
				a->source = GetID();
				a->type = atoi(sep.arg[1]);
				a->spell = 16;
				a->damage = 3;
				app.priority = 1;
				entity_list.QueueCloseClients(this, &app);
			}
			else if (strcasecmp(sep.arg[0], "#setaaxp") == 0) {
				if(sep.arg[1][0] == 0) {
					Message(0, "Usage: #setaaxp <new AA XP value>");
				}
				else {
					SetEXP(GetEXP(), atoi(sep.arg[1]), false);
				}
			}
			else if (strcasecmp(sep.arg[0], "#setaapts") == 0) {
				if(sep.arg[1][0] == 0) {
					Message(0, "Usage: #setaapts <new AA points value>");
				}
				else {
					SetEXP(GetEXP(),max_AAXP*atoi(sep.arg[1]),false);
					SendAAStats();
					SendAATable();
				}
			}
			else {
				Message(0, "Command does not exist");
			}
			break;
}

default:
	{
		Message(0, "Channel (%i) not implemented",(int16)chan_num);
		break;
	}
	
}
}

void Client::ChannelMessageSend(const char* from, const char* to, int8 chan_num, int8 language, const char* message, ...) {
	if ((chan_num == 11 || chan_num == 10) && !(this->Admin() >= 80)) // dont need to send /pr & /pet to everybody
		return;
	va_list argptr;
	char buffer[4096];
	
	va_start(argptr, message);
	vsnprintf(buffer, 4096, message, argptr);
	va_end(argptr);
	
	APPLAYER app;
	
	app.opcode = OP_ChannelMessage;
	app.size = sizeof(ChannelMessage_Struct)+strlen(buffer)+1;
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	ChannelMessage_Struct* cm = (ChannelMessage_Struct*) app.pBuffer;
	if (from == 0)
		strcpy(cm->sender, "ZServer"); 	else if (from[0] == 0)
		strcpy(cm->sender, "ZServer"); 	else
		strcpy(cm->sender, from);
	if (to != 0)
		strcpy((char *) cm->targetname, to);
	else
		cm->targetname[0] = 0;
	cm->language = language;
	cm->chan_num = chan_num;
	//cm->cm_unknown4[0] = 0xff;
	cm->cm_unknown4[1] = 0xff; // One of these tells the client how well we know the language
	cm->cm_unknown4[2] = 0xff;
	cm->cm_unknown4[3] = 0xff;
	cm->cm_unknown4[4] = 0xff;
	strcpy(&cm->message[0], buffer);
	
	if (chan_num == 7 && from != 0) 
	{ 
		strcpy(cm->targetname, pp.name); 
	} 
	QueuePacket(&app);
}

void Client::Message(int32 type, const char* message, ...) {
	va_list argptr;
	char buffer[4096];
	
	va_start(argptr, message);
	vsnprintf(buffer, 4096, message, argptr);
	va_end(argptr);
	
	APPLAYER* app = new APPLAYER;
	app->opcode = OP_SpecialMesg;
	app->size = 4+strlen(buffer)+1;
	app->pBuffer = new uchar[app->size];
	SpecialMesg_Struct* sm=(SpecialMesg_Struct*)app->pBuffer;
	sm->msg_type = type;
	strcpy(sm->message, buffer);
	QueuePacket(app);
	delete app;	
}

void Client::SendHPUpdate()	 {
	APPLAYER* app = new APPLAYER;
	CreateHPPacket(app);
	app->priority = 1;
	
	if (GMHideMe())
		entity_list.QueueClientsStatus(this, app, false, admin);
	else
		entity_list.QueueCloseClients(this, app);
	delete app;
}

void Client::SetMaxHP() {
	SetHP(CalcMaxHP());
	SendHPUpdate();
	Save();
}

void Client::AddEXP(int32 add_exp) {
	int32 add_aaxp = (int32)((float)add_exp * ((float)((float)pp.perAA) / 100.0f));
	int32 exp = GetEXP() + (add_exp - add_aaxp);
	int32 aaexp = GetAAXP() + add_aaxp;
	SetEXP(exp, aaexp, false);
	// FIXME!	int32 add_aaxp = (int32)((float)add_exp * ((float)pp.perAA / 100.0f));
	// FIXME!	SetEXP(GetEXP() + (add_exp - add_aaxp), GetAAXP() + add_aaxp, false);
	//	SetEXP(GetEXP() + add_exp, 0, false);
}

void Client::SetEXP(int32 set_exp, int32 set_aaxp, bool isrezzexp) {
	if (set_exp > pp.exp)
		if (isrezzexp)
			Message(0, "You regain some experience from resurrection.");	
		else
			Message(15, "You gain experience!!");
		else
			Message(15, "You have lost experience.");
		int16 check_level = GetLevel()+1;
		
		while (set_exp >= GetEXPForLevel(check_level)) {
			check_level++;
			if (check_level > 100) { // Quagmire - this was happening because GetEXPForLevel returned 0 on unknown race/class combo, Changed it to return 0xFFFFFFFF on error
				check_level = GetLevel()+1;
				break;
			}
		}
		while (set_exp < GetEXPForLevel(check_level-1)) {
			check_level--;
			if (check_level < 2) {
				check_level = 2;
				break;
			}
		}
		
		if (set_aaxp >= max_AAXP) {
			int last_unspentAA = pp.aapoints;
			pp.aapoints = set_aaxp / max_AAXP;
			set_aaxp = set_aaxp - (max_AAXP * pp.aapoints);
			if(set_aaxp <=0) {
				set_aaxp = 0;
			}
			pp.expAA = set_aaxp;
			//pp.aapoints += set_aaxp / max_AAXP;
			pp.aapoints += last_unspentAA;
			set_aaxp = pp.expAA % max_AAXP;
			Message(15, "You have gained %d skill points!!", pp.aapoints - last_unspentAA);
			Message(15, "You now have %d skill points available to spend.", pp.aapoints);
		}
		
		pp.expAA = set_aaxp;
		
		if ((GetLevel() != check_level-1) && !(check_level-1 >= 66)) {
			if (GetLevel() == check_level-2)
				Message(15, "You have gained a level! Welcome to level %i!", check_level-1);
			else if (GetLevel() == check_level)
				Message(15, "You lost a level! You are now level %i!", check_level-1);
			else
				Message(15, "Welcome to level %i!", check_level-1);
			pp.exp = set_exp;	
			SetLevel(check_level-1);
			UpdateWho();
		}
		else {
			APPLAYER app;
			app.opcode = OP_ExpUpdate;
			app.size = sizeof(ExpUpdate_Struct);
			app.pBuffer = new uchar[app.size];
			ExpUpdate_Struct* eu = (ExpUpdate_Struct*)app.pBuffer;
			eu->exp = ((int)((float)330/(GetEXPForLevel(GetLevel()+1)-GetEXPForLevel(GetLevel()))) * (set_exp-GetEXPForLevel(GetLevel())));
			QueuePacket(&app);
			pp.exp = set_exp;
		}
		SendAAStats();
		if (admin>=100) {
			Message(15, "[GM] You now have %d / %d EXP and %d / %d AA exp.", set_exp, GetEXPForLevel(GetLevel()+1), set_aaxp, max_AAXP);
		}
}

void Client::MovePC(int32 zoneID, float x, float y, float z, bool ignorerestrictions, bool summoned) {
	MovePC(database.GetZoneName(zoneID), x, y, z, ignorerestrictions, summoned);
}

void Client::MovePC(const char* zonename, float x, float y, float z, bool ignorerestrictions, bool summoned) {
	if (this->isgrouped && entity_list.GetGroupByClient(this) != 0)	
		entity_list.GetGroupByClient(this)->DelMember(this);
	zonesummon_ignorerestrictions = ignorerestrictions;
	
	APPLAYER* outapp = new APPLAYER;
	if(summoned==true) {
		outapp->opcode = OP_GMSummon;
	}
	else {
		outapp->opcode = OP_GMGoto;
	}
	outapp->size = sizeof(GMSummon_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	GMSummon_Struct* gms = (GMSummon_Struct*) outapp->pBuffer;
	strcpy(gms->charname, this->GetName());
	strcpy(gms->gmname, this->GetName());
	if (zonename == 0)
		gms->zoneID = zone->GetZoneID();
	else {
		gms->zoneID = database.GetZoneID(zonename);
		//if (strcasecmp(zonename, zone->GetShortName()) != 0) {
		strcpy(zonesummon_name, zonename);
		zonesummon_x = x;
		zonesummon_y = y;
		zonesummon_z = z;
		//}
	}
	gms->x = (sint32) x;
	gms->y = (sint32) y;
	gms->z = (sint32) z;
	/*int8 tmp[16] = { 0x7C, 0xEF, 0xFC, 0x0F, 0x80, 0xF3, 0xFC, 0x0F, 0xA9, 0xCB, 0x4A, 0x00, 0x7C, 0xEF, 0xFC, 0x0F };
	memcpy(gms->unknown2, tmp, 16);
	int8 tmp2[4] = { 0xE0, 0xE0, 0x56, 0x00 };
	memcpy(gms->unknown3, tmp2, 4);*/
	QueuePacket(outapp);
	delete outapp;
}


void Client::SetLevel(int8 set_level, bool command)
{
	if (GetEXPForLevel(set_level) == 0xFFFFFFFF) {
		cout << "Error in SetLevel" << endl;
		return;
	}
	
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_LevelUpdate;
	outapp->size = sizeof(LevelUpdate_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer,0,outapp->size); // no memset = BAD -kathgar
	LevelUpdate_Struct* lu = (LevelUpdate_Struct*)outapp->pBuffer;
	lu->level = set_level;
	lu->level_old = level;
	level = set_level;
	
	if(set_level > pp.level) // Yes I am aware that you could delevel yourself and relevel this is just to test!
		pp.points += 5;
	
	pp.level = set_level;
	if (command){
		pp.exp = GetEXPForLevel(set_level);	
		Message(15, "Welcome to level %i!", set_level);
		lu->exp = 0;
	}
	else
		lu->exp = ((int)((float)330/(GetEXPForLevel(GetLevel()+1)-GetEXPForLevel(GetLevel()))) * (pp.exp-GetEXPForLevel(GetLevel())));
	QueuePacket(outapp);
	delete outapp;
	this->SendAppearancePacket(0x01, set_level); // who level change
	
	cout << "Setting Level: " << GetName() << " = " << (int16) set_level << endl;
	
	SetHP(CalcMaxHP());		// Why not, lets give them a free heal
	SendHPUpdate();
	SetMana(CalcMaxMana());
	UpdateWho();
	//	ChannelMessageSend(0, 0, 7, 0, "Your level changed, please check if your max hp is %i. If not do a bug report with class, level, stamina and max hp", GetMaxHP());
}
//                           hum       bar    eru     elf     hie     def     hef     dwa     tro     ogr     hal    gno     iks,    vah
float  race_modifiers[14] =  {100.0f, 105.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 120.0f, 115.0f, 95.0f, 100.0f, 120.0f, 100.0f}; // Quagmire - Guessed on iks and vah
//                           war  cle  pal  ran  shd  dru  mnk  brd  rog  shm  nec  wiz  mag  enc bst
float class_modifiers[15] = { 9.0f, 10.0f, 14.0f, 14.0f, 14.0f, 10.0f, 12.0f, 14.0f, 9.05f, 10.0f, 11.0f, 11.0f, 11.0f, 11.0f, 10.0f};

/*
Note: The client calculates exp separatly, we cant change this function
Add: You can set the values you want now, client will be always sync :) - Merkur
*/
uint32 Client::GetEXPForLevel(int16 check_level)
{
	int8 tmprace = GetBaseRace();
	if (tmprace == IKSAR) // Quagmire, set these up so they read from array right
		tmprace = 12;
	else if (tmprace == VAHSHIR)
		tmprace = 13;
	
	tmprace -= 1;
	if (tmprace > 14 || GetClass() < 1 || GetClass() > 15)
		return 0xFFFFFFFF;
	
	if (check_level < 31)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]);
	else if (check_level < 36)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.1);
	else if (check_level < 41)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.2);
	else if (check_level < 46)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.3);
	else if (check_level < 52)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.4);
	else if (check_level < 53)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.5);
	else if (check_level < 54)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.6);
	else if (check_level < 55)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.7);
	else if (check_level < 56)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.9);
	else if (check_level < 57)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.1);
	else if (check_level < 58)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.3);
	else if (check_level < 59)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.5);
	else if (check_level < 60)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.7);
	else if (check_level < 61)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.0);
	else
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.1);
}

sint32 Client::CalcMaxHP() {
	max_hp = (CalcBaseHP() + itembonuses->HP + spellbonuses->HP);
	if (cur_hp > max_hp)
		cur_hp = max_hp;
	return max_hp;
}

/*
Note: The client calculates max hp separatly, we cant change this function
*/
sint32 Client::CalcBaseHP()
{
	int multiplier=GetClassLevelFactor();
	
	
	if (multiplier == 0)
	{
		cerr << "Multiplier == 0 in Client::CalcBaseHP" << endl;
	}
	
	//	cout << "m:" << (int)multiplier << " l:" << (int)GetLevel() << " s:" << (int)GetSTA() << endl;
	
	base_hp = 5+multiplier*GetLevel()+multiplier*GetLevel()*GetSTA()/300;
	return base_hp;
}

int8 Client::GetSkill(int skill_num)
{
	return pp.skills[skill_num];
}

/* 
Added 12-29-01 -socket
*/
void Client::SetSkill(int skillid, int8 value)
{
	if(value <= 252)
	{
		pp.skills[skillid] = value;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_SkillUpdate;
		outapp->size = sizeof(SkillUpdate_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, sizeof(outapp->size));
		SkillUpdate_Struct* skill = (SkillUpdate_Struct*)outapp->pBuffer;
		skill->skillId=skillid;
		skill->value=value;
		QueuePacket(outapp);
		delete outapp;
	}
}

void Client::AddSkill(int skillid, int8 value) {
	value = pp.skills[skillid] + value;
	if (value > 252) value = 252;
	SetSkill(skillid, value);
}

/*
This should return the combined AC of all the items the player is wearing.
*/
int16 Client::GetRawItemAC() {
	const Item_Struct* TempItem;
	int16 Total = 0;
	
	for(int x=0; x<=20; x++) {
		TempItem = database.GetItem(pp.inventory[x]);
		if (TempItem)
			Total += TempItem->common.AC;
	}
	
	return Total;
}

/*
This is a testing formula for AC, the value this returns should be the same value as the one the client shows...
ac1 and ac2 are probably the damage migitation and damage avoidance numbers, not sure which is which.
I forgot to include the iksar defense bonus and i cant find my notes now...
AC from spells are not included (cant even cast spells yet..)
*/
int16 Client::GetCombinedAC_TEST() {
	int ac1;
	
	ac1 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER) {
		ac1 = ac1*4/3;
	}
	ac1 += GetSkill(DEFENSE)/3;
	if (GetAGI() > 70)
	{
		ac1 += GetAGI()/20;
	}
	
	int ac2;
	
	ac2 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
		
	{
		ac2 = ac2*4/3;
	}
	ac2 += GetSkill(DEFENSE)*400/255;
	
	
	int combined_ac = (ac1+ac2)*1000/847;
	
	return combined_ac;
}

void Client::UpdateWho(bool remove) {
	if (account_id == 0)
		return;
	if (!worldserver.Connected())
		return;
	ServerPacket* pack = new ServerPacket(ServerOP_ClientList, sizeof(ServerClientList_Struct));
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = remove;
	strcpy(scl->name, this->GetName());
	scl->Admin = this->Admin();
	scl->AccountID = this->AccountID();
	strcpy(scl->AccountName, this->AccountName());
	scl->LSAccountID = this->LSAccountID();
	strcpy(scl->zone, zone->GetShortName());
	scl->race = this->GetRace();
	scl->class_ = GetClass();
	scl->level = GetLevel();
	if (pp.anon == 0)
		scl->anon = 0;
	else if (pp.anon == 1)
		scl->anon = 1;
	else if (pp.anon >= 2)
		scl->anon = 2;
	scl->tellsoff = tellsoff;
	scl->guilddbid = guilddbid;
	scl->guildeqid = guildeqid;
	scl->LFG = LFG;
	
	worldserver.SendPacket(pack);
	delete pack;
}

// Zone client to spot specified, cords all = 0xFFFF for safe point
/*void Client::MovePC(char* zonename, sint16 x, sint16 y, sint16 z) {
zonesummon_x = x;
zonesummon_y = y;
zonesummon_z = z;
APPLAYER* outapp = new APPLAYER;
outapp->opcode = OP_Translocate;
outapp->size = 88;
outapp->pBuffer = new uchar[outapp->size];
memset(outapp->pBuffer, 0, outapp->size);
if (zonename == 0)
strcpy((char*) outapp->pBuffer, zone->GetShortName());
else
strcpy((char*) outapp->pBuffer, zonename);
int8 tmp[68] = {
0x10, 0xd2, 0x3f, 0x04, 0x86, 0xf3, 0xc4, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xec, 0x46, 0x00, 0xa0, 0xa0, 0x6d, 0x0d,
0x80, 0x15, 0xd5, 0x06, 0xf4, 0xd2, 0xd2, 0x0c, 0xf5, 0x20, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
0x04, 0x00, 0x00, 0x00, 0xf4, 0xca, 0x84, 0x08, 0x00, 0x00, 0xfa, 0xc6, 0x00, 0x00, 0xfa, 0xc6,
0x00, 0x00, 0xfa, 0xc6 };
memcpy(&outapp->pBuffer[16], tmp, 68);

  outapp->pBuffer[84] = 1;
  QueuePacket(outapp);
  delete outapp;
}*/

void Client::WhoAll(Who_All_Struct* whom) {
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_Who;
		pack->size = sizeof(ServerWhoAll_Struct);
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, sizeof(pack->pBuffer));
		ServerWhoAll_Struct* whoall = (ServerWhoAll_Struct*) pack->pBuffer;
		whoall->admin = (int8) admin;
		strcpy(whoall->from, this->GetName());
		strcpy(whoall->whom, whom->whom);
		whoall->firstlvl = whom->firstlvl;
		whoall->gmlookup = whom->gmlookup;
		whoall->secondlvl = whom->secondlvl;
		whoall->wclass = whom->wclass;
		whoall->wrace = whom->wrace;
		worldserver.SendPacket(pack);
		delete pack;
	}
}

bool Client::SetGuild(int32 in_guilddbid, int8 in_rank) {
	if (in_guilddbid == 0) {
		// update DB
		if (!database.SetGuild(character_id, 0, GUILD_MAX_RANK))
			return false;
		// clear guildtag
		guilddbid = in_guilddbid;
		guildeqid = 0xFFFFFFFF;
		guildrank = GUILD_MAX_RANK;
		SendAppearancePacket(22, 0xFFFFFFFF);
		SendAppearancePacket(23, 3);
		UpdateWho();
		return true;
	}
	else {
		int32 tmp = database.GetGuildEQID(in_guilddbid);
		if (tmp != 0xFFFFFFFF) {
			if (!database.SetGuild(character_id, in_guilddbid, in_rank))
				return false;
			guildeqid = tmp;
			guildrank = in_rank;
			if (guilddbid != in_guilddbid) {
				guilddbid = in_guilddbid;
				SendAppearancePacket(22, guildeqid);
			}
			
			if (guilds[tmp].rank[in_rank].warpeace || guilds[tmp].leader == account_id)
				SendAppearancePacket(23, 2);
			else if (guilds[tmp].rank[in_rank].invite || guilds[tmp].rank[in_rank].remove || guilds[tmp].rank[in_rank].motd)
				SendAppearancePacket(23, 1);
			else
				SendAppearancePacket(23, 0);
			UpdateWho();
			return true;
		}
	}
	UpdateWho();
	return false;
}

void Client::GuildCommand(Seperator* sep) {
	if (strcasecmp(sep->arg[1], "help") == 0) {
		Message(0, "Guild commands:");
		Message(0, "  #guild status [name] - shows guild and rank of target");
		Message(0, "  #guild info guildnum - shows info/current structure");
		Message(0, "  #guild invite [charname]");
		Message(0, "  #guild remove [charname]");
		Message(0, "  #guild promote charname rank");
		Message(0, "  #guild demote charname rank");
		Message(0, "  /guildmotd [newmotd]    (use 'none' to clear)");
		Message(0, "  #guild edit rank title newtitle");
		Message(0, "  #guild edit rank permission 0/1");
		Message(0, "  #guild leader newleader (they must be rank0)");
		if (admin >= 100) {
			Message(0, "GM Guild commands:");
			Message(0, "  #guild list - lists all guilds on the server");
			Message(0, "  #guild create {guildleader charname or AccountID} guildname");
			Message(0, "  #guild delete guildDBID");
			Message(0, "  #guild rename guildDBID newname");
			Message(0, "  #guild set charname guildDBID    (0=no guild)");
			Message(0, "  #guild setrank charname rank");
			Message(0, "  #guild gmedit guilddbid rank title newtitle");
			Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			Message(0, "  #guild setleader guildDBID {guildleader charname or AccountID}");
			Message(0, "  #guild setdoor guildEQID");
		}
		
	}
	else if (strcasecmp(sep->arg[1], "status") == 0 || strcasecmp(sep->arg[1], "stat") == 0) {
		Client* client = 0;
		if (sep->arg[2][0] != 0)
			client = entity_list.GetClientByName(sep->argplus[2]);
		else if (target != 0 && target->IsClient())
			client = target->CastToClient();
		if (client == 0)
			Message(0, "You must target someone or specify a character name");
		else if ((client->Admin() >= 100 && admin < 100) && client->GuildDBID() != guilddbid) // no peeping for GMs, make sure tell message stays the same
			Message(0, "You must target someone or specify a character name.");
		else {
			if (client->GuildDBID() == 0)
				Message(0, "%s is not in a guild.", client->GetName());
			else if (guilds[client->GuildEQID()].leader == client->AccountID())
				Message(0, "%s is the leader of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
			else
				Message(0, "%s is a member of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
		}
	}
	else if (strcasecmp(sep->arg[1], "info") == 0) {
		if (sep->arg[2][0] == 0 && guilddbid == 0)
			if (admin >= 100)
				Message(0, "Usage: #guildinfo guilddbid");
			else
				Message(0, "You're not in a guild");
			else {
				int32 tmp;
				if (sep->arg[2][0] == 0)
					tmp = database.GetGuildEQID(guilddbid);
				else
					tmp = database.GetGuildEQID(atoi(sep->arg[2]));
				if (tmp < 0 || tmp >= 512)
					Message(0, "Guild not found.");
				else {
					database.GetGuildRanks(tmp, &guilds[tmp]);
					Message(0, "Guild info DB# %i, %s", guilds[tmp].databaseID, guilds[tmp].name);
					if (admin >= 100 || guildeqid == tmp) {
						if (account_id == guilds[tmp].leader || guildrank == 0 || admin >= 100) {
							char leadername[64];
							database.GetAccountName(guilds[tmp].leader, leadername);
							Message(0, "Guild Leader: %s", leadername);
						}
						Message(0, "Rank 0: %s", guilds[tmp].rank[0].rankname);
						Message(0, "  All Permissions.");
						for (int i = 1; i <= GUILD_MAX_RANK; i++) {
							Message(0, "Rank %i: %s", i, guilds[tmp].rank[i].rankname);
							Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove, guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
							//						Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove);
							//						Message(0, "  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
						}
					}
				}
			}
	}
	else if (strcasecmp(sep->arg[1], "leader") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (guilds[guildeqid].leader != account_id)
			Message(0, "You aren't the guild leader.");
		else {
			const char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "invite") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].invite)
			Message(0, "You dont have permission to invite.");
		else {
			const char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "remove") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if ((!guilds[guildeqid].rank[guildrank].remove) && !(target == this && sep->arg[2][0] == 0))
			Message(0, "You dont have permission to remove.");
		else {
			const char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildRemove;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "promote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep->arg[2]) == 1 && sep->arg[2][0] >= '0' && sep->arg[2][0] <= '9'))
			Message(0, "Usage: #guild promote rank [charname]");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			const char* tmptar = 0;
			if (sep->arg[3][0] != 0)
				tmptar = sep->argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildPromote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep->arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "demote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep->arg[2]) == 1 && sep->arg[2][0] >= '0' && sep->arg[2][0] <= '9'))
			Message(0, "Usage: #guild demote rank [charname]");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			const char* tmptar = 0;
			if (sep->arg[3][0] != 0)
				tmptar = sep->argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildDemote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep->arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "motd") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].motd)
			Message(0, "You dont have permission to change the motd.");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			char tmp[255];
			if (strcasecmp(sep->argplus[2], "none") == 0)
				strcpy(tmp, "");
			else
				snprintf(tmp, sizeof(tmp), "%s - %s", this->GetName(), sep->argplus[2]);
			if (database.SetGuildMOTD(guilddbid, tmp)) {
			/*
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_RefreshGuild;
			pack->size = 5;
			pack->pBuffer = new uchar[pack->size];
			memcpy(pack->pBuffer, &guildeqid, 4);
			worldserver.SendPacket(pack);
			delete pack;
				*/
			}
			else {
				Message(0, "Motd update failed.");
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "edit") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!sep->IsNumber(2))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (!guildrank == 0)
			Message(0, "You must be rank %s to use edit.", guilds[guildeqid].rank[0].rankname);
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			if (!GuildEditCommand(guilddbid, guildeqid, atoi(sep->arg[2]), sep->arg[3], sep->argplus[4])) {
				Message(0, "  #guild edit rank title newtitle");
				Message(0, "  #guild edit rank permission 0/1");
			}
			
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &guildeqid, 4);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "gmedit") == 0 && admin >= 100) {
		if (!sep->IsNumber(2))
			Message(0, "Error: invalid guilddbid.");
		else if (!sep->IsNumber(3))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep->arg[3]) < 0 || atoi(sep->arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 eqid = database.GetGuildEQID(atoi(sep->arg[2]));
			if (eqid == 0xFFFFFFFF)
				Message(0, "Error: Guild not found");
			else if (!GuildEditCommand(atoi(sep->arg[2]), eqid, atoi(sep->arg[3]), sep->arg[4], sep->argplus[5])) {
				Message(0, "  #guild gmedit guilddbid rank title newtitle");
				Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			}
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &eqid, 4);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "set") == 0 && admin >= 100) {
		if (!sep->IsNumber(3))
			Message(0, "Usage: #guild set charname guildgbid (0 = clear guildtag)");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSet;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->guilddbid = atoi(sep->arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep->arg[2]);
			worldserver.SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep->arg[1], "setdoor") == 0 && admin >= 100) {
		if (!sep->IsNumber(2))
			Message(0, "Usage: #guild setdoor guildEQid (0 = delete guilddoor)");
		else {
			if((!guilds[atoi(sep->arg[2])].databaseID) && (!atoi(sep->arg[2])) ){
				Message(0, "These is no guild with this guildEQid");
			}
			else
			{
				this->IsSettingGuildDoor = true;
				Message(0, "Click on a door you want to become a guilddoor");
				SetGuildDoorID = atoi(sep->arg[2]);
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "setrank") == 0 && admin >= 100) {
		if (!sep->IsNumber(3))
			Message(0, "Usage: #guild setrank charname rank");
		else if (atoi(sep->arg[3]) < 0 || atoi(sep->arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSetRank;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->newrank = atoi(sep->arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep->arg[2]);
			worldserver.SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep->arg[1], "create") == 0 && admin >= 100) {
		if (sep->arg[3][0] == 0)
			Message(0, "Usage: #guild create {guildleader charname or AccountID} guild name");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep->IsNumber(2))
				leader = atoi(sep->arg[2]);
			else
				leader = database.GetAccountIDByChar(sep->arg[2]);
			
			int32 tmp = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "Guild leader not found.");
			else if (tmp != 0) {
				int32 tmp2 = database.GetGuildEQID(tmp);
				Message(0, "Error: %s already is the leader of DB# %i '%s'.", sep->arg[2], tmp, guilds[tmp2].name);
			}
			else {
				int32 tmpeq = database.CreateGuild(sep->argplus[3], leader);
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild creation failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					database.GetGuildRanks(tmpeq, &guilds[tmpeq]);
					Message(0, "Guild created: Leader: %i, DB# %i, EQ# %i: %s", leader, guilds[tmpeq].databaseID, tmpeq, sep->argplus[3]);
				}
				
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "delete") == 0 && admin >= 100) {
		if (!sep->IsNumber(2))
			Message(0, "Usage: #guild delete guildDBID");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
			char tmpname[64];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);
			
			if (!database.DeleteGuild(atoi(sep->arg[2])))
				Message(0, "Guild delete failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild deleted: DB# %i, EQ# %i: %s", atoi(sep->arg[2]), tmpeq, tmpname);
				} else
					Message(0, "Guild deleted: DB# %i", atoi(sep->arg[2]));
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "rename") == 0 && admin >= 100) {
		if ((!sep->IsNumber(2)) || sep->arg[3][0] == 0)
			Message(0, "Usage: #guild rename guildDBID newname");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
			char tmpname[64];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);
			
			if (!database.RenameGuild(atoi(sep->arg[2]), sep->argplus[3]))
				Message(0, "Guild rename failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild renamed: DB# %i, EQ# %i, OldName: %s, NewName: %s", atoi(sep->arg[2]), tmpeq, tmpname, sep->argplus[3]);
				} else
					Message(0, "Guild renamed: DB# %i, NewName: %s", atoi(sep->arg[2]), sep->argplus[3]);
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "setleader") == 0 && admin >= 100) {
		if (sep->arg[3][0] == 0 || !sep->IsNumber(2))
			Message(0, "Usage: #guild setleader guilddbid {guildleader charname or AccountID}");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep->IsNumber(3))
				leader = atoi(sep->arg[3]);
			else
				leader = database.GetAccountIDByChar(sep->argplus[3]);
			
			int32 tmpdb = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "New leader not found.");
			else if (tmpdb != 0) {
				int32 tmpeq = database.GetGuildEQID(tmpdb);
				if (tmpeq >= 512)
					Message(0, "Error: %s already is the leader of DB# %i.", sep->argplus[3], tmpdb);
				else
					Message(0, "Error: %s already is the leader of DB# %i <%s>.", sep->argplus[3], tmpdb, guilds[tmpeq].name);
			}
			else {
				int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild not found.");
				else if (!database.SetGuildLeader(atoi(sep->arg[2]), leader))
					Message(0, "Guild leader change failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild leader changed: DB# %s, Leader: %s, Name: <%s>", sep->arg[2], sep->argplus[3], guilds[tmpeq].name);
				}
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "list") == 0 && admin >= 100) {
		int x = 0;
		Message(0, "Listing guilds on the server:");
		char leadername[64];
		for (int i = 0; i < 512; i++) {
			if (guilds[i].databaseID != 0) {
				leadername[0] = 0;
				database.GetAccountName(guilds[i].leader, leadername);
				if (leadername[0] == 0)
					Message(0, "  DB# %i EQ# %i  <%s>", guilds[i].databaseID, i, guilds[i].name);
				else
					Message(0, "  DB# %i EQ# %i  <%s> Leader: %s", guilds[i].databaseID, i, guilds[i].name, leadername);
				x++;
			}
		}
		Message(0, "%i guilds listed.", x);
	}
	else {
		Message(0, "Unknown guild command, try #guild help");
	}
}

bool Client::GuildEditCommand(int32 dbid, int32 eqid, int8 rank, const char* what, const char* value) {
	struct GuildRankLevel_Struct grl;
	strcpy(grl.rankname, guilds[eqid].rank[rank].rankname);
	grl.demote = guilds[eqid].rank[rank].demote;
	grl.heargu = guilds[eqid].rank[rank].heargu;
	grl.invite = guilds[eqid].rank[rank].invite;
	grl.motd = guilds[eqid].rank[rank].motd;
	grl.promote = guilds[eqid].rank[rank].promote;
	grl.remove = guilds[eqid].rank[rank].remove;
	grl.speakgu = guilds[eqid].rank[rank].speakgu;
	grl.warpeace = guilds[eqid].rank[rank].warpeace;
	
	if (strcasecmp(what, "title") == 0) {
		if (strlen(value) > 100)
			Message(0, "Error: Title has a maxium length of 100 characters.");
		else
			strcpy(grl.rankname, value);
	}
	else if (rank == 0)
		Message(0, "Error: Rank 0's permissions can not be changed.");
	else {
		if (!(strlen(value) == 1 && (value[0] == '0' || value[0] == '1')))
			return false;
		if (strcasecmp(what, "demote") == 0)
			grl.demote = (value[0] == '1');
		else if (strcasecmp(what, "heargu") == 0)
			grl.heargu = (value[0] == '1');
		else if (strcasecmp(what, "invite") == 0)
			grl.invite = (value[0] == '1');
		else if (strcasecmp(what, "motd") == 0)
			grl.motd = (value[0] == '1');
		else if (strcasecmp(what, "promote") == 0)
			grl.promote = (value[0] == '1');
		else if (strcasecmp(what, "remove") == 0)
			grl.remove = (value[0] == '1');
		else if (strcasecmp(what, "speakgu") == 0)
			grl.speakgu = (value[0] == '1');
		else if (strcasecmp(what, "warpeace") == 0)
			grl.warpeace = (value[0] == '1');
		else
			Message(0, "Error: Permission name not recognized.");
	}
	if (!database.EditGuild(dbid, rank, &grl))
		Message(0, "Error: database.EditGuild() failed");
	return true;
}

sint32 Client::CalcMaxMana()
{
	switch(GetCasterClass())
	{
	case 'I': {
		max_mana = (((GetINT()/5)+2) * GetLevel()) + spellbonuses->Mana + itembonuses->Mana;
		break;
			  }
	case 'W': {
		max_mana = (((GetWIS()/5)+2) * GetLevel()) + spellbonuses->Mana + itembonuses->Mana;
		break;
			  }
	case 'N': {
		max_mana = 0;
		break;
			  } 		default:
			  {
				  cerr << "Invalid Class in CalcMaxMana" << endl;
				  max_mana = 0;
				  break;
			  }
	}
	if (cur_mana > max_mana) {
		cur_mana = max_mana;
		SendManaUpdatePacket();
	}
	return max_mana;
}


void Client::UpdateAdmin() {
	admin = database.CheckStatus(account_id);
	UpdateWho();
	
	if (admin >= 100)
		SendAppearancePacket(20, 1);
	else
		SendAppearancePacket(20, 0);
}

void Client::FindItem(const char* search_criteria) {
	int count=0;
	//int iSearchLen = strlen(search_criteria)+1;
	char sName[36];
	char sCriteria[255];
	
	strncpy(sCriteria, search_criteria,100);
	strupr(sCriteria);
	const Item_Struct* item = 0;
	char* pdest;
	for (int32 i=0; i < database.GetMaxItem(); i++) {
		item = database.GetItem(i);
		if (item) {
			strcpy(sName, item->name);
			strupr(sName);
			
			pdest = strstr(sName, sCriteria);
			if (pdest != NULL) {
				Message(0, "  %i: %s", (int) item->item_nr, item->name);
				count++;
			}
			if (count == 20) {
				break;
			}
		}
	}
	if (count == 20)
		Message(0, "20 items shown...too many results.");
	else
		Message(0, "%i items found", count);
}

void Client::SummonItem(int16 item_id, sint8 charges) {
	const Item_Struct* item = database.GetItem(item_id);
	if (item == 0) {
		Message(0, "No such item: %i", item_id);
	}
	else {
		pp.inventory[0] = item_id;
		if (charges == 0){
			if (item->common.effecttype == 0)
				charges = 1;
			else
				charges = (item->common.charges == 0 || item->common.charges == 1) ? 255:charges = item->common.charges;
		}
		//	cout << "effect: " << (int16)item->common.effecttype  << endl;
		pp.invitemproperties[0].charges = charges;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_SummonedItem;
		outapp->size = sizeof(SummonedItem_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer,0,outapp->size);
		memcpy(outapp->pBuffer, item, sizeof(Item_Struct));
		Item_Struct* item2 = (Item_Struct*) outapp->pBuffer;
		item2->equipSlot = 0;
		if (item->flag != 0x7669)
			item2->common.charges = charges;
		// This is so GM+ can trade anything to anybody...:)
		// (Marking everything Droppable
		if (this->Admin() >= 100)
			item2->nodrop = 1;
		QueuePacket(outapp);
		delete outapp;
	}
}

sint32 Client::SetMana(sint32 amount) {
	Mob::SetMana(amount);
	SendManaUpdatePacket();
	return cur_mana;
}

void Client::SendManaUpdatePacket() {
	if (!Connected())
		return;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ManaChange;
	outapp->size = sizeof(ManaChange_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer,0,outapp->size); // no memset = BAD -kathgar
	ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
	manachange->new_mana = cur_mana;
	manachange->spell_id = 0;
	QueuePacket(outapp);
	delete outapp;
}

void Client::FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho)
{
	Mob::FillSpawnStruct(ns, ForWho);
	
	if (guildeqid == 0xFFFFFFFF) {
		ns->spawn.GuildID = 0xFFFF;
		ns->spawn.guildrank = -1;
	}
	else {
		ns->spawn.GuildID = guildeqid;
		if (guilds[guildeqid].rank[guildrank].warpeace || guilds[guildeqid].leader == account_id)
			ns->spawn.guildrank = 2;
		else if (guilds[guildeqid].rank[guildrank].invite || guilds[guildeqid].rank[guildrank].remove || guilds[guildeqid].rank[guildrank].motd)
			ns->spawn.guildrank = 1;
		else
			ns->spawn.guildrank = 0;
	}
	if (ForWho == this)
		ns->spawn.NPC = 10;
	else
		ns->spawn.NPC = 0;
	//	ns->spawn.not_linkdead = 1;
	
	if (pp.gm==1)
		ns->spawn.GM = 1;
	if (pp.pvp == 1)
		ns->spawn.pvp = 1;
	ns->spawn.anon = pp.anon;
	if (IsBecomeNPC() == true)
		ns->spawn.NPC=true;
	ns->spawn.npc_armor_graphic = texture;
	ns->spawn.npc_helm_graphic = helmtexture;
	
	const Item_Struct* item = 0;
	item = database.GetItem(pp.inventory[2]);
	if (item != 0) {
		ns->spawn.equipment[0] = item->common.material;
		ns->spawn.equipcolors[0] = item->common.color;
	}
	item = database.GetItem(pp.inventory[17]);
	if (item != 0) {
		ns->spawn.equipment[1] = item->common.material;
		ns->spawn.equipcolors[1] = item->common.color;
	}
	item = database.GetItem(pp.inventory[7]);
	if (item != 0) {
		ns->spawn.equipment[2] = item->common.material;
		ns->spawn.equipcolors[2] = item->common.color;
	}
	item = database.GetItem(pp.inventory[10]);
	if (item != 0) {
		ns->spawn.equipment[3] = item->common.material;
		ns->spawn.equipcolors[3] = item->common.color;
	}
	item = database.GetItem(pp.inventory[12]);
	if (item != 0) {
		ns->spawn.equipment[4] = item->common.material;
		ns->spawn.equipcolors[4] = item->common.color;
	}
	item = database.GetItem(pp.inventory[18]);
	if (item != 0) {
		ns->spawn.equipment[5] = item->common.material;
		ns->spawn.equipcolors[5] = item->common.color;
	}
	item = database.GetItem(pp.inventory[19]);
	if (item != 0) {
		ns->spawn.equipment[6] = item->common.material;
		ns->spawn.equipcolors[6] = item->common.color;
	}
	
	item = database.GetItem(pp.inventory[13]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[7] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[7] = 0;
		}
		ns->spawn.equipcolors[7] = 0;
	}
	item = database.GetItem(pp.inventory[14]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[8] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[8] = 0;
		}
		ns->spawn.equipcolors[8] = 0;
	}
	ns->spawn.haircolor = pp.haircolor;
	ns->spawn.beardcolor = pp.beardcolor;
	ns->spawn.eyecolor1 = pp.eyecolor1;
	ns->spawn.eyecolor2 = pp.eyecolor2;
	ns->spawn.hairstyle = pp.hairstyle;
	ns->spawn.title = pp.title;
	ns->spawn.luclinface = pp.luclinface;
}

int16 Client::GetItemAt(int16 in_slot) {
	if (in_slot <= 29) // Worn items and main inventory
		return pp.inventory[in_slot];
	else if (in_slot >= 250 && in_slot <= 329) // Main inventory's containers
		return pp.containerinv[in_slot-250];
	else if (in_slot >= 2000 && in_slot <= 2007) // Bank slots
		return pp.bank_inv[in_slot-2000];
	else if (in_slot >= 2030 && in_slot <= 2109) // Bank's containers
		return pp.bank_cont_inv[in_slot-2030];
	else {
		cerr << "Error: " << GetName() << ": GetItemAt(): Unknown slot: 0x" << hex << setw(4) << setfill('0') << in_slot << dec << endl;
		Message(0, "Error: GetItemAt(): Unknown slot: 0x%04x", in_slot);
	}
	return 0;
}

void Client::DeleteItemInInventory(uint32 slotid, bool clientupdate) {
	if (slotid <= 29){ // Worn items and main inventory
		pp.inventory[slotid] = 0xFFFF;
		pp.invitemproperties[slotid].charges = 0;
	}
	else if (slotid >= 250 && slotid <= 329){ // Main inventory's containers
		pp.containerinv[slotid-250] = 0xFFFF;
		pp.bagitemproperties[slotid].charges = 0;
	}
	else if (slotid >= 2000 && slotid <= 2007){ // Bank slots
		pp.bank_inv[slotid-2000] = 0xFFFF;
		pp.bankinvitemproperties[slotid].charges = 0;
	}
	else if (slotid >= 2030 && slotid <= 2109){ // Bank's containers
		pp.bank_cont_inv[slotid-2030] =0xFFFF;
		pp.bankbagitemproperties[slotid].charges = 0;
	}
	else {
		cout << "Error in DeleteItemInInventory : Unknown slot" << endl;
		return;
	}
	if (clientupdate){
		APPLAYER* outapp = new APPLAYER(OP_MoveItem, sizeof(MoveItem_Struct));
		MoveItem_Struct* delitem = (MoveItem_Struct*)outapp->pBuffer;
		delitem->from_slot = slotid;
		delitem->to_slot = 0xFFFFFFFF;
		delitem->number_in_stack = 0;
		//	DumpPacket(outapp);
		QueuePacket(outapp);
		delete outapp;
	}
	Save();	
}

bool Client::GMHideMe(Client* client) {
	if (gmhideme) {
		if (client == 0)
			return true;
		else if (admin > client->Admin())
			return true;
		else
			return false;
	}
	else
		
		return false;
	
}

void Client::Duck() {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa_out->spawn_id = GetID();
	sa_out->type = 0x0e;
	sa_out->parameter = 111; // duck
	entity_list.QueueClients(this, outapp);
	delete outapp;
	appearance = 2;
}

void Client::Stand() {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa_out->spawn_id = GetID();
	sa_out->type = 0x0e;
	sa_out->parameter = 100; // stand
	entity_list.QueueClients(this, outapp);
	delete outapp; 
	appearance = 0;
}

int16 Client::FindFreeInventorySlot(int16** pointer, bool ForBag, bool TryCursor) {
	int i;
	for (i=22; i<=29; i++) {
		if (pp.inventory[i] == 0xFFFF) {
			if (pointer != 0)
				*pointer = &pp.inventory[i];
			return i;
		}
	}
	if (!ForBag) {
		const Item_Struct* item;
		for (i=22; i<=29; i++) {
			item = database.GetItem(pp.inventory[i]);
			if (item != 0 && item->type == 0x01) { // make sure it's a container
				for (int k=0; k<10; k++) {
					if (pp.containerinv[((i-22)*10) + k] == 0xFFFF) {
						if (pointer != 0)
							*pointer = &pp.containerinv[((i-22)*10) + k];
						return 250 + ((i-22)*10) + k;
					}
				}
			}
		}
	}
	if (TryCursor) {
		if (pp.inventory[0] == 0xFFFF) {
			*pointer = &pp.inventory[0];
			return 0;
		}
	}
	return 0xFFFF;
}

bool Client::PutItemInInventory(int16 slotid, int16 itemid, sint8 charges) {
	const Item_Struct* item = database.GetItem(itemid);
	if (item == 0)
		return false;
	else
		return PutItemInInventory(slotid, item, charges);
}

bool Client::PutItemInInventory(int16 slotid, const Item_Struct* item)
{
	if (item->common.effecttype != 0)
		
		return PutItemInInventory(slotid, item, item->common.charges);
	else
		return PutItemInInventory(slotid, item, 1);
}

// Puts an item into the person's inventory
// Does NOT check if an item is already there
bool Client::PutItemInInventory(int16 slotid, const Item_Struct* item, sint8 charges) {
	if (slotid <= 29){
		pp.inventory[slotid] = item->item_nr;
		pp.invitemproperties[slotid].charges = charges;
	}
	else if (slotid >= 250 && slotid <= 329){
		pp.containerinv[slotid-250] = item->item_nr;
		pp.bagitemproperties[slotid].charges = charges;
	}
	else if (slotid >= 2000 && slotid <= 2007){
		pp.bank_inv[slotid-2000] = item->item_nr;
		pp.bankinvitemproperties[slotid].charges = charges;
	}
	else if (slotid >= 2030 && slotid <= 2109){
		pp.bank_cont_inv[slotid-2030] = item->item_nr;
		pp.bankbagitemproperties[slotid].charges = charges;
	}
	else
		return false;
	
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ItemTradeIn;
	outapp->size = sizeof(Item_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memcpy(outapp->pBuffer, item, outapp->size);
	Item_Struct* outitem = (Item_Struct*) outapp->pBuffer;
	outitem->equipSlot = slotid;
	//if (item->flag != 0x7669)
	outitem->common.charges = charges;
	QueuePacket(outapp);
	delete outapp;
	
	return true;
}
// works for stacks too, as long as they are not 0(1), use deleteitem then
void Client::DecreaseCharges(int16 slotid) { // does not check the slot, be sure that there IS an expandable item in this slot
	sint8 newcharges;
	int16 itemid;
	if (slotid <= 29){
		itemid = pp.inventory[slotid];
		if ((sint8)pp.invitemproperties[slotid].charges > 0){
			pp.invitemproperties[slotid].charges--;
			newcharges = pp.invitemproperties[slotid].charges;
		}
		else
			return;
	}
	else if (slotid >= 250 && slotid <= 329){
		itemid = pp.containerinv[slotid-250];
		if ((sint8)pp.bagitemproperties[slotid].charges > 0){
			pp.bagitemproperties[slotid].charges--;
			newcharges = pp.bagitemproperties[slotid].charges;
		}
		else
			return;
	}
	else if (slotid >= 2000 && slotid <= 2007){
		itemid = pp.bank_inv[slotid-2000];
		if ((sint8)pp.bankinvitemproperties[slotid].charges > 0){
			pp.bankinvitemproperties[slotid].charges--;
			newcharges =pp.bankinvitemproperties[slotid].charges;
		}
		else
			return;
	}
	else if (slotid >= 2030 && slotid <= 2109){
		itemid = pp.bank_cont_inv[slotid-2030];
		if ((sint8)pp.bankbagitemproperties[slotid].charges > 0){
			pp.bankbagitemproperties[slotid].charges--;
			newcharges = pp.bankbagitemproperties[slotid].charges;
		}
		else
			return;
	}
	else
		return;
	
	const Item_Struct* item = database.GetItem(itemid);
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ItemTradeIn;
	outapp->size = sizeof(Item_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memcpy(outapp->pBuffer, item, outapp->size);
	Item_Struct* outitem = (Item_Struct*) outapp->pBuffer;
	outitem->equipSlot = slotid;
	outitem->common.charges = newcharges;
	QueuePacket(outapp);
	delete outapp;
}

void Client::ChangeLastName(const char* in_lastname) {
	memset(pp.last_name, 0, sizeof(pp.last_name));
	if (strlen(in_lastname) >= sizeof(pp.last_name))
		strncpy(pp.last_name, in_lastname, sizeof(pp.last_name) - 1);
	else
		strcpy(pp.last_name, in_lastname);
	
	// Send name update packet here... once know what it is
}

void Client::ChangeFirstName(const char* oldname,const char* in_firstname,const char* gmname) {
	APPLAYER* outapp = new APPLAYER(OP_GMNameChange, sizeof(GMName_Struct));
	GMName_Struct* gmn=(GMName_Struct*)outapp->pBuffer;
	strncpy(gmn->gmname,gmname,64);
	strncpy(gmn->oldname,oldname,64);	
	strncpy(gmn->newname,in_firstname,64);
	
	bool usedname = database.CheckUsedName((char*) in_firstname);
	if (!usedname) {
		return;
	}
	
	UpdateWho();
	database.UpdateName(oldname, in_firstname);
	Save();
	
	memset(pp.name, 0, sizeof(pp.name));
	if (strlen(in_firstname) >= sizeof(pp.name))
		strncpy(pp.name, in_firstname, sizeof(pp.name) - 1);
	else
		strcpy(pp.name, in_firstname);
	
	gmn->unknown[0] = 1;
	gmn->unknown[1] = 1;
	gmn->unknown[2] = 1;
	entity_list.QueueClients(CastToMob(), outapp, false);
	UpdateWho();
}

char Client::GetCasterClass() {
	switch(class_)
	{
	case CLERIC:
	case PALADIN:
	case RANGER:
	case DRUID:
	case SHAMAN:
	case BEASTLORD:
		return 'W';
		break;
		
	case SHADOWKNIGHT:
	case BARD:
	case NECROMANCER:
	case WIZARD:
	case MAGICIAN:
	case ENCHANTER:
		return 'I';
		break;
		
	default:
		return 'N';
		break;
	}
}

void Client::SetGM(bool toggle) {
	if(toggle) {
		pp.gm=1;
		SendAppearancePacket(20, 1);
		Save();
		Message(13, "You are now a GM.");
	}
	else {
		pp.gm=0;
		SendAppearancePacket(20, 0);
		Save();
		Message(13, "You are no longer a GM.");
	}
}

void Client::ReadBook(char txtfile[14]) {
	char* booktxt = database.GetBook(txtfile);
	if (booktxt != 0) {
		cout << "Just Sent Book for: " << txtfile << " Text: " << booktxt << endl;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_ReadBook;
		outapp->size = strlen(booktxt)+4;
		outapp->pBuffer = (uchar*) booktxt;
		QueuePacket(outapp);
		delete outapp;
	}
}

void Client::TakeMoneyFromPP(uint32 copper){
	
	sint32 tmp;
	uint32 tmp2 = 0;
	tmp = pp.copper - copper;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.copper = tmp;
	
	tmp = pp.silver - tmp2;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.silver = tmp;
	
	tmp = pp.gold - tmp2;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.gold = tmp;
	
	tmp = pp.platinum - tmp2;
	if (tmp < 0){
		cout << "Error! Negativ amount of coins: " << this->name << endl;
		tmp = 0;
	}
	pp.platinum = tmp;
	Save();
	
	cout << "Debug: Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;
}

void Client::AddMoneyToPP(uint32 copper){
	uint32 tmp;
	uint32 tmp2;
	tmp = copper;
	tmp2 = tmp/1000;
	pp.platinum = pp.platinum + tmp2;
	tmp	= tmp - (tmp2* 1000);
	
	tmp2 = tmp/100;
	pp.gold = pp.gold + tmp2;
	tmp	= tmp - (tmp2* 100);
	
	tmp2 = tmp/10;
	pp.silver = pp.silver + tmp2;
	tmp	= tmp - (tmp2* 10);
	pp.copper = pp.copper + tmp;
	Save();
	cout << "Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;
}
void Client::AddMoneyToPP(uint32 copper, uint32 silver, uint32 gold,uint32 platinum){
	pp.platinum = pp.platinum + platinum;
	pp.gold = pp.gold + gold;
	pp.silver = pp.silver + silver;
	pp.copper = pp.copper + copper;
	Save();	
	cout << "Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;
	
}

void Client::SetPVP(bool toggle) {
	if(toggle) {
		pp.pvp = 1;
		SendAppearancePacket(4, 1);
		Save();
		Message(13, "You now follow the ways of discord.");
	}
	else {
		pp.pvp = 0;
		SendAppearancePacket(4, 0);
		Save();
		Message(13, "You no longer follow the ways of discord.");
	}
}

bool Client::CheckIncreaseSkill(int16 skillid,sint16 chancemodi){
	// TODO : Use skillcaps for classes and a better cap-calculation
	if (GetSkill(skillid) < GetLevel()*4){
		if (((float)rand()/RAND_MAX)*100 < 30+chancemodi){
			SetSkill(skillid,GetSkill(skillid)+1);
			return true;
		}
	}
	return false;
}

void Client::FinishTrade(Client* with) {
	const Item_Struct* item;
	//Item_Struct* outitem = 0;
	int16* toppslot;
	int16 toslot;
	int j;
	for (int i = 0;i != 7; i++){
		if (with->TradeList[i] != 0){
			item = database.GetItem(with->TradeList[i]);					
			toslot = FindFreeInventorySlot(&toppslot,(item->type == 1),true);
			if (toslot != 0xFFFF){
				this->PutItemInInventory(toslot,item,with->TradeCharges[i]);
				if (item->type == 1){
					for (j=0;j != 10; j++)
						this->PutItemInInventory(((toslot-22)*10) + j + 250,with->TradeList[((i+1)*10)+j],with->TradeCharges[((i+1)*10)+j]);					
				}
			}
		}
	}
}

void Client::RepairInventory(){
	int16 slotid;
	for (slotid = 0;slotid != 30;slotid++){
		if (pp.inventory[slotid] != 0xFFFF){
			if ((pp.invitemproperties[slotid].charges == 0 || pp.invitemproperties[slotid].charges > 20) && database.GetItem(pp.inventory[slotid]) != 0 && database.GetItem(pp.inventory[slotid])->common.normal.stackable == 1){  
				pp.inventory[slotid] = 0xFFFF;
				pp.invitemproperties[slotid].charges = 0;
				cout << "WARNING: Bad charges at slot " << slotid << " , delete item." << endl;
			}
		}
		else
			pp.invitemproperties[slotid].charges = 0;
	}
	for (slotid = 0;slotid != 80;slotid++){
		if (pp.containerinv[slotid] != 0xFFFF){
			if ((pp.bagitemproperties[slotid].charges == 0 || pp.bagitemproperties[slotid].charges > 20) && database.GetItem(pp.containerinv[slotid]) != 0 && database.GetItem(pp.containerinv[slotid])->common.normal.stackable == 1){  
				pp.containerinv[slotid] = 0xFFFF;
				pp.bagitemproperties[slotid].charges = 0;
				cout << "WARNING: Bad charges at slot " << slotid << " , delete item." << endl;
			}
		}
		else
			pp.bagitemproperties[slotid].charges = 0;
	}
	for (slotid = 0;slotid != 7;slotid++){
		if (pp.bank_inv[slotid] != 0xFFFF){
			if ((pp.bankinvitemproperties[slotid].charges == 0 || pp.bankinvitemproperties[slotid].charges > 20) && database.GetItem(pp.bank_inv[slotid]) != 0 && database.GetItem(pp.bank_inv[slotid])->common.normal.stackable == 1){  
				pp.bank_inv[slotid] = 0xFFFF;
				pp.bankinvitemproperties[slotid].charges = 0;
				cout << "WARNING: Bad charges at slot " << slotid << " , delete item." << endl;
			}
		}
		else
			pp.bankinvitemproperties[slotid].charges = 0;
	}
	for (slotid = 0;slotid != 80;slotid++){
		if (pp.bank_cont_inv[slotid] != 0xFFFF){
			if ((pp.bankbagitemproperties[slotid].charges == 0 || pp.bankbagitemproperties[slotid].charges > 20) && database.GetItem(pp.bank_cont_inv[slotid]) != 0 && database.GetItem(pp.bank_cont_inv[slotid])->common.normal.stackable == 1){  
				pp.bank_cont_inv[slotid] = 0xFFFF;
				pp.bankbagitemproperties[slotid].charges = 0;
				cout << "WARNING: Bad charges at slot " << slotid << " , delete item." << endl;
			}
		}
		else
			pp.bankbagitemproperties[slotid].charges = 0;
		
	}
	// TODO implement cursorbagitems in all functions
	for (slotid = 0;slotid != 10;slotid++){
		pp.cursorbaginventory[slotid] = 0xFFFF;
		pp.cursorbagitemproperties[slotid].charges = 0;
	}
}

bool Database::MakeDoorSpawnPacket(const char* zone,APPLAYER* app){
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	// probably i'll rewrite this code, so don't bother to make changes - Merkur
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name,pos_x,pos_y,pos_z,guild,heading,doorid,opentype FROM doors WHERE zone = '%s'", zone), errbuf, &result)) {
		delete[] query;
		int16 length = 0;
		int16 qty = 0;
		uchar buffer1[44];
		uchar buffer2[7000];
		while ((row = mysql_fetch_row(result)))
		{
			qty++;
			Door_Struct* nd = (Door_Struct*)buffer1;
			memset(nd,0,sizeof(Door_Struct));
			if ((uint8)atoi(row[6]) > 127) {
				cout << "MakeDoorSpawnPacket Error: door_id is too high!" << endl;
				nd->doorId = qty;
			}
			else
				nd->doorId = (atoi(row[4]) != 0) ? 128+atoi(row[6]):atoi(row[6]);
			nd->opentype = atoi(row[7]);
			//			if(GetInverseXY()==1) {
			//				nd->xPos = (float)atof(row[2]);
			//				nd->yPos = (float)atof(row[1]);				
			//			}
			//			else {
			nd->xPos = (float)atof(row[1]);
			nd->yPos = (float)atof(row[2]);
			//			}
			nd->zPos = (float)atof(row[3]);
			nd->unknown005 = 0xFFFF;
			nd->heading = atoi(row[5]);
			
			memcpy(nd->name,row[0],10);
			memcpy(buffer2+length,buffer1,44);
			length = length + 44;
		}
		mysql_free_result(result);
		//cout << length << endl;;
		if (qty == 0)
			return false;
		
		app->opcode = OP_SpawnDoor;
		app->pBuffer = new uchar[5000];
		length = DeflatePacket(buffer2,length,app->pBuffer+2,2000);
		app->size = length+2;
		DoorSpawns_Struct* ds = (DoorSpawns_Struct*)app->pBuffer;
		/*	Debug:
		uchar buffer3[2000];
		int txx = InflatePacket(app->pBuffer+2,length,buffer3,2000);
		cout << txx << endl;
		memcpy(app->pBuffer,buffer3,txx);		
		app->size =	txx;*/
		ds->count = qty;
		return true;	
	}
	else {
		cerr << "Error in MakeDoorSpawnPacket query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	
}

bool Database::CheckGuildDoor(int8 doorid,int16 guildid,const char* zone) {
	MYSQL_ROW row;
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
    MYSQL_RES *result;
	if (!RunQuery(query, MakeAnyLenString(&query, "SELECT guild FROM doors where doorid=%i AND zone='%s'",doorid-128, zone), errbuf, &result)) {
		cerr << "Error in CheckUsedName query '" << query << "' " << errbuf << endl;
		if (query != 0)
			delete[] query;
		return false;
	}
	else { 
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			if (atoi(row[0]) == guildid)
			{
				mysql_free_result(result);
				return true;
			}
			else
			{
				mysql_free_result(result);
				return false;
			}
			
			mysql_free_result(result);
			return false;
		}
	}
	return false;
}


bool Database::SetGuildDoor(int8 doorid,int16 guildid, const char* zone) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
	if (doorid > 127)
		doorid = doorid - 128;
	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE doors SET guild = %i WHERE (doorid=%i) AND (zone='%s')",guildid,doorid, zone), errbuf, 0,&affected_rows)) {
		cerr << "Error in SetGuildDoor query '" << query << "' " << errbuf << endl;
		return false;
	}
	delete[] query;
	
	if (affected_rows == 0)
	{
		return false;
	}
	
	return true;
}

bool Database::MakeZonepointPacket(const char* zone,APPLAYER* app){
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT zoneline FROM zonepoints_raw WHERE zone = '%s' ORDER BY id", zone), errbuf, &result)) {
		delete[] query;
		int16 length = 0;
		uchar buffer[5000];
		while ((row = mysql_fetch_row(result)))
		{
			memcpy(buffer+length,row[0],24);
			length = length + 24;
		}
		mysql_free_result(result);
		if (length == 0)
			return false;
		
		app->opcode = OP_SendZonepoints;
		app->pBuffer = new uchar[length+26];
		memset(app->pBuffer,0,length+26);
		app->size = length+26;
		memcpy(app->pBuffer+1,buffer,length);
		app->pBuffer[0] = length/24;
		return true;	
	}
	else {
		cerr << "Error in MakeZonepointPacket query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
}

void Client::WorldKick() {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_GMKick;
	outapp->size = sizeof(GMKick_Struct);
	GMKick_Struct* gmk = (GMKick_Struct *)outapp->pBuffer;
	memset(gmk, 0, sizeof(gmk));
	strcpy(gmk->name,GetName());
	QueuePacket(outapp);
	delete outapp;
}

void Client::GMKill() {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_GMKill;
	outapp->size = sizeof(GMKill_Struct);
	GMKill_Struct* gmk = (GMKill_Struct *)outapp->pBuffer;
	memset(gmk, 0, sizeof(gmk));
	strcpy(gmk->name,GetName());
	QueuePacket(outapp);
	delete outapp;
}

bool Client::CheckAccess(sint16 iDBLevel, sint16 iDefaultLevel) {
	if ((admin >= iDBLevel) || (iDBLevel == 255 && admin >= iDefaultLevel))
		return true;
	else
		return false;
}

void Client::SendAAStats() {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_SendAAStats;
	outapp->size = sizeof(AltAdvStats_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	AltAdvStats_Struct *aps = (AltAdvStats_Struct *)outapp->pBuffer;
	aps->experience = pp.expAA;
	aps->experience = (int32)(((float)330.0f * (float)pp.expAA) / (float)max_AAXP);
	aps->unspent = pp.aapoints;
	aps->percentage = pp.perAA;
	QueuePacket(outapp);
	delete outapp;
}

void Client::SendAATable() {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_RespondAA;
	outapp->size = sizeof(aa);
	outapp->pBuffer = new uint8[outapp->size];
	memcpy(outapp->pBuffer,&aa,outapp->size);
	QueuePacket(outapp);
	delete outapp;
}

/*bool Client::ServerFilter(APPLAYER *app)
{
if(ssfs.clientattackfilters == 0 && ssfs.npcattackfilters == 0 && ssfs.clientcastfilters == 0 && ssfs.npccastfilters == 0)
return true;

  switch(app->opcode)
  {
  case OP_Action:
  {
  
	Action_Struct* attk = (Action_Struct*)app->pBuffer;
	Mob* amob = entity_list.GetMob(attk->source);
	Mob* dmob = entity_list.GetMob(attk->target);
	
	  if(amob != 0 && amob->IsClient())
	  {
	  if(ssfs.clientattackfilters != 1 || ssfs.clientattackfilters != 2)
	  return true;
	  
		if(ssfs.clientattackfilters == 1 && (attk->target == GetID() || attk->source == GetID()))
		return true;
		if(ssfs.clientattackfilters == 2 && (attk->target == GetID() || attk->source == GetID()) || (this->isgrouped && entity_list.GetGroupByClient(this) != 0 && (entity_list.GetGroupByClient(this)->IsGroupMember(amob->CastToClient()) || (dmob->IsClient() && entity_list.GetGroupByClient(this)->IsGroupMember(dmob->CastToClient())))))
		return true;
		
		  return false;
		  }
		  if(amob != 0 && amob->IsNPC())
		  {
		  if(ssfs.npcattackfilters != 1 || ssfs.npcattackfilters != 2 || ssfs.npcattackfilters != 3)
		  return true;
		  
			if(ssfs.npcattackfilters == 1 && attk->damage > 0)
			return true;
			if(ssfs.npcattackfilters == 2 && attk->target == GetID() && attk->damage > 0)
			return true;
			if(ssfs.npcattackfilters == 3 && attk->damage > 0 && (dmob->IsClient() && this->isgrouped && entity_list.GetGroupByClient(this) != 0 && entity_list.GetGroupByClient(this)->IsGroupMember(dmob->CastToClient())))
			return true;
			
			  return false;
			  }
			  break;
			  }
			  case OP_BeginCast:
			  {
			  
				BeginCast_Struct* begincast = (BeginCast_Struct*)app->pBuffer;
				Mob* amob = entity_list.GetMob(begincast->caster_id);
				if(amob != 0 && amob->IsClient())
				{
				if(ssfs.npccastfilters != 1 && ssfs.npccastfilters != 2)
				return true;
				
				  if(ssfs.clientcastfilters == 1 && begincast->caster_id == GetID())
				  return true;
				  if(ssfs.clientcastfilters == 2 && amob->GetTarget()->CastToClient() == this)
				  return true;
				  
					return false;
					}
					if(amob != 0 && amob->IsNPC())
					{
					if(ssfs.npccastfilters != 1 || ssfs.npccastfilters != 2)
					return true;
					
					  if(ssfs.clientcastfilters == 2 && (amob->CastToNPC()->GetHateTop()->IsClient() && amob->CastToNPC()->GetHateTop()->CastToClient() == this))
					  return true;
					  
						return false;
						}
						
						  break;
						  }
						  }
						  
							return true;
}*/

