#include "../common/database.h"
#include "npc.h"

class InteractivePC : public NPC
{
public:
InteractivePC(NPCType* npc);
virtual ~InteractivePC();

virtual bool Process();
protected:
friend class EntityList;
};