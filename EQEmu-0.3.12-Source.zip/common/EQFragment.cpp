/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <string.h>
#include "EQFragment.h"

Fragment::Fragment()
{
	data = 0;
	size = 0;
}

Fragment::~Fragment()
{
	safe_delete(data);
}

void Fragment::SetData(uchar* d, int32 s)
{
	safe_delete(data);
	data = new uchar[s];
	memcpy(data, d, s);
	size = s; 
}

FragmentGroup::FragmentGroup(int16 seq, int16 opcode, int16 num_fragments)
{
	this->seq = seq;
	this->opcode = opcode;
	this->num_fragments = num_fragments;
	fragment = new Fragment[num_fragments];
}

FragmentGroup::~FragmentGroup()
{
	delete[] fragment;
}

void FragmentGroup::Add(int16 frag_id, uchar* data, int32 size)
{
	fragment[frag_id].SetData(data, size);
}

uchar* FragmentGroup::AssembleData(int32* size)
{
	uchar* buf;
	uchar* p;
	int i;

	*size = 0;	
	for(i=0; i<num_fragments; i++)
	{
		*size+=fragment[i].GetSize();		
	}
	buf = new uchar[*size];
	p = buf;
	for(i=0; i<num_fragments; i++)
	{
		memcpy(p, fragment[i].GetData(), fragment[i].GetSize());
		p += fragment[i].GetSize();
	}

	return buf;
}

void FragmentGroupList::Add(FragmentGroup* add_group)
{
	fragment_group_list.Insert(add_group);
}

FragmentGroup* FragmentGroupList::Get(int16 find_seq)
{
	LinkedListIterator<FragmentGroup*> iterator(fragment_group_list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetSeq() == find_seq)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

void FragmentGroupList::Remove(int16 remove_seq)
{
    LinkedListIterator<FragmentGroup*> iterator(fragment_group_list);

    iterator.Reset();
    while(iterator.MoreElements())
    {
        if (iterator.GetData()->GetSeq() == remove_seq)
        {
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}
}
