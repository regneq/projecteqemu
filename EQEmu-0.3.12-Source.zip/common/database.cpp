/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"

#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errmsg.h>
#include <mysqld_error.h>
#include <limits.h>
#include <ctype.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#define snprintf	_snprintf
      #define strncasecmp	_strnicmp
      #define strcasecmp	_stricmp
#else
	#include "unix.h"
#endif

#include "database.h"
#include "EQNetwork.h"
#include "packet_functions.h"
#include "eq_opcodes.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "../common/files.h"
#ifdef SHAREMEM
	#include "../common/EMuShareMem.h"
	extern LoadEMuShareMemDLL EMuShareMemDLL;
	extern Database database;
#endif

// change starting zone
const char* ZONE_NAME = "qeynos";

/*
	This is the amount of time in seconds the client has to enter the zone
	server after the world server, or inbetween zones when that is finished
*/

/*
	Establish a connection to a mysql database with the supplied parameters

	Added a very simple .ini file parser - Bounce

	Modify to use for win32 & linux - misanthropicfiend
*/
Database::Database ()
{
#ifndef SHAREMEM
	item_array = 0;
	npc_type_array = 0;
#endif
	max_item = 0;
	max_npc_type = 0;
	max_faction = 0;
	faction_array = 0;
	max_zonename = 0;
	zonename_array = 0;
	char host[200], user[200], passwd[200], database[200], buf[200], type[200];
	int items[4] = {0, 0, 0, 0};
	FILE *f;

	if (!(f = fopen (DB_INI_FILE, "r")))
	{
		printf ("Couldn't open '%s'.\n", DB_INI_FILE);
		printf ("Read README.TXT!\n");
		exit (1);
	}

	do
	{
		fgets (buf, 199, f);
		if (feof (f))
		{
			printf ("[Database] block not found in DB.INI.\n");
			printf ("Read README.TXT!\n");
			exit (1);
		}
	}
	while (strncasecmp (buf, "[Database]\n", 11) != 0 && strncasecmp (buf, "[Database]\r\n", 12) != 0);

	while (!feof (f))
	{
		#ifdef WIN32
		if (fscanf (f, "%[^=]=%[^\n]\n", type, buf) == 2)
		#else	
		if (fscanf (f, "%[^=]=%[^\r\n]\n", type, buf) == 2)
		#endif
		{
			if (!strncasecmp (type, "host", 4))
			{
				strncpy (host, buf, 199);
				items[0] = 1;
			}
			if (!strncasecmp (type, "user", 4))
			{
				strncpy (user, buf, 199);
				items[1] = 1;
			}
			if (!strncasecmp (type, "pass", 4))
			{
				strncpy (passwd, buf, 199);
				items[2] = 1;
			}
			if (!strncasecmp (type, "data", 4))
			{
				strncpy (database, buf, 199);
				items[3] = 1;
			}
		}
	}

	if (!items[0] || !items[1] || !items[2] || !items[3])
	{
		printf ("Incomplete DB.INI file.\n");
		printf ("Read README.TXT!\n");
		exit (1);
	}
	
	fclose (f);
	mysql_init(&mysql);
/*
Quagmire - added CLIENT_FOUND_ROWS flag to the connect
otherwise DB update calls would say 0 rows affected when the value already equalled
what the function was tring to set it to, therefore the function would think it failed 
*/
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, CLIENT_FOUND_ROWS))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}
/*
	Establish a connection to a mysql database with the supplied parameters
*/
Database::Database(const char* host, const char* user, const char* passwd, const char* database)
{
#ifndef SHAREMEM
	item_array = 0;
	npc_type_array = 0;
#endif
	max_item = 0;
	max_npc_type = 0;
	max_faction = 0;
	faction_array = 0;
	max_zonename = 0;
	zonename_array = 0;
	mysql_init(&mysql);
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, CLIENT_FOUND_ROWS))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}

sint16 Database::CommandRequirement(const char* commandname) {
	for(int i=0; i<maxcommandlevel; i++)
	{
		if((strcasecmp(commandname, commands[i]) == 0)) {
			return commandslevels[i];
		}
	}
	return 255;
}

void Database::ExtraOptions()
{
	FILE* f;
	int open = 1;
	char buf[200];
	char type[200];
	maxcommandlevel = 0;
if (!(f = fopen (ADDON_INI_FILE, "r")))
	{
		printf ("Couldn't open '%s'.\n", ADDON_INI_FILE);
		return;
	}
	do
	{
		fgets (buf, 199, f);
		if (feof (f))
		{
			printf ("[CommandLevels] block not found in ADDON.INI.\n");
			return;
		}
	}

	while (strncasecmp (buf, "[CommandLevels]\n", 11) != 0 && strncasecmp (buf, "[CommandLevels]\r\n", 12) != 0 && open == 1);

	while (!feof (f) && open == 1)
	{
		#ifdef WIN32
		if (fscanf (f, "%[^=]=%[^\n]\n", type, buf) == 2)
		#else	
		if (fscanf (f, "%[^=]=%[^\r\n]\n", type, buf) == 2)
		#endif
		{
			if(sizeof(type) > 0 && maxcommandlevel < 200) {
				snprintf(commands[maxcommandlevel], 200, "%s", type);
				commandslevels[maxcommandlevel] = atoi(buf);
				maxcommandlevel++;
			}
		}
	}
	
	fclose (f);
}
/*
	Close the connection to the database
*/
Database::~Database()
{
	unsigned int x;
#ifndef SHAREMEM
	if (item_array != 0) {
		for (x=0; x <= max_item; x++) {
			if (item_array[x] != 0)
				delete item_array[x];
		}
		delete item_array;
	}
	if (npc_type_array != 0) {
		for (x=0; x <= max_npc_type; x++) {
			if (npc_type_array[x] != 0)
				delete npc_type_array[x];
		}
		delete npc_type_array;
	}
#endif
	if (faction_array != 0) {
		for (x=0; x <= max_faction; x++) {
			if (faction_array[x] != 0)
				delete faction_array[x];
		}
		delete faction_array;
	}
	if (zonename_array) {
		for (x=0; x<=max_zonename; x++) {
			if (zonename_array[x])
				safe_delete(zonename_array[x]);
		}
		safe_delete(zonename_array);
	}
	mysql_close(&mysql);
}

// Sends the MySQL server a keepalive
void Database::ping() {
	LockMutex lock(&MDatabase);
	mysql_ping(&mysql);
}

bool Database::RunQuery(const char* query, int32 querylen, char* errbuf, MYSQL_RES** result, int32* affected_rows, int32* errnum, bool retry) {
	if (errnum)
		*errnum = 0;
	if (errbuf)
		errbuf[0] = 0;
	bool ret = false;
	LockMutex lock(&MDatabase);
	if (mysql_real_query(&mysql, query, querylen)) {
		if (mysql_errno(&mysql) == CR_SERVER_LOST) {
			if (retry) {
				cout << "Database Error: Lost connection, attempting to recover...." << endl;
				ret = RunQuery(query, querylen, errbuf, result, affected_rows, errnum, false);
			}
			else {
				if (errnum)
					*errnum = mysql_errno(&mysql);
				if (errbuf)
					snprintf(errbuf, MYSQL_ERRMSG_SIZE, "#%i: %s", mysql_errno(&mysql), mysql_error(&mysql));
				cout << "DB Query Error #" << mysql_errno(&mysql) << ": " << mysql_error(&mysql) << endl;
				ret = false;
			}
		}
		else {
			if (errnum)
				*errnum = mysql_errno(&mysql);
			if (errbuf)
				snprintf(errbuf, MYSQL_ERRMSG_SIZE, "#%i: %s", mysql_errno(&mysql), mysql_error(&mysql));
#ifdef _DEBUG
			cout << "DB Query Error #" << mysql_errno(&mysql) << ": " << mysql_error(&mysql) << endl;
#endif
			ret = false;
		}
	}
	else {
		if (affected_rows) {
			*affected_rows = mysql_affected_rows(&mysql);
		}
		if (result) {
			*result = mysql_store_result(&mysql);
			if (*result) {
				ret = true;
			}
			else {
#ifdef _DEBUG
				cout << "DB Query Error: No Result" << endl;
#endif
				if (errnum)
					*errnum = UINT_MAX;
				if (errbuf)
					strcpy(errbuf, "Database::RunQuery: No Result");
				ret = false;
			}
		}
		else {
			ret = true;
		}
	}
	return ret;
}

int32 Database::DoEscapeString(char* tobuf, const char* frombuf, int32 fromlen) {
	LockMutex lock(&MDatabase);
	return mysql_real_escape_string(&mysql, tobuf, frombuf, fromlen);
}

/*
	Check if the character with the name char_name from ip address ip has
	permission to enter zone zone_name. Return the account_id if the client
	has the right permissions, otherwise return zero.
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAuthentication(const char* char_name, const char* zone_name, int32 ip) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT account_id FROM authentication WHERE char_name='%s' AND zone_name='%s' AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", char_name, zone_name, ip, AUTHENTICATION_TIMEOUT), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			int32 account_id = atoi(row[0]);
			mysql_free_result(result);
			return account_id;
		}
		else {
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetAuthentication query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

/*
	Give the account with id "account_id" permission to enter zone "zone_name" from ip address "ip"
	with character "char_name". Return true if successful.
	False will be returned if there is a database error.
*/
bool Database::SetAuthentication(int32 account_id, const char* char_name, const char* zone_name, int32 ip) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM authentication WHERE account_id=%i", account_id), errbuf))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO authentication SET account_id=%i, char_name='%s', zone_name='%s', ip=%u", account_id, char_name, zone_name, ip), errbuf, 0, &affected_rows))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	delete[] query;

	if (affected_rows == 0) {
		return false;
	}

	return true;
}



/*
	This function will return the zone name in the "zone_name" parameter.
	This is used when a character changes zone, the old zone server sets
	the authentication record, the world server reads this new zone	name.
	If there was a record return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT char_name, zone_name FROM authentication WHERE account_id=%i AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", account_id, ip, AUTHENTICATION_TIMEOUT), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			strcpy(char_name, row[0]);
			strcpy(zone_name, row[1]);
			mysql_free_result(result);
			return true;
		}
		else {
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetAuthentication query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}


/*
	This function will remove the record in the authentication table for
	the account with id "accout_id"
	False will also be returned if there is a database error.
*/
bool Database::ClearAuthentication(int32 account_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM authentication WHERE account_id=%i", account_id), errbuf))
	{
		cerr << "Error in ClearAuthentication query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	delete[] query;

	return true;
}

/*
	Check if there is an account with name "name" and password "password"
	Return the account id or zero if no account matches.
	Zero will also be returned if there is a database error.
*/
int32 Database::CheckLogin(const char* name, const char* password) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	unsigned int i;
	for (i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}
	for (i=0; i<strlen(password); i++)
	{
		if ((password[i] < 'a' || password[i] > 'z') && 
		    (password[i] < 'A' || password[i] > 'Z') && 
		    (password[i] < '0' || password[i] > '9'))
			return 0;
	}

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM account WHERE name='%s' AND password='%s'", name, password), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 id = atoi(row[0]);
			mysql_free_result(result);
			return id;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckLogin query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int8 Database::GetGMSpeed(int32 account_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	MYSQL_RES *result;
	MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT gmspeed FROM account where id='%i'", account_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int8 gmspeed = atoi(row[0]);
			mysql_free_result(result);
			return gmspeed;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{

		cerr << "Error in GetGMSpeed query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return 0;

}

bool Database::SetGMSpeed(int32 account_id, int8 gmspeed)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE account SET gmspeed = %i where id = %i", gmspeed, account_id), errbuf)) {
		cerr << "Error in SetGMSpeed query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	delete[] query;
	return true;

}
sint16 Database::CheckStatus(int32 account_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT status FROM account WHERE id='%i'", account_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			sint16 status = atoi(row[0]);
			mysql_free_result(result);
			return status;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckStatus query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return 0;
}

bool Database::CreateAccount(const char* name, const char* password, sint16 status, int32 lsaccount_id) {	
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;

	cerr << "Account Attempting to be created:" << name << " " << password << " " << (sint16) status << endl;
	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO account SET name='%s', password='%s', status=%i, lsaccount_id=%i;",name,password,status, lsaccount_id), errbuf)) {
		cerr << "Error in CreateAccount query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	delete[] query;
	return true;
}

bool Database::DeleteAccount(const char* name) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	cerr << "Account Attempting to be deleted:" << name << endl;
	if (RunQuery(query, MakeAnyLenString(&query, "DELETE FROM account WHERE name='%s';",name), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1) {
			return true;
		}
	}
	else {

		cerr << "Error in DeleteAccount query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

bool Database::UpdateLiveChar(char* charname,int32 lsaccount_id) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE account SET charname='%s' WHERE id=%i;",charname, lsaccount_id), errbuf)) {
		cerr << "Error in UpdateLiveChar query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	delete[] query;
	return true;
}

bool Database::GetLiveChar(int32 lsaccount_id, char* cname)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT charname FROM account WHERE id=%i", lsaccount_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			strcpy(cname,row[0]);
			mysql_free_result(result);
			return true;
		}
	}
	else {
		cerr << "Error in GetLiveChar query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

bool Database::UpdateTempPacket(char* packet,int32 lsaccount_id) {

	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;

	end += sprintf(end, "UPDATE account SET packencrypt=");
	*end++ = '\'';
    end += DoEscapeString(end, packet, strlen(packet));
    *end++ = '\'';
    end += sprintf(end," WHERE id=%i", lsaccount_id);

	int32 affected_rows = 0;
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in UpdateTempPacket query " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

bool Database::GetTempPacket(int32 lsaccount_id, char* packet)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT packencrypt FROM account WHERE id=%i", lsaccount_id), errbuf, &result)) {
		delete[] query;

		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			memcpy(packet, row[0], strlen(row[0]));
			mysql_free_result(result);
			return true;
		}
	}
	else {
		delete[] query;
	}

	return false;
}

bool Database::SetGMFlag(const char* name, sint16 status) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32	affected_rows = 0;

	cout << "Account being GM Flagged:" << name << ", Level: " << (sint16) status << endl;
	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE account SET status=%i WHERE name='%s';", status, name), errbuf, 0, &affected_rows)) {
		delete[] query;
		return false;
	}
	delete[] query;

	if (affected_rows == 0)
	{
		cout << "Account: " << name << " does not exist, therefore it cannot be flagged\n";
		return false;
	}

	return true;
}

bool Database::SetSpecialAttkFlag(int8 id, const char* flag) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE npc_types SET npcspecialattks='%s' WHERE id=%i;",flag,id), errbuf, 0, &affected_rows)) {
		delete[] query;
		return false;
	}
	delete[] query;

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

#ifdef SHAREMEM
void Database::GetCharSelectInfo(int32 account_id, CharacterSelect_Struct* cs) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

    for(int i=0;i<10;i++) {
        strcpy(cs->name[i], "<none>");
        cs->zone[i] = 0;
        cs->level[i] = 0;
    }


	PlayerProfile_Struct* pp;
	int char_num = 0;
	unsigned long* lengths;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name,profile,zonename FROM character_ WHERE account_id=%i order by name", account_id), errbuf, &result)) {
		delete[] query;
		while ((row = mysql_fetch_row(result)))
		{
			lengths = mysql_fetch_lengths(result);
			if (lengths[1] != 0 && lengths[1] == sizeof(PlayerProfile_Struct))
			{
				strcpy(cs->name[char_num], row[0]);
				pp = (PlayerProfile_Struct*) row[1];
				cs->level[char_num] = pp->level;
				cs->class_[char_num] = pp->class_;
				cs->race[char_num] = pp->race;
				cs->gender[char_num] = pp->gender;
				cs->face[char_num] = pp->face;
				cs->zone[char_num] = GetZoneID(row[2]);

				// Coder_01 - REPLACE with item info when available.
				const Item_Struct* item = GetItem(pp->inventory[2]);
//				LoadAItem(pp->inventory[2],&cs->equip[char_num][0],&cs->cs_colors[char_num][0]);
				if (item != 0) {
					cs->equip[char_num][0] = item->common.material;
					cs->cs_colors[char_num][0] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[17]);
				//LoadAItem(pp->inventory[17],&cs->equip[char_num][1],&cs->cs_colors[char_num][1]);
				if (item != 0) {
					cs->equip[char_num][1] = item->common.material;
					cs->cs_colors[char_num][1] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[7]);
				//LoadAItem(pp->inventory[7],&cs->equip[char_num][2],&cs->cs_colors[char_num][2]);
				if (item != 0) {
					cs->equip[char_num][2] = item->common.material;
					cs->cs_colors[char_num][2] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[10]);
				//LoadAItem(pp->inventory[10],&cs->equip[char_num][3],&cs->cs_colors[char_num][3]);
				if (item != 0) {
					cs->equip[char_num][3] = item->common.material;
					cs->cs_colors[char_num][3] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[12]);
				//LoadAItem(pp->inventory[12],&cs->equip[char_num][4],&cs->cs_colors[char_num][4]);
				if (item != 0) {
					cs->equip[char_num][4] = item->common.material;
					cs->cs_colors[char_num][4] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[18]);
				//LoadAItem(pp->inventory[18],&cs->equip[char_num][5],&cs->cs_colors[char_num][5]);
				if (item != 0) {
					cs->equip[char_num][5] = item->common.material;
					cs->cs_colors[char_num][5] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[19]);
				//LoadAItem(pp->inventory[19],&cs->equip[char_num][6],&cs->cs_colors[char_num][6]);
				if (item != 0) {
					cs->equip[char_num][6] = item->common.material;
					cs->cs_colors[char_num][6] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[13]);
				//LoadAItem(pp->inventory[13],&cs->equip[char_num][7],&cs->cs_colors[char_num][7]); // Mainhand
				if (item != 0) {
					cs->equip[char_num][7] = item->common.material;
					cs->cs_colors[char_num][7] = item->common.color;
				}
				//delete item;
				item = GetItem(pp->inventory[14]);
				//LoadAItem(pp->inventory[14],&cs->equip[char_num][8],&cs->cs_colors[char_num][8]); // Offhand
				if (item != 0) {
					cs->equip[char_num][8] = item->common.material;
					cs->cs_colors[char_num][8] = item->common.color;
				}
				//delete item;
				char_num++;
				if (char_num > 10)
					break;
			}
			else {
				cout << "Got a bogus character (" << row[0] << "), deleting it." << endl;
				DeleteCharacter(row[0]);
			}
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetCharSelectInfo query '" << query << "' " << errbuf << endl;
		delete[] query;
		return;
	}

	return;
}
#else
void Database::GetCharSelectInfo(int32 account_id, CharacterSelect_Struct* cs) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

    for(int i=0;i<10;i++) {
        strcpy(cs->name[i], "<none>");
        cs->zone[i] = 0;
        cs->level[i] = 0;
    }


	PlayerProfile_Struct* pp;
	int char_num = 0;
	unsigned long* lengths;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name,profile,zonename FROM character_ WHERE account_id=%i order by name", account_id), errbuf, &result)) {
		delete[] query;
		while ((row = mysql_fetch_row(result)))
		{
			lengths = mysql_fetch_lengths(result);
			if (lengths[1] != 0)
			{
				strcpy(cs->name[char_num], row[0]);
				pp = (PlayerProfile_Struct*) row[1];
				cs->level[char_num] = pp->level;
				cs->class_[char_num] = pp->class_;
				cs->race[char_num] = pp->race;
				cs->gender[char_num] = pp->gender;
				cs->face[char_num] = pp->face;
				cs->zone[char_num] = GetZoneID(row[2]);

				// Coder_01 - REPLACE with item info when available.
				///*const*/ Item_Struct* item = 0;
				LoadAItem(pp->inventory[2],&cs->equip[char_num][0],&cs->cs_colors[char_num][0]);
				//if (item != 0) {
				//	&cs->equip[char_num][0] = item->common.material;
				//	&cs->cs_colors[char_num][0] = item->common.color;
				//}
				//delete item;
				/*item = */LoadAItem(pp->inventory[17],&cs->equip[char_num][1],&cs->cs_colors[char_num][1]);
				/*if (item != 0) {
					&cs->equip[char_num][1] = item->common.material;
					&cs->cs_colors[char_num][1] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[7],&cs->equip[char_num][2],&cs->cs_colors[char_num][2]);
				/*if (item != 0) {
					&cs->equip[char_num][2] = item->common.material;
					&cs->cs_colors[char_num][2] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[10],&cs->equip[char_num][3],&cs->cs_colors[char_num][3]);
				/*if (item != 0) {
					&cs->equip[char_num][3] = item->common.material;
					&cs->cs_colors[char_num][3] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[12],&cs->equip[char_num][4],&cs->cs_colors[char_num][4]);
				/*if (item != 0) {
					&cs->equip[char_num][4] = item->common.material;
					&cs->cs_colors[char_num][4] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[18],&cs->equip[char_num][5],&cs->cs_colors[char_num][5]);
				/*if (item != 0) {
					&cs->equip[char_num][5] = item->common.material;
					&cs->cs_colors[char_num][5] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[19],&cs->equip[char_num][6],&cs->cs_colors[char_num][6]);
				/*if (item != 0) {
					&cs->equip[char_num][6] = item->common.material;
					&cs->cs_colors[char_num][6] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[13],&cs->equip[char_num][7],&cs->cs_colors[char_num][7]); // Mainhand
				/*if (item != 0) {
					&cs->equip[char_num][7] = item->common.material;
					&cs->cs_colors[char_num][7] = item->common.color;
				}
				delete item;
				item = */LoadAItem(pp->inventory[14],&cs->equip[char_num][8],&cs->cs_colors[char_num][8]); // Offhand
				/*if (item != 0) {
					&cs->equip[char_num][8] = item->common.material;
					&cs->cs_colors[char_num][8] = item->common.color;
				}
				delete item;*/
				char_num++;
				if (char_num > 10)
					break;
			}
			else {
				cout << "Got a bogus character (" << row[0] << "), deleting it." << endl;
				DeleteCharacter(row[0]);
			}
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetCharSelectInfo query '" << query << "' " << errbuf << endl;
		delete[] query;
		return;
	}

	return;
}
#endif

/*
	Reserve the character name "name" for account "account_id"
	This name can then be used to create a character.
	Return true if successful, false if the name was already reserved.
	False will also be returned if there is a database error.
*/
bool Database::ReserveName(int32 account_id, char* name)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;

	//if (strlen(name) > 15)
	//	return false;

	/*for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}*/

	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT into character_ SET account_id=%i, name='%s', profile=NULL", account_id, name), errbuf)) {
		cerr << "Error in ReserveName query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	delete[] query;
	return true;
}

/*
	Delete the character with the name "name"
	False will also be returned if there is a database error.
*/
bool Database::DeleteCharacter(char* name)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;

	//if (strlen(name) > 15)
	//	return false;

	/*for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}*/

	if (!RunQuery(query, MakeAnyLenString(&query, "DELETE from character_ WHERE name='%s'", name), errbuf)) {
		cerr << "Error in DeleteCharacter query '" << query << "' " << errbuf << endl;
		if (query != 0)
			delete[] query;
		return false;
	}

	return true;
}

bool Database::CreateCharacter(int32 account_id, PlayerProfile_Struct* pp) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;
	int32 affected_rows = 0;

//	if (strlen(pp->name) > 15)
//		return false;

	unsigned int i;
	for (i=0; i<strlen(pp->name); i++) {
		if ((pp->name[i] < 'a' || pp->name[i] > 'z') && 
		    (pp->name[i] < 'A' || pp->name[i] > 'Z'))
			return 0;
	}
	toupper(pp->name[0]);
	pp->guildid = 0;
	for(i=1;i<strlen(pp->name);i++) tolower(pp->name[i]);
    end += sprintf(end, "UPDATE character_ SET zonename=\'%s\', x = %f, y = %f, z = %f, profile=", GetZoneName(pp->current_zone), pp->x, pp->y, pp->z);
    *end++ = '\'';
    end += DoEscapeString(end, (char*) pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s'", account_id, pp->name);

    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in CreateCharacter query '" << query << "' " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

/*
	Get the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
int32 Database::GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp, char* current_zone) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	/*for (int i=0; i<strlen(name); i++) {
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}*/

	unsigned long* lengths;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT profile, zonename, x, y, z FROM character_ WHERE account_id=%i AND name='%s'", account_id, name), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {	
			row = mysql_fetch_row(result);
			lengths = mysql_fetch_lengths(result);
			if (lengths[0] == sizeof(PlayerProfile_Struct)) {
				memcpy(pp, row[0], sizeof(PlayerProfile_Struct));
			}
			else {
				cerr << "Player profile length mismatch in GetPlayerProfile" << endl;
				mysql_free_result(result);
				return 0;
			}
			if (current_zone)
				strcpy(current_zone, row[1]);
			pp->current_zone = GetZoneID(row[1]);
			pp->x = atof(row[2]);
			pp->y = atof(row[3]);
			pp->z = atof(row[4]);
		}
		else {
			mysql_free_result(result);
			return 0;
		}
		int32 len = lengths[0];
		mysql_free_result(result);
		return len;
	}
	else {
		cerr << "Error in GetPlayerProfile query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

/*
	Update the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp, char* current_zone) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;

	//if (strlen(name) > 15)
	//	return false;

	/*for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}*/

	if (current_zone)
		end += sprintf(end, "UPDATE character_ SET zonename=\'%s\', x = %f, y = %f, z = %f, profile=", current_zone, pp->x, pp->y, pp->z);
	else
		end += sprintf(end, "UPDATE character_ SET zonename=\'%s\', x = %f, y = %f, z = %f, profile=", GetZoneName(pp->current_zone), pp->x, pp->y, pp->z);
	*end++ = '\'';
    end += DoEscapeString(end, (char*)pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s'", account_id, name);

	int32 affected_rows = 0;
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in SetPlayerProfile query " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

/*
	This function returns the account_id that owns the character with
	the name "name" or zero if no character with that name was found
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAccountIDByChar(const char* charname) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	/*for (int i=0; i<strlen(charname); i++)
	{
		if ((charname[i] < 'a' || charname[i] > 'z') && 
		    (charname[i] < 'A' || charname[i] > 'Z') && 
		    (charname[i] < '0' || charname[i] > '9'))
			return 0;
	}*/

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT account_id FROM character_ WHERE name='%s'", charname), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]); // copy to temp var because gotta free the result before exitting this function
			mysql_free_result(result);
			return tmp;
		}
	}
	else {
		cerr << "Error in GetAccountIDByChar query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}


int32 Database::GetAccountIDByName(const char* accname) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (unsigned int i=0; i<strlen(accname); i++)
	{
		if ((accname[i] < 'a' || accname[i] > 'z') && 
		    (accname[i] < 'A' || accname[i] > 'Z') && 
		    (accname[i] < '0' || accname[i] > '9'))
			return 0;
	}

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM account WHERE name='%s'", accname), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]); // copy to temp var because gotta free the result before exitting this function
			mysql_free_result(result);
			return tmp;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetAccountIDByAcc query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}

void Database::GetAccountName(int32 accountid, char* name, int32* oLSAccountID) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name, lsaccount_id FROM account WHERE id='%i'", accountid), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			strcpy(name, row[0]);
			if (row[1] && oLSAccountID) {
				*oLSAccountID = atoi(row[1]);
			}
		}
		mysql_free_result(result);
	}
	else {
		delete[] query;
		cerr << "Error in GetAccountName query '" << query << "' " << errbuf << endl;
	}
}

void Database::GetCharacterInfo(const char* name, int32* charid, int32* guilddbid, int8* guildrank) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id, guild, guildrank FROM character_ WHERE name='%s'", name), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			*charid = atoi(row[0]);
			*guilddbid = atoi(row[1]);
			*guildrank = atoi(row[2]);
			mysql_free_result(result);
			return;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetCharacterInfo query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
}

// Gets variable from 'variables' table
bool Database::GetVariable(const char* varname, char* varvalue, int16 varvalue_len) {
	if (strlen(varname) <= 1)
		return false;
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT value FROM variables WHERE varname like '%s'", varname), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			snprintf(varvalue, varvalue_len, "%s", row[0]);
			varvalue[varvalue_len-1] = 0;
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetVariable query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
	return false;
}

bool Database::SetVariable(const char* varname, const char* varvalue) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "Update variables set value='%s' WHERE varname like '%s'", varvalue, varname), errbuf, 0, &affected_rows)) {
		safe_delete(query);
		if (affected_rows != 1) {
			if (RunQuery(query, MakeAnyLenString(&query, "Insert Into variables (varname, value) values ('%s', '%s')", varname, varvalue), errbuf, 0, &affected_rows)) {
				safe_delete(query);
				if (affected_rows == 1) {
					return true;
				}
			}
		}
	}
	else {
		cerr << "Error in SetVariable query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
	return false;
}

bool Database::CheckZoneserverAuth(const char* ipaddr) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT * FROM zoneserver_auth WHERE '%s' like host", ipaddr), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) >= 1) {
			mysql_free_result(result);
			return true;
		}
		else {
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckZoneserverAuth query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	return false;
}

int8 Database::CheckWorldVerAuth(char* version) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
	MYSQL_ROW row;
	int32 errnum = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT approval FROM login_versions WHERE version='%s';", version), errbuf, &result, 0, &errnum)) {
		delete[] query;
		if (mysql_num_rows(result) >= 1) {
			row = mysql_fetch_row(result);
			mysql_free_result(result);
			return atoi(row[0]);
		}
		else {
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else if (errnum == ER_NO_SUCH_TABLE) {
		delete[] query;
		return true;
	}
	else {
		cerr << "Error in CheckWorldVerAuth query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	return false;
}

bool Database::GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id, eqid, name, leader, rank0title, rank1, rank1title, rank2, rank2title, rank3, rank3title, rank4, rank4title, rank5, rank5title from guilds where eqid=%i;", guildeqid), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			gr->leader = atoi(row[3]);
			gr->databaseID = atoi(row[0]);
			strcpy(gr->name, row[2]);
			for (int i = 0; i <= GUILD_MAX_RANK; i++) {
				strcpy(gr->rank[i].rankname, row[4 + (i*2)]);
				if (i == 0) {
					gr->rank[i].heargu = 1;
					gr->rank[i].speakgu = 1;
					gr->rank[i].invite = 1;
					gr->rank[i].remove = 1;
					gr->rank[i].promote = 1;
					gr->rank[i].demote = 1;
					gr->rank[i].motd = 1;
					gr->rank[i].warpeace = 1;
				}
				else if (strlen(row[3 + (i*2)]) >= 8) {
					gr->rank[i].heargu = (row[3 + (i*2)][GUILD_HEAR] == '1');
					gr->rank[i].speakgu = (row[3 + (i*2)][GUILD_SPEAK] == '1');
					gr->rank[i].invite = (row[3 + (i*2)][GUILD_INVITE] == '1');
					gr->rank[i].remove = (row[3 + (i*2)][GUILD_REMOVE] == '1');
					gr->rank[i].promote = (row[3 + (i*2)][GUILD_PROMOTE] == '1');
					gr->rank[i].demote = (row[3 + (i*2)][GUILD_DEMOTE] == '1');
					gr->rank[i].motd = (row[3 + (i*2)][GUILD_MOTD] == '1');
					gr->rank[i].warpeace = (row[3 + (i*2)][GUILD_WARPEACE] == '1');
				}
				else {
					gr->rank[i].heargu = 1;
					gr->rank[i].speakgu = 1;
					gr->rank[i].invite = 0;
					gr->rank[i].remove = 0;
					gr->rank[i].promote = 0;
					gr->rank[i].demote = 0;
					gr->rank[i].motd = 0;
					gr->rank[i].warpeace = 0;
				}

				if (gr->rank[i].rankname[0] == 0)
					snprintf(gr->rank[i].rankname, 100, "Guild Rank %i", i);
			}
		}
		else {
			gr->leader = 0;
			gr->databaseID = 0;
			memset(gr->name, 0, sizeof(gr->name));
			for (int i = 0; i <= GUILD_MAX_RANK; i++) {
				snprintf(gr->rank[i].rankname, 100, "Guild Rank %i", i);
				if (i == 0) {
					gr->rank[i].heargu = 1;
					gr->rank[i].speakgu = 1;
					gr->rank[i].invite = 1;
					gr->rank[i].remove = 1;
					gr->rank[i].promote = 1;
					gr->rank[i].demote = 1;
					gr->rank[i].motd = 1;
					gr->rank[i].warpeace = 1;
				}
				else {
					gr->rank[i].heargu = 0;
					gr->rank[i].speakgu = 0;
					gr->rank[i].invite = 0;
					gr->rank[i].remove = 0;
					gr->rank[i].promote = 0;
					gr->rank[i].demote = 0;
					gr->rank[i].motd = 0;
					gr->rank[i].warpeace = 0;
				}
			}
		}
		mysql_free_result(result);
		return true;
	}
	else {
		cerr << "Error in GetGuildRank query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::LoadGuilds(GuildRanks_Struct* guilds) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
//	int i;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int a = 0; a < 512; a++) {
		guilds[a].leader = 0;
		guilds[a].databaseID = 0;
		memset(guilds[a].name, 0, sizeof(guilds[a].name));
		for (int i = 0; i <= GUILD_MAX_RANK; i++) {
			snprintf(guilds[a].rank[i].rankname, 100, "Guild Rank %i", i);
			if (i == 0) {
				guilds[a].rank[i].heargu = 1;
				guilds[a].rank[i].speakgu = 1;
				guilds[a].rank[i].invite = 1;
				guilds[a].rank[i].remove = 1;
				guilds[a].rank[i].promote = 1;
				guilds[a].rank[i].demote = 1;
				guilds[a].rank[i].motd = 1;
				guilds[a].rank[i].warpeace = 1;
			}
			else {
				guilds[a].rank[i].heargu = 0;
				guilds[a].rank[i].speakgu = 0;
				guilds[a].rank[i].invite = 0;
				guilds[a].rank[i].remove = 0;
				guilds[a].rank[i].promote = 0;
				guilds[a].rank[i].demote = 0;
				guilds[a].rank[i].motd = 0;
				guilds[a].rank[i].warpeace = 0;
			}
		}
		Sleep(0);
	}

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id, eqid, name, leader, rank0title, rank1, rank1title, rank2, rank2title, rank3, rank3title, rank4, rank4title, rank5, rank5title from guilds"), errbuf, &result)) {
		delete[] query;
		int32 guildeqid = 0xFFFFFFFF;
		while ((row = mysql_fetch_row(result)))
		{
			guildeqid = atoi(row[1]);
			if (guildeqid < 512) {
				guilds[guildeqid].leader = atoi(row[3]);
				guilds[guildeqid].databaseID = atoi(row[0]);
				strcpy(guilds[guildeqid].name, row[2]);
				for (int i = 0; i <= GUILD_MAX_RANK; i++) {
					strcpy(guilds[guildeqid].rank[i].rankname, row[4 + (i*2)]);
					if (i == 0) {
						guilds[guildeqid].rank[i].heargu = 1;
						guilds[guildeqid].rank[i].speakgu = 1;
						guilds[guildeqid].rank[i].invite = 1;
						guilds[guildeqid].rank[i].remove = 1;
						guilds[guildeqid].rank[i].promote = 1;
						guilds[guildeqid].rank[i].demote = 1;
						guilds[guildeqid].rank[i].motd = 1;
						guilds[guildeqid].rank[i].warpeace = 1;
					}
					else if (strlen(row[3 + (i*2)]) >= 8) {
						guilds[guildeqid].rank[i].heargu = (row[3 + (i*2)][GUILD_HEAR] == '1');
						guilds[guildeqid].rank[i].speakgu = (row[3 + (i*2)][GUILD_SPEAK] == '1');
						guilds[guildeqid].rank[i].invite = (row[3 + (i*2)][GUILD_INVITE] == '1');
						guilds[guildeqid].rank[i].remove = (row[3 + (i*2)][GUILD_REMOVE] == '1');
						guilds[guildeqid].rank[i].promote = (row[3 + (i*2)][GUILD_PROMOTE] == '1');
						guilds[guildeqid].rank[i].demote = (row[3 + (i*2)][GUILD_DEMOTE] == '1');
						guilds[guildeqid].rank[i].motd = (row[3 + (i*2)][GUILD_MOTD] == '1');
						guilds[guildeqid].rank[i].warpeace = (row[3 + (i*2)][GUILD_WARPEACE] == '1');
					}
					else {
						guilds[guildeqid].rank[i].heargu = 1;
						guilds[guildeqid].rank[i].speakgu = 1;
						guilds[guildeqid].rank[i].invite = 0;
						guilds[guildeqid].rank[i].remove = 0;
						guilds[guildeqid].rank[i].promote = 0;
						guilds[guildeqid].rank[i].demote = 0;
						guilds[guildeqid].rank[i].motd = 0;
						guilds[guildeqid].rank[i].warpeace = 0;
					}

					if (guilds[guildeqid].rank[i].rankname[0] == 0)
						snprintf(guilds[guildeqid].rank[i].rankname, 100, "Guild Rank %i", i);
				}
			}
			Sleep(0);
		}
		mysql_free_result(result);
		return true;
	}
	else
	{
		cerr << "Error in LoadGuilds query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetGuildEQID(int32 guilddbid) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT eqid FROM guilds WHERE id=%i", guilddbid), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]);
			mysql_free_result(result);
			return tmp;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetGuildEQID query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0xFFFFFFFF;
}

// Pyro: Get zone starting points from DB
bool Database::GetSafePoints(const char* short_name, float* safe_x, float* safe_y, float* safe_z, sint16* minstatus, int8* minlevel) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
//	int buf_len = 256;
//    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT safe_x, safe_y, safe_z, minium_status, minium_level FROM zone WHERE short_name='%s'", short_name), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			if (safe_x != 0)
				*safe_x = atof(row[0]);
			if (safe_y != 0)
				*safe_y = atof(row[1]);
			if (safe_z != 0)
				*safe_z = atof(row[2]);
			if (minstatus != 0)
				*minstatus = atoi(row[3]);
			if (minlevel != 0)
				*minlevel = atoi(row[4]);
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetSafePoint query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
	return false;
}

bool Database::SetGuild(int32 charid, int32 guilddbid, int8 guildrank) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "UPDATE character_ SET guild=%i, guildrank=%i WHERE id=%i", guilddbid, guildrank, charid), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else {
		cerr << "Error in SetGuild query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetFreeGuildEQID()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[100];
    MYSQL_RES *result;

	for (int x = 1; x < 512; x++) {
		snprintf(query, 100, "SELECT eqid FROM guilds where eqid=%i;", x);

		if (RunQuery(query, strlen(query), errbuf, &result)) {
			if (mysql_num_rows(result) == 0) {
				mysql_free_result(result);
				return x;
			}
			mysql_free_result(result);
		}
		else {
			cerr << "Error in GetFreeGuildEQID query '" << query << "' " << errbuf << endl;
		}
	}

	return 0xFFFFFFFF;
}

int32 Database::CreateGuild(const char* name, int32 leader) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	char buf[65];
	int32 affected_rows = 0;
	DoEscapeString(buf, name, strlen(name)) ;

	int32 tmpeqid = GetFreeGuildEQID();
	if (tmpeqid == 0xFFFFFFFF) {
		cout << "Error in Database::CreateGuild: unable to find free eqid" << endl;
		return 0xFFFFFFFF;
	}

	if (RunQuery(query, MakeAnyLenString(&query, "INSERT INTO guilds (name, leader, eqid) Values ('%s', %i, %i)", buf, leader, tmpeqid), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1) {
			return tmpeqid;
		}
		else {
			return 0xFFFFFFFF;
		}
	}
	else {
		cerr << "Error in CreateGuild query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0xFFFFFFFF;
	}

	return 0xFFFFFFFF;
}

bool Database::DeleteGuild(int32 guilddbid)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "DELETE FROM guilds WHERE id=%i;", guilddbid), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else {
		cerr << "Error in DeleteGuild query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::RenameGuild(int32 guilddbid, const char* name) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;
	char buf[65];
	DoEscapeString(buf, name, strlen(name)) ;

	if (RunQuery(query, MakeAnyLenString(&query, "Update guilds set name='%s' WHERE id=%i;", buf, guilddbid), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else {
		cerr << "Error in RenameGuild query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    int chars = 0;
	int32 affected_rows = 0;
	char buf[203];
	char buf2[8];
	DoEscapeString(buf, grl->rankname, strlen(grl->rankname)) ;
	buf2[GUILD_HEAR] = grl->heargu + '0';
	buf2[GUILD_SPEAK] = grl->speakgu + '0';
	buf2[GUILD_INVITE] = grl->invite + '0';
	buf2[GUILD_REMOVE] = grl->remove + '0';
	buf2[GUILD_PROMOTE] = grl->promote + '0';
	buf2[GUILD_DEMOTE] = grl->demote + '0';
	buf2[GUILD_MOTD] = grl->motd + '0';
	buf2[GUILD_WARPEACE] = grl->warpeace + '0';

	if (ranknum == 0)
		chars = MakeAnyLenString(&query, "Update guilds set rank%ititle='%s' WHERE id=%i;", ranknum, buf, guilddbid);
	else
		chars = MakeAnyLenString(&query, "Update guilds set rank%ititle='%s', rank%i='%s' WHERE id=%i;", ranknum, buf, ranknum, buf2, guilddbid);

	if (RunQuery(query, chars, errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else {
		cerr << "Error in EditGuild query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::GetZoneLongName(const char* short_name, char** long_name, char* file_name, float* safe_x, float* safe_y, float* safe_z) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT long_name, file_name, safe_x, safe_y, safe_z FROM zone WHERE short_name='%s'", short_name), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			if (long_name != 0) {
				*long_name = strcpy(new char[strlen(row[0])+1], row[0]);
			}
			if (file_name != 0) {
				if (row[1] == 0)
					strcpy(file_name, short_name);
				else
					strcpy(file_name, row[1]);
			}
			if (safe_x != 0)
				*safe_x = atof(row[2]);
			if (safe_y != 0)
				*safe_y = atof(row[3]);
			if (safe_z != 0)
				*safe_z = atof(row[4]);
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetZoneLongName query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetGuildDBIDbyLeader(int32 leader)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM guilds WHERE leader=%i", leader), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]);
			mysql_free_result(result);
			return tmp;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetGuildDBIDbyLeader query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}

bool Database::SetGuildLeader(int32 guilddbid, int32 leader)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "UPDATE guilds SET leader=%i WHERE id=%i", leader, guilddbid), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else {
		cerr << "Error in SetGuildLeader query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::UpdateItem(int32 item_id,Item_Struct* is)
{
#ifndef SHAREMEM
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(Item_Struct)*2+1];
	char* end = query;

		end += sprintf(end, "UPDATE items SET raw_data=");
	*end++ = '\'';
    end += DoEscapeString(end, (char*)is, sizeof(Item_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE id=%i", item_id);

	item_array[item_id] = is;

	int32 affected_rows = 0;
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in UpdateItem query " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
#else
	return false;
#endif
}

bool Database::SetGuildMOTD(int32 guilddbid, const char* motd) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	char* motdbuf = 0;
	int32 affected_rows = 0;

	motdbuf = new char[(strlen(motd)*2)+3];
	DoEscapeString(motdbuf, motd, strlen(motd)) ;

	if (RunQuery(query, MakeAnyLenString(&query, "Update guilds set motd='%s' WHERE id=%i;", motdbuf, guilddbid), errbuf, 0, &affected_rows)) {
		delete[] query;
		delete motdbuf;
		if (affected_rows == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in SetGuildMOTD query '" << query << "' " << errbuf << endl;
		delete[] query;
		delete motdbuf;
		return false;
	}

	return false;
}

bool Database::GetGuildMOTD(int32 guilddbid, char* motd)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT motd FROM guilds WHERE id=%i", guilddbid), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			if (row[0] == 0)
				strcpy(motd, "");
			else
				strcpy(motd, row[0]);
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}


	else {
		cerr << "Error in GetGuildMOTD query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

sint32 Database::GetItemsCount(int32* oMaxID) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id), count(*) FROM items");

	int32 tmpMaxItem = 0;
	int32 tmpItemCount = 0;
//	Item_Struct tmpItem;
	
	if (RunQuery(query, strlen(query), errbuf, &result)) {
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != NULL && row[1] != 0) {
			sint32 ret = atoi(row[1]);
			if (oMaxID) {
				if (row[0])
					*oMaxID = atoi(row[0]);
				else
					*oMaxID = 0;
			}
			mysql_free_result(result);
			return ret;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetItemsCount query '" << query << "' " << errbuf << endl;
		delete[] query;
		return -1;
	}
	return -1;
}

sint32 Database::GetNPCTypesCount(int32* oMaxID) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id), count(*) FROM npc_types");
	if (RunQuery(query, strlen(query), errbuf, &result)) {
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != NULL && row[1] != 0) {
			sint32 ret = atoi(row[1]);
			if (oMaxID) {
				if (row[0])
					*oMaxID = atoi(row[0]);
				else
					*oMaxID = 0;
			}
			mysql_free_result(result);
			return ret;
		}
	}
	else {
		cerr << "Error in GetNPCTypesCount query '" << query << "' " << errbuf << endl;
		delete[] query;
		return -1;
	}
	
	return -1;
}

#ifdef SHAREMEM
extern "C" bool extDBLoadItems(int16 iItemCount, int16 iMaxItemID) { return database.DBLoadItems(iItemCount, iMaxItemID); }
bool Database::LoadItems() {
	if (!EMuShareMemDLL.Load())
		return false;
	sint32 tmp = 0;
	tmp = GetItemsCount(&max_item);
	if (tmp == -1) {
		cout << "Error: Database::LoadItems() (sharemem): GetItemsCount() returned -1" << endl;
		return false;
	}
	bool ret = EMuShareMemDLL.Items.DLLLoadItems(&extDBLoadItems, sizeof(Item_Struct), tmp, max_item);
	return ret;
}
bool Database::DBLoadItems(int16 iItemCount, int16 iMaxItemID) {
	cout << "Loading items from database..." << endl;
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id), count(*) FROM items");

//	Item_Struct tmpItem;
	
	if (RunQuery(query, strlen(query), errbuf, &result)) {
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != 0 && row[0] > 0) {
			max_item = atoi(row[0]);
			if (atoi(row[1]) != iItemCount) {
				cout << "Error: Insufficient shared memory to load items." << endl;
				cout << "Count(id): " << atoi(row[1]) << ", iItemCount: " << iItemCount << endl;
				return false;
			}
			if (atoi(row[0]) != iMaxItemID) {
				cout << "Error: Insufficient shared memory to load items." << endl;
				cout << "Max(id): " << atoi(row[0]) << ", iMaxItemID: " << iMaxItemID << endl;
				cout << "Fix this by increasing the MMF_EQMAX_ITEMS define statement" << endl;
				return false;
			}
			mysql_free_result(result);
			
			MakeAnyLenString(&query, "SELECT id,raw_data FROM items");

			if (RunQuery(query, strlen(query), errbuf, &result)) {
				delete[] query;
				while((row = mysql_fetch_row(result))) {
					unsigned long* lengths;
					lengths = mysql_fetch_lengths(result);
					if (lengths[1] == sizeof(Item_Struct)) {
//						memcpy(tmpItem, row[1], sizeof(Item_Struct));
//						EMuShareMemDLL.Items.cbAddItem(atoi(row[0]), tmpItem);
						EMuShareMemDLL.Items.cbAddItem(atoi(row[0]), (Item_Struct*) row[1]);
					}
					else {
						// TODO: Invalid item length in database
					}
					Sleep(0);
				}
				mysql_free_result(result);
			}
			else {
				cerr << "Error in DBLoadItems query '" << query << "' " << errbuf << endl;
				delete[] query;
				return false;
			}
		}
		else {
			mysql_free_result(result);
		}
	}
	else {
		cerr << "Error in DBLoadItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	return true;
}

const Item_Struct* Database::GetItem(uint32 id) {
	return EMuShareMemDLL.Items.GetItem(id);
}
#else
bool Database::LoadItems()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM items");

	
	if (RunQuery(query, strlen(query), errbuf, &result)) {
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != 0 && row[0] > 0)
		{ 
			max_item = atoi(row[0]);
			item_array = new Item_Struct*[max_item+1];
			for(unsigned int i=0; i<max_item; i++)
			{
				item_array[i] = 0;
			}
			mysql_free_result(result);
			
			MakeAnyLenString(&query, "SELECT id,raw_data FROM items");

			if (RunQuery(query, strlen(query), errbuf, &result))
			{
				delete[] query;
				while((row = mysql_fetch_row(result)))
				{
					unsigned long* lengths;
					lengths = mysql_fetch_lengths(result);
					if (lengths[1] == sizeof(Item_Struct))
					{
						item_array[atoi(row[0])] = new Item_Struct;
						memcpy(item_array[atoi(row[0])], row[1], sizeof(Item_Struct));
					}
					else
					{
						// TODO: Invalid item length in database
					}
					Sleep(0);
				}
				mysql_free_result(result);
			}
			else {
				cerr << "Error in LoadItems query '" << query << "' " << errbuf << endl;
				delete[] query;
				return false;
			}
		}
		else {
			mysql_free_result(result);
		}
	}
	else {
		cerr << "Error in LoadItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	return true;
}

const Item_Struct* Database::GetItem(uint32 id) {
	if (item_array && id <= max_item)
		return item_array[id];
	else
		return 0;
}
#endif

#ifdef SHAREMEM
extern "C" bool extDBLoadNPCTypes(int32 iNPCTypeCount, int32 iMaxNPCTypeID) { return database.DBLoadNPCTypes(iNPCTypeCount, iMaxNPCTypeID); }
const NPCType* Database::GetNPCType(uint32 id) {
	return EMuShareMemDLL.NPCTypes.GetNPCType(id);
}
bool Database::LoadNPCTypes() {
	if (!EMuShareMemDLL.Load())
		return false;
	sint32 tmp_max_npc_type = -1;
	int32 tmp = 0;
	tmp_max_npc_type = GetNPCTypesCount(&tmp);
	if (tmp_max_npc_type < 0) {
		cout << "Error: Database::LoadNPCTypes-ShareMem: GetNPCTypesCount() returned < 0" << endl;
		return false;
	}
	max_npc_type = tmp_max_npc_type;
	bool ret = EMuShareMemDLL.NPCTypes.DLLLoadNPCTypes(&extDBLoadNPCTypes, sizeof(NPCType), max_npc_type, tmp);
	return ret;
}
bool Database::DBLoadNPCTypes(int32 iNPCTypeCount, int32 iMaxNPCTypeID) {
	cout << "Loading NPCTypes from database..." << endl;
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id), Count(*) FROM npc_types");
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != 0 && row > 0 && row[0] != 0) {
			if (atoi(row[0]) > iMaxNPCTypeID) {
				cout << "Error: Insufficient shared memory to load items." << endl;
				cout << "Max(id): " << atoi(row[0]) << ", iMaxNPCTypeID: " << iMaxNPCTypeID << endl;
				cout << "Fix this by increasing the MMF_MAX_NPCTYPE_ID define statement" << endl;
				return false;
			}
			if (atoi(row[1]) != iNPCTypeCount) {
				cout << "Error: Insufficient shared memory to load items." << endl;
				cout << "Count(*): " << atoi(row[1]) << ", iNPCTypeCount: " << iNPCTypeCount << endl;
				return false;
			}
			max_npc_type = atoi(row[0]);
			mysql_free_result(result);
			
			NPCType tmpNPCType;
			// support the old database too for a while...
			MakeAnyLenString(&query, "SELECT id,name,level,race,class,hp,gender,texture,helmtexture,size,loottable_id, merchant_id, banish, mindmg, maxdmg, npcspecialattks,usedspells,d_meele_texture1,d_meele_texture2, walkspeed, runspeed,fixedz,hp_regen_rate,mana_regen_rate FROM npc_types");//WHERE zone='%s'", zone_name
			if (RunQuery(query, strlen(query), errbuf, &result))
			{
				safe_delete(query);
				while((row = mysql_fetch_row(result)))
				{
					memset(&tmpNPCType, 0, sizeof(NPCType));
					strncpy(tmpNPCType.name, row[1], 30);
					tmpNPCType.npc_id = atoi(row[0]); // rembrant, Dec. 2
					tmpNPCType.level = atoi(row[2]);
					tmpNPCType.race = atoi(row[3]);
					tmpNPCType.class_ = atoi(row[4]);
					tmpNPCType.cur_hp = atoi(row[5]);
					tmpNPCType.max_hp = atoi(row[5]);
					tmpNPCType.gender = atoi(row[6]);
					tmpNPCType.texture = atoi(row[7]);
					tmpNPCType.helmtexture = atoi(row[8]);
					tmpNPCType.size = atof(row[9]);
					tmpNPCType.loottable_id = atoi(row[10]);
					tmpNPCType.merchanttype = atoi(row[11]);
					tmpNPCType.STR = 75;
					tmpNPCType.STA = 75;
					tmpNPCType.DEX = 75;
					tmpNPCType.AGI = 75;
					tmpNPCType.WIS = 75;
					tmpNPCType.INT = 75;
					tmpNPCType.CHA = 75;
					tmpNPCType.banish = atoi(row[12]);
					tmpNPCType.min_dmg = atoi(row[13]);
					tmpNPCType.max_dmg = atoi(row[14]);
					strcpy(tmpNPCType.npc_attacks,row[15]);
					strcpy(tmpNPCType.npc_spells,row[16]);
					tmpNPCType.d_meele_texture1= atoi(row[17]);
					tmpNPCType.d_meele_texture2= atoi(row[18]);
					tmpNPCType.walkspeed= atof(row[19]);
					tmpNPCType.runspeed= atof(row[20]);
					tmpNPCType.fixedZ = atof(row[21]);
					tmpNPCType.hp_regen = (sint32)atof(row[22]);
					tmpNPCType.mana_regen = (sint32)atof(row[23]);
					EMuShareMemDLL.NPCTypes.cbAddNPCType(tmpNPCType.npc_id, &tmpNPCType);
					Sleep(0);
				}
				mysql_free_result(result);
			}
			else{
				safe_delete(query);
				query = 0;
				MakeAnyLenString(&query, "SELECT id,name,level,race,class,hp,gender,texture,helmtexture,size,loottable_id, merchant_id, banish, mindmg, maxdmg, npcspecialattks,usedspells FROM npc_types");//WHERE zone='%s'", zone_name
				if (RunQuery(query, strlen(query), errbuf, &result))
				{
					safe_delete(query);
					while((row = mysql_fetch_row(result))) {
						memset(&tmpNPCType, 0, sizeof(NPCType));
						strncpy(tmpNPCType.name, row[1], 30);
						tmpNPCType.npc_id = atoi(row[0]); // rembrant, Dec. 2
						tmpNPCType.level = atoi(row[2]);
						tmpNPCType.race = atoi(row[3]);
						tmpNPCType.class_ = atoi(row[4]);
						tmpNPCType.cur_hp = atoi(row[5]);
						tmpNPCType.max_hp = atoi(row[5]);
						tmpNPCType.gender = atoi(row[6]);
						tmpNPCType.texture = atoi(row[7]);
						tmpNPCType.helmtexture = atoi(row[8]);
						tmpNPCType.size = atof(row[9]);
						tmpNPCType.loottable_id = atoi(row[10]);
						tmpNPCType.merchanttype = atoi(row[11]);
						tmpNPCType.STR = 75;
						tmpNPCType.STA = 75;
						tmpNPCType.DEX = 75;
						tmpNPCType.AGI = 75;
						tmpNPCType.WIS = 75;
						tmpNPCType.INT = 75;
						tmpNPCType.CHA = 75;
						tmpNPCType.banish = atoi(row[12]);
						tmpNPCType.min_dmg = atoi(row[13]);
						tmpNPCType.max_dmg = atoi(row[14]);
						strcpy(tmpNPCType.npc_attacks,row[15]);
						strcpy(tmpNPCType.npc_spells,row[16]);
						EMuShareMemDLL.NPCTypes.cbAddNPCType(tmpNPCType.npc_id, &tmpNPCType);
						Sleep(0);
					}
					mysql_free_result(result);
					cout << "NPCs loaded - using old database format" << endl;
				}
				else
				{
					cerr << "Error in DBLoadNPCTypes query '" << query << "' " << errbuf << endl;
					delete[] query;
					return false;
				}
			}
		}
		else
		{
			mysql_free_result(result);
		}
	}
	else
	{
		cerr << "Error in DBLoadNPCTypes query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	
	return true;
}
#else
bool Database::LoadNPCTypes() {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM npc_types");
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != 0 && row > 0 && row[0] != 0)
		{
			max_npc_type = atoi(row[0]);
			npc_type_array = new NPCType*[max_npc_type+1];
			for (unsigned int x=0; x <= max_npc_type; x++)
				npc_type_array[x] = 0;
			mysql_free_result(result);
			
			// support the old database too for a while...
			MakeAnyLenString(&query, "SELECT id,name,level,race,class,hp,gender,texture,helmtexture,size,loottable_id, merchant_id, banish, mindmg, maxdmg, npcspecialattks,usedspells,d_meele_texture1,d_meele_texture2, walkspeed, runspeed,fixedz,hp_regen_rate,mana_regen_rate FROM npc_types");//WHERE zone='%s'", zone_name
			if (RunQuery(query, strlen(query), errbuf, &result))
			{
				safe_delete(query);
				while((row = mysql_fetch_row(result)))
				{
					npc_type_array[atoi(row[0])] = new NPCType;
					memset(npc_type_array[atoi(row[0])], 0, sizeof(NPCType));
					strncpy(npc_type_array[atoi(row[0])]->name, row[1], 30);
					npc_type_array[atoi(row[0])]->npc_id = atoi(row[0]); // rembrant, Dec. 2
					npc_type_array[atoi(row[0])]->level = atoi(row[2]);
					npc_type_array[atoi(row[0])]->race = atoi(row[3]);
					npc_type_array[atoi(row[0])]->class_ = atoi(row[4]);
					npc_type_array[atoi(row[0])]->cur_hp = atoi(row[5]);
					npc_type_array[atoi(row[0])]->max_hp = atoi(row[5]);
					npc_type_array[atoi(row[0])]->gender = atoi(row[6]);
					npc_type_array[atoi(row[0])]->texture = atoi(row[7]);
					npc_type_array[atoi(row[0])]->helmtexture = atoi(row[8]);
					npc_type_array[atoi(row[0])]->size = atof(row[9]);
					npc_type_array[atoi(row[0])]->loottable_id = atoi(row[10]);
					npc_type_array[atoi(row[0])]->merchanttype = atoi(row[11]);
					npc_type_array[atoi(row[0])]->STR = 75;
					npc_type_array[atoi(row[0])]->STA = 75;
					npc_type_array[atoi(row[0])]->DEX = 75;
					npc_type_array[atoi(row[0])]->AGI = 75;
					npc_type_array[atoi(row[0])]->WIS = 75;
					npc_type_array[atoi(row[0])]->INT = 75;
					npc_type_array[atoi(row[0])]->CHA = 75;
					npc_type_array[atoi(row[0])]->banish = atoi(row[12]);
					npc_type_array[atoi(row[0])]->min_dmg = atoi(row[13]);
					npc_type_array[atoi(row[0])]->max_dmg = atoi(row[14]);
					strcpy(npc_type_array[atoi(row[0])]->npc_attacks,row[15]);
					strcpy(npc_type_array[atoi(row[0])]->npc_spells,row[16]);
					npc_type_array[atoi(row[0])]->d_meele_texture1= atoi(row[17]);
					npc_type_array[atoi(row[0])]->d_meele_texture2= atoi(row[18]);
					npc_type_array[atoi(row[0])]->walkspeed= atof(row[19]);
					npc_type_array[atoi(row[0])]->runspeed= atof(row[20]);
					npc_type_array[atoi(row[0])]->fixedZ = atof(row[21]);
					npc_type_array[atoi(row[0])]->hp_regen = (sint32)atof(row[22]);
					npc_type_array[atoi(row[0])]->mana_regen = (sint32)atof(row[23]);
					Sleep(0);
				}
				mysql_free_result(result);
			}
			else{
				safe_delete(query);
				query = 0;
				MakeAnyLenString(&query, "SELECT id,name,level,race,class,hp,gender,texture,helmtexture,size,loottable_id, merchant_id, banish, mindmg, maxdmg, npcspecialattks,usedspells FROM npc_types");//WHERE zone='%s'", zone_name
				if (RunQuery(query, strlen(query), errbuf, &result))
				{
					safe_delete(query);
					while((row = mysql_fetch_row(result)))
					{
						npc_type_array[atoi(row[0])] = new NPCType;
						memset(npc_type_array[atoi(row[0])], 0, sizeof(NPCType));
						strncpy(npc_type_array[atoi(row[0])]->name, row[1], 30);
						npc_type_array[atoi(row[0])]->npc_id = atoi(row[0]); // rembrant, Dec. 2
						npc_type_array[atoi(row[0])]->level = atoi(row[2]);
						npc_type_array[atoi(row[0])]->race = atoi(row[3]);
						npc_type_array[atoi(row[0])]->class_ = atoi(row[4]);
						npc_type_array[atoi(row[0])]->cur_hp = atoi(row[5]);
						npc_type_array[atoi(row[0])]->max_hp = atoi(row[5]);
						npc_type_array[atoi(row[0])]->gender = atoi(row[6]);
						npc_type_array[atoi(row[0])]->texture = atoi(row[7]);
						npc_type_array[atoi(row[0])]->helmtexture = atoi(row[8]);
						npc_type_array[atoi(row[0])]->size = atof(row[9]);
						npc_type_array[atoi(row[0])]->loottable_id = atoi(row[10]);
						npc_type_array[atoi(row[0])]->merchanttype = atoi(row[11]);
						npc_type_array[atoi(row[0])]->STR = 75;
						npc_type_array[atoi(row[0])]->STA = 75;
						npc_type_array[atoi(row[0])]->DEX = 75;
						npc_type_array[atoi(row[0])]->AGI = 75;
						npc_type_array[atoi(row[0])]->WIS = 75;
						npc_type_array[atoi(row[0])]->INT = 75;
						npc_type_array[atoi(row[0])]->CHA = 75;
						npc_type_array[atoi(row[0])]->banish = atoi(row[12]);
						npc_type_array[atoi(row[0])]->min_dmg = atoi(row[13]);
						npc_type_array[atoi(row[0])]->max_dmg = atoi(row[14]);
						strcpy(npc_type_array[atoi(row[0])]->npc_attacks,row[15]);
						strcpy(npc_type_array[atoi(row[0])]->npc_spells,row[16]);
						Sleep(0);
					}
					mysql_free_result(result);
					cout << "NPCs loaded - using old database format" << endl;
				}
				else
				{
					cerr << "Error in LoadNPCTypes query '" << query << "' " << errbuf << endl;
					delete[] query;
					return false;
				}
			}
		}
		else
		{
			mysql_free_result(result);
		}
	}
	else
	{
		cerr << "Error in LoadNPCTypes query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	
	return true;
}

const NPCType* Database::GetNPCType(uint32 id) {
	if (npc_type_array && id <= max_npc_type)
		return npc_type_array[id]; 
	else
		return 0;
}
#endif

#ifndef SHAREMEM
void Database::LoadAItem(int item_id, unsigned int* texture, unsigned int* color)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	Item_Struct tempitem;
	MakeAnyLenString(&query, "SELECT raw_data FROM items where id=%d",item_id);
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		delete[] query;
		while((row = mysql_fetch_row(result)))
		{
			unsigned long* lengths;
			lengths = mysql_fetch_lengths(result);
			if (lengths[0] == sizeof(Item_Struct))
			{
				//tempitem=row[0];
				memcpy(&tempitem, row[0], sizeof(Item_Struct));
				*texture=tempitem.common.material;
				*color=tempitem.common.color;
			}
			else
			{
			// TODO: Invalid item length in database
			}
			Sleep(0);
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in LoadAItem query '" << query << "' " << errbuf << endl;
		delete[] query;
		//return false;
	}
	
	//return tempitemptr;
}
#endif

bool Database::SaveItemToDatabase(Item_Struct* ItemToSave)
{
	// Insert the modified item back into the database
	char Query[sizeof(Item_Struct)*2+1 + 64];
	char EscapedText[sizeof(Item_Struct)*2+1];

	char errbuf[MYSQL_ERRMSG_SIZE];
	MYSQL_RES 	*SQLResult;
//	long AffectedRows;

	if(mysql_real_escape_string(&mysql, EscapedText, (const char *)ItemToSave, sizeof(Item_Struct)))
	{
		sprintf(Query, "UPDATE items SET raw_data = '%s' WHERE id = %d\n", EscapedText, ItemToSave->item_nr);

		if(RunQuery(Query, strlen(Query), errbuf, &SQLResult))
		{
//			dpf("Affected rows = %d", AffectedRows);
			return(true);
		}
	}

	//dpf("Update failed");
	return(false);
}

bool Database::LoadZoneNames() {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(zoneidnumber) FROM zone");
	
	if (RunQuery(query, strlen(query), errbuf, &result)) {
		safe_delete(query);
		row = mysql_fetch_row(result);
		if (row != 0 && row[0] != 0)
		{ 
			max_zonename = atoi(row[0]);
			zonename_array = new char*[max_zonename+1];
			for(unsigned int i=0; i<max_zonename; i++) {
				zonename_array[i] = 0;
			}
			mysql_free_result(result);
			
			MakeAnyLenString(&query, "SELECT zoneidnumber, short_name FROM zone");
			if (RunQuery(query, strlen(query), errbuf, &result)) {
				delete[] query;
				while((row = mysql_fetch_row(result))) {
					zonename_array[atoi(row[0])] = new char[strlen(row[1]) + 1];
					strcpy(zonename_array[atoi(row[0])], row[1]);
					Sleep(0);
				}
				mysql_free_result(result);
			}
			else {
				cerr << "Error in LoadZoneNames query '" << query << "' " << errbuf << endl;
				delete[] query;
				return false;
			}
		}
		else {
			mysql_free_result(result);
		}
	}
	else {
		cerr << "Error in LoadZoneNames query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	return true;
}

bool Database::SetItemAtt(char* att, char * value, unsigned int ItemIndex) {
#ifndef SHAREMEM
	if (att && value && ItemIndex) {
		//item info
		if (strstr(att,"name")) {
			strcpy(item_array[ItemIndex]->name,value);
		}
		else if (strstr(att, "lore")) {
			strcpy(item_array[ItemIndex]->lore,value);
		}
		else if (strstr(att,"idfile")) {
			strcpy(item_array[ItemIndex]->idfile,value);
		}
		else if (strstr(att, "flag")) {
			item_array[ItemIndex]->flag = atoi(value);
		}
		else if (strstr(att, "weight")) {
			item_array[ItemIndex]->weight = atoi(value);
		}
		else if (strstr(att, "nosave")) {
			item_array[ItemIndex]->nodrop = atoi(value);
		}
		else if (strstr(att, "nodrop")) {
			item_array[ItemIndex]->nosave = atoi(value);
		}
		else if (strstr(att, "size")) {
			item_array[ItemIndex]->size = atoi(value);
		}
		else if (strstr(att, "type")) {
			item_array[ItemIndex]->type = atoi(value);
		}
		else if (strstr(att, "icon")) {
			item_array[ItemIndex]->icon_nr = atoi(value);
		}
		else if (strstr(att, "equipableSlots")) {
			item_array[ItemIndex]->equipableSlots = atoi(value);
		}
		//item stats
		else if (strstr(att, "str")) {
			item_array[ItemIndex]->common.STR = atoi(value);
		}
		else if (strstr(att, "sta")) {
			item_array[ItemIndex]->common.STA = atoi(value);
		}
		else if (strstr(att, "cha")) {
			item_array[ItemIndex]->common.CHA = atoi(value);
		}
		else if (strstr(att, "dex")) {
			item_array[ItemIndex]->common.DEX = atoi(value);
		}
		else if (strstr(att, "int")) {
			item_array[ItemIndex]->common.INT = atoi(value);
		}
		else if (strstr(att, "agi")) {
			item_array[ItemIndex]->common.AGI = atoi(value);
		}
		else if (strstr(att, "wis")) {
			item_array[ItemIndex]->common.WIS = atoi(value);
		}
		else if (strstr(att, "mr")) {
			item_array[ItemIndex]->common.MR = atoi(value);
		}
		else if (strstr(att, "fr")) {
			item_array[ItemIndex]->common.FR = atoi(value);
		}
		else if (strstr(att, "cr")) {
			item_array[ItemIndex]->common.CR = atoi(value);
		}
		else if (strstr(att, "dr")) {
			item_array[ItemIndex]->common.DR = atoi(value);
		}
		else if (strstr(att, "pr")) {
			item_array[ItemIndex]->common.PR = atoi(value);
		}
		else if (strstr(att, "hp")) {
			item_array[ItemIndex]->common.HP = atoi(value);
		}
		else if (strstr(att, "mana")) {
			item_array[ItemIndex]->common.MANA = atoi(value);
		}
		else if (strstr(att, "ac")) {
			item_array[ItemIndex]->common.AC = atoi(value);
		}
		else if (strstr(att, "material")) {
			item_array[ItemIndex]->common.material = atoi(value);
		}
		else if (strstr(att, "damage")) {
			item_array[ItemIndex]->common.damage = atoi(value);
		}
		else if (strstr(att, "delay")) {
			item_array[ItemIndex]->common.delay = atoi(value);
		}
		else if (strstr(att, "effect")) {
			item_array[ItemIndex]->common.effecttype0 = atoi(value);
		}
		else if (strstr(att,"spellID")) {
			item_array[ItemIndex]->common.spellId0 = atoi(value);
		}
		else if (strstr(att,"color")) {
			item_array[ItemIndex]->common.color = atoi(value);
		}
		else if (strstr(att,"classes")) {
			uint16 tv = 0;
			if (strstr(value,"warrior"))
				tv += warrior_1;
			if (strstr(value,"paladin"))
				tv += paladin_1;
			if (strstr(value,"shadow"))
				tv += shadow_1;
			if (strstr(value,"ranger"))
				tv += ranger_1;
			if (strstr(value,"rogue"))
				tv += rogue_1;
			if (strstr(value,"monk"))
				tv += monk_1;
			if (strstr(value,"beastlord"))
				tv += beastlord_1;
			if (strstr(value,"wizard"))
				tv += wizard_1;
			if (strstr(value,"enchanter"))
				tv += enchanter_1;
			if (strstr(value,"mage"))
				tv += mage_1;
			if (strstr(value,"necromancer"))
				tv += necromancer_1;
			if (strstr(value,"shaman"))
				tv += shaman_1;
			if (strstr(value,"cleric"))
				tv += cleric_1;
			if (strstr(value,"bard"))
				tv += bard_1;
			if (strstr(value,"druid"))
				tv += druid_1;
			if (strstr(value,"all"))
				tv += call_1;
			item_array[ItemIndex]->common.classes = tv;
		}
		else if (strstr(att,"races")) {
			uint16 tv = 0;
			if (strstr(value,"human"))
				tv += human_1;
			if (strstr(value,"barbarian"))
				tv += barbarian_1;
			if (strstr(value,"erudite"))
				tv += erudite_1;
			if (strstr(value,"woodelf"))
				tv += woodelf_1;
			if (strstr(value,"highelf"))
				tv += highelf_1;
			if (strstr(value,"darkelf"))
				tv += darkelf_1;
			if (strstr(value,"halfelf"))
				tv += halfelf_1;
			if (strstr(value,"dwarf"))
				tv += dwarf_1;
			if (strstr(value,"troll"))
				tv += troll_1;
			if (strstr(value,"ogre"))
				tv += ogre_1;
			if (strstr(value,"halfling"))
				tv += halfling_1;
			if (strstr(value,"gnome"))
				tv += gnome_1;
			if (strstr(value,"iksar"))
				tv += iksar_1;
			if (strstr(value,"vahshir"))
				tv += vahshir_1;
			if (strstr(value,"all"))
				tv += rall_1;			
			item_array[ItemIndex]->common.normal.races = tv;
		}
		SaveItemToDatabase(item_array[ItemIndex]);
return true;
	}
	return false;
#else
	return false;
#endif
}

int32 Database::GetZoneID(const char* zonename) {
	if (zonename_array == 0)
		return 0;
	if (zonename == 0)
		return 0;
	for (unsigned int i=0; i<=max_zonename; i++) {
		if (zonename_array[i] != 0 && strcasecmp(zonename_array[i], zonename) == 0) {
			return i;
		}
	}
	return 0;
}

const char* Database::GetZoneName(int32 zoneID, bool ErrorUnknown) {
	if (zonename_array == 0) {
		if (ErrorUnknown)
			return "UNKNOWN";
		else
			return 0;
	}
	if (zoneID <= max_zonename) {
		if (zonename_array[zoneID])
			return zonename_array[zoneID];
		else {
			if (ErrorUnknown)
				return "UNKNOWN";
			else
				return 0;
		}
	}
	if (ErrorUnknown)
		return "UNKNOWN";
	else
		return 0;
}

bool Database::CheckNameFilter(const char* name) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT count(*) FROM name_filter WHERE '%s' like name", name), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			if (row[0] != 0) {
				if (atoi(row[0]) == 0) {
					mysql_free_result(result);
					return false;
				}
			}
		}
		mysql_free_result(result);
		return true;
	}
	else
	{
		cerr << "Error in CheckNameFilter query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

bool Database::AddToNameFilter(const char* name) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO name_filter (name) values ('%s')", name), errbuf, 0, &affected_rows)) {
		cerr << "Error in AddToNameFilter query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

int32 Database::GetAccountIDFromLSID(int32 lsaccount_id) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM account WHERE lsaccount_id=%i", lsaccount_id), errbuf, &result))
	{
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int32 account_id = atoi(row[0]);
			mysql_free_result(result);
			return account_id;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetAccountIDFromLSID query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

bool Database::CreateSpawn2(int32 spawngroup, const char* zone, float heading, float x, float y, float z, int32 respawn, int32 variance)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

//	if(GetInverseXY()==1) {
//		float temp=x;
//		x=y;
//		y=temp;
//	}
	if (RunQuery(query, MakeAnyLenString(&query, "INSERT INTO spawn2 (spawngroupID,zone,x,y,z,heading,respawntime,variance, fixedz) Values (%i, '%s', %f, %f, %f, %f, %i, %i,1)", spawngroup, zone, x, y, z, heading, respawn, variance), errbuf, 0, &affected_rows)) {
		delete[] query;
		if (affected_rows == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	else {
		cerr << "Error in CreateSpawn2 query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return false;
}
int32	Database::GetMerchantData(int32 merchantid, int32 slot)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT item FROM merchantlist WHERE merchantid=%d and slot=%d", merchantid, slot), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]);
			mysql_free_result(result);
			return tmp;
		}
	}
	else {
		cerr << "Error in GetMerchantData query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}
int32	Database::GetMerchantListNumb(int32 merchantid)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT item FROM merchantlist WHERE merchantid=%d", merchantid), errbuf, &result)) {
		delete[] query;
		int32 tmp = mysql_num_rows(result);
		mysql_free_result(result);
		return tmp;
	}
	else {
		cerr << "Error in GetMerchantListNumb query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}

bool Database::UpdateName(const char* oldname, const char* newname) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32	affected_rows = 0;

	cout << "Renaming " << oldname << " to " << newname << "..." << endl;
	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE character_ SET name='%s' WHERE name='%s';", newname, oldname), errbuf, 0, &affected_rows)) {
		delete[] query;
		return false;
	}
	delete[] query;

	if (affected_rows == 0)
	{
		return false;
	}

	return true;
}

// If the name is used or an error occurs, it returns false, otherwise it returns true
bool Database::CheckUsedName(char* name)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
    MYSQL_RES *result;
	//if (strlen(name) > 15)
	//	return false;
	if (!RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM character_ where name='%s'", name), errbuf, &result)) {
		cerr << "Error in CheckUsedName query '" << query << "' " << errbuf << endl;
		if (query != 0)
			delete[] query;
		return false;
	}
	else { // It was a valid Query, so lets do our counts!
		int32 tmp = mysql_num_rows(result);
		mysql_free_result(result);
		if (tmp > 0) // There is a Name!  No change (Return False)
			return false;
		else // Everything is okay, so we go and do this.
			return true;
	}
}
bool Database::GetTradeRecipe(Combine_Struct* combin,int16 usedskill, int16* product, int16* skillneeded)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    MYSQL_RES *result;
    MYSQL_ROW row;
	char buf1[2000];
	char buf2[200];

	int32 tmp1 = 0;
	int32 tmp2 = 0;
	int32 check = 0;
	for (int i=0;i != 10; i++)
	{
		if (combin->iteminslot[i] != 0xFFFF)
		{
			if (tmp1 == 0)
				tmp1 = snprintf(buf1,200,"SELECT skillneeded,product,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10 FROM tradeskillrecipe WHERE ");
			else
			{
				tmp2 = snprintf(buf2,5, " AND ");
				memcpy(&buf1[tmp1],&buf2,tmp2);
				tmp1 = tmp1 + tmp2;
			}
					// if there is a better way to make this query tell me :)
			tmp2 = snprintf(buf2,200, "(i1 = %i or i2 = %i or i3 = %i or i4 = %i or i5= %i or i6 = %i or i7 = %i or i8 = %i or i9 = %i or i10 = %i)"
				,combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i],combin->iteminslot[i]);
			memcpy(&buf1[tmp1],&buf2,tmp2);
			tmp1 = tmp1 + tmp2;
			check = check + combin->iteminslot[i];
			const Item_Struct* item = GetItem(combin->iteminslot[i]);
			cout << "Item: " << item->name << endl;
		}
	}
	tmp2 = snprintf(buf2,50, " AND tradeskill = %i",usedskill);
	memcpy(&buf1[tmp1],&buf2,tmp2);
	tmp1 = tmp1 + tmp2;
	buf1[tmp1] = 0;
	//cout << "EndQuery: " << buf1 << endl;	
	if (RunQuery(buf1, tmp1, errbuf, &result)) {
		tmp2 =mysql_num_rows(result);
		if (tmp2 == 1)
		{			
			row = mysql_fetch_row(result);			
			int32 check2 = 0;	//just to make sure that quantity is correct)
			for (int i=2;i != 12;i++)
				check2 = check2 + atoi(row[i]); 
			if (check2 != check)
			{
				mysql_free_result(result);
				return false;
			}	
			*skillneeded = atoi(row[0]);
			*product = atoi(row[1]);
			mysql_free_result(result);
			return true;
		}
		else if (tmp2 == 0)
		{
			mysql_free_result(result);
			return false;
		}
		else
			if (tmp2 > 1)
			{
				cout << "Combine error: Recipe is not unique!" << endl;
				mysql_free_result(result);
				return false;
			}
	}
	else {
		cerr << "Error in GetTradeRecept query '" << buf2 << "' " << errbuf << endl;
	}	
	return false;
}

char* Database::GetBook(char txtfile[14])
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	char* txtout = 0;
	if (strlen(txtfile) > 14)
		return txtout;
	if (!RunQuery(query, MakeAnyLenString(&query, "SELECT txtfile FROM books where name='%s'", txtfile), errbuf, &result)) {
		cerr << "Error in GetBook query '" << query << "' " << errbuf << endl;
		if (query != 0)
			delete[] query;
		return txtout;
	}
	else {
		if (mysql_num_rows(result) == 0) {
			mysql_free_result(result);
			return txtout;
		}
		else {
			row = mysql_fetch_row(result);
			mysql_free_result(result);
			txtout = (char*) row[0];
			return txtout;
		}
	}
}

bool Database::UpdateZoneSafeCoords(const char* zonename, float x=0, float y=0, float z=0) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE zone SET safe_x='%f', safe_y='%f', safe_z='%f' WHERE short_name='%s';", x, y, z, zonename), errbuf, 0, &affected_rows)) {
		delete[] query;
		return false;
	}
	delete[] query;

	if (affected_rows == 0)
	{
		return false;
	}

	return true;
}
int8 Database::GetServerType()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	MYSQL_RES *result;
	MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT value FROM variables WHERE varname='ServerType'"), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int8 ServerType = atoi(row[0]);
			mysql_free_result(result);
			return ServerType;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{

		cerr << "Error in GetServerType query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return 0;

}

int8 Database::GetUseCFGSafeCoords()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	MYSQL_RES *result;
	MYSQL_ROW row;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT value FROM variables WHERE varname='UseCFGSafeCoords'"), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			int8 usecoords = atoi(row[0]);
			mysql_free_result(result);
			return usecoords;
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{

		cerr << "Error in GetUseCFGSafeCoords query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	return 0;

}

bool Database::MoveCharacterToZone(char* charname, char* zonename) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "UPDATE character_ SET zonename = '%s' WHERE name='%s'", zonename, charname), errbuf, 0,&affected_rows)) {
		cerr << "Error in MoveCharacterToZone query '" << query << "' " << errbuf << endl;
		return false;
	}
	delete[] query;

	if (affected_rows == 0)
	{
		return false;
	}

	return true;
}

int8 Database::CopyCharacter(const char* oldname, const char* newname, int8 acctid) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	MYSQL_RES *result;
	MYSQL_ROW row;
	PlayerProfile_Struct* pp;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT profile, guild, guildrank FROM character_ WHERE name='%s'", oldname), errbuf, &result)) {
		delete[] query;
		//if (mysql_num_rows(result) == 3)
		//{
			row = mysql_fetch_row(result);
			pp = (PlayerProfile_Struct*)row[0];
//			char* guild = row[1];
//			char* guildrank = row[2];
			strcpy(pp->name,newname);
			mysql_free_result(result);
			//return usecoords;
		//}
		//else
		//{
		//	mysql_free_result(result);
		//	return 0;
		//}
		//mysql_free_result(result);
	}
	else
	{

		cerr << "Error in CopyCharacter read query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}
	int32	affected_rows = 0;
	char query2[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end=query2;
	end += sprintf(end, "INSERT INTO character_ SET zonename=\'%s\', x = %f, y = %f, z = %f, profile=",GetZoneName(pp->current_zone), pp->x, pp->y, pp->z);
    *end++ = '\'';
    end += DoEscapeString(end, (char*) pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end,", account_id=%d, name='%s'", acctid, newname);
	//if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO character_ SET name='%s', account_id='%d', profile='%s', guild='%s', guildrank='%s', x='%s', y='%s', z='%s', zonename='%s'", newname, acctid, pp, guild, guildrank, x, y, z, zonename), errbuf, 0,&affected_rows)) {
	//	cerr << "Error in CopyCharacter write query '" << query << "' " << errbuf << endl;
	//	return 0;
	//}
	if (!RunQuery(query2, (int32) (end - query2), errbuf, 0, &affected_rows)) {
        cerr << "Error in CreateCharacter query '" << query << "' " << errbuf << endl;
		return 0;
    }

	if (affected_rows == 0) {
		return 0;
	}

	delete[] query;

	return 1;
}

/*
	Get the name of the alternate advancement skill with the given 'index'.
	Return true if the name was found, otherwise false.
	False will also be returned if there is a database error.
*/
int32 Database::GetAASkillVars(int32 skill_id, char* name_buf, int *cost, int *max_level)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	unsigned long* lengths;
	unsigned long len = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name, cost, max_level FROM altadv_vars WHERE skill_id=%i", skill_id), errbuf, &result)) {
		delete[] query;
    *name_buf = 0;
    *cost = 0;
    *max_level = 0;
		if (mysql_num_rows(result) == 1) {	
			row = mysql_fetch_row(result);
			lengths = mysql_fetch_lengths(result);
		  len = result->lengths[0];
  		strcpy(name_buf, row[0]);  // memcpy(name_buf, row[0], len);
      *cost = atoi(row[1]);
      *max_level = atoi(row[2]);
    } else {
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
		return len;
  } else {
		cerr << "Error in GetAASkillVars '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	//return true;
}

/*
	Update the player alternate advancement table for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::SetPlayerAlternateAdv(int32 account_id, char* name, PlayerAA_Struct* aa)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(PlayerAA_Struct)*2+1];
	char* end = query;

	//if (strlen(name) > 15)
	//	return false;

	/*for (int i=0; i< 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}*/

	
	end += sprintf(end, "UPDATE character_ SET alt_adv=\'");
  end += DoEscapeString(end, (char*)aa, sizeof(PlayerAA_Struct));
  *end++ = '\'';
  end += sprintf(end," WHERE account_id=%d AND name='%s'", account_id, name);

	int32 affected_rows = 0;
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in SetPlayerAlternateAdv query " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
}

/*
	Get the player alternate advancement table for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
int32 Database::GetPlayerAlternateAdv(int32 account_id, char* name, PlayerAA_Struct* aa)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	/*for (int i=0; i< 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}*/

	unsigned long* lengths;
  unsigned long len = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT alt_adv FROM character_ WHERE account_id=%i AND name='%s'", account_id, name), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {	
			row = mysql_fetch_row(result);
			lengths = mysql_fetch_lengths(result);
      len = result->lengths[0];
			//if (lengths[0] == sizeof(PlayerAA_Struct)) {
      if(row[0] && lengths[0] >= sizeof(PlayerAA_Struct)) {
        memcpy(aa, row[0], sizeof(PlayerAA_Struct));
      } else { // let's support ghetto-ALTERed databases that don't contain any data in the alt_adv column
        memset(aa, 0, sizeof(PlayerAA_Struct));
        len = sizeof(PlayerAA_Struct);
      }
			//}
			//else {
				//cerr << "Player alternate advancement table length mismatch in GetPlayerAlternateAdv" << endl;
				//mysql_free_result(result);
				//return false;
			//}
		}
		else {
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
//		unsigned long len=result->lengths[0];
		return len;
	}
	else {
		cerr << "Error in GetPlayerAlternateAdv query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	//return true;
}

bool Database::SetHackerFlag(const char* accountname, const char* charactername, const char* hacked) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO hackers(account,name,hacked) values('%s','%s','%s')", accountname, charactername, hacked), errbuf, 0,&affected_rows)) {
		cerr << "Error in SetHackerFlag query '" << query << "' " << errbuf << endl;
		return false;
	}
	delete[] query;

	if (affected_rows == 0)
	{
		return false;
	}

	return true;
}

int32 Database::GetServerFilters(char* name, ServerSideFilters_Struct *ssfs) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;


	unsigned long* lengths;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT serverfilters FROM account WHERE name='%s'", name), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {	
			row = mysql_fetch_row(result);
			lengths = mysql_fetch_lengths(result);
			if (lengths[0] == sizeof(ServerSideFilters_Struct)) {
				memcpy(ssfs, row[0], sizeof(ServerSideFilters_Struct));
			}
			else {
				cerr << "Player profile length mismatch in ServerSideFilters" << endl;
				mysql_free_result(result);
				return 0;
			}
		}
		else {
			mysql_free_result(result);
			return 0;
		}
		int32 len = lengths[0];
		mysql_free_result(result);
		return len;
	}
	else {
		cerr << "Error in ServerSideFilters query '" << query << "' " << errbuf << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

bool Database::SetServerFilters(char* name, ServerSideFilters_Struct *ssfs) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char query[256+sizeof(ServerSideFilters_Struct)*2+1];
	char* end = query;

	//if (strlen(name) > 15)
	//	return false;

	/*for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}*/


		end += sprintf(end, "UPDATE account SET serverfilters=");
	*end++ = '\'';
    end += DoEscapeString(end, (char*)ssfs, sizeof(ServerSideFilters_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE name='%s'", name);

	int32 affected_rows = 0;
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
        cerr << "Error in SetServerSideFilters query " << errbuf << endl;
		return false;
    }

	if (affected_rows == 0) {
		return false;
	}

	return true;
}