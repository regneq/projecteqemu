/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef PACKET_DUMP_FILE_H
#define PACKET_DUMP_FILE_H

#include <iostream.h>

#include "../common/types.h"

class APPLAYER;

void FileDumpPacketAscii(char* filename, uchar* buf, int32 size, int32 cols=16, int32 skip=0);
void FileDumpPacketHex(char* filename, uchar* buf, int32 size, int32 cols=16, int32 skip=0);
void FileDumpPacketHex(char* filename, APPLAYER* app);
void FileDumpPacketAscii(char* filename, APPLAYER* app);
void FileDumpPacket(char* filename, uchar* buf, int32 size);
void FileDumpPacket(char* filename, APPLAYER* app);
void FilePrintLine(char* filename, bool prefix_timestamp = false, char* text = 0, ...);
void FilePrint(char* filename, bool newline = true, bool prefix_timestamp = false, char* text = 0, ...);
#endif

