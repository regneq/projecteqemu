#ifndef EMuShareMem_H
#define EMuShareMem_H

#include <windows.h>
#include "../common/eq_packet_structs.h"
#include "../zone/zonedump.h"

typedef bool(*CALLBACK_DBLoadItems)(int16, int16);

typedef bool(*DLLFUNC_DLLLoadItems)(const CALLBACK_DBLoadItems, int32, int16, int16);
typedef const Item_Struct*(*DLLFUNC_GetItem)(uint16);
typedef const Item_Struct*(*DLLFUNC_IterateItems)(uint16*);
typedef bool(*DLLFUNC_AddItem)(int16, const Item_Struct*);
struct ItemsDLLFunc_Struct {
	DLLFUNC_DLLLoadItems DLLLoadItems;
	DLLFUNC_GetItem GetItem;
	DLLFUNC_IterateItems IterateItems;
	DLLFUNC_AddItem cbAddItem;
};

typedef bool(*CALLBACK_DBLoadNPCTypes)(int32, int32);

typedef bool(*DLLFUNC_DLLLoadNPCTypes)(const CALLBACK_DBLoadNPCTypes, int32, int32, int32);
typedef const NPCType*(*DLLFUNC_GetNPCType)(int32);
typedef bool(*DLLFUNC_AddNPCType)(int32, const NPCType*);
struct NPCTypesDLLFunc_Struct {
	DLLFUNC_DLLLoadNPCTypes DLLLoadNPCTypes;
	DLLFUNC_GetNPCType GetNPCType;
	DLLFUNC_AddNPCType cbAddNPCType;
};

class LoadEMuShareMemDLL {
public:
	LoadEMuShareMemDLL();
	~LoadEMuShareMemDLL();

	inline bool	Loaded() { return (hDLL != NULL); }
	bool	Load();
	void	Unload();

	ItemsDLLFunc_Struct		Items;
	NPCTypesDLLFunc_Struct	NPCTypes;
private:
	HINSTANCE hDLL;
};

#endif