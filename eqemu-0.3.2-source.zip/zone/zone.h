#ifndef ZONE_H
#define ZONE_H

#define ZONE_AUTOSHUTDOWN_DELAY		5000

#include "../common/Mutex.h"
#include "../common/linked_list.h"
#include "../common/types.h"
#include "../common/database.h"
//#include "spawn.h"
#include "mob.h"
#include "zonedump.h"
class Map;

struct ZonePoint {
	float x;
	float y;
	float z;
	float target_x;
	float target_y;
	float target_z;
	char  target_zone[16];
};

extern EntityList entity_list;

class Zone
{
public:
	static bool Zone::Bootup(char* zone_name);
	static void Zone::Shutdown(bool quite = false);
	Zone(int32 in_zoneid, char* in_short_name, char* in_address, int16 in_port);
	~Zone();

	bool	Init();
	bool	LoadZoneCFG(char* filename, bool DontLoadDefault = false);
	bool	SaveZoneCFG(char* filename);
	char*	GetAddress()	{ return address; }
	char*	GetLongName()	{ return long_name; }
	char*	GetFileName()	{ return file_name; }
	char*	GetShortName()	{ return short_name; }
	int32	GetZoneID()		{ return zoneid; }
	int16	GetPort()		{ return port; }
	float	safe_x()		{ return psafe_x; }
	float	safe_y()		{ return psafe_y; }
	float	safe_z()		{ return psafe_z; }

	int32	CountSpawn2();
	ZonePoint* GetClosestZonePoint(float x, float y, float z, char* to_name);
	ZonePoint* GetClosestZonePoint(float x, float y, float z, int32	to);
	SpawnGroupList* spawn_group_list;

//	NPCType* GetNPCType(uint16 id);
//	Item_Struct* GetItem(uint16 id);

	bool	Process();
	void	DumpAllSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index);
	int32	DumpSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index, Spawn2* spawn2);

	void	Depop();
	void	Repop(int32 delay = 0);
	void	SpawnStatus(Mob* client);
	void	StartShutdownTimer(int32 set_time = ZONE_AUTOSHUTDOWN_DELAY);

	void	AddAggroMob()		{aggroedmobs++;}
	void	DelAggroMob()		{aggroedmobs--;}
	bool    AggroLimitReached()	{return (aggroedmobs>10)?true:false;} // change this value, to allow more NPCs to autoaggro
	sint32	MobsAggroCount()			{return aggroedmobs;}

	Map*	map;
	NewZone_Struct	newzone_data;
//	uchar	zone_header_data[142];
	int8	zone_weather;
protected:
	friend class database;
	LinkedList<Spawn2*> spawn2_list; // CODER new spawn list
	sint32	aggroedmobs;
private:
	int32	zoneid;
	char*	short_name;
	char	file_name[16];
	char*	long_name;
	char*	address;
	int16	port;
	float	psafe_x, psafe_y, psafe_z;

	Timer*	autoshutdown_timer;

//	LinkedList<Spawn*> spawn_list;
	LinkedList<ZonePoint*> zone_point_list;
	
	Mutex	MZoneLock;
};

#endif

