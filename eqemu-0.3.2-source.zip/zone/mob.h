#ifndef MOB_H
#define MOB_H

#include "entity.h"

struct Buffs_Struct {
	int16	spellid;
	int8	casterlevel;
	int16	casterid;		// Maybe change this to a pointer sometime, but gotta make sure it's 0'd when it no longer points to anything
	int8	durationformula;
	int32	ticsremaining;
};

struct StatBonuses {
	sint16	AC;
	sint32	HP;
	sint16	Mana;
	sint16	ATK;
	sint16	STR;
	sint16	STA;
	sint16	DEX;
	sint16	AGI;
	sint16	INT;
	sint16	WIS;
	sint16	CHA;
	sint16	MR;
	sint16	FR;
	sint16	CR;
	sint16	PR;
	sint16	DR;
	sint16	DamageShield;
	int8	DamageShieldType;
};

class Mob : public Entity
{
public:
	static int8 Mob::GetDefaultGender(int8 in_race, int8 in_gender = 0xFF);
	static sint32 CalcPetHp(int8 levelb, int8 classb, int8 STA = 75);

	void RogueBackstab(Mob* other, Item_Struct *weapon1, int8 bs_skill);
	bool BehindMob(Mob* other, float playerx, float playery);

	Mob(char*   in_name,
	    char*   in_lastname,
	    sint32  in_cur_hp,
	    sint32  in_max_hp,
	    int8    in_gender,
	    int8    in_race,
	    int8    in_class,
	    int8    in_deity,
	    int8    in_level,
		int32   in_npctype_id, // rembrant, Dec. 20, 2001
		int8*	in_skills, // socket 12-29-01
		float	in_size,
		float	in_walkspeed,
		float	in_runspeed,
	    float   in_heading,
	    float	in_x_pos,
	    float	in_y_pos,
	    float	in_z_pos,

	    int8    in_light,
	    int8*   in_equipment,
		int8	in_texture,
		int8	in_helmtexture,
		int16	in_ac,
		int16	in_atk,
		int8	in_str,
		int8	in_sta,
		int8	in_dex,
		int8	in_agi,
		int8	in_int,
		int8	in_wis,
		int8	in_cha,
		int8	in_haircolor,
		int8	in_beardcolor,
		int8	in_eyecolor1, // the eyecolors always seem to be the same, maybe left and right eye?
		int8	in_eyecolor2,
		int8	in_hairstyle,
		int8	in_title, //Face Overlay? (barbarian only)
		int8	in_luclinface, // and beard);
		int16	in_fixedZ,
		int16	in_d_meele_texture1,
		int16	in_d_meele_texture2
	);
	virtual ~Mob();

	virtual bool IsMob() { return true; }

	void	TicProcess();
	virtual void SetLevel(uint8 in_level, bool command = false) { level = in_level; }

	virtual void SetSkill(int in_skill_num, int8 in_skill_id) { // socket 12-29-01
		skills[in_skill_num] = in_skill_id; }
	int8 GetSkill(int skill_num) { return skills[skill_num]; } // socket 12-29-01
	int8 GetEquipment(int item_num) { return equipment[item_num]; } // socket 12-30-01

	virtual void GoToBind() {}
	virtual void Attack(Mob* other, int Hand = 13) {}		// 13 = Primary (default), 14 = secondary
	virtual void Damage(Mob* from, sint32 damage, int16 spell_id, int8 attack_skill = 0x04)  {}
	virtual void Heal()  {}
	virtual void Death(Mob* killer, sint32 damage, int16 spell_id = 0xFFFF, int8 attack_skill = 0x04) {}
	virtual void SetHP(sint32 hp);
	void ChangeHP(Mob* other, sint32 amount, int16 spell_id = 0);
	void MonkSpecialAttack(Mob* other, int8 type);
	void DoAnim(const int animnum);

	void ChangeSize(float in_size);
	virtual void GMMove(float x, float y, float z, float heading = 0.01);
	void SendPosUpdate(bool SendToSelf = false);
	void MakeSpawnUpdate(SpawnPositionUpdate_Struct* spu);
	void CreateDespawnPacket(APPLAYER* app);
    void CreateSpawnPacket(APPLAYER* app, Mob* ForWho = 0);
	virtual void FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho);
	void CreateHPPacket(APPLAYER* app);

	void	DamageShield(Mob* other);
	bool	FindBuff(int16 spellid);
	bool	FindType(int8 type);
	int16	CalcPetLevel(int16 nlevel, int16 nclass);
	void	MakePet(char* pettype);
	void	MakePet(int8 in_level, int8 in_class, int16 in_race, int8 in_texture = 0, int8 in_pettype = 0, float in_size = 0);
	char*	GetRandPetName();

	int8	GetRace()			{ return race; }
	int8	GetGender()			{ return gender; }
	virtual int8	GetBaseRace()		{ return base_race; }
	virtual	int8	GetBaseGender()		{ return base_gender; }
	int8	GetDeity()			{ return deity; }
	int8	GetTexture()		{ return texture; }
	int8	GetHelmTexture()	{ return helmtexture; }
	int8	GetClass()			{ return class_; }
	int8	GetLevel()			{ return level; }
	char*	GetName()			{ return name; }
	Mob*	GetTarget()			{ return target; }
	void	SetTarget(Mob* mob)	{ target = mob; }
	int32	GetHPRatio()		{ return (int32)((float)cur_hp/max_hp*100); }
	virtual sint32	GetHP()			{ return cur_hp; }
	virtual sint32	GetMaxHP()		{ return max_hp; }
	virtual sint32	CalcMaxHP()		{ return max_hp = (base_hp  + itembonuses->HP + spellbonuses->HP); }

	virtual sint32	SetMana(sint32 amount);
	virtual sint32	GetMaxMana()	{ return max_mana; }
	virtual sint32	GetMana()		{ return cur_mana; }

	virtual int16	GetAC()		{ return AC + itembonuses->AC + spellbonuses->AC; } // Quagmire - this is NOT the right math
	virtual int16	GetATK()	{ return ATK + itembonuses->ATK + spellbonuses->ATK; }
	virtual sint16	GetSTR()	{ return STR + itembonuses->STR + spellbonuses->STR; }
	virtual sint16	GetSTA()	{ return STA + itembonuses->STA + spellbonuses->STA; }
	virtual sint16	GetDEX()	{ return DEX + itembonuses->DEX + spellbonuses->DEX; }
	virtual sint16	GetAGI()	{ return AGI + itembonuses->AGI + spellbonuses->AGI; }
	virtual sint16	GetINT()	{ return INT + itembonuses->INT + spellbonuses->INT; }
	virtual sint16	GetWIS()	{ return WIS + itembonuses->WIS + spellbonuses->WIS; }
	virtual sint16	GetCHA()	{ return CHA + itembonuses->CHA + spellbonuses->CHA; }

	void ShowStats(Client* client);
	void ShowBuffs(Client* client);
	int32 GetNPCTypeID()			{ return npctype_id; } // rembrant, Dec. 20, 2001

	float Dist(Mob*);
	float DistNoZ(Mob* other);
	float DistNoRoot(Mob*);
	float DistNoRootNoZ(Mob*); 

	float	GetX()				{ return x_pos; }
	float	GetY()				{ return y_pos; }
	float	GetZ()				{ return z_pos; }
	float	GetHeading()		{ return heading; }
	float	GetSize()			{ return size; }
	inline int32	LastChange() { return pLastChange; }

	virtual void Message(int32 type, char* message, ...) {} // fake so dont have to worry about typecasting
	void SpellProcess();
	void InterruptSpell();
	virtual void	CastSpell(int16 spell_id, int16 target_id, int16 slot = 10, int32 casttime = 0xFFFFFFFF);
	void SpellFinished(int16 spell_id, int32 target_id, int16 slot = 10, int16 mana_used = 0);
	void SpellOnTarget(int16 spell_id, Mob* spelltar);
	void SpellEffect(Mob* caster, int16 spell_id, int8 caster_level);
	void DoBuffTic(int16 spell_id, int32 ticsremaining, int8 caster_level, Mob* caster = 0);
	void BuffFade(int16 spell_id);
	void SendIllusionPacket(int8 in_race, int8 in_gender = 0xFF, int16 in_texture = 0xFFFF, int16 in_helmtexture = 0xFFFF, int8 in_haircolor = 0xFF, int8 in_beardcolor = 0xFF, int8 in_eyecolor1 = 0xFF, int8 in_eyecolor2 = 0xFF, int8 in_hairstyle = 0xFF, int8 in_title = 0xFF, int8 in_luclinface = 0xFF);
	void SendAppearancePacket(int32 type, int32 value, bool WholeZone = true);
	int8	GetAppearance()				{ return appearance; }	
	Mob*	GetPet();
	void	SetPet(Mob* newpet);
	Mob*	GetOwner();
	void	SetPetID(int16 NewPetID)	{ petid = NewPetID; }
	int16	GetPetID()					{ return petid;  }
	void	SetOwnerID(int16 NewOwnerID);
	int16	GetOwnerID()				{ return ownerid; }
	int8	GetPetType()				{ return typeofpet; }
	int16	FindSpell(int16 classp, int16 level, int8 type, int8 spelltype = 0); // 0=buff, 1=offensive, 2=helpful
	int16	CanUse(int16 spellid, int16 classa, int16 level);
	void	CheckBuffs();
	void	CheckPet();

	bool	invulnerable;
	bool	invisible;
	void	Spin();
	void	Kill();

	void	SetAttackTimer();
	void	SetHaste(int Haste) { HastePercentage = Haste; }
	int		GetHaste(void) { return(HastePercentage); }
	// Kaiyodo - new function prototypes for damage system
	int		GetWeaponDamageBonus(Item_Struct *Weapon);
	int		GetMonkHandToHandDamage(void);
	bool	CanThisClassDoubleAttack(void);
	bool	CanThisClassDuelWield(void);
	int		GetMonkHandToHandDelay(void);
	int8	GetClassLevelFactor();
	void	Mesmerize();
	bool	IsMezzed()	{ return mezzed;}
	bool	IsStunned() { return stunned; }
	void	BuffFadeByEffect(int8 effect);
	int16	GetErrorNumber()	{return adverrorinfo;}
protected:
	int32 pLastChange;
	void CalcSpellBonuses(StatBonuses* newbon);
	void CalcBonuses();

	char    name[64];
	char    lastname[70];

	sint32  cur_hp;
	sint32  max_hp;
	sint32	base_hp;
	sint32	cur_mana;
	sint32	max_mana;
	Buffs_Struct	buffs[15];
	StatBonuses*	itembonuses;
	StatBonuses*	spellbonuses;
	NPCType*		NPCTypedata;
	int16			petid;
	int16			ownerid;
	int8			typeofpet; // 0xFF = charmed

	int16	AC;
	int16	ATK;
	int8	STR;
	int8	STA;
	int8	DEX;
	int8	AGI;
	int8	INT;
	int8	WIS;
	int8	CHA;

	int8    gender;
	int16	race;
	int8	base_gender;
	int16	base_race;
	int8    class_;
	int16	deity;
	int8    level;
	int32   npctype_id; // rembrant, Dec. 20, 2001
	int8    skills[74];
	float	x_pos;
	float	y_pos;
	float	z_pos;
	float	heading;
	float	size;
	float	walkspeed;
	float	runspeed;
//	sint8   delta_x;
//	sint8   delta_y;
//	sint8   delta_z;
	sint8   delta_heading;
    sint32 delta_y:10,
           spacer1:1,
           delta_z:10,
           spacer2:1,
           delta_x:10;
	int32	guildeqid; // guild's EQ ID, 0-511, 0xFFFFFFFF = none

	int8    light;
	int8    equipment[9];
	int8	texture;
	int8	helmtexture;
	int16	fixedZ;
	int8    appearance; // 0 standing, 1 sitting, 2 ducking

	Mob*	target;
	Timer*	attack_timer;
	Timer*	tic_timer;
	Timer*	mana_timer;

	// Kaiyodo - Timer added for dual wield
	Timer * attack_timer_dw;

	Timer* spellend_timer;
	int16 casting_spell_id;
		
	
	bool	isinterrupted;
	bool	isattacked;
	int16 casting_spell_targetid;
	int16 casting_spell_slot;
	int16 casting_spell_mana;
	int8	haircolor;
	int8	beardcolor;
	int8	eyecolor1; // the eyecolors always seem to be the same, maybe left and right eye?
	int8	eyecolor2;
	int8	hairstyle;
	int8	title; //Face Overlay? (barbarian only)
	int8	luclinface; // and beard

	int16	d_meele_texture1;
	int16	d_meele_texture2;
	int HastePercentage;
	bool	mezzed;
	bool	stunned;
	bool	rooted;
	Timer* mezzed_timer;
	Timer*  stunned_timer;
	int16	adverrorinfo;
};

#endif

