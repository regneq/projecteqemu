#include "../common/debug.h"

#include <iostream.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQNetwork.h"
#include "../common/eq_packet_structs.h"
#include "../common/Mutex.h"

#include "net.h"
#include "client.h"
#include "zone.h"
#include "worldserver.h"
#include "spdat.h"
#include "../common/packet_dump_file.h"

NetConnection		net;
EntityList			entity_list;
WorldServer			worldserver;
int32				numclients = 0;
#ifdef CATCH_CRASH
	int8			error = 0;
#endif
GuildRanks_Struct	guilds[512];
char errorname[32];
int16 adverrornum = 0;
extern Zone* zone;
extern volatile bool ZoneLoaded;
EQNetworkServer eqns;
npcDecayTimes_Struct npcCorpseDecayTimes[100];
volatile bool RunLoops = true;
bool zoneprocess;
extern bool WorldLoopRunning;

#define SPDat_Location	"spdat.eff"
SPDat_Spell_Struct spells[SPDAT_RECORDS];
bool spells_loaded = false;

Database database;
#ifdef WIN32
	#include <process.h>
#else
	#include <pthread.h>
	#include "../common/unix.h"
#endif

void Shutdown();
void LoadSPDat();

int main(int argc, char** argv)
{
#ifdef _DEBUG
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	if (argc != 5)
	{
		cerr << "Usage: zone zone_name address port worldaddress" << endl;
		exit(0);
	}
	char* filename = argv[0];
	char* zone_name = argv[1];
	char* address = argv[2];
	int32 port = atoi(argv[3]);
	char* worldaddress = argv[4];

	if (strlen(address) <= 0)
	{
		cerr << "Invalid address" << endl;
		exit(0);
	}
	if (port <= 0)
	{
		cerr << "Bad port specified" << endl;
		exit(0);
	}
	if (strlen(worldaddress) <= 0)
	{
		cerr << "Invalid worldaddress" << endl;
		exit(0);
	}
	if (signal(SIGINT, CatchSignal) == SIG_ERR)
	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	#ifndef WIN32
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	#endif
	net.SaveInfo(address, port, worldaddress,filename);

	cout << "Loading zone names, items & NPCs...";
	database.LoadZoneNames();
	database.LoadItems();
	database.LoadNPCTypes();
	database.GetDecayTimes(npcCorpseDecayTimes);
	cout << "done." << endl;
	LoadSPDat();
	cout << "Loading guild ranks...";
	database.LoadGuilds(guilds);
	cout << "done." << endl;
	cout << "Loading faction data...";
	database.LoadFactionData();
	database.GetDecayTimes(npcCorpseDecayTimes);
	cout << "done." << endl;

	if (!worldserver.Init()) {
		cerr << "InitWorldServer failed" << endl;
	}

//	if (strcmp(zone_name, ".") == 0 || strcasecmp(zone_name, "sleep") == 0) {
			cout << "Entering sleep mode" << endl;
//	} else if (!ZoneBootup(zone_name)) {
//		cerr << "Zone bootup failed" << endl;
//		zone = 0;
//	}

	Timer InterserverTimer(INTERSERVER_TIMER); // does MySQL pings and auto-reconnect
	UpdateWindowTitle();
	bool worldwasconnected = worldserver.Connected();
	EQNetworkConnection* eqnc;
	while(RunLoops) {
		Timer::SetCurrentTime();
		while (eqnc = eqns.NewQueuePop()) {
			struct in_addr	in;
			in.s_addr = eqnc->GetrIP();
			cout << Timer::GetCurrentTime() << " New client from ip: " << inet_ntoa(in) << " port: " << ntohs(eqnc->GetrPort()) << endl;
			Client* client = new Client(eqnc);
			entity_list.AddClient(client);
		}
		if (worldserver.Connected()) {
#ifdef CATCH_CRASH
			try{
#endif
				worldserver.Process();
				worldwasconnected = true;
#ifdef CATCH_CRASH
			}
			catch(...){
				error = 1;
				adverrornum = worldserver.GetErrorNumber();
				worldserver.Disconnect();
				worldwasconnected = false;
			}
#endif			
		}
		else {
			if (worldwasconnected && ZoneLoaded)
				entity_list.ChannelMessageFromWorld(0, 0, 6, 0, 0, "WARNING: World server connection lost");
			worldwasconnected = false;
		}
		if (ZoneLoaded) {
			{	
#ifdef CATCH_CRASH
				try{
#endif
					entity_list.Process();
#ifdef CATCH_CRASH
				}
				catch(...){
					error = 4;
				}
				try{
#endif
					zoneprocess= zone->Process();
					if (!zoneprocess) {
						Zone::Shutdown();
					}
#ifdef CATCH_CRASH
				}
				catch(...){
					error = 2;
				}
#endif
			}
		}
		if (InterserverTimer.Check()
#ifdef CATCH_CRASH
			&& !error
#endif
			) {
#ifdef CATCH_CRASH
			try{
#endif
				InterserverTimer.Start();
				database.ping();
				entity_list.UpdateWho();
#ifdef CATCH_CRASH
			}
			catch(...)
			{
				error = 16;
				RunLoops = false;
			}
#endif
		}
#ifdef CATCH_CRASH
		if (error){
			RunLoops = false;
		}
#endif
		Sleep(1);
	}

#ifdef CATCH_CRASH
	if (error)
		FilePrint("eqemudebug.log",true,true,"Zone %i crashed. Errorcode: %i/%i. Current zone loaded:%s. Current clients:%i. Caused by: %s",net.GetZonePort(), error,adverrornum, zone->GetShortName(), numclients,errorname);
	try{
		entity_list.Message(0, 15, "ZONEWIDE_MESSAGE: This zone caused a fatal error and will shut down now. Your character will be restored to the last saved status. We are sorry for any inconvenience!");
	}
	catch(...){}
if (error){
#ifdef WIN32		
	ExitProcess(error);
#else	
	entity_list.Clear();
	safe_delete(zone);
#endif
}
#endif
	if (zone != 0
#ifdef CATCH_CRASH
		& !error
#endif
		)
		Zone::Shutdown(true);
	while ((WorldLoopRunning)
#ifdef CATCH_CRASH
		& !error
#endif
		) {
		Sleep(1);
	}
	//Fix for Linux world server problem.
	worldserver.Disconnect();
	return 0;
}

void CatchSignal(int sig_num) {
	cout << "Got signal " << sig_num << endl;
	RunLoops = false;
}

void Shutdown()
{
	Zone::Shutdown(true);
	RunLoops = false;
	worldserver.Disconnect();
//	safe_delete(worldserver);
	cout << "Shutting down..." << endl;
}

int32 NetConnection::GetIP()
{
	char     name[255+1];
	size_t   len = 0;
	hostent* host = 0;

	if (gethostname(name, len) < 0 || len <= 0)
	{
		return 0;
	}

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);
}

int32 NetConnection::GetIP(char* name)
{
	hostent* host = 0;

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);

}

void NetConnection::SaveInfo(char* address, int32 port, char* waddress, char* filename) {
	ZoneAddress = new char[strlen(address)+1];
	strcpy(ZoneAddress, address);
	ZonePort = port;
	WorldAddress = new char[strlen(waddress)+1];
	strcpy(WorldAddress, waddress);
	strcpy(ZoneFileName, filename);
}

NetConnection::~NetConnection() {
	if (ZoneAddress != 0)
		delete ZoneAddress;
	if (WorldAddress != 0)
		delete WorldAddress;
}

void LoadSPDat() {
	FILE *fp;
	for (int j = 0; j < SPDAT_RECORDS; j++)
		memset((char*) &spells[j], 0, sizeof(SPDat_Spell_Struct));

	if (fp = fopen(SPDat_Location, "rb"))
	{
//		if (_filelength(fp) != SPDAT_SIZE) {
//			cout << "SPDat wrong size ('" << SPDat_Location << "'), spells not loaded." << endl;
//		}
//		else
		{
			for (int i = 0; i < SPDAT_RECORDS; i++) {
				fread(&spells[i], sizeof(SPDat_Spell_Struct), 1, fp);
			}
			spells_loaded = true;
			cout << "Spells loaded from '" << SPDat_Location << "'." << endl;
		}
		fclose(fp);
	}
	else
		cout << "SPDat not found ('" << SPDat_Location << "'), spells not loaded." << endl;
}



void UpdateWindowTitle() {
#ifdef WIN32
	char tmp[500];
	if (zone)
		snprintf(tmp, sizeof(tmp), "%d: %s, %d clients", net.GetZonePort(), zone->GetShortName(), numclients);
	else
		snprintf(tmp, sizeof(tmp), "%d: sleeping", net.GetZonePort());
	SetConsoleTitle(tmp);
#endif
}
