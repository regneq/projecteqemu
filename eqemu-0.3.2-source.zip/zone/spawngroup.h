#ifndef SPAWNGROUP_H
#define SPAWNGROUP_H

#include "../common/linked_list.h"
#include "../common/types.h"

class SpawnEntry
{
public:
	SpawnEntry(uint32 in_NPCType, int in_chance );
	~SpawnEntry() { }
	uint32 NPCType;
	int chance;
};

class SpawnGroup
{
public:
	SpawnGroup(uint32 in_id, char* name );
	~SpawnGroup() { }
	uint32 GetNPCType();
	void AddSpawnEntry( SpawnEntry* newEntry );
	uint32 id;
private:
	char name_[64];
    LinkedList<SpawnEntry*> list_;
};

class SpawnGroupList
{
public:
	SpawnGroupList() {};
	~SpawnGroupList() {};

	void AddSpawnGroup(SpawnGroup* newGroup);
	SpawnGroup* GetSpawnGroup(uint32 id);
private:
    LinkedList<SpawnGroup*> list_;
};

#endif
