#ifndef VERSION_H
#define VERSION_H

#define CURRENT_CHAT_VERSION	"EqEmu 0.3.2-RC2 Chat Server - [Cauchemar]"
#define CURRENT_ZONE_VERSION	"EqEmu 0.3.2-RC2 Zoneserver - [Cauchemar]"
#define CURRENT_WORLD_VERSION   "EqEmu 0.3.2-RC2 Worldserver - [Cauchemar]"
#define CURRENT_VERSION			"0.3.2-Cauchemar"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
	#define LAST_MODIFIED	__TIME__
#else
	#define LAST_MODIFIED	__TIMESTAMP__
#endif

#endif

