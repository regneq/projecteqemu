/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "client.h"
#include "groups.h"
#include "spdat.h"
#include "PlayerCorpse.h"
#include "../common/packet_dump.h"
#include "../common/moremath.h"
#include "worldserver.h"
#include <math.h>
#ifndef WIN32
//	#include <pthread.h>
	#include <stdlib.h>
	#include "../common/unix.h"
#endif

extern Database database;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern WorldServer worldserver;

void ApplySpellsBonuses(int16 spell_id, int8 casterlevel, StatBonuses* newbon);
//sint32 CalcSpellValue(int8 formula, sint16 base, sint16 max, int8 caster_level);
void Mob::Spin() {
				APPLAYER* outapp = new APPLAYER(OP_Action,sizeof(Action_Struct));
				outapp->pBuffer[0] = 0x0B;
				outapp->pBuffer[1] = 0x0A;
				outapp->pBuffer[2] = 0x0B;
				outapp->pBuffer[3] = 0x0A;
				outapp->pBuffer[4] = 0xE7;
				outapp->pBuffer[5] = 0x00;
				outapp->pBuffer[6] = 0x4D;
				outapp->pBuffer[7] = 0x04;
				outapp->pBuffer[8] = 0x00;
				outapp->pBuffer[9] = 0x00;
				outapp->pBuffer[10] = 0x00;
				outapp->pBuffer[11] = 0x00;
				outapp->pBuffer[12] = 0x00;
				outapp->pBuffer[13] = 0x00;
				outapp->pBuffer[14] = 0x00;
				outapp->pBuffer[15] = 0x00;
				outapp->pBuffer[16] = 0x00;
				outapp->pBuffer[17] = 0x00;
				outapp->pBuffer[18] = 0xD4;
				outapp->pBuffer[19] = 0x43;
				outapp->pBuffer[20] = 0x00;
				outapp->pBuffer[21] = 0x00;
				outapp->pBuffer[22] = 0x00;
				outapp->pBuffer[23] = 0x00;
				outapp->priority = 5;
				CastToClient()->QueuePacket(outapp);
				delete outapp;
}

void Mob::SpellProcess() {								
	if (casting_spell_id != 0 && spellend_timer->Check()) {
		spellend_timer->Disable();

				Mob* tmob = entity_list.GetMob(casting_spell_targetid);
				if (tmob == 0)
				{
				InterruptSpell();
				return;	
				}

		SpellFinished(casting_spell_id, casting_spell_targetid, casting_spell_slot, casting_spell_mana);
	}
}

void Mob::CastSpell(int16 spell_id, int16 target_id, int16 slot, int32 cast_time) {
Mob* tmp = entity_list.GetMob(target_id); 
if(tmp == 0)
target_id = this->GetID();


	if (!spells_loaded)
		Message(0, "Spells not loaded.");
	else if (casting_spell_id != 0) {
		if(target_id == this->GetID()) {
			if (this->IsNPC())
				this->CastToNPC()->AddQueuedSpell(casting_spell_id);
		}
		Message(13, "You're already casting another spell!");
	}
	else {
		if (this->IsNPC()) {
			this->CastToNPC()->FaceTarget(entity_list.GetMob(target_id));
		}
		if (cast_time == 0xFFFFFFFF)
			cast_time = spells[spell_id].cast_time;

		if (cast_time == 0) {
			SpellFinished(spell_id, target_id, slot, spells[spell_id].mana);
			return;
		}

		/* Client begins to cast a spell */
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_BeginCast;
		outapp->size = sizeof(BeginCast_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, outapp->size);

		BeginCast_Struct* begincast = (BeginCast_Struct*)outapp->pBuffer;
		begincast->caster_id = GetID();
		begincast->spell_id = spell_id;
		begincast->cast_time = cast_time;
		outapp->priority = 3;
		entity_list.QueueCloseClients(this, outapp);
		delete outapp;

		casting_spell_id = spell_id;
		casting_spell_targetid = target_id;
		casting_spell_slot = slot;
		casting_spell_mana = spells[spell_id].mana;
		spellend_timer->Start(cast_time);
	}
}

void Mob::InterruptSpell() {
#define InterruptedMessage "Your spell was interrupted."
	if (casting_spell_id != 0) {
		cout << "Interrupting " << this->GetName() << "'s casting" << endl;
		spellend_timer->Disable();
		entity_list.MessageClose(this, true, 600, MT_Spells, "%s's casting has been interrupted!", this->GetName());
		if(this->IsNPC() && spells[casting_spell_id].resisttype)
		{
			this->CastToNPC()->AddQueuedSpell(casting_spell_id);
		}
		if (this->IsClient()) {
			APPLAYER* outapp = new APPLAYER(OP_InterruptCast, sizeof(InterruptCast_Struct));
			InterruptCast_Struct* ic = (InterruptCast_Struct*) outapp->pBuffer;
			ic->message = 0x01b7; // your spell has ...
			ic->color = 0x0121; //red
			ic->unknown2 = 0;			
			this->CastToClient()->QueuePacket(outapp);
//			DumpPacket(outapp);
			delete outapp;
			outapp = new APPLAYER;
			outapp->opcode = OP_ManaChange;
			outapp->size = sizeof(ManaChange_Struct);
			outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer, 0, outapp->size);
			ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
			manachange->new_mana = GetMana();
			manachange->spell_id = casting_spell_id ;//0x0120; // cancel spell
			outapp->priority = 5;
			this->CastToClient()->QueuePacket(outapp);
			delete outapp;
		}
		casting_spell_id = 0;
	}
	else
		cout << "Interrupting " << this->GetName() << "'s casting, but no spell to interrupt" << endl;
isattacked = false;
isinterrupted = false;
}

void Mob::SpellFinished(int16 spell_id, int32 target_id, int16 slot, int16 mana_used) {
  if (spell_id == 0)
    return;
  if (this->isinterrupted)
  {
    this->InterruptSpell();
    return;
  }
  casting_spell_id = 0;
  if (!spells_loaded)
    Message(0, "Spells not loaded.");
  else if (casting_spell_id != 0 && casting_spell_id != spell_id)
    Message(13, "You're already casting another spell!");
  else {
    APPLAYER* outapp = 0;
    if (this->IsClient())
    {
      /* Dunno why this goes here, but it does */
      // Quagmire - Think this is to grey the memorized spell icons?
      if (slot <= 9)
      {
        outapp = new APPLAYER;
        outapp->opcode = OP_MemorizeSpell;
        outapp->size = sizeof(MemorizeSpell_Struct);
        outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer, 0, outapp->size);
        MemorizeSpell_Struct* memspell = (MemorizeSpell_Struct*)outapp->pBuffer;
        memspell->slot = slot;
        memspell->spell_id = spell_id;
        memspell->scribing = 3;
        outapp->priority = 5;
        this->CastToClient()->QueuePacket(outapp);
        delete outapp;
      }
    }
    if(!target_id) target_id = this->GetID();
    Mob* target = entity_list.GetMob(target_id);
    if(target)
    {
      bool killspell=0;

      if(this->IsClient()) /* heh what a fucking mess, pvp protection -solar */
      {
        if(target->IsClient() && (this->GetID() != target->GetID()))
          if(this->CastToClient()->pp.pvp != target->CastToClient()->pp.pvp)
            killspell=1;
          else
            if(!spells[spell_id].goodEffect)
              if(!this->CastToClient()->pp.pvp || !target->CastToClient()->pp.pvp)
                killspell=1;
        if(target->GetOwnerID())
          if(target->GetOwner()->IsClient())
            if(this->CastToClient()->pp.pvp != target->GetOwner()->CastToClient()->pp.pvp)
              killspell=1;
            else
              if(!spells[spell_id].goodEffect)
                if(this->GetID() == target->GetOwnerID() || !this->CastToClient()->pp.pvp || !target->GetOwner()->CastToClient()->pp.pvp)
                  killspell=1;
      }
      if(killspell)
      {
        casting_spell_id=spell_id;
        this->InterruptSpell();
        return;
      }
    }




		/* Client animation */
		outapp = new APPLAYER;
		outapp->opcode = OP_Attack;
		outapp->size = sizeof(Attack_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, outapp->size);
		Attack_Struct* a = (Attack_Struct*)outapp->pBuffer;
		a->spawn_id = GetID();
        a->a_unknown1 = 0; // if this is not zero, the animation will not occur.
		a->type = 42;
		a->a_unknown2[5] = 0x80;      
		a->a_unknown2[6] = 0x3f;       
		outapp->priority = 2;
		entity_list.QueueCloseClients(this, outapp);
		delete outapp;  

		if (this->IsClient()) {
			/* Tell client it can cast again */
			outapp = new APPLAYER(OP_ManaChange, sizeof(ManaChange_Struct));
			ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
			SetMana(GetMana() - mana_used);
			manachange->new_mana = GetMana();
			manachange->spell_id = spell_id;
			outapp->priority = 5;
			this->CastToClient()->QueuePacket(outapp);
			delete outapp;
		}
		if (this->isattacked)
		{
			if (this->IsClient()){
				this->Message(MT_Spells, "You regain your concentration and continue your casting!");
				this->CastToClient()->CheckIncreaseSkill(13);
			}
			else
				entity_list.MessageClose(this, true, 300, MT_Spells, "%s's regains concentration and continues casting!", this->GetName());
		}
		isattacked = false;
		
		if (!spells_loaded) {
			Message(0, "Spells werent loaded on bootup.");
		}
		else if (spell_id == 1948 && (this->IsClient() && (this->CastToClient()->Admin() <= 79))) { // Destroy
			// This spell is lame!
		}
		else {
		//	if (target->CastToClient()->pp.pvp != NULL && /*TargetSelf*/(target->GetID() == this->GetID()) || /*TargetAlsoPVP*/(target->CastToClient()->pp.pvp == 1 && this->CastToClient()->pp.pvp == 1) || /*TargetPetAlsoPVP*/(target->GetOwner()->CastToClient()->pp.pvp == 1 && this->CastToClient()->pp.pvp == 1) || /*TargetNonPVP*/(target->CastToClient()->pp.pvp == 0 && this->CastToClient()->pp.pvp == 0) || /*TargetPetNonPVP*/(target->GetOwner()->CastToClient()->pp.pvp == 0 && this->CastToClient()->pp.pvp == 0) || /*TargetNPC*/(target->IsNPC())) {
			//Message(0, "I dont know that TargetType. 0x%x", spells[spell_id].targettype);	
				switch (spells[spell_id].targettype)
				{
					case ST_Tap:
					case ST_Target: {
						Mob* tar = entity_list.GetMob(target_id);
						if (tar)
							SpellOnTarget(spell_id, tar);
						else
							Message(13, "Error: Spell requires a target");
						break;
					}
					case ST_Self: {
						SpellOnTarget(spell_id, this);
						break;
					}
					case ST_AECaster: {
						entity_list.AESpell(this, this, spells[spell_id].aoerange, spell_id);
						break;
					}
					case ST_AETarget: {
						Mob* tar = entity_list.GetMob(target_id);
						if (tar)
							entity_list.AESpell(this, tar, spells[spell_id].aoerange, spell_id);
						else
							Message(13, "Invalid target for an AETarget spell");
						break;
					}
					case ST_Group: {
						
						if (this->IsClient() && this->CastToClient()->isgrouped && entity_list.GetGroupByClient(this->CastToClient()) != 0)	
							entity_list.GetGroupByClient(this->CastToClient())->CastGroupSpell(this->CastToClient(),spell_id);
						if (this-IsClient() && !this->CastToClient()->isgrouped)
							SpellOnTarget(spell_id,this);
							break;
					}
					case ST_Pet: {
						if (this->GetPetID() != 0) {
							SpellOnTarget(spell_id, entity_list.GetMob(this->GetPetID()));
							if (spell_id == 331) {
								Mob* mypet = entity_list.GetMob(this->GetPetID());
								if (mypet && mypet->IsNPC() && mypet->GetPetType() != 0xFF) {
									mypet->CastToNPC()->Depop();
									this->SetPet(0);
								}
							}
						}
						else {
							Message(13, "You don't have a pet to cast this on!");
						}
						break;
					}
					case ST_Corpse: {
						Mob* tar = entity_list.GetMob(target_id);
						if(!(tar->IsPlayerCorpse())) {
							Message(13, "Target is not a corpse.");
							break;
						}
						SpellOnTarget(spell_id, tar);
						break;
					}	
					default: {
						Message(0, "I dont know that TargetType. 0x%x", spells[spell_id].targettype);
						break;
					}
				}
		//	}
		//	else {
		//		Message(13, "Your spell was unable to take hold.");
		//	}
		}
	}
}

void Mob::SpellOnTarget(int16 spell_id, Mob* spelltar) {
	if (spelltar == 0) {
		Message(13, "You must have a target for this spell.");
		return;
	}
	if (spells[spell_id].targettype == ST_AECaster && spelltar == this) return;
	if (spell_id == 982) { // Cazic Touch, hehe =P
		char tmp[64];
		strcpy(tmp, spelltar->GetName());
		strupr(tmp);
		if (this->IsClient() && spelltar->IsClient()) {
			if (spelltar->CastToClient()->Admin() > this->CastToClient()->Admin())
				return;
		}
		//entity_list.Message(0, MT_Shout, "%s shouts, '%s!'", this->GetName(), tmp);
	}
	if (spelltar->IsNPC() && spells[spell_id].goodEffect==0)
		spelltar->CastToNPC()->AddToHateList(this,0,CalcSpellValue(spells[spell_id].formula[0], spells[spell_id].base[0], spells[spell_id].max[0], GetLevel()));
	APPLAYER* outapp = 0;
	outapp = new APPLAYER(OP_Action, sizeof(Action_Struct));
	Action_Struct* action = (Action_Struct *)outapp->pBuffer;
	action->damage = 0;
	//action->anim=spells[spell_id].TargetAnim;
	action->spell = spell_id;
	if (this->IsClient() && this->CastToClient()->GMHideMe())
		action->source = 0;
	else
		action->source = GetID();
	action->target = spelltar->GetID();
	action->type = 0xE7;
	outapp->priority = 3;
	entity_list.QueueCloseClients(spelltar, outapp, false, 600, this); // send target and people near target
	if (this->IsClient())
		this->CastToClient()->QueuePacket(outapp); // send to caster of the spell
	delete outapp;

	/* Actual cast action */
	outapp = new APPLAYER(OP_CastOn, sizeof(CastOn_Struct));
	CastOn_Struct* caston = (CastOn_Struct*) outapp->pBuffer;
	if (this->IsClient() && this->CastToClient()->GMHideMe())
		caston->source_id = 0;
	else
		caston->source_id = this->GetID();
	caston->target_id = spelltar->GetID();
	caston->action = 231;
	caston->spell_id = spell_id;
	caston->heading = this->GetHeading() * 2;
	caston->source_level = this->GetLevel();
	caston->unknown2 = 0x0A;
	caston->unknown4[0] = 0x00;
	caston->unknown1[1] = 0x41;
	caston->unknown4[1] = 0x04;

	entity_list.QueueCloseClients(spelltar, outapp, false, 600, this); // send target and people near target
	if (this->IsClient())
		this->CastToClient()->QueuePacket(outapp); // send to caster of the spell
//DumpPacket(outapp);
	delete outapp;
	spelltar->SpellEffect(this, spell_id, this->GetLevel());
}
// Hogie - Stuns "this"
void Client::Stun(int16 duration) {
	this->stunned = true;
	stunned_timer->Start(duration);
	APPLAYER* outapp = new APPLAYER(OP_Stun, sizeof(Stun_Struct));
	Stun_Struct* stunon = (Stun_Struct*) outapp->pBuffer;
	stunon->duration = duration;
	outapp->priority = 5;
	this->CastToClient()->QueuePacket(outapp);
	delete outapp;
}
void NPC::Stun(int16 duration) {
	cout << "Startduration: " << duration << endl;
	appearance = 0;
	pLastChange = Timer::GetCurrentTime();
	this->stunned = true;
	stunned_timer->Start(duration);
}
void Mob::Mesmerize(){
	this->mezzed = true;
	if (this->IsClient()){
		APPLAYER* outapp = new APPLAYER(OP_Stun, sizeof(Stun_Struct));
		Stun_Struct* stunon = (Stun_Struct*) outapp->pBuffer;
		stunon->duration = 0xFFFF;
		this->CastToClient()->QueuePacket(outapp);
		delete outapp;
	}
	else
	{
		appearance = 0;
		pLastChange = Timer::GetCurrentTime();
	}
}
void Corpse::CastRezz(int16 spellid, Mob* Caster){
		if (!rezzexp) {
			Caster->Message(4, "You cannot resurrect this corpse");
			return;
		}
		APPLAYER* outapp = new APPLAYER(OP_RezzRequest, sizeof(Resurrect_Struct));
		Resurrect_Struct* rezz = (Resurrect_Struct*) outapp->pBuffer;
		memset(rezz,0,sizeof(Resurrect_Struct));
		memcpy(rezz->your_name,this->orgname,30);
		memcpy(rezz->corpse_name,this->name,30);
		memcpy(rezz->rezzer_name,Caster->GetName(),30);
		memcpy(rezz->zone,zone->GetShortName(),15);
		rezz->spellid = spellid;
		rezz->x = this->x_pos;
		rezz->y = this->y_pos;
		rezz->z = (float)this->z_pos/10;
		worldserver.RezzPlayer(outapp, rezzexp, OP_RezzRequest);
		//DumpPacket(outapp);
		delete outapp;
}

// Quagmire - that case above getting to long and spells are gonna have a lot of cases of their own
void Mob::SpellEffect(Mob* caster, int16 spell_id, int8 caster_level) {
	if (!spells_loaded) {
		Message(0, "Spells werent loaded on bootup.");
		return;
	}
/*struct Buffs_Struct {
	int16	spellid;
	int8	casterlevel;
	int32	ticselapsed;
};*/

	int i = 0;
	bool IsBuff = false;
	if (spells[spell_id].buffdurationformula > 0) {
		if (spells[spell_id].buffduration == 0 && !(spells[spell_id].buffdurationformula == 50) && !(spells[spell_id].buffdurationformula == 5)) {
			Message(0, "Unknown buff duration formula (%d)", spells[spell_id].buffdurationformula);
		}
		else {
			for (i=0; i < 15; i++) {
				if (buffs[i].spellid == 0xFFFF || buffs[i].spellid == spell_id) {
					break;
				}
			}
			if (i >= 15) {
				if (caster != 0)
					caster->Message(13, "Error: All buff slots full on %s.", this->GetName());
				return;
			}
			else {
				buffs[i].spellid = spell_id;
				buffs[i].casterlevel = caster_level;
				if (caster == 0)
					buffs[i].casterid = 0;
				else
					buffs[i].casterid = caster->GetID();
				buffs[i].durationformula = spells[spell_id].buffdurationformula;
				buffs[i].ticsremaining = spells[spell_id].buffduration;
				IsBuff = true;
			}
			CalcBonuses();
		}
	}
	/*
	if(!this->IsClient())
	{
	float heading = (int8)caster->GetHeading();	// mob heading
	heading = (heading * 360.0)/256.0;	// convert to degrees
	if (heading < 270)
		heading += 90;
	else	
		heading -= 270;
	heading = heading*3.1415/180.0;	// convert to radians
	if(spells[spell_id].pushback !=0 || spells[spell_id].pushup != 0)
	{
		if(heading<(3.1415/4.0))
		{
			cout << "Moving " << this->name << " to: " << ((float)(cosf(heading)*(spells[spell_id].pushback*10.0))+this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)*sinf(heading)+this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove((cosf(heading)*(spells[spell_id].pushback*10.0))+this->GetX(),((spells[spell_id].pushback*10.0)*sinf(heading)+this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading>(3.1415/4.0) && heading < 3.1415/2.0)
		{
			cout << "Moving " << this->name << " to: " << ((float)(cosf((3.1415/2.0)-heading)*(spells[spell_id].pushback*10.0))-this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)*sinf((3.1415/2.0)-heading)+this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove((cosf((3.1415/2.0)-heading)*(spells[spell_id].pushback*10.0))-this->GetX(),((spells[spell_id].pushback*10.0)*sinf((3.1415/2.0)-heading)+this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if((heading>3.1415/2.0) && (heading < 3.1415 *(3.0/4.0)))
		{
			cout << "Moving " << this->name << " to: " << ((float)(cosf((3.1415*(3.0/4.0)-heading))*(spells[spell_id].pushback*10.0))-this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)*sinf((3.1415*(3.0/4.0)-heading))-this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove((cosf((3.1415*(3.0/4.0)-heading))*(spells[spell_id].pushback*10.0))-this->GetX(),((spells[spell_id].pushback*10.0)*sinf((3.1415*(3.0/4.0)-heading))-this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading>(3.1415*(3.0/4.0)))
		{
			cout << "Moving " << this->name << " to: " << ((float)(cosf(3.1415-heading)*(spells[spell_id].pushback*10.0))+this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)*sinf(3.1415-heading)-this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove((cosf(3.1415-heading)*(spells[spell_id].pushback*10.0))+this->GetX(),((spells[spell_id].pushback*10.0)*sinf(3.1415-heading)-this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading==(3.1415/4.0))
		{
			cout << "Moving " << this->name << " to: " << ((float)this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)+this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove(this->GetX(),((spells[spell_id].pushback*10.0)+this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading==(3.1415/2.0))
		{
			cout << "Moving " << this->name << " to: " << ((float)((spells[spell_id].pushback*10.0))-this->GetX()) << ' ' << ((float)this->GetY()) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove((spells[spell_id].pushback*10.0)-this->GetX(),this->GetY(),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading==(3.1415*(3.0/4.0)))
		{
			cout << "Moving " << this->name << " to: " << ((float)(spells[spell_id].pushback*10.0)-this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)-this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove(((spells[spell_id].pushback*10.0))+this->GetX(),((spells[spell_id].pushback*10.0)-this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
		else if(heading==3.1415)
		{
			cout << "Moving " << this->name << " to: " << ((float)this->GetX()) << ' ' << ((float)((spells[spell_id].pushback*10.0)-this->GetY())) << ' ' << ((float)this->GetZ()+(10.0*spells[spell_id].pushup)) << endl;
			this->GMMove(this->GetX(),((spells[spell_id].pushback*10.0)-this->GetY()),this->GetZ()+(spells[spell_id].pushup*10.0),this->GetHeading());		
		}
	}
	
	}*/
	for (i=0; i < 12; i++) {
		if (!(spells[spell_id].effectid[i] == 0xFE  || spells[spell_id].effectid[i] == 0xFF))
		{
		switch(spells[spell_id].effectid[i]) {
			case SE_CurrentHP: {
				if (IsBuff)
					break;
			}
			case SE_CurrentHPOnce: {
				if (caster)
					caster->Message(0, "Effect #%i: You changed %s's hp by %+i", i, this->GetName(), CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
				this->ChangeHP(caster, CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level), spell_id);
				break;
			}
			case SE_HealOverTime: {
				Message(0, "Effect #%i: You cast a Heal over Time spell.", i);
				break;
			}
			case SE_MovementSpeed: {
				Message(0, "Effect #%i: You cast an Movement Speed buff/debuff.", i);
				break;
			}
			case SE_AttackSpeed: {
				if (spells[spell_id].goodEffect==0)
					this->SetHaste(100 - (int) CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
				else
					this->SetHaste((int) CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
				this->SetAttackTimer();
				Message(0, "Effect #%i:You cast an Attack Speed buff/debuff.", i);
				break;
			}
			case SE_Invisibility: {
				Message(0, "Effect #%i: You cast an Invisibility spell.", i);
				break;
			}
			case SE_SeeInvis: {
				Message(0, "Effect #%i: You cast a See Invis buff.", i);
				break;
			}
			case SE_WaterBreathing: {
				Message(0, "Effect #%i: You cast a Water Breathing buff.", i);
				break;
			}
			case SE_CurrentMana: {
				if (IsBuff)
					break;
				SetMana(GetMana() + CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
				break;
			}
			case SE_AddFaction: {
				Message(0, "Effect #%i: You cast an Add Faction spell.", i);
				break;
			}
			case SE_Stun: {
				if (IsClient())
					CastToClient()->Stun(spells[spell_id].base[0]);
				else if (IsNPC())
					CastToNPC()->Stun(spells[spell_id].base[0]);
				break;
			}
			case SE_Charm: {
				Message(0, "Effect #%i: You cast a Charm spell.", i);
				if (this->GetPetID() != 0) {
					Message(13, "You\'ve already got a pet.");
					break;
				}
				if (IsClient())
					break;

				//this->MakePet(spells[spell_id].teleport_zone);
				this->CastToNPC()->SetPetType(0);
				this->SetOwnerID(caster->GetID());
				caster->SetPetID(this->GetID());
				break;
			}
			case SE_Fear: {
				Message(0, "Effect #%i: You cast a Fear spell.", i);
				break;
			}
			case SE_Stamina: {
				Message(0, "Effect #%i: You cast a Stamina add/subtract spell.", i);
				break;
			}
			case SE_BindAffinity: {
//				Message(0, "Effect #%i: You cast a Bind Affinity spell.", i);
				if (this->IsClient()) {
					this->CastToClient()->SetBindPoint();
					this->CastToClient()->Save();
				}
				break;
			}
			case SE_Gate: {
//				Message(0, "Effect #%i: You cast a Gate spell.", i);
				if (this->IsNPC())
					this->CastToNPC()->WhipeHateList();
				this->CastToNPC()->gohome_timer->Start(5000);
				this->GoToBind();
				break;
			}
			case SE_CancelMagic: {
				//Message(0, "Effect #%i: You cast a Cancel Magic spell.", i);
			/*	bool BuffExists=false;
				int countx;
				for(countx =0; countx < 15;countx++)
				{
					if(buffs[countx].spellid!=0 && buffs[countx].casterlevel <= caster_level + spells[spell_id].base[i])
					{
						BuffExists=true;
						countx=20;
					}
				}
				if(BuffExists)
				{
					int buffpos =0;
					do
					{
						buffpos=rand()%16;
					}
					while(buffs[buffpos].spellid != 0 && buffs[buffpos].casterlevel <= caster_level + spells[spell_id].base[i]);
					if(buffs[buffpos].spellid!=0)
						this->BuffFade(buffs[buffpos].spellid);
				}*/
				break;
			}
			case SE_InvisVsUndead: {
				Message(0, "Effect #%i: You cast an Invis Vs Undead spell.", i);
				break;
			}
			case SE_Mez: {
				Message(0, "Effect #%i: You cast a Mez spell.", i);
				this->Mesmerize();
				break;
			}
			case SE_SummonItem: {
				if (this->IsClient()) {
					Message(0, "Effect #%i: You cast a Summon Item #%i.", i, spells[spell_id].base[i]);
					int16 tmpcharges = CalcSpellValue(spells[spell_id].formula[i], 0, 20, caster_level);
					if (tmpcharges == 0)
						this->CastToClient()->SummonItem(spells[spell_id].base[i], 1);
					else
						this->CastToClient()->SummonItem(spells[spell_id].base[i], tmpcharges);
				}
				break;
			}
			case SE_NecPet:
			case SE_SummonPet: {
				if (this->GetPetID() != 0 || this->GetOwnerID() != 0) {
					Message(13, "You\'ve already got a pet or are a pet.");
					break;
				}
				this->MakePet(spells[spell_id].teleport_zone);
				break;
			}
			case SE_DivineAura: {
				Message(0, "Effect #%i: You cast a Divine Aura spell.", i);
				break;
			}
			case SE_ShadowStep: {
				Message(0, "Effect #%i: You cast a Shadow Step spell.", i);
				break;
			}
			case SE_SenseDead: {
				Message(0, "Effect #%i: You cast a Sense Dead spell.", i);
				break;
			}
			case SE_SenseSummoned: {
				Message(0, "Effect #%i: You cast a Sense Summoned spell.", i);
				break;
			}
			case SE_SenseAnimals: {
				Message(0, "Effect #%i: You cast a Sense Animals spell.", i);
				break;
			}
			case SE_Rune: {
				Message(0, "Effect #%i: You cast a Rune spell.", i);
				break;
			}
			case SE_TrueNorth: {
				Message(0, "Effect #%i: You cast a True North spell. UBER!", i);
				break;
			}
			case SE_Levitate: {
				this->SendAppearancePacket(19, 2);
				Message(0, "Effect #%i: You cast a Levitate spell.", i);
				break;
			}
			case SE_Illusion: {
				SendIllusionPacket(spells[spell_id].base[i], Mob::GetDefaultGender(spells[spell_id].base[i], GetGender()));
				Message(0, "Effect #%i: You cast an Illusion spell.", i);
				break;
			}
			case SE_DamageShield: {
				Message(0, "Effect #%i: You cast a Damage Shield spell.", i);
				break;
			}
			case SE_Identify: {
				Message(0, "Effect #%i: You cast an Identify spell.", i);
				break;
			}
			case SE_WhipeHateList: {
				if (this->IsNPC()) {
					this->CastToNPC()->WhipeHateList();
					this->CastToNPC()->gohome_timer->Start(5000);
				}
				Message(13, "Your mind fogs. Who are my friends? Who are my enimies?... it was all so clear a moment ago...");
				break;
			}
			case SE_SpinTarget: {
				if (IsClient())
					Spin();
				Message(0, "Effect #%i: You cast a Spin Target spell.", i);
				break;
			}
			case SE_InfaVision: {
				Message(0, "Effect #%i: You cast an InfaVision buff.", i);
				break;
			}
			case SE_UltraVision: {
				Message(0, "Effect #%i: You cast an UltraVision buff.", i);
				break;
			}
			case SE_EyeOfZomm: {
				Message(0, "Effect #%i: You cast an Eye of Zomm spell.", i);
				break;
			}
			case SE_ReclaimPet: {
				Message(0, "Effect #%i: You cast a Reclaim Pet spell.", i);
				break;
			}
			case SE_BindSight: {
				Message(0, "Effect #%i: You cast a Bind Sight spell.", i);
				break;
			}
			case SE_FeignDeath: {
				Message(0, "Effect #%i: You cast a Feign Death spell.", i);
				break;
			}
			case SE_VoiceGraft: {
				Message(0, "Effect #%i: You cast a Voice Graft spell.", i);
				break;
			}
			case SE_Sentinel: {
				Message(0, "Effect #%i: You cast Sentinel. Fuck You.", i);
				break;
			}
			case SE_LocateCorpse: {
				Message(0, "Effect #%i: You cast a Locate Corpse spell.", i);
				break;
			}
			case SE_Revive: {
				if (this->IsCorpse() && this->CastToCorpse()->IsPlayerCorpse())
					this->CastToCorpse()->CastRezz(spell_id, caster);
				break;
			}
			case SE_Teleport: {
				if (this->IsClient())
					this->CastToClient()->MovePC(spells[spell_id].teleport_zone, spells[spell_id].base[1], spells[spell_id].base[0], spells[spell_id].base[2]);
				break;
			}
			case SE_ModelSize: {
				this->ChangeSize(this->GetSize()*(spells[spell_id].base[i]/100));
				Message(0, "Effect #%i: You cast a Shrink/Grow spell.", i);
				break;
			}
			case SE_Root: {
				if (this->IsNPC()){
					this->rooted = true;
					appearance = 0;
					pLastChange = Timer::GetCurrentTime();
				}
				Message(0, "Effect #%i: You cast a Root spell.", i);
				break;
			}
			case SE_SummonCorpse:{
				// TODO: Take reagents from caster
				if (this->GetTarget() && this->GetTarget()->IsClient()){
					/*
					if (entity_list.GetGroupByClient(this->GetTarget()->CastToClient()) != entity_list.GetGroupByClient(this->CastToClient())){
						Message(13, "You can only summon corpses form groupmembers");
						break;
					}*/
					Corpse* corpse = entity_list.GetCorpseByOwner(this->GetTarget()->CastToClient());
					if (!corpse)
						Message(4, "There is no corpse from %s in this zone!",this->GetTarget()->GetName());
					else {
						corpse->Summon(this->CastToClient(),true);
						Message(4, "You summon %s's corpse",this->GetTarget()->GetName() );
					}		
				}
				else
					Message(13, "You need to target a player!");
			}
			case 0xFE:
			case 0xFF: {
				// this is the code for empty... i think
				break;
			}
			case SE_TotalHP:
			case SE_ArmorClass:
			case SE_ATK:
			case SE_STR:
			case SE_DEX:
			case SE_AGI:
			case SE_STA:
			case SE_INT:
			case SE_WIS:
			case SE_CHA:
			case SE_ResistFire:
			case SE_ResistCold:
			case SE_ResistPoison:
			case SE_ResistDisease:
			case SE_ResistMagic:
			{
				// Buffs are handeled elsewhere
				break;
			}
			default: {
				Message(0, "Effect #%i: I dont know what this effect is: 0x%x.", i, spells[spell_id].effectid[i]);
			}
		}
		}
	}
}

sint32 CalcSpellValue(int8 formula, sint16 base, sint16 max, int8 caster_level) {
/*
0x01 - 0x63 = level * formulaID

0x64 = min
0x65 = min + level / 2
0x66 = min + level
0x67 = min + level * 2
0x68 = min + level * 3
0x69 = min + level * 4
0x6c = min + level / 3
0x6d = min + level / 4
0x6e = min + level / 5
0x77 = min + level / 8
*/
//cout << "Cast Spell: f=0x" << hex << (int) formula << dec << ", b=" << base << ", m=" << max << ", cl=" << (int) caster_level << endl;
	sint16 ubase = abs(base);
	sint16 result = 0;
	switch(formula) {
		case 0x64:
		case 0x00: {
			result = ubase;
			break;
		}
		case 0x65: {
			result = ubase + (caster_level / 2);
			break;
		}
		case 0x66: {
			result = ubase + caster_level;
			break;
		}
		case 0x67: {
			result = ubase + (caster_level * 2);
			break;
		}
		case 0x68: {
			result = ubase + (caster_level * 3);
			break;
		}
		case 0x69: {
			result = ubase + (caster_level * 4);
			break;
		}
		case 0x6c: {
			result = ubase + (caster_level / 3);
			break;
		}
		case 0x6d: {
			result = ubase + (caster_level / 4);
			break;
		}
		case 0x6e: {
			result = ubase + (caster_level / 5);
			break;
		}
		case 0x77: {
			result = ubase + (caster_level / 8);
			break;
		}
		default: {
			if (formula < 100) {
				result = ubase + (caster_level * formula);
				break;
			}
			else {
//				cout << "Unknown spell formula. b=" << base << ", m=" << max << ", f=0x" << hex << (int) formula << dec << endl;
				break;
			}
		}
	}
	if (result >= max && max != 0)
		return max * sign(base);
	else
		return result * sign(base);
}

void Mob::CalcBonuses() {
	StatBonuses* newbon;
	StatBonuses* oldbon;

	if (this->IsClient()) {
		newbon = new StatBonuses;
		memset(newbon, 0, sizeof(StatBonuses));
		this->CastToClient()->CalcItemBonuses(newbon);
		oldbon = itembonuses;
		itembonuses = newbon;
		safe_delete(oldbon);
	}

	newbon = new StatBonuses;
	memset(newbon, 0, sizeof(StatBonuses));
	CalcSpellBonuses(newbon);
	oldbon = spellbonuses;
	spellbonuses = newbon;
	safe_delete(oldbon);

	CalcMaxHP();
	if (this->IsClient())
		this->CastToClient()->CalcMaxMana();
}

void Client::CalcItemBonuses(StatBonuses* newbon) {

	const Item_Struct* item = 0;
	for (int i=1; i<21; i++) {
		item = database.GetItem(pp.inventory[i]);
		if (item != 0) {
			if (item->flag != 0x7669) {
				newbon->AC += item->common.AC;
				newbon->HP += item->common.HP;
				newbon->Mana += item->common.MANA;
				newbon->STR += item->common.STR;
				newbon->STA += item->common.STA;
				newbon->DEX += item->common.DEX;
				newbon->AGI += item->common.AGI;
				newbon->INT += item->common.INT;
				newbon->WIS += item->common.WIS;
				newbon->CHA += item->common.CHA;
				newbon->MR += item->common.MR;
				newbon->FR += item->common.FR;
				newbon->CR += item->common.CR;
				newbon->PR += item->common.PR;
				newbon->DR += item->common.DR;
				if (item->common.spellId != 0xFFFF && item->common.effecttype == 2) { // latent effects
					ApplySpellsBonuses(item->common.spellId0, item->common.level0, newbon);
				}
			}
		}
	}
}

void Mob::CalcSpellBonuses(StatBonuses* newbon) {
	for (int j=0; j<15; j++) {
		ApplySpellsBonuses(buffs[j].spellid, buffs[j].casterlevel, newbon);
	}
}

void ApplySpellsBonuses(int16 spell_id, int8 casterlevel, StatBonuses* newbon) {
	if (!spells_loaded)
		return;
	if (spell_id != 0xFFFF) {
		for (int i=0; i < 12; i++) {
			switch (spells[spell_id].effectid[i]) {
				case SE_TotalHP: {
					newbon->HP += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast an HP buff/debuff.", i);
					break;
				}
				case SE_ArmorClass: {
					newbon->AC += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast an AC buff/debuff.", i);
					break;
				}
				case SE_ATK: {
					newbon->ATK += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast an ATK buff/debuff.", i);
					break;
				}
				case SE_STR: {
					newbon->STR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a STR buff/debuff.", i);
					break;
				}
				case SE_DEX: {
					newbon->DEX += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a DEX buff/debuff.", i);
					break;
				}
				case SE_AGI: {
					newbon->AGI += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast an AGI buff/debuff.", i);
					break;
				}
				case SE_STA: {
					newbon->STA += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a STA buff/debuff.", i);
					break;
				}
				case SE_INT: {
					newbon->INT += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast an INT buff/debuff.", i);
					break;
				}
				case SE_WIS: {
					newbon->WIS += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a WIS buff/debuff.", i);
					break;
				}
				case SE_CHA: {
					if (spells[spell_id].base[i] != 0) {
						newbon->CHA += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//						Message(0, "Effect #%i: You cast a CHA buff/debuff.", i);
					}
					else {
						// this is used in a lot of spells as a spacer, dunno why
					}
					break;
				}
				case SE_ResistFire: {
					newbon->FR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a Resist Fire spell.", i);
					break;
				}
				case SE_ResistCold: {
					newbon->CR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a Resist Cold spell.", i);
					break;
				}
				case SE_ResistPoison: {
					newbon->PR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a Resist Poison spell.", i);
					break;
				}
				case SE_ResistDisease: {
					newbon->DR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a Resist Disease spell.", i);
					break;
				}
				case SE_ResistMagic: {
					newbon->MR += CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], casterlevel);
//					Message(0, "Effect #%i: You cast a Resist Magic spell.", i);
					break;
				}
				default: {
					// do we need to do anyting here?
				}
			}
		}
	}
}

void Mob::DoBuffTic(int16 spell_id, int32 ticsremaining, int8 caster_level, Mob* caster) {
	if (!spells_loaded)
		return;
	if (spell_id != 0xFFFF) {
		for (int i=0; i < 12; i++) {
			switch (spells[spell_id].effectid[i]) {
				case SE_CurrentHP: {
					if (this->IsClient() || caster != 0){
						adverrorinfo = 41;
						this->ChangeHP(caster, CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level), spell_id);
						adverrorinfo = 4;
					}
					break;
				}
				case SE_HealOverTime: {
					if (this->IsClient() || caster != 0){
						adverrorinfo = 42;
						this->ChangeHP(caster, CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level), spell_id);
						adverrorinfo = 4;
					}
					break;
				}
				case SE_CurrentMana: {
					this->SetMana(GetMana() + CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
					break;
				}
				default: {
					// do we need to do anyting here?
				}
			}
		}
	}
}

void Mob::BuffFadeByEffect(uint8 effect){
	for (int j=0; j<15; j++) {
		if (buffs[j].spellid < SPDAT_RECORDS){
			for (int x=0; x < 12; x++) {
				if (spells[buffs[j].spellid].effectid[x] == effect){
					BuffFade(buffs[j].spellid);
					return;
				}
			}
		}
	}
}

void Mob::BuffFade(int16 spell_id, int8 unknown) {
	if (!spells_loaded)
		return;
// 0xFFFe is my code for nuke all buffs
	for (int j=0; j<15; j++) {
		if (buffs[j].spellid == spell_id || spell_id == 0xFFFe) {
			if (buffs[j].spellid <= SPDAT_RECORDS) {
				for (int i=0; i < 12; i++) {
					switch (spells[buffs[j].spellid].effectid[i]) {
						case SE_Illusion: {
							SendIllusionPacket(GetBaseRace(), GetBaseGender());
							break;
						}
						case SE_Levitate: {
							this->SendAppearancePacket(19, 0);
							break;
						}
						case SE_AttackSpeed: {
							this->SetHaste(0);
							this->SetAttackTimer();
							break;
						}
						case SE_Mez: {
							this->mezzed = false;
						}
						case SE_Root: {
							if (this->IsNPC())
								this->rooted = false;
						}
					}
				}
			}
			buffs[j].spellid = 0xFFFF;
			if (this->IsClient())
				this->CastToClient()->MakeBuffFadePacket(spell_id, j, unknown);
		}
	}
	CalcBonuses();
}

void Client::MakeBuffFadePacket(int16 spell_id, int8 slot_id, int8 unknown) {
//	return;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_Buff;
	outapp->size = sizeof(SpellBuffFade_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer,0x0, outapp->size);
	SpellBuffFade_Struct* sbf = (SpellBuffFade_Struct*) outapp->pBuffer;
	sbf->spellid = 0xFFFF;
	sbf->slotid = slot_id;
	sbf->unknown000[0] = unknown;
	//sbf->unknownset = 0x44;
	sbf->unknownset2 = 0x01;
	//sbf->unknown000[0] = 0x55;
	QueuePacket(outapp);
	//DumpPacket(outapp);
	delete outapp;
}

void Client::SetBindPoint() {
	pp.bind_point_zone = zone->GetZoneID();
	pp.bind_location[0][0] = x_pos;
	pp.bind_location[1][0] = y_pos;
	pp.bind_location[2][0] = z_pos;
}

void Client::GoToBind() {
	if (pp.bind_point_zone == zone->GetZoneID()) //if same zone no reason to zone
		GMMove(pp.bind_location[0][0],pp.bind_location[1][0],pp.bind_location[2][0]);
	else
		MovePC(pp.bind_point_zone, pp.bind_location[0][0], pp.bind_location[1][0], pp.bind_location[2][0], true); //lets zone
}

const char* Mob::GetRandPetName() {
	char* petreturn = 0;
	char petnames[77][64] = { "Gabeker","Gann","Garanab","Garn","Gartik","Gebann","Gebekn","Gekn","Geraner","Gobeker","Gonobtik","Jabantik","Jasarab","Jasober","Jeker","Jenaner","Jenarer","Jobantik","Jobekn","Jonartik","Kabann","Kabartik","Karn","Kasarer","Kasekn","Kebekn","Keber","Kebtik","Kenantik","Kenn","Kentik","Kibekab","Kobarer","Kobobtik","Konaner","Konarer","Konekn","Konn","Labann","Lararer","Lasobtik","Lebantik","Lebarab","Libantik","Libtik","Lobn","Lobtik","Lonaner","Lonobtik","Varekab","Vaseker","Vebobab","Venarn","Venekn","Vener","Vibobn","Vobtik","Vonarer","Vonartik","Xabtik","Xarantik","Xarar","Xarer","Xeber","Xebn","Xenartik","Xeratik","Xesekn","Xonartik","Zabantik","Zabn","Zabeker","Zanab","Zaner","Zenann","Zonarer","Zonarn" };
	petreturn = petnames[rand() % 77];
	printf("Using %s\n", petreturn);
	return petreturn;
}

int16 Mob::CalcPetLevel(int16 nlevel, int16 nclass) {
	int plevel = 0;
	if (nclass == 13)
		return (nlevel - 10);

	else
		return (nlevel - 12);
}

sint32 Mob::CalcPetHp(int8 levelb, int8 classb, int8 STA) {
	int8 multiplier = 0;
	sint32 base_hp = 0;
	switch(classb) {
	case WARRIOR:
			if (levelb < 20)
				multiplier = 22;
			else if (levelb < 30)
				multiplier = 23;
			else if (levelb < 40)
				multiplier = 25;
			else if (levelb < 53)
				multiplier = 27;
			else if (levelb < 57)
				multiplier = 28;
			else
				multiplier = 30;
		case DRUID:
		case CLERIC:
		case SHAMAN:
			multiplier = 15;
			break;

		case PALADIN:
		case SHADOWKNIGHT:
			if (levelb < 35)
				multiplier = 21;
			else if (levelb < 45)
				 multiplier = 22;
			else if (levelb < 51)
				 multiplier = 23;
			else if (levelb < 56)
				 multiplier = 24;
			else if (levelb < 60)
				 multiplier = 25;
			else
				 multiplier = 26;
			break;

		case MONK:
		case BARD:
		case ROGUE:
		case BEASTLORD:
			if (levelb < 51)
				multiplier = 18;
			else if (levelb < 58)
				multiplier = 19;
			else
				multiplier = 20;				
			break;

		case RANGER:
			if (levelb < 58)
				multiplier = 20;
			else
				multiplier = 21;			
			break;

		case MAGICIAN:
		case WIZARD:
		case NECROMANCER:
		case ENCHANTER:
			multiplier = 12;
			break;

		default:
			if (levelb < 35)
				multiplier = 21;
			else if (levelb < 45)
				multiplier = 22;
			else if (levelb < 51)
				multiplier = 23;
			else if (levelb < 56)
				multiplier = 24;
			else if (levelb < 60)
				multiplier = 25;
			break;
	}

	if (multiplier == 0)
	{
		cerr << "Multiplier == 0 in Client::CalcBaseHP" << endl;
	}

//	cout << "m:" << (int)multiplier << " l:" << (int)levelb << " s:" << (int)GetSTA() << endl;

	base_hp = 5 + (multiplier*levelb) + ((multiplier*levelb*STA) + 1)/300;
	return base_hp;
}

void Mob::MakePet(char* pettype) {
	if (strncmp(pettype, "SumEarthR", 9) == 0) {
		int8 tmp = atoi(&pettype[9]);
		if (tmp >= 2 && tmp <= 14) {
			MakePet(((int)(2 + ((tmp-2) * 3.5) + (rand()%3))), 0, 75, 0, 0, 4 + (((float)(tmp - 2) / 14) * 3),0);
		}
		else {
			Message(0, "Error: Unknown Earth Pet foruma");
		}
	}
	else if (strncmp(pettype, "SumFireR", 8) == 0) {
		int8 tmp = atoi(&pettype[8]);
		if (tmp >= 2 && tmp <= 14) {
			MakePet(((int)(4 + ((tmp-2) * 3.5) + (rand()%3))), 0, 75, 1, 0, 4 + (((float)(tmp - 2) / 14) * 3),0);
		}
		else {
			Message(0, "Error: Unknown Fire Pet foruma");
		}
	}
	else if (strncmp(pettype, "SumAirR", 7) == 0) {
		int8 tmp = atoi(&pettype[7]);
		if (tmp >= 2 && tmp <= 14) {
			MakePet(((int)(3 + ((tmp-2) * 3.5) + (rand()%3))), 0, 75, 3, 0, 4 + (((float)(tmp - 2) / 14) * 3),0);
		}
		else {
			Message(0, "Error: Unknown Air Pet foruma");
		}
	}
	else if (strncmp(pettype, "SumWaterR", 9) == 0) {
		int8 tmp = atoi(&pettype[9]);
		if (tmp >= 2 && tmp <= 14) {
			MakePet(((int)(3 + ((tmp-2) * 3.5) + (rand()%3))), 0, 75, 2, 0, 4 + (((float)(tmp - 2) / 14) * 3),0);
		}
		else {
			Message(0, "Error: Unknown Water Pet foruma");
		}
	}
	else if (strncmp(pettype, "SpiritWolf", 10) == 0) {
		
		MakePet(35, 0, 42, 0,0);
	}
	else if (strncmp(pettype, "Animation", 9) == 0) {
		int r = rand() % GetLevel();
		if(r < (GetLevel()-10))
			r = GetLevel()-10;
		MakePet(r, 0, 127, 0,2);
	}
	else if (strncmp(pettype, "Skeleton", 8) == 0) {
		int r = rand() % GetLevel();
		if(r < (GetLevel()-5))
			r = GetLevel()-5;
		MakePet(r, 0, 60, 0,0);
	}
/*	else if (strncmp(pettype, "MonsterSum", 9) == 0) {
	}
	else if (strncmp(pettype, "Mistwalker", 10) == 0) {
	}
	else if (strncmp(pettype, "SumEarthYael", 12) == 0) {
	}
	else if (strncmp(pettype, "DALSkelGolin", 12) == 0) {
	}
	else if (strncmp(pettype, "SUMHammer", 9) == 0) {
	}
	else if (strncmp(pettype, "TunareBane", 10) == 0) {
	}
	else if (strncmp(pettype, "DruidPet", 8) == 0) {
	}
	else if (strncmp(pettype, "SumHammer", 9) == 0) {
	}
	else if (strncmp(pettype, "SumSword", 8) == 0) {
	}
	else if (strncmp(pettype, "SumDecoy", 8) == 0) {
	}
	else if (strncmp(pettype, "Burnout", 7) == 0) {
	}
	else if (strncmp(pettype, "ValeGuardian", 12) == 0) {
	}*/
	else if (strncmp(pettype, "SumMageMultiElement", 19) == 0) {
		MakePet(50,0,75,3,0,8,15);
	}
	else {
		Message(13, "Unknown pet type: %s", pettype);
	}
}

void Mob::MakePet(int8 in_level, int8 in_class, int16 in_race, int8 in_texture, int8 in_pettype, float in_size, int8 type) {
	if (this->GetPetID() != 0) {
		return;
	}

	NPCType* npc_type = new NPCType;
	memset(npc_type, 0, sizeof(NPCType));
	npc_type->gender = 2;
	if (this->IsClient())
		strcpy(npc_type->name, GetRandPetName());
	else {
		strcpy(npc_type->name, this->GetName());
		npc_type->name[29] = 0;
		npc_type->name[28] = 0;
		npc_type->name[19] = 0;
		strcat(npc_type->name, "'s_pet");
	}
	npc_type->level = in_level;
	npc_type->race = in_race;
	npc_type->class_ = in_class;
	npc_type->texture = in_texture;
	npc_type->helmtexture = in_texture;
	npc_type->size = in_size;
	npc_type->max_hp = CalcPetHp(npc_type->level, npc_type->class_);
	npc_type->cur_hp = npc_type->max_hp;
	npc_type->fixedZ = 1;

	switch(type)
	{
	case 15: // Mage Epic Pet
		{
		npc_type->max_hp = 3000;
		npc_type->cur_hp = 3000;
		npc_type->min_dmg = 0;
		npc_type->max_dmg = 25;
		sprintf(npc_type->npc_spells,"847 848 849");
		break;
		}
	case 2: // Enchanter Pet
		{
		npc_type->gender = 0;
		npc_type->equipment[7] = 44;
		npc_type->equipment[8] = 202;
		break;
		}
	default:
		break;
	}
	NPC* npc = new NPC(npc_type, 0, this->GetX(), this->GetY(), this->GetZ(), this->GetHeading());
	delete npc_type;
	npc->SetPetType(in_pettype);
	npc->SetOwnerID(this->GetID());
	entity_list.AddNPC(npc);
	this->SetPetID(npc->GetID());
}

void Mob::CheckBuffs() {
	return;
	if (this->casting_spell_id == 0) {
		this->CheckPet();
		int8 newtype[15] = { SE_ArmorClass, SE_STR, SE_DEX, SE_AGI, SE_WIS, SE_INT, SE_CHA, SE_AttackSpeed, SE_MovementSpeed, SE_DamageShield, SE_ResistFire, SE_ResistCold, SE_ResistMagic, SE_ResistPoison, SE_ResistDisease };
		for (int h=0; h<15; h++) {
			if (!this->FindType(newtype[h])) {
				int16 buffid = FindSpell(this->class_, this->level, newtype[h], 0);
				if (buffid != 0) {
					this->CastSpell(buffid, this->GetID());
				}
			}
		}
	}
}

void Mob::CheckPet() {
	int16 buffid = 0;
	if (this->GetPetID() == 0 && (this->GetClass() == 11 || this->GetClass() == 13)) {
		if (this->GetClass() == 13) {
			buffid = FindSpell(this->class_, this->level, SE_SummonPet);
		}
		else if (this->GetClass() == 11) {
			buffid = FindSpell(this->class_, this->level, SE_NecPet);
		}
		if (buffid != 0) {
			this->CastSpell(buffid, this->GetID());
		}
	}
}

int16 Mob::FindSpell(int16 classp, int16 level, int8 type, int8 spelltype) {
	if (this->casting_spell_id != 0)
		return 0;

	if (spelltype == 2) // for future use
		spelltype = 0;

	int count=0;
	int16 bestsofar = 0;
	int16 bestspellid = 0;
	for (int i = 0; i < SPDAT_RECORDS; i++) {
		if ((spells[i].targettype == ST_Tap && spelltype == 1) || (spells[i].targettype != ST_Group && spells[i].targettype != ST_Undead && spells[i].targettype != ST_Summoned && spells[i].targettype != ST_Pet && strstr(spells[i].name,"Summoning") == NULL)) {
			int Canuse = CanUse(i, classp, level);
			if (Canuse != 0) {
				for (int z=0; z < 12; z++) {
					int spfo = CalcSpellValue(spells[i].formula[z], spells[i].base[z], spells[i].max[z], this->GetLevel());
					if (spells[i].effectid[z] == SE_ArmorClass && type == SE_ArmorClass && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_TotalHP && type == SE_TotalHP && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_STR && type == SE_STR && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_DEX && type == SE_DEX && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}

					if (spells[i].effectid[z] == SE_AGI && type == SE_AGI && !FindBuff(i)) {

						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}

					if (spells[i].effectid[z] == SE_WIS && type == SE_WIS && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}

					if (spells[i].effectid[z] == SE_INT && type == SE_INT && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_CHA && type == SE_CHA && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}

					if (spells[i].effectid[z] == SE_MovementSpeed && type == SE_MovementSpeed && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}

					if (spells[i].effectid[z] == SE_AttackSpeed && type == SE_AttackSpeed && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_ResistFire && type == SE_ResistFire && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_ResistCold && type == SE_ResistCold && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_ResistMagic && type == SE_ResistMagic && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_ResistDisease && type == SE_ResistDisease && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_ResistPoison && type == SE_ResistPoison && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_DamageShield && type == SE_DamageShield && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_CurrentHPOnce && type == SE_CurrentHPOnce && !FindBuff(i)) {
						if (spfo > 0 && (spfo + spells[i].buffduration) > bestsofar) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_SummonPet && type == SE_SummonPet && !FindBuff(i)) {
						if (Canuse > bestsofar) {
							bestsofar = Canuse;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_NecPet && type == SE_NecPet && !FindBuff(i)) {
						if (Canuse > bestsofar) {
							bestsofar = Canuse;
							bestspellid = i;
						}
					}
					if (spells[i].effectid[z] == SE_CurrentHP && type == SE_CurrentHP && !FindBuff(i)) {
						if (spfo < 0 && (spells[i].buffduration + spfo) < bestsofar && spelltype == 1) {
							bestsofar = ((spells[i].buffduration * -1) + spfo);
							bestspellid = i;
						}
						if ((spfo + spells[i].buffduration) > bestsofar && spfo > 0 && spelltype == 0) {
							bestsofar = spfo + spells[i].buffduration;
							bestspellid = i;
						}

					}
				}
			}
		}
	}

	return bestspellid;
}

int16 Mob::CanUse(int16 spellid, int16 classa, int16 level) {
	classa = classa-1;
	for (int u=0; u<14; ++u) {
		if (u == classa && level >= spells[spellid].classes[u] && spells[spellid].classes[u] != 0 && spells[spellid].classes[u] != 61) {
			return spells[spellid].classes[u];
		}
	}
	return 0;
}

bool Mob::FindBuff(int16 spellid) {
	for (int i=0;i<15;i++) {
		if (buffs[i].spellid == spellid && buffs[i].spellid != 0xFFFF) {
			return true;
		}
	}
	return false;
}

bool Mob::FindType(int8 type) {
	for (int i=0;i<15;i++) {
		if (buffs[i].spellid != 0xFFFF) {
			for (int o=0; o<12; o++) {
				if (spells[buffs[i].spellid].effectid[o] == SE_ArmorClass && type == SE_ArmorClass) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_TotalHP && type == SE_TotalHP) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_STR && type == SE_STR) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_DEX && type == SE_DEX) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_AGI && type == SE_AGI) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_WIS && type == SE_WIS) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_INT && type == SE_INT) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_CHA && type == SE_CHA) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_ResistFire && type == SE_ResistFire) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_ResistCold && type == SE_ResistCold) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_ResistMagic && type == SE_ResistMagic) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_ResistPoison && type == SE_ResistPoison) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_ResistDisease && type == SE_ResistDisease) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_DamageShield && type == SE_DamageShield) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_MovementSpeed && type == SE_MovementSpeed) {
					return true;
				}
				if (spells[buffs[i].spellid].effectid[o] == SE_AttackSpeed && type == SE_AttackSpeed) {
					return true;
				}
			}
		}
	}
	return false;
}
