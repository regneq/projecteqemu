/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef SPDAT_H
#define SPDAT_H

sint32 CalcSpellValue(int8 formula, sint16 base, sint16 max, int8 caster_level);

//#define SPDAT_SIZE		1824000
/* 
   solar: look at your spells_en.txt and find the id of the last spell.
   this number has to be 1 more than that.  if it's higher, your zone will
   NOT start up.  gonna autodetect this later..
*/
#define SPDAT_RECORDS	3500

//Target Type IDs
#define ST_AECaster			0x04 // ae centered around caster
#define ST_Target			0x05 // single targetted
#define ST_Self				0x06 // self only
#define ST_AETarget			0x08 // ae around target
#define ST_Group			0x29 // group spell
#define ST_Undead			0x0a
#define ST_Tap				0x0d
#define ST_Pet				0x0e
//#define ST_Unknown1			0x14
//#define ST_Unknown			0x18
#define ST_Summoned			0x19
#define ST_Corpse			0x0f


//Spell Effect IDs
#define SE_CurrentHP		0x00 // Heals and nukes, repeates every tic if in a buff
#define SE_ArmorClass		0x01
#define SE_ATK				0x02
#define SE_MovementSpeed	0x03 // SoW, SoC, etc
#define SE_STR				0x04
#define SE_DEX				0x05
#define SE_AGI				0x06
#define SE_STA				0x07
#define SE_INT				0x08
#define SE_WIS				0x09
#define SE_CHA				0x0a // Often used as a spacer, who knows why
#define SE_AttackSpeed		0x0b
#define SE_Invisibility		0x0c
#define SE_SeeInvis			0x0d
#define SE_WaterBreathing	0x0e
#define SE_CurrentMana		0x0f
#define SE_AddFaction		0x13 // Alliance line
#define SE_Stun				0x15
#define SE_Charm			0x16
#define SE_Fear				0x17
#define SE_Stamina			0x18 // Invigor and such
#define SE_BindAffinity		0x19
#define SE_Gate				0x1a // Gate to bind point
#define SE_CancelMagic		0x1b
#define SE_InvisVsUndead	0x1c
#define SE_InvisVsAnimals	0x1d
#define SE_Mez				0x1f
#define SE_SummonItem		0x20
#define SE_SummonPet		0x21
#define SE_DivineAura		0x28
#define SE_ShadowStep		0x2a
#define SE_ResistFire		0x2e
#define SE_ResistCold		0x2f
#define SE_ResistPoison		0x30
#define SE_ResistDisease	0x31
#define SE_ResistMagic		0x32
#define SE_SenseDead		0x34
#define SE_SenseSummoned	0x35
#define SE_SenseAnimals		0x36
#define SE_Rune				0x37
#define SE_TrueNorth		0x38
#define SE_Levitate			0x39
#define SE_Illusion			0x3a
#define SE_DamageShield		0x3b
#define SE_Identify			0x3d
#define SE_WhipeHateList	0x3f
#define SE_SpinTarget		0x40
#define SE_InfaVision		0x41
#define SE_UltraVision		0x42
#define SE_EyeOfZomm		0x43
#define SE_ReclaimPet		0x44
#define SE_TotalHP			0x45
#define SE_NecPet			0x47
#define SE_BindSight		0x49
#define SE_FeignDeath		0x4a
#define SE_VoiceGraft		0x4b
#define SE_Sentinel			0x4c
#define SE_LocateCorpse		0x4d
#define SE_CurrentHPOnce	0x4f // Heals and nukes, non-repeating if in a buff
#define SE_Revive			0x51
#define SE_Teleport			0x53
#define SE_ModelSize		0x59 // Shrink, Growth
#define SE_SummonCorpse		0x5b
#define SE_Root				0x63
#define SE_HealOverTime		0x64

struct SPDat_Spell_Struct
{
/* 000 */	char	name[32];					/* Name of the spell */
/* 032 */	char	player_1[32];				/* "PLAYER_1" */
/* 064 */	char	teleport_zone[32];			/* Teleport zone, or item summoned */
/* 096 */	char	you_cast[64];				/* Message when you cast */
/* 160 */	char	other_casts[64];			/* Message when other casts */
/* 224 */	char	cast_on_you[64];			/* Message when spell is cast on you */
/* 288 */	char	cast_on_other[64];			/* Message when spell is cast on someone else */
/* 352 */	char	spell_fades[64];			/* Spell fades */
/* 416 */	float	range;
/* 420 */	float	aoerange;
/* 424 */	float	pushback;
/* 428 */	float	pushup;
/* 432 */	int32	cast_time;					/* Cast time */
/* 436 */	int32	recovery_time;				/* Recovery time */
/* 440 */	int32	recast_time;				/* Recast same spell time */
/* 444 */	int32	buffdurationformula;
///* 445 */	int8	unknown_1[3];				/* Spacer */
/* 448 */	int32	buffduration;
/* 450 */	int32	ImpactDuration;				/* Spacer */
/* 456 */	int16	mana;						/* Mana Used */
/* 458 */	sint16	base[12];
/* 482 */	sint16	max[12];
/* 508 */	int16	icon;						/* Spell icon */
			int16	memicon;					/* Icon on membarthing */
/* 510 */	sint16	components[4];				// regents
/* 518 */	int component_counts[4];		// amount of regents used
/* 526 */	signed NoexpendReagent[4];				/* Spacer */
/* 530 */	int16	formula[12];     			// Spell's value formula
			int	LightType;				// probaly another effecttype flag
			int	goodEffect;				// 1= very good ;) 2 = Translocate etc unknown4[1]
			int	Activated;				// probaly another effecttype flag	
			
			int	resisttype;
			//int8	badEffect;					//unknown4[3] - Spells can have good & bad effects
/* 546 */	int	effectid[12];				/* Spell's effects */
/* 558 */	int	targettype;					/* Spell's Target */
/* 559 */	int	basediff;					/* I think this has something to do with resists */
/* 560 */	int	skill;
			sint16	zonetype;
			int16	EnvironmentType;
			int	TimeOfDay;
/* 565 */	int	classes[15];				/* Classes */
/* 580 *///	int16	unknown1[3];
		//	sint16 unknown2;
			int8	CastingAnim;
/*0598*/	int8	TargetAnim;
/*0600*/	int32	TravelType;
/*0604*/	int16	SpellAffectIndex;
/*0606*/	int16	Spacing2[5];
			
};
#endif

