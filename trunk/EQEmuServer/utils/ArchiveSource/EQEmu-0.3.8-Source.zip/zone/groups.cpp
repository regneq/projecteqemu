/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "groups.h"
#include "entity.h"
#include "client.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
extern EntityList entity_list;

Group::Group(Client* leader){
	memset(members,0,sizeof(members));
	members[0] = leader;
	leader->isgrouped = true;
}

bool Group::AddMember(Client* newmember){
int i = 0;
	while(1) {
		if (i == 5)
			return false;
		if (members[i] == 0){
			members[i] = newmember;
			break;
		}
		i++;
	}
	APPLAYER* outapp = new APPLAYER(OP_GroupUpdate,sizeof(GroupUpdate_Struct));
	memset(outapp->pBuffer,0,outapp->size);
	GroupUpdate_Struct* gu = (GroupUpdate_Struct*) outapp->pBuffer;

	strcpy(gu->yourname,newmember->GetName());
	gu->action = 0;
	for (i = 0;i != 5;i++){
		if (members[i] != 0 && members[i] != newmember){
#ifdef CATCH_CRASH
			try{
#endif
				strcpy(gu->membername,members[i]->GetName());
				newmember->QueuePacket(outapp);
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}

	strcpy(gu->membername,newmember->GetName());
	for (i = 0;i != 5;i++){
		if (members[i] != 0 && members[i] != newmember){
#ifdef CATCH_CRASH
			try{
#endif
				strcpy(gu->yourname,members[i]->GetName());
				members[i]->QueuePacket(outapp);
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}
	delete outapp;
	newmember->isgrouped = true;
	return true;
}

bool Group::DelMember(Client* oldmember,bool ignoresender){
	int i = 0;
	if (oldmember == 0)
		return false;
	while(1) {
		if (i == 5)
			return false;
		if (members[i] == oldmember){
			members[i] = 0;
			break;
		}
		i++;
	}	
	APPLAYER* outapp = new APPLAYER(OP_GroupUpdate,sizeof(GroupUpdate_Struct));
	memset(outapp->pBuffer,0,outapp->size);
	GroupUpdate_Struct* gu = (GroupUpdate_Struct*) outapp->pBuffer;
	gu->action = 6;
	strcpy(gu->membername,oldmember->GetName());
	for (i = 0;i != 5;i++){
		if (members[i] != 0 && (members[i] != oldmember)){
#ifdef CATCH_CRASH
			try{
#endif
				strcpy(gu->yourname,members[i]->GetName());
				members[i]->QueuePacket(outapp);
//				DumpPacket(outapp);
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}
	if (!ignoresender){
		strcpy(gu->yourname,oldmember->GetName());
		strcpy(gu->membername,oldmember->GetName());
		gu->action = 6;
		oldmember->QueuePacket(outapp);
	}
	delete outapp;
	oldmember->isgrouped = false;
	return true;
}

void Group::DisbandGroup(){
int i = 0;
	APPLAYER* outapp = new APPLAYER(OP_GroupUpdate,sizeof(GroupUpdate_Struct));
	memset(outapp->pBuffer,0,outapp->size);
	GroupUpdate_Struct* gu = (GroupUpdate_Struct*) outapp->pBuffer;
	gu->action = 4;
	for (i = 0;i != 5;i++){
		if (members[i] != 0){
#ifdef CATCH_CRASH
			try{
#endif
				strcpy(gu->yourname,members[i]->GetName());
				members[i]->QueuePacket(outapp);
				members[i]->isgrouped = false;
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}	
	delete outapp;
	entity_list.RemoveEntity(this->GetID());
}
void Group::CastGroupSpell(Client* caster, uint16 spellid){
int i = 0;
	for (i = 0;i != 5;i++){
		if (members[i] != 0){
#ifdef CATCH_CRASH
			try{
#endif
				caster->SpellOnTarget(spellid,members[i]);
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}	
}

void Group::SplitExp(uint32 exp){
int i = 0;
uint32 groupexp = exp;
int8 membercount = 0;
for (i = 0;i != 5;i++){ //10% bonus per groupmember
		if (members[i] != 0){
			groupexp += exp/10;
				membercount++;
		}
	}	
	for (i = 0;i != 5;i++){
		if (members[i] != 0){
#ifdef CATCH_CRASH
			try{
#endif
				// add exp + exp cap
				members[i]->AddEXP(((members[i]->GetLevel()+3) * (members[i]->GetLevel()+3) * 75*3.5f < groupexp/membercount ) ? members[i]->GetLevel() * members[i]->GetLevel() * 75*3.5f:groupexp/membercount );
#ifdef CATCH_CRASH
			}
			catch(...){
				cout << "ERROR: Invalid client in group found" << endl;
				members[i] = 0;
			}
#endif
		}
	}	
}

bool Group::IsGroupMember(Client* client){
	for (int i = 0;i != 5;i++){
		if (members[i] == client)
			return true;
	}
	return false;
}

void Group::GroupMessage(Client* sender,char* message){

	for (int i = 0;i != 5;i++){
		if (members[i] != 0) {
			members[i]->CastToClient()->ChannelMessageSend(sender->GetName(),members[i]->GetName(),2,0,message);	
		}
	}	
}