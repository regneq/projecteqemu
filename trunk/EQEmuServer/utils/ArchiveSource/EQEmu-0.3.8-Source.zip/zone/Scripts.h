#include "../common/types.h"
#include "../common/seperator.h"
#include "Mob.h"
#include "../common/linked_list.h"

#define TriggerOP_Text		1
#define TriggerOP_Item		2
#define TriggerOP_Death		3
#define TriggerOP_Arrgo		4
#define TriggerOP_Timer		5

class Scripts;

struct sTriggerArray {
	int32	TriggerOP;
	int32	NPCTypeID;
	int32	ActionID;
	int32	MatchID;
	char*	MatchText;
};

struct sActionArray {
	int32	version;
	int32	dbID;
	char	ActionText[0];
};

struct sTriggerTimer {
	int32	TriggerTime;
	int32	ActionID;
	int16	EntityID;
};

class Scripts {
public:
	static bool		IsCommented(char* line);
	static void		KillFrontWhitespace(Seperator* sep);
	static char*	KillFrontWhitespace(char* line);

	Scripts();
	~Scripts();

	// NPCTypeID = 0 means it's a "zone" trigger, returns number of triggers hit
	int32	DoTrigger(int32 iTriggerOP, int32 iNPCTypeID = 0, Mob* causer = 0, NPC* responder = 0, int32 iMatchID = 0, char* iMatchText = 0); // True if trigger found (and executed)
	bool	Load(char* filename);
	void	Clear();	// Unload all scripts
	void	RemoveTimerByEntityID(int16 entityid);
	void	CheckTimers();
protected:
	int32	AddAction(char* iActionText, int32 version);
	int32	AddTrigger(int32 iTriggerOP, int32 iNPCTypeID, int32 iActionID, int32 iMatchID = 0, char* iMatchText = 0);
	void	AddTimer(int32 iDelay, int32 iActionID, int16 entityid = 0);
private:
	bool	Phraser(char* iPhraseText);
	bool	Phraser_v1(Seperator* linesep);
	bool	Phraser_v2(Seperator* linesep);
	void	DoAction(sActionArray* iAction, Mob* causer = 0, NPC* responder = 0);
	void	DoAction_v1(sActionArray* iAction, Mob* causer, NPC* responder);
	void	DoAction_v2(sActionArray* iAction, Mob* causer, NPC* responder);

	sTriggerArray*	triggerarray;
	sActionArray**	actionarray;
	int32			max_triggerarray;
	int32			max_actionarray;

	LinkedList<sTriggerTimer*> timer_list;
	int32			NextTimer;
};
