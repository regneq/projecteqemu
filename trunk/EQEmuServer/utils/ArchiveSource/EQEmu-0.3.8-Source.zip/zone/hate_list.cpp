

#include "../common/debug.h"
#include <assert.h>
#include <stdlib.h>
#include "mob.h"
#include "client.h"
#include "hate_list.h"

HateList::HateList()
{
  list=0;
}

HateList::~HateList()
{
  Wipe();
}

void HateList::Wipe()
{
  struct hl_struct *prev, *cur;
  if(list)
  {
    cur=list;
    do
    {
      prev=cur;
      cur=cur->next;
      delete prev;
    }
    while(cur);
  }

  list=NULL;
}

struct hl_struct *HateList::Find(Mob *ent)
{
  struct hl_struct *cur;

  for(cur=list;cur;cur=cur->next)
    if(ent == cur->ent) return cur;

  return NULL;
}

void HateList::Add(Mob *ent, sint32 in_dam, sint32 in_hate)
{
  struct hl_struct *cur, *newelem;

  if(!ent) return;

  if((unsigned)in_hate == 0xffffffff)
    in_hate=in_dam;

  if((cur=Find(ent)))	/* already in hate list */
  {
    cur->damage+=in_dam;
    cur->hate+=in_hate;

    while(cur->prev && (cur->hate > cur->prev->hate)) /* this ent moved up in the list */
    {
      /* A B CUR D */
      /* A CUR B D */
      struct hl_struct *a, *b, *c, *d;
      a=cur->prev->prev;
      b=cur->prev;
      c=cur;
      d=cur->next;

      if(a) a->next=c;
      if(d) d->prev=b;
      c->prev=a;
      c->next=b;
      b->prev=c;
      b->next=d;
    }
    return;
  }
  else
  {
    newelem=new struct hl_struct;
    assert(newelem != NULL);
    memset(newelem, 0, sizeof(struct hl_struct));
    newelem->ent=ent;
    newelem->damage=in_dam;
    newelem->hate=in_hate;

    if(!list)
    {
      list=newelem;
      return;
    }

    for(cur=list;cur->next;cur=cur->next)
      if(newelem->hate > cur->hate) /* newelem goes before cur */
      {
        if(cur == list)	/* we're gonna be at the head of the list */
        {
          newelem->next=cur;
          cur->prev=newelem;
          list=newelem;
        }
        else
        {
          assert(cur->prev != NULL);
          newelem->next=cur;
          cur->prev->next=newelem;
          cur->prev=newelem;
        }
        return;
      }

    assert(cur->next == NULL);
    cur->next=newelem;
    newelem->prev=cur;
    return;
  }
}

void HateList::RemoveEnt(Mob *ent)
{
  struct hl_struct *cur;

  for(cur=list;cur;cur=cur->next)
    if(cur && cur->ent == ent)
    {
      if(cur == list)
        list=cur->next;
      if(cur->prev)
        cur->prev->next=cur->next;
      if(cur->next)
        cur->next->prev=cur->prev;
      delete cur;
      return;
    }
}

void HateList::DoFactionHits(int32 npc_id)
{
  struct hl_struct *cur;

  for(cur=list;cur;cur=cur->next)
    if(cur->ent->IsClient())
    {
      Client *client=cur->ent->CastToClient();
      client->SetFactionLevel(client->CharacterID(), npc_id, client->GetClass(), client->GetRace(), client->GetDeity());
    }
}

Mob *HateList::GetTop()
{
  if(list)
    return list->ent;
  else
    return NULL;
}

Mob *HateList::GetRandom()
{
  int count, elem;
  struct hl_struct *cur;

  for(count=0,cur=list;cur;cur=cur->next,count++);
  if(!count) return NULL;
  elem=rand()%count;
  for(cur=list,count=0;count<elem;cur=cur->next,count++);
  return cur->ent;
}

sint32 HateList::GetEntHate(Mob *ent)
{
  struct hl_struct *cur;

  cur=Find(ent);

  if(cur)
    return cur->hate;
  else
    return 0;
}

