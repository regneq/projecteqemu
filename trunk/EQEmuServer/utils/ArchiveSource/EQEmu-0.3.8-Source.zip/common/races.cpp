/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "../common/eq_packet_structs.h"
#include "../common/races.h"

const char* GetRaceName(int8 race) {
	switch(race) {
		case HUMAN:
			return "Human";
		case BARBARIAN:
			return "Barbarian";
		case ERUDITE:
			return "Erudite";
		case WOOD_ELF:
			return "Wood Elf";
		case HIGH_ELF:
			return "High Elf";
		case DARK_ELF:
			return "Dark Elf";
		case HALF_ELF:
			return "Half Elf";
		case DWARF:
			return "Dwarf";
		case TROLL:
			return "Troll";
		case OGRE:
			return "Ogre";
		case HALFLING:
			return "Halfling";
		case GNOME:
			return "Gnome";
		case IKSAR:
			return "Iksar";
		case WEREWOLF:
			return "Werewolf";
		case SKELETON:
			return "Skeleton";
		case ELEMENTAL:
			return "Elemental";
		case EYE_OF_ZOMM:
			return "Eye of Zomm";
		case WOLF_ELEMENTAL:
			return "Wolf Elemental";
		case IKSAR_SKELETON:
			return "Iksar Skeleton";
		case VAHSHIR:
			return "Vah Shir";
		default:
			return "Unknown";
	}
}
