EQEMu 0.2.5  (March 16, 2002)


What�s New in 0.2.5:-------------------------------------------------------
---------------------------------------------------------------------------

highlights: Scruffy fixed fRadius bug (No more crashing! YAY)

See CHANGELOG.TXT for complete details on fixes. 





________________________________________________________________________________________________________________________________________________________________________________________________________________

          EQEmu Windows Install Guide v3.5 by Shawn319. Revised 3/16/2002 2:00 AM EST
                                ---------------------------------

    This install guide is designed for EQEmu 0.2.5 and may not be accurate in other versions
                                
                                 http://eqemu.sourceforge.net



*Note: There is two ways to setup a server and connect. 
____________________________________________________________________________________________

First way: Connecting to an EQEmu server using Gotfrags Loginserver-------------------------
--------------------------------------------------------------------------------------------

Part 1: Setting EQ up to work with the emulator.


1) Patch to the current version of Everquest by running "Everquest" on your desktop or by running Everquest.exe in your EQ directory.

2) Download EQW 2.21 from http://eqw.eqhackers.com/

3) Extract eqw.zip into your Everquest directory. It would also be a good idea to create a shortcut of this file on your desktop or EQEmu directory. 

**NOTE: EQW requires your desktop be set to 16 bit color mode.

4) Open eqhost.txt in your EQ directory and change it to say this (use copy/paste):

[Registration Servers]
{
"eqlogin.gotfrags.com:5999"
}
[Login Servers]
{
"eqlogin.gotfrags.com:5999"
}



--------------------------------------------------------------------------------------------

Part 2: Setting up EQEmu.


1) Unzip the EQEmu zip files to a folder on your desktop or on your main drive (I would recommend C:\eqemu)

2) Copy spdat.eff from your Everquest directory to your EQEmu directory (Should be C:\eqemu)


--------------------------------------------------------------------------------------------

Part 3: Setting up mySQL Database.


1) Download and install mySQL from http://www.mysql.com.

2) Copy db.sql from your EQEmu folder to the mySQL bin directory (usually C:\mysql\bin).

3) In your mySQL bin directory, run Winmysqladmin.exe and it should ask you to enter a username and password. Choose a username and password that you can remember because you will need it later.

4) After you have chosen a username and password go to the Database tab in mySQL and right click the area for Databases and click Create Database.

5) Type in eq as the database name and click Create database.

6) Close winmysqladmin.

7) Run mysql.exe in your mySQL bin directory. 

8) Type "use eq" without the quotes and hit enter. It should say Database changed.

9) Type "source db.sql" without the quotes and hit enter. A lot of lines should pass by and that is normal. If you get an error at this point then you didn�t copy db.sql into the mySQL/bin folder.

10) Close mySQL.exe.

--------------------------------------------------------------------------------------------

Part 4: Setting up EQEmu ini settings.


1) In your EQEmu directory (where you extracted the files) open db.ini and it should look like this:

# READ README.TXT!

[Database]
host=192.168.0.x
user=eqemu
password=eqemu
database=eq

Change host to say localhost and the user/password to the username/password you set for mySQL (You did write it down didn�t you??)

Db.ini should now say:

[Database]
host=localhost
user=yourMYSQLusername
password=yourMYSQLpassword
database=eq

Close and save db.ini.

2) In your EQEmu directory, open loginserver.ini and it should look like this:

[LoginServer]
loginserver=eqlogin.gotfrags.com
worldname=Your Server Name Here
locked=false
worldaddress=
account=
password=
worldaddress=
loginport=5999

Don�t change the loginserver because the only one up right now is Gotfrags.

Worldname is where you would put the name of your server (How it would appear on the server select screen).

Worldaddress requires your real IP address. If you leave this field blank you will get an incorrect version error in world.exe.

Account and password should be left blank unless an Admin at Gotfrags has made an account for you. If they have then put the account and password they gave you.

3) Edit Boot5Zones.bat (right click it and hit EDIT, then change all 127.0.0.1 entries to your IP).

--------------------------------------------------------------------------------------------

Part 5: Running the server for the first time.


1) In your EQEmu directory run world.exe and it should say:

LoginServer.ini read.
Using database 'eq' at localhost
Loading guild ranks...done.
World server listening on port:9000
Connected to LoginServer: eqlogin.gotfrags.com:5999

If you get any errors then you didn�t setup the mySQL database or db.ini correctly.

2) Run Boot5Zones.bat (You no longer need to have a zone up, only empty zone servers)

It should say:

Using database 'eq' at localhost
Loading items & NPCs...Done.
Spells loaded from 'spdat.eff'.
Loading guild ranks...done.
Connected to worldserver: YourIP:Port
Entering sleep mode


3) Run eqw.exe (or the shortcut you made). 

4) Click connect and enter your Login and Password for the Gotfrags loginserver (You can register one for free at http://eq.gotfrags.com:443)

Make your character just as you would in Everquest and when your done click Enter World.

____________________________________________________________________________________________


Second way: Connecting via minilogin:---------------------------------------
-----------------------------------------------------------------------------

1) Follow part 1 but edit eqhost.txt to say:


[Registration Servers]
{
"localhost:5999"
}
[Login Servers]
{
"localhost:5999"
}


2) Follow part 2 and 3.

3) Follow part 4 step 1, 2 and 3 but change loginserver.ini to say this

[LoginServer]
loginserver=localhost
worldname=Your server name here
locked=false
account=
password=
worldaddress=localhost
loginport=5999

and make sure Boot5Zones.bat has 127.0.0.1 as all of the IP addresses 
(Right click and hit Edit)

4) Run minilogin.exe

5) Run World.exe

6) Run Boot5Zones.bat

7) Connect using the login/password eqemu/eqemu 
(It is the only account that will with with Minilogin)



If you want to flag the EQEmu account, at the command line run:

World.exe flag EQEmu status

Status Listing: 0= Normal, 10= PU, 80= Quest Troupe, 100= GM, 101= GM-Events, 150= LGM, 200= Serverop


*Note: Connecting via minilogin only supports one account at this time.


Other:-----------------------------------------------------------------------
-----------------------------------------------------------------------------


Command list:


EQEMu Commands:

#itemsearch [id]  searches item database
#summonitem [id]  summon item
#goto  [x,y,z]    warps you to coords
#zone [zonename]  zones to safepoint in zonename
#zonestatus       shows what zones are up
#guild            guild commands (type for more info)
#showstats        Shows what the server thinks your stats are


EQEMu Priviliged User Commands (10):

#level  [id]    sets target level.
#heal   (PC ONLY) completely heals target
#spawn   lets you spawn a creature
#dbspawn [npctypeid]
#mana               replenishes target PC mana
#texture [texture] [helmtexture]  (0-255, 255 for show equipment)
#gender [0-2]  (0=male, 1=female, 2=neuter)
#npctypespawn [npctype]


EQEMu Very Priviliged User Commands (20):

#size [size]        sets your targets size
#FindSpell [spellname]
#CastSpell [id]
#setskill [skill num (0-73)] [number (0-255)] - Sets the targeted player's skill to number.
#setallskill [0-255] - Sets all of the targeted player's skills to number.
#kill   kills your selected target
#flymode
#race [0-255]  (0 for back to normal)


EQEMu Quest Troupe Commands (80):

#showloot    shows the loot the targeted npc is packing
#npcstats - shows the stats of the targetted NPC.
#zheader [zone name/none] - Change the sky/fog/etc. of the current zone.
#zsky [sky number] - Changes the sky of the current zone.
#zcolor [red] [green] [blue] - Changes the fog colour of the current zone.
#zstats - Shows the zone header data for the current zone.
#timeofday - Sets the date to Monday, Janurary 1st, 1 at the specified time.
#date - Sets the time to the specified date.
#weather <0/1/2> - Off/Rain/Snow.
#permaclass <classnum> - Changes your class.
#permarace <racenum> - Changes your race.
#permagender <0/1/2> - Changes your gender.


EQEMu GM Commands (100):

#damage [id]   inflicts damage upon target.
#setxp   sets target exp
#emote   sends emotish message, type for syntax
/broadcast [text]   broadcasts text
/pr [text]          sends text over GMSAY
#Depop              Depops targeted NPC
#DepopZone          Depops the zone
#Repop [delay]      Repops the zone, optional delay in seconds
#zuwcoords [number] - Changes the underworld coordinates of the current zone.
#zsafecoords [x] [y] [z] - Changes the safe coordinates of the current zone.
#zclip [min clip] [max clip] - Changes the clipping plane of the current zone.
#invul [1/0]        makes the targeted player invul to attack
#hideme [0/1] - removes you from the spawm list
#npccast targetname spellid - makes the targeted NPC cast on targetname
#ListNPCs           Lists all the NPCs currently spawned
#ListNPCCorpses     Lists all NPC corpses in the zone
#ListPlayerCorpses  Lists all player corpses in the zone
#DeleteNPCCorpses   Deletes all NPC corpses in the zone
#freeze - Freezes your current target.
#unfreeze - Unfreezes your current target.
#pkill - Makes current target pkill.
#unpkill - Makes current target nonpkill.


EQEMu Lead-GM Commands (150):

#summon [charname]  summons a player to you
#kick [charname]    kicks player off of the server
#zoneshutdown [ZoneID | ZoneName]  shuts down the zoneserver
#zonebootup [ZoneID] [ZoneName]    boots ZoneName on the zoneserver specified
#deletecorpse - delete targeted player corpse
#DeletePlayerCorpses - deletes all player corpses in the zone
#motd [New MoTD Message]  Changes the server's MOTD
#lock    Locks the worldserver
#unlock  Unlocks the world server


EQEMu ServerOP Commands (200):

#shutdown        shuts down the server.
#worldshutdown   shuts down the worldserver and all zones
#flag [name] [status]  flags account with GM status
#createacct [name] [password] [status]   creates a Everquest account.
#delacct [name]   deletes an EQEmu account.
#zsave [file name] - Save the current zone header to ./cfg/<filename>.cfg
#dbspawn2 [spawngroup] [respawn] [variance]
#version    shows build date of zone.exe

#setskill command-----------------------------------------------------

List of skills for use with #setskill command 
(You can also use #setallskill 252 to max all skills).

Usage: #setskill # amount

(#setskill 0 252 would give a 252 skill in 1h Slashing)


1H SLASHING			0

2H SLASHING			1

PIERCING			2

1H BLUNT			3

2H BLUNT			4

ALTERATION			5

APPLY POISON			6

ARCHERY				7

BACKSTAB			8

BIND WOUND			9

BASH				10

BLOCK				11

BRASS INSTRUMENTS		12

CHANNELING			13

CONJURATION			14

DEFENSE				15

DISARM				16

DISARM TRAPS			17

DIVINATION			18

DODGE				19

DOUBLE ATTACK			20

DRAGON PUNCH			21

DUEL WIELD			22

EAGLE STRIKE			23

EVOCATION			24

FEIGN DEATH			25

FLYING KICK		        26

FORAGE				27

HAND TO HAND	             	28

HIDE				29

KICK				30

MEDITATE			31

MEND				32

OFFENSE				33

PARRY				34

2H PIERCING			35

RIPOSTE				37

ROUND KICK			38

SAFE FALL			39

SENSE HEADING			40

SING				41

SNEAK				42

SPECIALIZE ABJURE		43

SPECIALIZE ALTERATION	        44

SPECIALIZE CONJURATION       	45

SPECIALIZE DIVINATION   	46

SPECIALIZE EVOCATION	        47

PICK POCKETS			48

STRINGED INSTRUMENTS     	49

SWIMMING			50

THROWING			51

TIGER CLAW			52

TRACKING			53

WIND INSTRUMENTS		54

FISHING				55

MAKE POISON			56

TINKERING			57

RESEARCH			58

ALCHEMY				59

BAKING				60

TAILORING			61

SENSE TRAPS			62

BLACKSMITHING			63

FLETCHING			64

BREWING				65

ALCOHOL TOLERANCE		66

BEGGING				67

JEWELRY MAKING			68

POTTERY				69

PERCUSSION INSTRUMENTS	        70

INTIMIDATION			71

BERSERKING			72

TAUNT				73

-------------------------------------------------------------------
#spawn command-----------------------------------------------------

List of races to use with #spawn command (Incomplete).

*Note: Not all races will work in any certain zone. The model has to be in the zonename_chr.s3d or the global files or it will show up as human

0 Soldier
1 Human
2 Barbarian
3 Erudite
4 Wood Elf
5 High Elf
6 Dark Elf
7 Half Elf
8 Dwarf
9 Troll
10 Ogre
11 Halfling
12 Gnome
13 Aviak
14 Were Wolf
15 Brownie
16 Centaur
17 Golem
18 Giant / Cyclops
19 Trakenon
20 Doppleganger
21 Evil Eye
22 Beetle
23 Kerra
24 Fish
25 Fairy
26 Froglok
27 Froglok Ghoul
28 Fungusman
29 Gargoyle
30 Gasbag
31 Gelatinous Cube
32 Ghost
33 Ghoul
34 Giant Bat
35 Giant Eel
36 Giant Rat
37 Giant Snake
38 Giant Spider
39 Gnoll
40 Goblin
41 Gorilla
42 Wolf
43 Bear
44 Freeport Guards
45 Demi Lich
46 Imp
47 Griffin
48 Kobold
49 Lava Dragon
50 Lion
51 Lizard Man
52 Mimic
53 Minotaur
54 Orc
55 Human Beggar
56 Pixie
57 Dracnid
58 Solusek Ro
59 Bloodgills
60 Skeleton
61 Shark
62 Tunare
63 Tiger
64 Treant
65 Vampire
66 Rallos Zek
67 Highpass Citizen
68 Tentacle
69 Will O Wisp
70 Zombie
71 Qeynos Citizen
72 Ship
73 Launch
74 Piranha
75 Elemental
76 Puma
77 Neriak Citizen
78 Erudite Citizen
79 Bixie
80 Reanimated Hand
81 Rivervale Citizen
82 Scarecrow
83 Skunk
84 Snake Elemental
85 Spectre
86 Sphinx
87 Armadillo
88 Clockwork Gnome
89 Drake
90 Halas Citizen
91 Alligator
92 Grobb Citizen
93 Oggok Citizen
94 Kaladim Citizen
95 Cazic Thule
96 Cockatrice
97 Daisy Man
98 Elf Vampire
99 Denizen
100 Dervish
101 Efreeti
102 Froglok Tadpole
103 Kedge
104 Leech
105 Swordfish
106 Felguard
107 Mammoth
108 Eye of Zomm
109 Wasp
110 Mermaid
111 Harpie
112 Fayguard
113 Drixie
114 Ghost Ship
115 Clam
116 Sea Horse
117 Ghost Dwarf
118 Erudite Ghost
119 Sabertooth Cat
120 Wolf Elemental
121 Gorgon
122 Dragon Skeleton
123 Innoruuk
124 Unicorn
125 Pegasus
126 Djinn
127 Invisible Man
128 Iksar
129 Scorpion
130 Vah Shir
131 Sarnak
132 Draglock
133 Lycanthrope
134 Mosquito
135 Rhino
136 Xalgoz
137 Kunark Goblin
138 Yeti
139 Iksar Citizen
140 Forest Giant
141 Boat
144 Burynai
145 Goo
146 Spectral Sarnak
147 Spectral Iksar
148 Kunark Fish
149 Iksar Scorpion
150 Erollisi
151 Tribunal
152 Bertoxxulous
153 Bristlebane
154 Fay Drake
155 Sarnak Skeleton
156 Ratman
157 Wyvern
158 Wurm
159 Devourer
160 Iksar Golem
161 Iksar Skeleton
162 Man Eating Plant
163 Raptor
164 Sarnak Golem
165 Water Dragon
166 Iksar Hand
167 Succulent
168 Flying Monkey
169 Brontotherium
170 Snow Dervish
171 Dire Wolf
172 Manticore
173 Totem
174 Cold Spectre
175 Enchanted Armor
176 Snow Bunny
177 Walrus
178 Rock-gem Men
181 Yak Man
182 Faun
183 Coldain
184 Velious Dragons
185 Hag
186 Hippogriff
187 Siren
188 Frost Giant
189 Storm Giant
190 Ottermen
191 Walrus Man
192 Clockwork Dragon
193 Abhorent
194 Sea Turtle
195 Black and White Dragons
196 Ghost Dragon
197 Ronnie Test
198 Prismatic Dragon
199 ShikNar
200 Rockhopper
201 Underbulk
202 Grimling
203 Vacuum Worm
204 Evan Test
205 Kahli Shah
206 Owlbear
207 Rhino Beetle,
208 Vampyre
209 Earth Elemental
210 Air Elemental
211 Water Elemental
212 Fire Elemental
213 Wetfang Minnow
214 Thought Horror
215 Tegi
216 Horse
217 Shissar
218 Fungal Fiend
219 Vampire Volatalis
220 StoneGrabber
221 Scarlet Cheetah
222 Zelniak
223 Lightcrawler
224 Shade
225 Sunflower
226 Sun Revenant
227 Shrieker
228 Galorian
229 Netherbian
230 Akheva
231 Spire Spirit
232 Sonic Wolf
233 Ground Shaker
234 Vah Shir Skeleton
235 Mutant Humanoid
236 Seru
237 Recuso
238 Vah Shir King
239 Vah Shir Guard
240 Teleport Man (Invisible)
255 Pathing cube (Do not use)
655 Tree 1 of current zone
654 Weed of current Zone


-----------------------------------------------------------------

If you want to change the MOTD, in MySQL type:

UPDATE variables SET value='test' WHERE varname='MOTD';

Replacing test with the MOTD you want. (Or you can use the EQemu Admin Tool)
-----------------------------------------------------------------

If you want to disable the worldserver command line, in MySQL type:

UPDATE variables SET value='1' WHERE varname='disablecommandline';

1 = disabled, 0 = enabled. (Record not there = enabled)

"World clean" is always enabled. (Or you can use the EQEmu Admin Tool, By Windcatcher)


Links:-----------------------------------------------------------------------
-----------------------------------------------------------------------------
EQEmu Homepage: http://eqemu.sourceforge.net/ 

EQEmu Sourceforge Page: https://sourceforge.net/projects/eqemu/

EQEmu Admin Tool is very useful for DB editing and is available on the EQemu Sourceforge page.
