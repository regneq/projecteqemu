#include "../common/debug.h"
#include <iostream.h>

#include "hate_list.h"
#include "mob.h"
#include "client.h"

HateList::HateList()
{
  first = 0;
}

HateList::~HateList()
{
	if (first != 0)
	{
		delete first;
	}
}


void HateList::Add(Mob* ent, sint32 in_dam, sint32 in_hate) {
	if (ent == 0)
		return;
	if (in_hate == 0xFFFFFFFF) {
		// TODO: Some calulations or something
		in_hate = in_dam;
	}

	HateListElement* tmp = Pop(ent);
	if (tmp) {
		tmp->AddHate(in_dam, in_hate);
	}
	else {
		tmp = new HateListElement(ent, in_dam, in_hate);
	}

	HateListElement* current = first;
	HateListElement* prev = 0;
	while (current) {
		if (current->GetHate() < tmp->GetHate()) {
			break;
		}
		prev = current;
		current = current->GetNext();
	}
	tmp->SetNext(current);
	if (prev) {
		prev->SetNext(tmp);
	}
	else {
		first = tmp;
	}
}

HateListElement* HateList::Pop(Mob* in_ent) {
	HateListElement *current = first;
	HateListElement *prev = 0;

	while (current != 0) {
		if (current->GetEnt() == in_ent) {
			break;
		}
		prev = current;
		current = current->GetNext();
	}

	if (current != 0) {
		if (prev == 0) {
			first = current->GetNext();
		}
		else {
			prev->SetNext(current->GetNext());
		}
		current->SetNext(0);
		return current;
	}

	return 0;
}

Mob* HateList::GetTop()
{
	if (first == 0)
	{
		return 0;
	}

	return first->GetEnt();
}

void HateList::RemoveEnt(Mob *ent) {
	HateListElement *current = first;
	HateListElement *prev = 0;

	while (current != 0) {
		if (current->GetEnt() == ent)
		{
			break;
		}
		prev = current;
		current = current->GetNext();
	}

	if (current != 0) {
		if (prev == 0) {
			first = current->GetNext();
		}
		else {
			prev->SetNext(current->GetNext());
		}
		current->SetNext(0);
		delete current;
	}
}

void HateList::Whipe() {
	if (first != 0) {
		delete first;
		first = 0;
	}
}

void HateList::DoFactionHits(int32 npc_id) {
	if (first != 0)
		first->DoFactionHits(npc_id);
}

void HateListElement::DoFactionHits(int32 npc_id) {
	if (ent->IsClient()) {
		Client* client = ent->CastToClient();
		client->SetFactionLevel(client->CharacterID(), npc_id, client->GetClass(), client->GetRace(), client->GetDeity());
	}
	if (next != 0)
		next->DoFactionHits(npc_id);
}

