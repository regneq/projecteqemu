#ifndef SPAWN2_H
#define SPAWN2_H

#include "../common/timer.h"
class Spawn2
{
public:
	Spawn2(int32 spawn2_id, int32 spawngroup_id, float x, float y, float z, float heading, int32 respawn, int32 variance, int32 timeleft = 0);
	~Spawn2();

	void	Enable();
	bool	Process();
	void	Reset();
	void	Depop();
	void	Repop(int32 delay = 0);

	int32	GetID()		{ return spawn2_id; }
	float	GetX()		{ return x; }
	float	GetY()		{ return y; }
	float	GetZ()		{ return z; }
protected:
	friend class Zone;
	int32	spawn2_id;
	Timer*	timer;
private:
	int32	resetTimer();

	int32	spawngroup_id_;
	float	x;
	float	y;
	float	z;
	float	heading;
	int32	respawn_;
	int32	variance_;
};

#endif
