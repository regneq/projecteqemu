#include "../common/debug.h"
#include "../common/eq_packet_structs.h"
#include "../common/classes.h"

char* GetClassName(int8 class_) {
	switch(class_) {
		case WARRIOR:
			return "Warrior";
		case CLERIC:
			return "Cleric";
		case PALADIN:
			return "Paladin";
		case RANGER:
			return "Ranger";
		case SHADOWKNIGHT:
			return "ShadowKnight";
		case DRUID:
			return "Druid";
		case MONK:
			return "Monk";
		case BARD:
			return "Bard";
		case ROGUE:
			return "Rogue";
		case SHAMAN:
			return "Shaman";
		case NECROMANCER:
			return "Necromancer";
		case WIZARD:
			return "Wizard";
		case MAGICIAN:
			return "Magician";
		case ENCHANTER:
			return "Enchanter";
		case BEASTLORD:
			return "Beastlord";
		case BANKER:
			return "Banker";
		case WARRIORGM:
			return "Warrior Guildmaster";
		case CLERICGM:
			return "Cleric Guildmaster";
		case PALADINGM:
			return "Paladin Guildmaster";
		case RANGERGM:
			return "Ranger Guildmaster";
		case SHADOWKNIGHTGM:
			return "Shadowknight Guildmaster";
		case DRUIDGM:
			return "Druid Guildmaster";
		case MONKGM:
			return "Monk Guildmaster";
		case BARDGM:
			return "Bard Guildmaster";
		case ROGUEGM:
			return "Rogue Guildmaster";
		case SHAMANGM:
			return "Shaman Guildmaster";
		case NECROMANCERGM:
			return "Necromancer Guildmaster";
		case WIZARDGM:
			return "Wizard Guildmaster";
		case MAGICIANGM:
			return "Magician Guildmaster";
		case ENCHANTERGM:
			return "Enchantet Guildmaster";
		case BEASTLORDGM:
			return "Beastlord Guildmaster";
		case MERCHANT:
			return "Merchant";
		default:
			return "Unknown";
	}
}

