/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>

#include "../common/database.h"
#ifdef WIN32
#define snprintf	_snprintf
#endif

extern Database database;

// Queries the loottable: adds item & coin to the npc
void Database::AddLootTableToNPC(int32 loottable_id, ItemList* itemlist, int32* copper, int32* silver, int32* gold, int32* plat) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	*copper = 0;
	*silver = 0;
	*gold = 0;
	*plat = 0;
	
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id, mincash, maxcash, avgcoin FROM loottable WHERE id=%i", loottable_id), errbuf, &result)) {
		safe_delete(query);
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			int32 mincash = atoi(row[1]);
			int32 maxcash = atoi(row[2]);
			if (mincash > maxcash) {
				cerr << "Error in loottable #" << row[0] << ": mincash > maxcash" << endl;
			}
			else if (maxcash != 0) {
				int32 cash = 0;
				if (mincash == maxcash)
					cash = mincash;
				else
					cash = (rand() % (maxcash - mincash)) + mincash;
				if (cash != 0) {
					int32 coinavg = atoi(row[3]);
					if (coinavg != 0) {
						int32 mincoin = (int32) (coinavg * 0.75 + 1);
						int32 maxcoin = (int32) (coinavg * 1.25 + 1);
						*copper = (rand() % (maxcoin - mincoin)) + mincoin - 1;
						*silver = (rand() % (maxcoin - mincoin)) + mincoin - 1;
						*gold = (rand() % (maxcoin - mincoin)) + mincoin - 1;
						cash -= *copper;
						cash -= *silver * 10;
						cash -= *gold * 10;
					}
					*plat = cash / 1000;
					cash -= *plat * 1000;
					int32 gold2 = cash / 100;
					cash -= gold2 * 100;
					int32 silver2 = cash / 10;
					cash -= silver2 * 10;
					*gold += gold2;
					*silver += silver2;
					*copper += cash;
				}
			}
		}
		else {
			mysql_free_result(result);
			return;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in AddLootTableToNPC get coin query '" << query << "' " << errbuf << endl;
		safe_delete(query);
		return;
	}
	
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT loottable_id, lootdrop_id, multiplier, probability FROM loottable_entries WHERE loottable_id=%i", loottable_id), errbuf, &result)) {
		safe_delete(query);
		while ((row = mysql_fetch_row(result))) {
			int multiplier = atoi(row[2]);
			for (int i = 1; i <= multiplier; i++) {
				if ( ((rand()%1)*100) < atoi(row[3])) {
					AddLootDropToNPC(atoi(row[1]), itemlist);
				}
			}
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in AddLootTableToNPC get items query '" << query << "' " << errbuf << endl;
		safe_delete(query);
		return;
	}
	
	return;
}

// Called by AddLootTableToNPC
// maxdrops = size of the array npcd
void Database::AddLootDropToNPC(int32 lootdrop_id, ItemList* itemlist) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

// This is Wiz's updated Pool Looting functionality.  Eventually, the database format should be moved over to use this
// or implemented to support both methods.  (A unique identifier in lootable_entries indicates to roll for a pool item
// in another table.
#ifdef POOLLOOTING
	int32 chancepool = 0;
	int32 items[50];
	int32 itemchance[50];
	int16 itemcharges[50];
	int8 i = 0;

	for (int m=0;m < 50;m++)
	{
		items[m]=0;
		itemchance[m]=0;
		itemcharges[m]=0;
	}
	
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT lootdrop_id, item_id, item_charges, equip_item, chance FROM lootdrop_entries WHERE lootdrop_id=%i", lootdrop_id), errbuf, &result))
	{
		delete[] query;
		while (row = mysql_fetch_row(result))
		{
			items[i] = atoi(row[1]);
			itemchance[i] = atoi(row[4]) + chancepool;
			itemcharges[i] = atoi(row[2]);
			chancepool += atoi(row[4]);
			i++;
		}
		int32 res;
		i = 0;

        if (chancepool!=0) //avoid divide by zero if some mobs have 0 for chancepool
        {
            res = rand()%chancepool;
        }
        else
        {
            res = 0;
        }

		while (items[i] != 0)
		{
			if (res <= itemchance[i])
				break;
			else
				i++;
		}
		const Item_Struct* dbitem = database.GetItem(items[i]);
		if (dbitem == 0)
		{
			cerr << "Error in AddLootDropToNPC: dbitem=0, item#=" << items[i] << ", lootdrop_id=" << lootdrop_id << endl;
		}
		else
		{
			cout << "Adding item to Mob" << endl;
			ServerLootItem_Struct* item = new ServerLootItem_Struct;
			item->item_nr = dbitem->item_nr;
			item->charges = itemcharges[i];
			item->equipSlot = 0;
			(*itemlist).Append(item);
		}
		mysql_free_result(result);
	}
#else
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT lootdrop_id, item_id, item_charges, equip_item, chance FROM lootdrop_entries WHERE lootdrop_id=%i", lootdrop_id), errbuf, &result))
	{
		delete[] query;
		while ((row = mysql_fetch_row(result)))
		{
			int8 LootDropMod=1;  // place holder till I put it in a database variable to make it configurable.
			if( (rand()%100) < ((atoi(row[4]) * LootDropMod)) )
			{
				int32 itemid = atoi(row[1]);
				const Item_Struct* dbitem = database.GetItem(itemid);
				if (dbitem == 0)
				{
					cerr << "Error in AddLootDropToNPC: dbitem=0, item#=" << itemid << ", lootdrop_id=" << lootdrop_id << endl;
				}
				else
				{
					ServerLootItem_Struct* item = new ServerLootItem_Struct;
					item->item_nr = dbitem->item_nr;
					item->charges = atoi(row[2]);
					item->equipSlot = 0;
					(*itemlist).Append(item);
				}
				
				//mysql_free_result(result);
				//return;
			}
		}
		mysql_free_result(result);
	}
#endif
	else
	{
		cerr << "Error in AddLootDropToNPC query '" << query << "' " << errbuf << endl;
		delete[] query;
		return;
	}
	
	return;
}
