/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef NPC_H
#define NPC_H

class NPC;
#include "../common/database.h"
#include "mob.h"
//#include "spawn.h"
#include "spawn2.h"
#include "hate_list.h"
#include "loottable.h"
#include "zonedump.h"

#ifdef WIN32
	#define  M_PI	3.141592
#endif

//typedef LinkedList<Item_Struct*> ItemList;

class NPC : public Mob
{
public:
	static NPC* SpawnNPC(const char* spawncommand, float in_x, float in_y, float in_z, float in_heading = 0, Client* client = 0);

	NPC(const NPCType* data, Spawn2* respawn, float x, float y, float z, float heading, bool IsCorpse = false);
	virtual ~NPC();

	virtual bool IsNPC() { return true; }

	virtual bool Process();
    bool ProcessAI();

    void Heal() {} // todo: add some code

	// neotokyo: added frenzy
    void	AddToHateList(Mob* other, sint32 hate = 0, sint32 damage = 0, bool bFrenzy = false);
	void	SetHate(Mob* other, sint32 hate = 0, sint32 damage = 0) {hate_list.Set(other,hate,damage);}
	int32	GetHateAmount(Mob* tmob, bool is_dam = false)  {return hate_list.GetEntHate(tmob,is_dam);}
	int32	GetDamageAmount(Mob* tmob)  {return hate_list.GetEntHate(tmob, true);}
	// Kaiyodo - added attacking hand as a param
	void	Attack(Mob* other, int Hand = 13, bool = false);
	void	Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill = 0x04);
	void	Death(Mob* other, sint32 damage, int16 spell_id = 0xFFFF, int8 attack_skill = 0x04);
	Mob*	GetHateTop()  {return hate_list.GetTop();}
	Mob*	GetHateDamageTop(Mob* other)  {return hate_list.GetDamageTop(other);}
	Mob*	GetHateRandom()  {return hate_list.GetRandom();}
	bool	IsEngaged()   {return (hate_list.GetTop() == 0) ? false:true; }
	bool	DatabaseCastAccepted(int spell_id);
	bool	AddQueuedSpell(int16 spell_id);
	int32	RandomTimer(int min, int max);
	int32	spelllimit;

	sint32 GetAggroRadius() { return (spellbonuses->aggroradius == -1)? aggroradius : spellbonuses->aggroradius; }

	void	FaceTarget(Mob* MobToFace = 0, bool update = false);
	void	RemoveFromHateList(Mob* mob);
	void	WhipeHateList() { hate_list.Wipe(); }
	void	GoToBind()	{ GMMove(org_x, org_y, org_z, org_heading); }

	void	InteractiveChat(int8 chan_num, int8 language, const char * message, const char* targetname,Mob* sender);
	void	TakenAction(int8 action,Mob* actiontaker);

	void	AddItem(const Item_Struct* item, int8 charges, int8 slot = 0);
	void	AddItem(int32 itemid, int8 charges, int8 slot = 0);
	void	AddLootTable();
	void	NPCSpecialAttacks(const char* parse, int permtag);
	void	NPCDatabaseSpells(const char* parse);
	void	NPCUnharmSpell(int spell_id);
	void	CheckFriendlySpellStatus();
	void	CheckEnemySpellStatus();
	void	NPCHarmSpell(int target,int type);
	void    HateSummon();
	void	RemoveItem(uint16 item_id);
	void	ClearItemList();
	ServerLootItem_Struct*	GetItem(int slot_id);
	void	AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum);
	void	AddCash();
	void	RemoveCash();
	ItemList*	GetItemList() { return itemlist; }
	void	QueryLoot(Client* to);
	int32	CountLoot();
    bool SpecAttacks[SPECATK_MAXNUM];
#define MAX_RAMPAGE_TARGETS 3
#define MAX_FLURRY_HITS 2
    char RampageArray[MAX_RAMPAGE_TARGETS][64];
    bool Flurry();
    bool Rampage();
    bool AddRampage(Mob*);

    void StartEnrage();
    bool IsEnraged();

	int32 NPCSpells[20]; //Maximum of 20 spells...
	int32 NPCSpellTime[20];
	void	DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex);
	int32	GetLoottableID()	{ return loottable_id; }
	void	SetPetType(int8 in_type)	{ typeofpet = in_type; } // put this here because only NPCs can be anything but charmed pets

	uint32	GetCopper()		{ return copper; }
	uint32	GetSilver()		{ return silver; }
	uint32	GetGold()		{ return gold; }
	uint32	GetPlatinum()	{ return platinum; }
	uint32	MerchantType;
	void	SendTo(float new_x, float new_y);
	void	Depop(bool StartSpawnTimer = true);
	void	Stun(int16 duration);
	bool	IsStunned() { return stunned; }
//	bool	IsRooted() { return rooted; }


	bool	IsInteractive() { return interactive; }
	bool	IsPVP() { return pvp; }
	bool	IsGrouped() { return isgrouped; }
	int8	CurrentPosition() { return position; }


	int8	HasBanishCapability() { return banishcapability; }

	int32   GetFactionID()  { return faction_id; } // Merkur 03/11
	Mob*	GetIgnoreTarget() { return ignore_target; }
	void	SetIgnoreTarget(Mob* mob) {ignore_target = mob; }
	sint32	GetNPCHate(Mob* in_ent)  {return hate_list.GetEntHate(in_ent);}
    bool    IsOnHatelist(Mob*p) { return hate_list.IsOnHateList(p);}

	void	SetFactionID(int32 newfactionid) { faction_id=newfactionid; }
	bool	CheckAggro(Mob* other) {return hate_list.IsOnHateList(other);}
	void	SetFeignMemory(const char* num) {feign_memory = num;}
    sint8	CalculateHeadingToTarget(float in_x, float in_y);
    bool	CalculateNewPosition(float x, float y, float z, float speed);
    float	CalculateDistance(float x, float y, float z);
	void	CalculateNewWaypoint();
	int8	CalculateHeadingToNextWaypoint();
	float	CalculateDistanceToNextWaypoint();

	const char*    GetFeignMemory()	{ return feign_memory; }

    enum AIStatus { S_UNKNOWN, S_ROAMING, S_PATROLLING, S_FIGHTING, S_RESTING,
        S_PURSUING, S_CHANGEROAMPATH, S_RETURNHOME, S_SPAWNING, S_RANDOMWAITFORBUFFING, S_LOSINGBATTLE,
        S_WINNINGBATTLE, S_BUFFINGSELF, S_BUFFINGOTHERS, S_CHECKWHILEPATROLLING,
        S_CHECKINGAREA, S_STARTROAMING, S_RETURNHOMETOSPAWN, S_PETFOLLOWMASTER,
        S_PETASSISTMASTER, S_PETGUARD, S_PETSITDOWN, S_PETRETURNTOGUARD, S_PETSTARTGUARD, };
    void SetStatus( AIStatus s ) { m_RememberStatus = m_Status; m_Status = s; }
    void SaveGuardSpot();
    float GetGuardX() { return guard_x; }
    float GetGuardY() { return guard_y; }
    float GetGuardZ() { return guard_z; }
    float GetGuardHeading() { return guard_heading; }

	//Waypoint stuff, leave this unprotected.
	void	AssignWaypoints(int16 grid);
	float	wp_x[50]; //X of waypoint
	float	wp_y[50]; //Y of waypoint
	float	wp_z[50]; //Z of waypoint
	int32	wp_s[50]; //Pause of waypoint
	int16	wp_a[6]; //0 = Amount of waypoints, 1 = Wandering Type, 2 = Pause Type, 3 = Current Waypoint, 4 = Grid Number, 5 = Used for patrol grids
	Timer*	walking_timer;
	bool	roamer;
	float   org_x, org_y, org_z, org_heading;

	bool	IsCityController() { return citycontroller; }
	bool	IsGuildBank() { return guildbank; }
	void	SetGuildOwner(int32 guild) { guildowner = guild; }
	int32	GetGuildOwner() { return guildowner; }
	void	SetGuildTerrainName(char* terrain) { strcpy(ownedterrain,terrain); }
	char*	GetGuildTerrainName() { return ownedterrain; }
	bool	HasMoved() { return moved; }
    void    HasMoved(bool b) { moved = b; }
protected:
	friend class EntityList;
	LinkedList<struct NPCFaction*> faction_list;
    float guard_x, guard_y, guard_z, guard_heading;
    AIStatus m_Status, m_RememberStatus;
	sint32 aggroradius;
	HateList hate_list;
//	Spawn*	respawn;
	Spawn2*	respawn2;
	Mob*	ignore_target;
	uint32	copper;
	uint32	silver;
	uint32	gold;
	uint32	platinum;
	ItemList*	itemlist;

	int32	faction_id;
	
	Timer*	scanarea_timer; 
	Timer*	spells_timer; 
	Timer*	forget_timer;
	Timer*	movement_timer;
	Timer*	tics_timer;

    bool	evader;
	bool	interactive;
	bool	isgrouped;
	int8	position;	// 0 - Standing, 1 - Sitting, 2 - Crouching, 4 - Looting
	bool	pvp;
	int8	tired;
	int8	tiredmax;
	Timer*	interactive_timer;
	Timer*	randombuff_timer;

	int8	banishcapability;
	int8	max_dmg;
	int8	min_dmg;
	sint32	hp_regen;
	sint32	mana_regen;
	const char*	feign_memory;
	int8    forgetchance;

	bool	citycontroller;
	int32	guildowner;
	char*	ownedterrain;
	bool	guildbank;
private:
	int32	loottable_id;
	bool	p_depop;
	bool	moved;
};

#endif

