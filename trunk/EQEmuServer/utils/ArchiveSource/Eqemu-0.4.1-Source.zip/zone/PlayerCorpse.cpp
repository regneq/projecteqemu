/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
/*
New class for handeling corpses and everything associated with them.
Child of the Mob class.
-Quagmire
*/
#include "../common/debug.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream.h>
#ifdef WIN32
#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#endif

#include "PlayerCorpse.h"
#include "../common/packet_functions.h"

extern Database database;
extern EntityList entity_list;
extern Zone* zone;
extern npcDecayTimes_Struct npcCorpseDecayTimes[100];

void Corpse::SendEndLootErrorPacket(Client* client) {
	APPLAYER* outapp = new APPLAYER(OP_LootComplete, 0);
	client->QueuePacket(outapp);
	delete outapp;
}

void Corpse::SendLootReqErrorPacket(Client* client, int8 response) {
	APPLAYER* outapp = new APPLAYER(OP_MoneyOnCorpse, sizeof(moneyOnCorpseStruct));
	moneyOnCorpseStruct* d = (moneyOnCorpseStruct*) outapp->pBuffer;
	d->response		= response;
	d->unknown1		= 0x5a;
	d->unknown2		= 0x40;
	client->QueuePacket(outapp);
	delete outapp;
}

Corpse* Corpse::LoadFromDBData(int32 in_dbid, int32 in_charid, char* in_charname, uchar* in_data, int32 in_datasize, float in_x, float in_y, float in_z, float in_heading, char* time) {
	if (in_datasize < sizeof(DBPlayerCorpse_Struct)) {
		return false;
	}
	DBPlayerCorpse_Struct* dbpc = (DBPlayerCorpse_Struct*) in_data;
	if (in_datasize != (sizeof(DBPlayerCorpse_Struct) + (dbpc->itemcount * sizeof(ServerLootItem_Struct)))) {
		return false;
	}
	ItemList* itemlist = new ItemList();
	ServerLootItem_Struct* tmp = 0;
	for (unsigned int i=0; i < dbpc->itemcount; i++) {
		tmp = new ServerLootItem_Struct;
		memcpy(tmp, &dbpc->items[i], sizeof(ServerLootItem_Struct));
		itemlist->Append(tmp);
	}
	Corpse* pc = new Corpse(in_dbid, in_charid, in_charname, itemlist, dbpc->copper, dbpc->silver, dbpc->gold, dbpc->plat, in_x, in_y, in_z, in_heading, dbpc->size, dbpc->gender, dbpc->race, dbpc->class_, dbpc->deity, dbpc->level, dbpc->texture, dbpc->helmtexture,dbpc->exp);
	if (pc->IsEmpty()) {
		delete pc;
		return 0;
	}
	else {
		return pc;
	}
}

// To be used on NPC death and ZoneStateLoad
Corpse::Corpse(NPC* in_npc, ItemList** in_itemlist, int32 in_npctypeid, NPCType** in_npctypedata, int32 in_decaytime)
 : Mob("Unnamed_Corpse","",0,0,in_npc->GetGender(),in_npc->GetRace(),in_npc->GetClass(),0//bodytype added
       ,in_npc->GetDeity(),in_npc->GetLevel(),in_npc->GetNPCTypeID(),0,in_npc->GetSize(),0,0,in_npc->GetHeading(),in_npc->GetX(),in_npc->GetY(),in_npc->GetZ(),0,0,in_npc->GetTexture(),in_npc->GetHelmTexture(),0,0,0,0,0,0,0,0,0,0xff,0xff,0xff,0xff,0xff,0xff,0xff,1,0,0)
{
	p_PlayerCorpse = false;
	BeingLootedBy = 0xFFFFFFFF;
	if (in_itemlist) {
		itemlist = *in_itemlist;
		*in_itemlist = 0;
	}
	else {
		itemlist = new ItemList();
	}
	AddCash(in_npc->GetCopper(), in_npc->GetSilver(), in_npc->GetGold(), in_npc->GetPlatinum());
	
	npctype_id = in_npctypeid;
	if (in_npctypedata) {
		NPCTypedata = *in_npctypedata;
		*in_npctypedata = 0;
	}
	
	charid = 0;
	dbid = 0;
	p_depop = false;
	strcpy(orgname, in_npc->GetName());
	strcpy(name, in_npc->GetName());
	corpse_decay_timer = new Timer(in_decaytime);
	// Added By Hogie 
	for(int count = 0; count < 100; count++) {
		if ((level >= npcCorpseDecayTimes[count].minlvl) && (level <= npcCorpseDecayTimes[count].maxlvl)) {
			corpse_decay_timer->SetTimer(npcCorpseDecayTimes[count].seconds*1000);
			break;
		}
	}
	// Added By Hogie -- End
	this->rezzexp = 0;
	corpse_decay_timer->Start();
}

// To be used on PC death
Corpse::Corpse(Client* client, PlayerProfile_Struct* pp,sint32 in_rezexp)
 : Mob("Unnamed_Corpse","",0,0,client->GetGender(),client->GetRace(),client->GetClass(), 0, // bodytype added
        client->GetDeity(),client->GetLevel(),0,0, client->GetSize(), 0, 0,client->GetHeading(),client->GetX(),client->GetY(),client->GetZ(),0,0,client->GetTexture(),client->GetHelmTexture(),0,0,0,0,0,0,0,0,0,0xff,0xff,0xff,0xff,0xff,0xff,0xff,1,0,0)
{
	rezzexp = in_rezexp;
	p_PlayerCorpse = true;
	BeingLootedBy = 0xFFFFFFFF;
	itemlist = new ItemList();
	charid = client->CharacterID();
	dbid = 0;
	p_depop = false;
	strcpy(orgname, pp->name);
	strcpy(name, pp->name);
	AddCash(pp->copper, pp->silver, pp->gold, pp->platinum);
	pp->copper = 0;
	pp->silver = 0;
	pp->gold = 0;
	pp->platinum = 0;
	int i;
	client->RepairInventory();
	for (i=0; i<30; i++) {
		AddItem(pp->inventory[i], 1, i);
		pp->inventory[i] = 0xFFFF;
		pp->invitemproperties[i].charges = 0;
	}
	for (i=0; i<80; i++) {
		AddItem(pp->containerinv[i], pp->bagitemproperties[i].charges, i+250);
		pp->containerinv[i] = 0xFFFF;
		pp->bagitemproperties[i].charges = 0;
	}
	Save();
	client->Save();
	corpse_decay_timer = 0;
	
}

// To be called from LoadFromDBData
Corpse::Corpse(int32 in_dbid, int32 in_charid, char* in_charname, ItemList* in_itemlist, int32 in_copper, int32 in_silver, int32 in_gold, int32 in_plat, float in_x, float in_y, float in_z, float in_heading, float in_size, int8 in_gender, int8 in_race, int8 in_class, int8 in_deity, int8 in_level, int8 in_texture, int8 in_helmtexture,int32 in_rezexp)
 : Mob("Unnamed_Corpse","",0,0,in_gender, in_race, in_class, 0, // bodytype added
        in_deity, in_level,0,0, in_size, 0, 0, in_heading, in_x, in_y, in_z,0,0,in_texture,in_helmtexture,0,0,0,0,0,0,0,0,0,0xff,0xff,0xff,0xff,0xff,0xff,0xff,1,0,0)
{
	p_PlayerCorpse = true;
	BeingLootedBy = 0xFFFFFFFF;
	dbid = in_dbid;
	p_depop = false;
	charid = in_charid;
	itemlist = in_itemlist;
	
	strcpy(orgname, in_charname);
	strcpy(name, in_charname);
	this->copper = in_copper;
	this->silver = in_silver;
	this->gold = in_gold;
	this->platinum = in_plat;
	corpse_decay_timer = 0;
	rezzexp = in_rezexp;
}

Corpse::~Corpse() {
	if (p_PlayerCorpse && itemlist) {
		if (IsEmpty() && dbid != 0)
			database.DeletePlayerCorpse(dbid);
		else if (!IsEmpty() && !(p_depop && dbid == 0))
			Save();
	}
	safe_delete(itemlist);
	safe_delete(corpse_decay_timer);
	if (npctype_id == 0)
		safe_delete(NPCTypedata);
}

/*
this needs to be called AFTER the entity_id is set
the client does this too, so it's unchangable
*/
void Corpse::CalcCorpseName() {
	EntityList::RemoveNumbers(name);
	name[14] = 0; name[28] = 0; name[29] = 0;
#ifdef WIN32
	snprintf(name, sizeof(name), "%s's corpse%d", name, GetID());
#else
	//make a copy as glibc snprintf clears destination--misanthropicfiend
	char temp_name[64];
	strncpy(temp_name, name, 30);
	snprintf(name, sizeof(name), "%s's_corpse%d", temp_name, GetID());
#endif
}

bool Corpse::Save() {
	if (IsEmpty()) {
		Delete();
		return true;
	}
	
	if (!p_PlayerCorpse)
		return true;
	
	int32 tmp = this->CountItems();
	int32 tmpsize = sizeof(DBPlayerCorpse_Struct) + (tmp * sizeof(ServerLootItem_Struct));
	DBPlayerCorpse_Struct* dbpc = (DBPlayerCorpse_Struct*) new uchar[tmpsize];
	dbpc->itemcount = tmp;
	dbpc->copper = this->copper;
	dbpc->silver = this->silver;
	dbpc->gold = this->gold;
	dbpc->plat = this->platinum;
	dbpc->race = race;
	dbpc->class_ = class_;
	dbpc->gender = gender;
	dbpc->deity = deity;
	dbpc->level = level;
	dbpc->texture = this->texture;
	dbpc->helmtexture = this->helmtexture;
	dbpc->exp = rezzexp;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	int32 x = 0;
	while(iterator.MoreElements()) {
		memcpy((char*) &dbpc->items[x++], (char*) iterator.GetData(), sizeof(ServerLootItem_Struct));
		iterator.Advance();
	}
	if (dbid == 0)
		dbid = database.CreatePlayerCorpse(charid, orgname, zone->GetShortName(), (uchar*) dbpc, tmpsize, x_pos, y_pos, z_pos, heading);
	else
		dbid = database.UpdatePlayerCorpse(dbid, charid, orgname, zone->GetShortName(), (uchar*) dbpc, tmpsize, x_pos, y_pos, z_pos, heading);
	delete dbpc;
	if (dbid == 0) {
		cout << "Error: Failed to save player corpse '" << this->GetName() << "'" << endl;
		return false;
	}
	return true;
}

void Corpse::Delete() {
	if (IsPlayerCorpse() && dbid != 0)
		database.DeletePlayerCorpse(dbid);
	p_depop = true;
}

void Corpse::Depop(bool StartSpawnTimer) {
	if (IsNPCCorpse())
		p_depop = true;
}

int32 Corpse::CountItems() {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int32 x = 0;
	while(iterator.MoreElements())
	{
		x++;
		iterator.Advance();
	}
	
	return x;
}

void Corpse::AddItem(int16 itemnum, int8 charges, int16 slot) {
	if (!database.GetItem(itemnum))
		return;
	ServerLootItem_Struct* item = new ServerLootItem_Struct;
	memset(item, 0, sizeof(ServerLootItem_Struct));
	item->item_nr = itemnum;
	item->charges = charges;
	item->equipSlot = slot;
	(*itemlist).Append(item);
}

ServerLootItem_Struct* Corpse::GetItem(int16 lootslot) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->lootslot == lootslot)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	
	return 0;
}

int16 Corpse::GetWornItem(int16 equipSlot) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->equipSlot == equipSlot)
		{
			return iterator.GetData()->item_nr;
		}
		iterator.Advance();
	}
	
	return 0;
}

void Corpse::RemoveItem(int16 lootslot) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->lootslot == lootslot)
		{
			APPLAYER* outapp = new APPLAYER;
			outapp->opcode = OP_WearChange;
			outapp->size = sizeof(WearChange_Struct);
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			WearChange_Struct* wc = (WearChange_Struct*) outapp->pBuffer;
			wc->spawn_id = this->GetID();
			
			if (iterator.GetData()->equipSlot == 2)
				wc->wear_slot_id = 0;
			else if (iterator.GetData()->equipSlot == 17)
				wc->wear_slot_id = 1;
			else if (iterator.GetData()->equipSlot == 7)
				wc->wear_slot_id = 2;
			else if (iterator.GetData()->equipSlot == 10)
				wc->wear_slot_id = 3;
			else if (iterator.GetData()->equipSlot == 12)
				wc->wear_slot_id = 4;
			else if (iterator.GetData()->equipSlot == 18)
				wc->wear_slot_id = 5;
			else if (iterator.GetData()->equipSlot == 19)
				wc->wear_slot_id = 6;
			else if (iterator.GetData()->equipSlot == 13)
				wc->wear_slot_id = 7;
			else if (iterator.GetData()->equipSlot == 14)
				wc->wear_slot_id = 8;
			else
				safe_delete(outapp);
			if (outapp != 0) {
				entity_list.QueueClients(0, outapp);
				safe_delete(outapp);
			}
			
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}
}

void Corpse::AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum) {
	this->copper = in_copper;
	this->silver = in_silver;
	this->gold = in_gold;
	this->platinum = in_platinum;
}

void Corpse::RemoveCash() {
	this->copper = 0;
	this->silver = 0;
	this->gold = 0;
	this->platinum = 0;
}

bool Corpse::IsEmpty() {
	if (copper != 0 || silver != 0 || gold != 0 || platinum != 0)
		return false;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	return !iterator.MoreElements();
}

bool Corpse::Process() {
	if (p_depop)
		return false;
	if (corpse_decay_timer) {
		if(corpse_decay_timer->Check()) {
			return false;
		}
	}
	
	return true;
}

void Corpse::SetDecayTimer(int32 decaytime) {
	if (corpse_decay_timer) {
		corpse_decay_timer = new Timer(1);
	}
	if (decaytime == 0)
		corpse_decay_timer->Trigger();
	else
		corpse_decay_timer->Start(decaytime);
}

void Corpse::MakeLootRequestPackets(Client* client, APPLAYER* app) {
		// Added 12/08.  Started compressing loot struct on live.
	    int cpisize = sizeof(ItemOnCorpse_Struct) + (50 * sizeof(MerchantItemD_Struct));
        ItemOnCorpse_Struct* cpi = (ItemOnCorpse_Struct*) new uchar[cpisize];
        memset(cpi, 0, cpisize);

	if (IsPlayerCorpse() && dbid == 0) {
		SendLootReqErrorPacket(client, 0);
		client->Message(13, "Error: Corpse's dbid = 0! Cannot get data.");
		cout << "Error: PlayerCorpse::MakeLootRequestPackets: dbid = 0!" << endl;
		return;
	}
	if (this->BeingLootedBy != 0xFFFFFFFF) {
		// lets double check....
		Entity* looter = entity_list.GetID(this->BeingLootedBy);
		if (looter == 0)
			this->BeingLootedBy = 0xFFFFFFFF;
	}
	if (this->BeingLootedBy != 0xFFFFFFFF && this->BeingLootedBy != client->GetID()) {
		// ok, now we tell the client to fuck off
		// Quagmire - i think this is the right packet, going by pyro's logs
		SendLootReqErrorPacket(client, 0);
		cout << "Telling " << client->GetName() << " corpse '" << this->GetName() << "' is busy..." << endl;
	}
	else if (IsPlayerCorpse() && (this->charid != client->CharacterID() && client->Admin() < 100)) {
		// Not their corpse... get lost
		SendLootReqErrorPacket(client, 2);
		cout << "Telling " << client->GetName() << " corpse '" << this->GetName() << "' is busy..." << endl;
	}
	else {
		this->BeingLootedBy = client->GetID();
		APPLAYER* outapp = new APPLAYER(OP_MoneyOnCorpse, sizeof(moneyOnCorpseStruct));
		moneyOnCorpseStruct* d = (moneyOnCorpseStruct*) outapp->pBuffer;
		
		d->response		= 1;
		d->unknown1		= 0x5a;
		d->unknown2		= 0x40;
		if (!IsPlayerCorpse() || this->charid == client->CharacterID()) {
			d->copper		= this->GetCopper();
			d->silver		= this->GetSilver();
			d->gold			= this->GetGold();
			d->platinum		= this->GetPlatinum();
			client->AddMoneyToPP(this->GetCopper(),this->GetSilver(),this->GetGold(),this->GetPlatinum());
			this->RemoveCash();
		}
		client->QueuePacket(outapp); 
		delete outapp;
		
		LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
		iterator.Reset();
		int i = 0;
		while(iterator.MoreElements()) {
			ServerLootItem_Struct* item_data = iterator.GetData();
			const Item_Struct* item = database.GetItem(item_data->item_nr);
			Item_Struct* outitem;
			
			if (item) {
				memcpy(&cpi->item[cpi->count].item, item, sizeof(Item_Struct));
				cpi->item[cpi->count].item.equipSlot = i;
				item_data->lootslot=i;
                
			if(item->flag != 0x7669)
				cpi->item[cpi->count].item.common.charges = item_data->charges;
				cpi->count++;
				i++;

				//Old way.  12/08
				//item_data->lootslot = counter;
				//outapp = new APPLAYER;
				//outapp->opcode = OP_ItemOnCorpse;
				//outapp->size = sizeof(ItemOnCorpse_Struct);
				//outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer,0,outapp->size); // no memset = BAD -kathgar
				//memcpy(outapp->pBuffer, item, sizeof(Item_Struct));
				// modify the copy of the item
				//outitem = (Item_Struct*) outapp->pBuffer;
				//outitem->equipSlot = item_data->lootslot;
				//if (item->flag != 0x7669)
				//	outitem->common.charges = item_data->charges;
				//client->QueuePacket(outapp);
				//counter++;
				//delete outapp;
			}
			iterator.Advance();
		}
	}	
		APPLAYER* outapp = new APPLAYER(OP_ItemOnCorpse, 10000);
		outapp->size = 2 + DeflatePacket((uchar*) cpi->item, cpi->count * sizeof(MerchantItemD_Struct), &outapp->pBuffer[2], 10000-2);
		ItemOnCorpse_Struct* cpi2 = (ItemOnCorpse_Struct*) outapp->pBuffer;
		cpi2->count = cpi->count;
		client->QueuePacket(outapp);
		//DumpPacket(outapp);
		//printf("Merchant has %i items available.\n",cpi->count);
		delete outapp;
		// Disgrace: Client seems to require that we send the packet back...
		client->QueuePacket(app);
	}

void Corpse::LootItem(Client* client, APPLAYER* app) {
	if (this->BeingLootedBy != client->GetID()) {
		client->Message(13, "Error: Corpse::LootItem: BeingLootedBy != client");
		SendEndLootErrorPacket(client);
		return;
	}
	LootingItem_Struct* lootitem = (LootingItem_Struct*)app->pBuffer;
	ServerLootItem_Struct* item_data = this->GetItem(lootitem->slot_id);
	const Item_Struct* item = 0;
	if (item_data != 0)
		item = database.GetItem(item_data->item_nr);
	if (item!=0) {
		if (lootitem->type == 1) {
			int16 tmpslot = client->FindFreeInventorySlot(0, (item->type == 0x01), false);
			if (tmpslot == 0xFFFF) {
				client->Message(13, "Error: No room in your inventory, putting the item back onto the corpse.");
			}
			else if (!client->PutItemInInventory(tmpslot, item_data->item_nr, item_data->charges)) {
				client->Message(13, "Error adding this item to your inventory, putting it back on the corpse.");
			}
			else
				this->RemoveItem(item_data->lootslot);
		}
		else {
			client->SummonItem(item_data->item_nr, item_data->charges);
			this->RemoveItem(item_data->lootslot);
		}
	}
	else {
		client->Message(15, "Error: Item not found.");
	}
	client->QueuePacket(app);
}

void Corpse::EndLoot(Client* client, APPLAYER* app) {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_LootComplete;
	outapp->size = 0;
	client->QueuePacket(outapp);
	delete outapp;
	
	client->Save();
	this->Save();
	this->BeingLootedBy = 0xFFFFFFFF;
	if (this->IsEmpty()) {
		Delete();
	}
}

void Corpse::FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho) {
	Mob::FillSpawnStruct(ns, ForWho);
	
	if (IsPlayerCorpse())
		ns->spawn.NPC = 3;
	else
		ns->spawn.NPC = 2;
	
	ns->spawn.npc_armor_graphic = texture;
	ns->spawn.npc_helm_graphic = helmtexture;
	
	if (IsPlayerCorpse()) {
		const Item_Struct* item = 0;
		if (helmtexture == 0xFF) {
			item = database.GetItem(GetWornItem(2));
			if (item != 0) {
				ns->spawn.equipment[0] = item->common.material;
				ns->spawn.equipcolors[0] = item->common.color;
			}
		}
		if (texture == 0xFF) {
			item = database.GetItem(GetWornItem(17));
			if (item != 0) {
				ns->spawn.equipment[1] = item->common.material;
				ns->spawn.equipcolors[1] = item->common.color;
			}
			item = database.GetItem(GetWornItem(7));
			if (item != 0) {
				ns->spawn.equipment[2] = item->common.material;
				ns->spawn.equipcolors[2] = item->common.color;
			}
			item = database.GetItem(GetWornItem(10));
			if (item != 0) {
				ns->spawn.equipment[3] = item->common.material;
				ns->spawn.equipcolors[3] = item->common.color;
			}
			item = database.GetItem(GetWornItem(12));
			if (item != 0) {
				ns->spawn.equipment[4] = item->common.material;
				ns->spawn.equipcolors[4] = item->common.color;
			}
			item = database.GetItem(GetWornItem(18));
			if (item != 0) {
				ns->spawn.equipment[5] = item->common.material;
				ns->spawn.equipcolors[5] = item->common.color;
			}
			item = database.GetItem(GetWornItem(19));
			if (item != 0) {
				ns->spawn.equipment[6] = item->common.material;
				ns->spawn.equipcolors[6] = item->common.color;
			}
			item = database.GetItem(GetWornItem(13));
			if (item != 0) {
				if (strlen(item->idfile) >= 3) {
					ns->spawn.equipment[7] = (int8) atoi(&item->idfile[2]);
				}
				else {
					ns->spawn.equipment[7] = 0;
				}
				ns->spawn.equipcolors[7] = 0;
			}
			item = database.GetItem(GetWornItem(14));
			if (item != 0) {
				if (strlen(item->idfile) >= 3) {
					ns->spawn.equipment[8] = (int8) atoi(&item->idfile[2]);
				}
				else {
					ns->spawn.equipment[8] = 0;
				}
				ns->spawn.equipcolors[8] = 0;
			}
		}
	}
}

void Corpse::QueryLoot(Client* to) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements())
	{
		const Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
		if (item)
			to->Message(0, "  %d: %s", item->item_nr, item->name);
		else
			to->Message(0, "  Error: %04x", iterator.GetData()->item_nr);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void Corpse::Summon(Client* client,bool spell) {
	int32 dist = 10000; // pow(100, 2);
	// TODO: Check consent list
	if (!spell){
		if (this->GetCharID() == client->CharacterID()) {
			if (DistNoRootNoZ(client) <= dist)
				GMMove(client->GetX(), client->GetY(), client->GetZ());
			else
				client->Message(0, "Corpse is too far away.");
		}
	}
	else
		GMMove(client->GetX(), client->GetY(), client->GetZ());
	Save();
}

void Corpse::CompleteRezz(){
	rezzexp = 0;
	this->Save();
}

int32 Database::UpdatePlayerCorpse(int32 dbid, int32 charid, const char* charname, const char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = new char[256+(datasize*2)];
	char* end = query;
	int32 affected_rows = 0;
	
	end += sprintf(end, "Update player_corpses SET data=");
	*end++ = '\'';
	end += DoEscapeString(end, (char*)data, datasize);
	*end++ = '\'';
	end += sprintf(end,", charname='%s', zonename='%s', charid=%d, x=%1.1f, y=%1.1f, z=%1.1f, heading=%1.1f WHERE id=%d", charname, zonename, charid, x, y, z, heading, dbid);
	
	if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
		delete[] query;
        cerr << "Error1 in UpdatePlayerCorpse query " << errbuf << endl;
		return 0;
    }
	delete[] query;
	
	if (affected_rows == 0) {
        cerr << "Error2 in UpdatePlayerCorpse query: affected_rows = 0" << endl;
		return 0;
	}
	
	return dbid;
}

int32 Database::CreatePlayerCorpse(int32 charid, const char* charname, const char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = new char[256+(datasize*2)];
	char* end = query;
    MYSQL_RES *result;
    MYSQL_ROW row;
	int32 affected_rows = 0;
	
	end += sprintf(end, "Insert into player_corpses SET data=");
	*end++ = '\'';
	end += DoEscapeString(end, (char*)data, datasize);
	*end++ = '\'';
	end += sprintf(end,", charname='%s', zonename='%s', charid=%d, x=%1.1f, y=%1.1f, z=%1.1f, heading=%1.1f", charname, zonename, charid, x, y, z, heading);
	
    if (!RunQuery(query, (int32) (end - query), errbuf, 0, &affected_rows)) {
		delete[] query;
        cerr << "Error1 in CreatePlayerCorpse query " << errbuf << endl;
		return 0;
    }
	delete[] query;
	
	if (affected_rows == 0) {
        cerr << "Error2 in CreatePlayerCorpse query: affected_rows = 0" << endl;
		return 0;
	}
	
    query = new char[256+(datasize*2)];
	end = query;
	
	end += sprintf(end, "Select id from player_corpses where data=");
	*end++ = '\'';
	end += DoEscapeString(end, (char*)data, datasize);
	*end++ = '\'';
	end += sprintf(end," AND zonename='%s' AND charid=%d AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < 15 Order by time Desc", zonename, charid);
	
    if (RunQuery(query, (int32) (end - query), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1) {
			row = mysql_fetch_row(result);
			int32 tmp = atoi(row[0]);
			mysql_free_result(result);
			return tmp;
		}
		mysql_free_result(result);
	}
	else {
		delete[] query;
        cerr << "Error3 in CreatePlayerCorpse query " << errbuf << endl;
		return 0;
    }
	
	cerr << "Error4 in CreatePlayerCorpse query: reached end!" << endl;
	return 0;
}

bool Database::LoadPlayerCorpses(const char* zonename) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	
	//	int char_num = 0;
	unsigned long* lengths;
	
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT id, charid, charname, x, y, z, heading, data, time FROM player_corpses WHERE zonename='%s'", zonename), errbuf, &result)) {
		//                                                       0   1       2         3  4  5  6        7     8
		delete[] query;
		while ((row = mysql_fetch_row(result)))
		{
			lengths = mysql_fetch_lengths(result);
			entity_list.AddCorpse(Corpse::LoadFromDBData(atoi(row[0]), atoi(row[1]), row[2], (uchar*) row[7], lengths[7], atof(row[3]), atoi(row[4]), atoi(row[5]), atoi(row[6]), row[8]));
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in LoadPlayerCorpses query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	
	return true;
}

bool Database::DeletePlayerCorpse(int32 dbid) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	
	if (!RunQuery(query, MakeAnyLenString(&query, "Delete from player_corpses where id=%d", dbid), errbuf)) {
		cerr << "Error in DeletePlayerCorpse query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	
	delete[] query;
	return true;
}

