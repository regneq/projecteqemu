/*
  Note: Do NOT change this to load items on an as-needed basis. Since this memory is
  accessed from multiple threads, you'd need mutex's all over the place if it was
  ever to be modified/updated/added to. The overhead of the mutexes would be alot more
  in the long run than the delay in loading.

  -Quagmire
*/

#include <windows.h>
#include <memory.h>
#include <iostream.h>
#include "Items.h"
#include "../common/timer.h"

HANDLE hMapObjectItems = NULL;
LPVOID lpvMemItems = 0;
MMFItems_Struct* MMFItems = 0;
bool AddItemAllowed = false;

extern "C" __declspec(dllexport) const Item_Struct* GetItem(uint16 id) {
	return pGetItem(id);
};

extern "C" __declspec(dllexport) bool AddItem(uint16 id, const Item_Struct* item) {
	return pAddItem(id, item);
};

extern "C" __declspec(dllexport) const Item_Struct* IterateItems(uint16* NextIndex) {
	return pIterateItems(NextIndex);
};

extern "C" __declspec(dllexport) bool DLLLoadItems(CALLBACK_DBLoadItems cbDBLoadItems, int32 iItemStructSize, int16 iItemCount, int16 iMaxItemID) {
	return pDLLLoadItems(cbDBLoadItems, iItemStructSize, iItemCount, iMaxItemID);
};

bool pAddItem(uint16 id, const Item_Struct* item) {
	if (!AddItemAllowed)
		return false;
	if (MMFItems->ItemIndex[id] != 0xFFFF)
		return false;
	
	MMFItems->ItemIndex[id] = MMFItems->NextFreeIndex++;
	memcpy(&MMFItems->Items[MMFItems->ItemIndex[id]], item, sizeof(Item_Struct));

	return true;
}

bool pDLLLoadItems(CALLBACK_DBLoadItems cbDBLoadItems, int32 iItemStructSize, int16 iItemCount, int16 iMaxItemID) {
	if (iItemStructSize != sizeof(Item_Struct)) {
		cout << "Error: EMuShareMem: DLLLoadItems: iItemStructSize != sizeof(Item_Struct)" << endl;
		cout << "Item_Struct has changed, EMuShareMem.dll needs to be recompiled." << endl;
		return false;
	}
	int8 ret = OpenItemsMMF(iItemCount);
	MMFItems->MaxItemID = iMaxItemID;
	MMFItems->ItemCount = iItemCount;
	if (ret == 2) {
		AddItemAllowed = true;
		// use a callback so the DB functions are done in the main exe
		// this way the DLL doesnt have to open a connection to mysql
		cbDBLoadItems(iItemCount, iMaxItemID);
		AddItemAllowed = false;
		MMFItems->Loaded = true;
		return true;
	}
	else if (ret == 1) {
		if (!MMFItems->Loaded) {
			Timer::SetCurrentTime();
			int32 starttime = Timer::GetCurrentTime();
			while ((!MMFItems->Loaded) && ((Timer::GetCurrentTime() - starttime) < 300000)) {
				Sleep(10);
				Timer::SetCurrentTime();
			}
			if (!MMFItems->Loaded)
				return false;
		}
		return true;
	}
	else {
		cout << "Error Loading Items: Items.cpp: pDLLLoadItems: ret == 0" << endl;
		return false;
	}
	return false;
};

/*
  OpenItemsMMF opens the Memory-Mapped File handel and sets the global MMFItems pointer to it.
  If we were the First Process and had to create the MMF, it also memsets() the memory to 0;
  Return: 0=Error, 1=Sucess, 2=FirstProcess
*/
int8 OpenItemsMMF(int16 iItemsCount) {
	HANDLE hMutex;
	hMutex = CreateMutex( 
	NULL,                       // no security attributes
	FALSE,                      // initially not owned
	"MutexToProtectOpenItemsMMF");  // name of mutex

	if (hMutex == NULL) {
		cout << "Error Loading Items: Items.cpp: OpenItemsMMF: hMutex == Null" << endl;
		return 0;
	}

	DWORD dwWaitResult;
    // Request ownership of mutex.
	dwWaitResult = WaitForSingleObject( 
		hMutex,   // handle to mutex
		2000L);   // two-second time-out interval

	if (dwWaitResult != WAIT_OBJECT_0) {
		// Mutex not aquired, crap out
		cout << "Error Loading Items: Items.cpp: OpenItemsMMF: dwWaitResult != WAIT_OBJECT_0" << endl;
		return 0;
	}

	// Finally, ready to rock.
	bool fInit = false;
	int32 tmpMemSize = sizeof(MMFItems_Struct) + 256 + (sizeof(Item_Struct) * iItemsCount);
	__try {
		hMapObjectItems = CreateFileMapping( 
			INVALID_HANDLE_VALUE,	// use paging file
			NULL,					// default security attributes
			PAGE_READWRITE,			// read/write access
			0,						// size: high 32-bits
			tmpMemSize,				// size: low 32-bits
			"dllitemsmemfilemap");	// name of map object
		if (hMapObjectItems == NULL) {
			cout << "Error Loading Items: Items.cpp: OpenItemsMMF: hMapObjectItems == Null" << endl;
			return 0;
		}
 
		// The first process to attach initializes memory.

		fInit = (bool) (GetLastError() != ERROR_ALREADY_EXISTS); 

		// Get a pointer to the file-mapped shared memory.

		lpvMemItems = MapViewOfFile( 
			hMapObjectItems,		// object to map view of
			FILE_MAP_WRITE,			// read/write access
			0,						// high offset:  map from
			0,						// low offset:   beginning
			0);						// default: map entire file
		if (lpvMemItems == NULL) {
			cout << "Error Loading Items: Items.cpp: OpenItemsMMF: lpvMemItems == Null" << endl;
			return 0;
		}
 
		// Initialize memory if this is the first process.
 		if (fInit) 
			memset(lpvMemItems, 0, tmpMemSize);

		MMFItems = (MMFItems_Struct*) lpvMemItems;

		if (fInit) {
			MMFItems->Loaded = false;
			for(int i=0; i<MMF_EQMAX_ITEMS; i++)
				MMFItems->ItemIndex[i] = 0xFFFF;
		}
	} // end of try block

	__finally {
		// Clean up the Mutex stuff
		if (!ReleaseMutex(hMutex)) {
			cout << "Error Loading Items: Items.cpp: OpenItemsMMF: !ReleaseMutex(hMutex)" << endl;
			return 0;
		}
	}
	CloseHandle(hMutex);

	if (fInit)
		return 2;
	return 1;
}

void CloseItemsMMF() {
	if (lpvMemItems == 0)
		return;
	MMFItems = 0;
	// Unmap shared memory from the process's address space.
	UnmapViewOfFile(lpvMemItems); 
	lpvMemItems = 0;
 
	// Close the process's handle to the file-mapping object.
	CloseHandle(hMapObjectItems);
	hMapObjectItems = NULL;
}

const Item_Struct* pGetItem(uint16 id) {
	if (MMFItems == 0 || (!MMFItems->Loaded))
		return 0;
	if (MMFItems->ItemIndex[id] == 0xFFFF)
		return 0;
	return &MMFItems->Items[MMFItems->ItemIndex[id]];
}

const Item_Struct* pIterateItems(uint16* NextIndex) {
	do {
		if (MMFItems->ItemIndex[*NextIndex] != 0xFFFF)
			return &MMFItems->Items[MMFItems->ItemIndex[(*NextIndex)++]];
	} while ((*NextIndex)++ < MMF_EQMAX_ITEMS);
}
