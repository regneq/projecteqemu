Compiling on linux.    -  Trumpcard 12/24/2002
---------------------------------------------

Dependencies:  You need to have mysql server and the development headers and libraries installed.  These can all be found at 
www.mysql.com.  If you receive errors related to database calls, you most likely do not have them, or your makefile does not
point to the correct directory for the includes.  Ensure the mysql headers are where the makefile thinks they should be.

Once you have the linux source unpacked, you will have 2 directories to be concerned with, world and zone.

Edit your makefiles (they live in both the world and zone directories)
I have now included a highly optimized makefile and debug makefile with the release. I have tested with gcc3.2, your mileage may
vary with 2.9x.  Compile it using makefile -f <makefilename>.  makefile.opt and makefile.debug.


Optimize flags
----------------------------------------------
gcc can do various levels of auto optimization based on the -O flag.  The levels go from -O to -O6.  I generally use 
-O3 and have never had any problems.  Try -O3 first, and move up or down based on your experineces and/or comfort level.

CPU flags
----------------------------------------------
The cpu flags are set for 'march=i585' which should be fine for any pentium and later machines (I am assuming no one is going to 
try and run it with a 486.  If you are using a pentium, AMD K6, or K6-2,  leave it at 585.  If you have any of the later chips,
try changing this to march=i686.

Additionally, if you have gcc 3.2 (gcc -v will tell you what version of gcc you are compiling with), you can 
use some of the CPU specific optimization flags. I use 'march=athlon-xp' for instance when I compile as I have 
an athlon-xp 2000. This generally results in better code specific for your machine, but anything compiled with the
march=cpu flag will be non portable. (You wont be able to run the binary on a different cpu architecture)

NOTE:  Make sure to change the makefiles in both world and zone.


Onto world first.  

cd world
Once there, I would examine the makefile to make sure it looks good to you. If you get errors building the source stemming from calls in database.cpp
, you are most likely using the wrong paths to the mysql includes and lib's, verify them before you go on.

To build world, just type 'make'

If all goes well, you will ended up with a compiled and linked 'world' exectubable.  I generally copy this binary to a directory 
called 'bin' where I colocate it with 'zone' , and all my ini files, spells_en.txt file, cfg files, quest files, etc.  This saves you trouble as you can
make code changes and compile, and once you are ready copy it over to your running directory for testing.  It also keeps your
directories a bit cleaner.

cd ../zone

type 'make'
Assuming everything is ok, you will get a 'zone' executable next.  copy it to your bin directory (or leave it right there, your preference)


If you have set up your ini files correctly, then next you will be able to run the exectuables and hopefully log
onto your server.

Open a few term windows.  In one, cd to your world binary, and run  './world'.  Assuming everything is setup
correctly, you will have a running world server.  Next, go to whereever your zone server is.  
Run './zone . <IP ADDRESS> <PORT TO LISTEN ON> <IP ADDRESS OF DATABASE>'  to start the zone.
Assuming your ip is 200.100.100.100, and you opened port 7995 in your firewall for it, you will exectute
./zone . 200.100.100.100 7995 200.100.100.100

once the zone has successfully started, you will see it enter sleep mode.

MAKE SURE TO COPY YOUR SPELL_EN.TXT FROM YOUR EVERQUEST FOLDER TO THE DIRECTORIES WITH YOUR WORLD AND ZONE BINARIES IN THEM.


That's it!  If theres any additional tips or tricks you uncover, feel free to post them to the Linux Support Forum
at

http://www.eqemu.net



