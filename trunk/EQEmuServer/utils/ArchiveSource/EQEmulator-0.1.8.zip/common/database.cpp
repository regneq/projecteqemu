#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#define snprintf	_snprintf
#else
	#include "unix.h"
#endif

#include "database.h"

// change starting zone
const char* ZONE_NAME = "qeynos";


/*
	This is the amount of time in seconds the client has to enter the zone
	server after the world server, or inbetween zones when that is finished
*/
#define AUTHENTICATION_TIMEOUT 120

#ifdef WIN32
/*
	Establish a connection to a mysql database with the supplied parameters

	Added a very simple .ini file parser - Bounce
*/
Database::Database ()
{
	item_array = 0;
	max_item = 0;
	max_npc_type = 0;
	npc_type_array = 0;
	char host[200], user[200], passwd[200], database[200], buf[200], type[200];
	int items[4] = {0, 0, 0, 0};
	FILE *f;

	if (!(f = fopen ("db.ini", "r")))
	{
		printf ("Couldn't open the DB.INI file.\n");
		printf ("Read README.TXT!\n");
		exit (1);
	}

	do
	{
		fgets (buf, 199, f);
		if (feof (f))
		{
			printf ("[Database] block not found in DB.INI.\n");
			printf ("Read README.TXT!\n");
			exit (1);
		}
	}
	while (stricmp (buf, "[Database]\n"));

	while (!feof (f))
	{
		if (fscanf (f, "%[^=]=%[^\n]\n", type, buf) == 2)
		{
			if (!strnicmp (type, "host", 4))
			{
				strcpy (host, buf);
				items[0] = 1;
			}
			if (!strnicmp (type, "user", 4))
			{
				strcpy (user, buf);
				items[1] = 1;
			}
			if (!strnicmp (type, "pass", 4))
			{
				strcpy (passwd, buf);
				items[2] = 1;
			}
			if (!strnicmp (type, "data", 4))
			{
				strcpy (database, buf);
				items[3] = 1;
			}
		}
	}

	if (!items[0] || !items[1] || !items[2] || !items[3])
	{
		printf ("Incomplete DB.INI file.\n");
		printf ("Read README.TXT!\n");
		exit (1);
	}
	
	fclose (f);

	mysql_init(&mysql);
/*
Quagmire - added CLIENT_FOUND_ROWS flag to the connect
otherwise DB update calls would say 0 rows affected when the value already equalled
what the function was tring to set it to, therefore the function would think it failed 
*/
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, CLIENT_FOUND_ROWS))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}
#else
/*
	Establish a connection to a mysql database with the supplied parameters
*/
Database::Database(const char* host, const char* user, const char* passwd, const char* database)
{
	item_array = 0;
	max_item = 0;
	max_npc_type = 0;
	npc_type_array = 0;
	mysql_init(&mysql);
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, CLIENT_FOUND_ROWS))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}
#endif

/*
	Close the connection to the database
*/
Database::~Database()
{
	int x;
	if (item_array != 0) {
		for (x=0; x <= max_item; x++) {
			if (item_array[x] != 0)
				delete item_array[x];
		}
		delete item_array;
	}
	if (npc_type_array != 0) {
		for (x=0; x <= max_npc_type; x++) {
			if (npc_type_array[x] != 0)
				delete npc_type_array[x];
		}
		delete npc_type_array;
	}
	mysql_close(&mysql);
}

// Sends the MySQL server a keepalive
void Database::ping() {
	mysql_ping(&mysql);
}

/*
	Get the address and port to the zone server with the given name.
	If a record with that zone name is found return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetZoneServer(char* name, char* address, int16* port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address,port FROM zone_server WHERE name='%s'", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strncpy(address,row[0],256); // TODO: Find out max address len
				*port = atoi(row[1]);
				mysql_free_result(result);
				return true;
			}
			else
			{
				mysql_free_result(result);
				return false;
			}
		}
		else
		{
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

/*
	If a record with that zone name is found return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetZoneServer(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address,port FROM zone_server WHERE name='%s'", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				mysql_free_result(result);
				return true;
			}
			else
			{
				mysql_free_result(result);
				return false;
			}
		}
		else
		{
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}


/*
	Register a zone server with the given address and port. If a zone
	with the given name is not registered or is already registered with 
	the same address and port we will return true, otherwise return false.
	False will also be returned if there is a database error.
*/
bool Database::RegisterZoneServer(char* name, char* address, int16 port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address, port FROM zone_server WHERE name='%s' AND address='%s' AND port=%i", name, address, port);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}

	query = 0;
	buf_len = 256;
	chars = -1;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO zone_server SET name='%s', address='%s', port=%i", name, address, port);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in RegisterZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;	
}

/*
	Unregister the zone server with the given name, address and port. If the zone was
	was registered return trure, otherwise return false.
	False will also be returned if there is a database error.
*/
bool Database::UnregisterZoneServer(char* name, char* address, int16 port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM zone_server WHERE name='%s' AND address='%s' AND port=%i", name, address, port);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in UnRegisterZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;	
}

/*
	Check if the character with the name char_name from ip address ip has
	permission to enter zone zone_name. Return the account_id if the client
	has the right permissions, otherwise return zero.
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAuthentication(char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT account_id FROM authentication WHERE char_name='%s' AND zone_name='%s' AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", char_name, zone_name, ip, AUTHENTICATION_TIMEOUT);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 account_id = atoi(row[0]);
				mysql_free_result(result);
				return account_id;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

/*
	Give the account with id "account_id" permission to enter zone "zone_name" from ip address "ip"
	with character "char_name". Return true if successful.
	False will be returned if there is a database error.
*/
bool Database::SetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM authentication WHERE account_id=%i", account_id);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	buf_len = 128;
	chars = -1;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO authentication SET account_id=%i, char_name='%s', zone_name='%s', ip=%u", account_id, char_name, zone_name, ip);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	This function will return the zone name in the "zone_name" parameter.
	This is used when a character changes zone, the old zone server sets
	the authentication record, the world server reads this new zone	name.
	If there was a record return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT char_name, zone_name FROM authentication WHERE account_id=%i AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", account_id, ip, AUTHENTICATION_TIMEOUT);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strcpy(char_name, row[0]);
				strcpy(zone_name, row[1]);
				mysql_free_result(result);
				return true;
			}
			else
			{
				mysql_free_result(result);
				return false;
			}
		}
		else
		{
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}


/*
	This function will remove the record in the authentication table for
	the account with id "accout_id"
	False will also be returned if there is a database error.
*/
bool Database::ClearAuthentication(int32 account_id)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM authentication WHERE account_id=%i", account_id);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in ClearAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

/*
	Check if there is an account with name "name" and password "password"
	Return the account id or zero if no account matches.
	Zero will also be returned if there is a database error.
*/
int32 Database::CheckLogin(char* name, char* password)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	int i;
	for (i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}
	for (i=0; i<strlen(password); i++)
	{
		if ((password[i] < 'a' || password[i] > 'z') && 
		    (password[i] < 'A' || password[i] > 'Z') && 
		    (password[i] < '0' || password[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id FROM account WHERE name='%s' AND password='%s'", name, password);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 id = atoi(row[0]);
				mysql_free_result(result);
				return id;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckLogin query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::CheckStatus(int32 account_id)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT status FROM account WHERE id='%i'", account_id);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckStatus query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::CheckZoneWeather(char* zonename)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT rain FROM zone_server WHERE name='%s'", zonename);
		cerr << "Zone Weather: " << zonename << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckZoneWeather query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::SetZoneWeather(char* zonename, char* weather)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "UPDATE zone_server SET rain='%s' WHERE name='%s'",weather,zonename);
		cerr << "Updating Weather for: " << zonename << "Setting to: " << weather << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				mysql_free_result(result);
				return true;
			}
		}
		else
		{
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in SetWorldWeather query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

bool Database::CreateAccount(char* name, char* password, char* status, int32 lsaccount_id)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO account SET name='%s', password='%s', status='%s', lsaccount_id=%i;",name,password,status, lsaccount_id);
		cerr << "Account Attempting to be created:" << name << " " << password << " " << status << endl;
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in CreateAccount query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;
	return true;
}

int32 Database::DeleteAccount(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM account WHERE name='%s';",name);
		cerr << "Account Attempting to be deleted:" << name << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				mysql_free_result(result);
				return true;
			}
		}
		else
		{
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in DeleteAccount query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

bool Database::SetGMFlag(char* name, char* status)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		
		chars = snprintf(query, buf_len, "UPDATE account SET status='%s' WHERE name='%s';",status,name);
		cout << "Account being GM Flagged:" << name << ", Level: " << status << endl;
	}

	if (mysql_query(&mysql, query))
	{
		delete[] query;
		return false;
	}
	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

void Database::GetCharSelectInfo(int32 account_id, CharacterSelect_Struct* cs)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

    memset((char*)cs, 0, 1120);
    for(int i=0;i<10;i++)
    {
        strcpy(cs->name[i], "<none>");
        strcpy(cs->zone[i], ZONE_NAME);
        cs->level[i] = 0;
    }

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT name,profile FROM character_ WHERE account_id=%i", account_id);
	}

	PlayerProfile_Struct* pp;
	int char_num = 0;
	unsigned long* lengths;

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while ((row = mysql_fetch_row(result)))
			{
				lengths = mysql_fetch_lengths(result);
				if (lengths[1] == sizeof(PlayerProfile_Struct))
				{
					strcpy(cs->name[char_num], row[0]);
					pp = (PlayerProfile_Struct*) row[1];
					cs->level[char_num] = pp->level;
					cs->class_[char_num] = pp->class_;
					cs->race[char_num] = pp->race;
					cs->gender[char_num] = pp->gender;
					cs->face[char_num] = pp->pp_unknown2[0];
					strcpy(cs->zone[char_num], pp->current_zone);

					// Coder_01 - REPLACE with item info when available.
					Item_Struct* item = 0;
					item = GetItem(pp->inventory[2]);
					if (item != 0) {
						cs->equip[char_num][0] = item->common.material;
						cs->cs_colors[char_num][0] = item->common.color;
					}
					item = GetItem(pp->inventory[17]);
					if (item != 0) {
						cs->equip[char_num][1] = item->common.material;
						cs->cs_colors[char_num][1] = item->common.color;
					}
					item = GetItem(pp->inventory[7]);
					if (item != 0) {
						cs->equip[char_num][2] = item->common.material;
						cs->cs_colors[char_num][2] = item->common.color;
					}
					item = GetItem(pp->inventory[10]);
					if (item != 0) {
						cs->equip[char_num][3] = item->common.material;
						cs->cs_colors[char_num][3] = item->common.color;
					}
					item = GetItem(pp->inventory[12]);
					if (item != 0) {
						cs->equip[char_num][4] = item->common.material;
						cs->cs_colors[char_num][4] = item->common.color;
					}
					item = GetItem(pp->inventory[18]);
					if (item != 0) {
						cs->equip[char_num][5] = item->common.material;
						cs->cs_colors[char_num][5] = item->common.color;
					}
					item = GetItem(pp->inventory[19]);
					if (item != 0) {
						cs->equip[char_num][6] = item->common.material;
						cs->cs_colors[char_num][6] = item->common.color;
					}

					char_num++;
				}
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetCharSelectInfo query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return;
	}

	return;
}

/*
	Reserve the character name "name" for account "account_id"
	This name can then be used to create a character.
	Return true if successful, false if the name was already reserved.
	False will also be returned if there is a database error.
*/
bool Database::ReserveName(int32 account_id, char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT into character_ SET account_id=%i, name='%s', profile=NULL", account_id, name);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in ReserveName query '" << query << "' " << mysql_error(&mysql) << endl;
		if (query != 0)
			delete[] query;
		return false;
	}

	return true;
}

/*
	Delete the character with the name "name"
	False will also be returned if there is a database error.
*/
bool Database::DeleteCharacter(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE from character_ WHERE name='%s'", name);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in DeleteCharacter query '" << query << "' " << mysql_error(&mysql) << endl;
		if (query != 0)
			delete[] query;
		return false;
	}

	return true;
}

/*
	Create and store a character profile with the give parameters.
	This function will not check if the paramaters are legal for this class/race combination.
	Return true if successful. Return false if the name was not reserved for character creation
	for this "account_id".
	False will also be returned if there is a database error.
*/
bool Database::CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis, int8 face)
{
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
	}

	PlayerProfile_Struct pp;
	memset((char*)&pp, 0, sizeof(PlayerProfile_Struct));

// TODO: Get the right data into this without using this file
/*
FILE* fp;
fp = fopen("../zone/start_profile_packet", "r");
fread((char*)&pp, sizeof(PlayerProfile_Struct), 1, fp);
fclose(fp);
*/
	strcpy(pp.name, name);
	
	//Disgrace: temp storage place for face until we can figure out where it is stored...
	pp.pp_unknown2[0] = face;
	
	pp.last_name[0] = 0;
	pp.race = race;
	pp.class_ = class_;
	pp.gender = gender;
	pp.level = 1;
	pp.exp = 0;
//	pp.pp_unknown5[0] = 0x05;
	pp.mana = 0;
	pp.pp_unknown6[0] = 0x02;
//	pp.pp_unknown6[48] = 0x14;
//	pp.pp_unknown6[50] = 0x05;
	pp.cur_hp = 20; // TODO: This should be max hp
	pp.STR = str;
	pp.STA = sta;
	pp.CHA = cha;
	pp.DEX = dex;	
	pp.INT = int_;
	pp.AGI = agi;
	pp.WIS = wis;
	
	// Disgrace: for windows compile
	#ifndef WIN32
		for (int i=0;i<24;i++) 
			pp.languages[i] = 100;
		for (int i=0;i<sizeof(pp.inventory); i++) 
		{ 
			pp.inventory[i] = 0xffff; 
		} 
	#else
		for (i=0;i<24;i++) 
			pp.languages[i] = 100;
		for (i=0;i<sizeof(pp.inventory); i++) 
		{ 
			pp.inventory[i] = 0xffff; 
		} 
	#endif
/*
	pp.pp_unknown8[58] = 0x07;
	pp.pp_unknown8[59] = 0x27;
	pp.pp_unknown8[60] = 0x06;
	pp.pp_unknown8[61] = 0x27;
	pp.pp_unknown8[62] = 0x0d;
	pp.pp_unknown8[63] = 0x27;
	pp.pp_unknown8[64] = 0xfb;
	pp.pp_unknown8[65] = 0x26;
	pp.pp_unknown8[66] = 0x04;
	pp.pp_unknown8[67] = 0x27;
	pp.pp_unknown8[68] = 0x02;
	pp.pp_unknown8[69] = 0x27;
	pp.pp_unknown8[70] = 0x1e;
	pp.pp_unknown8[71] = 0x49;
	pp.pp_unknown8[72] = 0x0c;
	pp.pp_unknown8[73] = 0x49;
*/
	// Disgrace: for windows compile
	#ifndef WIN32
		for (int i=0;i<15; i++)
			pp.buffs[i].spell = 0xffff;

		for (int i=0;i<180; i++)
		{
			pp.pp_unknown9[i] = 0xff;
		}

		for (int i=0;i<256; i++)
			pp.spell_book[i] = 0xffff;
		for (int i=0;i<8; i++)
			pp.spell_memory[i] = 0xffff;
	#else
		for (i=0;i<15; i++)
			pp.buffs[i].spell = 0xffff;

		for (i=0;i<180; i++)
		{
			pp.pp_unknown9[i] = 0xff;
		}

		for (i=0;i<256; i++)
			pp.spell_book[i] = 0xffff;
		for (i=0;i<8; i++)
			pp.spell_memory[i] = 0xffff;
	#endif



	char tmp[16];
	// Pyro: Get zone start locs from database, if they don't exist set to defaults.
	if (!GetVariable("startzone", tmp, 16))
		strcpy(pp.current_zone, ZONE_NAME);
	else
		strncpy(pp.current_zone, tmp, 16);

	if (!GetSafePoints(pp.current_zone, &pp.x, &pp.y, &pp.z)) {
		pp.x = 0;
		pp.y = 0;
		pp.z = 5;
	}

	pp.platinum = 10;
	pp.gold = 20;
	pp.silver = 30;
	pp.copper = 40;
	pp.platinum_bank = 15;
	pp.gold_bank = 25;
	pp.silver_bank = 35;
	pp.copper_bank = 45;

	// Disgrace: for windows compile
	#ifndef WIN32
		for (int i=0;i<74; i++)
			pp.skills[i] = i;	
		strcpy(pp.bind_point_zone, ZONE_NAME);
		for (int i=0;i<4; i++)
			strcpy(pp.start_point_zone[i], ZONE_NAME);
	#else
		for (i=0;i<74; i++)
			pp.skills[i] = i;	
		strcpy(pp.bind_point_zone, ZONE_NAME);
		for (i=0;i<4; i++)
			strcpy(pp.start_point_zone[i], ZONE_NAME);
	#endif

    end += sprintf(end, "UPDATE character_ SET profile=");
    *end++ = '\'';
    end += mysql_real_escape_string(&mysql, end, (char*)&pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s' AND profile IS NULL", account_id, name);

    if (mysql_real_query(&mysql, query, (unsigned int) (end - query)))
    {
        cerr << "Error in CreateCharacter query '" << query << "' " << mysql_error(&mysql) << endl;
		return false;
    }

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	Get the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT profile FROM character_ WHERE account_id=%i AND name='%s'", account_id, name);
	}

	unsigned long* lengths;

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{	
				row = mysql_fetch_row(result);
				lengths = mysql_fetch_lengths(result);
				if (lengths[0] == sizeof(PlayerProfile_Struct))
				{
					memcpy(pp, row[0], sizeof(PlayerProfile_Struct));
				}
				else
				{
					cerr << "Pleyer profile length mismatch in GetPlayerProfile" << endl;
					mysql_free_result(result);
					return false;
				}
			}
			else
			{
				mysql_free_result(result);
				return false;
			}
		}
		else
		{
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetPlayerProfile query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

/*
	Update the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp)
{
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}

    end += sprintf(end, "UPDATE character_ SET profile=");
    *end++ = '\'';
    end += mysql_real_escape_string(&mysql, end, (char*)pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s'", account_id, name);

    if (mysql_real_query(&mysql, query, (unsigned int) (end - query)))
    {
        cerr << "Error in SetPlayerProfile query " << mysql_error(&mysql) << endl;
		return false;
    }

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	This function returns the account_id that owns the character with
	the name "name" or zero if no character with that name was found
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAccountIDByChar(char* charname)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int i=0; i<strlen(charname); i++)
	{
		if ((charname[i] < 'a' || charname[i] > 'z') && 
		    (charname[i] < 'A' || charname[i] > 'Z') && 
		    (charname[i] < '0' || charname[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT account_id FROM character_ WHERE name='%s'", charname);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 tmp = atoi(row[0]); // copy to temp var because gotta free the result before exitting this function
				mysql_free_result(result);
				return tmp;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetAccountIDByChar query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return 0;
}


int32 Database::GetAccountIDByName(char* accname)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int i=0; i<strlen(accname); i++)
	{
		if ((accname[i] < 'a' || accname[i] > 'z') && 
		    (accname[i] < 'A' || accname[i] > 'Z') && 
		    (accname[i] < '0' || accname[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id FROM account WHERE name='%s'", accname);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 tmp = atoi(row[0]); // copy to temp var because gotta free the result before exitting this function
				mysql_free_result(result);
				return tmp;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetAccountIDByAcc query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return 0;
}

void Database::GetAccountName(int32 accountid, char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT name FROM account WHERE id='%i'", accountid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strcpy(name, row[0]);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		delete[] query;
		cerr << "Error in GetAccountName query '" << query << "' " << mysql_error(&mysql) << endl;
	}
}

void Database::GetCharacterInfo(char* name, int32* charid, int32* guilddbid, int8* guildrank)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id, guild, guildrank FROM character_ WHERE name='%s'", name);
	}
	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				*charid = atoi(row[0]);
				*guilddbid = atoi(row[1]);
				*guildrank = atoi(row[2]);
				mysql_free_result(result);
				return;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetCharacterID query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
}

// Gets variable from 'variables' table
bool Database::GetVariable(char* varname, char* varvalue, int16 varvalue_len) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT value FROM variables WHERE varname like '%s'", varname);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				snprintf(varvalue, varvalue_len, "%s", row[0]);
				varvalue[varvalue_len-1] = 0;
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetVariable query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
	return false;
}

bool Database::SetVariable(char* varname, char* varvalue) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "Update variables set value='%s' WHERE varname like '%s'", varvalue, varname);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		query = 0;
		if (mysql_affected_rows(&mysql) != 1) {
			chars = -1;
			while (chars == -1 || chars >= buf_len)
			{
				if (query != 0)	{
					delete[] query;
					query = 0;
					buf_len *= 2;
				}
				query = new char[buf_len];
				chars = snprintf(query, buf_len, "Insert Into variables (varname, value) values ('%s', '%s')", varname, varvalue);
			}
			if (!mysql_query(&mysql, query))
			{
				delete[] query;
				query = 0;
				if (mysql_affected_rows(&mysql) == 1) {
					return true;
				}
			}
		}
	}
	else
	{
		cerr << "Error in SetVariable query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
	return false;
}

bool Database::CheckZoneserverAuth(char* ipaddr) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT * FROM zoneserver_auth WHERE '%s' like host", ipaddr);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) >= 1) {
				mysql_free_result(result);
				return true;
			}
			else {
				mysql_free_result(result);
				return false;
			}
		}
		else
		{
			mysql_free_result(result);
			return false;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in CheckZoneserverAuth query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
	return false;
}

bool Database::GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
	int i;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id, eqid, name, leader, rank0title, rank1, rank1title, rank2, rank2title, rank3, rank3title, rank4, rank4title, rank5, rank5title from guilds where eqid=%i;", guildeqid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				gr->leader = atoi(row[3]);
				gr->databaseID = atoi(row[0]);
				strcpy(gr->name, row[2]);
				for (int i = 0; i <= GUILD_MAX_RANK; i++) {
					strcpy(gr->rank[i].rankname, row[4 + (i*2)]);
					if (i == 0) {
						gr->rank[i].heargu = 1;
						gr->rank[i].speakgu = 1;
						gr->rank[i].invite = 1;
						gr->rank[i].remove = 1;
						gr->rank[i].promote = 1;
						gr->rank[i].demote = 1;
						gr->rank[i].motd = 1;
						gr->rank[i].warpeace = 1;
					}
					else if (strlen(row[3 + (i*2)]) >= 8) {
						gr->rank[i].heargu = (row[3 + (i*2)][GUILD_HEAR] == '1');
						gr->rank[i].speakgu = (row[3 + (i*2)][GUILD_SPEAK] == '1');
						gr->rank[i].invite = (row[3 + (i*2)][GUILD_INVITE] == '1');
						gr->rank[i].remove = (row[3 + (i*2)][GUILD_REMOVE] == '1');
						gr->rank[i].promote = (row[3 + (i*2)][GUILD_PROMOTE] == '1');
						gr->rank[i].demote = (row[3 + (i*2)][GUILD_DEMOTE] == '1');
						gr->rank[i].motd = (row[3 + (i*2)][GUILD_MOTD] == '1');
						gr->rank[i].warpeace = (row[3 + (i*2)][GUILD_WARPEACE] == '1');
					}
					else {
						gr->rank[i].heargu = 0;
						gr->rank[i].speakgu = 0;
						gr->rank[i].invite = 0;
						gr->rank[i].remove = 0;
						gr->rank[i].promote = 0;
						gr->rank[i].demote = 0;
						gr->rank[i].motd = 0;
						gr->rank[i].warpeace = 0;
					}

					if (gr->rank[i].rankname[0] == 0)
						snprintf(gr->rank[i].rankname, 100, "Guild Rank %i", i);
				}
			}
			else {
				gr->leader = 0;
				gr->databaseID = 0;
				memset(gr->name, 0, sizeof(gr->name));
				for (int i = 0; i <= GUILD_MAX_RANK; i++) {
					snprintf(gr->rank[i].rankname, 100, "Guild Rank %i", i);
					if (i == 0) {
						gr->rank[i].heargu = 1;
						gr->rank[i].speakgu = 1;
						gr->rank[i].invite = 1;
						gr->rank[i].remove = 1;
						gr->rank[i].promote = 1;
						gr->rank[i].demote = 1;
						gr->rank[i].motd = 1;
						gr->rank[i].warpeace = 1;
					}
					else {
						gr->rank[i].heargu = 0;
						gr->rank[i].speakgu = 0;
						gr->rank[i].invite = 0;
						gr->rank[i].remove = 0;
						gr->rank[i].promote = 0;
						gr->rank[i].demote = 0;
						gr->rank[i].motd = 0;
						gr->rank[i].warpeace = 0;
					}
				}
			}
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetGuildRank query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::LoadGuilds(GuildRanks_Struct* guilds) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
	int i;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int a = 0; a < 512; a++) {
		guilds[a].leader = 0;
		guilds[a].databaseID = 0;
		memset(guilds[a].name, 0, sizeof(guilds[a].name));
		for (int i = 0; i <= GUILD_MAX_RANK; i++) {
			snprintf(guilds[a].rank[i].rankname, 100, "Guild Rank %i", i);
			if (i == 0) {
				guilds[a].rank[i].heargu = 1;
				guilds[a].rank[i].speakgu = 1;
				guilds[a].rank[i].invite = 1;
				guilds[a].rank[i].remove = 1;
				guilds[a].rank[i].promote = 1;
				guilds[a].rank[i].demote = 1;
				guilds[a].rank[i].motd = 1;
				guilds[a].rank[i].warpeace = 1;
			}
			else {
				guilds[a].rank[i].heargu = 0;
				guilds[a].rank[i].speakgu = 0;
				guilds[a].rank[i].invite = 0;
				guilds[a].rank[i].remove = 0;
				guilds[a].rank[i].promote = 0;
				guilds[a].rank[i].demote = 0;
				guilds[a].rank[i].motd = 0;
				guilds[a].rank[i].warpeace = 0;
			}
		}
		Sleep(0);
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id, eqid, name, leader, rank0title, rank1, rank1title, rank2, rank2title, rank3, rank3title, rank4, rank4title, rank5, rank5title from guilds;");
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			int32 guildeqid = 0xFFFFFFFF;
			while (row = mysql_fetch_row(result))
			{
				guildeqid = atoi(row[1]);
				if (guildeqid < 512) {
					guilds[guildeqid].leader = atoi(row[3]);
					guilds[guildeqid].databaseID = atoi(row[0]);
					strcpy(guilds[guildeqid].name, row[2]);
					for (int i = 0; i <= GUILD_MAX_RANK; i++) {
						strcpy(guilds[guildeqid].rank[i].rankname, row[4 + (i*2)]);
						if (i == 0) {
							guilds[guildeqid].rank[i].heargu = 1;
							guilds[guildeqid].rank[i].speakgu = 1;
							guilds[guildeqid].rank[i].invite = 1;
							guilds[guildeqid].rank[i].remove = 1;
							guilds[guildeqid].rank[i].promote = 1;
							guilds[guildeqid].rank[i].demote = 1;
							guilds[guildeqid].rank[i].motd = 1;
							guilds[guildeqid].rank[i].warpeace = 1;
						}
						else if (strlen(row[3 + (i*2)]) >= 8) {
							guilds[guildeqid].rank[i].heargu = (row[3 + (i*2)][GUILD_HEAR] == '1');
							guilds[guildeqid].rank[i].speakgu = (row[3 + (i*2)][GUILD_SPEAK] == '1');
							guilds[guildeqid].rank[i].invite = (row[3 + (i*2)][GUILD_INVITE] == '1');
							guilds[guildeqid].rank[i].remove = (row[3 + (i*2)][GUILD_REMOVE] == '1');
							guilds[guildeqid].rank[i].promote = (row[3 + (i*2)][GUILD_PROMOTE] == '1');
							guilds[guildeqid].rank[i].demote = (row[3 + (i*2)][GUILD_DEMOTE] == '1');
							guilds[guildeqid].rank[i].motd = (row[3 + (i*2)][GUILD_MOTD] == '1');
							guilds[guildeqid].rank[i].warpeace = (row[3 + (i*2)][GUILD_WARPEACE] == '1');
						}
						else {
							guilds[guildeqid].rank[i].heargu = 0;
							guilds[guildeqid].rank[i].speakgu = 0;
							guilds[guildeqid].rank[i].invite = 0;
							guilds[guildeqid].rank[i].remove = 0;
							guilds[guildeqid].rank[i].promote = 0;
							guilds[guildeqid].rank[i].demote = 0;
							guilds[guildeqid].rank[i].motd = 0;
							guilds[guildeqid].rank[i].warpeace = 0;
						}

						if (guilds[guildeqid].rank[i].rankname[0] == 0)
							snprintf(guilds[guildeqid].rank[i].rankname, 100, "Guild Rank %i", i);
					}
				}
				Sleep(0);
			}
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetGuildRank query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetGuildEQID(int32 guilddbid)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT eqid FROM guilds WHERE id=%i", guilddbid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 tmp = atoi(row[0]);
				mysql_free_result(result);
				return tmp;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetGuildEQID query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return 0xFFFFFFFF;
}

// Pyro: Get zone starting points from DB
bool Database::GetSafePoints(char* short_name, float* safe_x, float* safe_y, float* safe_z) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT safe_x, safe_y, safe_z FROM zone WHERE short_name='%s'", short_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				*safe_x = atof(row[0]);
				*safe_y = atof(row[1]);
				*safe_z = atof(row[2]) * 10;
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetSafePoint query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
	return false;
}

bool Database::SetGuild(int32 charid, int32 guilddbid, int8 guildrank)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "UPDATE character_ SET guild=%i, guildrank=%i WHERE id=%i", guilddbid, guildrank, charid);
	}
	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in SetGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetFreeGuildEQID()
{
    char query[50];
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int x = 1; x < 512; x++) {
		snprintf(query, 50, "SELECT eqid FROM guilds where eqid=%i;", x);

		if (!mysql_query(&mysql, query))
		{
			result = mysql_store_result(&mysql);
			if (result)
			{
				if (!(mysql_num_rows(result) == 1)) {
					mysql_free_result(result);
					return x;
				}
			}
			mysql_free_result(result);
		}
		else
		{
			cerr << "Error in GetFreeGuildEQID query '" << query << "' " << mysql_error(&mysql) << endl;
		}
	}

	return 0xFFFFFFFF;
}

int32 Database::CreateGuild(char* name, int32 leader)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
	char buf[65];
	mysql_real_escape_string(&mysql, buf, name, strlen(name)) ;

	int32 tmpeqid = GetFreeGuildEQID();
	if (tmpeqid == 0xFFFFFFFF) {
		cout << "Error in Database::CreateGuild: unable to find free eqid" << endl;
		return 0xFFFFFFFF;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO guilds (name, leader, eqid) Values ('%s', %i, %i)", buf, leader, tmpeqid);
	}

	if (!mysql_real_query(&mysql, query, strlen(query)))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
		{
			return tmpeqid;
		}
		else
		{
			return 0xFFFFFFFF;
		}
	}
	else
	{
		cerr << "Error in CreateGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return 0xFFFFFFFF;
	}

	return 0xFFFFFFFF;
}

bool Database::DeleteGuild(int32 guilddbid)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM guilds WHERE id=%i;", guilddbid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		return true;
	}
	else
	{
		cerr << "Error in DeleteGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::RenameGuild(int32 guilddbid, char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
	char buf[65];
	mysql_real_escape_string(&mysql, buf, name, strlen(name)) ;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "Update guilds set name='%s' WHERE id=%i;", buf, guilddbid);
	}

	if (!mysql_real_query(&mysql, query, strlen(query)))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in RenameGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
	char buf[203];
	char buf2[8];
	mysql_real_escape_string(&mysql, buf, grl->rankname, strlen(grl->rankname)) ;
	buf2[GUILD_HEAR] = grl->heargu + '0';
	buf2[GUILD_SPEAK] = grl->speakgu + '0';
	buf2[GUILD_INVITE] = grl->invite + '0';
	buf2[GUILD_REMOVE] = grl->remove + '0';
	buf2[GUILD_PROMOTE] = grl->promote + '0';
	buf2[GUILD_DEMOTE] = grl->demote + '0';
	buf2[GUILD_MOTD] = grl->motd + '0';
	buf2[GUILD_WARPEACE] = grl->warpeace + '0';

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "Update guilds set rank%ititle='%s', rank%i='%s' WHERE id=%i;", ranknum, buf, ranknum, buf2, guilddbid);
	}

	if (!mysql_real_query(&mysql, query, strlen(query)))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in EditGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::GetZoneLongName(char* short_name, char** long_name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT long_name FROM zone WHERE short_name='%s'", short_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				if (long_name != 0) {
					row = mysql_fetch_row(result);
					*long_name = strcpy(new char[strlen(row[0])+1], row[0]);
				}
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetZoneLongName query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

int32 Database::GetGuildDBIDbyLeader(int32 leader)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id FROM guilds WHERE leader=%i", leader);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 tmp = atoi(row[0]);
				mysql_free_result(result);
				return tmp;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetGuildDBIDbyLeader query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return 0;
}

bool Database::SetGuildLeader(int32 guilddbid, int32 leader)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "UPDATE guilds SET leader=%i WHERE id=%i", leader, guilddbid);
	}
	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in SetGuildLeader query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::SetGuildMOTD(int32 guilddbid, char* motd)
{
    char *query = 0;
	int buf_len = 512;
    int chars = -1;
	char* motdbuf = 0;

	motdbuf = new char[(strlen(motd)*2)+3];
	mysql_real_escape_string(&mysql, motdbuf, motd, strlen(motd)) ;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "Update guilds set motd='%s' WHERE id=%i;", motdbuf, guilddbid);
	}

	if (!mysql_real_query(&mysql, query, strlen(query)))
	{
		delete[] query;
		if (mysql_affected_rows(&mysql) == 1)
			return true;
		else
			return false;
	}
	else
	{
		cerr << "Error in RenameGuild query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

bool Database::GetGuildMOTD(int32 guilddbid, char* motd)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT motd FROM guilds WHERE id=%i", guilddbid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				if (row[0] == 0)
					strcpy(motd, "");
				else
					strcpy(motd, row[0]);
				mysql_free_result(result);
				return true;
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetGuildMOTD query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return false;
}

bool Database::LoadItems()
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM items");

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			row = mysql_fetch_row(result);
			if (row != 0 && row[0] > 0)
			{ 
				max_item = atoi(row[0]);
				item_array = new Item_Struct*[max_item+1];
				for(int i=0; i<max_item; i++)
				{
					item_array[i] = 0;
				}
				mysql_free_result(result);
				
				query = 0;
				buf_len = 256;
				chars = -1;
				while (chars == -1 || chars >= buf_len)
				{
					if (query != 0)
					{
						delete[] query;
						query = 0;
						buf_len *= 2;
					}
					query = new char[buf_len];
					chars = snprintf(query, buf_len, "SELECT id,raw_data FROM items");
				}

				unsigned long* lengths;
				if (!mysql_query(&mysql, query))
				{
					delete[] query;
					result = mysql_store_result(&mysql);
					if (result)
					{
						while(row = mysql_fetch_row(result))
						{
							lengths = mysql_fetch_lengths(result);
							if (lengths[1] == sizeof(Item_Struct))
							{
								item_array[atoi(row[0])] = new Item_Struct;
								memcpy(item_array[atoi(row[0])], row[1], sizeof(Item_Struct));
							}
							else
							{
								// TODO: Invalid item length in database
							}
							Sleep(0);
						}
					}
					mysql_free_result(result);
				}
				else
				{
					cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
					delete[] query;
					return false;
				}
			}
			else
			{
				mysql_free_result(result);
			}
		}
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
	return true;
}

bool Database::LoadNPCTypes() {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM npc_types");
	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			row = mysql_fetch_row(result);
			if (row != 0 && row > 0)
			{
				max_npc_type = atoi(row[0]);
				npc_type_array = new NPCType*[max_npc_type+1];
				for (int x=0; x <= max_npc_type; x++)
					npc_type_array[x] = 0;
				mysql_free_result(result);

				query = 0;
				buf_len = 256;
				chars = -1;
				while (chars == -1 || chars >= buf_len)
				{
					if (query != 0)
					{
						delete[] query;
						query = 0;
						buf_len *= 2;
					}
					query = new char[buf_len];
					chars = snprintf(query, buf_len, "SELECT id,name,level,race,class,hp,gender,texture,loottable_id FROM npc_types");//WHERE zone='%s'", zone_name);
				}

				if (!mysql_query(&mysql, query))
				{
					delete[] query;
					result = mysql_store_result(&mysql);
					if (result)
					{
						while(row = mysql_fetch_row(result))
						{
							npc_type_array[atoi(row[0])] = new NPCType;
							memset(npc_type_array[atoi(row[0])], 0, sizeof(NPCType));
							strncpy(npc_type_array[atoi(row[0])]->name, row[1], 30);
							npc_type_array[atoi(row[0])]->npc_id = atoi(row[0]); // rembrant, Dec. 2
							npc_type_array[atoi(row[0])]->level = atoi(row[2]);
							npc_type_array[atoi(row[0])]->race = atoi(row[3]);
							npc_type_array[atoi(row[0])]->class_ = atoi(row[4]);
							npc_type_array[atoi(row[0])]->cur_hp = atoi(row[5]);
							npc_type_array[atoi(row[0])]->max_hp = atoi(row[5]);
							npc_type_array[atoi(row[0])]->gender = atoi(row[6]);
							npc_type_array[atoi(row[0])]->texture = atoi(row[7]);
							npc_type_array[atoi(row[0])]->loottable_id = atoi(row[8]);
							Sleep(0);
						}
					}
					mysql_free_result(result);
				}
				else
				{
					cerr << "Error in LoadNPCTypes query '" << query << "' " << mysql_error(&mysql) << endl;
					delete[] query;
					return false;
				}
			}
			else
			{
				mysql_free_result(result);
			}
		}
	}
	else
	{
		cerr << "Error in LoadNPCTypes query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

Item_Struct* Database::GetItem(uint32 id)
{
	if (item_array && id <= max_item)
		return item_array[id];
	else
		return 0;
}

NPCType* Database::GetNPCType(uint32 id)
{
	if (npc_type_array && id <= max_npc_type)
		return npc_type_array[id]; 
	else
		return 0;
}

void Database::ClearZoneServerTable() {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM zone_server");
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in ClearZoneServerTable query '" << query << "' " << mysql_error(&mysql) << endl;
	}

	delete[] query;
}

bool Database::CheckNameFilter(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT count(*) FROM name_filter WHERE '%s' like name", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				if (row[0] != 0) {
					if (atoi(row[0]) == 0) {
						mysql_free_result(result);
						return false;
					}
				}
			}
		}
		mysql_free_result(result);
		return true;
	}
	else
	{
		cerr << "Error in CheckNameFilter query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return false;
}

bool Database::AddToNameFilter(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO name_filter (name) values ('%s')", name);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in AddToNameFilter query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

int32 Database::GetAccountIDFromLSID(int32 lsaccount_id) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id FROM account WHERE lsaccount_id=%i", lsaccount_id);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 account_id = atoi(row[0]);
				mysql_free_result(result);
				return account_id;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetAccountIDFromLSID query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return 0;
	}

	return 0;
}
