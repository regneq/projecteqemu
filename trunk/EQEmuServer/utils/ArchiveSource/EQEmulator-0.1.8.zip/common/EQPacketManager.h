#ifndef EQPACKETMANAGER_H
#define EQPACKETMANAGER_H

#include <iostream.h>

#include "types.h"
#include "queue.h"
#include "timer.h"

#include "eq_opcodes.h"
#include "EQPacket.h"
#include "EQFragment.h"
#include "packet_dump.h"

// Added struct
typedef struct
{
    uchar*  buffer;
    int16   size;
}MySendPacketStruct;

template <typename type>
void SAFE_DELETE(type &del){if(del){delete[]del; del=0;}}

/************ DEFINES ************/

#define PM_ACTIVE    0 //manager is up and running
#define PM_FINISHING 1 //manager received closing bits and is going to send final packet
#define PM_FINISHED  2 //manager has sent closing bits back to client


/************ STRUCTURES/CLASSES ************/

    /************ PACKET RELATED STRUCT ************/
    class APPLAYER
    {
    public:
        ~APPLAYER() { SAFE_DELETE(pBuffer); }
        APPLAYER() { size = 0; opcode = 0; pBuffer = 0; }
        int32  size;
        int16  opcode;
        uchar* pBuffer;
    };

    /************ Contain ack stuff ************/
    struct ACK_INFO
    {
        ACK_INFO() { dwARQ = 0; dbASQ_high = dbASQ_low = 0; dwGSQ = 0; }

        int16   dwARQ; //Current request ack
        int16   dbASQ_high : 8,
                dbASQ_low  : 8;
        int16   dwGSQ; //Main sequence number SHORT#2
        
    };


class CEQPacketManager  
{
public:
/************ PUBLIC FUNCTIONS ************/
    CEQPacketManager();//CTimer *tim_set, int32 ddTimerID_set);
    virtual ~CEQPacketManager();
    /**********/

    void SetDebugLevel(int8 set_level) { debug_level = set_level; }
	void LogPackets(bool logging) { LOG_PACKETS = logging; }
    /************ parce/make packets ************/
    void ParceEQPacket(int16 dwSize, uchar* pPacket);
    void MakeEQPacket(APPLAYER* app, bool ack_req=true); //Make a fragment eq packet and put them on the SQUEUE/RSQUEUE

    /************ Add ack to packet if requested ************/
    void AddAck(CEQPacket *pack)
    {
        if(CACK.dwARQ)
        {       
            pack->HDR.b2_ARSP = 1;          //Set ack response field
            pack->dwARSP = CACK.dwARQ;      //ACK current ack number.
            CACK.dwARQ = 0;
        }
    }
    /************ Timer Functions ************/
    void CheckTimers(void); //Check all inclass timers and call proper functions

    /************ Check if  ************/
    int CheckActive(void) { if(pm_state == PM_FINISHED) return(0); else
return(1);}
    void Close() { if (pm_state == PM_ACTIVE) pm_state = PM_FINISHING; }

    /************ INCOMING/OUTGOING ACK ************/
    void IncomingARSP(int16 dwARSP); 
    void IncomingARQ(int16 dwARQ);
    void OutgoingARQ(int16 dwARQ);
    void OutgoingARSP();
    /************ END INCOMING/OUTGOING ACK ************/

/************ PUBLIC VARIABLES ************/

    MyQueue<MySendPacketStruct> SendQueue; //Store packets thats on the send que
    MyQueue<APPLAYER>           OutQueue; //parced packets ready to go out of this class


private:
/************ PRIVATE FUNCTIONS ************/
    bool ProcessPacket(CEQPacket* pack, bool from_buffer=false);
    void CheckBufferedPackets();

/************ PRIVATE VARIABLES ************/
    FragmentGroupList fragment_group_list;
    MyQueue<CEQPacket> ResendQueue; //Resend queue

    LinkedList<CEQPacket*> buffered_packets; // Buffer of incoming packets
    
    ACK_INFO    SACK; //Server -> client info.
    ACK_INFO    CACK; //Client -> server info.
    int16       dwLastCACK;

    Timer* no_ack_received_timer;
    Timer* no_ack_sent_timer;
    Timer* keep_alive_timer;

    int    pm_state;  //manager state 
    int8   resend_count;
    int16  dwFragSeq;   //current fragseq

    int8 debug_level;

	bool LOG_PACKETS;
};

#endif
