# MySQL dump 8.16
#
# Host: localhost    Database: emurelease
#--------------------------------------------------------
# Server version	3.23.45-max-nt

Alter Table spawn rename spawnback;
INSERT INTO variables VALUES ('PersistentZoneState','0');

INSERT INTO zone VALUES ('qeynos','South Qeynos',10,14,3);
INSERT INTO zone VALUES ('lfaydark','Lesser Faydark',-312,1249,5);
INSERT INTO zone VALUES ('nurga','Mines of Nurga',-1318,-83,5);
INSERT INTO zone VALUES ('commons','West Commonlands',-840,3074,5);
INSERT INTO zone VALUES ('unrest','Estate of Unrest',635,-35,5);
INSERT INTO zone VALUES ('dreadlands','Dreadlands',20,20,10);
INSERT INTO zone VALUES ('eastwastes','Eastern Wastelands',0,0,5);
INSERT INTO zone VALUES ('templeveeshan','Temple of Veeshan',-500,-2000,-40);
INSERT INTO zone VALUES ('rathemtn','Rathe Mountains',2944,-828,5);
INSERT INTO zone VALUES ('neriakb','Neriak Commons',-560,-56,-38);
INSERT INTO zone VALUES ('neriakc','Neriak Third Gate',-779,581,-54);
INSERT INTO zone VALUES ('lakerathe','Lake Rathetear',-432,657,5);
INSERT INTO zone VALUES ('trakanon','Trakanon\'s Teeth',-3331,2649,5);
INSERT INTO zone VALUES ('oasis','Oasis of Marr',-835,885,0);
INSERT INTO zone VALUES ('rivervale','Rivervale',0,0,-37);
INSERT INTO zone VALUES ('veeshan','Veeshan\'s Peak',1680,40,30);
INSERT INTO zone VALUES ('sebilis','Old Sebilis',0,248,39.1);
INSERT INTO zone VALUES ('karnor','Karnor\'s Castle',305,18,3.1);
INSERT INTO zone VALUES ('thurgadinb','Icewell Keep',0,0,5);
INSERT INTO zone VALUES ('arena','The Arena',1050,-50,3.2);
INSERT INTO zone VALUES ('fearplane','Plane of Fear',-558,588,5);
INSERT INTO zone VALUES ('necropolis','Dragon Necropolis',0,0,5);
INSERT INTO zone VALUES ('eastkarana','Eastern Plains of Karana',-636,-52,5);
INSERT INTO zone VALUES ('cabwest','Cabilis West',-140,593,5);
INSERT INTO zone VALUES ('freportw','West Freeport',-245,-230,5);
INSERT INTO zone VALUES ('felwithea','Northern Felwithe',0,-444,5);
INSERT INTO zone VALUES ('timorous','Timorous Deep',-535,2564,5);
INSERT INTO zone VALUES ('erudsxing','Erud\'s Crossing',483,996,5);
INSERT INTO zone VALUES ('innothule','Innothule Swamp',-2614,-501,5);
INSERT INTO zone VALUES ('feerrott','The Feerrott',4,-1654,5);
INSERT INTO zone VALUES ('qeynos2','North Qeynos',-88,-67,5);
INSERT INTO zone VALUES ('lavastorm','Lavastorm Mountains',-408,929,5);
INSERT INTO zone VALUES ('qey2hh1','Western Plains of Karana',426,-4362,5);
INSERT INTO zone VALUES ('akanon','Ak\'Anon',848,-430,5);
INSERT INTO zone VALUES ('freportn','North Freeport',-51,-243,5);
INSERT INTO zone VALUES ('cshome','Sunset Home',0,0,5);
INSERT INTO zone VALUES ('cauldron','Dagnor\'s Cauldron',-563,-1507,5);
INSERT INTO zone VALUES ('warrens','Warrens',0,0,5);
INSERT INTO zone VALUES ('firiona','Firiona Vie',-3796,1654,5);
INSERT INTO zone VALUES ('lakeofillomen','Lake of Ill Omen',2007,-3172,5);
INSERT INTO zone VALUES ('befallen','Befallen',-813,-205,5);
INSERT INTO zone VALUES ('neriaka','Neriak - Foreign Quarter',-241,-387,5);
INSERT INTO zone VALUES ('kaladimb','South Kaladim',183,-137,5);
INSERT INTO zone VALUES ('soltemple','Temple of Solusek Ro',417,-22,5);
INSERT INTO zone VALUES ('soldungb','Nagafen\'s Lair',-753,-75,5);
INSERT INTO zone VALUES ('sirens','Sirens Grotto',0,0,5);
INSERT INTO zone VALUES ('ecommons','East Commonlands',-794,1570,5);
INSERT INTO zone VALUES ('crushbone','Crushbone',76,-71,5);
INSERT INTO zone VALUES ('sky','Plane of Sky',1305,585,5);
INSERT INTO zone VALUES ('qcat','Qeynos Aqueduct System',217,-303,5);
INSERT INTO zone VALUES ('swampofnohope','Swamp Of No Hope',297,1083,5);
INSERT INTO zone VALUES ('hole','The Hole',-60,29,5);
INSERT INTO zone VALUES ('oggok','Oggok',352,1139,5);
INSERT INTO zone VALUES ('skyfire','Skyfire Mountains',-3532,2298,5);
INSERT INTO zone VALUES ('cabeast','Cabilis East',1014,-188,5);
INSERT INTO zone VALUES ('beholder','Gorge of King Xorbb',1168,-119,5);
INSERT INTO zone VALUES ('tox','Toxxulia Forest',-2394,-163,5);
INSERT INTO zone VALUES ('charasis','Howling stones',0,0,5);
INSERT INTO zone VALUES ('oot','Ocean of Tears',-2888,-795,5);
INSERT INTO zone VALUES ('butcher','Butcherblock Mountains',-1184,-1956,5);
INSERT INTO zone VALUES ('northkarana','Northern Plains of Karana',416,2222,5);
INSERT INTO zone VALUES ('warslikswood','Warslilks Woods',-2205,-582,5);
INSERT INTO zone VALUES ('skyshrine','Sky Shrine',0,0,5);
INSERT INTO zone VALUES ('runnyeye','Runnyeye Citadel',-233,92,5);
INSERT INTO zone VALUES ('cobaltscar','Cobalt Scar',0,0,5);
INSERT INTO zone VALUES ('kerraridge','Kerra Isle',-148,273,5);
INSERT INTO zone VALUES ('frontiermtns','Frontier Mountains',2379,2541,5);
INSERT INTO zone VALUES ('thurgadina','City of Thurgadin',0,0,5);
INSERT INTO zone VALUES ('gukbottom','Ruins of Old Guk',771,-545,5);
INSERT INTO zone VALUES ('westwastes','Western Wastelands',0,0,5);
INSERT INTO zone VALUES ('highpass','Highpass Hold',417,-52,5);
INSERT INTO zone VALUES ('grobb','Grobb',301,-414,5);
INSERT INTO zone VALUES ('crystal','Crystal Caverns',0,0,5);
INSERT INTO zone VALUES ('growthplane','Plane of Growth',0,0,5);
INSERT INTO zone VALUES ('stonebrunt','Stonebrunt Mountains',0,0,5);
INSERT INTO zone VALUES ('qeytoqrg','Qeynos Hills',3773,962,5);
INSERT INTO zone VALUES ('soldunga','Solusek\'s Eye',-96,-667,5);
INSERT INTO zone VALUES ('halas','Halas',567,-364,5);
INSERT INTO zone VALUES ('paineel','Paineel',783,836,5);
INSERT INTO zone VALUES ('iceclad','Iceclad Ocean',0,0,5);
INSERT INTO zone VALUES ('paw','Lair of the Splitpaw',357,246,5);
INSERT INTO zone VALUES ('permafrost','Permafrost Caverns',187,-546,5);
INSERT INTO zone VALUES ('frozenshadow','Tower of Frozen Shadow',0,0,5);
INSERT INTO zone VALUES ('mischiefplane','Plane of Mischief',0,0,5);
INSERT INTO zone VALUES ('overthere','The Overthere',2889,2210,5);
INSERT INTO zone VALUES ('droga','Mines of Droga',-580,2111,5);
INSERT INTO zone VALUES ('kaladima','North Kaladim',401,-155,5);
INSERT INTO zone VALUES ('southkarana','Southern Plains of Karana',-6699,1149,5);
INSERT INTO zone VALUES ('kithicor','Kithicor Woods',1753,4121,5);
INSERT INTO zone VALUES ('kaesora','Kaesora',120,74,5);
INSERT INTO zone VALUES ('misty','Misty Thicket',-759,-1197,5);
INSERT INTO zone VALUES ('blackburrow','Blackburrow',-152,198,5);
INSERT INTO zone VALUES ('cazicthule','Lost Temple of CazicThule',145,-99,5);
INSERT INTO zone VALUES ('mistmoore','Castle Mistmoore',-270,-102,5);
INSERT INTO zone VALUES ('fieldofbone','Field of Bone',1480,2078,5);
INSERT INTO zone VALUES ('qrg','Surefall Glade',-159,-300,5);
INSERT INTO zone VALUES ('nro','Northern Desert of Ro',3176,98,5);
INSERT INTO zone VALUES ('erudnext','Erudin',-1104,-212,5);
INSERT INTO zone VALUES ('airplane','Plane of Air',0,0,5);
INSERT INTO zone VALUES ('sro','Southern Desert of Ro',310,622,5);
INSERT INTO zone VALUES ('dalnir','Dalnir',250,-929,5);
INSERT INTO zone VALUES ('erudnint','Erudin Palace',728,833,5);
INSERT INTO zone VALUES ('felwitheb','Southern Felwithe',531,-868,5);
INSERT INTO zone VALUES ('steamfont','Steamfont Mountains',165,-860,5);
INSERT INTO zone VALUES ('burningwood','The Burning Wood',-2529,2596,5);
INSERT INTO zone VALUES ('freporte','East Freeport',-159,-271,5);
INSERT INTO zone VALUES ('wakening','Wakening Lands',0,0,5);
INSERT INTO zone VALUES ('guktop','Guk',1653,462,5);
INSERT INTO zone VALUES ('sleeper','Sleepers Tomb',0,0,5);
INSERT INTO zone VALUES ('emeraldjungle','The Emerald Jungle',-1721,1274,5);
INSERT INTO zone VALUES ('everfrost','Everfrost',-1598,-167,5);
INSERT INTO zone VALUES ('gfaydark','Greater Faydark',1015,1046,5);
INSERT INTO zone VALUES ('greatdivide','Great Divide',0,0,5);
INSERT INTO zone VALUES ('kedge','Kedge Keep',-242,-231,5);
INSERT INTO zone VALUES ('kurn','Kurn\'s Tower',-114,264,5);
INSERT INTO zone VALUES ('kael','Kael Drakael',0,0,5);
INSERT INTO zone VALUES ('citymist','The City of Mist',-240,-473,5);
INSERT INTO zone VALUES ('chardok','Chardok',154,-352,5);
INSERT INTO zone VALUES ('hateplane','Plane of Hate',-372,-252,5);
INSERT INTO zone VALUES ('highkeep','High Keep',-56,-292,5);
INSERT INTO zone VALUES ('velketor','Velketor\'s Labrynth',0,0,5);
INSERT INTO zone VALUES ('nektulos','Nektulos Forest',-1108,2307,3.2);
INSERT INTO zone VALUES ('najena','Najena',254,173,5);

#
# Table structure for table 'zone_state_dump'
#

CREATE TABLE zone_state_dump (
  zonename varchar(16) NOT NULL default '',
  spawn2_count int(10) unsigned NOT NULL default '0',
  npc_count int(10) unsigned NOT NULL default '0',
  npcloot_count int(10) unsigned NOT NULL default '0',
  gmspawntype_count int(10) unsigned NOT NULL default '0',
  spawn2 mediumblob,
  npcs mediumblob,
  npc_loot mediumblob,
  gmspawntype mediumblob,
  time timestamp(14) NOT NULL,
  PRIMARY KEY  (zonename)
) TYPE=MyISAM;




