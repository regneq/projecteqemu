EQEMu 0.1.8 windows release
http://emu.hackersrealm.net/


Installation of MySQL DB:----------------------------------------
-----------------------------------------------------------------
1) Setup a MySQL Server
2) Execute "mysqladmin create eq"
3) In the EQEmu source directory type "mysql eq < db.sql" and press enter.
4) Setup db.ini with the proper information.
5) Open up dreadlands.bat and setup the bat file like shown:

	zone dreadlands 127.0.0.1 7999 127.0.0.1
        N/A   zonename   zoneip   port  worldip

6) Run world.exe in the main folder.
7) Default zone is set at dreadlands, so run dreadlands.bat
Read the bottom of the page if you wish to change the startzone.
-----------------------------------------------------------------
-----------------------------------------------------------------


Whats New:-------------------------------------------------------
-----------------------------------------------------------------
NPC corpse decay
#timeofday
+stats on items working
latent effects half working
Clickable items with proper cast time
looting fixed (for real =P)
Zone state saving (has to be enabled in variables)

The default account for testing is:------------------------------
-----------------------------------------------------------------
Username: eqemu
Password: eqemu
-----------------------------------------------------------------

Editable Items:--------------------------------------------------
-----------------------------------------------------------------

If you want to create an account with GM status, at the command line run:

world.exe adduser username password status

Status Listing: 0 = Normal, 1=PU, 2=GM, 3=Lead-GM, 4=ServerOP

-----------------------------------------------------------------

If you want to upgrade an account to GM status, at the command line run:

world.exe flag username status

Status Listing: 0 = Normal, 1=PU, 2=GM, 3=Lead-GM, 4=ServerOP

-----------------------------------------------------------------

If you want to change your start zone, at the command line run:

world.exe startzone dreadlands

Replacing dreadlands with the zone you want to run.

-----------------------------------------------------------------

If you want to change the MOTD, in MySQL type:

UPDATE variables SET value='test' WHERE varname='MOTD';

Replacing test with the MOTD you want.
-----------------------------------------------------------------

If you want to disable the worldserver command line, in MySQL type:

UPDATE variables SET value='1' WHERE varname='disablecommandline';

1 = disabled, 0 = enabled. (record not there = enabled)

"world clean" is always enabled
-----------------------------------------------------------------