#ifndef NPC_H
#define NPC_H

class NPC;
#include "../common/database.h"
#include "mob.h"
//#include "spawn.h"
#include "spawn2.h"
#include "hate_list.h"
#include "loottable.h"
#include "zonedump.h"

#ifdef BUILD_FOR_WINDOWS
	#define  M_PI	3.141592
#endif

//typedef LinkedList<Item_Struct*> ItemList;

class NPC : public Mob
{
public:
	NPC(NPCType* data, void* respawn, float x, float y, float z, float heading, bool isgroup, bool IsCorpse = false);
	virtual ~NPC();

	virtual bool IsNPC() { return true; }

	virtual bool Process();

	void	Attack(Mob* other);
	void	Damage(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);
	void	Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);
	void	SetDecayTimer(int32 decaytime);

	float	FaceTarget();
	void	RemoveFromHateList(Mob* mob);
	void	WhipeHateList() { hate_list.Whipe(); }

	void	AddItem(Item_Struct* item, int8 charges, uint8 slot);
	void	AddItem(int32 itemid, int8 charges, uint8 slot);
	void	AddLootTable();
	void	RemoveItem(uint16 item_id);
	void	ClearItemList();
	ServerLootItem_Struct*	GetItem(int slot_id);
	void	AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum);
	void	AddCash();
	void	RemoveCash();
	ItemList*	GetItemList() { return itemlist; }
	void	QueryLoot(Client* to);
	int32	CountLoot();
	void	DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex);
	int32	GetNPCTypeid() { return npc_id; }

	uint32	GetCopper()		{ return copper; }
	uint32	GetSilver()		{ return silver; }
	uint32	GetGold()		{ return gold; }
	uint32	GetPlatinum()	{ return platinum; }

	void	Depop(bool StartSpawnTimer = true);
protected:
	friend class EntityList;
	NPCType* NPCTypedata;
	HateList hate_list;
//	Spawn*	respawn;
	Spawn2*	respawn2;
	
	uint32	copper;
	uint32	silver;
	uint32	gold;
	uint32	platinum;
	ItemList*	itemlist;

	Timer*	movement_timer;
private:
	int32	loottable_id;
	bool	p_depop;
};

#endif

