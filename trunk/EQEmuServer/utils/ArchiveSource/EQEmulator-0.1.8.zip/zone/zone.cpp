#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include "spawngroup.h"
#include "spawn2.h"
#include "zone.h"
#include "worldserver.h"
#include "npc.h"
#include "net.h"
#include "../common/seperator.h"

extern Database database;
extern WorldServer* worldserver;
extern Zone* zone;

#ifdef BUILD_FOR_WINDOWS
	#define	 snprintf	_snprintf
	#define  vsnprintf	_vsnprintf
#endif

Zone::Zone(char* in_short_name, char* in_address, int16 in_port)
{
	short_name = strcpy(new char[strlen(in_short_name)+1], in_short_name);
	long_name = 0;
	address = strcpy(new char[strlen(in_address)+1], in_address);
	port = in_port;

	spawn_group_list = new SpawnGroupList();

	database.GetZoneLongName(short_name, &long_name);
//	database.PopulateZoneLists(short_name, npc_type_array, max_npc_type, spawn_list, zone_point_list, spawn2_list, spawn_group_list);
	database.PopulateZoneLists(short_name, &zone_point_list, spawn_group_list);
	char pzs[3] = "";
	if (database.GetVariable("PersistentZoneState", pzs, 2)) {
		if (pzs[0] == '1') {
			sint8 tmp = database.LoadZoneState(short_name, spawn2_list);
			if (tmp == 1) {
				cout << "Zone state loaded." << endl;
			}
			else if (tmp == -1) {
				cout << "Error loading zone state" << endl;
				ZoneShutdown();
			}
			else if (tmp == 0) {
				cout << "Zone state not found, loading from spawn lists." << endl;
				database.PopulateZoneSpawnList(short_name, spawn2_list);
			}
			else
				cout << "Unknown LoadZoneState return value" << endl;
		}
		else
			database.PopulateZoneSpawnList(short_name, spawn2_list);
	}
	else
		database.PopulateZoneSpawnList(short_name, spawn2_list);


	if (long_name == 0)
	{
		long_name = strcpy(new char[18], "Long zone missing");
	}
//	if (worldserver != 0)
//		worldserver->SetZone(this->GetShortName());
}

Zone::~Zone()
{
	database.UnregisterZoneServer(short_name, address, port);
	delete[] short_name;
	delete[] long_name;
	delete[] address;
	if (worldserver != 0)
		worldserver->SetZone("");
}

void Zone::Process()
{
//	LinkedListIterator<Spawn*> iterator(spawn_list);
	LinkedListIterator<Spawn2*> iterator2(spawn2_list);

/*	iterator.Reset();
	while (iterator.MoreElements())
	{
		iterator.GetData()->Process();
		iterator.Advance();
	}
*/

	iterator2.Reset();
	while (iterator2.MoreElements())
	{
		iterator2.GetData()->Process();
		iterator2.Advance();
	}
}

void Zone::Depop() {
	LinkedListIterator<Spawn2*> iterator(spawn2_list);

	iterator.Reset();
	while (iterator.MoreElements())
	{
		iterator.GetData()->Depop();
		iterator.Advance();
	}
	entity_list.Depop();
}

void Zone::Repop(int32 delay) {
	Depop();

	LinkedListIterator<Spawn2*> iterator(spawn2_list);

	iterator.Reset();
	while (iterator.MoreElements())
	{
		iterator.RemoveCurrent();
	}
	
	database.PopulateZoneSpawnList(short_name, spawn2_list, delay);
}

ZonePoint* Zone::GetClosestZonePoint(float x, float y, float z, char* to_name)
{
	LinkedListIterator<ZonePoint*> iterator(zone_point_list);
	ZonePoint* closest_zp = 0;
	float closest_dist = FLT_MAX;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		ZonePoint* zp = iterator.GetData();
		if (strcmp(zp->target_zone, to_name) == 0)
		{
			float dist = (zp->x-x)*(zp->x-x)+(zp->y-y)*(zp->y-y)+(zp->z-z)*(zp->z-z);
			if (dist < closest_dist)
			{
				closest_zp = zp;
				closest_dist = dist;	
			}
		}
		iterator.Advance();
	}
	return closest_zp;
}

//bool Database::PopulateZoneLists(char* zone_name, NPCType* &npc_type_array, uint32 &max_npc_type, LinkedList<Spawn*>& spawn_list, LinkedList<ZonePoint*>& zone_point_list, LinkedList<Spawn2*> &spawn2_list, SpawnGroupList* spawn_group_list)
//bool Database::PopulateZoneLists(char* zone_name, NPCType* &npc_type_array, uint32 &max_npc_type, LinkedList<ZonePoint*>& zone_point_list, SpawnGroupList* spawn_group_list)
bool Database::PopulateZoneLists(char* zone_name, LinkedList<ZonePoint*>* zone_point_list, SpawnGroupList* spawn_group_list)
{
	char *query = 0;
	int buf_len = 256;
	int chars = -1;
	MYSQL_RES *result;
	MYSQL_ROW row;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT x,y,z,target_x,target_y,target_z,target_zone FROM zone_points WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				ZonePoint* zp = new ZonePoint;
				zp->x = atof(row[0]);
				zp->y = atof(row[1]);
				zp->z = atof(row[2]);
				zp->target_x = atof(row[3]);
				zp->target_y = atof(row[4]);
				zp->target_z = atof(row[5]);
				strncpy(zp->target_zone, row[6], 16);
				zone_point_list->Insert(zp);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
/*
	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT npc_type,x,y,z,respawn FROM spawn WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				Spawn* sp = new Spawn(atoi(row[0]), atoi(row[1]), atoi(row[2]), atoi(row[3]), atoi(row[4])*1000);
				spawn_list.Insert(sp);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
*/
// CODER new spawn code
	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT DISTINCT(spawngroupID), spawngroup.name FROM spawn2,spawngroup WHERE spawn2.spawngroupID=spawngroup.ID and zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				SpawnGroup* newSpawnGroup = new SpawnGroup( atoi(row[0]), row[1]);
				spawn_group_list->AddSpawnGroup( newSpawnGroup );
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT spawnentry.spawngroupID, npcid, chance from spawnentry, spawn2 where spawnentry.spawngroupID=spawn2.spawngroupID and zone='%s' ORDER by chance", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				SpawnEntry* newSpawnEntry = new SpawnEntry( atoi(row[1]), atoi(row[2]));
				spawn_group_list->GetSpawnGroup(atoi(row[0]))->AddSpawnEntry(newSpawnEntry);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

// CODER end new spawn code

	return true;
}

bool Database::PopulateZoneSpawnList(char* zone_name, LinkedList<Spawn2*> &spawn2_list, int32 repopdelay) {
	char* query = 0;
	int buf_len = 256;
	int chars = -1;
	MYSQL_RES *result;
	MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id, spawngroupID, x, y, z,respawntime,variance FROM spawn2 WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				Spawn2* newSpawn = new Spawn2(atoi(row[0]), atoi(row[1]), atoi(row[2]), atoi(row[3]), atoi(row[4]), atoi(row[5]), atoi(row[6]));
				newSpawn->Repop(repopdelay);
				spawn2_list.Insert( newSpawn );
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

int32 Zone::CountSpawn2() {
	LinkedListIterator<Spawn2*> iterator(spawn2_list);
	int16 count = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		count++;
		iterator.Advance();
	}
	return count;
}

int32 Zone::DumpSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index, Spawn2* spawn2) {
	if (spawn2 == 0)
		return 0;
	LinkedListIterator<Spawn2*> iterator(spawn2_list);
	int32	index = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		if (iterator.GetData() == spawn2) {
			spawn2dump[*spawn2index].spawn2_id = iterator.GetData()->spawn2_id;
			spawn2dump[*spawn2index].time_left = iterator.GetData()->timer->GetRemainingTime();
			iterator.RemoveCurrent();
			return (*spawn2index)++;
		}
		iterator.Advance();
	}
	return 0xFFFFFFFF;
}

void Zone::DumpAllSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index) {
	LinkedListIterator<Spawn2*> iterator(spawn2_list);
	int32	index = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		spawn2dump[*spawn2index].spawn2_id = iterator.GetData()->spawn2_id;
		spawn2dump[*spawn2index].time_left = iterator.GetData()->timer->GetRemainingTime();
		(*spawn2index)++;
		iterator.RemoveCurrent();
	}
}

bool Database::DumpZoneState() {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0) {
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM zone_state_dump WHERE zonename='%s'", zone->GetShortName());
	}
	if (mysql_query(&mysql, query))	{
		cerr << "Error in DumpZoneState query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
	delete[] query;

	
	
	int32	spawn2_count = zone->CountSpawn2();
	int32	npc_count = 0;
	int32	npcloot_count = 0;
	int32	gmspawntype_count = 0;
	entity_list.CountNPC(&npc_count, &npcloot_count, &gmspawntype_count);

cout << "DEBUG: spawn2count=" << spawn2_count << ", npc_count=" << npc_count << ", npcloot_count=" << npcloot_count << ", gmspawntype_count=" << gmspawntype_count << endl;

	ZSDump_Spawn2* spawn2_dump = 0;
	ZSDump_NPC*	npc_dump = 0;
	ZSDump_NPC_Loot* npcloot_dump = 0;
	NPCType* gmspawntype_dump = 0;
	if (spawn2_count > 0) {
		spawn2_dump = new ZSDump_Spawn2[spawn2_count];
		memset(spawn2_dump, 0, sizeof(ZSDump_Spawn2) * spawn2_count);
	}
	if (npc_count > 0) {
		npc_dump = new ZSDump_NPC[npc_count];
		memset(npc_dump, 0, sizeof(ZSDump_NPC) * npc_count);
		for (int i=0; i < npc_count; i++) {
			npc_dump[i].spawn2_dump_index = 0xFFFFFFFF;
			npc_dump[i].gmspawntype_index = 0xFFFFFFFF;
		}
	}
	if (npcloot_count > 0) {
		npcloot_dump = new ZSDump_NPC_Loot[npcloot_count];
		memset(npcloot_dump, 0, sizeof(ZSDump_NPC_Loot) * npcloot_count);
		for (int k=0; k < npc_count; k++)
			npcloot_dump[k].npc_dump_index = 0xFFFFFFFF;
	}
	if (gmspawntype_count > 0) {
		gmspawntype_dump = new NPCType[gmspawntype_count];
		memset(gmspawntype_dump, 0, sizeof(NPCType) * gmspawntype_count);
	}

	entity_list.DoZoneDump(spawn2_dump, npc_dump, npcloot_dump, gmspawntype_dump);
    query = new char[512 + ((sizeof(ZSDump_Spawn2) * spawn2_count + sizeof(ZSDump_NPC) * npc_count + sizeof(ZSDump_NPC_Loot) * npcloot_count + sizeof(NPCType) * gmspawntype_count) * 2)];
	char* end = query;

    end += sprintf(end, "Insert Into zone_state_dump (zonename, spawn2_count, npc_count, npcloot_count, gmspawntype_count, spawn2, npcs, npc_loot, gmspawntype) values ('%s', %i, %i, %i, %i, ", zone->GetShortName(), spawn2_count, npc_count, npcloot_count, gmspawntype_count);
    *end++ = '\'';
	if (spawn2_dump != 0) {
	    end += mysql_real_escape_string(&mysql, end, (char*)spawn2_dump, sizeof(ZSDump_Spawn2) * spawn2_count);
		delete spawn2_dump;
	}
    *end++ = '\'';
    end += sprintf(end, ", ");
    *end++ = '\'';
	if (npc_dump != 0) {
	    end += mysql_real_escape_string(&mysql, end, (char*)npc_dump, sizeof(ZSDump_NPC) * npc_count);
		delete npc_dump;
	}
    *end++ = '\'';
    end += sprintf(end, ", ");
    *end++ = '\'';
	if (npcloot_dump != 0) {
	    end += mysql_real_escape_string(&mysql, end, (char*)npcloot_dump, sizeof(ZSDump_NPC_Loot) * npcloot_count);
		delete npcloot_dump;
	}
    *end++ = '\'';
    end += sprintf(end, ", ");
    *end++ = '\'';
	if (gmspawntype_dump != 0) {
	    end += mysql_real_escape_string(&mysql, end, (char*)gmspawntype_dump, sizeof(NPCType) * gmspawntype_count);
		delete gmspawntype_dump;
	}
    *end++ = '\'';
    end += sprintf(end, ")");

    if (mysql_real_query(&mysql, query, (unsigned int) (end - query))) {
		delete[] query;
        cerr << "Error in ZoneDump query " << mysql_error(&mysql) << endl;
		return false;
    }
	delete[] query;

	if (mysql_affected_rows(&mysql) == 0) {
		cerr << "Zone dump failed. (affected rows = 0)" << endl;
		return false;
	}
	return true;
}

sint8 Database::LoadZoneState(char* zonename, LinkedList<Spawn2*>& spawn2_list) {

    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT spawn2_count, npc_count, npcloot_count, gmspawntype_count, spawn2, npcs, npc_loot, gmspawntype, (UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time)) as elapsedtime FROM zone_state_dump WHERE zonename='%s'", zonename);
	}

	int32 i;
	unsigned long* lengths;
	int32	elapsedtime = 0;
	int32	spawn2_count = 0;
	int32	npc_count = 0;
	int32	npcloot_count = 0;
	int32	gmspawntype_count = 0;
	ZSDump_Spawn2* spawn2_dump = 0;
	ZSDump_NPC*	npc_dump = 0;
	ZSDump_NPC_Loot* npcloot_dump = 0;
	NPCType* gmspawntype_dump = 0;
	Spawn2** spawn2_loaded = 0;
	NPC** npc_loaded = 0;

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
cout << "Elapsed time: " << row[8] << endl;
				elapsedtime = atoi(row[8]) * 1000;
				lengths = mysql_fetch_lengths(result);
				spawn2_count = atoi(row[0]);
				if (lengths[4] == (sizeof(ZSDump_Spawn2) * spawn2_count)) {
					spawn2_dump = new ZSDump_Spawn2[spawn2_count];
					spawn2_loaded = new Spawn2*[spawn2_count];
					memcpy(spawn2_dump, row[4], lengths[4]);
					for (i=0; i < spawn2_count; i++) {
						if (spawn2_dump[i].time_left == 0xFFFFFFFF) // npc spawned, timer should be disabled
							spawn2_loaded[i] = database.LoadSpawn2(spawn2_list, spawn2_dump[i].spawn2_id, 0xFFFFFFFF);
						else if (spawn2_dump[i].time_left <= elapsedtime)
							spawn2_loaded[i] = database.LoadSpawn2(spawn2_list, spawn2_dump[i].spawn2_id, 0);
						else
							spawn2_loaded[i] = database.LoadSpawn2(spawn2_list, spawn2_dump[i].spawn2_id, spawn2_dump[i].time_left - elapsedtime);
						if (spawn2_loaded[i] == 0) {
							cerr << "Error in LoadZoneState: spawn2_loaded[" << i << "] == 0" << endl;
							mysql_free_result(result);
							return -1;
						}
					}
				}
				else {
					cerr << "Error in LoadZoneState: spawn2_dump length mismatch" << endl;
					mysql_free_result(result);
					return -1;
				}

				gmspawntype_count = atoi(row[3]);
				if (lengths[7] == (sizeof(NPCType) * gmspawntype_count)) {
					gmspawntype_dump = new NPCType[gmspawntype_count];
					memcpy(gmspawntype_dump, row[7], lengths[7]);
				}
				else {
					cerr << "Error in LoadZoneState: gmspawntype_dump length mismatch" << endl;
					delete spawn2_dump;
					delete spawn2_loaded;
					mysql_free_result(result);
					return -1;
				}

				npc_count = atoi(row[1]);
				if (lengths[5] == (sizeof(ZSDump_NPC) * npc_count)) {
					npc_dump = new ZSDump_NPC[npc_count];
					npc_loaded = new NPC*[npc_count];
					memcpy(npc_dump, row[5], lengths[5]);
					for (i=0; i < npc_count; i++) {
						npc_loaded[i] = 0;
						Spawn2* tmp = 0;
						if (!npc_dump[i].corpse && npc_dump[i].spawn2_dump_index != 0xFFFFFFFF) {
							tmp = spawn2_loaded[npc_dump[i].spawn2_dump_index];
						}
						if (npc_dump[i].npctype_id == 0) {
							if (npc_dump[i].gmspawntype_index == 0xFFFFFFFF) {
								cerr << "Error in LoadZoneState: gmspawntype index invalid" << endl;
								mysql_free_result(result);
								return -1;
							}
							else {
								npc_loaded[i] = new NPC(&gmspawntype_dump[npc_dump[i].gmspawntype_index], tmp, npc_dump[i].x, npc_dump[i].y, npc_dump[i].z, npc_dump[i].heading, (tmp != 0), npc_dump[i].corpse);
							}
						}
						else {
							NPCType* crap = database.GetNPCType(npc_dump[i].npctype_id);
							if (crap != 0)
								npc_loaded[i] = new NPC(crap, tmp, npc_dump[i].x, npc_dump[i].y, npc_dump[i].z, npc_dump[i].heading, (tmp != 0), npc_dump[i].corpse);
							else
								cerr << "Error in LoadZoneState: Unknown npctype_id: " << npc_dump[i].npctype_id << endl;
						}
						if (npc_loaded[i] != 0) {
							npc_loaded[i]->AddCash(npc_dump[i].copper, npc_dump[i].silver, npc_dump[i].gmspawntype_index, npc_dump[i].platinum);
							if (npc_dump[i].corpse) {
								if (npc_dump[i].decay_time_left <= elapsedtime)
									npc_loaded[i]->SetDecayTimer(0);
								else
									npc_loaded[i]->SetDecayTimer(npc_dump[i].decay_time_left - elapsedtime);
							}
							entity_list.AddNPC(npc_loaded[i]);
						}
					}
				}
				else {
					cerr << "Error in LoadZoneState: npc_dump length mismatch" << endl;
					delete spawn2_dump;
					delete spawn2_loaded;
					delete gmspawntype_dump;
					mysql_free_result(result);
					return -1;
				}

				npcloot_count = atoi(row[2]);
				if (lengths[6] == (sizeof(ZSDump_NPC_Loot) * npcloot_count)) {
					npcloot_dump = new ZSDump_NPC_Loot[npcloot_count];
					memcpy(npcloot_dump, row[6], lengths[6]);
					for (i=0; i < npcloot_count; i++) {
						if (npc_loaded[npcloot_dump[i].npc_dump_index] != 0)
							npc_loaded[npcloot_dump[i].npc_dump_index]->AddItem(npcloot_dump[i].itemid, npcloot_dump[i].charges, npcloot_dump[i].equipSlot);
					}
				}
				else {
					cerr << "Error in LoadZoneState: npcloot_dump length mismatch" << endl;
					mysql_free_result(result);
					delete spawn2_dump;
					delete spawn2_loaded;
					delete gmspawntype_dump;
					delete npc_dump;
					delete npc_loaded;
					return -1;
				}
				delete spawn2_dump;
				delete spawn2_loaded;
				delete gmspawntype_dump;
				delete npc_dump;
				delete npc_loaded;
				delete npcloot_dump;
			}
			else
			{
				mysql_free_result(result);
				return 0;
			}
		}
		else
		{
			mysql_free_result(result);
			return 0;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in LoadZoneState query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return -1;
	}

	return 1;
}

Spawn2* Database::LoadSpawn2(LinkedList<Spawn2*> &spawn2_list, int32 spawn2id, int32 timeleft) {
	char* query = 0;
	int buf_len = 256;
	int chars = -1;
	MYSQL_RES *result;
	MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id, spawngroupID, x, y, z,respawntime,variance FROM spawn2 WHERE id=%i", spawn2id);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				Spawn2* newSpawn = new Spawn2(atoi(row[0]), atoi(row[1]), atoi(row[2]), atoi(row[3]), atoi(row[4]), atoi(row[5]), atoi(row[6]), timeleft);
				spawn2_list.Insert( newSpawn );
				mysql_free_result(result);
				return newSpawn;
			}
		}
		mysql_free_result(result);
	}
	else
		delete[] query;

	cerr << "Error in LoadSpawn2 query '" << query << "' " << mysql_error(&mysql) << endl;
	return 0;
}

void Zone::SpawnStatus(Mob* client) {
	LinkedListIterator<Spawn2*> iterator(spawn2_list);

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		if (iterator.GetData()->timer->GetRemainingTime() == 0xFFFFFFFF)
			client->Message(0, "%d:  %d %d %d:  disabled", iterator.GetData()->GetID(), iterator.GetData()->GetX(), iterator.GetData()->GetY(), iterator.GetData()->GetZ());
		else
			client->Message(0, "%d:  %d, %d, %d:  %d", iterator.GetData()->GetID(), iterator.GetData()->GetX(), iterator.GetData()->GetY(), iterator.GetData()->GetZ(), iterator.GetData()->timer->GetRemainingTime());
		iterator.Advance();
	}
}

// Added By Hogie 
bool Database::GetDecayTimes(npcDecayTimes_Struct* npcCorpseDecayTimes) {
	char* query = 0;
	int buf_len = 256;
	int chars = -1;
	int i = 0;
	MYSQL_RES *result;
	MYSQL_ROW row;
	query = new char[buf_len];
	chars = snprintf(query, buf_len, "SELECT varname, value FROM variables WHERE varname like 'decaytime%' ORDER BY varname");

	if (!mysql_query(&mysql, query) && i < 10)
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				Seperator sep(row[0]);
				npcCorpseDecayTimes[i].minlvl = atoi(sep.arg[1]);
				npcCorpseDecayTimes[i].maxlvl = atoi(sep.arg[2]);
				if (atoi(row[1]) > 7200)
					npcCorpseDecayTimes[i].seconds = 720;
				else
					npcCorpseDecayTimes[i].seconds = atoi(row[1]);
				i++;
			}
			mysql_free_result(result);
		}
	}
	else {
		delete[] query;
		return false;
	}
	return true;
}
// Added By Hogie -- End

