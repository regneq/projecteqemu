#include <stdlib.h>
#include "spawn2.h"
#include "entity.h"
#include "npc.h"
#include "zone.h"
#include "spawngroup.h"
#include "../common/database.h"

extern EntityList entity_list;
extern Zone* zone;
extern Database database;


Spawn2::Spawn2(int32 in_spawn2_id, int32 spawngroup_id, sint16 x, sint16 y, sint16 z, int32 respawn, int32 variance, int32 timeleft)
{
	spawn2_id = in_spawn2_id;
	spawngroup_id_ = spawngroup_id;
	x_ = x;
	y_ = y;
	z_ = z;
    respawn_ = respawn;
	variance_ = variance;

	timer = new Timer( resetTimer() );
	if (timeleft == 0xFFFFFFFF)
		timer->Disable();
	else if (timeleft == 0)
		timer->Trigger();
	else
		timer->Start(timeleft);
}

Spawn2::~Spawn2()
{
	delete timer;
}

int32 Spawn2::resetTimer()
{
	int32 rspawn = respawn_ * 1000;

	if (variance_ != 0) {
		int32 vardir = (rand()%50);
		int32 variance = (rand()%variance_);
		float varper = variance*0.01;
		float varvalue = varper*(rspawn);
		if (vardir < 50)
		{
		  varvalue = varvalue * -1;
		}

		rspawn += (int32) varvalue;
	}

	return (rspawn);

}

void Spawn2::Process()
{
	if (timer->Check())
	{
		timer->Disable();

		int npcid = zone->spawn_group_list->GetSpawnGroup(spawngroup_id_)->GetNPCType();
		if (npcid > 0)
		{
			NPC* npc = new NPC(database.GetNPCType(npcid), this, x_, y_, z_, 0, true);
			npc->AddLootTable();
			entity_list.AddNPC(npc);
		}
		else
		{
			Reset();
		}
	}
}

void Spawn2::Reset()
{
	timer->Start(resetTimer());
}

void Spawn2::Depop() {
	timer->Disable();
}

void Spawn2::Repop(int32 delay) {
	if (delay == 0)
		timer->Trigger();
	else
		timer->Start(delay);
}

