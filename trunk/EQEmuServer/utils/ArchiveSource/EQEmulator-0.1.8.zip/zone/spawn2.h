#ifndef SPAWN2_H
#define SPAWN2_H

#include "../common/timer.h"
class Spawn2
{
public:
	Spawn2(int32 spawn2_id, int32 spawngroup_id, sint16 x, sint16 y, sint16 z, int32 respawn, int32 variance, int32 timeleft = 0);
	~Spawn2();

	void Enable();
	void Process();
	void Reset();

	void Depop();
	void Repop(int32 delay = 0);
	int32	GetID() { return spawn2_id; }
	sint16	GetX() { return x_; }
	sint16	GetY() { return y_; }
	sint16	GetZ() { return z_; }
protected:
	friend class Zone;
	int32 spawn2_id;
	Timer* timer;
private:
	int32 resetTimer();

	int32 spawngroup_id_;
	sint16 x_;
	sint16 y_;
	sint16 z_;
	int32 respawn_;
	int32 variance_;
};

#endif
