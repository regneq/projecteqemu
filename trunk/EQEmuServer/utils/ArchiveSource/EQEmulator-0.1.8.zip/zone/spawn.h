#ifndef SPAWN_H
#define SPAWN_H

#include "../common/timer.h"

class Spawn
{
public:
	Spawn(int npc_type, int x, int y, int z, int respawn);
	~Spawn();

	void Enable();
	void Process();
	void Reset();

private:
	int npc_type;
	int x;
	int y;
	int z;
	Timer* timer;
};

#endif
