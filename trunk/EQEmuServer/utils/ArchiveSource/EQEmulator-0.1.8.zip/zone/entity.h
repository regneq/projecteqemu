#ifndef ENTITY_H
#define ENTITY_H

#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/database.h"
#include "zonedump.h"

#ifdef WIN32
	class	APPLAYER;
#else
	struct	APPLAYER;
#endif

class Client;
class Mob;
class NPC;

void ProcessClientThreadSpawn(void *tmp);

class Entity
{
public:
	Entity();
	virtual ~Entity();

	virtual bool IsClient() { return false; }
	virtual bool IsNPC()    { return false; }
	virtual bool IsMob()    { return false; }

#ifdef WIN32
	virtual bool Process()  { return false; }
#else
	virtual bool Process()  {}
#endif

	Client* CastToClient();
	NPC*    CastToNPC();
	Mob*    CastToMob();

	void SetID(int16 set_id);
	int16 GetID();
	virtual char* GetName() { return ""; }
protected:
	int16 id;
};

class EntityList
{
public:
	EntityList() {}
	~EntityList() {}

	Entity* GetID(int16 id);
	Client* GetClientByName(char *name); 
	Client* GetClientByAccID(int32 accid);
	Client* GetClient(int32 ip, int16 port);

	void    AddClient(Client*);
	void    AddNPC(NPC*);
	void	Clear();

	int16   GetFreeID();

	void	Message(int32 to_guilddbid, int32 type, char* message, ...);
	void	MessageClose(Mob* sender, bool skipsender, float dist, int32 type, char* message, ...);
	void	ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...);
	void    ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...);
	void	ChannelMessageSend(Mob* to, int8 chan_num, int8 language, char* message, ...);
	void    SendZoneSpawns(Client*);
	void    Save();

	void    RemoveFromTargets(Mob* mob);

	void	QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender=false, float dist=200, Mob* SkipThisMob = 0);
	void    QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender=false);

	void	AESpell(Mob* caster, Mob* center, float dist, int16 spell_id);

	void	UpdateWho();

	void	CountNPC(int32* NPCCount, int32* NPCLootCount, int32* gmspawntype_count);
	void	DoZoneDump(ZSDump_Spawn2* spawn2dump, ZSDump_NPC* npcdump, ZSDump_NPC_Loot* npclootdump, NPCType* gmspawntype_dump);
	void    RemoveEntity(int16 id);

    void    Process();
protected:
	friend class Zone;
	void	Depop();
private:
	LinkedList<Entity*> list;
	int16 last_insert_id;
};

#endif

