#ifndef CLIENTLIST_H
#define CLIENTLIST_H

#ifndef WIN32
	#include <pthread.h>
#endif

#include "../common/types.h"
#include "../common/linked_list.h"
#include "client.h"

class ClientList;

class ClientList {
public:
	ClientList();
	~ClientList();
	void SendPacketQueues();
	void Add(Client* client);
	void Remove(Client* client);

	bool RecvData(int32 ip, int16 port, uchar* buffer, int len);
#ifdef WIN32
	CRITICAL_SECTION CSListLock;
#else
	pthread_mutex_t CSListLock;
#endif
private:
	void RemoveAll();
	LinkedList<Client*> list;
};

#endif
