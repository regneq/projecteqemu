#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
#include "worldserver.h"
//#include "../common/packet_dump_file.h"

extern WorldServer* worldserver;
extern GuildRanks_Struct guilds[512];

bool Client::Process()
{
	if (Connected())
	{
		if (auto_attack && target != 0 && attack_timer->Check())
		{
			if (DistNoRootNoZ(target) > 10*10)
			{
				Message(13,"Your target is too far away, get closer!");
			}
			else if (target == this)
			{
				Message(13,"Try attacking someone else then yourself!");
			}
/*			else if (CantSee(target))
			{
				Message(13,"You can't see your target from here.");				
			}*/
			else if (!IsNPC() && appearance == 3)
			{
			}
			else if (target->GetHP() > 0)
			{
				Attack(target);
			}
		}
		if (position_timer->Check())
		{
			SendPosUpdate();
		}
		if (spellend_timer->Check()) {
			spellend_timer->Disable();
			SpellFinished(casting_spell_id, casting_spell_targetid, casting_spell_slot, casting_spell_mana);
		}
		if (regen_timer->Check())
		{
			max_hp = GetMaxHP();
			if (GetHP() < max_hp) // TODO: Get regen/tick confirmed
			{
				if (appearance == 1) // If we are sitting
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+4);
						else if (GetLevel() < 50)
							SetHP(GetHP()+6);
						else
							SetHP(GetHP()+12);
					}
					else
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+2);
						else if (GetLevel() < 50)
							SetHP(GetHP()+3);
						else if (GetLevel() < 51)
							SetHP(GetHP()+4);
						else
							SetHP(GetHP()+5);
					}
				}
				else
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+1);
						else if (GetLevel() < 50)
							SetHP(GetHP()+2);
						else
							SetHP(GetHP()+4);
					}
					else
					{
						if (GetLevel() < 51)
							SetHP(GetHP()+1);
						else
							SetHP(GetHP()+2);
					}
				}
				if (GetHP() > max_hp)
					SetHP(max_hp);
				SendHPUpdate();
			}
		}
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(app = PMOutQueuePop())
	{
		switch(client_state)
		{
			case CLIENT_CONNECTING1:
			{
				if (app->opcode == 0xe821)
				{
					cout << "Login packet 1" << endl;
//					DumpPacket(app);
					client_state = CLIENT_CONNECTING2;
				}
				break;
			}
			case CLIENT_CONNECTING2: {
				if (app->opcode == OP_ZoneEntry)
				{
					cout << "Login packet 2" << endl;
//					DumpPacket(app);

					// Quagmire - Antighost code
					// tmp var is so the search doesnt find this object
					char tmp[16];
					strncpy(tmp, (char*)&app->pBuffer[4], 16);
					Client* client = entity_list.GetClientByName(tmp);
					strncpy(name, (char*)&app->pBuffer[4], 16);
					account_id = database.GetAuthentication(name, zone->GetShortName(), ip);
					if (account_id == 0)
					{
						cout << "Client dropped: GetAuthentication = 0, n=" << tmp << endl;
						return false; // TODO: Can we tell the client to get lost in a good way
					}
					if (client != 0)
						client->Kick();  // Bye Bye ghost

					admin = database.CheckStatus(account_id);
					database.GetAccountName(account_id, account_name);
					database.GetCharacterInfo(name, &character_id, &guilddbid, &guildrank);

					// Try to find the EQ ID for the guild, if doesnt exist, guild has been deleted.
					// Clear memory, but leave it in the DB (no reason not to, guild might be restored?)
					guildeqid = database.GetGuildEQID(guilddbid);
					if (guildeqid == 0xFFFFFFFF) {
						guilddbid = 0;
						guildrank = GUILD_MAX_RANK;
					}

					if (!database.GetPlayerProfile(account_id, name, &pp))
					{
						cout << "Client dropped: !GetPlayerProfile, name=" << name << endl;
						return false;
					}

					strcpy(lastname, pp.last_name); 
					x_pos = (sint16)(pp.x);
					y_pos = (sint16)(pp.y);
					z_pos = (sint16)(pp.z);
					heading = pp.heading;
					race = pp.race;
					class_ = pp.class_;
					gender = pp.gender;
					level = pp.level;
					CalcBonuses();
					SetHP(pp.cur_hp);
					max_hp = GetMaxHP();
					if (cur_hp > max_hp)
						cur_hp = max_hp;
					pp.inventory[0] = 0xffff; // Inventory

					SetEQChecksum((unsigned char*)&pp, sizeof(PlayerProfile_Struct));

					APPLAYER *outapp;
					outapp = new APPLAYER;				
					outapp->opcode = OP_PlayerProfile;		
					outapp->pBuffer = new uchar[5000];
					outapp->size = DeflatePacket((unsigned char*)&pp, sizeof(PlayerProfile_Struct), outapp->pBuffer, 5000);
					EncryptProfilePacket(outapp);
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_ZoneEntry;
					outapp->pBuffer = new uchar[sizeof(ServerZoneEntry_Struct)];
		   			outapp->size = sizeof(ServerZoneEntry_Struct);
					memset(outapp->pBuffer, 0, sizeof(ServerZoneEntry_Struct));
					ServerZoneEntry_Struct *sze = (ServerZoneEntry_Struct*)outapp->pBuffer;
					strcpy(sze->name, name);
					strcpy(sze->zone, zone->GetShortName());
					sze->class_ = pp.class_;
					sze->race = pp.race;
					sze->gender = pp.gender;
					sze->level = pp.level;
					sze->x = pp.x;
					sze->y = pp.y;
					sze->z = pp.z / 10;
					sze->sze_unknown3[0] = 0xf5;
					sze->sze_unknown3[1] = 0x81;
					sze->sze_unknown3[2] = pp.heading;//0x85;
					sze->sze_unknown3[3] = 0x43;
					sze->walk_speed = 0.46;
					sze->run_speed = 0.7;

					// Disgrace: proper face selection
					sze->face = GetFace();

					// Quagmire - added coder?'s code from messageboard
					if (pp.inventory[2] != 0xFFFF) {
						uint16 item_id = pp.inventory[2];
						Item_Struct* item = database.GetItem(item_id);

						sze->helmet = item->common.material;
						sze->helmcolor = item->common.color;
					}
					sze->npc_armor_graphic = 0xff;  // tell client to display PC's gear

					SetEQChecksum((unsigned char*)sze, sizeof(ServerZoneEntry_Struct));
					QueuePacket(outapp);
					delete outapp;


					int weather = 0;
					weather = database.CheckZoneWeather(zone->GetShortName());
					cerr << "Zone Weather for: " << zone->GetShortName() << " " << weather << endl;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Controls Rain
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = weather; // rain
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_TimeOfDay;
					outapp->pBuffer = new uchar[6];
					outapp->size = 6;
					outapp->pBuffer[0] = 0x00;
					outapp->pBuffer[1] = 0x00;
					outapp->pBuffer[2] = 0x00;
					outapp->pBuffer[3] = 0x00;
					outapp->pBuffer[4] = 0x00;
					outapp->pBuffer[5] = 0x00;
					QueuePacket(outapp);
					delete outapp;				

					SetAttackTimer();
					client_state = CLIENT_CONNECTING3;
				}
				break;
			}
			case CLIENT_CONNECTING3: {
				if (app->opcode == 0x5d20)
				{
					cout << "Login packet 3" << endl; // Here the client sends tha character name again.. 
                                                      // not sure why, nothing else in this packet
					client_state = CLIENT_CONNECTING4;
				}
				break;
			}
			case CLIENT_CONNECTING4: {
				if (app->opcode == 0x0a20)
				{
					cout << "Login packet 4" << endl; // This packet was empty...

					APPLAYER* outapp;
					outapp = new APPLAYER;
					outapp->opcode =  OP_NewZone;
					outapp->pBuffer = new uchar[sizeof(NewZone_Struct)];
		   			outapp->size = sizeof(NewZone_Struct);
					memset(outapp->pBuffer, 0, sizeof(ServerZoneEntry_Struct));
					NewZone_Struct *nz = (NewZone_Struct*)outapp->pBuffer;
					strcpy(nz->zone_short_name, zone->GetShortName());
					strcpy(nz->zone_long_name, zone->GetLongName());

					int16 somedata3[71] = {
					0x00c8,
					0xc8c8, 0xc8c8, 0xc8c8, 0xc8d2, 0xd2d2, 0xd200, 0x0000, 0x2041,
					0x0000, 0x2041, 0x0000, 0x2041, 0x0000, 0x2041, 0x0000, 0xe143,
					0x0000, 0xe143, 0x0000, 0xe143, 0x0000, 0xe143, 0xcdcc, 0xcc3e,
					0x0232, 0x3232, 0x3218, 0x1818, 0x1800, 0x0000, 0x0000, 0x0000,
					0x00ff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff,
					0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff,
					0xff00, 0x0100, 0x0400, 0x0100, 0x0000, 0x0000, 0x0000, 0x403f,
					0x0000, 0x2041, 0x0000, 0x0000, 0x0000, 0xa040, 0x0000, 0xc842,
					0x0000, 0xa0c3, 0x0000, 0xe143, 0x0000, 0xe143};
					int16* temp3 = (int16*)nz->nz_unknown2;
					for (int i=0;i<71;i++)
					{
						*temp3 = ntohs(somedata3[i]); temp3++;
					}

					QueuePacket(outapp);
					delete outapp;				

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
			   		outapp->size = 0;
					QueuePacket(outapp);
					delete outapp;

					client_state = CLIENT_CONNECTING5;
				}
				break;
			}
			case CLIENT_CONNECTING5:
			{
				if (app->opcode == 0xd820)
				{
					APPLAYER* outapp;

					outapp = new APPLAYER;
					outapp->opcode = 0xc321; // Unknown
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_SpawnAppearance; 
					outapp->pBuffer = new uchar[12];
					memset(outapp->pBuffer, 0, 12);
					SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
					sa->type = 0x10;                       // Is 0x10 used to set the player id?
					sa->parameter = id;                    // Four bytes for this parameter...
		   			outapp->size = 12;
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
		   			outapp->size = 0;
					QueuePacket(outapp);
					delete outapp;

					// Inform the client about the world
					entity_list.SendZoneSpawns(this);
					
					// Inform the world about the client
					outapp = new APPLAYER;
					CreateSpawnPacket(outapp);
					entity_list.QueueClients(this, outapp, true);
					delete outapp;

					// We are now fully connected and ready to play					
					client_state = CLIENT_CONNECTED;

					outapp = new APPLAYER;
					outapp->opcode = OP_Stamina; 
		   			outapp->size = sizeof(Stamina_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					Stamina_Struct* sta = (Stamina_Struct*)outapp->pBuffer;
					sta->food = 127;
					sta->water = 125;
					sta->fatigue = 0;
					QueuePacket(outapp);
					delete outapp;

					// Quagmire - Setting Guildtag
					// Cant figure out where in pp is it, so will cheat
					if (guilddbid == 0) {
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 22;
						appearance->parameter = 0xFFFFFFFF;
						QueuePacket(outapp);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 23;
						appearance->parameter = 3;
						QueuePacket(outapp);
						delete outapp;
					}
					else {
						APPLAYER* outapp;
						SpawnAppearance2_Struct* appearance;
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 22;
						appearance->parameter = guildeqid;
						QueuePacket(outapp);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 23;
						if (guilds[guildeqid].rank[guildrank].warpeace || guilds[guildeqid].leader == account_id)
							appearance->parameter = 2;
						else if (guilds[guildeqid].rank[guildrank].invite || guilds[guildeqid].rank[guildrank].remove || guilds[guildeqid].rank[guildrank].motd)
							appearance->parameter = 1;
						else
							appearance->parameter = 0;
						QueuePacket(outapp);
						delete outapp;
					}

					// Quagmire - Setting GM flag
					if (admin >= 2) {
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 20;
						appearance->parameter = 1;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;
					}

					for (int i=0;i<sizeof(pp.inventory); i++) {
						uint16 item_id = pp.inventory[i];
						Item_Struct* item = database.GetItem(item_id);
						if (item) {
							item->equipSlot = i;                                        
//							cout << "Sending inventory slot:" << i << endl;

							APPLAYER* app = new APPLAYER;
							app->opcode = 0x3120;
							app->size = sizeof(Item_Struct);
							app->pBuffer = new uchar[app->size];
							memcpy(app->pBuffer, item, sizeof(Item_Struct));
							QueuePacket(app);
							delete app;
                                   
							item->equipSlot = 0;
						}
					}

					// Coder_01's container code
					for (int j=0;j<sizeof(pp.containerinv); j++) {
						uint16 item_id = pp.containerinv[j];
						Item_Struct* item = database.GetItem(item_id);
						if (item) {
							item->equipSlot = 250+j;                                        
//							cout << "Sending inventory slot:" << 250+j << endl;

							APPLAYER* app = new APPLAYER;
							app->opcode = 0x3120;
							app->size = sizeof(Item_Struct);
							app->pBuffer = new uchar[app->size];
							memcpy(app->pBuffer, item, sizeof(Item_Struct));
							QueuePacket(app);
							delete app;

							item->equipSlot = 0;
						}
					}

					UpdateWho(false);
				}
				break;
			}
			case CLIENT_CONNECTED:
			{
				switch(app->opcode)
				{
					case 0:
						break;
					case OP_AutoAttack:
					{
						if (app->size == 4)
						{
							if (app->pBuffer[0] == 0)
								auto_attack = false;
							else if (app->pBuffer[0] == 1)
								auto_attack = true;
						}
						else
						{
							cerr << "Wrong size " << app->size << " on OP_AutoAttack, should be 4" << endl; 
						}
						break;
					}
					case OP_ClientUpdate:
					{
						SpawnPositionUpdate_Struct* cu=(SpawnPositionUpdate_Struct*)app->pBuffer;
						if (app->size == sizeof(SpawnPositionUpdate_Struct))
						{
//							DumpPacketHex(app);
							appearance = cu->anim_type;
							x_pos = cu->x_pos;
							y_pos = cu->y_pos;
							z_pos = cu->z_pos;
							delta_x = cu->delta_x/125;
							delta_y = cu->delta_y/125;
							delta_z = cu->delta_z;
							heading = cu->heading;
							delta_heading = cu->delta_heading;
/*
							cout << "X:"  << x_pos << " ";
							cout << "Y:"  << y_pos << " ";
							cout << "Z:"  << z_pos << " ";
							cout << "dX:" << delta_x << " ";
							cout << "dY:" << delta_y << " ";
							cout << "dZ:" << delta_z << " ";
							cout << "H:"  << (int)heading << " ";
							cout << "dH:" << (int)delta_heading << " ";
							cout << "Heading hex 0x" << hex << (int)heading << dec;
							cout << endl;
*/
							SendPosUpdate(); // TODO: Move this outside this case
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(SpawnPositionUpdate_Struct) << " on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_ClientTarget:
					{
						ClientTarget_Struct* ct=(ClientTarget_Struct*)app->pBuffer;	
						if (app->size == sizeof(ClientTarget_Struct))
						{
							Entity* entity = entity_list.GetID(ct->new_target);
							if (entity != 0 && entity->IsMob())
							{
								target = entity->CastToMob();
							}
							else
							{	
								target = 0;
							}
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ClientTarget_Struct) << " on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_Jump:
					{
						cout << name << " jumped." << endl;
						break; 
					}
					case OP_Consider:
					{
						// TODO: Let client consider things that are not targeted
						if (target != 0)
						{
							APPLAYER* outapp = new APPLAYER;
							outapp->opcode = OP_Consider;
							outapp->size = sizeof(Consider_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							Consider_Struct* con = (Consider_Struct*)outapp->pBuffer;
							con->playerid = id;
							con->unknown1[0] = 0;
							con->unknown1[1] = 0;
							con->targetid = target->GetID();
							con->unknown2[0] = 0;
							con->unknown2[1] = 0;
							con->faction = GetFactionLevel(character_id,target->GetNpcId(), race, class_, DEITY_AGNOSTIC); // rembrant, Dec. 20, 2001; TODO: Send the players proper deity
							con->level = target->GetLevel();
							con->cur_hp = target->GetHP(); // rembrant, Dec. 20, 2001
							con->max_hp = target->GetMaxHP(); // rembrant, Dec. 20, 2001
							QueuePacket(outapp);
							delete outapp;
						}
						break;
					}
					case OP_Surname:
					{
						Surname_Struct surname;

						memcpy(&surname, app->pBuffer, sizeof(Surname_Struct));
						/* I don't know why the following works, but it does */
						surname.s_unknown1 = 0;
						surname.s_unknown2 = 1;
						surname.s_unknown3 = 1;
						surname.s_unknown4 = 1;
						memcpy(app->pBuffer, &surname, sizeof(Surname_Struct));
						
						strcpy(lastname, surname.lastname);
						strcpy(pp.last_name, surname.lastname);

						QueuePacket(app);
						cout << surname.name << " changed surname to " << surname.lastname << endl;
						break;
					}
					case OP_YellForHelp: // Pyro
					{
						cout << name << " yells for help." << endl;
						// TODO: write a msg send routine
						break;
					}
					case OP_SafePoint: // Pyro
					{
						cout << name << " moved to safe point." << endl;
						// This is handled clientside
						break;
					}
					case OP_SpawnAppearance:
					{
						SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
						if (sa->type == 0x0e)
						{
							if (sa->parameter == 0x64)
							{
								cout << "Client " << name << " standing" << endl;
								appearance = 0;
							}
							else if (sa->parameter == 0x6e)
							{
								cout << "Client " << name << " sitting" << endl;
								appearance = 1;
								InterruptSpell();
							}
							else if (sa->parameter == 0x6f)
							{
								cout << "Client " << name << " ducking" << endl;
								appearance = 2;
								InterruptSpell();
							}
							else if (sa->parameter == 0x73)
							{
								cout << "Client " << name << " unconscious" << endl;
								appearance = 3;
								InterruptSpell();
							}
							else
							{
								cerr << "Client " << name << " unknown apperance " << (int)sa->parameter << endl;
								break;
							}
							APPLAYER* outapp = new APPLAYER;;
							outapp->opcode = OP_SpawnAppearance;
							outapp->size = sizeof(SpawnAppearance_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
							sa_out->spawn_id = id;
							sa_out->sa_unknown1 = 0;
							sa_out->type = 0x0e;
							sa_out->sa_unknown2 = 0;
							sa_out->parameter = sa->parameter;
							entity_list.QueueClients(this, app, true);
							delete outapp;
						}
						break;
					}
					case OP_Death:
					{
//						packet_manager.Close();
//						QueuePacket(0);

						// TODO: Make real bind coords
						zonesummon_x = -3;
						zonesummon_y = -3;
						zonesummon_z = -3;
						break;
					}
					case 0x2921:
					{
						break;
					}
					case OP_MoveItem: 
					{
						MoveItem_Struct* mi = (MoveItem_Struct*)app->pBuffer; 
						if (mi->to_slot != 0xffffffff) 
						{
							uint16* to_slot;
							uint16* from_slot;
							uint16 itemmoved;
							uint16 itemreplaced;

							if (mi->to_slot < 30)
								to_slot = &(pp.inventory[mi->to_slot]);
							else if (mi->to_slot > 249)
								to_slot=&(pp.containerinv[mi->to_slot-250]);

							if (mi->from_slot < 30)
								from_slot = &(pp.inventory[mi->from_slot]);
							else if (mi->from_slot > 249)
								from_slot=&(pp.containerinv[mi->from_slot-250]);

								itemmoved = *from_slot;
								itemreplaced = *to_slot;

								*to_slot = itemmoved;
								*from_slot = itemreplaced;

								cout << "Moved " << itemmoved << " from: " << mi->from_slot << " to: " << mi->to_slot << endl;
								if ((mi->from_slot >= 1 && mi->from_slot <= 21) || (mi->to_slot >= 1 && mi->to_slot <= 21))
									this->CalcBonuses(); // Update item/spell bonuses
								if (mi->from_slot == 13 || mi->to_slot == 13) {
									SetAttackTimer();
								}
							}
						else
						{
							pp.inventory[mi->from_slot] = 0xffff;
							cout << "Set slot: " << mi->from_slot << " to: 0xffff" << endl;
						}
						break; 
					} 
					case OP_Camp:
					{
						// TODO: Implement camp, LD and all that
						// camp_timer->Start(30000);
						break;
					}
					case OP_Mend:
					{
						sint32 mendhp = (int32) ((float)GetMaxHP() * .75);
						SetHP(GetHP() + mendhp);
						SendHPUpdate();
						Message(4, "You mend your wounds and heal some damage");
						break;
					}
					case OP_Forage:
					{
						// TODO: Implement forage
						ChannelMessageSend(0,0,7,0,"Forage not implemented");
						break;
					}
					case OP_Sneak:
					{
						// TODO: Implement sneak
						ChannelMessageSend(0,0,7,0,"Sneak not implemented");
						break;
					}
					case OP_Hide:
					{
						// TODO: Implement hide
						ChannelMessageSend(0,0,7,0,"Hide not implemented");
						break;
					}
					case OP_ChannelMessage:
					{
						ChannelMessage_Struct* cm=(ChannelMessage_Struct*)app->pBuffer;
						if (app->size > sizeof(ChannelMessage_Struct))
						{
							ChannelMessageReceived(cm->chan_num, cm->language, &cm->message[0], &cm->targetname[0]);
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ChannelMessage_Struct) << "+ on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_WearChange:
					{
						//DumpPacketHex(app);
						WearChange_Struct* wc=(WearChange_Struct*)app->pBuffer;
						if (app->size == sizeof(WearChange_Struct)) {
						}
						else {
							cout << "Wrong size " << app->size << ", should be " << sizeof(WearChange_Struct) << " on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_ZoneChange:
					{
						ZoneChange_Struct* zc=(ZoneChange_Struct*)app->pBuffer;
						if (app->size == sizeof(ZoneChange_Struct))
						{
							float tarx = 0, tary = 0, tarz = 0;
							char tarzone[16] = "";
							cout << "Zone request for:" << zc->char_name << " to:" << zc->zone_name << endl;
//							if (strcmp(zc->zone_name, zone->GetShortName()) == 0)
//								break;
					
							// this both loads the safe points and does a sanity check on zone name
							if (database.GetSafePoints(zc->zone_name, &tarx, &tary, &tarz))
								strcpy(tarzone, zc->zone_name);

							cout << "Player at x:" << x_pos << " y:" << y_pos << " z:" << z_pos << endl;
							ZonePoint* zone_point = zone_point = zone->GetClosestZonePoint(x_pos, y_pos, z_pos, zc->zone_name);

							// -1, -1, -1 = code for zone safe point
							if (zonesummon_x == -1 && zonesummon_y == -1 && (zonesummon_z == -1 || zonesummon_z == -10)) {
								cout << "Zoning to safe coords: " << tarzone << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
								zonesummon_x = -2;
								zonesummon_y = -2;
								zonesummon_z = -2;
							} // -3 -3 -3 = bind point, zone safe point for now
							else if (zonesummon_x == -3 && zonesummon_y == -3 && (zonesummon_z == -3 || zonesummon_z == -30)) {
								strcpy(tarzone, zone->GetShortName());
								if (!database.GetSafePoints(tarzone, &tarx, &tary, &tarz)) {
									tarx=0;
									tary=0;
									tarz=10;
								}
								cout << "Zoning: Death, zoning to safe point: " << tarzone << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
								zonesummon_x = -2;
								zonesummon_y = -2;
								zonesummon_z = -2;
							} // if not -2 -2 -2, zone to these coords
							else if (!(zonesummon_x == -2 && zonesummon_y == -2 && (zonesummon_z == -2 || zonesummon_z == -20))) {
								tarx = zonesummon_x;
								tary = zonesummon_y;
								tarz = zonesummon_z;
								cout << "Zoning to specified cords: " << tarzone << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
								zonesummon_x = -2;
								zonesummon_y = -2;
								zonesummon_z = -2;
							}
							else if (zone_point != 0) {
								cout << "Zone point found at x:" << zone_point->x << " y:" << zone_point->y << " z:" << zone_point->z << endl;
								tarx = zone_point->target_x;
								tary = zone_point->target_y;
								tarz = zone_point->target_z;
							}
							else
								tarzone[0] = 0;
							
								
							APPLAYER* outapp;
							if (tarzone[0] != 0 && database.GetZoneServer(tarzone))
							{
								cout << "Zone target:" << tarzone << " x:" << tarx << " y:" << tary << " z:" << tarz << endl;

								outapp = new APPLAYER;
								outapp->opcode = 0xdb20;
								outapp->size = 0;
								QueuePacket(outapp);
								delete outapp;
								
								outapp = new APPLAYER;
								outapp->opcode = 0x1020;
								outapp->size = 0;
								QueuePacket(outapp);					
								delete outapp;
								
								outapp = new APPLAYER;
								outapp->opcode = OP_ZoneChange;
								outapp->pBuffer = new uchar[sizeof(ZoneChange_Struct)];
								outapp->size = sizeof(ZoneChange_Struct);
								memset(outapp->pBuffer, 0, sizeof(ZoneChange_Struct));
								ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
								strcpy(zc2->char_name, zc->char_name);
								strcpy(zc2->zone_name, tarzone);
								//								memcpy(zc2->zc_unknown1, zc->zc_unknown1, sizeof(zc->zc_unknown1));
								
								zc2->zc_unknown1[0] = 0x10;
								zc2->zc_unknown1[1] = 0x00; 
								zc2->zc_unknown1[2] = 0x00;
								zc2->zc_unknown1[3] = 0x00;
								zc2->zc_unknown1[4] = 0x04;
								zc2->zc_unknown1[5] = 0xb5; 
								zc2->zc_unknown1[6] = 0x01;
								zc2->zc_unknown1[7] = 0x02; 
								zc2->zc_unknown1[8] = 0x43; 
								zc2->zc_unknown1[9] = 0x58; 
								zc2->zc_unknown1[10] = 0x4f;
								zc2->zc_unknown1[11] = 0x00; 
								zc2->zc_unknown1[12] = 0xb0; 
								zc2->zc_unknown1[13] = 0xa5; 
								zc2->zc_unknown1[14] = 0xc7; 
								zc2->zc_unknown1[15] = 0x0d; 
								zc2->zc_unknown1[16] = 0x01;
								zc2->zc_unknown1[17] = 0x00;
								zc2->zc_unknown1[18] = 0x00;
								zc2->zc_unknown1[19] = 0x00;


								// The client seems to dump this profile on us, but I ignore it for now. Saving is client initiated?
								x_pos = (sint16)tarx; // Hmm, these coordinates will now be saved when ~client is called
								y_pos = (sint16)tary;
								z_pos = (sint16)tarz;
								strcpy(pp.current_zone, tarzone);
								Save();

								database.SetAuthentication(account_id, zc->char_name, tarzone, ip); // We have to tell the world server somehow?
								QueuePacket(outapp);
								delete outapp;
							}
							else
							{
								cerr << "Zone '" << zc->zone_name << "' is not available" << endl;

								outapp = new APPLAYER;
								outapp->opcode = 0xdb20;
					   			outapp->size = 0;
								QueuePacket(outapp);
								delete outapp;

								outapp = new APPLAYER;
								outapp->opcode = 0x1020;
					   			outapp->size = 0;
								QueuePacket(outapp);					
								delete outapp;

								outapp = new APPLAYER;
								outapp->opcode = OP_ZoneChange;
								outapp->pBuffer = new uchar[sizeof(ZoneChange_Struct)];
				   				outapp->size = sizeof(ZoneChange_Struct);
								memset(outapp->pBuffer, 0, sizeof(ZoneChange_Struct));
								ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
								strcpy(zc2->char_name, zc->char_name);
								strcpy(zc2->zone_name, zc->zone_name);
								QueuePacket(outapp);
								delete outapp;
							}
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ZoneChange_Struct) << " on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_DeleteSpawn:
					{
						// The client will send this with his id when he zones, maybe when he disconnects too?
						// When zoning he seems to want 5921 and finish flag
						cout << "Player attempting to delete spawn..." << endl;
						APPLAYER* outapp;
						outapp = new APPLAYER;
						outapp->opcode = 0x5921;
	   					outapp->size = 0;
						QueuePacket(outapp);
						delete outapp;

						packet_manager.Close();
						QueuePacket(0); // Make a closing packet

						break;
					}
					case 0x5521: // Client dumps player profile on zoning, is this same opcode as saving?
					{
						cout << "Got a player profile" << endl;
//FileDumpPacket("playerprofile.txt", app);
						break;
					}
					case OP_Save:
					{
						cout << "Got a player save request" << endl;
//FileDumpPacket("playerprofile.txt", app);
						Save();
						break;
					}
					case OP_AutoAttack2: // Why 2
					{
						break;
					}
					case OP_WhoAll: // Pyro
					{
						WhoAll();
						break;
					}
					case OP_GMZoneRequest: // Quagmire
					{
//cout << "DEBUG: OP_GMZoneRequest" << endl;
//DumpPacket(app);
						GMZoneRequest_Struct* gmzr = (GMZoneRequest_Struct*) app->pBuffer;
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_GMZoneRequest;
						outapp->size = sizeof(GMZoneRequest_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						memset(outapp->pBuffer, 0, outapp->size);
						GMZoneRequest_Struct* gmzr2 = (GMZoneRequest_Struct*) outapp->pBuffer;
						strcpy(gmzr2->charname, this->GetName());
						strcpy(gmzr2->zonename, gmzr->zonename);
						gmzr2->success = 1;
						int8 tmp[32] = { 0xe8, 0xf0, 0x58, 0x00, 0x70, 0xef, 0xad, 0x0e, 0x74, 0xf3, 0xad, 0x0e, 0xc7, 0x01, 0x4c, 0x00,
										 0x00, 0xa0, 0x04, 0xc5, 0x00, 0x20, 0x5f, 0xc5, 0x00, 0x00, 0xba, 0xc2, 0x00, 0x00, 0x00, 0x00 };
						memcpy(gmzr2->unknown1, tmp, 32);
						QueuePacket(outapp);
						delete outapp;
						break;
					}
					case OP_GMZoneRequest2: {
						this->MovePC((char*) app->pBuffer, -1, -1, -1);
						break;
					}
					case OP_GMFlagged: // Pyro - tired of spam
					{
						break;
					}

					case OP_EndLootRequest:
					{
						cout << "got end loot request" << endl;


						Entity* entity = entity_list.GetID((int16)*app->pBuffer);
						if (entity == 0)
						{
							cout << "trying to delete an invalid corpse" << endl;
							break;
						}
						
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_LootComplete;
						outapp->size = 0;
						QueuePacket(outapp);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_DeleteSpawn;
						outapp->size = sizeof(DeleteSpawn_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						DeleteSpawn_Struct* delspawn = (DeleteSpawn_Struct*)outapp->pBuffer;
						delspawn->spawn_id = entity->GetID();
						delspawn->ds_unknown1 = 0;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;
						
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* sa_out = (SpawnAppearance2_Struct*)outapp->pBuffer;
						sa_out->spawn_id = id;
						sa_out->type = 0x0e;
						sa_out->parameter = 110; // stand...
						entity_list.QueueClients(this, app);
						delete outapp;

						entity_list.RemoveEntity(entity->GetID());
						break;
					}
					case OP_LootRequest:
					{
//cout << "Lootrequest" << endl;
//DumpPacket(app);
//FilePrintLine("lootingdebug.txt", true, "Incomming OP_LootRequest");
//FileDumpPacket("lootingdebug.txt", app);
						NPC* npc = (entity_list.GetID((int16)*app->pBuffer))->CastToNPC();
						if (npc != 0)
						{
//FilePrintLine("lootingdebug.txt",  false, "npc->name = %s", npc->GetName());
						
							if (npc->BeingLootedBy != 0) {
								// lets double check....
								Entity* looter = entity_list.GetID(npc->BeingLootedBy);
								if (looter == 0)
									npc->BeingLootedBy = 0;
							}
							if (npc->BeingLootedBy != 0) {
								// ok, now we tell the client to fuck off
								// Quagmire - i think this is the right packet, going by pyro's logs
								APPLAYER outapp;
								outapp.opcode = OP_MoneyOnCorpse;
								outapp.size = sizeof(moneyOnCorpseStruct);
								outapp.pBuffer = new uchar[outapp.size];
								memset(outapp.pBuffer, 0, outapp.size);
								moneyOnCorpseStruct* d = (moneyOnCorpseStruct*)outapp.pBuffer;
								d->response		= 0;
								d->unknown1		= 0x5a;
								d->unknown3		= 0x40;
								d->unknown1 = 0x40;
								cout << "Telling " << this->GetName() << " corpse '" << npc->GetName() << "' is busy..." << endl;
//FilePrintLine("lootingdebug.txt", true, "Outgoing OP_MoneyOnCorpse - NACK");
//FileDumpPacket("lootingdebug.txt", &outapp);
								QueuePacket(&outapp); 
							}
							else {
								APPLAYER outapp;
								outapp.opcode = OP_MoneyOnCorpse;
								outapp.size = sizeof(moneyOnCorpseStruct);
								outapp.pBuffer = new uchar[outapp.size];
								memset(outapp.pBuffer, 0, outapp.size);
								moneyOnCorpseStruct* d = (moneyOnCorpseStruct*)outapp.pBuffer;
								
								d->response		= 1;
								d->unknown1		= 0x5a;
								d->unknown3		= 0x40;
								d->copper		= npc->GetCopper();
								d->silver		= npc->GetSilver();
								d->gold			= npc->GetGold();
								d->platinum		= npc->GetPlatinum();

								cout << "sending MoneyOnCorpse" << endl;
//FilePrintLine("lootingdebug.txt", true, "Outgoing OP_MoneyOnCorpse - OK");
//FileDumpPacket("lootingdebug.txt", &outapp);
								QueuePacket(&outapp); 
								cout << "removing cash from NPC" << endl;
								npc->RemoveCash();
							
								cout << "getting item list" << endl;
								ItemList* itemlist = npc->GetItemList();
								LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
								iterator.Reset();
								int counter = 0;
								cout << "looping through npc items" << endl;
								while(iterator.MoreElements())
								{
									ServerLootItem_Struct* item_data = iterator.GetData();
									
									Item_Struct* item = database.GetItem(item_data->item_nr);
									//Disgrace: debug
									char buff[500];
									sprintf(buff, "adding loot item: %s to [npc %s itemnum %d]", item->name, npc->GetName(), item->item_nr);
									cout << buff << endl;
									
									cout << "adding item to npc slot: " << counter << endl;
									item_data->equipSlot = counter;
									APPLAYER* outapp2 = new APPLAYER;
									outapp2->opcode = OP_ItemOnCorpse;
									outapp2->size = sizeof(ItemOnCorpse_Struct);
									outapp2->pBuffer = new uchar[outapp2->size];
									memcpy(outapp2->pBuffer, item, sizeof(Item_Struct));
									// modify the copy of the item
									item = (Item_Struct*)outapp2->pBuffer;
									item->equipSlot = item_data->equipSlot;
									if (item->flag != 0x7669)
										item->common.charges = item_data->charges;
									cout << "sending OP_ItemOnCorpse" << endl;
//FilePrintLine("lootingdebug.txt", true, "Outgoing OP_ItemOnCorpse");
//FileDumpPacket("lootingdebug.txt", outapp2);
									QueuePacket(outapp2);
									counter++;
									delete outapp2;

									cout << "next item" << endl;
									iterator.Advance();
								}
							}

						}
						else
						{
							cout << "npc == 0 LOOTING FOOKED" << endl;
							APPLAYER* outapp2 = new APPLAYER;
							outapp2->opcode = OP_ItemOnCorpse;
							outapp2->size = 0;
//FilePrintLine("lootingdebug.txt", true, "Outgoing OP_ItemOnCorpse - LOOTING FOOKED");
//FileDumpPacket("lootingdebug.txt", outapp2);
							QueuePacket(outapp2);
							delete outapp2;
						}
						
						// Disgrace: Client seems to require that we send the packet back...
						cout << "sending client echo packet of lootrequest" << endl;
//FilePrintLine("lootingdebug.txt", true, "Outgoing OP_LootRequest - Echo");
//FileDumpPacket("lootingdebug.txt", app);
						QueuePacket(app);
						break;
					}
					case OP_LootItem:
					{	
						/*
						** Disgrace: 
						**	fixed the looting code so that it sends the correct opcodes
						**	and now correctly removes the looted item the player selected
						**	as well as gives the player the proper item.
						**	Also fixed a few UI lock ups that would occur.
						*/
						cout << "looting item" << endl;
	
						Entity* entity = entity_list.GetID((int16)*app->pBuffer);
						if (entity == 0)
							cout << "invalid mob selected" << endl;

						NPC* npc = entity->CastToNPC();
						if (npc != 0)
						{
							LootingItem_Struct* lootitem = (LootingItem_Struct*)app->pBuffer;
							cout << "lootitem data" << endl;
							DumpPacket(app);
							cout << "item slot being looted: " << lootitem->slot_id << endl;
							ServerLootItem_Struct* item_data = npc->GetItem(lootitem->slot_id);
							Item_Struct* item = database.GetItem(item_data->item_nr);
							if (item!=0)
							{
								cout << "sending OP_ItemTradeIn" << endl;
								
								/*
								** Disgrace: 
								**	Find open slot in players inventory. Currently does not
								**	check to see if the item can be equipped. (next version)
								*/
								item_data->equipSlot = 0xFF;
								for (int i=22; i<31; i++)
								{
									if (pp.inventory[i] == 0xFFFF)
									{
										item_data->equipSlot = i;
										break;
									}
								}

								if (item_data->equipSlot == 0xFF)
								{
									Message(14,"There is no room in your inventory. The item has been dropped on the ground.");
								}
								else
								{
									// Disgrace: Let the client know what they looted. 
									// Not sure if im using the right channel here...
									Message(14,"You have looted a %s", item->name);

									cout << "adding item to inventory" << endl;
									pp.inventory[item_data->equipSlot] = item->item_nr;
									APPLAYER* newapp = new APPLAYER;
									newapp->opcode = OP_ItemTradeIn;
									newapp->size = sizeof(Item_Struct);
									newapp->pBuffer = new uchar[newapp->size];
									memcpy(newapp->pBuffer, item, sizeof(Item_Struct));
									// modify the copy of the item
									item = (Item_Struct*)newapp->pBuffer;
									item->equipSlot = item_data->equipSlot;
									if (item->flag != 0x7669)
										item->common.charges = item_data->charges;
									QueuePacket(newapp);
									delete newapp;

									cout << "removing item from npc " << endl;
									npc->RemoveItem(item_data->item_nr);
								}
							}
						}

						// Disgrace: Client seems to require that we send the packet back...
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = app->opcode;
						outapp->size = app->size;
						outapp->pBuffer = new uchar[app->size];
						memcpy(outapp->pBuffer, app->pBuffer, app->size);
						QueuePacket(outapp);
						delete outapp;

						break;
					}							
					case OP_GuildMOTD:
					{
//						app->pBuffer[0] = name of me
//						app->pBuffer[36] = new motd
						char tmp[255];
						if (guilddbid == 0) {
// client calls for a motd on login even if they arent in a guild
//							Message(0, "Error: You arent in a guild!");
						}
						else if (guilds[guildeqid].rank[guildrank].motd && !(strlen((char*) &app->pBuffer[36]) == 0)) {
							if (strcasecmp((char*) &app->pBuffer[36+strlen((char*) &app->pBuffer[0])], " - none") == 0)
								strcpy(tmp, "");
							else
								strncpy(tmp, (char*) &app->pBuffer[36], sizeof(tmp)); // client includes the "name - "

							if (!database.SetGuildMOTD(guilddbid, tmp)) {
								Message(0, "Motd update failed.");
							}
							worldserver->SendEmoteMessage(0, guilddbid, MT_Guild, "Guild MOTD: %s", tmp);
						}
						else {
							database.GetGuildMOTD(guilddbid, tmp);
							if (strlen(tmp) != 0)
								Message(14, "Guild MOTD: %s", tmp);
						}
						break;
					}
					case OP_GuildPeace:
					case OP_GuildWar:
					{
						Message(0, "Guildwars arent implemented. Stupid idea anyways. =P");
						break;
					}
					case OP_GuildLeader:
					{
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!(guilds[guildeqid].leader == account_id))
							Message(0, "Error: You arent the guild leader!");
						else if (worldserver == 0)
							Message(0, "Error: World server disconnected");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildLeader;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, (char*) app->pBuffer);
							worldserver->SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildInvite:
					{
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!guilds[guildeqid].rank[guildrank].invite)
							Message(0, "You dont have permission to invite.");
						else if (worldserver == 0)
							Message(0, "Error: World server disconnected");
						else {
							GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildInvite;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, gc->othername);
							worldserver->SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildRemove:
					{
						GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!(guilds[guildeqid].rank[guildrank].remove || strcasecmp(gc->othername, this->GetName()) == 0))
							Message(0, "You dont have permission to remove.");
						else if (worldserver == 0)
							Message(0, "Error: World server disconnected");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildRemove;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, gc->othername);
							worldserver->SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildInviteAccept:
					{
						GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
						if (gc->guildeqid == 0) {
							int32 tmpeq = database.GetGuildEQID(this->PendingGuildInvite);
							if (guilddbid != 0)
								Message(0, "Error: You're already in a guild!");
							else if (worldserver == 0)
								Message(0, "Error: World server disconnected");
							else if (this->PendingGuildInvite == 0)
								Message(0, "Error: No guild invite pending.");
							else {
								this->PendingGuildInvite = 0;
								if (this->SetGuild(guilds[tmpeq].databaseID, GUILD_MAX_RANK))
									worldserver->SendEmoteMessage(0, guilds[tmpeq].databaseID, MT_Guild, "%s has joined the guild. Rank: %s.", this->GetName(), guilds[tmpeq].rank[GUILD_MAX_RANK].rankname);
								else {
									worldserver->SendEmoteMessage(gc->othername, 0, 0, "Guild invite accepted, but failed.");
									Message(0, "Guild invite accepted, but failed.");
								}
							}
						}
						else if (gc->guildeqid == 4) {
							this->PendingGuildInvite = 0;
							worldserver->SendEmoteMessage(gc->othername, 0, 0, "%s's guild invite window timed out.", this->GetName());
						}
						else if (gc->guildeqid == 5) {
							this->PendingGuildInvite = 0;
							worldserver->SendEmoteMessage(gc->othername, 0, 0, "%s has declined to join the guild.", this->GetName());
						}
						else {
							this->PendingGuildInvite = 0;
							worldserver->SendEmoteMessage(gc->othername, 0, 0, "Unknown response from %s to guild invite.", this->GetName());
						}
						break;
					}
					case OP_MemorizeSpell: 
					{
						MemorizeSpell_Struct memspell; 
						MoveItem_Struct spellmoveitem; 

						memcpy(&memspell, app->pBuffer, sizeof(MemorizeSpell_Struct)); 

						packet_manager.MakeEQPacket(app); 
						DumpPacketHex(app); 

						if (memspell.scribing == 0) 
						{ 
							pp.spell_book[memspell.slot] = memspell.spell_id; 
							APPLAYER* outapp = new APPLAYER; 
							outapp->opcode = OP_MoveItem; 
							outapp->size = sizeof(MoveItem_Struct); 
							outapp->pBuffer = new uchar[outapp->size]; 
							spellmoveitem.from_slot = 0; 
							spellmoveitem.to_slot = 0xffffffff; 
							spellmoveitem.number_in_stack = 0; 
							memcpy(outapp->pBuffer, &spellmoveitem, sizeof(MoveItem_Struct)); 
							packet_manager.MakeEQPacket(outapp); 
							delete outapp; 
						} 
						else if (memspell.scribing == 1) 
						{ 
							pp.spell_memory[memspell.slot] = memspell.spell_id; 
						} 
						else if (memspell.scribing == 2) 
						{ 
							pp.spell_memory[memspell.slot] = 0xffff; 
						} 

						break; 
					}
					case OP_SwapSpell: 
					{
						SwapSpell_Struct swapspell; 
						short swapspelltemp; 

						memcpy(&swapspell, app->pBuffer, sizeof(SwapSpell_Struct)); 

						swapspelltemp = pp.spell_book[swapspell.from_slot]; 
						pp.spell_book[swapspell.from_slot] = pp.spell_book[swapspell.to_slot]; 
						pp.spell_book[swapspell.to_slot] = swapspelltemp; 

						packet_manager.MakeEQPacket(app); 

						break; 
					}
					case OP_CastSpell:
					{
						if (app->size != sizeof(CastSpell_Struct)) {
							cout << "Wrong size: OP_CastSpell, size=" << app->size << ", expected " << sizeof(CastSpell_Struct) << endl;
							break;
						}
						CastSpell_Struct* castspell = (CastSpell_Struct*)app->pBuffer;
//DumpPacketHex(app);
						cout << "Client casting #" << castspell->spell_id << ", slot=" << castspell->slot << ", invslot=0x" << hex << castspell->inventoryslot << dec << endl;
						if (castspell->slot == 10) { // this means right-click
							if (castspell->inventoryslot < 30) { // santity check
								Item_Struct* item = database.GetItem(pp.inventory[castspell->inventoryslot]);
								if (item == 0) {
									Message(0, "Error: item==0 for inventory slot #%i", castspell->inventoryslot);
								}
								else if (item->common.effecttype == 1 || item->common.effecttype == 3 || item->common.effecttype == 4 || item->common.effecttype == 5) {
									if (item->common.casttime == 0)
										SpellFinished(item->common.spellId, castspell->target_id, castspell->slot, 0);
									else
										CastSpell(item->common.spellId, castspell->target_id, castspell->slot, item->common.casttime);
								}
								else {
									Message(0, "Error: unknown item->common.effecttype (0x%02x)", item->common.effecttype);
								}
							}
							else
								Message(0, "Error: castspell->inventoryslot >= 30 (0x%04x)", castspell->inventoryslot);
						}
						else {
							CastSpell(castspell->spell_id, castspell->target_id, castspell->slot);
						}
						break;
					}
					case OP_MonkAtk:
					{
						Monk_Attack_Struct* matk = (Monk_Attack_Struct*) app->pBuffer;
						if (target != 0)
							MonkSpecialAttack(target, matk->m_type);
						break;
					}
					case OP_InstillDoubt:
					{
//						Fear Spell not yet implemented
						Instill_Doubt_Struct* iatk = (Instill_Doubt_Struct*) app->pBuffer;
						if (iatk->i_atk == 0x2E) {
							Message(4, "You\'re not scaring anyone.");
						}
						break;
					}
					case OP_GMSummon: {
						if (admin >= 2) {
							GMSummon_Struct* gms = (GMSummon_Struct*) app->pBuffer;
							Client* client = entity_list.GetClientByName(gms->charname);
							if (client != 0) {
								client->Message(15, "You have been summoned by the gods!");
								this->Message(0, "Local: Summoning %s to %i, %i, %i", gms->charname, gms->x, gms->y, gms->z + 1);
								client->MovePC(0, gms->x, gms->y, gms->z + 1);
							}
							else if (worldserver == 0)
								Message(0, "Error: World server disconnected");
							else {
								ServerPacket* pack = new ServerPacket;
								pack->opcode = ServerOP_ZonePlayer;
								pack->size = sizeof(ServerZonePlayer_Struct);
								pack->pBuffer = new uchar[pack->size];
								ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
								strcpy(szp->adminname, gms->gmname);
								strcpy(szp->name, gms->charname);
								strcpy(szp->zone, gms->zonename);
								szp->x_pos = gms->x;
								szp->y_pos = gms->y;
								szp->z_pos = gms->z;
								worldserver->SendPacket(pack);
								delete pack;
							}
						}
						else
							Message(0, "You're not a GM, wtf you think you're doing?");
						break;
					}
					case OP_Petition:
					{
						if (worldserver == 0)
							Message(0, "Error: World server disconnected");
						else
							worldserver->SendChannelMessage(this->GetName(), 0, 10, 0, 0, (char*) app->pBuffer);
						break;
					}
					case OP_GMNameChange: {
						DumpPacket(app);
						break;
					}
					case OP_GMKill: {
						DumpPacket(app);
						break;
					}
					case OP_GMLastName: {
						DumpPacket(app);
						break;
					}
					default:
					{
						cout << "Unkown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
						cout << " size:" << app->size << endl;
//						DumpPacket(app->pBuffer, app->size);
						break;
					}
				}
				break;
			}
			case CLIENT_KICKED:
			case DISCONNECTED:
				break;
			default:
			{
				cerr << "Unknown client_state:" << (int16) client_state << endl;
				break; 
			}
		}
		delete app;
	}    

	if (client_state == CLIENT_KICKED) {
		packet_manager.Close();
		QueuePacket(0);
	}

	if (client_state == DISCONNECTED) {
		cout << "Client disconnected (cs=d): " << GetName() << endl;
		return false;
	}

    if (timeout_timer->Check())
    {
		cout << "Client timeout" << endl;
		return false;
    }

	return true;
}

void Client::SetAttackTimer() {
	// Quagmire - image's attack timer code
	Item_Struct* item = database.GetItem(pp.inventory[13]);
	if (item == 0)
		attack_timer->Start(2000);
	else if (item->common.skill > 4)
		attack_timer->Disable();
	else
		attack_timer->Start(item->common.delay*100);
}
