#include "../common/servertalk.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"

#include "../common/eq_packet_structs.h"
#include "mob.h"

const int PORT = 9000;
#ifdef BUILD_FOR_WINDOWS
	void WorldServerLoop(void *tmp);
	void ClientInitWorldServer(void *tmp);
	void AutoInitWorldServer(void *tmp);
#else
	void *WorldServerLoop(void *tmp);
	void *ClientInitWorldServer(void *tmp);
	void *AutoInitWorldServer(void *tmp);
#endif
bool InitWorldServer(bool DoTimer = false);

class WorldServer {
public:
	WorldServer(int32 ip, int16 port, int in_send_socket);
    ~WorldServer();

	bool Process();
	bool ReceiveData();
	void SendPacket(ServerPacket* pack);
	void SendChannelMessage(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...);
	void SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...);
	void SetZone(char* zone);
	void SetPort();

	int32 GetIP()    { return ip; }
	int16 GetPort()    { return port; }


private:
	int32 ip;
	int16 port;

	int send_socket;

	MyQueue<ServerPacket> ServerOutQueue;
	MyQueue<SPackSendQueue> ServerSendQueue;

	Timer* timeout_timer;
};
