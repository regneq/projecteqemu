#include "mob.h"
#include "../common/eq_packet_structs.h"

void EncryptSpawnPacket(APPLAYER* app);

void Mob::CreateSpawnPacket(APPLAYER *app)
{
	app->opcode = OP_NewSpawn;
	app->pBuffer = new uchar[sizeof(NewSpawn_Struct)];
	app->size = sizeof(NewSpawn_Struct);

memset(app->pBuffer, 0, sizeof(NewSpawn_Struct));
	NewSpawn_Struct* ns = (NewSpawn_Struct*)app->pBuffer;

	ns->spawn.heading = heading;
	ns->spawn.x_pos = x_pos;
	ns->spawn.y_pos = y_pos;
	ns->spawn.z_pos = z_pos;
	ns->spawn.spawn_id = id;
	ns->spawn.max_hp = 0x64;
	ns->spawn.cur_hp = 0xffff; //Guild Id now?
	ns->spawn.race = race;
	if (IsClient())
	{
		ns->spawn.NPC = 0;
		ns->spawn.not_linkdead = 1;
		if (corpse)
			ns->spawn.NPC = 3;
	}
	else if (IsNPC())
	{
		ns->spawn.NPC = 1;
		if (corpse)
			ns->spawn.NPC = 2;
	}
	ns->spawn.class_ = class_;
	ns->spawn.gender = gender;
	ns->spawn.level = level;
	ns->spawn.anim_type = 0x64;
	ns->spawn.light = light;

//memset(ns->spawn.s_unknown5, 10, 9);
	ns->spawn.s_unknown5[3] = 0x10;//01;
	ns->spawn.s_unknown5[7] = 0xff;

	for(int i=0; i<9; i++)
		ns->spawn.equipment[i] = equipment[i];
	strcpy(ns->spawn.name, name);
	ns->spawn.lastname[0] = 0;
	ns->spawn.deity = deity;
/*
ns->spawn.s_unknown7[2] = 0xff;
ns->spawn.s_unknown9[0] = 0xff;
ns->spawn.s_unknown9[1] = 0xff;
ns->spawn.s_unknown9[2] = 0xff;
ns->spawn.s_unknown9[3] = 0xff;
ns->spawn.s_unknown9[4] = 0xff;
ns->spawn.s_unknown9[5] = 0x05;
ns->spawn.s_unknown9[6] = 0x2b;
ns->spawn.s_unknown9[7] = 0x03;
*/


// Testing uknowns
//	for (int i=0;i<49;i++)
//		ns->spawn.s_unknown1[i] = 0xff;
/*
	ns->spawn.s_unknown2[0] = 0xff;
	ns->spawn.s_unknown3[0] = 0xff;
	ns->spawn.s_unknown3[1] = 0xff;

	ns->spawn.s_unknown4[0] = 0xff;
	ns->spawn.s_unknown4[1] = 0xff;

	for (int i=0;i<49;i++)
		ns->spawn.s_unknown5[i] = 0xff;
	ns->spawn.s_unknown6[0] = 0xff;
	ns->spawn.s_unknown6[1] = 0xff;
	ns->spawn.s_unknown7[0] = 0xff;
	ns->spawn.s_unknown7[1] = 0xff;
	ns->spawn.s_unknown7[2] = 0xff;
*/

//	SetEQChecksum((unsigned char*)app->pBuffer, app->size); no, doesnt seem to need a checksum
//	DumpPacketHex(app);
	EncryptSpawnPacket(app);
}