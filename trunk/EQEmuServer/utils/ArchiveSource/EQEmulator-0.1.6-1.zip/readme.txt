EQEMu 0.1.6.1 windows release
http://emu.hackersrealm.net/


Installation of MySQL DB:----------------------------------------
-----------------------------------------------------------------
1) Setup a MySQL Server
2) Execute "mysqladmin create eq"
3) In the EQEmu source directory type "mysql eq < db.sql" and press enter.
4) Setup db.ini with the proper information.
5) Open up dreadlands.bat and setup the bat file like shown:

	zone dreadlands 127.0.0.1 7999 127.0.0.1
        N/A   zonename   zoneip   port  worldip

6) Run world.exe in the main folder.
7) Default zone is set at dreadlands, so run dreadlands.bat
Read the bottom of the page if you wish to change the startzone.
-----------------------------------------------------------------
-----------------------------------------------------------------


Whats New:-------------------------------------------------------
-----------------------------------------------------------------
#zone and #summon working
multi-threaded the zoneserver, should work better with higher numbers of users now
guilds finished
spawn tables
faction tables
item drop tables
#showloot - shows what a npc will drop when killed
#flag - sets GM flag
sanity checks on a few commands
basic spellcasting (all spells = complete heal atm)
worldserver accepts commands, run "world help" for more info
worn items will now show up on you and on char select (still not for others)

The default account for testing is:------------------------------
-----------------------------------------------------------------
Username: eqemu
Password: eqemu
-----------------------------------------------------------------
-----------------------------------------------------------------


Editable Items:--------------------------------------------------
-----------------------------------------------------------------

If you want to create a account with GM status, in MySQL type:

INSERT INTO ACCOUNT SET NAME='username', password='userpassword', status='status';

Status Listing: 0 = Normal, 1 = GM, 2 = Lead GM

-----------------------------------------------------------------

If you want to change your start zone in MySQL type:

UPDATE variables SET value='dreadlands' WHERE varname='startzone';

Replacing dreadlands with the zone you want to run.

-----------------------------------------------------------------

If you want to change the MOTD, in MySQL type:

UPDATE variables SET value='test' WHERE varname='MOTD';

Replacing test with the MOTD you want.
-----------------------------------------------------------------

If you want to disable the worldserver command line, in MySQL type:

UPDATE variables SET value='1' WHERE varname='disablecommandline';

1 = disabled, 0 = enabled. (record not there = enabled)

"world clean" is always enabled
-----------------------------------------------------------------