#ifndef BUILD_FOR_WINDOWS
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <netdb.h>
	#include <unistd.h>
	#include <errno.h>
	#include <fcntl.h>
#else
	#include <errno.h>
	#include <fcntl.h>
	#include <windows.h>
	#include <winsock.h>
#endif


const int PORT = 9000;

class NetConnection
{
public:
	bool Init();
	void ListenNewClients();

private:
	int listening_socket;
};
