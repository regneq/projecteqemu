#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>

// Disgrace: for windows compile
#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
#endif

// Disgrace: for windows compile
#ifndef BUILD_FOR_WINDOWS
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];

Client::Client(int32 in_ip, int16 in_port, int in_send_socket)
{
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;

	timeout_timer = new Timer(CLIENT_TIMEOUT);
	
	account_id = 0;

	packet_manager.SetDebugLevel(1);
	strcpy(zone_name, ZONE_NAME); // TODO: Starting zone should not be hardcoded
	char_name[0] = 0;
}

Client::~Client()
{
}

void Client::ReceiveData(uchar* buf, int len)
{
	timeout_timer->Start();
	packet_manager.ParceEQPacket(len, buf);
}

void Client::SendCharInfo()
{
	APPLAYER *outapp;
	outapp = new APPLAYER;
	outapp->opcode = OP_SendCharInfo;
	outapp->pBuffer = new uchar[1120];//1112];
	outapp->size	= 1120;//1112;

	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(account_id, cs_struct);

	packet_manager.MakeEQPacket(outapp);
	delete outapp;
}

bool Client::Process()
{
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(app = packet_manager.OutQueue.pop())
	{
		switch(app->opcode)
		{
		case 0:
		break;
		case OP_SendLoginInfo:
		{
//		DumpPacket(app->pBuffer,app->size);

			char name[16] = "";
			char password[16] = "";

			strncpy(name, (char*)app->pBuffer, 16);
			if (app->size < strlen(name)+2)
				return false;
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 16);
			
			account_id = database.CheckLogin(name,password);
			if (account_id == 0)
			{
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Wrong username/password" << endl;
				return false;
			}

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0x0710;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			outapp = new APPLAYER;
			outapp->opcode = 0x0180;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			packet_manager.MakeEQPacket(outapp);

			delete outapp;
			
cout << "Sending list of guilds" << endl;
			// Quagmire - tring to send list of guilds
			outapp = new APPLAYER;
			outapp->opcode = OP_GuildsList;
			outapp->size = sizeof(GuildsList_Struct);
		   	outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

			for (int i=0; i < 512; i++) {
				gl->Guilds[i].guildID = 0xFFFFFFFF;
				gl->Guilds[i].unknown1[0] = 0xFF;
				gl->Guilds[i].unknown1[1] = 0xFF;
				gl->Guilds[i].unknown1[2] = 0xFF;
				gl->Guilds[i].unknown1[3] = 0xFF;
				gl->Guilds[i].exists = 0;
				gl->Guilds[i].unknown3[0] = 0xFF;
				gl->Guilds[i].unknown3[1] = 0xFF;
				gl->Guilds[i].unknown3[2] = 0xFF;
				gl->Guilds[i].unknown3[3] = 0xFF;
				if (guilds[i].databaseID != 0) {
					gl->Guilds[i].guildID = i;
					strcpy(gl->Guilds[i].name, guilds[i].name);
					gl->Guilds[i].exists = 1;
				}
			}
			
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			// We are logging in and want to see character select
			SendCharInfo();
		    break;
		}
		case 0x8B20: //Name approval
		{
			if (account_id == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				return false;
			}
		    char name[16];
		    strncpy(name,(char*)app->pBuffer,16);
		    uchar race = app->pBuffer[32];
		    uchar clas = app->pBuffer[36];

		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0x8B20;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.ReserveName(account_id, name))
		   	{
				outapp->pBuffer[0] = 1;
			}
			else
			{
				outapp->pBuffer[0] = 0;
			}
			packet_manager.MakeEQPacket(outapp);
			delete outapp;
		    break;			
		}
		case 0x4920: //Char create
		{
			if (account_id == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				return false;
			}
			// TODO: Sanity check in data

		    char name[16];
		    strncpy(name,(char*)app->pBuffer,16);

			int16 gender = app->pBuffer[50];
			int16 race = app->pBuffer[52];
			int16 class_ = app->pBuffer[54];
			int8 face = app->pBuffer[68];
			int8 str = app->pBuffer[119];
			int8 sta = app->pBuffer[120];
			int8 cha = app->pBuffer[121];
			int8 dex = app->pBuffer[122];
			int8 int_ = app->pBuffer[123];
			int8 agi = app->pBuffer[124];
			int8 wis = app->pBuffer[125]; // TODO: Find out where deity,face and starting location is located

			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			{
				// TODO Can we tell the client this failed?
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp;
				outapp = new APPLAYER;
				outapp->opcode = 0x8B20;
		   		outapp->pBuffer = new uchar[1];
		   		outapp->size = 1;
				outapp->pBuffer[0] = 0;
				packet_manager.MakeEQPacket(outapp);
				delete outapp;
				return false;
			}

			cout << "Char create:" << name << endl;
/*
			cout << "str" << (int)str << " ";
			cout << "sta" << (int)sta << " ";
			cout << "agi" << (int)agi << " ";
			cout << "dex" << (int)dex << " ";
			cout << "wis" << (int)wis << " ";
			cout << "int" << (int)int_ << " ";
			cout << "cha" << (int)cha << " ";
			cout << "gender" << gender << " ";
			cout << "race" << race << " ";
			cout << "class" << class_ << endl;
*/
			SendCharInfo();

		    break;
		}
		case 0x180: // Enter world
		{
			if (account_id == 0)
			{
				cerr << "Enter world with no logged in account" << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}
			char name[16];
            strncpy(name,(char*)app->pBuffer,16);

			// If we are zoning make sure character name matches
/*			if (strlen(char_name) > 0 && strcmp(char_name, name) != 0)
			{
				cerr << "Character names doesnt match" << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}
*/
			// Make sure this account owns this character
			if (database.GetAccountID(name) != account_id)
			{
				cerr << "This account does not own this character" << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}

			PlayerProfile_Struct pp;
			if (!database.GetPlayerProfile(account_id, name, &pp))
			{
				cerr << "Could not get PlayerProfile for " << name << endl;
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				break;
			}
			strcpy(zone_name, pp.current_zone);

			cout << "Enter world: " << name << ": " << zone_name << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0xdd21; // This is message of the day?
			char tmp[500];
			if (database.GetVariable("MOTD", tmp, 500)) {
				outapp->size = strlen(tmp)+1;
				outapp->pBuffer = new uchar[outapp->size];
				strcpy((char*)outapp->pBuffer, tmp);
			} else {
				outapp->size = 59;
				outapp->pBuffer = new uchar[59];
				strcpy((char*)outapp->pBuffer, "Welcome to EQ Emu(tm)! v0.1.5");
			}
			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			int16 zone_port;
			char zone_address[255];
			
			if(!database.GetZoneServer(zone_name, zone_address, &zone_port))
			{
				packet_manager.Close();
				packet_manager.MakeEQPacket(0);
				return false;
			}
			 //if (strncasecmp(name,"local",5)==0) {
				//strcpy(name,"192.168.0.23");
			 //} 
			database.SetAuthentication(account_id, name, zone_name, ip);

			outapp = new APPLAYER;
			outapp->opcode = OP_ZoneServerInfo;//0x0480;
		   	outapp->pBuffer = new uchar[130];
			outapp->size = 130;
			strcpy((char*) outapp->pBuffer,     zone_address);
			strcpy((char*)&outapp->pBuffer[75], zone_name);
			int16 *temp = (int16*)&outapp->pBuffer[128];
			*temp = ntohs(zone_port);

			packet_manager.MakeEQPacket(outapp);
			delete outapp;

			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
			SendCharInfo();
			return false;
			}
			SendCharInfo();
			break;
		}
		case 0x3521:
		case 0x3921:
			cout << Timer::GetCurrentTime() << " Unkown opcode:" << (int)app->opcode;
			cout << " size:" << app->size << endl;
			break;		
		default:
		{
			cout << Timer::GetCurrentTime() << " Unkown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app->pBuffer, app->size);
			break;
		}
		}

		delete app;
	}    
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
	while(p = packet_manager.SendQueue.pop())
	{
		// Disgrace: for windows compile
		#ifndef BUILD_FOR_WINDOWS
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, (const char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif
		

		delete[] p;
	}
	/************ Processing finished ************/

	// Agz: Had to move this to the end of the function instead
	if (!packet_manager.CheckActive())
	{
		cout << "Client disconnected" << endl;
		return false;
	}
    if (timeout_timer->Check())
    {
		cout << "Client timeout" << endl;
		return false;
    }
	packet_manager.CheckTimers();

	return true;
}

void ClientList::Add(Client* client)
{
	list.Insert(client);
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

void ClientList::Process()
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << ntohs((int16)(iterator.GetData()->GetPort())) << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}
