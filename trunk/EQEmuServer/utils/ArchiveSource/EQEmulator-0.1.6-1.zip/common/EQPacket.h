// EQPacket.h: interface for the CEQPacket class.
//
//////////////////////////////////////////////////////////////////////

#ifndef EQPACKET_H
#define EQPACKET_H

#include <string.h>

#include "types.h"
#include "eq_opcodes.h"

/************ DEFINES ************/           // Agz: Added 2 to max_header_size, out of memory when first packet was a fragment packet
#define MAX_HEADER_SIZE 18
#define ACK_ONLY_SIZE   6
#define ACK_ONLY    0x400

/************ PACKETS ************/
struct EQPACKET_HDR_INFO
{
    int8    
        a0_Unknown  :   1,
        a1_ARQ      :   1,
        a2_Closing  :   1,
        a3_Fragment :   1,
        a4_ASQ      :   1,
        a5_SEQStart :   1,
        a6_Closing  :   1,
        a7_SEQEnd   :   1;
    
    int8
        b0_SpecARQ  :   1,
        b1_Unknown  :   1,
        b2_ARSP     :   1,
        b3_Unknown  :   1,
        b4_Unknown  :   1,
        b5_Unknown  :   1,
        b6_Unknown  :   1,
        b7_Unknown  :   1;
};
struct FRAGMENT_INFO
{
    int16 dwSeq;
    int16 dwCurr;
    int16 dwTotal;
};
/*****************************************************************************
*********/

class CEQPacket  
{
public:
/************ PUBLIC FUNCTIONS ************/

    CEQPacket();
    virtual ~CEQPacket();

    /**********/
    void  DecodePacket(int16 length, uchar *pPacket);
    uchar* ReturnPacket(int16 *dwLength);
    /**********/

    void AddAdditional(int size, uchar *pAdd) 
    {   
        if(!pExtra)
            delete[] pExtra;
        pExtra = new uchar[size];
        memcpy( (void*) pExtra, (void*) pAdd, size);
    }       
    
    void Clear(void) {  /************ CLEAR FIELDS ************/
                        *((int16*)&HDR) = 0;

                        dwSEQ           = 0;        
                        dwARSP          = 0;
                        dwARQ           = 0;
                        dbASQ_low       = 0;        
                        dbASQ_high      = 0;
                        dwOpCode        = 0;    
                        fraginfo.dwCurr = 0;
                        fraginfo.dwSeq  = 0;
                        fraginfo.dwTotal= 0;
                        dwExtraSize     = 0;
                        pExtra          = 0;
                        /************ END CLEAR FIELDS ************/ 
                    }
/************ PUBLIC VARIABLES ************/
                   
    EQPACKET_HDR_INFO   HDR;

    int16               dwSEQ;      //Sequence number
    int16               dwARSP;
    int16               dwARQ;
    int16               dbASQ_high : 8,
                        dbASQ_low  : 8;

    int16               dwOpCode;   //Not all packet have opcodes. 

    FRAGMENT_INFO       fraginfo;       //Fragment info


    int16               dwExtraSize;//Size of additional info.
    uchar              *pExtra; //Additional information


private:
/************ PRIVATE FUNCTIONS ************/

    int32 RoL(int32 in, int32 bits);
    int32 CRCLookup(uchar idx);
    int32 GenerateCRC(int32 b, int32 bufsize, uchar *buf);

    
/************ PRIVATE VARIABLES ************/

};

#endif
