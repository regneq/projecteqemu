#ifndef EQPACKETMANAGER_H

#define EQPACKETMANAGER_H



#include <iostream.h>



#include "types.h"

#include "queue.h"

#include "timer.h"



#include "eq_opcodes.h"

#include "EQPacket.h"

#include "EQFragment.h"



// Added struct

typedef struct

{

	uchar*	buffer;

	int16	size;

}MySendPacketStruct;



template <typename type>

void SAFE_DELETE(type &del){if(del){delete[]del; del=0;}}



/************ DEFINES ************/



#define PM_ACTIVE	 0 //manager is up and running

#define PM_FINISHING 1 //manager received closing bits and is going to send

final packet

#define PM_FINISHED  2 //manager has sent closing bits back to client





/************ STRUCTURES/CLASSES ************/



	/************ PACKET RELATED STRUCT ************/

	class APPLAYER

	{

	public:

		~APPLAYER() { SAFE_DELETE(pBuffer); }

		APPLAYER() { size = 0; opcode = 0; pBuffer = 0; }

		int32  size;

		int16  opcode;

		uchar* pBuffer;

	};



	/************ Contain ack stuff ************/

	struct ACK_INFO

	{

		ACK_INFO() { dwARQ = 0; dbASQ_high = dbASQ_low = 0; dwGSQ = 0; }



		int16	dwARQ; //Current request ack

		int16   dbASQ_high : 8,

				dbASQ_low  : 8;

		int16   dwGSQ; //Main sequence number SHORT#2



	};





class CEQPacketManager

{

public:

/************ PUBLIC FUNCTIONS ************/

	CEQPacketManager();//CTimer *tim_set, int32 ddTimerID_set);

	virtual ~CEQPacketManager();

	/**********/



	void SetDebugLevel(int8 set_level) { debug_level = set_level; }



	/************ parce/make packets ************/

	void ParceEQPacket(int16 dwSize, uchar* pPacket);

	void MakeEQPacket(APPLAYER* app); //Make a/fragment eq packet and put them on

the SQUEUE/RSQUEUE



	/************ Add ack to packet if requested ************/

	void AddAck(CEQPacket *pack)

	{

		if(CACK.dwARQ)

		{

			pack->HDR.b2_ARSP = 1;			//Set ack response field

			pack->dwARSP = CACK.dwARQ; 		//ACK current ack number.

			CACK.dwARQ = 0;

		}

	}

	/************ Timer Functions ************/

	void CheckTimers(void); //Check all inclass timers and call proper functions

//	_MEM_STRUCT<uchar>* ProcessSendBuffer(void); //Returns a buffer to packet if

send buff timer has timed out!



	/************ Check if  ************/

	int CheckActive(void) { if(pm_state == PM_FINISHED) return(0); else return(1);}

	void Close() { if (pm_state == PM_ACTIVE) pm_state = PM_FINISHING; }



	/************ INCOMING/OUTGOING ACK ************/

	void IncomingARSP(int16 dwARSP)

	{

		if(dwARSP<= SACK.dwARQ && dwARSP >= dwTimerARQ)

		{

			ResendQueue.clear();

			no_ack_received_timer->Disable();



			if (debug_level >= 2)

			{

				cout << Timer::GetCurrentTime() << " no_ack_received_timer->Disable()";

				cout << " dwARSP:" << (unsigned short)dwARSP;

				cout << " SACK.dwARQ:" << (unsigned short)SACK.dwARQ;

				cout << " dwTiemrARQ:" << (unsigned short)dwTimerARQ << endl;

			}

			dwTimerARQ = 0; //Reset ack.

		}

		else

		{

			if (debug_level >= 1)

			{

				cout << "Client sent invalid an ack respond!";

			        cout << "dwARSP:" << (unsigned short)dwARSP;

				cout << " SACK.dwARQ:" << (unsigned short)SACK.dwARQ;

				cout << " dwTiemrARQ:" << (unsigned short)dwTimerARQ << endl;

			}

		}

	}

	void IncomingARQ(int16 dwARQ)

	{

		CACK.dwARQ = dwARQ;

		dwLastCACK = dwARQ;



		no_ack_sent_timer->SetTimer(500);



		if (debug_level >= 2)

			cout << Timer::GetCurrentTime() << " no_ack_sent_timer->SetTimer(500)" <<

endl;

	}

	void OutgoingARQ(int16 dwARQ)   //An ack request is sent

	{

		if(!dwTimerARQ)

		{

			dwTimerARQ = dwARQ;

			no_ack_received_timer->Start(500);

			if (debug_level >= 2)

				cout << Timer::GetCurrentTime() << " no_ack_received_timer->SetTimer(500)"

<< "ARQ:" << (unsigned short) dwARQ << endl;

		}

	}

	void OutgoingARSP(void)

	{

			no_ack_sent_timer->Disable();

			if (debug_level >= 2)

				cout << Timer::GetCurrentTime() << " no_ack_sent_timer->Disable()" << endl;

	}

	/************ END INCOMING/OUTGOING ACK ************/



	/************ Sendbuffer timer NOT USED AT THE MOMENT!!!!!!!!!************/

	/*

	int CheckSendTimer(void)

	{

		return((int)tim->CheckTimer(ddTimerID, TIMER_SENDBUFF));

	}

	void ResetSendTimer(void)

	{

		tim->Activate(ddTimerID, TIMER_SENDBUFF, 1);

	}

*/





/************ PUBLIC VARIABLES ************/





	MyQueue<MySendPacketStruct> SendQueue; //Store packets thats on the send que

	MyQueue<APPLAYER>		    OutQueue; //parced packets ready to go out of this class





private:

/************ PRIVATE FUNCTIONS ************/

	bool ProcessPacket(CEQPacket* pack, bool from_buffer=false);

	void CheckBufferedPackets();



/************ PRIVATE VARIABLES ************/

//	FRAGMENT_GROUP    fgIn;		//Store incoming fragments

	FragmentGroupList fragment_group_list;

	MyQueue<CEQPacket> ResendQueue;	//Resend queue



	LinkedList<CEQPacket*> buffered_packets; // Buffer of incoming packets



	ACK_INFO	SACK; //Server -> client info.

	ACK_INFO	CACK; //Client -> server info.

	int16		dwLastCACK;

	int16		dwTimerARQ; //This was current ack when the ARQtimer started.



//	int32  ddTimerID;

//	CTimer *tim; //Static ptr to the CTimer class.

	Timer* no_ack_received_timer;

	Timer* no_ack_sent_timer;



	int	   pm_state;  //manager state

	int8   resend_count;

	int16  dwFragSeq;   //current fragseq



	int8 debug_level;

};



#endif



