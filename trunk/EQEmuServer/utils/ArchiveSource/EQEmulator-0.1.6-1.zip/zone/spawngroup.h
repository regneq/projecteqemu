#ifndef SPAWNGROUP_H
#define SPAWNGROUP_H

#include "../common/linked_list.h"

class SpawnEntry
{
public:
	SpawnEntry( int in_NPCType, int in_chance );
	~SpawnEntry();
	int NPCType;
	int chance;
};

class SpawnGroup
{
public:
	SpawnGroup( int in_id, char name[30] );
	~SpawnGroup();
	int GetNPCType();
	void AddSpawnEntry( SpawnEntry* newEntry );
	int id;
private:
	char name_[30];
    LinkedList<SpawnEntry*> list_;
};

class SpawnGroupList
{
public:
	SpawnGroupList() {};
	~SpawnGroupList() {};

	void AddSpawnGroup(SpawnGroup* newGroup);
	SpawnGroup* GetSpawnGroup(int id);
private:
    LinkedList<SpawnGroup*> list_;
};

#endif
