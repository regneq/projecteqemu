#ifndef NPC_H
#define NPC_H

#include "../common/database.h"
#include "mob.h"
#include "spawn.h"
#include "spawn2.h"
#include "hate_list.h"
#include "loottable.h"

#ifdef BUILD_FOR_WINDOWS
	#define  M_PI	3.141592
#endif

//typedef LinkedList<Item_Struct*> ItemList;

class NPC : public Mob
{
public:
	NPC(NPCType* data, void* respawn, float x, float y, float z, float heading, bool isgroup);
	virtual ~NPC();

	virtual bool IsNPC() { return true; }

	virtual bool Process();

	void Attack(Mob* other);
	void Damage(Mob* other, int32 damage, int16 spell);
	void Death(Mob* other, int32 damage, int16 spell);

	void FaceTarget();
	void RemoveFromHateList(Mob* mob);

	void AddItem(Item_Struct* item);
	Item_Struct* RemoveItem(uint16 item_id);

	void AddCash(int16 copper, int16 silver, int16 gold, int16 platinum);
	void RemoveCash();
	ItemList* GetItemList() { return itemlist; }
	void QueryLoot(Client* to);

	uint32 GetCopper() { return copper; }
	uint32 GetSilver() { return silver; }
	uint32 GetGold()   { return gold; }
	uint32 GetPlatinum() { return platinum; }
protected:
	HateList hate_list;
	Spawn* respawn;
	Spawn2* respawn2;
	
	uint32 copper;
	uint32 silver;
	uint32 gold;
	uint32 platinum;
	ItemList* itemlist;
};

#endif

