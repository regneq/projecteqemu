#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include "spawngroup.h"
#include "spawn2.h"
#include "zone.h"
#include "worldserver.h"

extern Database database;
extern WorldServer* worldserver;

#ifdef BUILD_FOR_WINDOWS
	#define	 snprintf	_snprintf
	#define  vsnprintf	_vsnprintf
#endif

Zone::Zone(char* in_short_name, char* in_address, int16 in_port)
{
	short_name = strcpy(new char[strlen(in_short_name)+1], in_short_name);
	long_name = 0;
	address = strcpy(new char[strlen(in_address)+1], in_address);
	port = in_port;

	max_npc_type = 0;
	npc_type_array = 0;

	spawn_group_list = new SpawnGroupList();

	database.GetZoneLongName(short_name, &long_name);
	database.PopulateZoneLists(short_name, npc_type_array, max_npc_type, spawn_list, zone_point_list, spawn2_list, spawn_group_list);

	if (long_name == 0)
	{
		long_name = strcpy(new char[18], "Long zone missing");
	}
//	if (worldserver != 0)
//		worldserver->SetZone(this->GetShortName());
}

Zone::~Zone()
{
	database.UnregisterZoneServer(short_name, address, port);
	delete[] short_name;
	delete[] long_name;
	delete[] address;
	if (worldserver != 0)
		worldserver->SetZone("");
}

void Zone::Process()
{
	LinkedListIterator<Spawn*> iterator(spawn_list);
	LinkedListIterator<Spawn2*> iterator2(spawn2_list);

	iterator.Reset();
	while (iterator.MoreElements())
	{
		iterator.GetData()->Process();
		iterator.Advance();
	}

	iterator2.Reset();
	while (iterator2.MoreElements())
	{
		iterator2.GetData()->Process();
		iterator2.Advance();
	}
}

NPCType* Zone::GetNPCType(uint16 id)
{
	if (npc_type_array && id <= max_npc_type)
		return &npc_type_array[id]; 
	else
		return 0;
}

ZonePoint* Zone::GetClosestZonePoint(float x, float y, float z, char* to_name)
{
	LinkedListIterator<ZonePoint*> iterator(zone_point_list);
	ZonePoint* closest_zp = 0;
	float closest_dist = FLT_MAX;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		ZonePoint* zp = iterator.GetData();
		if (strcmp(zp->target_zone, to_name) == 0)
		{
			float dist = (zp->x-x)*(zp->x-x)+(zp->y-y)*(zp->y-y)+(zp->z-z)*(zp->z-z);
			if (dist < closest_dist)
			{
				closest_zp = zp;
				closest_dist = dist;	
			}
		}
		iterator.Advance();
	}
	return closest_zp;
}

bool Database::PopulateZoneLists(char* zone_name, NPCType* &npc_type_array, uint16 &max_npc_type, LinkedList<Spawn*>& spawn_list, LinkedList<ZonePoint*>& zone_point_list, LinkedList<Spawn2*> &spawn2_list, SpawnGroupList* spawn_group_list)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT x,y,z,target_x,target_y,target_z,target_zone FROM zone_points WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				ZonePoint* zp = new ZonePoint;
				zp->x = atof(row[0]);
				zp->y = atof(row[1]);
				zp->z = atof(row[2]);
				zp->target_x = atof(row[3]);
				zp->target_y = atof(row[4]);
				zp->target_z = atof(row[5]);
				strncpy(zp->target_zone, row[6], 16);
				zone_point_list.Insert(zp);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT npc_type,x,y,z,respawn FROM spawn WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				Spawn* sp = new Spawn(atoi(row[0]), atoi(row[1]), atoi(row[2]), atoi(row[3]), atoi(row[4])*1000);
				spawn_list.Insert(sp);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

// CODER new spawn code
	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT DISTINCT(spawngroupID), spawngroup.name FROM spawn2,spawngroup WHERE spawn2.spawngroupID=spawngroup.ID and zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				SpawnGroup* newSpawnGroup = new SpawnGroup( atoi(row[0]), row[1]);
				spawn_group_list->AddSpawnGroup( newSpawnGroup );
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT spawnentry.spawngroupID, npcid, chance from spawnentry,spawn2 where spawnentry.spawngroupID=spawn2.spawngroupID and zone='%s' ORDER by chance", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				SpawnEntry* newSpawnEntry = new SpawnEntry( atoi(row[1]), atoi(row[2]));
				spawn_group_list->GetSpawnGroup(atoi(row[0]))->AddSpawnEntry(newSpawnEntry);
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	query = 0;
	buf_len = 256;
	chars = -1;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT spawngroupID ,x,y,z,respawntime,variance FROM spawn2 WHERE zone='%s'", zone_name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while(row = mysql_fetch_row(result))
			{
				Spawn2* newSpawn = new Spawn2(atoi(row[0]), atoi(row[1]), atoi(row[2]), atoi(row[3]), atoi(row[4]), atoi(row[5]));
				spawn2_list.Insert( newSpawn );
			}
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
// CODER end new spawn code

	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM npc_types");

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			row = mysql_fetch_row(result);
			if (row != 0 && row > 0)
			{
				max_npc_type = atoi(row[0]);
				npc_type_array = new NPCType[max_npc_type+1];
				mysql_free_result(result);

				query = 0;
				buf_len = 256;
				chars = -1;
				while (chars == -1 || chars >= buf_len)
				{
					if (query != 0)
					{
						delete[] query;
						query = 0;
						buf_len *= 2;
					}
					query = new char[buf_len];
					chars = snprintf(query, buf_len, "SELECT id,name,level,race,class,hp,gender,texture,loottable_id FROM npc_types");// WHERE zone='%s'", zone_name);
				}

				if (!mysql_query(&mysql, query))
				{
					delete[] query;
					result = mysql_store_result(&mysql);
					if (result)
					{
						while(row = mysql_fetch_row(result))
						{
							strncpy(npc_type_array[atoi(row[0])].name, row[1], 30);
							npc_type_array[atoi(row[0])].npc_id = atoi(row[0]); // rembrant, Dec. 2
							npc_type_array[atoi(row[0])].level = atoi(row[2]);
							npc_type_array[atoi(row[0])].race = atoi(row[3]);
							npc_type_array[atoi(row[0])].class_ = atoi(row[4]);
							npc_type_array[atoi(row[0])].cur_hp = atoi(row[5]);
							npc_type_array[atoi(row[0])].max_hp = atoi(row[5]);
							npc_type_array[atoi(row[0])].gender = atoi(row[6]);
							npc_type_array[atoi(row[0])].texture = atoi(row[7]);
							npc_type_array[atoi(row[0])].loottable_id = atoi(row[8]);
						}
					}
					mysql_free_result(result);
				}
				else
				{
					cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
					delete[] query;
					return false;
				}
			}
			else
			{
				mysql_free_result(result);
			}
		}
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

/*
	query = new char[256];
	strcpy(query, "SELECT MAX(id) FROM items");

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			row = mysql_fetch_row(result);
			if (row != 0 && row[0] > 0)
			{ 
				max_item = atoi(row[0]);
				item_array = new Item_Struct*[max_item+1];
				for(int i=0; i<max_item; i++)
				{
					item_array[i] = 0;
				}
				mysql_free_result(result);
				
				query = 0;
				buf_len = 256;
				chars = -1;
				while (chars == -1 || chars >= buf_len)
				{
					if (query != 0)
					{
						delete[] query;
						query = 0;
						buf_len *= 2;
					}
					query = new char[buf_len];
					chars = snprintf(query, buf_len, "SELECT id,raw_data FROM items");
				}

				unsigned long* lengths;
				if (!mysql_query(&mysql, query))
				{
					delete[] query;
					result = mysql_store_result(&mysql);
					if (result)
					{
						while(row = mysql_fetch_row(result))
						{
							lengths = mysql_fetch_lengths(result);
							if (lengths[1] == sizeof(Item_Struct))
							{
								item_array[atoi(row[0])] = new Item_Struct;
								memcpy(item_array[atoi(row[0])], row[1], sizeof(Item_Struct));
							}
							else
							{
								// TODO: Invalid item length in database
							}
						}
					}
					mysql_free_result(result);
				}
				else
				{
					cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
					delete[] query;
					return false;
				}
			}
			else
			{
				mysql_free_result(result);
			}
		}
	}
	else
	{
		cerr << "Error in PopulateZoneLists query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}
*/
	return true;
}
