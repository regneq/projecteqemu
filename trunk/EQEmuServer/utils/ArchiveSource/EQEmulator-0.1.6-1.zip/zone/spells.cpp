#include "client.h"
#include "spdat.h"

extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;

void Client::CastSpell(int16 spell_id, int32 target_id, int16 slot) {
	if (!spells_loaded)
		Message(0, "Spells not loaded.");
	else {
		/* Client begins to cast a spell */
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_BeginCast;
		outapp->size = sizeof(BeginCast_Struct);
		outapp->pBuffer = new uchar[outapp->size];

		BeginCast_Struct* begincast = (BeginCast_Struct*)outapp->pBuffer;
//		begincast->target_id = target_id;
		begincast->target_id = GetID();
		begincast->spell_id = spell_id;
		begincast->bc_unknown1 = 0xffff;
		begincast->bc_unknown2 = 0xffff;
		begincast->bc_unknown3 = 0xffff;
		QueuePacket(outapp);
		delete outapp;

		/* Dunno why this goes here, but it does */
		// Quagmire - Think this is to grey the memorized spell icons?
		outapp = new APPLAYER;
		outapp->opcode = OP_MemorizeSpell;
		outapp->size = sizeof(MemorizeSpell_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		MemorizeSpell_Struct* memspell = (MemorizeSpell_Struct*)outapp->pBuffer;
		memspell->slot = slot;
		memspell->spell_id = spell_id;
		memspell->scribing = 3;
		QueuePacket(outapp);
		delete outapp;

		/* Actual cast action */
		outapp = new APPLAYER;
		outapp->opcode = OP_CastOn;
		outapp->size = sizeof(CastOn_Struct);
		outapp->pBuffer = new uchar[outapp->size];

		CastOn_Struct* caston = (CastOn_Struct *)outapp->pBuffer;
		memset(outapp->pBuffer, 0, outapp->size);
		caston->source_id = id;
		caston->target_id = target_id;
		caston->action = 231;
		caston->spell_id = spell_id;
		QueuePacket(outapp);
		delete outapp;

		/* Client animation */
		outapp = new APPLAYER;
		outapp->opcode = OP_Attack;
		outapp->size = sizeof(Attack_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, outapp->size);
		Attack_Struct* a = (Attack_Struct*)outapp->pBuffer;
		a->spawn_id = id;
		if ((target) && (target != this))
		  a->a_unknown1 = target->GetID();
		a->type = 42;
		a->a_unknown2[5] = 0x80;      
		a->a_unknown2[6] = 0x3f;       
		entity_list.QueueCloseClients(this, outapp);
		delete outapp;  

		/* Effect of the spell (currently every spell works like heal) */
		outapp = new APPLAYER;
		outapp->opcode = OP_Action;
		outapp->size = sizeof(Action_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		Action_Struct* action = (Action_Struct *)outapp->pBuffer;
		memset(outapp->pBuffer, 0, outapp->size);
		action->damage = 0;
		action->spell = spell_id;
		action->source = id;
		action->target = target_id;
		action->type = 0xE7;
		QueuePacket(outapp);
		delete outapp;

		/* Tell client it can cast again */
		outapp = new APPLAYER;
		outapp->opcode = OP_ManaChange;
		outapp->size = sizeof(ManaChange_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
		pp.mana = pp.mana - spells[spell_id].mana;
		manachange->new_mana = pp.mana - spells[spell_id].mana;
		manachange->spell_id = spell_id;
		QueuePacket(outapp);
		delete outapp;

		SpellEffect(spell_id, target_id);
	}
}

// Quagmire - that case above getting to long and spells are gonna have a lot of cases of their own
void Client::SpellEffect(int16 spell_id, int32 target_id) {
	if (!spells_loaded) {
		Message(0, "Spells werent loaded on bootup.");
		return;
	}
	for (int i = 0; i < 12; i++) {
		switch(spells[spell_id].effectid[i])
		{
			case SE_CurrentHP: {
				Message(0, "Effect #%i: You cast a heal or nuke.", i);
				if (target == 0) {
					SetMaxHP();
					SendHPUpdate();
					Message(0, "Healing you.");
				}
				else if (target->IsClient()) {
					Client* client = target->CastToClient();
					client->SetMaxHP();
					client->SendHPUpdate();
					client->Message(0, "You have been healed by %s", this->GetName());
				}
				break;
			}
			case SE_ArmorClass: {
				Message(0, "Effect #%i: You cast an AC buff/debuff.", i);
				break;
			}
			case SE_ATK: {
				Message(0, "Effect #%i: You cast an ATK buff/debuff.", i);
				break;
			}
			case SE_MovementSpeed: {
				Message(0, "Effect #%i: You cast an Movement Speed buff/debuff.", i);
				break;
			}
			case SE_DEX: {
				Message(0, "Effect #%i: You cast a DEX buff/debuff.", i);
				break;
			}
			case SE_AGI: {
				Message(0, "Effect #%i: You cast an AGI buff/debuff.", i);
				break;
			}
			case SE_STA: {
				Message(0, "Effect #%i: You cast a STA buff/debuff.", i);
				break;
			}
			case SE_INT: {
				Message(0, "Effect #%i: You cast an INT buff/debuff.", i);
				break;
			}
			case SE_WIS: {
				Message(0, "Effect #%i: You cast a WIS buff/debuff.", i);
				break;
			}
			case SE_CHA: {
				if (spells[spell_id].base[i] != 0)
					Message(0, "Effect #%i: You cast a CHA buff/debuff.", i);
				else {
					// this is used in a lot of spells as a spacer, dunno why
				}
				break;
			}
			case SE_AttackSpeed: {
				Message(0, "Effect #%i:You cast an Attack Speed buff/debuff.", i);
				break;
			}
			case SE_Invisibility: {
				Message(0, "Effect #%i: You cast an Invisibility spell.", i);
				break;
			}
			case SE_SeeInvis: {
				Message(0, "Effect #%i: You cast a See Invis buff.", i);
				break;
			}
			case SE_WaterBreathing: {
				Message(0, "Effect #%i: You cast a Water Breathing buff.", i);
				break;
			}
			case SE_CurrentMana: {
				Message(0, "Effect #%i: You cast an add/subtract mana spell.", i);
				break;
			}
			case SE_AddFaction: {
				Message(0, "Effect #%i: You cast an Add Faction spell.", i);
				break;
			}
			case SE_Stun: {
				Message(0, "Effect #%i: You cast a Stun spell.", i);
				break;
			}
			case SE_Charm: {
				Message(0, "Effect #%i: You cast a Charm spell.", i);
				break;
			}
			case SE_Fear: {
				Message(0, "Effect #%i: You cast a Fear spell.", i);
				break;
			}
			case SE_Stamina: {
				Message(0, "Effect #%i: You cast a Stamina add/subtract spell.", i);
				break;
			}
			case SE_CancelMagic: {
				Message(0, "Effect #%i: You cast a Cancel Magic spell.", i);
				break;
			}
			case SE_InvisVsUndead: {
				Message(0, "Effect #%i: You cast an Invis Vs Undead spell.", i);
				break;
			}
			case SE_Mez: {
				Message(0, "Effect #%i: You cast a Mez spell.", i);
				break;
			}
			case SE_SummonItem: {
				Message(0, "Effect #%i: You cast a Summon Item #%i.", i, spells[spell_id].base[i]);
				Item_Struct* item = database.GetItem(spells[spell_id].base[i]);
				if (item == 0) {
					Message(0, "No such item: %i", spells[spell_id].base[i]);
				}
				else {
					pp.inventory[0] = spells[spell_id].base[i];
					APPLAYER* outapp = new APPLAYER;
					outapp->opcode = OP_SummonedItem;
					outapp->size = sizeof(SummonedItem_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					memcpy(outapp->pBuffer, item, sizeof(Item_Struct));
					Item_Struct* item2 = (Item_Struct*) outapp->pBuffer;
					item2->equipSlot = 0;
					QueuePacket(outapp);
					delete outapp;
				}
				break;
			}
			case SE_SummonPet: {
				Message(0, "Effect #%i: You cast a Summon Pet spell.", i);
				break;
			}
			case SE_DivineAura: {
				Message(0, "Effect #%i: You cast a Divine Aura spell.", i);
				break;
			}
			case SE_ShadowStep: {
				Message(0, "Effect #%i: You cast a Shadow Step spell.", i);
				break;
			}
			case SE_ResistFire: {
				Message(0, "Effect #%i: You cast a Resist Fire spell.", i);
				break;
			}
			case SE_ResistCold: {
				Message(0, "Effect #%i: You cast a Resist Cold spell.", i);
				break;
			}
			case SE_ResistPoison: {
				Message(0, "Effect #%i: You cast a Resist Poison spell.", i);
				break;
			}
			case SE_ResistDisease: {
				Message(0, "Effect #%i: You cast a Resist Disease spell.", i);
				break;
			}
			case SE_ResistMagic: {
				Message(0, "Effect #%i: You cast a Resist Magic spell.", i);
				break;
			}
			case SE_SenseDead: {
				Message(0, "Effect #%i: You cast a Sense Dead spell.", i);
				break;
			}
			case SE_SenseSummoned: {
				Message(0, "Effect #%i: You cast a Sense Summoned spell.", i);
				break;
			}
			case SE_SenseAnimals: {
				Message(0, "Effect #%i: You cast a Sense Animals spell.", i);
				break;
			}
			case SE_Rune: {
				Message(0, "Effect #%i: You cast a Rune spell.", i);
				break;
			}
			case SE_TrueNorth: {
				Message(0, "Effect #%i: You cast a True North spell. UBER!", i);
				break;
			}
			case SE_Levitate: {
				Message(0, "Effect #%i: You cast a Levitate spell.", i);
				break;
			}
			case SE_Illusion: {
				Message(0, "Effect #%i: You cast an Illusion spell.", i);
				break;
			}
			case SE_DamageShield: {
				Message(0, "Effect #%i: You cast a Damage Shield spell.", i);
				break;
			}
			case SE_Identify: {
				Message(0, "Effect #%i: You cast an Identify spell.", i);
				break;
			}
			case SE_WhipeHateList: {
				Message(0, "Effect #%i: You cast a Mem Blur spell.", i);
				break;
			}
			case SE_SpinTarget: {
				Message(0, "Effect #%i: You cast a Spin Target spell.", i);
				break;
			}
			case SE_InfaVision: {
				Message(0, "Effect #%i: You cast an InfaVision buff.", i);
				break;
			}
			case SE_UltraVision: {
				Message(0, "Effect #%i: You cast an UltraVision buff.", i);
				break;
			}
			case SE_EyeOfZomm: {
				Message(0, "Effect #%i: You cast an Eye of Zomm spell.", i);
				break;
			}
			case SE_ReclaimPet: {
				Message(0, "Effect #%i: You cast a Reclaim Pet spell.", i);
				break;
			}
			case SE_TotalHP: {
				Message(0, "Effect #%i: You cast an HP buff/debuff.", i);
				break;
			}
			case SE_BindSight: {
				Message(0, "Effect #%i: You cast a Bind Sight spell.", i);
				break;
			}
			case SE_FeignDeath: {
				Message(0, "Effect #%i: You cast a Feign Death spell.", i);
				break;
			}
			case SE_VoiceGraft: {
				Message(0, "Effect #%i: You cast a Voice Graft spell.", i);
				break;
			}
			case SE_Sentinel: {
				Message(0, "Effect #%i: You cast Sentinel. Fuck You.", i);
				break;
			}
			case SE_LocateCorpse: {
				Message(0, "Effect #%i: You cast a Locate Corpse spell.", i);
				break;
			}
			case SE_CurrentHPOnce: {
				Message(0, "Effect #%i: You cast a Heal / Nuke (non-reoccuring) spell.", i);
				break;
			}
			case SE_Revive: {
				Message(0, "Effect #%i: You cast a Revive spell.", i);
				break;
			}
			case SE_Teleport: {
				ZonePC(spells[spell_id].teleport_zone, spells[spell_id].base[1], spells[spell_id].base[0], spells[spell_id].base[2]);
				break;
			}
			case SE_ModelSize: {
				Message(0, "Effect #%i: You cast a Shrink/Grow spell.", i);
				break;
			}
			case SE_Root: {
				Message(0, "Effect #%i: You cast a Root spell.", i);
				break;
			}
			case 0xFE:
			case 0xFF: {
				// this is the code for empty... i think
				break;
			}
			default: {
				Message(0, "Effect #%i: I dont know what this effect is: 0x%x.", i, spells[spell_id].effectid[i]);
			}
		}
	}
}