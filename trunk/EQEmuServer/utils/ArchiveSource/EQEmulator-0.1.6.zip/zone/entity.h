#ifndef ENTITY_H
#define ENTITY_H

#include "../common/types.h"
#include "../common/linked_list.h"

#ifdef BUILD_FOR_WINDOWS
	class	APPLAYER;
#else
	struct APPLAYER;
#endif

class Client;
class Mob;
class NPC;

void ProcessClientThreadSpawn(void *tmp);

class Entity
{
public:
	Entity();
	virtual ~Entity();

	virtual bool IsClient() { return false; }
	virtual bool IsNPC()    { return false; }
	virtual bool IsMob()    { return false; }

#ifdef BUILD_FOR_WINDOWS
	virtual bool Process()  { return false; }
#else
	virtual bool Process()  {}
#endif

	Client* CastToClient();
	NPC*    CastToNPC();
	Mob*    CastToMob();

	void SetID(int16 set_id);
	int16 GetID();
	volatile bool BeingProcessed;
	volatile bool DropMe;

protected:
	int16 id;
};

class EntityList
{
public:
    EntityList();
    ~EntityList();

	Entity* GetID(int16 id);
	Client* GetClientByName(char *name); 
    Client* GetClient(int32 ip, int16 port);

	void    AddClient(Client*);
	void    AddNPC(NPC*);
	void	Clear();

	int16   GetFreeID();

	void	Message(int32 to_guilddbid, int32 type, char* message, ...);
	void	ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...);
	void    ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...);
	void	ChannelMessageSend(Mob* to, int8 chan_num, int8 language, char* message, ...);
	void    SendZoneSpawns(Client*);
	void    Save();

	void    RemoveFromTargets(Mob* mob);

	void	QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender=false, float dist=200);
	void    QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender=false);

	void	UpdateWho();

	void    RemoveEntity(int16 id);

    void    ProcessNCE(); // Process Non-Client Entities
	void	ProcessClientThreadManagerLoop(); // Manages the worker threads that call Client->Process
	void	ClientSendPacketQueue(); // Sends packets from client out queues
private:
    LinkedList<Entity*> list;
	int16 last_insert_id;
};

#endif

