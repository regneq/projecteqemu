#include <math.h>
#include <time.h>
#ifndef BUILD_FOR_WINDOWS
	#include <stdlib.h>
#endif

#include "npc.h"
#include "client.h"

extern Database database;

NPC::NPC(NPCType* d, void* in_respawn, float x, float y, float z, float heading, bool isgroup)
 : Mob(d->name,
       d->lastname,
       d->max_hp,
       d->max_hp,
       d->gender,
       d->race,
       d->class_,
       d->deity,
       d->level,
	   d->npc_id, // rembrant, Dec. 20, 2001
       heading,
       x,
       y,
       z,
       d->light,
       d->equipment)
{
	if (d->npc_id == 0) { // GM created
		respawn = 0;
		respawn2 = 0;
	}
	if (isgroup) {
		respawn =0;
		respawn2 = (Spawn2*) in_respawn;
	}
	else {
		respawn2 =0;
		respawn = (Spawn*) in_respawn;
	}

	itemlist = new ItemList();
	if (d->npc_id != 0) { // check if it's a GM spawn
		database.AddLootTableToNPC(d->loottable_id, itemlist, &copper, &silver, &gold, &platinum);
	}
}

NPC::~NPC()
{
	delete itemlist;
}

void NPC::AddItem(Item_Struct* item)
{
    cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	(*itemlist).Append(item);
}

Item_Struct* NPC::RemoveItem(uint16 item_id)
{
	LinkedListIterator<Item_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->item_nr == item_id)
		{
			Item_Struct* item = iterator.GetData();
			iterator.RemoveCurrent();
			cout << "removing item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << 
				"from: " << this->name << " " << this->id << endl;
			return item;
		}
		iterator.Advance();
	}

	return 0;
}

void NPC::QueryLoot(Client* to) {
	LinkedListIterator<Item_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements())
	{
		Item_Struct* item = iterator.GetData();
		to->Message(0, "  %d: %s", item->item_nr, item->name);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void NPC::AddCash(int16 copper, int16 silver, int16 gold, int16 platinum)
{
	srand(time(NULL));
	this->copper = (rand() % 100)+1;
	this->silver = (rand() % 50)+1;
	this->gold = (rand() % 10)+1;
	this->platinum = (rand() % 5)+1;
}

void NPC::RemoveCash()
{
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
}

bool NPC::Process()
{
	if (corpse)
		return true;

	SetTarget(hate_list.GetTop());

	if (target != 0)
	{
		if (attack_timer->Check())
		{
			FaceTarget();
			Attack(target);
			SendPosUpdate();
		}
	}

    return true;
}

void NPC::FaceTarget()
{
	// TODO: Simplify?

	float angle;

	if (target->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else if (target->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (target->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
//cout << "dX:" << target->GetX()-x_pos;
//cout << "dY:" << target->GetY()-y_pos;
//cout << "Angle:" << angle;

	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;

	heading = 256*(360-angle)/360.0f;

//cout << "Heading:" << (int)heading << endl;
}

void NPC::RemoveFromHateList(Mob* mob)
{
	hate_list.RemoveEnt(mob);
}