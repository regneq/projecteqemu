#ifndef ZONE_H
#define ZONE_H

#include "../common/linked_list.h"
#include "../common/types.h"
#include "../common/database.h"
#include "spawn.h"
#include "mob.h"

struct ZonePoint {
	float x;
	float y;
	float z;
	float target_x;
	float target_y;
	float target_z;
	char  target_zone[16];
};

extern EntityList entity_list;

class Zone
{
public:
	Zone(char* in_short_name, char* in_address, int16 in_port);
	~Zone();

	char* GetAddress() { return address; }
	char* GetLongName() { return long_name; }
	char* GetShortName() { return short_name; }
	int16 GetPort() { return port; }

	ZonePoint* GetClosestZonePoint(float x, float y, float z, char* to_name);
	SpawnGroupList* spawn_group_list;

	NPCType* GetNPCType(uint16 id);
//	Item_Struct* GetItem(uint16 id);

	void Process();
    void Find(Mob* client, char* search_criteria);
private:
	char* short_name;
	char* long_name;
	char* address;
	int16 port;

	uint16 max_npc_type;
//	uint16 max_item;
	NPCType* npc_type_array;
//	Item_Struct** item_array;
	LinkedList<Spawn*> spawn_list;
	LinkedList<Spawn2*> spawn2_list; // CODER new spawn list
	LinkedList<ZonePoint*> zone_point_list;
};

#endif

