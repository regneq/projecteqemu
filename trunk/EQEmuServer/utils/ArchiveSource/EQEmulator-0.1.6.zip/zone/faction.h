#ifndef FACTION_H
#define FACTION_H

#include "../common/types.h"

#define FACTION_ALLY			1
#define FACTION_WARMLY			2
#define FACTION_KINDLY			3
#define FACTION_AMIABLE			4
#define FACTION_INDIFFERENT		5
#define FACTION_APPREHENSIVE	9
#define FACTION_DUBIOUS			8
#define FACTION_THREATENLY		7
#define FACTION_SCOWLS			6

#define MAX_FACTION	 1500
#define MIN_FACTION -1500

struct FactionMods
{
	sint32 base;
	sint32 class_mod;
	sint32 race_mod;
	sint32 deity_mod;
};

char* BuildFactionMessage(sint32 tmpvalue, int32 faction_id);
int8 CalculateFaction(FactionMods* fm, sint32 tmpCharacter_value);
#endif