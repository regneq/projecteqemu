#include <stdlib.h>

#include "npc.h"
#include "client.h"
#include "../common/eq_packet_structs.h"
#include <stdio.h>

#ifdef BUILD_FOR_WINDOWS
	#define snprintf	_snprintf
#endif

extern EntityList entity_list;

void Client::Attack(Mob* other)
{
	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;

	a->spawn_id = id;
	a->type = 5;
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;

	entity_list.QueueCloseClients(this, &app, false, 200);

	int damage = 0;

	if ((float)rand()/RAND_MAX < 0.8)
	{
		damage = 4.2*level;
	}
	other->Damage(this, damage, 0xffff);
}

void Client::Heal(Mob* other, int32 damage, int16 spell_id)
{
	SetMaxHP();
    APPLAYER app;
    app.opcode = OP_Action;
    app.size = sizeof(Action_Struct);
    app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
    Action_Struct* a = (Action_Struct*)app.pBuffer;

    a->target = id;
    a->source = other->GetID();
    a->type = 231; // 1
    a->spell = 0x000d; //spell_id
    a->damage = damage;

    entity_list.QueueCloseClients(this, &app);
    APPLAYER hp_app;
    CreateHPPacket(&hp_app);
    SendHPUpdate();

    cout << name << " healed via #heal" << endl; // Pyro: Why say damage?
}

void Client::Damage(Mob* other, int32 damage, int16 spell_id)
{
	if (damage > GetHP())
	{
		cur_hp = 0;
		Death(other, damage, spell_id);
		//return;
	}

	SetHP(GetHP()-damage);

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = id;
	a->source = other->GetID();
	a->type = 1;
	a->spell = spell_id;
	a->damage = damage;

	entity_list.QueueCloseClients(this, &app);
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, true); // Dont send this hp update to the client that got hurt
//	SendHPUpdate();                                     // Use this different message instead?
        if (damage != 0) // Pyro: Why log this message if no damage is inflicted
        {
                cout << name << " hit for " << damage << ", " << GetHP() << " left." << endl; // More intuitive console output
        }


}

void Client::Death(Mob* other, int32 damage, int16 spell)
{
	cout << "Player " << name << " has died, what do I do now?" << endl;
}

void NPC::Attack(Mob* other)
{
	if (DistNoRootNoZ(other) > 10*10)
	{
	return;
	}

	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;

	a->spawn_id = id;
	a->type = 5;

	entity_list.QueueCloseClients(this, &app);

	int damage = 0;

	if ((float)rand()/RAND_MAX < 0.4)
	{
		damage = 6*level;
	}
	other->Damage(this, damage, 0xffff);
}

void NPC::Damage(Mob* other, int32 damage, int16 spell_id)
{
	if (damage > cur_hp)
	{
		cur_hp = 0;
		Death(other, damage, spell_id);
		return;
	}


	cur_hp -= damage;

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = id;
	a->source = other->GetID();
	a->type = 0x1c;
	a->spell = spell_id;
	a->damage = damage;

	a->unknown4[0] = 0xcd;
	a->unknown4[1] = 0xcc;

	a->unknown4[2] = 0xcc;
	a->unknown4[3] = 0x3d;

	a->unknown4[4] = 0x71;
	a->unknown4[5] = 0x6b;

	a->unknown4[6] = 0x3d;
	a->unknown4[7] = 0x41;

	entity_list.QueueCloseClients(this, &app);

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app);

	hate_list.Add(other, damage);
}

void NPC::Death(Mob* other, int32 damage, int16 spell)
{
	cur_hp = 0;
	corpse = true;
	// Quagmire - Lets set the name right, "npc's_corpse"
	snprintf(name, sizeof(name), "%s's_corpse", name);

	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->spawn_id = id;
	d->killer_id = other->GetID();
	d->spell_id = spell;
	d->type = 5;
	d->damage = damage;
	entity_list.QueueClients(this, &app, false);

	if (hate_list.GetTop() != 0 && hate_list.GetTop()->IsClient())
	{
		hate_list.GetTop()->CastToClient()->AddEXP(level*level*75); // Pyro: Comment this if NPC death crashes zone
		if (other->IsClient())
			hate_list.GetTop()->CastToClient()->SetFactionLevel(other->CastToClient()->CharacterID(), npc_id, other->CastToClient()->GetClass(), other->CastToClient()->GetRace(), other->CastToClient()->GetDeity());
	}

	if (respawn !=0)
	{
		respawn->Reset();
	}
	else if (respawn2 != 0)
	{
		respawn2->Reset();
	}
}
