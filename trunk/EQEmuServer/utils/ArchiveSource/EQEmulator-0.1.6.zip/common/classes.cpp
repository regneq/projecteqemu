#include "../common/eq_packet_structs.h"
#include "../common/classes.h"

char* GetClassName(int8 class_) {
	switch(class_) {
		case WARRIOR:
			return "Warrior";
		case CLERIC:
			return "Cleric";
		case PALADIN:
			return "Paladin";
		case RANGER:
			return "Ranger";
		case SHADOWKNIGHT:
			return "ShadowKnight";
		case DRUID:
			return "Druid";
		case MONK:
			return "Monk";
		case BARD:
			return "Bard";
		case ROGUE:
			return "Rogue";
		case SHAMAN:
			return "Shaman";
		case NECROMANCER:
			return "Necromancer";
		case WIZARD:
			return "Wizard";
		case MAGICIAN:
			return "Magician";
		case ENCHANTER:
			return "Enchanter";
		case BEASTLORD:
			return "Beastlord";
		default:
			return "Unknown";
	}
}

