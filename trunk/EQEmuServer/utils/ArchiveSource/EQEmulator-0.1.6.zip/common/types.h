#ifndef TYPES_H
#define TYPES_H

// TODO: If we require signed or unsigned we should the s and u types..

typedef unsigned char		int8;
typedef unsigned short		int16;
typedef unsigned int		int32;

typedef unsigned char		uint8;
typedef  signed  char		sint8;
typedef unsigned short		uint16;
typedef  signed  short		sint16;
typedef unsigned int		uint32;
typedef  signed  int		sint32;

//typedef unsigned __int64	uint64;
//typedef  signed  __int64	sint64;
typedef unsigned long		ulong;
typedef unsigned short		ushort;
typedef unsigned char		uchar;

#endif
