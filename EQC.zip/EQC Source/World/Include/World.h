// ***************************************************************
//  EQCException   �  date: 21/12/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// 
// ***************************************************************

#ifndef WORLD_H
#define WORLD_H


void CatchSignal(int sig_num);
void HandleApplicationArguments(int argc, char** argv);

#endif