// ***************************************************************
//  World Guild Network Manager   �  date: 12/05/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// This class is for use when the world needs to send packets
// to the client	
// ***************************************************************

#ifndef WORLDGUILDNETWORKMANAGER_H
#define WORLDGUILDNETWORKMANAGER_H

namespace EQC
{
	namespace World
	{
		namespace Network
		{
			class WorldGuildNetworkManager
			{
			public:
				WorldGuildNetworkManager();
				~WorldGuildNetworkManager();
			protected:

			private:

			};
		}
	}
}
#endif