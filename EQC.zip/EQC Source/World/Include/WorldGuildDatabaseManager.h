// ***************************************************************
//  World Guild Network Manager   �  date: 12/05/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// This class is for use when the world needs to access (send or recive)
// data from the database
// ***************************************************************

#ifndef WORLDGUILDDATABASEMANAGER_H
#define WORLDGUILDDATABASEMANAGER_H

namespace EQC
{
	namespace World
	{
		namespace WorldDatabase
		{
			class WorldGuildDatabaseManager
			{
			public:
				WorldGuildDatabaseManager();
				~WorldGuildDatabaseManager();
			protected:

			private:

			};
		}
	}
}
#endif