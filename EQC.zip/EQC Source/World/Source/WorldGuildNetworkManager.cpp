// ***************************************************************
//  World Guild Network Manager   �  date: 12/05/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// This class is for use when the world needs to send packets
// to the client	
// ***************************************************************

#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
#include <cstdio>

#include "WorldGuildNetworkManager.h"

using namespace std;

namespace EQC
{
	namespace World
	{
		namespace Network
		{
			// Constructor
			WorldGuildNetworkManager::WorldGuildNetworkManager()
			{
			}

			// Destructor
			WorldGuildNetworkManager::~WorldGuildNetworkManager()
			{
			}


		}
	}
}