// ***************************************************************
//  Petition Manager   �  date: 16/05/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// This class is for use with handling peitions
// ***************************************************************

#include "PetitionManager.h"

//EQC::World::PetitionManager petition_mgr;

namespace EQC
{
	namespace Zone
	{
		PetitionManager::PetitionManager()
		{
		}

		PetitionManager::~PetitionManager()
		{
		}
	}
}