#include <cstdio>
#include <cstring>
#include <string>
#include <iomanip>
#include "client.h"
#include "classes.h"
#include "database.h"
#include "EQCUtils.hpp"
#include "eq_opcodes.h"
#include "GuildNetwork.h"
#include "petitions.h"
#include "PlayerCorpse.h"
#include "skills.h"
#include "worldserver.h"
#include "zone.h"
#include "config.h"
#include "groups.h"
#include "packet_dump_file.h"
#include "ZoneGuildManager.h"

using namespace std;
using namespace EQC::Zone;

extern PetitionList petition_list;
extern WorldServer worldserver;
extern Zone* zone;
extern ZoneGuildManager zgm;



#if(0)
void Client::ProcessOpcode(APPLAYER* app)
{
	//Show all packets but position ones..
	//if(app->opcode != 62240)
	//{
	//	cout << "opcode: " << app->opcode << "  size: " << app->size << endl;
	//	DumpPacket(app);
	//}

	//Cofruben: for debugging purposes.
	//****
	//cout << "Opcode: " << app->opcode << endl;
	//DumpPacket(app);
	//****

	switch(app->opcode)
	{
	case 0:
		break;
	case OP_AutoAttack:
		{
			this->ProcessOP_AutoAttack(app);
			break;
		}
	case OP_FeignDeath:
		{
			this->ProcessOP_FeignDeath(app);
			break;
		}
	case OP_DuelResponse:
		{
			this->ProcessOP_DuelResponse(app);
			break;
		}
	case OP_DuelResponse2:
		{
			this->ProcessOP_DuelResponse2(app);
			break;
		}
	case OP_RequestDuel:
		{
			this->ProcessOP_RequestDuel(app);
			break;
		}
	case OP_ClientUpdate:
		{
			this->ProcessOP_ClientUpdate(app);
			break;
		}
	case OP_ClientTarget:
		{
			this->ProcessOP_ClientTarget(app);
			break;
		}
	case OP_Jump:
		{
			this->Process_Jump(app);
			break; 
		}
	case OP_AssistTarget:
		{
			this->ProcessOP_AssistTarget(app);
			break;
		}
	case OP_Consider:
		{
			this->ProcessOP_Consider(app);
			break;
		}
	case OP_Surname:
		{
			this->ProcessOP_Surname(app);
			break;
		}
	case OP_YellForHelp: // Pyro
		{
			this->ProcessOP_YellForHelp(app);
			break;
		}
	case OP_SafePoint: // Pyro
		{
			this->Process_SafePoints(app);
			break;
		}
	case OP_SpawnAppearance:
		{
			this->ProcessOP_SpawnAppearance(app);
			break;
		}
	case OP_Death:
		{
			this->ProcessOP_Death(app);
			break;
		}
	case OP_MoveCoin: 
		{
			this->ProcessOP_MoveCoin(app); // slot 3 = trading
			break;
		}
	case OP_MoveItem: 
		{
			this->ProcessOP_MoveItem(app);
			break; 
		} 
	case OP_ConsumeItem:
		{
			this->ProcessOP_ConsumeItem(app);
			break; 
		} 
	case OP_Camp:
		{
			this->ProcessOP_Camp();
			break;
		}
	case OP_Mend:
		{
			this->ProcessOP_Mend();
			break;
		}
	case OP_Forage:
		{
			this->ProcessOP_Forage(app);
			break;
		}
	case OP_Beg:
		{
			this->ProcessOP_Beg(app);
			break;
		}
	case OP_Sneak:
		{
			this->ProcessOP_Sneak(app);
			break;
		}
	case OP_Hide:
		{
			this->ProcessOP_Hide(app);
			break;
		}
	case OP_SenseTraps:
		{
			this->Process_SenseTraps(app);
			break;
		}
	case OP_DisarmTraps:
		{
			this->Process_DisarmTraps(app);
			break;
		}
	case OP_InstillDoubt:
		{
			this->Process_InstillDoubt(app);
			break;
		}
	case OP_PickPockets:
		{
			this->ProcessOP_PickPockets(app);
			break;
		}
	case OP_SafeFallSuccess: 
		{
			this->ProcessOP_SafeFallSuccess(app);
			break;
		}
	case OP_Track: 
		{
			this->Process_Track(app);
			break;
		}
	case OP_ChannelMessage:
		{
			this->ProcessOP_ChannelMessage(app);
			break;
		}
	case OP_WearChange:
		{
			this->ProcessOP_WearChange(app);
			break;
		}
	case OP_Action:  // 13/10/2007 - froglok23 Added
		{
			this->Process_Action(app);
		}
		break;
	// 13/10/2007 - froglok23 - Added
	// 15/10/2007 - froglok23 - put in code to determin food or drink
	case OP_Consume: 
		{
			this->Process_Consume(app);
		}
		break;
	case OP_ENVDAMAGE2:
		{
			//DumpPacket(app);
			//cout << "OP_ENVDAMAGE2 size: " << app->size << endl;
			entity_list.QueueClients(this, app, false);
		}
		break;
	case OP_ZoneChange:
		{
			this->ProcessOP_ZoneChange(app);
			break;
		}
	case OP_DeleteSpawn:
		{
			this->ProcessOP_DeleteSpawn();
			break;
		}
	case OP_CraftingStation:
		{
			DumpPacket(app);
			this->ProcessOP_CraftingStation();
			break;
		}
	case 0x2a21:
	{
		QueuePacket(app); //rezurrections - Wizzel
		break;
	}
	case 0x4121:
	{
		QueuePacket(app); // console says shoudl be size 2
		break;
	}
	case 0x5521: 
		{ 
			// Client dumps player profile on zoning, is this same opcode as saving?
			if (app->size != sizeof(PlayerProfile_Struct) - PLAYERPROFILE_CHECKSUM_LENGTH) 
			{ 
				// DumpPacket(app);
				cout << "Wrong size on 0x5521. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) - PLAYERPROFILE_CHECKSUM_LENGTH << endl;
				Save();
				break;
			}
			//Cofruben: this packet has NO checksum at begining.
			EQC::Common::PrintF(CP_CLIENT, "Got a player save request (0x5521)\n");
			PlayerProfile_Struct* in_pp = (PlayerProfile_Struct*) (app->pBuffer - PLAYERPROFILE_CHECKSUM_LENGTH);

			x_pos = in_pp->x;
			y_pos = in_pp->y;
			z_pos = in_pp->z;
			heading = in_pp->heading;
			Save();
			break;
		}
	case OP_Save: 
		{
			// For easy playerprofile analysis -Wizzel
			//FileDumpPacket("player_profile.txt", app);
			this->ProcessOP_Save(app);
			break;
		}
	case OP_AutoAttack2: // Why 2
		{
			break;
		}
	case OP_WhoAll: // Pyro
		{
			this->ProcessOP_WhoAll(app);
			break;
		}
	case OP_GMZoneRequest: // Quagmire
		{
			this->ProcessOP_GMZoneRequest(app);
			break;
		}
	case OP_GMZoneRequest2: 
		{
			if (admin < 100 && !strcasecmp((char*) app->pBuffer, "gmhome"))
			{
				Message(BLACK, "GMHome is for GMs only");
			}
			else
			{
				this->MovePC((char*) app->pBuffer, -1, -1, -1);
			}
			break;
		}
	case OP_EndLootRequest:
		{
			this->ProcessOP_EndLootRequest(app);
			break;
		}
	case OP_LootRequest:
		{
			this->ProcessOP_LootRequest(app);
			break;
		}
	case OP_LootItem:
		{	
			this->ProcessOP_LootItem(app);
			break;
		}							
	case OP_GuildMOTD:
	case OP_GuildInvite:
	case OP_GuildInviteAccept:
	case OP_GuildRemove:
	case OP_GuildPeace:
	case OP_GuildWar:
	case OP_GuildLeader: 
		{
			zgm.Process(app, this);
			break;
		}
	case OP_MemorizeSpell: 
		{
			this->ProcessOP_MemorizeSpell(app);
			break; 
		}
	case OP_SwapSpell: 
		{
			this->ProcessOP_SwapSpell(app); 
			break; 
		}
	case OP_CastSpell:
		{
			this->ProcessOP_CastSpell(app);
			break;
		}

		// Pinedepain // In case this is a ManaChange, it means the bard has stopped a song
	case OP_ManaChange:
		{
			ProcessOP_ManaChange(app);
			break;
		}

			// Pinedepain //
	case OP_InterruptCast:
		{
			ProcessOP_InterruptCast(app);
			break;
		}
	case OP_Medding:
		{
			if (app->pBuffer[0])
				medding = true;
			else
				medding = false;
			break;
		}
		//heko: replaced the MonkAtk, renamed Monk_Attack_Struct
	case OP_CombatAbility:
		{
			this->ProcessOP_CombatAbility(app);
			break;
		}
		//heko: 
		//Packet length 4
		//0000: 00 00		NPC ID
	case OP_Taunt:
		{
			this->ProcessOP_Taunt(app);
			break;
		}

	/*case OP_UseAbility:
		{
			this->ProcessOP_UseAbility(app);
			break;
		}
	*/
	case OP_GMSummon:
		{
			this->ProcessOP_GMSummon(app);
			break;
		}
	case OP_GiveItem: 
		{
			this->ProcessOP_GiveItem(app);
			break;
		}
	case OP_TradeAccepted:
		{
			this->ProcessOP_TradeAccepted(app);
			break;
		}
	case OP_DropItem:
		{
			this->ProcessOP_DropItem(app);
			break;
		}
	case OP_DropCoin:
		{
			this->ProcessOP_DropCoin(app);
			break;
		}
	case OP_PickupItem:
		{
			this->ProcessOP_PickupItem(app);
			break;
		}
	case OP_CancelTrade:
		{
			this->ProcessOP_CancelTrade(app);
			break;
		}
	case OP_Click_Give:
		{
			this->ProcessOP_Click_Give(app);
			break;
		}
	case OP_SplitMoney:
		{
			this->ProcessOP_SplitMoney(app);
			break;
		}
	case OP_Random: 
		{
			this->ProcessOP_Random(app);
			break;
		}
	case OP_Buff: 
		{
			this->ProcessOP_Buff(app);
			break;
		}
	case OP_GMHideMe: 
		{
			this->ProcessOP_GMHideMe(app);
			break;
		}
	case OP_GMNameChange: 
		{
			this->ProcessOP_GMNameChange(app);
			break;
		}
	case OP_GMKill:
		{
			this->ProcessOP_GMKill(app);
			break;
		}
	case OP_GMSurname: 
		{
			this->ProcessOP_GMSurname(app);
			break;
		}
	case OP_GMToggle:
		{
			this->ProcessOP_GMToggle(app);
			break;
		}
	case OP_LFG: 
		{
			this->ProcessOP_LFG(app);
			break;
		}
	case OP_SenseHeading:
		{
			// Nothing needs to be done here AFAIK. Client handles sense heading correctly. - Wizzel
			CheckAddSkill(SENSE_HEADING);
			break;
		}
	case OP_GMGoto:
		{
			this->ProcessOP_GMGoto(app);
			break;
		}
		/*
		0 is e7 from 01 to
		1 is 03
		2 is 00
		3 is 00
		4 is ??
		5 is ??
		6 is 00 from a0 to
		7 is 00 from 3f to */			
	case OP_ShopRequest: 
		{
			this->ProcessOP_ShopRequest(app);
			break;
		}
	case OP_ShopPlayerBuy: 
		{
			this->ProcessOP_ShopPlayerBuy(app);
			break;
		}
	case OP_ShopPlayerSell: 
		{
			this->ProcessOP_ShopPlayerSell(app);
			break;
		}
	case OP_ShopEnd: 
		{
			this->Process_ShoppingEnd(app);
			break; 
		}
	case OP_ClassTraining:
		{
			this->ProcessOP_ClassTraining(app);
			break;
		}
	case OP_ClassEndTraining:
		{
			this->ProcessOP_ClassEndTraining(app);
			break;
		}
	case OP_ClassTrainSkill:
		{
			this->ProcessOP_ClassTrainSkill(app);
			break;
		}
	case OP_GroupInvite: 
		{
			this->ProcessOP_GroupInvite(app);
			break;
		}
	case OP_BackSlashTarget:
		{
			this->ProcessOP_BackSlashTarget(app);
			break;
		}
	case OP_GroupFollow: 
		{
			this->ProcessOP_GroupFollow(app);
			break;
		}
	case OP_GroupDeclineInvite:				//Client clicks disband after receiving an invite; 
		{
			this->ProcessOP_GroupDeclineInvite(app);
			break;
		}
	case OP_GroupDelete:					//Only comes when a group leader disbands himself;
		{
			if (this->IsGrouped() && entity_list.GetGroupByClient(this) != 0){
				entity_list.GetGroupByClient(this)->DisbandGroup();
			}
			break;
		}
	case OP_GroupQuit:						//When member disbands himself or leader kicks him;
		{
			this->ProcessOP_GroupQuit(app);
			break;
		}
	case OP_GMEmoteZone: 
		{
			this->ProcessOP_GMEmoteZone(app);			
			break;
		}
	case OP_InspectRequest: 
		{
			this->ProcessOP_InspectRequest(app);
			break; 
		}  
	case OP_InspectAnswer: 
		{ 
			this->ProcessOP_InspectAnswer(app);
			break; 
		} 
	case OP_Petition: 
		{
			this->ProcessOP_Petition(app);
			break;
		}
	case OP_PetitionCheckIn: 
		{
			this->ProcessOP_PetitionCheckIn(app);
			break;
		}
	case OP_PetitionDelete: 
		{
			this->ProcessOP_PetitionDelete(app);
			break;
		}
	case OP_PetitionCheckout: 
		{
			this->ProcessOP_PetitionCheckout(app);
			break;
		}
	case OP_PetitionRefresh: 
		{
			// This is When Client Asks for Petition Again and Again...
			// break is here because it floods the zones and causes lag if it
			// Were to actually do something:P  We update on our own schedule now.
			break;
		}
	case OP_BugReport: 
		{
			this->ProcessOP_BugReport(app);
			break;
		}
	case OP_TradeSkillCombine: 
		{
			this->ProcessOP_TradeSkillCombine(app);
			break;
		}
	case OP_ReadBook: 
		{
			this->ProcessOP_ReadBook(app);
			break;
		}
	case OP_Social_Text:
		{
			this->ProcessOP_Social_Text(app);
			break;
		}
	case OP_Social_Action: 
		{
			cout << "Social Action:  " << app->size << endl;
			//DumpPacket(app);
			entity_list.QueueCloseClients(this, app, true);
			break;
		}
	case OP_SetServerFilter: 
		{
			/*	APPLAYER* outapp = new APPLAYER;
			outapp = new APPLAYER;
			outapp->opcode = OP_SetServerFilterAck;
			outapp->size = sizeof(SetServerFilterAck_Struct);
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			QueuePacket(outapp);
			safe_delete(outapp);//delete outapp;*/
			break;
		}
	case OP_GMDelCorpse: 
		{
			this->ProcessOP_GMDelCorpse(app);
			break;
		}
	case OP_GMKick: 
		{
			this->ProcessOP_GMKick(app);
			break;
		}
	case OP_GMServers: 
		{
			this->ProcessOP_GMServers(app);
			break;
		}
	case OP_MovementUpdate: // DB - Noticed this was going unknown opcode between run/walk
		{
			break;
		}
	case OP_Fishing:
		{
			this->ProcessOP_Fishing(app);
			break;
		}
	case OP_BindWound:
		{
			if (app->size != sizeof(BindWound_Struct)){
				cout<<"Size mismatch for Bind wound packet"<<endl;
				DumpPacket(app);
			}
			BindWound_Struct* bind_in = (BindWound_Struct*) app->pBuffer;
			Mob* bindmob = entity_list.GetMob(bind_in->to);
			if (!bindmob){
				cout<<"Bindwound on non-exsistant mob from "<<this->GetName()<<endl;
			}
			cout<<"BindWound in: to: "<<bindmob->GetName()<<" from= "<< GetName()<<endl;
			BindWound(bindmob, true);
			break;
		}
	case OP_ClickDoor:
		{
			//DumpPacketHex(app);
			this->ProcessOP_ClickDoor(app);
			break;
		}
	case OP_GetOnBoat:
		{
			this->ProcessOP_GetOnBoat(app);
			break;
		}
	case OP_GetOffBoat:
		{
			this->ProcessOP_GetOffBoat(app);
			break;
		}
	case OP_CommandBoat:
		{
			this->ProcessOP_CommandBoat(app);
			break;
		}
	case 0x0821: //Yeahlight: Player touches a bulletin board
		{
			DumpPacketHex(app);
			break;
		}
	case OP_Illusion:
		{
			DumpPacketHex(app); //hex workaround testing -Wizzel
			break;
		}
	case OP_GMBecomeNPC:
		{
			this->ProcessOP_GMBecomeNPC(app);
			break;
		}	
	case 0x2921: // 13/10/2007 - froglok23 - UNKNOWN
	default:
		{
			this->Process_UnknownOpCode(app);
			break;
		}
	}
}

#endif


/** Replaces the original ProcessOpcode without the switch statement. */
void Client::ProcessOpcode(APPLAYER* app)
{
	////Cofruben: for debugging purposes.
	////****
	//if(app->opcode != 62240)
	//{
	//	cout << "Opcode: " << app->opcode << endl;
	//	DumpPacketHex(app);
	//}
	////****
	(this->*process_opcode_array[app->opcode])(app);
}


/** Initializes the function array that processes opcodes by the opcode index number.*/
void Client::InitProcessArray()
{
	for(int i=0;i<0xFFFF;i++){
		process_opcode_array[i] = &Client::ProcessOP_Default;
	}
	
	process_opcode_array[OP_AutoAttack]		= &Client::ProcessOP_AutoAttack;
	process_opcode_array[OP_FeignDeath]		= &Client::ProcessOP_FeignDeath;
	process_opcode_array[OP_DuelResponse]	= &Client::ProcessOP_DuelResponse;
	process_opcode_array[OP_DuelResponse2]	= &Client::ProcessOP_DuelResponse2;
	process_opcode_array[OP_RequestDuel]	= &Client::ProcessOP_RequestDuel;
	process_opcode_array[OP_AutoAttack]		= &Client::ProcessOP_AutoAttack;
	process_opcode_array[OP_AutoAttack]		= &Client::ProcessOP_AutoAttack;
	process_opcode_array[OP_ClientUpdate]	= &Client::ProcessOP_ClientUpdate;
	process_opcode_array[OP_ClientTarget]	= &Client::ProcessOP_ClientTarget;
	process_opcode_array[OP_Jump]			= &Client::Process_Jump;
	process_opcode_array[OP_AssistTarget]	= &Client::ProcessOP_AssistTarget;
	process_opcode_array[OP_Consider]		= &Client::ProcessOP_Consider;
	process_opcode_array[OP_Surname]		= &Client::ProcessOP_Surname;
	process_opcode_array[OP_YellForHelp]	= &Client::ProcessOP_YellForHelp;
	process_opcode_array[OP_SpawnAppearance]= &Client::ProcessOP_SpawnAppearance;
	process_opcode_array[OP_Death]			= &Client::ProcessOP_Death;
	process_opcode_array[OP_MoveCoin]		= &Client::ProcessOP_MoveCoin;
	process_opcode_array[OP_MoveItem]		= &Client::ProcessOP_MoveItem;
	process_opcode_array[OP_ConsumeItem]	= &Client::ProcessOP_ConsumeItem;
	process_opcode_array[OP_Forage]			= &Client::ProcessOP_Forage;
	process_opcode_array[OP_Beg]			= &Client::ProcessOP_Beg;
	process_opcode_array[OP_Sneak]			= &Client::ProcessOP_Sneak;
	process_opcode_array[OP_Hide]			= &Client::ProcessOP_Hide;
	process_opcode_array[OP_SenseTraps]		= &Client::Process_SenseTraps;
	process_opcode_array[OP_DisarmTraps]	= &Client::Process_DisarmTraps;
	process_opcode_array[OP_InstillDoubt]	= &Client::Process_InstillDoubt;
	process_opcode_array[OP_PickPockets]	= &Client::ProcessOP_PickPockets;
	process_opcode_array[OP_SafeFallSuccess]= &Client::ProcessOP_SafeFallSuccess;
	process_opcode_array[OP_Track]			= &Client::Process_Track;
	process_opcode_array[OP_ChannelMessage]	= &Client::ProcessOP_ChannelMessage;
	process_opcode_array[OP_WearChange]		= &Client::ProcessOP_WearChange;
	process_opcode_array[OP_Action]			= &Client::Process_Action;
	process_opcode_array[OP_Consume]		= &Client::Process_Consume;
	process_opcode_array[OP_ZoneChange]		= &Client::ProcessOP_ZoneChange;
	process_opcode_array[OP_Camp]			= &Client::ProcessOP_Camp;
	process_opcode_array[OP_DeleteSpawn]	= &Client::ProcessOP_DeleteSpawn;
	process_opcode_array[OP_Mend]			= &Client::ProcessOP_Mend;
	process_opcode_array[OP_Save]			= &Client::ProcessOP_Save;
	process_opcode_array[OP_Taunt]			= &Client::ProcessOP_Taunt;
	//process_opcode_array[OP_UseAbility]		= &Client::ProcessOP_UseAbility;
	process_opcode_array[OP_GMSummon]		= &Client::ProcessOP_GMSummon;
	process_opcode_array[OP_GiveItem]		= &Client::ProcessOP_GiveItem;
	process_opcode_array[OP_TradeAccepted]	= &Client::ProcessOP_TradeAccepted;
	process_opcode_array[OP_DropItem]		= &Client::ProcessOP_DropItem;
	process_opcode_array[OP_DropCoin]		= &Client::ProcessOP_DropCoin;
	process_opcode_array[OP_PickupItem]		= &Client::ProcessOP_PickupItem;
	process_opcode_array[OP_CancelTrade]	= &Client::ProcessOP_CancelTrade;
	process_opcode_array[OP_Click_Give]		= &Client::ProcessOP_Click_Give;
	process_opcode_array[OP_SplitMoney]		= &Client::ProcessOP_SplitMoney;
	process_opcode_array[OP_Random]			= &Client::ProcessOP_Random;
	process_opcode_array[OP_Buff]			= &Client::ProcessOP_Buff;
	process_opcode_array[OP_GMHideMe]		= &Client::ProcessOP_GMHideMe;
	process_opcode_array[OP_GMNameChange]	= &Client::ProcessOP_GMNameChange;
	process_opcode_array[OP_GMKill]			= &Client::ProcessOP_GMKill;
	process_opcode_array[OP_GMSurname]		= &Client::ProcessOP_GMSurname;
	process_opcode_array[OP_GMToggle]		= &Client::ProcessOP_GMToggle;
	process_opcode_array[OP_LFG]			= &Client::ProcessOP_LFG;
	process_opcode_array[OP_WhoAll]			= &Client::ProcessOP_WhoAll;
	process_opcode_array[OP_GMZoneRequest]	= &Client::ProcessOP_GMZoneRequest;
	process_opcode_array[OP_EndLootRequest]	= &Client::ProcessOP_EndLootRequest;
	process_opcode_array[OP_LootRequest]	= &Client::ProcessOP_LootRequest;
	process_opcode_array[OP_LootItem]		= &Client::ProcessOP_LootItem;
	process_opcode_array[OP_MemorizeSpell]	= &Client::ProcessOP_MemorizeSpell;
	process_opcode_array[OP_SwapSpell]		= &Client::ProcessOP_SwapSpell;
	process_opcode_array[OP_CastSpell]		= &Client::ProcessOP_CastSpell;
	process_opcode_array[OP_ManaChange]		= &Client::ProcessOP_ManaChange;
	process_opcode_array[OP_InterruptCast]	= &Client::ProcessOP_InterruptCast;
	process_opcode_array[OP_ShopRequest]	= &Client::ProcessOP_ShopRequest;
	process_opcode_array[OP_ShopPlayerBuy]	= &Client::ProcessOP_ShopPlayerBuy;
	process_opcode_array[OP_ShopPlayerSell]	= &Client::ProcessOP_ShopPlayerSell;
	process_opcode_array[OP_ShopEnd]		= &Client::Process_ShoppingEnd;
	process_opcode_array[OP_ClassTraining]	= &Client::ProcessOP_ClassTraining;
	process_opcode_array[OP_ClassEndTraining]	= &Client::ProcessOP_ClassEndTraining;
	process_opcode_array[OP_ClassTrainSkill]	= &Client::ProcessOP_ClassTrainSkill;
	process_opcode_array[OP_GroupInvite]		= &Client::ProcessOP_GroupInvite;
	process_opcode_array[OP_BackSlashTarget]	= &Client::ProcessOP_BackSlashTarget;
	process_opcode_array[OP_GroupFollow]		= &Client::ProcessOP_GroupFollow;
	process_opcode_array[OP_GroupDeclineInvite]	= &Client::ProcessOP_GroupDeclineInvite;
	process_opcode_array[OP_GroupQuit]			= &Client::ProcessOP_GroupQuit;
	process_opcode_array[OP_GMEmoteZone]		= &Client::ProcessOP_GMEmoteZone;
	process_opcode_array[OP_InspectRequest]		= &Client::ProcessOP_InspectRequest;
	process_opcode_array[OP_InspectAnswer]		= &Client::ProcessOP_InspectAnswer;
	process_opcode_array[OP_Petition]			= &Client::ProcessOP_Petition;
	process_opcode_array[OP_PetitionCheckIn]	= &Client::ProcessOP_PetitionCheckIn;
	process_opcode_array[OP_PetitionDelete]		= &Client::ProcessOP_PetitionDelete;
	process_opcode_array[OP_PetitionCheckout]	= &Client::ProcessOP_PetitionCheckout;
	process_opcode_array[OP_BugReport]			= &Client::ProcessOP_BugReport;
	process_opcode_array[OP_TradeSkillCombine]	= &Client::ProcessOP_TradeSkillCombine;
	process_opcode_array[OP_ReadBook]			= &Client::ProcessOP_ReadBook;
	process_opcode_array[OP_Social_Text]		= &Client::ProcessOP_Social_Text;
	process_opcode_array[OP_GMDelCorpse]	= &Client::ProcessOP_GMDelCorpse;
	process_opcode_array[OP_GMKick]			= &Client::ProcessOP_GMKick;
	process_opcode_array[OP_GMServers]		= &Client::ProcessOP_GMServers;
	process_opcode_array[OP_Fishing]		= &Client::ProcessOP_Fishing;
	process_opcode_array[OP_ClickDoor]		= &Client::ProcessOP_ClickDoor;
	process_opcode_array[OP_GetOnBoat]		= &Client::ProcessOP_GetOnBoat;
	process_opcode_array[OP_GetOffBoat]		= &Client::ProcessOP_GetOffBoat;
	process_opcode_array[OP_CommandBoat]	= &Client::ProcessOP_CommandBoat;
	process_opcode_array[OP_BindWound]		= &Client::ProcessOP_BindWound;
	process_opcode_array[OP_MBRetrieveMessages]	= &Client::ProcessOP_MBRetrieveMessages;
	process_opcode_array[OP_MBPostMessage]	= &Client::ProcessOP_MBPostMessage;
	process_opcode_array[OP_MBEraseMessage]	= &Client::ProcessOP_MBEraseMessage;
	process_opcode_array[OP_MBRetrieveMessage]	= &Client::ProcessOP_MBRetrieveMessage;	
	process_opcode_array[OP_UseDiscipline]	= &Client::ProcessOP_UseDiscipline;
	process_opcode_array[OP_Translocate]	= &Client::ProcessOP_TranslocateResponse;	
	process_opcode_array[OP_ClientError]	= &Client::ProcessOP_ClientError;
	process_opcode_array[OP_ApplyPoison]	= &Client::ProcessOP_ApplyPoison;
	
}