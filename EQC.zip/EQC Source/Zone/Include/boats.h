#ifndef BOATS_H
#define BOATS_H

#include <vector>
#include "client.h"

//This file will fill up as I keep going with boats. For now, it is kinda pointless :p


using std::vector;

 //vector <char*> boatlist; //When uncommented, gives weird link errors.

#endif