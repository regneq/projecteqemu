#ifndef FORAGE_H
#define FORAGE_H
#include "types.h"

#define MAX_COMMON_FOOD_IDS 7

uint32 ForageItem(char CurrentZone[], int8 skill_level);

#endif
