// ***************************************************************
//  Petition Manager   �  date: 16/05/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// This class is for use with handling peitions
// ***************************************************************

#ifndef PETITIONMANAGER_H
#define PETITIONMANAGER_H

namespace EQC
{
	namespace Zone
	{
		class PetitionManager 
		{
		public:
			PetitionManager();
			~PetitionManager();
			
		protected:

		private:
		};
	}
}


#endif