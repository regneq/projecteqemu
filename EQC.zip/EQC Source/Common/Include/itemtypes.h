// ***************************************************************
//  EQCException   �  date: 18/7/2007
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
// These contain the item types for more labeled item/stack management.
// ***************************************************************

#ifndef ITEMTYPES_H
#define ITEMTYPES_H

#ifdef WIN32
	#include <process.h>
	#include <windows.h>
	#include <winsock.h>
#endif

// These are the item types for our client. These are used in managing stackable items.
// They should all be correct. Some of the latter ones may not be used. - Wizzel

#define ONE_HAND_SLASHING		0
#define TWO_HAND_SLASHING		1
#define ONE_HAND_PIERCING		2
#define ONE_HAND_BLUNT			3
#define TWO_HAND_BLUNT			4
#define BOW						5
#define THROWN					7 // This seems to be wrong in the database. Things like Throwing Axes don't stack. -Wizzel
#define SHIELD					8
#define ARMOR					10
#define NONSTACKABLE_ITEM		11
#define LOCKPICK				12
#define	FOOD					14
#define DRINK					15
#define LIGHT_SOURCE			16
#define STACKABLE_ITEM			17
#define BANDAGES				18
#define THROWING_KNIFE			19
#define SPELL					20
#define POTION					21
#define WIND_INSTRUMENT			23
#define STRING_INSTRUMENT		24
#define BRASS_INSTRUMENT		25
#define PERCUSSION_INSTRUMENT	26
#define ARROWS					27
#define JEWELRY					29
#define JEWELED_SKULL			30
#define SPECIAL_NOTE			32
#define KEY_USABLE				33
#define COIN					34
#define TWO_HAND_PIERCING		35
#define FISHING_POLE			36
#define FISHING_BAIT			37
#define ALCOHOL					38
#define KEY_QUEST				39

//Not sure about these.
#define COMPASS					40
#define POSION					42
#define HAND_TO_HAND_WEAPON		45
#define HANDMADE_BACKPACK		98
#define TAILORED_LARGE_BAG		211

#endif