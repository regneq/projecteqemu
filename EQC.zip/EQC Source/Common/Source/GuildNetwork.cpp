#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <errmsg.h>

#include "config.h"
#include "EQCUtils.hpp"
#include "GuildNetwork.h"


namespace EQC
{
	namespace Common
	{
		namespace Network
		{
		}
	}
}