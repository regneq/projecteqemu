EQEMu 0.1.5 /*Windows Version*\
http://emu.hackersrealm.net/


Installation of MySQL DB:----------------------------------------
-----------------------------------------------------------------
1) Setup a MySQL Server
2) Execute "mysqladmin create eq"
3) In the EQEmu source directory type "mysql eq < db.sql" and press enter.
4) Setup db.ini with the proper information.
5) Open up dreadlands.bat and setup the bat file like shown:

	zone dreadlands 127.0.0.1 7999 127.0.0.1
        N/A   zonename   zoneip   port  worldip

6) Run world.exe in the main folder.
7) Default zone is set at dreadlands, so run dreadlands.bat
Read the bottom of the page if you wish to change the startzone.
-----------------------------------------------------------------
-----------------------------------------------------------------


Whats New:-------------------------------------------------------
-----------------------------------------------------------------
- Item saving implemented!
- Remote console added (Port 9000 listening on world)
- Client HP updating *fixed*
- Druid class regen *fixed*
- Guilds implemented (new command - #guild)
- Zone start/safepoints are now definable in the database.
- (Real GM "/" commands are being implemented)
- Check #help for additional commands
- There are database changes! Please use the new DB included.
-----------------------------------------------------------------
NOTE: Corpse decay was delayed until the next release
-----------------------------------------------------------------


The default account for testing is:------------------------------
-----------------------------------------------------------------
Username: eqemu
Password: eqemu
-----------------------------------------------------------------
-----------------------------------------------------------------


Editable Items:--------------------------------------------------
-----------------------------------------------------------------

If you want to create a account with GM status, in MySQL type:

INSERT INTO ACCOUNT NAME='username', password='userpassword', status='status';

Status Listing: 0 = Normal, 1 = GM, 2 = Lead GM

-----------------------------------------------------------------

If you want to change your start zone in MySQL type:

UPDATE variables SET value='dreadlands' WHERE varname='startzone';

Replacing dreadlands with the zone you want to run.

-----------------------------------------------------------------

If you want to change the MOTD, in MySQL type:

UPDATE variables SET value='test' WHERE varname='MOTD';

Replacing test with the MOTD you want.
-----------------------------------------------------------------
-----------------------------------------------------------------