#include <iostream.h>
#include <string.h>

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQPacket.h"
#include "../common/EQPacketManager.h"
#include "net.h"
#include "client.h"
#include "../common/database.h"
#ifdef BUILD_FOR_WINDOWS
	#include <process.h>
#else
	#include <pthread.h>
#endif
#include "zoneserver.h"
#include "console.h"


NetConnection net;
ClientList client_list;
ZSList zoneserver_list;
volatile bool ShutdownLoops = false;
uint32 numclients = 0;
uint32 numzones = 0;

#ifdef BUILD_FOR_WINDOWS
	Database database;
#else
	Database database("localhost", "user", "pw", "eq");
#endif

int main()
{
	InitTCP();
	net.Init();

	cout << "World server listening on port:" << PORT << endl;
		

	#ifdef BUILD_FOR_WINDOWS
		_beginthread(ConsoleLoop, 0, NULL);
		_beginthread(ZoneServerLoop, 0, NULL);

		while(!ShutdownLoops)
		{
			Timer::SetCurrentTime();
			net.ListenNewClients();
			if (numclients == 0)
			{
				Sleep(10);
				continue;
			}
			Sleep(1);
			client_list.Process();
		}
	#else
		pthread_t thread;
		pthread_create(&thread, NULL, ConsoleLoop, NULL)
		pthread_create(&thread, NULL, ZoneServerLoop, NULL)
		while(!ShutdownLoops)
		{
			Timer::SetCurrentTime();
			net.ListenNewClients();
			client_list.Process();
			Sleep(1);
		}
	#endif
}
	

bool NetConnection::Init()
{
	struct sockaddr_in address;
	int reuse_addr = 1;
	
	// Disgrace: for windows compile
	#ifdef BUILD_FOR_WINDOWS
		unsigned long nonblocking = 1;
		WORD version = MAKEWORD (1,1);
		WSADATA wsadata;
	#endif

	WSAStartup (version, &wsadata);

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up UDP port for new clients */
	listening_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (listening_socket < 0) 
 	{
	
		return false;
	}

	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));
	#else
		setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse_addr, sizeof(reuse_addr));
	#endif

	if (bind(listening_socket, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
		// Disgrace: for windows compile
		#ifdef BUILD_FOR_WINDOWS
			closesocket(listening_socket);
		#else
			close(listening_socket);
		#endif
		
		return false;
	}

	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		fcntl(listening_socket, F_SETFL, O_NONBLOCK);
	#else
		ioctlsocket (listening_socket, FIONBIO, &nonblocking);
	#endif


	return true;
}

void NetConnection::ListenNewClients()
{
	
    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		status = recvfrom(listening_socket, &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, &fromlen);
	#else
		status = recvfrom(listening_socket, (char *) &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, (int *) &fromlen);
	#endif

    if (status > 1)
    {
		Client* client = 0;

		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		client = client_list.Get(in.s_addr, from.sin_port);
		if (client == 0)
		{
			// If it is a new client make sure it has the starting flag set. Ignore otherwise
            if (buffer[0] & 0x20)
			{
				cout << Timer::GetCurrentTime() << " New client from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << endl;
			    client = new Client(in.s_addr, port, listening_socket);
			    client_list.Add(client);
				numclients++;
			}
			else
			{
				return;
			}
		}
		else
		{
//			cout << Timer::GetCurrentTime() << " Data from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << " length: " << status << endl;
		}
		client->ReceiveData(buffer, status);
    }
}
