#ifndef CLIENT_H
#define CLIENT_H

#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/EQPacketManager.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/database.h"
#include "errno.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "mob.h"
#include "npc.h"
#include "zone.h"
#include "../common/Seperator.h"

extern Database database;
extern EntityList entity_list;
extern Zone* zone;

#define CLIENT_TIMEOUT 90000

#define CLIENT_CONNECTING1 0
#define CLIENT_CONNECTING2 1
#define CLIENT_CONNECTING3 2
#define CLIENT_CONNECTING4 3
#define CLIENT_CONNECTING5 4
#define CLIENT_CONNECTED   5
#define CLIENT_KICKED	   6

class Client : public Mob
{
public:
	Client(int32 ip, int16 port, int send_socket);
    ~Client();

	virtual bool IsClient() { return true; }

	
	virtual bool Process();
	void ReceiveData(uchar* buf, int len);

	void ChannelMessageReceived(int8 chan_num, int8 language, char* message, char* targetname);
//	void ChannelMessageReceived(int8 chan_num, int8 language, char* message);
	void ChannelMessageSend(char* from, char* to, int8 chan_num, int8 language, char* message, ...);
	void Message(int32 type, char* message, ...);

	int32 GetIP()    { return ip; }
	int16 GetPort()  { return port; }

	void QueuePacket(APPLAYER* app);
	bool Save();

	bool Connected() { return (client_state == CLIENT_CONNECTED); }
	void Kick() { client_state = CLIENT_KICKED; }

	void Attack(Mob* other);
	void Heal(Mob* other, int32 damage, int16 spell_id);
	void Damage(Mob* other, int32 damage, int16 spell);
	void Death(Mob* other, int32 damage, int16 spell);

	void SendHPUpdate();
	void SetMaxHP();

	int8 GetRace()    { return pp.race; }
	int8 GetClass()   { return pp.class_; }
	int8 GetGender()  { return pp.gender; }
	int8 GetLevel()   { return pp.level; }
	int16 GetHP()     { return pp.cur_hp; }

	int8 GetBaseSTR() { return pp.STR; }
	int8 GetBaseSTA() { return pp.STA; }
	int8 GetBaseCHA() { return pp.CHA; }
	int8 GetBaseDEX() { return pp.DEX; }
	int8 GetBaseINT() { return pp.INT; }
	int8 GetBaseAGI() { return pp.AGI; }
	int8 GetBaseWIS() { return pp.WIS; }
	int8 GetLanguageSkill(int8 n) { return pp.languages[n]; }

	int8 GetSTR() { return GetBaseSTR(); }
	int8 GetSTA() { return GetBaseSTA(); }
	int8 GetCHA() { return GetBaseCHA(); }
	int8 GetDEX() { return GetBaseDEX(); }
	int8 GetINT() { return GetBaseINT(); }
	int8 GetAGI() { return GetBaseAGI(); }
	int8 GetWIS() { return GetBaseWIS(); }

	uint32 GetEXP() { return pp.exp; }

	void SetHP(uint16 hp) { pp.cur_hp = hp; }

	uint16 GetMaxHP(); // TODO: Save max_hp in variable and recalc when needed instead?

	void AddEXP(uint32 add_exp);
	void SetEXP(uint32 set_exp);
	virtual void SetLevel(uint16 set_level);
	void MovePC(sint16 move_x, sint16 move_y, sint16 move_z);
	void ZonePC(char* zonename, sint16 x, sint16 y, sint16 z);
	void WhoAll();


	int8 GetSkill(int skill_num);
	int16 GetRawItemAC();
	int16 GetCombinedAC_TEST();

	int32 GetAccountID() { return account_id; }
	char* GetAccountName() { return account_name; }
	int8 Admin() { return admin; }
	void UpdateWho(bool remove);
	int32 GuildEQID() { return guildeqid; }
	int32 GuildDBID() { return guilddbid; }
	int8 GuildRank() { return guildrank; }
	bool SetGuild(int32 in_guilddbid, int8 in_rank);

    // Disgrace: currently set from database.CreateCharacter. 
	// Need to store in proper position in PlayerProfile...
	int8 GetFace() { return pp.pp_unknown2[0]; } 
	int16 GetMaxMana();
private:
	int32            ip;
	int16            port;
	int8             client_state;
	int              send_socket;
	CEQPacketManager packet_manager;
	Timer*           timeout_timer;
	int32			 character_id;
	int32            account_id;
	char			 account_name[30];
	int8			 admin;
	int32			 guilddbid; // guild's ID in the database
	int8			 guildrank; // player's rank in the guild, 0-GUILD_MAX_RANK

	bool             auto_attack;

	PlayerProfile_Struct pp;

	void GuildCommand(Seperator sep);
	bool GuildEditCommand(int32 dbid, int32 eqid, int8 rank, char* what, char* value);
	uint32 GetEXPForLevel(uint16 level);

	//Disgrace: make due for now...
	char GetCasterClass() { return 'I'; }
};

#endif

