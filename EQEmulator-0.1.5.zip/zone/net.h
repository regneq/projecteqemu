#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
	#include <netdb.h>
#endif


#include <errno.h>
#include <fcntl.h>
#include "../common/types.h"

bool ZoneBootup(char* zone_name);
void ZoneShutdown();
void CatchSignal(int);

class NetConnection
{
public:
	bool Init();
	void ListenNewClients();

	int32 NetConnection::GetIP();
	int32 NetConnection::GetIP(char* name);
	void Close();
	void SaveInfo(char* address, int32 port, char* waddress);
	char* GetWorldAddress() { return WorldAddress; }
	char* GetZoneAddress() { return ZoneAddress; }
	int32 GetZonePort() { return ZonePort; }
	NetConnection::~NetConnection();
	NetConnection::NetConnection() { ZonePort = 0; ZoneAddress = 0; WorldAddress = 0; };

private:
	int listening_socket;
	int16 ZonePort;
	char* ZoneAddress;
	char* WorldAddress;
};
