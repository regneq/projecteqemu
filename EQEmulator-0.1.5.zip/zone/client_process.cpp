#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
//#include "../common/packet_dumpfile.h"

extern GuildRanks_Struct guilds[512];

bool Client::Process()
{
	if (client_state == CLIENT_KICKED)
		return false;

	if (Connected())
	{
		if (auto_attack && target != 0 && attack_timer->Check())
		{
			if (DistNoRootNoZ(target) > 10*10)
			{
				Message(13,"Your target is too far away, get closer!");
			}
			else if (target == this)
			{
				Message(13,"Try attacking someone else then yourself!");
			}
/*			else if (CantSee(target))
			{
				Message(13,"You can't see your target from here.");				
			}*/
			else if (target->GetHP() > 0)
			{
				Attack(target);
			}
		}
		if (regen_timer->Check())
		{
			int16 max_hp = GetMaxHP();
			if (GetHP() < max_hp) // TODO: Get regen/tick confirmed
			{
				if (appearance == 1) // If we are sitting
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+4);
						else if (GetLevel() < 50)
							SetHP(GetHP()+6);
						else
							SetHP(GetHP()+12);
					}
					else
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+2);
						else if (GetLevel() < 50)
							SetHP(GetHP()+3);
						else if (GetLevel() < 51)
							SetHP(GetHP()+4);
						else
							SetHP(GetHP()+5);
					}
				}
				else
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+1);
						else if (GetLevel() < 50)
							SetHP(GetHP()+2);
						else
							SetHP(GetHP()+4);
					}
					else
					{
						if (GetLevel() < 51)
							SetHP(GetHP()+1);
						else
							SetHP(GetHP()+2);
					}
				}
				if (GetHP() > max_hp)
					SetHP(max_hp);
				SendHPUpdate();
			}
		}
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(app = packet_manager.OutQueue.pop())
	{
		switch(client_state)
		{
			case CLIENT_CONNECTING1:
			{
				if (app->opcode == 0xe821)
				{
					cout << "Login packet 1" << endl;
//					DumpPacket(app);
					client_state = CLIENT_CONNECTING2;
				}
				break;
			}
			case CLIENT_CONNECTING2: {
				if (app->opcode == OP_ZoneEntry)
				{
					cout << "Login packet 2" << endl;
//					DumpPacket(app);

					// Quagmire - Antighost code
					// tmp var is so the search doesnt find this object
					char tmp[16];
					strncpy(tmp, (char*)&app->pBuffer[4], 16);
					Client* client = entity_list.GetClientByName(tmp);
					strncpy(name, (char*)&app->pBuffer[4], 16);
					account_id = database.GetAuthentication(name, zone->GetShortName(), ip);
					if (account_id == 0)
					{
						cout << "Client dropped: GetAuthentication = 0, n=" << tmp << endl;
						return false; // TODO: Can we tell the client to get lost in a good way
					}
					if (client != 0)
						client->Kick();  // Bye Bye ghost

					admin = database.CheckStatus(account_id);
					database.GetAccountName(account_id, account_name);
					database.GetCharacterInfo(name, &character_id, &guilddbid, &guildrank);
					guildeqid = database.GetGuildEQID(guilddbid);
					if (guildeqid == 0xFFFFFFFF) {
						guilddbid = 0;
						guildrank = GUILD_MAX_RANK;
					}


					if (!database.GetPlayerProfile(account_id, name, &pp))
					{
						cout << "Client dropped: !GetPlayerProfile, n=" << tmp << endl;
						return false;
					}

					strcpy(lastname, pp.last_name); 
					x_pos = (sint16)(pp.x);
					y_pos = (sint16)(pp.y);
					z_pos = (sint16)(pp.z); // FIXME: z seems wrong
					heading = pp.heading;
					race = pp.race;
					class_ = pp.class_;
					gender = pp.gender;
					level = pp.level;
					cur_hp = pp.cur_hp;
					max_hp = pp.cur_hp; // TODO: How do we calculate max hp
					pp.inventory[0] = 0xffff; // Inventory

					SetEQChecksum((unsigned char*)&pp, sizeof(PlayerProfile_Struct));

					APPLAYER *outapp;
					outapp = new APPLAYER;				
					outapp->opcode = OP_PlayerProfile;		
					outapp->pBuffer = new uchar[5000];
					outapp->size = DeflatePacket((unsigned char*)&pp, sizeof(PlayerProfile_Struct), outapp->pBuffer, 5000);
					EncryptProfilePacket(outapp);
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_ZoneEntry;
					outapp->pBuffer = new uchar[sizeof(ServerZoneEntry_Struct)];
		   			outapp->size = sizeof(ServerZoneEntry_Struct);
					memset(outapp->pBuffer, 0, sizeof(ServerZoneEntry_Struct));
					ServerZoneEntry_Struct *sze = (ServerZoneEntry_Struct*)outapp->pBuffer;
					strcpy(sze->name, name);
					strcpy(sze->zone, zone->GetShortName());
					sze->class_ = pp.class_;
					sze->race = pp.race;
					sze->gender = pp.gender;
					sze->level = pp.level;
					sze->x = pp.x; //464;
					sze->y = pp.y; //-440;
					sze->z = pp.z; //2.751;
					sze->sze_unknown3[0] = 0xf5;
					sze->sze_unknown3[1] = 0x81;
					sze->sze_unknown3[2] = pp.heading;//0x85;
					sze->sze_unknown3[3] = 0x43;
					sze->walk_speed = 0.46;
					sze->run_speed = 0.7;
					
					// Disgrace: proper face selection
					sze->face = GetFace();

					SetEQChecksum((unsigned char*)sze, sizeof(ServerZoneEntry_Struct));
					packet_manager.MakeEQPacket(outapp);
					delete outapp;


			int weather = 0;
			weather = database.CheckZoneWeather(zone->GetShortName());
			cerr << "Zone Weather for: " << zone << " " << weather << endl;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Controls Rain
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = weather; // rain
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_TimeOfDay;
					outapp->pBuffer = new uchar[6];
					outapp->size = 6;
					outapp->pBuffer[0] = 0x00;
					outapp->pBuffer[1] = 0x00;
					outapp->pBuffer[2] = 0x00;
					outapp->pBuffer[3] = 0x00;
					outapp->pBuffer[4] = 0x00;
					outapp->pBuffer[5] = 0x00;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;				

					client_state = CLIENT_CONNECTING3;				
				}
				break;
			}
			case CLIENT_CONNECTING3: {
				if (app->opcode == 0x5d20)
				{
					cout << "Login packet 3" << endl; // Here the client sends tha character name again.. 
                                                      // not sure why, nothing else in this packet
					client_state = CLIENT_CONNECTING4;
				}
				break;
			}
			case CLIENT_CONNECTING4: {
				if (app->opcode == 0x0a20)
				{
					cout << "Login packet 4" << endl; // This packet was empty...

					APPLAYER* outapp;
					outapp = new APPLAYER;
					outapp->opcode =  OP_NewZone;
					outapp->pBuffer = new uchar[sizeof(NewZone_Struct)];
		   			outapp->size = sizeof(NewZone_Struct);
					memset(outapp->pBuffer, 0, sizeof(ServerZoneEntry_Struct));
					NewZone_Struct *nz = (NewZone_Struct*)outapp->pBuffer;
					strcpy(nz->zone_short_name, zone->GetShortName());
					strcpy(nz->zone_long_name, zone->GetLongName());

					int16 somedata3[71] = {
					0x00c8,
					0xc8c8, 0xc8c8, 0xc8c8, 0xc8d2, 0xd2d2, 0xd200, 0x0000, 0x2041,
					0x0000, 0x2041, 0x0000, 0x2041, 0x0000, 0x2041, 0x0000, 0xe143,
					0x0000, 0xe143, 0x0000, 0xe143, 0x0000, 0xe143, 0xcdcc, 0xcc3e,
					0x0232, 0x3232, 0x3218, 0x1818, 0x1800, 0x0000, 0x0000, 0x0000,
					0x00ff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff,
					0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff,
					0xff00, 0x0100, 0x0400, 0x0100, 0x0000, 0x0000, 0x0000, 0x403f,
					0x0000, 0x2041, 0x0000, 0x0000, 0x0000, 0xa040, 0x0000, 0xc842,
					0x0000, 0xa0c3, 0x0000, 0xe143, 0x0000, 0xe143};
					int16* temp3 = (int16*)nz->nz_unknown2;
					for (int i=0;i<71;i++)
					{
						*temp3 = ntohs(somedata3[i]); temp3++;
					}

					packet_manager.MakeEQPacket(outapp);
					delete outapp;				

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
			   		outapp->size = 0;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					client_state = CLIENT_CONNECTING5;
				}
				break;
			}
			case CLIENT_CONNECTING5:
			{
				if (app->opcode == 0xd820)
				{
					APPLAYER* outapp;

					outapp = new APPLAYER;
					outapp->opcode = 0xc321; // Unknown
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = OP_SpawnAppearance; 
					outapp->pBuffer = new uchar[12];
					memset(outapp->pBuffer, 0, 12);
					SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
					sa->type = 0x10;                       // Is 0x10 used to set the player id?
					sa->parameter = id;                    // Four bytes for this parameter...
		   			outapp->size = 12;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
		   			outapp->size = 0;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					// Inform the client about the world
					entity_list.SendZoneSpawns(this);
					
					// Inform the world about the client
					outapp = new APPLAYER;
					CreateSpawnPacket(outapp);
					entity_list.QueueClients(this, outapp, true);
					delete outapp;

					// We are now fully connected and ready to play					
					client_state = CLIENT_CONNECTED;

					outapp = new APPLAYER;
					outapp->opcode = OP_Stamina; 
		   			outapp->size = sizeof(Stamina_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					Stamina_Struct* sta = (Stamina_Struct*)outapp->pBuffer;
					sta->food = 127;
					sta->water = 125;
					sta->fatigue = 0;
					packet_manager.MakeEQPacket(outapp);
					delete outapp;

					// Quagmire - Setting Guildtag
					// Cant figure out where in pp is it, so will cheat
					if (guilddbid == 0) {
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 22;
						appearance->parameter = 0xFFFFFFFF;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 23;
						appearance->parameter = 3;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;
					}
					else {
						APPLAYER* outapp;
						SpawnAppearance2_Struct* appearance;
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 22;
						appearance->parameter = guildeqid;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 23;
						if (guilds[guildeqid].rank[guildrank].warpeace || guilds[guildeqid].leader == account_id)
							appearance->parameter = 2;
						else if (guilds[guildeqid].rank[guildrank].invite || guilds[guildeqid].rank[guildrank].remove || guilds[guildeqid].rank[guildrank].motd)
							appearance->parameter = 1;
						else
							appearance->parameter = 0;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;
					}

					// Quagmire - Setting GM flag
					if (admin >= 1) {
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
						appearance->spawn_id = id;
						appearance->type = 20;
						appearance->parameter = 1;
						entity_list.QueueClients(this, outapp, false);
						delete outapp;
					}
						for (int i=0;i<sizeof(pp.inventory); i++) {
							uint16 item_id = pp.inventory[i];
							Item_Struct* item = zone->GetItem(item_id);
							if (item) {
								item->equipSlot = i;                                        
								cout << "Sending inventory slot:" << i << endl;

								APPLAYER* app = new APPLAYER;
								app->opcode = 0x3120;
								app->size = sizeof(Item_Struct);
								app->pBuffer = new uchar[app->size];
								memcpy(app->pBuffer, item, sizeof(Item_Struct));
								packet_manager.MakeEQPacket(app);
								delete app;
                                       
								item->equipSlot = 0;
							}
					}

					UpdateWho(false);
				}
				break;
			}
			case CLIENT_CONNECTED:
			{
				switch(app->opcode)
				{
					case 0:
						break;
					case OP_AutoAttack:
					{
						if (app->size == 4)
						{
							if (app->pBuffer[0] == 0)
								auto_attack = false;
							else if (app->pBuffer[0] == 1)
								auto_attack = true;
						}
						else
						{
							cerr << "Wrong size " << app->size << " on OP_AutoAttack, should be 4" << endl; 
						}
						break;
					}
					case OP_ClientUpdate:
					{
						SpawnPositionUpdate_Struct* cu=(SpawnPositionUpdate_Struct*)app->pBuffer;
						if (app->size == sizeof(SpawnPositionUpdate_Struct))
						{
//							DumpPacketHex(app);
							x_pos = cu->x_pos;
							y_pos = cu->y_pos;
							z_pos = cu->z_pos;
							delta_x = cu->delta_x;
							delta_y = cu->delta_y;
							delta_z = cu->delta_z;
							heading = cu->heading;
							delta_heading = cu->delta_heading;
/*
							cout << "X:"  << x_pos << " ";
							cout << "Y:"  << y_pos << " ";
							cout << "Z:"  << z_pos << " ";
							cout << "dX:" << delta_x << " ";
							cout << "dY:" << delta_y << " ";
							cout << "dZ:" << delta_z << " ";
							cout << "H:"  << (int)heading << " ";
							cout << "dH:" << (int)delta_heading << " ";
							cout << "Heading hex 0x" << hex << (int)heading << dec;
							cout << endl;
*/
							SendPosUpdate(); // TODO: Move this outside this case
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(SpawnPositionUpdate_Struct) << " on " << app->opcode << endl;
						}
						break;
					}
					case OP_ClientTarget:
					{
						ClientTarget_Struct* ct=(ClientTarget_Struct*)app->pBuffer;	
						if (app->size == sizeof(ClientTarget_Struct))
						{
							Entity* entity = entity_list.GetID(ct->new_target);
							if (entity != 0 && entity->IsMob())
							{
								target = entity->CastToMob();
							}
							else
							{	
								target = 0;
							}
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ClientTarget_Struct) << " on " << app->opcode << endl;
						}
						break;
					}
					case OP_Jump:
					{
						cout << name << " jumped." << endl;
						break; 
					}
					case OP_Consider:
					{
						// Dont know if we are interested in any data in this packet?
						if (target != 0)
						{
							APPLAYER* outapp = new APPLAYER;
							outapp->opcode = OP_Consider;
							outapp->size = sizeof(Consider_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							Consider_Struct* con = (Consider_Struct*)outapp->pBuffer;
							con->playerid = id;
							con->unknown1[0] = 0;
							con->unknown1[1] = 0;
							con->targetid = target->GetID();
							con->unknown2[0] = 0;
							con->unknown2[1] = 0;
							con->faction = 5;
							con->level = target->GetLevel();
							con->cur_hp = 0;
							con->max_hp = 0x64;
							packet_manager.MakeEQPacket(outapp);
							delete outapp;
						}
						break;
					}
					case OP_Surname:
					{
						Surname_Struct surname;

						memcpy(&surname, app->pBuffer, sizeof(Surname_Struct));
						/* I don't know why the following works, but it does */
						surname.s_unknown1 = 0;
						surname.s_unknown2 = 1;
						surname.s_unknown3 = 1;
						surname.s_unknown4 = 1;
						memcpy(app->pBuffer, &surname, sizeof(Surname_Struct));
						
						strcpy(lastname, surname.lastname);
						strcpy(pp.last_name, surname.lastname);

						packet_manager.MakeEQPacket(app);
						cout << surname.name << " changed surname to " << surname.lastname << endl;
						break;
					}
					case OP_YellForHelp: // Pyro
					{
						cout << name << " yells for help." << endl;
						// TODO: write a msg send routine
						break;
					}
					case OP_SafePoint: // Pyro
					{
						cout << name << " moved to safe point." << endl;
						// This is handled clientside
						break;
					}
					case OP_SpawnAppearance:
					{
						SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
						if (sa->type == 0x0e)
						{
							if (sa->parameter == 0x64)
							{
								cout << "Client " << name << " standing" << endl;
								appearance = 0;
							}
							else if (sa->parameter == 0x6e)
							{
								cout << "Client " << name << " sitting" << endl;
								appearance = 1;
							}
							else if (sa->parameter == 0x6f)
							{
								cout << "Client " << name << " ducking" << endl;
								appearance = 2;
							}
							else if (sa->parameter == 0x73)
							{
								Message(13,"Saving Character");
								Message(13,"Please note: If you die, you will be dropped from the server (to the desktop).  Simply rejoin and you will be back at your last saved point.");
								pp.x = x_pos;
								pp.y = y_pos;
								pp.z = z_pos;
								pp.heading = heading;
								pp.cur_hp = max_hp;
								if (!database.SetPlayerProfile(account_id, name, &pp))
								{	
									cerr << "Failed to update player profile" << endl;
								//return false;
								}
								cout << "Client " << name << " unconscious" << endl;
								appearance = 3;
							}
							else
							{
								cerr << "Client " << name << " unknown apperance " << (int)sa->parameter << endl;
								break;
							}
							APPLAYER* outapp = new APPLAYER;;
							outapp->opcode = OP_SpawnAppearance;
							outapp->size = sizeof(SpawnAppearance_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
							sa_out->spawn_id = id;
							sa_out->sa_unknown1 = 0;
							sa_out->type = 0x0e;
							sa_out->sa_unknown2 = 0;
							sa_out->parameter = sa->parameter;
							entity_list.QueueClients(this, app, true);
							delete outapp;
						}
						break;
					}
					case OP_Death:
					{
						APPLAYER app;
						app.opcode = OP_Death;
						app.size = sizeof(Death_Struct);
						app.pBuffer = new uchar[app.size];
						memset(app.pBuffer, 0, app.size);
						Death_Struct* d = (Death_Struct*)app.pBuffer;
						d->spawn_id = id;
						entity_list.QueueClients(this, &app);
						packet_manager.Close();
						packet_manager.MakeEQPacket(0);
						break;
					}
					case 0x2921:
					{

					}
					case OP_MoveItem: 
					{ 
						MoveItem_Struct* mi = (MoveItem_Struct*)app->pBuffer; 
						if (mi->to_slot != 0xffffffff) {
							uint32 toitem = pp.inventory[mi->to_slot];
							pp.inventory[mi->to_slot] = pp.inventory[mi->from_slot];
							cout << "Moved " << pp.inventory[mi->from_slot] << " from: " << mi->from_slot << " to: " << mi->to_slot << endl;
							pp.inventory[mi->from_slot] = toitem;
							cout << "Moved " << toitem << " into: " << mi->from_slot << endl;
						}
						else
						{
							pp.inventory[mi->from_slot] = 0xffff;
							cout << "Set slot: " << mi->from_slot << " to: 0xffff" << endl;
						}
						break; 
					} 
					case OP_Camp:
					{
						// TODO: Implement camp, LD and all that
						// camp_timer->Start(30000);
						break;
					}
					case OP_Mend:
					{
						// TODO: Implement mend
						ChannelMessageSend(0,0,7,0,"Mend not implemented");
						break;
					}
					case OP_Forage:
					{
						// TODO: Implement forage
						ChannelMessageSend(0,0,7,0,"Forage not implemented");
						break;
					}
					case OP_Sneak:
					{
						// TODO: Implement sneak
						ChannelMessageSend(0,0,7,0,"Sneak not implemented");
						break;
					}
					case OP_Hide:
					{
						// TODO: Implement hide
						ChannelMessageSend(0,0,7,0,"Hide not implemented");
						break;
					}
					case OP_ChannelMessage:
					{
						ChannelMessage_Struct* cm=(ChannelMessage_Struct*)app->pBuffer;
						if (app->size > sizeof(ChannelMessage_Struct))
						{
							ChannelMessageReceived(cm->chan_num, cm->language, &cm->message[0], &cm->targetname[0]);
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ChannelMessage_Struct) << "+ on " << app->opcode << endl;
						}
						break;
					}
					case OP_WearChange:
					{
						//DumpPacketHex(app);
						WearChange_Struct* wc=(WearChange_Struct*)app->pBuffer;
						if (app->size == sizeof(WearChange_Struct))
						{
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(WearChange_Struct) << " on " << app->opcode << endl;
						}
						break;
					}
					case OP_ZoneChange:
						{
							ZoneChange_Struct* zc=(ZoneChange_Struct*)app->pBuffer;
							if (app->size == sizeof(ZoneChange_Struct))
							{
								cout << "Zone request for:" << zc->char_name << " to:" << zc->zone_name << endl;
								//							if (strcmp(zc->zone_name, zone->GetShortName()) == 0)
								//								break;
								
								cout << "Player at x:" << x_pos << " y:" << y_pos << " z:" << z_pos << endl;
								ZonePoint* zone_point = zone_point = zone->GetClosestZonePoint(x_pos, y_pos, z_pos, zc->zone_name);
								
								
								
								cout << "Zone point found at x:" << zone_point->x << " y:" << zone_point->y << " z:" << zone_point->z << endl;
								cout << "Zone target:" << zone_point->target_zone << " x:" << zone_point->target_x << " y:" << zone_point->target_y << " z:" << zone_point->target_z << endl;
								
								APPLAYER* outapp;
								if (database.GetZoneServer(zc->zone_name) &&strcmp(zc->zone_name, zone->GetShortName()) != 0 && zone_point != 0)
								{
									outapp = new APPLAYER;
									outapp->opcode = 0xdb20;
									outapp->size = 0;
									packet_manager.MakeEQPacket(outapp);
									delete outapp;
									
									outapp = new APPLAYER;
									outapp->opcode = 0x1020;
									outapp->size = 0;
									packet_manager.MakeEQPacket(outapp);					
									delete outapp;
									
									outapp = new APPLAYER;
									outapp->opcode = OP_ZoneChange;
									outapp->pBuffer = new uchar[sizeof(ZoneChange_Struct)];
									outapp->size = sizeof(ZoneChange_Struct);
									memset(outapp->pBuffer, 0, sizeof(ZoneChange_Struct));
									ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
									strcpy(zc2->char_name, zc->char_name);
									strcpy(zc2->zone_name, zc->zone_name);
									//								memcpy(zc2->zc_unknown1, zc->zc_unknown1, sizeof(zc->zc_unknown1));
									
									zc2->zc_unknown1[0] = 0x10;
									zc2->zc_unknown1[1] = 0x00; 
								zc2->zc_unknown1[2] = 0x00;
								zc2->zc_unknown1[3] = 0x00;
								zc2->zc_unknown1[4] = 0x04;
								zc2->zc_unknown1[5] = 0xb5; 
								zc2->zc_unknown1[6] = 0x01;
								zc2->zc_unknown1[7] = 0x02; 
								zc2->zc_unknown1[8] = 0x43; 
								zc2->zc_unknown1[9] = 0x58; 
								zc2->zc_unknown1[10] = 0x4f;
								zc2->zc_unknown1[11] = 0x00; 
								zc2->zc_unknown1[12] = 0xb0; 
								zc2->zc_unknown1[13] = 0xa5; 
								zc2->zc_unknown1[14] = 0xc7; 
								zc2->zc_unknown1[15] = 0x0d; 
								zc2->zc_unknown1[16] = 0x01;
								zc2->zc_unknown1[17] = 0x00;
								zc2->zc_unknown1[18] = 0x00;
								zc2->zc_unknown1[19] = 0x00;


								// The client seems to dump this profile on us, but I ignore it for now. Saving is client initiated?
								x_pos = (sint16)zone_point->target_x; // Hmm, these coordinates will now be saved when ~client is called
								y_pos = (sint16)zone_point->target_y;
								z_pos = (sint16)zone_point->target_z;
								strcpy(pp.current_zone, zc->zone_name);
								Save();

								database.SetAuthentication(account_id, zc->char_name, zc->zone_name, ip); // We have to tell the world server somehow?
								packet_manager.MakeEQPacket(outapp);
								delete outapp;
							}
							else
							{
								cerr << "Zone '" << zc->zone_name << "' is not available" << endl;

								outapp = new APPLAYER;
								outapp->opcode = 0xdb20;
					   			outapp->size = 0;
								packet_manager.MakeEQPacket(outapp);
								delete outapp;

								outapp = new APPLAYER;
								outapp->opcode = 0x1020;
					   			outapp->size = 0;
								packet_manager.MakeEQPacket(outapp);					
								delete outapp;

								outapp = new APPLAYER;
								outapp->opcode = OP_ZoneChange;
								outapp->pBuffer = new uchar[sizeof(ZoneChange_Struct)];
				   				outapp->size = sizeof(ZoneChange_Struct);
								memset(outapp->pBuffer, 0, sizeof(ZoneChange_Struct));
								ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
								strcpy(zc2->char_name, zc->char_name);
								strcpy(zc2->zone_name, zc->zone_name);
								packet_manager.MakeEQPacket(outapp);
								delete outapp;
							}
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ZoneChange_Struct) << " on " << app->opcode << endl;
						}
						break;
					}
					case OP_DeleteSpawn:
					{
						// The client will send this with his id when he zones, maybe when he disconnects too?
						// When zoning he seems to want 5921 and finish flag
						cout << "Player attempting to delete spawn..." << endl;
						APPLAYER* outapp;
						outapp = new APPLAYER;
						outapp->opcode = 0x5921;
	   					outapp->size = 0;
						packet_manager.MakeEQPacket(outapp);
						delete outapp;

						packet_manager.Close();
						packet_manager.MakeEQPacket(0); // Make a closing packet

						break;
					}
					case 0x5521: // Client dumps player profile on zoning, is this same opcode as saving?
					{
						cout << "Got a player profile" << endl;
//FileDumpPacket("playerprofile.txt", app);
						break;
					}
					case OP_Save:
					{
						cout << "Got a player save request" << endl;
//FileDumpPacket("playerprofile.txt", app);
						Save();
						break;
					}
					case OP_AutoAttack2: // Why 2
					{
						break;
					}
					case OP_WhoAll: // Pyro
					{
						WhoAll();
						break;
					}
					case OP_GMZoneRequest: // Quagmire
					{
						// this is the wrong struct for this packet, but the zonename is in the same spot so i used it. =P
						ZoneChange_Struct* zc = (ZoneChange_Struct*) app->pBuffer;
						cout << this->GetName() << " used /zone: " << zc->zone_name << endl;
						this->ZonePC(zc->zone_name, 0, 0, 10);
						break;
					}
					case OP_GMFlagged: // Pyro - tired of spam
					{
						break;
					}
					case OP_EndLootRequest:
					{
						cout << "got end loot request" << endl;


						Entity* entity = entity_list.GetID((int16)*app->pBuffer);
						if (entity == 0)
						{
							cout << "trying to delete an invalid corpse" << endl;
							break;
						}
						
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_LootComplete;
						outapp->size = 0;
						packet_manager.MakeEQPacket(outapp);
						delete outapp;

						outapp = new APPLAYER;
						outapp->opcode = OP_DeleteSpawn;
						outapp->size = sizeof(DeleteSpawn_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						DeleteSpawn_Struct* delspawn = (DeleteSpawn_Struct*)outapp->pBuffer;
						delspawn->spawn_id = entity->GetID();
						delspawn->ds_unknown1 = 0;
						packet_manager.MakeEQPacket(outapp);
						delete outapp;
						
						outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* sa_out = (SpawnAppearance2_Struct*)outapp->pBuffer;
						sa_out->spawn_id = id;
						sa_out->type = 0x0e;
						sa_out->parameter = 110; // stand...
						entity_list.QueueClients(this, app);
						delete outapp;

						entity_list.RemoveEntity(entity->GetID());

						DumpPacket(app);
						break;
					}
					case OP_LootRequest:
					{
						cout << "Lootrequest" << endl;
						
						NPC* npc = (entity_list.GetID((int16)*app->pBuffer))->CastToNPC();
						if (npc != 0)
						{
							int16 copper = npc->GetCopper();
							int16 silver = npc->GetSilver();
							int16 gold = npc->GetGold();
							int16 platinum = npc->GetPlatinum();
							if (!(copper==0 && silver==0 && gold==0 && platinum==0))
							{
								APPLAYER outapp;
								outapp.opcode = OP_MoneyOnCorpse;
								outapp.size = sizeof(moneyOnCorpseStruct);
								outapp.pBuffer = new uchar[outapp.size];
								memset(outapp.pBuffer, 0, outapp.size);
								moneyOnCorpseStruct* d = (moneyOnCorpseStruct*)outapp.pBuffer;
								d->player_id = id;
								d->copper = copper;
								d->silver = silver;
								d->gold = gold;
								d->platinum = platinum;
								packet_manager.MakeEQPacket(&outapp); 
								npc->RemoveCash();
								cout << "player received: " << copper << ":copper " << silver << ":silver " << gold << ":gold " << platinum << ":platinum " << endl;
							}
							
							ItemList* itemlist = npc->GetItemList();
							LinkedListIterator<Item_Struct*> iterator(*itemlist);
							iterator.Reset();
							int counter = 0;
							while(iterator.MoreElements())
							{
								Item_Struct* item = iterator.GetData();
								
								//Disgrace: debug
								char buff[500];
								sprintf(buff, "adding loot item: %s to [npc %s itemnum %d", item->name, npc->GetName(), item->item_nr);
								cout << buff << endl;
								
								item->equipSlot = counter;
								counter++;
								APPLAYER* outapp2 = new APPLAYER;
								outapp2->opcode = OP_ItemOnCorpse;
								outapp2->size = sizeof(ItemOnCorpse_Struct);
								outapp2->pBuffer = new uchar[outapp2->size];
								memcpy(outapp2->pBuffer, item, sizeof(Item_Struct));
								packet_manager.MakeEQPacket(outapp2);
								delete outapp2;
								iterator.Advance();
							}

						}
						else
						{
							APPLAYER* outapp2 = new APPLAYER;
							outapp2->opcode = OP_ItemOnCorpse;
							outapp2->size = 0;
							packet_manager.MakeEQPacket(outapp2);
							delete outapp2;
						}
						
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* sa_out = (SpawnAppearance2_Struct*)outapp->pBuffer;
						sa_out->spawn_id = id;
						sa_out->type = 0x0e;
						sa_out->parameter = 110; // stand...
						entity_list.QueueClients(this, app);
						delete outapp;

						break;
					}
					case OP_LootItem:
					{	
						// FIXME: send spawn appearance
						//d7 1c 11 00 16 00 00 00						

						cout << "looting item" << endl;
						DumpPacket(app);
						
						Entity* entity = entity_list.GetID((int16)*app->pBuffer);
						if (entity == 0)
							cout << "invalid mob selected" << endl;

						NPC* npc = entity->CastToNPC();
						if (npc != 0)
						{
							ItemList* itemlist = npc->GetItemList();
							LinkedListIterator<Item_Struct*> iterator(*itemlist);
							iterator.Reset();

							int counter = 0;
							LootingItem_Struct* lootitem = (LootingItem_Struct*)app->pBuffer;
							while(iterator.MoreElements())
							{
								Item_Struct* item = iterator.GetData();

								cout << "looting item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
								item->equipSlot = lootitem->slot_id;
								
								item->equipSlot = 0;
								APPLAYER* app = new APPLAYER;
								app->opcode = OP_SummonedItem;
								app->size = sizeof(SummonedItem_Struct);
								app->pBuffer = new uchar[app->size];
								memcpy(app->pBuffer, item, sizeof(Item_Struct));
								packet_manager.MakeEQPacket(app);
								delete app;
								npc->RemoveItem(item->item_nr);
								break;
							}
							
						}

						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance2_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						SpawnAppearance2_Struct* sa_out = (SpawnAppearance2_Struct*)outapp->pBuffer;
						sa_out->spawn_id = id;
						sa_out->type = 0x0e;
						sa_out->parameter = 110; // stand...
						entity_list.QueueClients(this, app);
						delete outapp;

						break;
					}							


					default:
					{
						cout << Timer::GetCurrentTime() << " Unkown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
						cout << " size:" << app->size << endl;
//						DumpPacket(app->pBuffer, app->size);
						break;
					}
				}
				break;
			}
			default:
			{
				cerr << "Unknown client_state:" << client_state << endl;
				break; 
			}
		}
		delete app;
	}    
// Moved the packet send to after the packet receive
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
    sockaddr_in to;	
	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
	while(p = packet_manager.SendQueue.pop())
	{
		#ifdef BUILD_FOR_WINDOWS
			sendto(send_socket, (char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif

		delete[] p;
	}
	/************ Processing finished ************/

	if (!packet_manager.CheckActive())
	{
		cout << "Client disconnected" << endl;
		return false;
	}
    if (timeout_timer->Check())
    {
		cout << "Client timeout" << endl;
		return false;
    }

	packet_manager.CheckTimers();

	return true;
}
