#ifndef EQ_PACKET_STRUCTS_H
#define EQ_PACKET_STRUCTS_H 

#include "types.h"

/*
** Compiler override to ensure
** byte aligned structures
*/
#pragma pack(1)

struct CharacterSelect_Struct
{
	char  name[10][30];
	int8  level[10];
	int8  class_[10];
	int16 race[10];
	char  zone[10][20];
	int8  gender[10];
	int8  face[10];
	int8  cs_unknown[560];
};

struct ServerZoneEntry_Struct
{
	int8 sze_unknown1[5];
	char name[30];
	char zone[15];
	int8 sze_unknown2[8-2];
	float y;
	float x;
	float z;
	int8 sze_unknown3[85];
	int8 sze_unknown_add[4];		// sze->sze_unknown_add[3] = (0=ok, 1=name color as dead, 2=death on zone in)
	int8 class_;
	int8 race;
	int8 sze_unknown4[1]; // race is probably 2 bytes?
	int8 gender;
	int8 level;
	///////////////////////////////////
	// [Disgrace]
	// the following were parts of sze_unknown5[74] that i have broken out.
	// Seems to only affect character appearance.  
	///////////////////////////////////
	int8 sze_unknown5[2];
	int8 pvp;						// 0x0=non_pvp 0x1=pvp
	int8 sze_unknown5_2_1[2];
	int8 face;						// characters face
	int8 helmet;					// the helmet on the character model ??
	int8 sze_unknown5_2_2_0;
	int8 sze_unknown5_2_2_1;
	int8 sze_unknown5_2_2_2;
	int8 sze_unknown5_2_2_3;
	int8 sze_unknown5_2_2_4;
	int8 sze_unknown5_2_2_5;
	int8 left_hand;					// weapon in character models left hand ??
	int8 right_hand;				// weapon in character models right hand ??
	int8 sze_unknown5_2_2[59];		// sze->sze_unknown5_2_2[39] = suit of armor 0=none 1=leather 2=chain 3=steelplate
	//////////////////////////////////
	float walk_speed;
	float run_speed;
	int8 sze_unknown6[56]; // At least one flag in here disables a zone point or all
	int8 sze_unknown_add2[12];
};

struct NewZone_Struct // 372 bytes
{
	char char_name[30];            // Character name
	char zone_short_name[15];      // Zone Short Name
	int8 nz_unknown1[5];           // *** Placeholder
	char zone_long_name[180];      // Zone Long Name
	int8 nz_unknown2[142];         // *** Placeholder
};

struct MemorizeSpell_Struct 
{ 
int32 slot;     // Spot in the spell book/memorized slot 
int32 spell_id; // Spell id (200 or c8 is minor healing, etc) 
int32 scribing; // 1 if memorizing a spell, set to 0 if scribing to book 
}; 

struct CastOn_Struct
{
/*00*/ uint16 target_id;
/*02*/ uint16 source_id;
/*04*/ int16 co_unknown1;
/*06*/ int16 co_unknown2;
/*08*/ int16 co_unknown3;
/*10*/ int32 co_zero1[2];
/*18*/  int16 co_unknown4;
/*20*/ int32 co_zero2;
/*24*/ uint32 action;
/*28*/ uint16 spell_id;
/*30*/ int16 co_unknown5;
};

struct ManaChange_Struct
{
uint16 new_mana;                  // New Mana AMount
uint16 spell_id;                  // Last Spell Cast
};

struct SwapSpell_Struct 
{ 
int32 from_slot; 
int32 to_slot; 
}; 

struct BeginCast_Struct
{
uint32  target_id;               // Id of who is casting
uint32  spell_id;                // Id of spell
int16   bc_unknown1;             // Paramater 1
int16   bc_unknown2;             // Paramater 2
int16   bc_unknown3;             // Parameter 3
};

struct Buff_Struct
{
uint32 target_id;
uint32 b_unknown1;
uint16 spell_id;
uint32 b_unknown2;
uint16 b_unknown3;
uint32 buff_slot;
};

struct CastSpell_Struct
{
uint16 slot;
uint16 spell_id;
int32  cs_unknown1;
uint32 target_id;
int32  cs_unknown2;
};

struct SpawnAppearance2_Struct
{
/*0000*/ uint32 spawn_id;          // ID of the spawn
/*0004*/ uint32 type;              // Values associated with the type
/*0002*/ uint32 parameter;         // Type of data sent
};


/*
** Buffs
** Length: 10 Bytes
** Used in:
**    playerProfileStruct(2d20)
*/
struct SpellBuff_Struct
{
	int8  b_unknown1;            // ***Placeholder
	int8  level;                 // Level of person who casted buff
	int8  b_unknown2;            // ***Placeholder
	int8  b_unknown3;            // ***Placeholder
	int16 spell;                 // Spell
	int32 duration;              // Duration in ticks
};

/*
** Player Profile
** Length: 4534 Bytes
** OpCode: 2d20
*/
struct PlayerProfile_Struct
{
/*0000*/ int8   pp_unknown1[4];         // This is a checksum
/*0004*/ char   name[30];               // Name of player
/*0034*/ char   last_name[20];          // Last name of player
/*0054*/ int8   pp_unknown2[2];         // ***Placeholder
/*0056*/ int8   race;                   // Player race
/*0057*/ int8   pp_unknown3;            // ***Placeholder
/*0058*/ int8   class_;                 // Player class
/*0059*/ int8   gender;                 // Player gender
/*0060*/ int8   level;                  // Level of player (might be one int8)
/*0061*/ int8   pp_unknown4[3];         // ***Placeholder
/*0064*/ int32  exp;                    // Current Experience
/*0068*/ int8   pp_unknown5[2];         // ***Placeholder
/*0070*/ int16  mana;                   // MANA
/*0072*/ int8   pp_unknown6[48];        // ***Placeholder
/*0120*/ int16  cur_hp; 
/*0122*/ int8   pp_unknown7;
/*0123*/ int8   STR;                    // Strength
/*0124*/ int8   STA;                    // Stamina
/*0125*/ int8   CHA;                    // Charisma
/*0126*/ int8   DEX;                    // Dexterity
/*0127*/ int8   INT;                    // Intelligence
/*0128*/ int8   AGI;                    // Agility
/*0129*/ int8   WIS;                    // Wisdom
/*0130*/ int8   languages[24];          // List of languages (MAX_KNOWN_LANGS)
/*0154*/ int8   pp_unknown8_2[10]; 
/*0164*/ uint16 inventory[30]; 		// Inventory Storage
/*0224*/ int8   pp_unknown8[424];                                                         
/*0648*/ struct SpellBuff_Struct buffs[15];    // Buffs currently on the player
/*0798*/ int8   pp_unknown9[1080];      // ***Placeholder
/*1878*/ short  spell_book[256];        // List of the Spells scribed in the spell book
/*2390*/ short  spell_memory[8];        // List of spells memorized
/*2406*/ int8   pp_unknown10[2];
/*2408*/ float  y;
/*2412*/ float  x;
/*2416*/ float  z;
/*2420*/ int8   pp_unknown11[2];
/*2422*/ int8   heading;
/*2423*/ int8   pp_unknown12;
/*2424*/ char   current_zone[15];       // No idea if size is correct
/*2439*/ int8   pp_unknown13[21];
/*2460*/ int32  platinum;               // Amount of Platinum Pieces on player
/*2464*/ int32  gold;                   // Amount of Gold Pieces on player
/*2468*/ int32  silver;                 // Amount of Silver Pieces on player
/*2472*/ int32  copper;                 // Amount of Copper Pieces on player
/*2476*/ int32  platinum_bank;          // Amount of Platinum Pieces in Bank
/*2480*/ int32  gold_bank;              // Amount of Gold Pieces in Bank
/*2484*/ int32  silver_bank;            // Amount of Silver Pieces in Bank
/*2488*/ int32  copper_bank;            // Amount of Copper Pieces in Bank
/*2492*/ int8   pp_unknown14[16];       // ***Placeholder
/*2508*/ int8   skills[74];             // List of skills (MAX_KNOWN_SKILLS)

/*0000*/ int8   pp_unknown15[262];
/*0000*/ char   bind_point_zone[20];    // Agz: Not confirmed
/*0000*/ char   start_point_zone[4][20];// Agz: Not confirmed
/*0000*/ int8   pp_unknown16[1588];

/*
	int8   pp_unknown11[154-36];   // ***Placeholder
	char   GUILD[144];             // Guild Info -- Length probably wrong
	int8   pp_unknown12[1376];     // ***Placeholder
	char   GroupMembers[5][48];    // List of all the members in the players group
	int8   pp_unknown13[72];       // ***PlaceHolder
*/
	int8 more_new_trash[1348];
	int8 empty[2224]; // This was empty
};

/*
** client changes target struct
** Length: 6 Bytes               // Agz: 4
** OpCode: 6221
*/
struct ClientTarget_Struct
{
	int16  new_target;              // Target ID
	int16  ct_unknown1;            // ***Placeholder
};


/*
** Generic Spawn Struct
** Length: 156 Bytes
** Used in:
**
*/
struct Spawn_Struct
{
/*000*/ int8   s_unknown1[49];        // Placeholder
/*049*/ sint8  heading;               // Current Heading
/*050*/ sint8  deltaHeading;          // Delta Heading
/*051*/ sint16 y_pos;                 // Y Position
/*053*/ sint16 x_pos;                 // X Position
/*055*/ sint16 z_pos;                 // Z Position
/*057*/ sint32 deltaY:10,             // Velocity Y
           spacer1:1,             // Placeholder
           deltaZ:10,             // Velocity Z
           spacer2:1,             // ***Placeholder
           deltaX:10;             // Velocity X
/*061*/ int8   s_unknown2[1];         // ***Placeholder
/*062*/ int16  spawn_id;              // Id of new spawn
/*064*/ int8   s_unknown3[2];         // ***Placeholder
/*066*/ int16  pet_owner_id;          // Id of pet owner (0 if not a pet)
/*068*/ sint16 max_hp;                // Maximum hp's of Spawn
/*070*/ uint16 GuildID;               // GuildID - previously Current hp's of Spawn
/*072*/ int8   race;                  // Race
/*073*/ int8   NPC;                   // NPC type: 0=Player, 1=NPC, 2=Player Corpse,
                                  //           3=Monster Corpse, 4=???,
                                  //           5=Unknown Spawn,10=Self
/*074*/ int8  class_;                 // Class
/*075*/ int8  gender;                 // Gender Flag, 0 = Male, 1 = Female, 2 = Other
/*076*/ int8  level;                  // Level of spawn (might be one sint8)
/*077*/ int8  s_unknown4[2];          // ***Placeholder
/*079*/ int8  not_linkdead;
/*080*/ int8  anim_type;
/*081*/ int8  light;                  // Light emitting
/*082*/ int8  s_unknown5[9];          // ***Placeholder
/*091*/ int8  equipment[9];           // Equipment worn
/*099*/	char  name[30];               // Name of spawn (len is 30 or less)
	char  lastname[20];           // Last Name of player
	int8  s_unknown6[2];          // ***Placeholder
	int8  deity;                  // Deity.
	int8  s_unknown7[3];          // ***Placeholder
	int8  s_unknown8[4];          // ***Placeholder
	int8  s_unknown9[8];          // ***Placeholder
};

/*
** New Spawn
** Length: 158 Bytes
** OpCode: 4921
*/
struct NewSpawn_Struct
{
	int32  ns_unknown1;            // ***Placeholder
	struct Spawn_Struct spawn;     // Spawn Information
};

/*
** Delete Spawn
** Length: 6 Bytes
** OpCode: 2b20
*/
struct DeleteSpawn_Struct
{
/*00*/ int16 spawn_id;             // Spawn ID to delete
/*02*/ int32 ds_unknown1;            // ***Placeholder
};

/*
** Channel Message received or sent
** Length: 71 Bytes + Variable Length + 4 Bytes
** OpCode: 0721
*/
struct ChannelMessage_Struct
{
	char  targetname[32];		// Tell recipient
//	int16 cm_unknown1[16];        // ***Placeholder
	char  sender[23];             // The senders name (len might be wrong)
	int8  cm_unknown2[9];         // ***Placeholder
	int16  language;               // Language
//	int8  cm_unknown3;            // ***Placeholder
	int16  chan_num;               // Channel
	int8  cm_unknown4[5-1];         // ***Placeholder
	char  message[0];             // Variable length message
};

/*
** Spawn Appearance
** Length: 14 Bytes
** OpCode: f520
*/
struct SpawnAppearance_Struct
{
/*0000*/ int16 spawn_id;               // ID of the spawn
/*0002*/ int16 sa_unknown1;            // ***Placeholder
/*0004*/ int16 type;                   // Type of data sent
/*0006*/ int16 sa_unknown2;            // ***Placeholder
/*0008*/ int32 parameter;              // Values associated with the type
};


/*
** When somebody changes what they're wearing
**      or give a pet a weapon (model changes)
** Length: 14 Bytes
** Opcode: 9220
*/
struct WearChange_Struct{
	int16  spawn_id;               // SpawnID
	int8   wc_unknown1[2];         // ***Placeholder
	int8   wear_slot_id;           // Slot
	int8   new_item_id;            // Item ID
	int8   wc_unknown2[6];         // first few bytes react to clothing changes
};


/*
** Type:   Zone Change Request (before hand)
** Length: 70 Bytes-2 = 68 bytes 
** OpCode: a320
*/
struct ZoneChange_Struct
{
	char char_name[32];     // Character Name
	char zone_name[16];     // Zone Short Name
	int8 zc_unknown1[20];   // *** Placeholder
};

struct Attack_Struct
{
/*00*/ int16   spawn_id;               // Spawn ID
/*02*/ int16   a_unknown1;             // ***Placeholder
/*04*/ int8    type;
/*05*/ int8    a_unknown2[7];          // ***Placeholder
};

/*
** Battle Code
** Length: 30 Bytes
** OpCode: 5820
*/
struct Action_Struct
{
/*00*/ int16  target;                 // Target ID
/*02*/ int8   unknown1[2];         // ***Placeholder
/*04*/ int16  source;                 // SourceID
/*06*/ int8   unknown2[2];         // ***Placeholder
/*08*/ int8   type;                   // Casts, Falls, Bashes, etc...
/*09*/ int8   unknown3;            // ***Placeholder
/*10*/ int16  spell;                  // SpellID
/*12*/ int32  damage;                 // Amount of Damage
/*16*/ int8   unknown4[12];        // ***Placeholder
};

/*
** Consider Struct
** Length: 26 Bytes
** OpCode: 3721
*/
struct Consider_Struct{
/*0000*/ int16  playerid;               // PlayerID
/*0002*/ int8   unknown1[2];            // ***Placeholder
/*0004*/ int16  targetid;               // TargetID
/*0006*/ int8   unknown2[2];            // ***Placeholder
/*0008*/ int32  faction;                // Faction
/*0012*/ int32  level;                  // Level
/*0016*/ int32  cur_hp;                  // Current Hitpoints
/*0020*/ int32  max_hp;                  // Maximum Hitpoints
};

/*
** Spawn Death Blow
** Length: 22 Bytes
** OpCode: 4a20
*/
struct Death_Struct
{
/*0002*/ int16  spawn_id;               // Id of spawn that died
/*0004*/ int16  d_unknown1;             // ***Placeholder
/*0006*/ int16  killer_id;              // Killer
/*0008*/ int8   d_unknown2[6];          // ***Placeholder
/*0014*/ int16  spell_id;               // ID of Spell
/*0016*/ int8   type;                   // Spell, Bash, Hit, etc...
/*0017*/ int8   d_unknown3;             // ***Placeholder
/*0018*/ int16  damage;                 // Damage
/*0020*/ int8   d_unknown4[2];          // ***Placeholder
};

/*
** Generic Spawn Update
** Length: 15 Bytes
** Used in:
**
*/
struct SpawnPositionUpdate_Struct
{
/*0000*/ int16  spawn_id;               // Id of spawn to update
/*0002*/ int8   anim_type; // ??
/*0003*/ sint8  heading;                // Heading
/*0004*/ sint8  delta_heading;          // Heading Change
/*0005*/ sint16 y_pos;                  // New Y position of spawn
/*0007*/ sint16 x_pos;                  // New X position of spawn
/*0009*/ sint16 z_pos;                  // New Z position of spawn
/*0011*/ int32  delta_y:10,             // Y Velocity
                spacer1:1,              // ***Placeholder
                delta_z:10,             // Z Velocity
                spacer2:1,              // ***Placeholder
                delta_x:10;             // Z Velocity
};

/*
** Spawn Position Update
** Length: 6 Bytes + Number of Updates * 15 Bytes
** OpCode: a120
*/
struct SpawnPositionUpdates_Struct
{
/*0000*/ int32  num_updates;               // Number of SpawnUpdates
/*0004*/ struct SpawnPositionUpdate_Struct // Spawn Position Update
                     spawn_update[0];
};

/*
** Spawn HP Update
** Length: 14 Bytes
** OpCode: b220
*/
struct SpawnHPUpdate_Struct
{
/*02*/ int16  spawn_id;               // Id of spawn to update
/*04*/ int16  shu_unknown1;           // ***Placeholder
/*06*/ sint16 cur_hp;                 // Current hp of spawn
/*08*/ int16  shu_unknown2;           // ***Placeholder
/*10*/ sint16 max_hp;                 // Maximum hp of spawn
/*12*/ int16  shu_unknown3;           // ***Placeholder
};

/*
** Stamina
** Length: 8 Bytes
** OpCode: 5721
*/
struct Stamina_Struct {
/*00*/ int16 food;                     // (low more hungry 127-0)
/*02*/ int16 water;                    // (low more thirsty 127-0)
/*04*/ int16 fatigue;                  // (high more fatigued 0-100)
};

/*
** Special Message
** Length: 6 Bytes + Variable Text Length
** OpCode: 8021
*/
struct SpecialMesg_Struct
{
/*0000*/ int32 msg_type;                // Type of message
/*0004*/ char  message[0];              // Message, followed by four bytes?
};

/*
** Level Update
** Length: 14 Bytes
** OpCode: 9821
*/
struct LevelUpdate_Struct
{
/*00*/ uint32 level;                  // New level
/*04*/ uint32 level_old;              // Old level
/*08*/ uint32 exp;                    // Current Experience
};

/*
** Experience Update
** Length: 14 Bytes
** OpCode: 9921
*/
struct ExpUpdate_Struct
{
/*0000*/ uint32 exp;                    // Current experience value
};

/*
** Generic Item structure
** Length: 244 bytes
** Used in:
**    itemShopStruct(0c20), itemReceivedPlayerStruct(5220),
**    itemPlayerStruct(6421), bookPlayerStruct(6521),
**    containerPlayerStruct(6621), summonedItemStruct(7821),
**    tradeItemStruct(df20),
*/
struct Item_Struct
{
/*0000*/ char   name[35];                // Name of item
/*0035*/ char   lore[60];                // Lore text, same as name if no lore
/*0095*/ char   idfile[6];               // Not sure what this is used for, eg: IT63
/*0101*/ sint16 flag;                    // Flag value indicating type of item:
  // 0x0031 - Normal Item - Only seen once on GM summoned food
  // 0x0036 - Normal Item (all scribed spells, Velium proc weapons, and misc.)
  // 0x315f - Normal Item
  // 0x3336 - Normal Item
  // 0x5400 - Container (Combine, Player made, Weight Reducing, etc...)
  // 0x5450 - Container, plain ordinary newbie containers
  // 0x7669 - Book item
/*0103*/ sint8  unknown0103[22];         // Placeholder
/*0125*/ uint8  weight;                  // Weight of item
/*0126*/ sint8  nosave;                  // Nosave flag 1=normal, 0=nosave, -1=spell?
/*0127*/ sint8  nodrop;                  // Nodrop flag 1=normal, 0=nodrop, -1=??
/*0128*/ uint8  size;                    // Size of item
/*0129*/ sint8  unknown0129;             // ***Placeholder
/*0130*/ uint16 item_nr;                  // Unique Item number
/*0132*/ uint16 icon_nr;                  // Icon Number
/*0134*/ sint16 equipSlot;               // Current Equip slot
/*0136*/ uint32 equipableSlots;          // Slots where this item goes
/*0140*/ sint32 cost;                    // Item cost in copper
/*0144*/ char   unknown0144[28];         // ***Placeholder
union // 0172-291 have different meanings depending on flags
{
  // note, each of the following 2 structures must be kept of equal size
  struct // Common Item Structure (everything but books (flag != 0x7669)
  {
    /*0172*/ sint8  STR;                 // Strength
    /*0173*/ sint8  STA;                 // Stamina
    /*0174*/ sint8  CHA;                 // Charisma
    /*0175*/ sint8  DEX;                 // Dexterity
    /*0176*/ sint8  INT;                 // Intelligence
    /*0177*/ sint8  AGI;                 // Agility
    /*0178*/ sint8  WIS;                 // Wisdom
    /*0179*/ sint8  MR;                  // Magic Resistance
    /*0180*/ sint8  FR;                  // Fire Resistance
    /*0181*/ sint8  CR;                  // Cold Resistance
    /*0182*/ sint8  DR;                  // Disease Resistance
    /*0183*/ sint8  PR;                  // Poison Resistance
    /*0184*/ sint8  HP;                  // Hitpoints
    /*0185*/ sint8  MANA;                // Mana
    /*0186*/ sint8  AC;                  // Armor Class
    /*0187*/ sint8  unknown0187[2];      // ***Placeholder
    /*0189*/ uint8  light;               // Light effect of this item
    /*0190*/ sint8  delay;               // Weapon Delay
    /*0191*/ sint8  damage;              // Weapon Damage
    /*0192*/ sint8  unknown0192;         // ***Placeholder
    /*0193*/ uint8  range;               // Range of weapon
    /*0194*/ uint8  skill;               // Skill of this weapon
    /*0195*/ sint8  magic;               // Magic flag
    //   00  (0000)  =   ???
    //   01  (0001)  =  magic
    //   12  (1100)  =   ???
    //   14  (1110)  =   ???
    //   15  (1111)  =   ???
    /*0196*/ sint8  level0;              // Casting level
    /*0197*/ uint8  material;            // Material?
    /*0198*/ sint8  unknown0198[2];      // ***Placeholder
    /*0200*/ uint32 color;               // Amounts of RGB in original color
    /*0204*/ sint8  unknown0204[2];      // ***Placeholder
    /*0206*/ uint16 spellId0;            // SpellID of special effect
    /*0208*/ uint16 classes;             // Classes that can use this item
    /*0210*/ sint8  unknown0210[2];      // ***Placeholder
    union // 0212-0216 have different meanings depending on flags
    {
      // note, each of the following 2 structures must be kept of equal size
      struct // normal non-containers
      {
    /*0212*/ uint16  races;           // Races that can use this item
    /*0214*/ sint8   unknown0214[3];  // ***Placeholder
      } normal;
      struct // containers flag == 0x5400 or 0x5450
      {
    /*0212*/ sint8  unknown0212;     // ***Placeholder
    /*0213*/ uint8  numSlots;        // number of slots in container
    /*0214*/ sint8  unknown0214;     // ***Placeholder
    /*0215*/ sint8  sizeCapacity;    // Maximum size item container can hold
    /*0216*/ uint8  weightReduction; // % weight reduction of container
      } container;
    };
    /*0217*/ uint8  level;               // Casting level
    union // 0218 has different meanings depending on an unknown indicator
    {
      /*0218*/ sint8   number;            // Number of items in stack
      /*0218*/ sint8   charges;           // Number of charges (-1 = unlimited)
    };
    /*0219*/ sint8   unknown0219;         // ***Placeholder
    /*0220*/ uint16  spellId;             // spellId of special effect
    /*0222*/ sint8   unknown0222[70];     // ***Placeholder
  } common;
  struct // Book Structure (flag == 0x7669)
  {
    /*0172*/ sint8  unknown0172[3];      // ***Placeholder
    /*0175*/ char   file[15];            // Filename of book text on server
    /*0190*/ sint8  unknown0190[102];    // ***Placeholder
  } book;
};
};

/*
** Summoned Item - Player Made Item?
** Length: 244 Bytes
** OpCode: 7821
*/
struct SummonedItem_Struct
{
/*0000*/ struct Item_Struct item;        // Refer to itemStruct for members
};

struct Consume_Struct
{
/*0000*/ int32 slot;
/*0004*/ int32 auto_consumed; // 0xffffffff when auto eating e7030000 when right click
/*0008*/ int8  c_unknown1[4];
/*0012*/ int8  type; // 0x01=Food 0x02=Water
};

struct MoveItem_Struct
{
/*0000*/ uint32 from_slot;
/*0004*/ uint32 to_slot;
/*0008*/ uint32 number_in_stack;
};

struct Surname_Struct 
{ 
       char name[30]; 
       char s_unknown1; 
       char s_unknown2; 
       char s_unknown3; 
       char s_unknown4; 
       char s_unknown5; 
       char s_unknown6; 
       char lastname[18]; 
}; 

struct GuildsListEntry_Struct {
	int32 guildID;  // empty = 0xFFFFFFFF
	char name[32];
	int8 unknown1[4]; // = 0xFF
	int8 unknown2; // = 0x01 if exists, 0x00 on empty
	int8 unknown3[7]; // = 0x00
	int8 unknown4[4]; // = 0xFF
	int8 unknown5[8]; // = 0x00
};

struct GuildsList_Struct {
	int8 head[4];
	GuildsListEntry_Struct Guilds[512];
};

//#define CODE_NEW_GUILD                  0x7b21
struct GuildUpdate_Struct {
//        OpCode                  code;                   // 0x7b, 0x21
        uchar                    unknown0[8];
        char                    guildname[56];
};

/*
** Money Loot
** Length: 22 Bytes
** OpCode: 5020
*/
struct moneyOnCorpseStruct
{
/*0002*/ uint32 player_id; // ***Placeholder
/*0006*/ uint32 platinum; // Platinum Pieces
/*0010*/ uint32 gold; // Gold Pieces
/*0014*/ uint32 silver; // Silver Pieces
/*0018*/ uint32 copper; // Copper Pieces
};

//opcode = 0x5220
// size 292
struct ItemOnCorpse_Struct
{
  Item_Struct item;
};

struct LootingItem_Struct
{
  int16 lootee;
  int16 unknown1;
  int16 looter;
  int16 unknown2;
  int16 slot_id;
  int16 unknown3[3];
};

// Restore structure packing to default
#pragma pack()

#endif
