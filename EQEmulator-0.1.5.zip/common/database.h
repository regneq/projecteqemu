#ifndef DATABASE_H
#define DATABASE_H

// Disgrace: for windows compile
#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
#endif

#include <mysql.h>

#include "types.h"
#include "linked_list.h"
#include "eq_packet_structs.h"
#include "../common/guilds.h"

class Spawn;
struct ZonePoint;

struct NPCType
{
    char    name[30];
    char    lastname[20];

    sint16  cur_hp;
    sint16  max_hp;

    int8    gender;
    int8    race;
    int8    class_;
    int8    deity;
    int8    level;

    int8    light;
    int8    equipment[9];
};

class Database
{
public:
	#ifdef BUILD_FOR_WINDOWS
		Database();
	#else
		Database(const char* host, const char* user, const char* passwd, const char* database);
	#endif
	~Database();

	bool PopulateZoneLists(char* short_name, NPCType* &npc_type_array, uint16 &max_npc_type, Item_Struct** &item_type_array, uint16 &max_item, LinkedList<Spawn*>& spawn_list, LinkedList<ZonePoint*>& zone_point_list);
	bool GetZoneLongName(char* short_name, char** long_name);
	bool RegisterZoneServer(char* name, char* address, int16 port);
	bool UnregisterZoneServer(char* name, char* address, int16 port);
	bool GetZoneServer(char* name);
	bool GetZoneServer(char* name, char* address, int16* port);
	int32 GetAuthentication(char* char_name, char* zone_name, int32 ip);
	bool SetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool ClearAuthentication(int32 account_id);

	int32 CheckLogin(char* name, char* password);
	int32 CheckStatus(int32 account_id);
	int32 CheckZoneWeather(char* zonename);
	int32 SetZoneWeather(char* zonename, char* weather);
	int32 CreateAccount(char* name, char* password, char* status);
	int32 DeleteAccount(char* name);
	int32 SetGMFlag(char* name, char* status);
	bool CheckZoneserverAuth(char* ipaddr);

	void GetCharSelectInfo(int32 account_id, CharacterSelect_Struct*);
	bool GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);
	bool SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);

	bool ReserveName(int32 account_id, char* name);
	bool CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis, int8 face);
	bool DeleteCharacter(char* name);
	
	int32 GetAccountID(char* name);
	void GetAccountName(int32 accountid, char* name);
	void GetCharacterInfo(char* name, int32* charid, int32* guilddbid, int8* guildrank);

	bool GetVariable(char* varname, char* varvalue);
	bool GetGuildsList(GuildsList_Struct* gl);
	bool GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr);
	int32 GetGuildEQID(int32 guilddbid);
	bool SetGuild(int32 charid, int32 guilddbid, int8 guildrank);
	int32 GetFreeGuildEQID();
	int32 CreateGuild(char* name, int32 leader);
	bool DeleteGuild(int32 guilddbid);
	bool RenameGuild(int32 guilddbid, char* name);
	bool EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl);

	bool GetStartPointX(char* short_name, char* safe_x);
	bool GetStartPointY(char* short_name, char* safe_y);
	bool GetStartPointZ(char* short_name, char* safe_z);


	MYSQL mysql;
};
#endif

