/*
create table guilds (id int(11) primary key auto_increment, eqid smallint(4) unsigned not null unique, name varchar(32) not null unique, leader int(11) not null unique, 
rank0title varchar(100) not null, rank0 char(8) not null, rank1title varchar(100) not null, rank1 char(8) not null, rank2title varchar(100) not null, rank2 char(8) not null, 
rank3title varchar(100) not null, rank3 char(8) not null, rank4title varchar(100) not null, rank4 char(8) not null, rank5title varchar(100) not null, rank5 char(8) not null);

alter table character_ add column (guild int(11) default 0, guildrank tinyint(2) unsigned default 5);
*/

#ifndef GUILD_H
#define GUILD_H

#define GUILD_MAX_RANK  5   // 0-5 - some places in the code assume a single digit, dont go above 9

#define GUILD_HEAR		0
#define GUILD_SPEAK		1
#define GUILD_INVITE	2
#define GUILD_REMOVE	3
#define GUILD_PROMOTE	4
#define GUILD_DEMOTE	5
#define GUILD_MOTD		6
#define GUILD_WARPEACE	7

struct GuildRankLevel_Struct {
	char rankname[101];
	bool heargu;
	bool speakgu;
	bool invite;
	bool remove;
	bool promote;
	bool demote;
	bool motd;
	bool warpeace;
};

struct GuildRanks_Struct {
	char name[32];
	int32 databaseID;
	int32 leader;  // AccountID of leader
	GuildRankLevel_Struct rank[GUILD_MAX_RANK+1];
};
#endif