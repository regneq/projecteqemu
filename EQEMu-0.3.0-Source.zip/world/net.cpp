#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQPacket.h"
#include "../common/EQPacketManager.h"
#include "net.h"
#include "client.h"
#include "../common/database.h"
#include "../common/seperator.h"
#ifdef WIN32
	#include <process.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include "../common/unix.h"
#endif
#include "zoneserver.h"
#include "console.h"
#include "LoginServer.h"

NetConnection net;
ClientList client_list;
ZSList zoneserver_list;
LoginServer* loginserver;
volatile bool RunLoops = true;
uint32 numclients = 0;
uint32 numzones = 0;
GuildRanks_Struct guilds[512];
extern volatile bool ZoneLoopRunning;
extern volatile bool ConsoleLoopRunning;
extern volatile bool LoginLoopRunning;

Database database;

int main(int argc, char** argv)
{
#ifdef _DEBUG
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	if (signal(SIGINT, CatchSignal) == SIG_ERR)	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	if (argc >= 2) {
		char tmp[2];
		if (strcasecmp(argv[1], "help") == 0 || strcasecmp(argv[1], "?") == 0 || strcasecmp(argv[1], "/?") == 0 || strcasecmp(argv[1], "-?") == 0 || strcasecmp(argv[1], "-h") == 0 || strcasecmp(argv[1], "-help") == 0) {
			cout << "Worldserver command line commands:" << endl;
			cout << "adduser username password flag    - adds a user account" << endl;
			cout << "flag username flag    - sets GM flag on the account" << endl;
			cout << "startzone zoneshortname    - sets the starting zone" << endl;
			return 0;
		}
		else if (database.GetVariable("disablecommandline", tmp, 2)) {
			if (strlen(tmp) == 1) {
				if (tmp[0] == '1') {
					cout << "Command line disabled in database... exiting" << endl;
					return 0;
				}
			}
		}

		if (strcasecmp(argv[1], "adduser") == 0) {
			if (argc == 5) {
				if (Seperator::IsNumber(argv[4])) {
					if (atoi(argv[4]) >= 0 && atoi(argv[4]) <= 255) {
						if (database.CreateAccount(argv[2], argv[3], atoi(argv[4])) == 0)
							cout << "database.CreateAccount failed." << endl;
						else
							cout << "Account created: Username='" << argv[2] << "', Password='" << argv[3] << ", status=" << argv[4] << endl;
						return 0;
					}
				}
			}
			cout << "Usage: world adduser username password flag" << endl;
			cout << "flag = 0, 1 or 2" << endl;
			return 0;
		}
		else if (strcasecmp(argv[1], "flag") == 0) {
			if (argc == 4) {
				if (Seperator::IsNumber(argv[3])) {
					if (atoi(argv[3]) >= 0 && atoi(argv[3]) <= 255) {
						if (database.SetGMFlag(argv[2], atoi(argv[3])))
							cout << "Account flagged: Username='" << argv[2] << "', status=" << argv[3] << endl;
						else
							cout << "database.SetGMFlag failed." << endl;
						return 0;
					}
				}
			}
			cout << "Usage: world flag username flag" << endl;
			cout << "flag = 0-9" << endl;
			return 0;
		}
		else if (strcasecmp(argv[1], "startzone") == 0) {
			if (argc == 3) {
				if (strlen(argv[2]) < 3) {
					cout << "Error: zone name too short" << endl;
				}
				else if (strlen(argv[2]) > 15) {
					cout << "Error: zone name too long" << endl;
				}
				else {
					if (database.SetVariable("startzone", argv[2]))
						cout << "Starting zone changed: '" << argv[2] << "'" << endl;
					else
						cout << "database.SetVariable failed." << endl;
				}
				return 0;
			}
			cout << "Usage: world startzone zoneshortname" << endl;
			return 0;
		}
		cout << "Error, unknown command line option" << endl;
		return 0;
	}

	cout << "Loading items...";
	database.LoadItems();
	cout << "done." << endl;
	cout << "Loading guild ranks...";
	database.LoadGuilds(guilds);
	cout << "done." << endl;

	InitTCP();
	net.Init();

	if (strlen(net.GetWorldAddress()) == 0)
		cout << "World server listening on: port " << PORT << endl;
	else
		cout << "World server listening on: " << net.GetWorldAddress() << ":" << PORT << endl;

	#ifdef WIN32
		_beginthread(ConsoleLoop, 0, NULL);
		_beginthread(ZoneServerLoop, 0, NULL);
	#else
		pthread_t thread1, thread2;
		pthread_create(&thread1, NULL, &ConsoleLoop, NULL);
		pthread_create(&thread2, NULL, &ZoneServerLoop, NULL);
	#endif

	Timer InterserverTimer(INTERSERVER_TIMER); // does MySQL pings and auto-reconnect
	InterserverTimer.Trigger();
	while(RunLoops)
	{
		Timer::SetCurrentTime();
		net.ListenNewClients();
		if (InterserverTimer.Check()) {
			InterserverTimer.Start();
			database.ping();
			if (net.LoginServerInfo && loginserver == 0) {
#ifdef WIN32
				_beginthread(AutoInitLoginServer, 0, NULL);
#else
				pthread_t thread;
				pthread_create(&thread, NULL, &AutoInitLoginServer, NULL);
#endif
			}
		}
		if (numclients == 0)
		{
			Sleep(10);
			continue;
		}
		client_list.Process();
		Sleep(1);
	}
	while (ZoneLoopRunning || ConsoleLoopRunning || LoginLoopRunning) {
		Sleep(1);
	}
	return 0;
}

void CatchSignal(int sig_num)
{
	cout << "Got signal " << sig_num << endl;
	RunLoops = false;
}

bool NetConnection::Init()
{
	struct sockaddr_in address;
	int reuse_addr = 1;
	
	// Disgrace: for windows compile
#ifdef WIN32
	unsigned long nonblocking = 1;
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;

	WSAStartup (version, &wsadata);
#endif


  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up UDP port for new clients */
	listening_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (listening_socket < 0) 
 	{
	
		return false;
	}

	// Disgrace: for windows compile
#ifndef WIN32
	setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));
#else
	setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse_addr, sizeof(reuse_addr));
#endif

	if (bind(listening_socket, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
		// Disgrace: for windows compile
		#ifdef WIN32
			closesocket(listening_socket);
		#else
			close(listening_socket);
		#endif
		
		return false;
	}

	// Disgrace: for windows compile
#ifndef WIN32
	fcntl(listening_socket, F_SETFL, O_NONBLOCK);
#else
	ioctlsocket (listening_socket, FIONBIO, &nonblocking);
#endif


	return true;
}

void NetConnection::ListenNewClients()
{
	
    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	// Disgrace: for windows compile
#ifndef WIN32
	status = recvfrom(listening_socket, &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, &fromlen);
#else
	status = recvfrom(listening_socket, (char *) &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, (int *) &fromlen);
#endif

    if (status > 1)
    {
		Client* client = 0;

		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		client = client_list.Get(in.s_addr, from.sin_port);
		if (client == 0)
		{
			// If it is a new client make sure it has the starting flag set. Ignore otherwise
            if (buffer[0] & 0x20)
			{
				cout << Timer::GetCurrentTime() << " New client from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << endl;
			    client = new Client(in.s_addr, port, listening_socket);
			    client_list.Add(client);
				numclients++;
			}
			else {
				return;
			}
		}
		else {
//			cout << Timer::GetCurrentTime() << " Data from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << " length: " << status << endl;
		}
		client->ReceiveData(buffer, status);
    }
}

bool NetConnection::ReadLoginINI() {
	char buf[201], type[201];
	int items[2] = {0, 0};
	FILE *f;

	if (!(f = fopen ("LoginServer.ini", "r"))) {
		printf ("Couldn't open the LoginServer.ini file.\n");
		return false;
	}
	do {
		fgets (buf, 200, f);
		if (feof (f))
		{
			printf ("[LoginServer] block not found in LoginServer.ini.\n");
			fclose (f);
			return false;
		}
	}
	while (strncasecmp (buf, "[LoginServer]\n", 14) != 0 && strncasecmp (buf, "[LoginServer]\r\n", 15) != 0);

	while (!feof (f))
	{
#ifdef WIN32
		if (fscanf (f, "%[^=]=%[^\n]\r\n", type, buf) == 2)
#else
		if (fscanf (f, "%[^=]=%[^\r\n]\n", type, buf) == 2)
#endif
		{
			if (!strncasecmp (type, "loginserver", 11)) {
				strncpy (loginaddress, buf, 100);
				items[0] = 1;
			}
			if (!strncasecmp (type, "worldname", 9)) {
				char tmp[200];
				strncpy (tmp, buf, 180);
				sprintf(tmp, "%s [%s]", tmp, CURRENT_VERSION);
				strncpy (worldname, tmp, 200);
				items[1] = 1;
			}
			if (!strncasecmp (type, "account", 7)) {
				strncpy(worldaccount, buf, 30);
			}
			if (!strncasecmp (type, "password", 8)) {
				strncpy (worldpassword, buf, 30);
			}
			if (!strncasecmp (type, "locked", 6)) {
				if (strcasecmp(buf, "true") == 0 || (buf[0] == '1' && buf[1] == 0))
					world_locked = true;
			}
			if (!strncasecmp (type, "worldaddress", 12)) {
				strncpy (worldaddress, buf, 250);
			}
			if (!strncasecmp(type, "loginport", 9)) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport = atoi(buf);
				}
			}
		}
	}

	if (!items[0] || !items[1])
	{
		cout << "Incomplete LoginServer.INI file." << endl;
		fclose (f);
		return false;
	}

/*	if (strcasecmp(worldname, "Unnamed server") == 0) {
		cout << "LoginServer.ini: server unnamed, disabling uplink" << endl;
		fclose (f);
		return false;
	}*/
	
	fclose (f);
	cout << "LoginServer.ini read." << endl;
	return true;
}
