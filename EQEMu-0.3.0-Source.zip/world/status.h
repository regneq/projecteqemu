#ifndef STATUS_H
#define STATUS_H

#ifdef WIN32
void StatusLoop(void *tmp);
#else
void *StatusLoop(void *tmp);
#endif

class Stats {
public:

	bool ReadINI();
	void WriteXML();
	Stats() {
		loaded = false;
		interval = 0;
		memset(fileout, 0, sizeof(fileout));
		ReadINI();
	}
	~Stats();
	int32 GetInterval() { return interval; }
	char* GetFilename() { return (char*) fileout; }
	
private:

	char fileout[200];
	int32 interval;
	boolean loaded;
};
#endif