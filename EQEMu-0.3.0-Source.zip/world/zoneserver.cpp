#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <errno.h>
	#include <pthread.h>

	#include "../common/unix.h"

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1

	extern int errno;
#endif

#include "../common/servertalk.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "../common/classes.cpp"
#include "../common/races.h"
#include "../common/seperator.h"
#include "zoneserver.h"
#include "net.h"
#include "client.h"
#include "LoginServer.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

extern Database			database;
extern uint32			numclients;
extern uint32			numzones;
extern ZSList			zoneserver_list;
extern ClientList		client_list;
extern volatile bool	RunLoops;
extern ConsoleList		console_list;
extern GuildRanks_Struct guilds[512];
extern bool GetZoneLongName(char* short_name, char** long_name);
extern NetConnection net;
extern LoginServer* loginserver;
volatile bool ZoneLoopRunning = false;

#ifdef WIN32
void ZoneServerLoop(void *tmp);
#else
void *ZoneServerLoop(void *tmp);
#endif
void ListenNewZoneServer();
bool InitZoneServer();

ZoneServer::ZoneServer(int32 in_ip, int16 in_port, int in_send_socket) : WorldTCPConnection() {
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	ID = zoneserver_list.GetNextID();
	timeout_timer = new Timer(SERVER_TIMEOUT);
	memset(zone_name, 0, sizeof(zone_name));

	memset(clientaddress, 0, sizeof(clientaddress));
	clientport = 0;
	BootingUp = false;
}

ZoneServer::~ZoneServer()
{
	delete timeout_timer;
	if (RunLoops)
		zoneserver_list.ClientRemove(0, this->GetZoneName());
	shutdown(send_socket, 0x01);
	shutdown(send_socket, 0x00);
	// TODO: Unregister zone
}

bool ZoneServer::SetZone(char* zonename) {
	BootingUp = false;
	if (strlen(zonename) >= 15) { // Dunno why this would ever happen, but...
		cerr << "ERROR: strlen(zonename) >= 15!" << endl;
		return false;
	}
	strcpy(zone_name, zonename);
	cout << "Zoneserver SetZone: " << GetCAddress() << ":" << GetCPort() << " " << zonename << endl;
	// TODO: Register zone in DB
	client_list.ZoneBootup(this);
	return true;
}

bool ZoneServer::SetConnectInfo(char* in_address, int16 in_port) {
	client_list.ZoneBootup(this);
	strcpy(clientaddress, in_address);
	clientport = in_port;
	struct in_addr  in;
	in.s_addr = GetIP();
	cout << "Zoneserver SetConnectInfo: " << inet_ntoa(in) << ":" << GetPort() << ": " << clientaddress << ":" << clientport << endl;
	return true;
}

bool ZoneServer::Process()
{
#ifdef WIN32
    SOCKADDR_IN to;
#else
    struct sockaddr_in to;
#endif

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	ServerPacket *pack = 0;
	while(pack = RecvQueuePop())
	{
		switch(pack->opcode) {
		case 0:
		break;
		case ServerOP_KeepAlive: {
			// ignore this
			break;
		}
		case ServerOP_ChannelMessage: {
			ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;
			if (scm->chan_num == 7) {
				ClientListEntry* cle = zoneserver_list.FindCharacter(scm->deliverto);
				if (cle == 0) {
					if (!scm->noreply)
						zoneserver_list.SendEmoteMessage(scm->from, 0, 0, "You told %s, '%s is not online at this time'", scm->to, scm->to);
				}
				else if (cle->TellsOff() && ((cle->Anon() == 1 && scm->fromadmin < cle->Admin()) || scm->fromadmin < 100)) {
					if (!scm->noreply)
						zoneserver_list.SendEmoteMessage(scm->from, 0, 0, "You told %s, '%s is not online at this time'", scm->to, scm->to);
				}
				else if (cle->Server() == 0) {
					if (!scm->noreply)
						zoneserver_list.SendEmoteMessage(scm->from, 0, 0, "You told %s, '%s is not contactable at this time'", scm->to, scm->to);
				}
				else
					cle->Server()->SendPacket(pack);
			}
			else
				zoneserver_list.SendPacket(pack);
			break;
		}
		case ServerOP_EmoteMessage: {
			ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
			zoneserver_list.SendEmoteMessage(sem->to, sem->guilddbid, sem->type, sem->message);
			break;
		}
		case ServerOP_MultiLineMsg: {
			ServerMultiLineMsg_Struct* mlm = (ServerMultiLineMsg_Struct*) pack->pBuffer;
			zoneserver_list.SendPacket(mlm->to, pack);
			break;
		}
		case ServerOP_SetZone: {
			if (pack->size > 1) {
				SetZone((char*) &pack->pBuffer[0]);
			}
			else
				SetZone("");
			break;
		}
		case ServerOP_SetConnectInfo: {
			if (pack->size != sizeof(ServerConnectInfo))
				break;

			ServerConnectInfo* sci = (ServerConnectInfo*) pack->pBuffer;
			SetConnectInfo(sci->address, sci->port);
			break;
		}
		case ServerOP_ShutdownAll: {
			zoneserver_list.SendPacket(pack);
			zoneserver_list.Process();
			CatchSignal(0);
			break;
		}
		case ServerOP_ZoneShutdown: {
			ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
			ZoneServer* zs = 0;
			if (s->ZoneServerID != 0)
				zs = zoneserver_list.FindByID(s->ZoneServerID);
			else if (s->zonename[0] != 0)
				zs = zoneserver_list.FindByName(s->zonename);
			else
				zoneserver_list.SendEmoteMessage(s->adminname, 0, 0, "Error: SOP_ZoneShutdown: neither ID nor name specified");

			if (zs == 0)
				zoneserver_list.SendEmoteMessage(s->adminname, 0, 0, "Error: SOP_ZoneShutdown: zoneserver not found");
			else
				zs->SendPacket(pack);
			break;
		}
		case ServerOP_ZoneBootup: {
			ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
			ZSList::SOPZoneBootup(s->adminname, s->ZoneServerID, s->zonename);
			break;
		}
		case ServerOP_ZoneStatus: {
			if (pack->size >= 1)
				zoneserver_list.SendZoneStatus((char *) &pack->pBuffer[1], (int8) pack->pBuffer[0], this);
			break;

		}
		case ServerOP_ClientList: {
			ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
			if (scl->remove)
				zoneserver_list.ClientRemove(scl->name, scl->zone);
			else
				zoneserver_list.ClientUpdate(this, scl->name, scl->AccountID, scl->AccountName, scl->Admin, scl->zone, scl->level, scl->class_, scl->race, scl->anon, scl->tellsoff, scl->guilddbid, scl->guildeqid, scl->LFG);
			break;
		}
		case ServerOP_Who: {
			ServerWhoAll_Struct* whoall = (ServerWhoAll_Struct*) pack->pBuffer;
			Who_All_Struct* whom = new Who_All_Struct;
			memset(whom,0,sizeof(Who_All_Struct));
			whom->firstlvl = whoall->firstlvl;
			whom->gmlookup = whoall->gmlookup;
			whom->secondlvl = whoall->secondlvl;
			whom->wclass = whoall->wclass;
			whom->wrace = whoall->wrace;
			strcpy(whom->whom,whoall->whom);
			zoneserver_list.SendWhoAll(whoall->from, whoall->admin, whom, this);
			delete whom;
			break;
		}
		case ServerOP_ZonePlayer: {
			ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
			zoneserver_list.SendPacket(pack);
			break;
		}
		case ServerOP_KickPlayer: {
			zoneserver_list.SendPacket(pack);
			break;
		}
		case ServerOP_KillPlayer: {
			zoneserver_list.SendPacket(pack);
			break;
		}
		case ServerOP_RefreshGuild: {
			if (pack->size == 5) {
				int32 guildeqid = 0xFFFFFFFF;
				memcpy(&guildeqid, pack->pBuffer, 4);
				database.GetGuildRanks(guildeqid, &guilds[guildeqid]);
				zoneserver_list.SendPacket(pack);
			}
			else
				cout << "Wrong size: ServerOP_RefreshGuild. size=" << pack->size << endl;
			break;
		}
		case ServerOP_GuildLeader:
		case ServerOP_GuildInvite:
		case ServerOP_GuildRemove:
		case ServerOP_GuildPromote:
		case ServerOP_GuildDemote:
		case ServerOP_GuildGMSet:
		case ServerOP_GuildGMSetRank:
		{
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			ClientListEntry* cle = zoneserver_list.FindCharacter(sgc->target);
			if (cle == 0)
				zoneserver_list.SendEmoteMessage(sgc->from, 0, 0, "%s is not online.", sgc->target);
			else if (cle->Server() == 0)
				zoneserver_list.SendEmoteMessage(sgc->from, 0, 0, "%s is not online.", sgc->target);
			else if ((cle->Admin() >= 100 && sgc->admin < 100) && cle->GuildDBID() != sgc->guilddbid) // no peeping for GMs, make sure tell message stays the same
				zoneserver_list.SendEmoteMessage(sgc->from, 0, 0, "%s is not online.", sgc->target);
			else
				cle->Server()->SendPacket(pack);
			break;
		}
		case ServerOP_FlagUpdate: {
			zoneserver_list.SendPacket(pack);
			break;
		}
		case ServerOP_GMGoto: {
			if (pack->size != sizeof(ServerGMGoto_Struct)) {
				cout << "Wrong size on ServerOP_GMGoto. Got: " << pack->size << ", Expected: " << sizeof(ServerGMGoto_Struct) << endl;
				break;
			}
			ServerGMGoto_Struct* gmg = (ServerGMGoto_Struct*) pack->pBuffer;
			ClientListEntry* cle = zoneserver_list.FindCharacter(gmg->gotoname);
			if (cle != 0) {
				if (cle->Server() == 0)
					this->SendEmoteMessage(gmg->myname, 0, 13, "Error: Cannot identify %s's zoneserver.", gmg->gotoname);
				else if (cle->Anon() == 1 && cle->Admin() > gmg->admin) // no snooping for anon GMs
					this->SendEmoteMessage(gmg->myname, 0, 13, "Error: %s not found", gmg->gotoname);
				else
					cle->Server()->SendPacket(pack);
			}
			else {
				this->SendEmoteMessage(gmg->myname, 0, 13, "Error: %s not found", gmg->gotoname);
			}
			break;
		}
		case ServerOP_Lock: {
			if (pack->size != sizeof(ServerLock_Struct)) {
				cout << "Wrong size on ServerOP_Lock. Got: " << pack->size << ", Expected: " << sizeof(ServerLock_Struct) << endl;
				break;
			}
		    ServerLock_Struct* slock = (ServerLock_Struct*) pack->pBuffer;
  			if (slock->mode >= 1) 
				net.world_locked = true;
			else
				net.world_locked = false;
			if (loginserver == 0)
			{
				if (slock->mode >= 1)
					this->SendEmoteMessage(slock->myname, 0, 13, "World locked, but login server not connected.");
				else 
					this->SendEmoteMessage(slock->myname, 0, 13, "World unlocked, but login server not conencted.");
			}
			else
			{
				loginserver->SendStatus();
				if (slock->mode >= 1)
					this->SendEmoteMessage(slock->myname, 0, 13, "World locked");
				else
					this->SendEmoteMessage(slock->myname, 0, 13, "World unlocked");
			}
			break;
		}
		case ServerOP_Motd: {
			if (pack->size != sizeof(ServerMotd_Struct)) {
				cout << "Wrong size on ServerOP_Motd. Got: " << pack->size << ", Expected: " << sizeof(ServerMotd_Struct) << endl;
				break;
			}
			ServerMotd_Struct* smotd = (ServerMotd_Struct*) pack->pBuffer;
			database.SetVariable("MOTD",smotd->motd);
			this->SendEmoteMessage(smotd->myname, 0, 13, "Updated Motd.");
			break;
		}
		case ServerOP_Uptime: {
			if (pack->size != sizeof(ServerUptime_Struct)) {
				cout << "Wrong size on ServerOP_Uptime. Got: " << pack->size << ", Expected: " << sizeof(ServerUptime_Struct) << endl;
				break;
			}
			ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
			if (sus->zoneserverid == 0) {
				int32 ms = Timer::GetCurrentTime();
				int32 d = ms / 86400000;
				ms -= d * 86400000;
				int32 h = ms / 3600000;
				ms -= h * 3600000;
				int32 m = ms / 60000;
				ms -= m * 60000;
				int32 s = ms / 1000;
				if (d)
					this->SendEmoteMessage(sus->adminname, 0, 0, "Worldserver Uptime: %02id %02ih %02im %02is", d, h, m, s);
				else if (h)
					this->SendEmoteMessage(sus->adminname, 0, 0, "Worldserver Uptime: %02ih %02im %02is", h, m, s);
				else
					this->SendEmoteMessage(sus->adminname, 0, 0, "Worldserver Uptime: %02im %02is", m, s);
			}
			else {
				ZoneServer* zs = zoneserver_list.FindByID(sus->zoneserverid);
				if (zs)
					zs->SendPacket(pack);
			}
			break;
		}
		case ServerOP_Petition: {
			zoneserver_list.SendPacket(pack);
			break;
		}
		default:
		{
			cout << "Unknown ServerOPcode:" << (int)pack->opcode;
			cout << " size:" << pack->size << endl;
DumpPacket(pack->pBuffer, pack->size);
			break;
		}
		}

		delete pack;
	}    
	/************ Get first send packet on queue and send it! ************/
	SPackSendQueue* p = 0;
	int status = 0;
	while(p = SendQueuePop())
	{
//		cout << "p->size=" << p->size << endl;
#ifdef WIN32
		status = send(send_socket, (const char *) p->buffer, p->size, 0);
#else
		status = send(send_socket, p->buffer, p->size, 0);
#endif
		delete p;
		if (status == SOCKET_ERROR) {
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Zoneserver send() failed, assumed disconnect: #" << GetID() << " " << zone_name << " " << inet_ntoa(in) << ":" << GetPort() << " (" << GetCAddress() << ":" << GetCPort() << ")" << endl;
#ifdef WIN32
			cout << "send_socket=" << send_socket << ", Status: " << status << ", Errorcode: " << WSAGetLastError() << endl;
#else
			cout << "send_socket=" << send_socket << ", Status: " << status << ", Errorcode: " << strerror(errno) << endl;
#endif
			return false;
		}
	}
	/************ Processing finished ************/
    if (timeout_timer->Check())
    {
		// this'll hit the "send error, assumed disconnect" if the zoneserver has gone byebye
		pack = new ServerPacket;
		pack->opcode = ServerOP_KeepAlive;
		pack->size = 0;
		SendPacket(pack);
		delete pack;
    }

	return true;
}

void ZoneServer::SendPacket(ServerPacket* pack) {
	SPackSendQueue* spsq = (SPackSendQueue*) new uchar[sizeof(SPackSendQueue) + pack->size + 4];
	if (pack->pBuffer != 0 && pack->size != 0)
		memcpy((char *) &spsq->buffer[4], (char *) pack->pBuffer, pack->size);
	memcpy((char *) &spsq->buffer[0], (char *) &pack->opcode, 2);
	spsq->size = pack->size+4;
	memcpy((char *) &spsq->buffer[2], (char *) &spsq->size, 2);
	LockMutex lock(&MPacketLock);
	ServerSendQueue.push(spsq);
}

SPackSendQueue* ZoneServer::SendQueuePop() {
	SPackSendQueue* spsq = 0;
	LockMutex lock(&MPacketLock);
	spsq = ServerSendQueue.pop();
	return spsq;
}

void ZoneServer::RecvPacket(ServerPacket* pack) {
	LockMutex lock(&MPacketLock);
	ServerRecvQueue.push(pack);
}

ServerPacket* ZoneServer::RecvQueuePop() {
	ServerPacket* pack = 0;
	LockMutex lock(&MPacketLock);
	pack = ServerRecvQueue.pop();
	return pack;
}

bool ZoneServer::ReceiveData() {
    uchar		buffer[10240];
	
    int			status;
    unsigned short	port;

    struct in_addr	in;

    status = recv(send_socket, (char *) &buffer, sizeof(buffer), 0);

    if (status > 1)
    {
		in.s_addr = GetIP();

//cout << "TCPData from ip: " << inet_ntoa(in) << " port:" << GetPort() << " length: " << status << endl;
//DumpPacket(buffer, status);

		timeout_timer->Start();
		int16 base = 0;
		int16 size = 0;
// Fucking TCP stack will throw all the packets queued at you at once in one buffer
// Have to find the packet splitpoints
// Hoping it'll never throw only half a packet, but who knows :/
		while (base < status) {
			size = 4;
			if ((status - base) < 4)
				cout << "ZoneServer: packet too short for processing" << endl;
			else {
				ServerPacket* pack = new ServerPacket;
				memcpy((char*) &size, (char*) &buffer[base + 2], 2);

				memcpy((char*) &pack->opcode, (char*) &buffer[base + 0], 2);
				pack->size = size - 4;
				if (size > 4) {
					pack->pBuffer = new uchar[pack->size];
					memcpy((char*) pack->pBuffer, (char*) &buffer[base + 4], pack->size);
				} else
					pack->pBuffer = 0;
//cout << "Packet from zoneserver: OPcode=" << pack->opcode << " size=" << pack->size << endl;
//DumpPacket(buffer, status);
				RecvPacket(pack);
			}
			base += size;
		}
	} else if (status == SOCKET_ERROR) {
#ifdef WIN32
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
#else
		if (!(errno == EWOULDBLOCK)) {
#endif
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Zoneserver connection lost: " << zone_name << " " << inet_ntoa(in) << ":" << GetPort() << " (" << GetCAddress() << ":" << GetCPort() << ")" << endl;
			return false;
		}
	}
	return true;
}

ZSList::ZSList() {
	NextID = 1;
}

ZSList::~ZSList() {
}

void ZSList::Add(ZoneServer* zoneserver)
{
	LockMutex lock(&MListLock);
	list.Insert(zoneserver);
}

void ZSList::Process()
{
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing zoneserver from ip:" << inet_ntoa(in) << " port:" << (int16)(iterator.GetData()->GetPort()) << " (" << iterator.GetData()->GetCAddress() << ":" << iterator.GetData()->GetCPort() << ")" << endl;
			iterator.RemoveCurrent();
			numzones--;
		}
		else
		{
			iterator.Advance();
		}
	}
}

void ZSList::ReceiveData() {
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->ReceiveData()) {
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing zoneserver: " << iterator.GetData()->GetZoneName() << " " << inet_ntoa(in) << ":" << (int16)(iterator.GetData()->GetPort()) << " (" << iterator.GetData()->GetCAddress() << ":" << iterator.GetData()->GetCPort() << ")" << endl;
			iterator.RemoveCurrent();
			numzones--;
		} else {
			iterator.Advance();
		}

	}
}

void ZSList::SendPacket(ServerPacket* pack) {
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->SendPacket(pack);
		iterator.Advance();
	}
}

void ZSList::SendPacket(char* to, ServerPacket* pack) {
	if (to == 0 || to[0] == 0)
		zoneserver_list.SendPacket(pack);
	else if (to[0] == '*') {
		// Cant send a packet to a console....
		return;
	}
	else {
		ClientListEntry* cle = zoneserver_list.FindCharacter(to);
		if (cle != 0) {
			if (cle->Server() != 0)
				cle->Server()->SendPacket(pack);
			return;
		}
		else {
			ZoneServer* zs = zoneserver_list.FindByName(to);
			if (zs != 0) {
				zs->SendPacket(pack);
				return;
			}
		}
	}
}

ZoneServer* ZSList::FindByName(char* zonename) {
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->GetZoneName(), zonename) == 0) {
			ZoneServer* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

ZoneServer* ZSList::FindByID(int32 ZoneID) {
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == ZoneID) {
			ZoneServer* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

void ZSList::SendZoneStatus(char* to, int8 admin, WorldTCPConnection* connection) {
	LinkedListIterator<ZoneServer*> iterator(list);
	struct in_addr  in;
	
	LockMutex lock(&MListLock);
	iterator.Reset();
	char locked[4];
	if (net.world_locked == true)
		strcpy(locked, "Yes");
	else
		strcpy(locked, "No");
	connection->SendEmoteMessage(to, 0, 0, "World Locked: %s", locked);
	connection->SendEmoteMessage(to, 0, 0, "Zoneservers online:");
	int x=0, y=0;
	while(iterator.MoreElements())
	{
		in.s_addr = iterator.GetData()->GetIP();

		if (admin >= 150) {
			connection->SendEmoteMessage(to, 0, 0, "  #%i  %s:%i  %s:%i  %s", iterator.GetData()->GetID(), inet_ntoa(in), iterator.GetData()->GetPort(), iterator.GetData()->GetCAddress(), iterator.GetData()->GetCPort(), iterator.GetData()->GetZoneName());
			x++;
		}
		else if (strlen(iterator.GetData()->GetZoneName()) != 0) {
			connection->SendEmoteMessage(to, 0, 0, "  #%i  %s", iterator.GetData()->GetID(), iterator.GetData()->GetZoneName());
			x++;
		}
		y++;
		iterator.Advance();
	}
	connection->SendEmoteMessage(to, 0, 0, "%i servers listed. %i servers online.", x, y);
}

void ZSList::SendChannelMessage(char* from, char* to, int8 chan_num, int8 language, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->opcode = ServerOP_ChannelMessage;
	pack->size = sizeof(ServerChannelMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;
	if (from == 0) {
		strcpy(scm->from, "WServer");
		scm->noreply = true;
	}
	else if (from[0] == 0) {
		strcpy(scm->from, "WServer");
		scm->noreply = true;
	}
	else
		strcpy(scm->from, from);
	if (to != 0) {
		strcpy((char *) scm->to, to);
		strcpy((char *) scm->deliverto, to);
	}
	else {
		scm->to[0] = 0;
		scm->deliverto[0] = 0;
	}

	scm->language = language;
	scm->chan_num = chan_num;
	strcpy(&scm->message[0], buffer);
	zoneserver_list.SendPacket(pack);
	delete pack;
}

void ZoneServer::SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->opcode = ServerOP_EmoteMessage;
	pack->size = sizeof(ServerEmoteMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
	
	if (to != 0) {
		strcpy((char *) sem->to, to);
	}
	else {
		sem->to[0] = 0;
	}

	sem->guilddbid = to_guilddbid;
	sem->type = type;
	strcpy(&sem->message[0], buffer);

	this->SendPacket(pack);
	delete pack;
}

void ZSList::SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->opcode = ServerOP_EmoteMessage;
	pack->size = sizeof(ServerEmoteMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
	
	if (to != 0) {
		strcpy((char *) sem->to, to);
	}
	else {
		sem->to[0] = 0;
	}

	sem->guilddbid = to_guilddbid;
	sem->type = type;
	strcpy(&sem->message[0], buffer);

	if (sem->to[0] == 0)
		zoneserver_list.SendPacket(pack);
	else {
		ZoneServer* zs = zoneserver_list.FindByName(sem->to);
		Console* con = 0;
		if (sem->to[0] == '*')
			con = console_list.FindByAccountName(&sem->to[1]);

		if (zs != 0)
			zs->SendPacket(pack);
		else if (con != 0)
			con->SendExtMessage(sem->message);
		else
			zoneserver_list.SendPacket(pack);
	}
	delete pack;
}

void ZSList::ClientRemove(char* name, char* zone) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->zone(), zone) == 0) {
			if (name == 0)
				iterator.RemoveCurrent();
			else if (name[0] == 0)
				iterator.RemoveCurrent();
			else if (strcasecmp(iterator.GetData()->name(), name) == 0) {
				iterator.RemoveCurrent();
				return;
			}
		}
		iterator.Advance();
	}
}

ClientListEntry* ZSList::FindCharacter(char* name) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->name(), name) == 0) {
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

void ZSList::CLCheckStale() {
	return;
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->CheckStale()) {
			iterator.RemoveCurrent();
		}
		else
			iterator.Advance();
	}
}

void ZSList::ClientUpdate(ZoneServer* zoneserver, char* name, int32 accountid, char* accountname, int8 admin, char* zone, int8 level, int8 class_, int8 race, int8 anon, bool tellsoff, int32 guilddbid, int32 guildeqid, bool LFG) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->name(), name) == 0) {
			iterator.GetData()->Update(zoneserver, name, accountid, accountname, admin, zone, level, class_, race, anon, tellsoff, guilddbid, guildeqid, LFG);
			return;
		}
		iterator.Advance();
	}
	ClientListEntry* tmp = new ClientListEntry(zoneserver, name, accountid, accountname, admin, zone, level, class_, race, anon, tellsoff, guilddbid, guildeqid, LFG);
	clientlist.Insert(tmp);
}

void ZSList::SendWhoAll(char* to, int8 admin, Who_All_Struct* whom, WorldTCPConnection* connection) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);
	iterator.Reset();
	char tmpgm[25] = "";
	char accinfo[150] = "";
	char line[300] = "";
	char tmpguild[50] = "";
	char LFG[10] = "";
	int32 x = 0;
	int whomlen = 0;
	if (whom)
		whomlen = strlen(whom->whom);

	connection->SendEmoteMessage(to, 0, 10, "Players on server:");
	while(iterator.MoreElements()) {
		if (whom == 0 || (
(iterator.GetData()->Admin() >= 80 || whom->gmlookup == 0xFFFF) && 
(whom->wclass == 0xFFFF || iterator.GetData()->class_() == whom->wclass) && 
(whom->wrace == 0xFFFF || iterator.GetData()->race() == whom->wrace) && 
(whomlen == 0 || strncasecmp(iterator.GetData()->zone(),whom->whom, whomlen) == 0 || strncasecmp(iterator.GetData()->name(),whom->whom, whomlen) == 0 || (iterator.GetData()->GuildEQID() != 0xFFFFFFFF && strncasecmp(guilds[iterator.GetData()->GuildEQID()].name, whom->whom, whomlen) == 0) || (admin >= 100 && strncasecmp(iterator.GetData()->AccountName(), whom->whom, whomlen) == 0))
)) {
			line[0] = 0;
			if (iterator.GetData()->Admin() == 101)
				strcpy(tmpgm, "* GM-Events *");
			else if (iterator.GetData()->Admin() == 80)
				strcpy(tmpgm, "* Quest Troupe *");
			else if (iterator.GetData()->Admin() >= 200)
				strcpy(tmpgm, "* ServerOP *");
			else if (iterator.GetData()->Admin() >= 150)
				strcpy(tmpgm, "* Lead-GM *");
			else if (iterator.GetData()->Admin() >= 100)
				strcpy(tmpgm, "* GM *");
			else
				tmpgm[0] = 0;

			if (iterator.GetData()->GuildEQID() != 0xFFFFFFFF) {
				if (guilds[iterator.GetData()->GuildEQID()].databaseID == 0)
					tmpguild[0] = 0;
				else
					snprintf(tmpguild, 36, " <%s>", guilds[iterator.GetData()->GuildEQID()].name);
			}
			else
				tmpguild[0] = 0;

			if (iterator.GetData()->LFG())
				strcpy(LFG, " LFG");
			else
				LFG[0] = 0;

			if (admin >= 150 && admin >= iterator.GetData()->Admin()) {
				sprintf(accinfo, " AccID: %i AccName: %s Status: %i", iterator.GetData()->AccountID(), iterator.GetData()->AccountName(), iterator.GetData()->Admin());
			}
			else
				accinfo[0] = 0;

			if (iterator.GetData()->Anon() == 2) { // Roleplay
				if (admin >= 100 && admin >= iterator.GetData()->Admin())
					sprintf(line, "  %s[RolePlay %i %s] %s (%s)%s zone: %s%s%s", tmpgm, iterator.GetData()->level(), GetClassName(iterator.GetData()->class_()), iterator.GetData()->name(), GetRaceName(iterator.GetData()->race()), tmpguild, iterator.GetData()->zone(), LFG, accinfo);
				else if (iterator.GetData()->Admin() >= 100 && admin < 100) {
					iterator.Advance();
					continue;
				}
				else
					sprintf(line, "  %s[ANONYMOUS] %s%s%s%s", tmpgm, iterator.GetData()->name(), tmpguild, LFG, accinfo);
			}
			else if (iterator.GetData()->Anon() == 1) { // Anon
				if (admin >= 100 && admin >= iterator.GetData()->Admin())
					sprintf(line, "  %s[ANON %i %s] %s (%s)%s zone: %s%s%s", tmpgm, iterator.GetData()->level(), GetClassName(iterator.GetData()->class_()), iterator.GetData()->name(), GetRaceName(iterator.GetData()->race()), tmpguild, iterator.GetData()->zone(), LFG, accinfo);
				else if (iterator.GetData()->Admin() >= 100) {
					iterator.Advance();
					continue;
				}
				else
					sprintf(line, "  %s[ANONYMOUS] %s%s%s", tmpgm, iterator.GetData()->name(), LFG, accinfo);
			}
			else
				sprintf(line, "  %s[%i %s] %s (%s)%s zone: %s%s%s", tmpgm, iterator.GetData()->level(), GetClassName(iterator.GetData()->class_()), iterator.GetData()->name(), GetRaceName(iterator.GetData()->race()), tmpguild, iterator.GetData()->zone(), LFG, accinfo);

			connection->SendEmoteMessage(to, 0, 10, line);
			x++;
		}
		iterator.Advance();
	}


	if (connection == 0)
		zoneserver_list.SendEmoteMessage(to, 0, 10, "%i players online", x);
	else
		connection->SendEmoteMessage(to, 0, 10, "%i players online", x);
//		connection->SendMessage(1, "%i players online", x);

	if (admin >= 100)
		console_list.SendConsoleWho(to, admin, connection);
}

#ifdef WIN32
void ZoneServerLoop(void *tmp) {
#else
void *ZoneServerLoop(void *tmp) {
#endif
	ZoneLoopRunning = true;
	while(RunLoops) {
		zoneserver_list.ReceiveData();
		zoneserver_list.Process();
		zoneserver_list.CLCheckStale();
		Sleep(1);
	}
	ZoneLoopRunning = false;
}

void ZSList::SOPZoneBootup(char* adminname, int32 ZoneServerID, char* zonename) {
	ZoneServer* zs = 0;
	ZoneServer* zs2 = 0;
	char* crap;
	if (!database.GetZoneLongName(zonename, &crap))
		zoneserver_list.SendEmoteMessage(adminname, 0, 0, "Error: SOP_ZoneBootup: zone '%s' not found in 'zone' table. Typo protection=ON.", zonename);
	else {
		if (ZoneServerID != 0)
			zs = zoneserver_list.FindByID(ZoneServerID);
		else
			zoneserver_list.SendEmoteMessage(adminname, 0, 0, "Error: SOP_ZoneBootup: ServerID must be specified");

		if (zs == 0)
			zoneserver_list.SendEmoteMessage(adminname, 0, 0, "Error: SOP_ZoneBootup: zoneserver not found");
		else {
			zs2 = zoneserver_list.FindByName(zonename);
			if (zs2 != 0)
				zoneserver_list.SendEmoteMessage(adminname, 0, 0, "Error: SOP_ZoneBootup: zone '%s' already being hosted by ZoneServer #%i", zonename, zs2->GetID());
			else {
				zs->TriggerBootup(zonename, adminname);
			}
		}
	}
	delete[] crap;
}

int32 ZSList::TriggerBootup(char* zonename) {
	LinkedListIterator<ZoneServer*> iterator(list);

	LockMutex lock(&MListLock);
	srand(time(NULL));
	int32 x = 0;
	iterator.Reset();
	while(iterator.MoreElements()) {
		x++;
		iterator.Advance();
	}
	if (x == 0) {
		return 0;
	}

	ZoneServer** tmp = new ZoneServer*[x];
	int32 y = 0;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetZoneName()[0] == 0 && !iterator.GetData()->IsBootingUp()) {
			tmp[y++] = iterator.GetData();
		}
		iterator.Advance();
	}
	if (y == 0) {
		safe_delete(tmp);
		return 0;
	}

	int32 z = rand() % y;
	tmp[z]->TriggerBootup(zonename);
	int32 ret = tmp[z]->GetID();

	safe_delete(tmp);
	return ret;
}

void ZoneServer::TriggerBootup(char* zonename, char* adminname) {
	BootingUp = true;
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_ZoneBootup;
	pack->size = sizeof(ServerZoneStateChange_struct);
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
	s->ZoneServerID = ID;
	if (adminname != 0)
		strcpy(s->adminname, adminname);
	if (zonename == 0)
		strcpy(s->zonename, this->zone_name);
	else
		strcpy(s->zonename, zonename);
	SendPacket(pack);
	delete pack;
}

