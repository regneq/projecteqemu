#ifndef WorldTCPCONNECTION_H
#define WorldTCPCONNECTION_H
class WorldTCPConnection
{
public:
	WorldTCPConnection() { }
	~WorldTCPConnection() { }
	virtual void SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...) { }
};

#endif
