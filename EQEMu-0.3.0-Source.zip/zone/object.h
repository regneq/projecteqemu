#ifndef OBJECT_H
#define OBJECT_H

#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "client.h"
#include "mob.h"
#include "npc.h"
#include "entity.h"

#define OT_DROPPEDITEM	1

class Object: public Entity
{
public:
	Object(int16 type,int16 itemid,float ypos,float xpos, float zpos, int8 heading, char objectname[6]);
	~Object();
	bool	IsObject()			{ return true; }
	void	CreateSpawnPacket(APPLAYER* app);
	void	CreateDeSpawnPacket(APPLAYER* app);
	bool	HandleClick(Client* sender,APPLAYER* app);
	void	SetBagItems(int16 slot, int16 item)	{bagitems[slot] = item;}
	bool	Process()  { return true; }

private:
	int32	itemid;
	int32	dropid;
	float	ypos;
	float	xpos;
	float	zpos;
	int8	heading;
	char	objectname[16];
	int16	objecttype;
	int16	bagitems[10];
};

#endif