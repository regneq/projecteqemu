#include "../common/debug.h"

#include <iostream.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQPacket.h"
#include "../common/EQPacketManager.h"
#include "../common/eq_packet_structs.h"
#include "../common/Mutex.h"

#include "net.h"
#include "client.h"
#include "zone.h"
#include "worldserver.h"
#include "spdat.h"
#include "ClientList.h"

NetConnection		net;
EntityList			entity_list;
WorldServer			worldserver;
int32				numclients = 0;
GuildRanks_Struct	guilds[512];
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern ClientList	client_list;
npcDecayTimes_Struct npcCorpseDecayTimes[100];
volatile bool RunLoops = true;
bool ProcessLoopRunning = false;
extern bool WorldLoopRunning;

#define SPDat_Location	"spdat.eff"
SPDat_Spell_Struct spells[SPDAT_RECORDS];
bool spells_loaded = false;

Database database;
#ifdef WIN32
	#include <process.h>
#else
	#include <pthread.h>
	#include "../common/unix.h"
#endif

void Shutdown();
void LoadSPDat();

Mutex MNetLoop;

int main(int argc, char** argv)
{
#ifdef _DEBUG
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	if (argc != 5)
	{
		cerr << "Usage: zone zone_name address port worldaddress" << endl;
		exit(0);
	}

	char* zone_name = argv[1];
	char* address = argv[2];
	int32 port = atoi(argv[3]);
	char* worldaddress = argv[4];

	if (strlen(address) <= 0)
	{
		cerr << "Invalid address" << endl;
		exit(0);
	}
	if (port <= 0)
	{
		cerr << "Bad port specified" << endl;
		exit(0);
	}
	if (strlen(worldaddress) <= 0)
	{
		cerr << "Invalid worldaddress" << endl;
		exit(0);
	}
	if (signal(SIGINT, CatchSignal) == SIG_ERR)
	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	net.SaveInfo(address, port, worldaddress);

	cout << "Loading items & NPCs...";
	database.LoadItems();
	database.LoadNPCTypes();
	database.GetDecayTimes(npcCorpseDecayTimes);
	cout << "done." << endl;
	LoadSPDat();
	cout << "Loading guild ranks...";
	database.LoadGuilds(guilds);
	cout << "done." << endl;
	cout << "Loading faction data...";
	database.LoadFactionData();
	database.GetDecayTimes(npcCorpseDecayTimes);
	cout << "done." << endl;

	if (!worldserver.Init()) {
		cerr << "InitWorldServer failed" << endl;
	}

//	if (strcmp(zone_name, ".") == 0 || strcasecmp(zone_name, "sleep") == 0) {
			cout << "Entering sleep mode" << endl;
//	} else if (!ZoneBootup(zone_name)) {
//		cerr << "Zone bootup failed" << endl;
//		zone = 0;
//	}

	Timer InterserverTimer(INTERSERVER_TIMER); // does MySQL pings and auto-reconnect
	net.StartProcessLoop();
	MNetLoop.lock();
	while(RunLoops)
	{
		Timer::SetCurrentTime();
		if (ZoneLoaded) {
			net.ListenNewClients();
			client_list.SendPacketQueues();
		}
		if (InterserverTimer.Check()) {
			InterserverTimer.Start();
			database.ping();
			entity_list.UpdateWho();
		}
		MNetLoop.unlock();
		Sleep(1);
		MNetLoop.lock();
	}
	MNetLoop.unlock();
	if (zone != 0)
		Zone::Shutdown(true);
	while (WorldLoopRunning || ProcessLoopRunning) {
		Sleep(1);
	}
	return 0;
}

void CatchSignal(int sig_num)
{

	cout << "Got signal " << sig_num << endl;

	RunLoops = false;
}

void Shutdown()
{
	Zone::Shutdown(true);
	MNetLoop.lock();
	RunLoops = false;
	worldserver.Disconnect();
	MNetLoop.unlock();
//	safe_delete(worldserver);
	cout << "Shutting down..." << endl;
}

bool NetConnection::Init()
{
	struct sockaddr_in address;
	int reuse_addr = 1;
	
	#ifdef WIN32
		unsigned long nonblocking = 1;
		WORD version = MAKEWORD (1,1);
		WSADATA wsadata;
	#endif

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(ZonePort);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up UDP port for new clients */
	listening_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (listening_socket < 0) 
 	{
	
		return false;
	}

//	setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));

	if (bind(listening_socket, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
		#ifdef WIN32
			closesocket(listening_socket);
		#else
			close(listening_socket);
		#endif
		
		return false;
	}

	#ifdef WIN32
		ioctlsocket (listening_socket, FIONBIO, &nonblocking);
	#else
		fcntl(listening_socket, F_SETFL, O_NONBLOCK);
	#endif
	

	return true;
}

void NetConnection::ListenNewClients()
{
	
    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	#ifdef WIN32
		status = recvfrom(listening_socket, (char *) &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, (int *) &fromlen);
	#else
		status = recvfrom(listening_socket, &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, &fromlen);
	#endif
    

    if (status > 1)
    {
		Client* client = 0;

		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

//cout << Timer::GetCurrentTime() << " Data from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << " length: " << status << endl;
		if (!client_list.RecvData(in.s_addr, from.sin_port, buffer, status)) {
			// If it is a new client make sure it has the starting flag set. Ignore otherwise
			if (buffer[0] & 0x20)
			{
				cout << " New client from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << endl;
				client = new Client(in.s_addr, port, listening_socket);
				client->ReceiveData(buffer, status);
	    		entity_list.AddClient(client);
				client_list.Add(client);
				numclients++;
			}
			else
			{
				return;
			}
		}
	}
}

int32 NetConnection::GetIP()
{
	char     name[255+1];
	size_t   len = 0;
	hostent* host = 0;

	if (gethostname(name, len) < 0 || len <= 0)
	{
		return 0;
	}

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);
}

int32 NetConnection::GetIP(char* name)
{
	hostent* host = 0;

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);

}

void NetConnection::SaveInfo(char* address, int32 port, char* waddress) {
	ZoneAddress = new char[strlen(address)+1];
	strcpy(ZoneAddress, address);
	ZonePort = port;
	WorldAddress = new char[strlen(waddress)+1];
	strcpy(WorldAddress, waddress);
}

NetConnection::~NetConnection() {
	if (ZoneAddress != 0)
		delete ZoneAddress;
	if (WorldAddress != 0)
		delete WorldAddress;
}

void NetConnection::Close() {
	#ifdef WIN32
		closesocket(listening_socket);
	#else
		close(listening_socket);
	#endif
}

void LoadSPDat() {
	FILE *fp;
	for (int j = 0; j < SPDAT_RECORDS; j++)
		memset((char*) &spells[j], 0, sizeof(SPDat_Spell_Struct));

	if (fp = fopen(SPDat_Location, "rb"))
	{
//		if (_filelength(fp) != SPDAT_SIZE) {
//			cout << "SPDat wrong size ('" << SPDat_Location << "'), spells not loaded." << endl;
//		}
//		else
		{
			for (int i = 0; i < SPDAT_RECORDS; i++) {
				fread(&spells[i], sizeof(SPDat_Spell_Struct), 1, fp);
			}
			spells_loaded = true;
			cout << "Spells loaded from '" << SPDat_Location << "'." << endl;
		}
		fclose(fp);
	}
	else
		cout << "SPDat not found ('" << SPDat_Location << "'), spells not loaded." << endl;
}

void NetConnection::StartProcessLoop() {
#ifdef WIN32
	_beginthread(ProcessLoop, 0, NULL);
#else
	pthread_t thread;
	pthread_create(&thread, NULL, ProcessLoop, NULL);
#endif
}



// this should always be called in a new thread
#ifdef WIN32
void ProcessLoop(void *tmp) {
#else
void *ProcessLoop(void *tmp) {
#endif
	srand(time(NULL));
	bool worldwasconnected = worldserver.Connected();
	ProcessLoopRunning = true;
	while(RunLoops) {
		if (worldserver.Connected()) {
			worldserver.Process();
			worldwasconnected = true;
		}
		else {
			if (worldwasconnected && ZoneLoaded)
				entity_list.ChannelMessageFromWorld(0, 0, 6, 0, 0, "WARNING: World server connection lost");
			worldwasconnected = false;
		}
		if (ZoneLoaded) {
#ifndef DEBUG
			try
#endif
			{
				entity_list.Process();
				if (!zone->Process()) {
					Zone::Shutdown();
				}
			}
#ifndef DEBUG
			catch (...)
			{	
				try
				{
					cout << "Fatal Error! Sending zone to sleep" << endl;
					zone->ErrorHandler();
					Zone::Shutdown();
				}
				catch(...)
				{
					ProcessLoopRunning = false;
#ifdef WIN32
					return;
#else
					return 0;					
#endif
				}
			}
#endif
		}
		Sleep(1);
	}
	ProcessLoopRunning = false;
#ifndef WIN32
	return 0;
#endif
}
