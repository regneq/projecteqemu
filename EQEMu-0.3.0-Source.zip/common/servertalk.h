#ifndef EQ_SOPCODES_H
#define EQ_SOPCODES_H

#define EQEMU_VERSION	"0.2.4"

#include "../common/types.h"

#define SERVER_TIMEOUT	60000	// how often keepalive gets sent
#define INTERSERVER_TIMER					90000
#define LoginServer_StatusUpdateInterval	15000
#define LoginServer_AuthStale				60000
#define AUTHCHANGE_TIMEOUT					900	// in seconds

#define ServerOP_KeepAlive			0x0001	// packet to test if port is still open
#define ServerOP_ChannelMessage		0x0002	// broadcast/guildsay
#define ServerOP_SetZone			0x0003	// client -> server zoneinfo
#define ServerOP_ShutdownAll		0x0004	// exit(0);
#define ServerOP_ZoneShutdown		0x0005	// unload all data, goto sleep mode
#define ServerOP_ZoneBootup			0x0006	// come out of sleep mode and load zone specified
#define ServerOP_ZoneStatus			0x0007	// Shows status of all zones
#define ServerOP_SetConnectInfo		0x0008	// Tells server address and port #
#define ServerOP_EmoteMessage		0x0009	// Worldfarts
#define ServerOP_ClientList			0x000A	// Update worldserver's client list, for #whos
#define ServerOP_Who				0x000B	// #who
#define ServerOP_ZonePlayer			0x000C  // #zone, or #summon
#define ServerOP_KickPlayer			0x000D  // #kick
#define ServerOP_RefreshGuild		0x000E	// Notice to all zoneservers to refresh their guild cache for ID# in packet
#define ServerOP_GuildKickAll		0x000F	// Remove all clients from this guild
#define ServerOP_GuildInvite		0x0010
#define ServerOP_GuildRemove		0x0011
#define ServerOP_GuildPromote		0x0012
#define ServerOP_GuildDemote		0x0013
#define ServerOP_GuildLeader		0x0014
#define ServerOP_GuildGMSet			0x0015
#define ServerOP_GuildGMSetRank		0x0016
#define ServerOP_FlagUpdate			0x0018	// GM Flag updated for character, refresh the memory cache
#define ServerOP_GMGoto				0x0019
#define ServerOP_MultiLineMsg		0x001A
#define ServerOP_Lock				0x001B  // For #lock/#unlock inside server
#define ServerOP_Motd				0x001C  // For changing MoTD inside server.
#define ServerOP_Uptime				0x001D
#define ServerOP_Petition			0x001E
#define	ServerOP_KillPlayer			0x001F
#define ServerOP_UpdateGM			0x0020

#define ServerOP_LSInfo				0x1000
#define ServerOP_LSStatus			0x1001
#define ServerOP_LSClientAuth		0x1002
#define ServerOP_LSFatalError		0x1003
#define ServerOP_SystemwideMessage	0x1005
#define ServerOP_ListWorlds			0x1006
#define ServerOP_PeerNewServer1		0x1100 // For New Server From a Peer Server
#define	ServerOP_PeerNewServer2		0x1101 // For New Server From a Peer Server
#define ServerOP_UpdateServer		0x1102 // Used for Number Changes, Locked Changes & Up/Down Changes
#define ServerOP_RemoveServer		0x1103 // Used to delete the server from the list.
#define ServerOP_DeleteServers		0x1104 // Cleans all Peers off Server List

/************ PACKET RELATED STRUCT ************/
class ServerPacket
{
public:
	~ServerPacket() { safe_delete(pBuffer); }
    ServerPacket(int16 in_opcode = 0, int32 in_size = 0) {
		size = in_size;
		opcode = in_opcode;
		if (size == 0) {
			pBuffer = 0;
		}
		else {
			pBuffer = new uchar[size];
			memset(pBuffer, 0, size);
		}
	}
	int16  size;
	int16  opcode;
	uchar* pBuffer;
};

#pragma pack(1)

struct SPackSendQueue {
	int16 size;
	uchar buffer[0];
};

struct ServerZoneStateChange_struct {
	int32 ZoneServerID;
	char adminname[30];
	char zonename[15];
};

struct ServerChannelMessage_Struct {
	char  deliverto[32];
	char  to[32];
	char  from[32];
	int8 fromadmin;
	bool  noreply;
	int16 chan_num;
	int32 guilddbid;
	int16  language;
	char  message[0];
};

struct ServerEmoteMessage_Struct {
	char to[32];
	int32 guilddbid;
	int32 type;
	char message[0];
};

struct ServerClientList_Struct {
	bool	remove;
	char	zone[30];
	int8	Admin;
	char	name[30];
	int32	AccountID;
	char	AccountName[30];
	int8	race;
	int8	class_;
	int8	level;
	int8	anon;
	bool	tellsoff;
	int32	guilddbid;
	int32	guildeqid;
	bool	LFG;
};

struct ServerZonePlayer_Struct {
	char	adminname[30];
	int8	adminrank;
	bool	ignorerestrictions;
	char	name[30];
	char	zone[15];
    float	x_pos;
    float	y_pos;
    float	z_pos;
};

struct ServerKickPlayer_Struct {
	char adminname[30];
	int8 adminrank;
	char name[30];
	int32 AccountID;
};

struct ServerGuildCommand_Struct {
	int32 guilddbid;
	int32 guildeqid;
	char from[30];
	int8 fromrank;
	int32 fromaccountid;
	char target[30];
	int8 newrank;
	int8 admin;
};

struct ServerLSInfo_Struct {
	char	name[201];		// name the worldserver wants
	char	address[250];	// DNS address of the server
	char	account[31];	// account name for the worldserver
	char	password[31];	// password for the name
	char	version[25];	// server's version #
	int8	servertype;		// 0=world, 1=chat
};

struct ServerLSStatus_Struct {
	sint32 status;
};

struct ServerLSClientAuth {
	int32	lsaccount_id;	// ID# in login server's db
	char	name[30];		// username in login server's db
	char	key[30];		// the Key the client will present
	int8	lsadmin;		// login server admin level
};

struct ServerSystemwideMessage {
	int32	lsaccount_id;
	char	key[30];		// sessionID key for verification
	int32	type;
	char	message[0];
};

struct ServerConnectInfo {
	char	address[250];
	int16	port;
};

struct ServerGMGoto_Struct {
	char	myname[32];
	char	gotoname[32];
	int8	admin;
};

struct ServerMultiLineMsg_Struct {
	char	to[30];
	char	message[0];
};

struct ServerLock_Struct {
	char	myname[32]; // User that did it
	int8	mode; // 0 = Unlocked ; 1 = Locked
};

struct ServerMotd_Struct {
	char	myname[32]; // User that set the motd
	char	motd[512]; // the new MoTD
};

struct ServerUptime_Struct {
	int32	zoneserverid;	// 0 for world
	char	adminname[32];
};

struct ServerPetitionUpdate_Struct {
	int32 petid;  // Petition Number
	int8  status; // 0x00 = ReRead DB -- 0x01 = Checkout -- More?  Dunno... lol
};

struct ServerWhoAll_Struct {
	int8 admin;
	char from[32];
	char whom[32];
	int16 wrace; // FF FF = no race
	int16 wclass; // FF FF = no class
	int16 firstlvl; // FF FF = no numbers
	int16 secondlvl; // FF FF = no numbers
	int16 gmlookup; // FF FF = not doing /who all gm
};

struct ServerKillPlayer_Struct {
	char gmname[30];
	char target[30];
	int8 admin;
};

struct ServerUpdateGM_Struct {
	char gmname[30];
	bool gmstatus;
};

struct NewServer_Struct {
	int32 account_id;
	int32 admin_id;
	char accountname[30];
	char worldname[30];
	char worldaddress[30];
	int8 status;
	bool down;
	bool greenname;
	bool locked;
};

struct UpdateServer_Struct {
	char worldname[30];
	bool greenname;
	bool locked;
	bool down;
	int8 shownum;
};

struct RemoveServer_Struct {
	char worldname[30];
};
#pragma pack()

#endif
