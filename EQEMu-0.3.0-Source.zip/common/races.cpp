#include "../common/debug.h"
#include "../common/eq_packet_structs.h"
#include "../common/races.h"

char* GetRaceName(int8 race) {
	switch(race) {
		case HUMAN:
			return "Human";
		case BARBARIAN:
			return "Barbarian";
		case ERUDITE:
			return "Erudite";
		case WOOD_ELF:
			return "Wood Elf";
		case HIGH_ELF:
			return "High Elf";
		case DARK_ELF:
			return "Dark Elf";
		case HALF_ELF:
			return "Half Elf";
		case DWARF:
			return "Dwarf";
		case TROLL:
			return "Troll";
		case OGRE:
			return "Ogre";
		case HALFLING:
			return "Halfling";
		case GNOME:
			return "Gnome";
		case IKSAR:
			return "Iksar";
		case WEREWOLF:
			return "Werewolf";
		case SKELETON:
			return "Skeleton";
		case ELEMENTAL:
			return "Elemental";
		case EYE_OF_ZOMM:
			return "Eye of Zomm";
		case WOLF_ELEMENTAL:
			return "Wolf Elemental";
		case IKSAR_SKELETON:
			return "Iksar Skeleton";
		case VAHSHIR:
			return "Vah Shir";
		default:
			return "Unknown";
	}
}
