#include "../common/debug.h"
#include <string.h>
#include "EQFragment.h"

Fragment::Fragment()
{
	data = 0;
	size = 0;
}

Fragment::~Fragment()
{
	safe_delete(data);
}

void Fragment::SetData(uchar* d, int32 s)
{
	safe_delete(data);
	data = new uchar[s];
	memcpy(data, d, s);
	size = s; 
}

FragmentGroup::FragmentGroup(int16 seq, int16 opcode, int16 num_fragments)
{
	this->seq = seq;
	this->opcode = opcode;
	this->num_fragments = num_fragments;
	fragment = new Fragment[num_fragments];
}

FragmentGroup::~FragmentGroup()
{
	delete[] fragment;
}

void FragmentGroup::Add(int16 frag_id, uchar* data, int32 size)
{
	fragment[frag_id].SetData(data, size);
}

uchar* FragmentGroup::AssembleData(int32* size)
{
	uchar* buf;
	uchar* p;
	int i;

	*size = 0;	
	for(i=0; i<num_fragments; i++)
	{
		*size+=fragment[i].GetSize();		
	}
	buf = new uchar[*size];
	p = buf;
	for(i=0; i<num_fragments; i++)
	{
		memcpy(p, fragment[i].GetData(), fragment[i].GetSize());
		p += fragment[i].GetSize();
	}

	return buf;
}

void FragmentGroupList::Add(FragmentGroup* add_group)
{
	fragment_group_list.Insert(add_group);
}

FragmentGroup* FragmentGroupList::Get(int16 find_seq)
{
	LinkedListIterator<FragmentGroup*> iterator(fragment_group_list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetSeq() == find_seq)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

void FragmentGroupList::Remove(int16 remove_seq)
{
    LinkedListIterator<FragmentGroup*> iterator(fragment_group_list);

    iterator.Reset();
    while(iterator.MoreElements())
    {
        if (iterator.GetData()->GetSeq() == remove_seq)
        {
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}
}
