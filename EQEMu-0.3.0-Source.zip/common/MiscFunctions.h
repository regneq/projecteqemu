#ifndef MISCFUNCTIONS_H
#define MISCFUNCTIONS_H

#include "types.h"
#include <stdio.h>

int MakeAnyLenString(char** ret, const char* format, ...);
int32 AppendAnyLenString(char** ret, int32* bufsize, int32* strlen, const char* format, ...);
int32 hextoi(char* num);
sint32 filesize(FILE* fp);

#endif

