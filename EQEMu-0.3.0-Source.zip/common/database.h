#ifndef DATABASE_H
#define DATABASE_H

#define AUTHENTICATION_TIMEOUT	60

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#endif
#include <mysql.h>

#include "types.h"
#include "linked_list.h"
#include "eq_packet_structs.h"
#include "EQPacketManager.h"
#include "../common/guilds.h"
#include "../common/MiscFunctions.h"
#include "../common/Mutex.h"
#include "../zone/loottable.h"
#include "../zone/faction.h"

//class Spawn;
class Spawn2;
class SpawnGroupList;
class Petition;

struct Combine_Struct;
//struct Faction;
//struct FactionMods;
//struct FactionValue;
struct ZonePoint;
struct NPCType;

// Added By Hogie 
// INSERT into variables (varname,value) values('decaytime [minlevel] [maxlevel]','[number of seconds]');
// IE: decaytime 1 54 = Levels 1 through 54
//     decaytime 55 100 = Levels 55 through 100
// It will always put the LAST time for the level (I think) from the Database
struct npcDecayTimes_Struct {
	int16 minlvl;
	int16 maxlvl;
	int32 seconds;
};
// Added By Hogie -- End

class Database
{
public:
	Database();
	Database(const char* host, const char* user, const char* passwd, const char* database);
	~Database();

	bool	MoveCharacterToZone(char* charname, char* zonename);
	bool	SetGMSpeed(int32 account_id, int8 gmspeed);
	int8	GetGMSpeed(int32 account_id);
	void	DeletePetitionFromDB(Petition* wpet);
	void	UpdatePetitionToDB(Petition* wpet);
	void	InsertPetitionToDB(Petition* wpet);
	void	RefreshPetitionsFromDB();
	bool	GetDecayTimes(npcDecayTimes_Struct* npcCorpseDecayTimes);
	bool	PopulateZoneLists(char* zone_name, LinkedList<ZonePoint*>* zone_point_list, SpawnGroupList* spawn_group_list);
	bool	PopulateZoneSpawnList(char* zone_name, LinkedList<Spawn2*> &spawn2_list, int32 repopdelay = 0);
	Spawn2*	LoadSpawn2(LinkedList<Spawn2*> &spawn2_list, int32 spawn2id, int32 timeleft);
	bool	DumpZoneState();
	sint8	LoadZoneState(char* zonename, LinkedList<Spawn2*>& spawn2_list);
	int32	CreatePlayerCorpse(int32 charid, char* charname, char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading);
	int32	UpdatePlayerCorpse(int32 dbid, int32 charid, char* charname, char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading);
	bool	DeletePlayerCorpse(int32 dbid);
	bool	LoadPlayerCorpses(char* zonename);
	bool	GetZoneLongName(char* short_name, char** long_name, char* file_name = 0, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0);
	int32	GetAuthentication(char* char_name, char* zone_name, int32 ip);
	bool	SetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool	GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool	ClearAuthentication(int32 account_id);
	int8	GetServerType();

	int32	CheckLogin(char* name, char* password);
	int8	CheckStatus(int32 account_id);
	bool	CreateAccount(char* name, char* password, int8 status, int32 lsaccount_id = 0);
	bool	DeleteAccount(char* name);
	bool	SetGMFlag(char* name, int8 status);
	bool	SetSpecialAttkFlag(int8 id, char* flag);
	bool	CheckZoneserverAuth(char* ipaddr);
	bool	UpdateName(char* oldname, char* newname);

	void	GetCharSelectInfo(int32 account_id, CharacterSelect_Struct*);
	unsigned long	GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);
	bool	SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp);
	bool	CreateSpawn2(int32 spawngroup, char* zone, float heading, float x, float y, float z, int32 respawn, int32 variance);
	bool	CheckNameFilter(char* name);
	bool	AddToNameFilter(char* name);
	bool	CheckUsedName(char* name);
	bool	ReserveName(int32 account_id, char* name);
	bool	CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis, int8 face);
	bool	CreateCharacter(int32 account_id, PlayerProfile_Struct* pp);
	bool	DeleteCharacter(char* name);
	bool    SetStartingItems(PlayerProfile_Struct *cc, int8 si_race, int8 si_class, char* si_name);

	int32	GetAccountIDByChar(char* charname);
	int32	GetAccountIDByName(char* accname);
	void	GetAccountName(int32 accountid, char* name);
	void	GetCharacterInfo(char* name, int32* charid, int32* guilddbid, int8* guildrank);

	bool	OpenQuery(char* zonename);
	bool	GetVariable(char* varname, char* varvalue, int16 varvalue_len);
	bool	SetVariable(char* varname, char* varvalue);
	bool	LoadGuilds(GuildRanks_Struct* guilds);
	bool	GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr);
	int32	GetGuildEQID(int32 guilddbid);
	bool	SetGuild(int32 charid, int32 guilddbid, int8 guildrank);
	int32	GetFreeGuildEQID();
	int32	CreateGuild(char* name, int32 leader);
	bool	DeleteGuild(int32 guilddbid);
	bool	RenameGuild(int32 guilddbid, char* name);
	bool	EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl);
	int32	GetGuildDBIDbyLeader(int32 leader);
	bool	SetGuildLeader(int32 guilddbid, int32 leader);
	bool	SetGuildMOTD(int32 guilddbid, char* motd);
	bool	GetGuildMOTD(int32 guilddbid, char* motd);
	int32	GetMerchantData(int32 merchantid, int32 slot);
	int32	GetMerchantListNumb(int32 merchantid);
	bool	GetSafePoints(char* short_name, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0, int8* minstatus = 0, int8* minlevel = 0);
	bool	LoadItems();
	bool	LoadNPCTypes();
	Item_Struct*	GetItem(uint32 id);
	NPCType*		GetNPCType(uint32 id);

	bool	GetNPCFactionList(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetNPCPrimaryFaction(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetFactionData(FactionMods* fd, sint32 class_mod, sint32 race_mod, sint32 deity_mod, int32 faction_id); //rembrant, needed for factions Dec, 16 2001
	bool	GetFactionName(int32 faction_id, char* name); // rembrant, needed for factions Dec, 16 2001
	bool	SetCharacterFactionLevel(int32 char_id, int32 faction_id, sint32 value,LinkedList<FactionValue*>* val_list); // rembrant, needed for factions Dec, 16 2001
	bool	LoadFactionData();
	bool	LoadFactionValues(LinkedList<FactionValue*>* val_list, int32 char_id);

	int32	GetAccountIDFromLSID(int32 lsaccount_id);

	bool	SetLSAuthChange(int32 account_id, char* ip);
	bool	UpdateLSAccountAuth(int32 account_id, int8* auth);
	int32	GetLSAuthentication(int8* auth);
	int32	GetLSAuthChange(char* ip);
	bool	ClearLSAuthChange();
	bool	RemoveLSAuthChange(int32 account_id);
	bool	GetLSAccountInfo(int32 account_id, char* name, int8* lsadmin, int* status);
	sint8	CheckWorldAuth(char* account, char* password, int32* account_id, int32* admin_id, bool* GreenName, bool* ShowDown);
	bool	UpdateWorldName(int32 accountid, char* name);
	char*	GetBook(char txtfile[14]);
	void	LoadWorldList();

	void	ping();

	bool	GetTradeRecipe(Combine_Struct* combin,int16 tradeskill, int16* product, int16* skillneeded);
	bool	MakeDoorSpawnPacket(char* zone,APPLAYER* app);
	bool	CheckGuildDoor(int8 doorid,int16 guildid,char* zone);
	bool	SetGuildDoor(int8 doorid,int16 guildid,char* zone);
	bool	MakeZonepointPacket(char* zone,APPLAYER* app);

	uint32			max_item;
	Item_Struct**	item_array;
	uint32			max_npc_type;
	NPCType**		npc_type_array;
	uint32			max_faction;
	Faction**		faction_array;

	void AddLootTableToNPC(int32 loottable_id, ItemList* itemlist, int32* copper, int32* silver, int32* gold, int32* plat);
	bool UpdateZoneSafeCoords(char* zonename, float x, float y, float z);
	int8 GetUseCFGSafeCoords();
	int8 CopyCharacter(char* oldname, char* newname, int8 acctid);
protected:
	void	AddLootDropToNPC(int32 lootdrop_id, ItemList* itemlist);
	bool	RunQuery(char* query, int32 querylen, char* errbuf = 0, MYSQL_RES** result = 0, int32* affected_rows = 0, bool retry = true);
	int32	DoEscapeString(char* tobuf, char* frombuf, int32 fromlen);
private:
	MYSQL	mysql;
	Mutex	MDatabase;
};
#endif

