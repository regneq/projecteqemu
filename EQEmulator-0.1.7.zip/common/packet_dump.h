#include <iostream.h>

#include "EQPacketManager.h"

void DumpPacketAscii(uchar* buf, int32 size, int32 cols=16, int32 skip=0);
void DumpPacketHex(uchar* buf, int32 size, int32 cols=16, int32 skip=0);
void DumpPacketHex(APPLAYER* app);
void DumpPacketAscii(APPLAYER* app);
void DumpPacket(uchar* buf, int32 size);
void DumpPacket(APPLAYER* app);
