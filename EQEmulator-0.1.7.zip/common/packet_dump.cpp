#include <iostream.h>
#include <iomanip.h>
#include <stdio.h>

#include "packet_dump.h"

#ifdef WIN32
void DumpPacketAscii(uchar* buf, int32 size, int32 cols, int32 skip)
#else
void DumpPacketAscii(uchar* buf, int32 size, int32 cols=16, int32 skip=0)
#endif
{
	// Output as ASCII
	for(int i=skip; i<size; i++)
	{
		if ((i-skip)%cols==0)
		{
			cout << endl << setw(3) << i-skip << ":";
		}
		else if ((i-skip)%(cols/2)==0)
		{
			cout << " - ";
		}
		if (buf[i] > 32 && buf[i] < 127)
		{
			cout << buf[i];
		}
		else
		{
			cout << '.';
		}
	}
	cout << endl << endl;
}

#ifdef WIN32
void DumpPacketHex(uchar* buf, int32 size, int32 cols, int32 skip)
#else
void DumpPacketHex(uchar* buf, int32 size, int32 cols=16, int32 skip=0)
#endif
{
	// Output as HEX
	char output[4];
    for(int i=skip; i<size; i++)
    {
		if ((i-skip)%cols==0)
		{
			cout << endl << setw(3) << i-skip << ": ";
		}
		else if ((i-skip)%(cols/2) == 0)
		{
			cout << "- ";
		}
		sprintf(output, "%02X ",(unsigned char)buf[i]);
		cout << output;
//		cout << setfill(0) << setw(2) << hex << (int)buf[i] << " ";
    }	
	cout << endl << endl;
}

void DumpPacketHex(APPLAYER* app)
{
	DumpPacketHex(app->pBuffer, app->size);
}

void DumpPacketAscii(APPLAYER* app)
{
	DumpPacketAscii(app->pBuffer, app->size);
}

void DumpPacket(uchar* buf, int32 size)
{
	DumpPacketHex(buf, size);
	DumpPacketAscii(buf,size);
}

void DumpPacket(APPLAYER* app)
{
	DumpPacketHex(app->pBuffer, app->size);
	DumpPacketAscii(app->pBuffer, app->size);
}
