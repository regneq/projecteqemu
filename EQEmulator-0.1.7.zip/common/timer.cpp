// Disgrace: for windows compile
#ifndef WIN32
	#include <sys/time.h>
#else
	#include <sys/timeb.h>
#endif

#include <iostream.h>

#include "timer.h"

int32 Timer::current_time = 0;
int32 Timer::last_time = 0;

Timer::Timer(int32 in_timer_time)
{
	timer_time = in_timer_time;
	start_time = current_time;
	set_at_trigger = timer_time;
	if (timer_time == 0)
	{
		enabled = false;
	}
	else
	{
		enabled = true;
	}
}

/* Reimplemented for MSVC - Bounce */
#ifdef WIN32
int gettimeofday (timeval *tp, ...)
{
	timeb tb;

	ftime (&tb);

	tp->tv_sec  = tb.time;
	tp->tv_usec = tb.millitm * 10;

	return 0;
}
#endif

/* This function checks if the timer triggered */
bool Timer::Check()
{
    if (enabled && current_time-start_time > timer_time)
    {
		start_time = current_time; // Reset timer
		timer_time = set_at_trigger;
		return true;
    }
	
    return false;
}

/* This function disables the timer */
void Timer::Disable()
{
	enabled = false;
}

/* This function set the timer and restart it */
// Disgrace: for windows compile
#ifndef WIN32
void Timer::Start(int32 set_timer_time=0)
#else
void Timer::Start(int32 set_timer_time)
#endif
{	
    start_time = current_time;
	enabled = true;
    if (set_timer_time != 0)
    {	
		timer_time = set_timer_time;	
set_at_trigger = set_timer_time;
    }
}

/* This timer updates the timer without restarting it */
// Disgrace: for windows compile
#ifndef WIN32
void Timer::SetTimer(int32 set_timer_time=0)
#else
void Timer::SetTimer(int32 set_timer_time)
#endif
{
    /* If we were disabled before => restart the timer */
    if (!enabled)
    {
		start_time = current_time;
		enabled = true;
    }
    if (set_timer_time != 0)
    {
		timer_time = set_timer_time;
set_at_trigger = set_timer_time;
    }
}

void Timer::SetAtTrigger(int32 in_set_at_trigger)
{
	set_at_trigger = in_set_at_trigger;
}

void Timer::Trigger()
{
	enabled = true;

	timer_time = set_at_trigger;
	start_time = current_time-timer_time-1;
}

int32 Timer::GetCurrentTime()
{	
    return current_time;
}

void Timer::SetCurrentTime()
{
    struct timeval read_time;	
    int32 this_time;

    gettimeofday(&read_time,0);
    this_time = read_time.tv_sec * 1000 + read_time.tv_usec / 1000;

    if (last_time == 0)
    {
		current_time = 0;
    }
    else
    {
		current_time += this_time - last_time;
    }
    
	last_time = this_time;

//	cerr << "Current time:" << current_time << endl;
}
