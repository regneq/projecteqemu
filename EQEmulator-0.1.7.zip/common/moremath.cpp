
// Quagmire - i was really surprised, but i couldnt find the equivilent standard library function
signed char sign(signed int tmp) {
	if (tmp > 0)
		return 1;
	else if (tmp < 0)
		return -1;
	else
		return 0;
}
