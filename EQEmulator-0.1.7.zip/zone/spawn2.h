#ifndef SPAWN2_H
#define SPAWN2_H

#include "../common/timer.h"
class Spawn2
{
public:
	Spawn2(int spawngroup_id, int x, int y, int z, int respawn, int variance);
	~Spawn2();

	void Enable();
	void Process();
	void Reset();

private:
	int resetTimer();

	int spawngroup_id_;
	int x_;
	int y_;
	int z_;
	int respawn_;
	int variance_;
	Timer* timer;
};

#endif
