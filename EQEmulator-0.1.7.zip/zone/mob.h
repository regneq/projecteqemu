#ifndef MOB_H
#define MOB_H

#include "../common/EQPacketManager.h"
#include "entity.h"

struct Buffs_Struct {
	int16 spellid;
	int32 ticselapsed;
};

class Mob : public Entity
{
public:
	Mob(char*   in_name,
	    char*   in_lastname,
	    sint32  in_cur_hp,
	    sint32  in_max_hp,
	    int8    in_gender,
	    int8    in_race,
	    int8    in_class,
	    int8    in_deity,
	    int8    in_level,
		int32   in_npc_id, // rembrant, Dec. 20, 2001
		int8*	in_skills, // socket 12-29-01
	    int8    in_heading,
	    sint16  in_x_pos,
	    sint16  in_y_pos,
	    sint16  in_z_pos,

	    int8    in_light,
	    int8*   in_equipment);
	
	virtual ~Mob();

	virtual bool IsMob() { return true; }

	virtual void SetLevel(uint8 in_level) { level = in_level; }

	virtual void SetSkill(int in_skill_num, int8 in_skill_id) { // socket 12-29-01
		skills[in_skill_num] = in_skill_id; }
	int8 GetSkill(int skill_num) { return skills[skill_num]; } // socket 12-29-01
	int8 GetEquipment(int item_num) { return equipment[item_num]; } // socket 12-30-01

	virtual void Attack(Mob* other) {}
	virtual void Damage(Mob* from, sint32 damage, int16 spell_id, int8 attack_skill = 0x04)  {}
	virtual void Heal(Mob* from, sint32 damage, int16 spell_id)  {}
	virtual void Death(Mob* killer, sint32 damage, int16 spell_id, int8 attack_skill = 0x04) {}
	virtual void SetHP(sint32 hp);
	void ChangeHP(Mob* other, sint32 amount, int16 spell_id = 0);

	void SendPosUpdate();
	void CreateDespawnPacket(APPLAYER* app);
    void CreateSpawnPacket(APPLAYER* app, Mob* ForWho = 0);
	void CreateHPPacket(APPLAYER* app);

	int8 GetLevel()   { return level; }
	char* GetName()   { return name; }
	int8 GetHPRatio() { return (int8)((float)cur_hp/max_hp*100); }
	virtual sint32 GetHP() { return cur_hp; }
	virtual sint32 GetMaxHP()  { return max_hp; }
	Mob* GetTarget()  { return target; }
	void SetTarget(Mob* mob) { target = mob; }

	int32 GetNpcId() { return npc_id; } // rembrant, Dec. 20, 2001

	float Dist(Mob*);
	float DistNoZ(Mob* other);
	float DistNoRoot(Mob*);
	float DistNoRootNoZ(Mob*); 

	sint16 GetX() { return x_pos; }
	sint16 GetY() { return y_pos; }
	sint16 GetZ() { return z_pos; }

	virtual void Message(int32 type, char* message, ...) {} // fake so dont have to worry about typing
	void SpellOnTarget(int16 spell_id, Entity* spelltar);
	void SpellEffect(Mob* caster, int16 spell_id, int8 caster_level);
	bool invulnerable;
	int16 BeingLootedBy;
protected:
	char    name[30];
	char    lastname[20];

	sint32  cur_hp;
	sint32  max_hp;
	Buffs_Struct buffs[16];

	int8    gender;
	int8    race;
	int8    class_;
	int8    deity;
	int8    level;
	int32   npc_id; // rembrant, Dec. 20, 2001
	int8    skills[74]; // socket 12-29-01
	sint8   heading;
	sint8   delta_heading;
	sint16  x_pos;
	sint16  y_pos;
	sint16	z_pos;
//	sint8   delta_x;
//	sint8   delta_y;
//	sint8   delta_z;
    sint32 delta_y:10,
           spacer1:1,
           delta_z:10,
           spacer2:1,
           delta_x:10;
	int32	guildeqid; // guild's EQ ID, 0-511, 0xFFFFFFFF = none


	int8    light;
	int8    equipment[9];

	int8    appearance; // 0 standing, 1 sitting, 2 ducking

	bool	corpse;

	Mob*    target;
	Timer*  attack_timer;
	Timer*  regen_timer;
	Timer*  position_timer;
};

#endif

