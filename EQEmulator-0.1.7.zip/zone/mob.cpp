#include <math.h>

#include "mob.h"

#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"

#include <stdio.h>
extern EntityList entity_list;

void DumpPacketHex(APPLAYER*);

void EncryptSpawnPacket(APPLAYER* app);
void SetEQChecksum(uchar* in_data, int32 in_length);

Mob::Mob(char*   in_name, 
         char*   in_lastname, 
         sint32  in_cur_hp, 
         sint32  in_max_hp,
         int8    in_gender,
         int8    in_race,
         int8    in_class,
         int8    in_deity,
         int8    in_level,
         int32	 in_npc_id, // rembrant, Dec. 20, 2001
         int8*	 in_skills, // socket 12-29-01
         int8	 in_heading,
         sint16  in_x_pos,
         sint16  in_y_pos,
         sint16  in_z_pos,

         int8    in_light,
         int8*   in_equipment)
{
	strncpy(name, in_name, 30);
	strncpy(lastname, in_lastname, 20);
	cur_hp    = in_cur_hp;
	max_hp    = in_max_hp;
	gender    = in_gender;
    race      = in_race;
	class_    = in_class;
	deity     = in_deity;
	level     = in_level;
	npc_id    = in_npc_id; // rembrant, Dec. 20, 2001
	heading   = in_heading;
	x_pos     = in_x_pos;
	y_pos     = in_y_pos;
	z_pos     = in_z_pos;

	light     = in_light;
	for (int i=0; i<9; i++)
	{
		if (in_equipment == 0)
		{
			equipment[i] = 0;
		}
		else
		{
			equipment[i] = in_equipment[i];
		}
	}
	for (i=0; i<74; i++) { // socket 12-29-01
		if (in_skills == 0) {
			skills[i] =0;
		}
		else {
			skills[i] = in_skills[i];
		}
	}
	for (int j = 0; j < 16; j++) {
		buffs[j].spellid = 0;
		buffs[j].ticselapsed = 0;
	}

	delta_heading = 0;
	delta_x = 0;
	delta_y = 0;
	delta_z = 0;

	invulnerable = false;
	corpse = false;
	BeingLootedBy = 0;
	appearance = 0;
	guildeqid = 0xFFFFFFFF;

	attack_timer = new Timer(2000);
	regen_timer = new Timer(6000);
	position_timer = new Timer(5000);
}     

Mob::~Mob()
{
	APPLAYER app;
	CreateDespawnPacket(&app);
	entity_list.QueueClients(this, &app, true);
	entity_list.RemoveFromTargets(this);
}

void Mob::CreateSpawnPacket(APPLAYER* app, Mob* ForWho)
{
	app->opcode = OP_NewSpawn;
	app->pBuffer = new uchar[sizeof(NewSpawn_Struct)];
	app->size = sizeof(NewSpawn_Struct);

	memset(app->pBuffer, 0, sizeof(NewSpawn_Struct));
	NewSpawn_Struct* ns = (NewSpawn_Struct*)app->pBuffer;

	ns->spawn.heading = heading;
	ns->spawn.x_pos = x_pos;
	ns->spawn.y_pos = y_pos;
	ns->spawn.z_pos = z_pos;
	ns->spawn.spawn_id = id;
	ns->spawn.max_hp = 0x64;
	ns->spawn.race = race;
	if (IsClient()) {
		if (guildeqid == 0xFFFFFFFF)
			ns->spawn.GuildID = 0xFFFF;
		else
			ns->spawn.GuildID = guildeqid;
	}
	else
		ns->spawn.GuildID = 0xffff;

	if (IsClient())
	{
		if (ForWho == this)
			ns->spawn.NPC = 10;
		else
			ns->spawn.NPC = 0;
		ns->spawn.not_linkdead = 1;
		if (corpse)
			ns->spawn.NPC = 3;
	}
	else if (IsNPC())
	{
		ns->spawn.NPC = 1;
		if (corpse)
			ns->spawn.NPC = 2;
	}
	ns->spawn.class_ = class_;
	ns->spawn.gender = gender;
	ns->spawn.level = level;
	ns->spawn.anim_type = 0x64;
	ns->spawn.light = light;

//memset(ns->spawn.s_unknown5, 10, 9);
	ns->spawn.s_unknown5[3] = 0x10;//01;
	ns->spawn.s_unknown5[7] = 0xff;

	for(int i=0; i<9; i++)
		ns->spawn.equipment[i] = equipment[i];
	strcpy(ns->spawn.name, name);
//	ns->spawn.lastname[0] = 0;
	strcpy(ns->spawn.lastname, lastname);
	ns->spawn.deity = deity;
/*
ns->spawn.s_unknown7[2] = 0xff;
ns->spawn.s_unknown9[0] = 0xff;
ns->spawn.s_unknown9[1] = 0xff;
ns->spawn.s_unknown9[2] = 0xff;
ns->spawn.s_unknown9[3] = 0xff;
ns->spawn.s_unknown9[4] = 0xff;
ns->spawn.s_unknown9[5] = 0x05;
ns->spawn.s_unknown9[6] = 0x2b;
ns->spawn.s_unknown9[7] = 0x03;
*/


// Testing uknowns
//	for (int i=0;i<49;i++)
//		ns->spawn.s_unknown1[i] = 0xff;
/*
	ns->spawn.s_unknown2[0] = 0xff;
	ns->spawn.s_unknown3[0] = 0xff;
	ns->spawn.s_unknown3[1] = 0xff;

	ns->spawn.s_unknown4[0] = 0xff;
	ns->spawn.s_unknown4[1] = 0xff;

	for (int i=0;i<49;i++)
		ns->spawn.s_unknown5[i] = 0xff;
	ns->spawn.s_unknown6[0] = 0xff;
	ns->spawn.s_unknown6[1] = 0xff;
	ns->spawn.s_unknown7[0] = 0xff;
	ns->spawn.s_unknown7[1] = 0xff;
	ns->spawn.s_unknown7[2] = 0xff;
*/

//	SetEQChecksum((unsigned char*)app->pBuffer, app->size); no, doesnt seem to need a checksum
//	DumpPacketHex(app);
	EncryptSpawnPacket(app);
}

void Mob::CreateDespawnPacket(APPLAYER* app)
{
	app->opcode = OP_DeleteSpawn;
	app->size = sizeof(DeleteSpawn_Struct);
	app->pBuffer = new uchar[app->size];
	memset(app->pBuffer, 0, app->size);
	DeleteSpawn_Struct* ds = (DeleteSpawn_Struct*)app->pBuffer;
	ds->spawn_id = id;
}

void Mob::CreateHPPacket(APPLAYER* app)
{
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	memset(app->pBuffer, 0, sizeof(SpawnHPUpdate_Struct));
	SpawnHPUpdate_Struct* ds = (SpawnHPUpdate_Struct*)app->pBuffer;
	ds->spawn_id = id;
	if (IsNPC())
	{
		ds->cur_hp = GetHPRatio();
		ds->max_hp = 100;
	}
	else
	{
		ds->cur_hp = cur_hp;
		ds->max_hp = max_hp;
	}
}

void Mob::SendPosUpdate()
{
	APPLAYER* app = new APPLAYER;

	app->opcode = OP_MobUpdate;
	app->size = sizeof(SpawnPositionUpdates_Struct) + sizeof(SpawnPositionUpdate_Struct);

	#ifdef BUILD_FOR_WINDOWS
		app->pBuffer = new uchar[app->size];
		SpawnPositionUpdates_Struct* spu = (SpawnPositionUpdates_Struct*)app->pBuffer;	
	#else
		SpawnPositionUpdates_Struct* spu = (SpawnPositionUpdates_Struct*)app->pBuffer = new uchar[app->size];
	#endif

	spu->num_updates = 1;
	spu->spawn_update[0].spawn_id = id;


	spu->spawn_update[0].anim_type = appearance;


	spu->spawn_update[0].heading = heading;
	spu->spawn_update[0].delta_heading = delta_heading;
	spu->spawn_update[0].x_pos = x_pos;
	spu->spawn_update[0].y_pos = y_pos;
	// Quagmire: -50 seems to help vertical hopping
	// i think it's because the client reports it's position @ it's head, and spawn packets are at the entity's feet, heh
	// When we find a size field, lets try -(size * 10)
	if (this->IsClient())
		spu->spawn_update[0].z_pos = z_pos - 50;
	else
		spu->spawn_update[0].z_pos = z_pos;
	spu->spawn_update[0].delta_y = delta_y/125;
	spu->spawn_update[0].delta_x = delta_x/125;
	spu->spawn_update[0].delta_z = delta_z;

	entity_list.QueueClients(this, app, true); // FIXME: Restrict updates to closest clients?
	delete app;
}

float Mob::Dist(Mob* other)
{
	return sqrt((double)(pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2) + pow(other->z_pos-z_pos, 2)));
//	return pow((other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos), 1/3);
}

float Mob::DistNoZ(Mob* other)
{
	return sqrt((double)pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2));
//	return pow((other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos), 1/3);
}

float Mob::DistNoRoot(Mob* other)
{
	return pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2) + pow(other->z_pos-z_pos, 2);
//	return (other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos);
}

float Mob::DistNoRootNoZ(Mob* other)
{
	return (other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos);
} 

void Mob::SetHP(sint32 hp) {
	if (hp >= max_hp)
		cur_hp = max_hp;
	else
		cur_hp = hp;
}
