#include "client.h"
#include "spdat.h"
#include "../common/packet_dump.h"
#include "../common/moremath.h"
#ifndef WIN32
	#include <pthread.h>
#endif

extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;

void Client::CastSpell(int16 spell_id, int16 target_id, int16 slot) {
	if (!spells_loaded)
		Message(0, "Spells not loaded.");
	else {
		/* Client begins to cast a spell */
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_BeginCast;
		outapp->size = sizeof(BeginCast_Struct);
		outapp->pBuffer = new uchar[outapp->size];

		BeginCast_Struct* begincast = (BeginCast_Struct*)outapp->pBuffer;
		begincast->caster_id = GetID();
		begincast->spell_id = spell_id;
		begincast->unknown2 = 0xFF; // spell effects on/off  0xFF = on, all others seem to be off
		begincast->unknown3 = 0xFFFF;
		entity_list.QueueCloseClients(this, outapp);
		delete outapp;

		casting_spell_id = spell_id;
		casting_spell_targetid = target_id;
		casting_spell_slot = slot;
		casting_spell_mana = spells[spell_id].mana;
		spellend_timer->Start(spells[spell_id].cast_time);
	}
}

void Client::InterruptSpell() {
#define InterruptedMessage "Your spell was interrupted."
	if (casting_spell_id != 0) {
cout << "Interrupting " << this->GetName() << "'s casting" << endl;
		spellend_timer->Disable();
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_InterruptCast;
		outapp->size = sizeof(InterruptCast_Struct) + strlen(InterruptedMessage) + 1;
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, outapp->size);
		InterruptCast_Struct* ic = (InterruptCast_Struct*) outapp->pBuffer;
		ic->spawnid = this->GetID();
		strcpy(ic->message, InterruptedMessage);
		QueuePacket(outapp);
		delete outapp;
		entity_list.MessageClose(this, false, 200, MT_Spells, "%s's casting has been interrupted!", this->GetName());

		outapp = new APPLAYER;
		outapp->opcode = OP_ManaChange;
		outapp->size = sizeof(ManaChange_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
		manachange->new_mana = pp.mana;
		manachange->spell_id = casting_spell_id;
		QueuePacket(outapp);
		delete outapp;
		casting_spell_id = 0;
	}
}

void Client::SpellFinished(int16 spell_id, int32 target_id, int16 slot, int16 mana_used) {
	if (spell_id == 0)
		return;
	casting_spell_id = 0;
	if (!spells_loaded)
		Message(0, "Spells not loaded.");
	else {
		APPLAYER* outapp = 0;
		/* Dunno why this goes here, but it does */
		// Quagmire - Think this is to grey the memorized spell icons?
		if (slot <= 7) {
			outapp = new APPLAYER;
			outapp->opcode = OP_MemorizeSpell;
			outapp->size = sizeof(MemorizeSpell_Struct);
			outapp->pBuffer = new uchar[outapp->size];
			MemorizeSpell_Struct* memspell = (MemorizeSpell_Struct*)outapp->pBuffer;
			memspell->slot = slot;
			memspell->spell_id = spell_id;
			memspell->scribing = 3;
			QueuePacket(outapp);
			delete outapp;
		}

		/* Client animation */
		outapp = new APPLAYER;
		outapp->opcode = OP_Attack;
		outapp->size = sizeof(Attack_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memset(outapp->pBuffer, 0, outapp->size);
		Attack_Struct* a = (Attack_Struct*)outapp->pBuffer;
		a->spawn_id = id;
        a->a_unknown1 = 0; // if this is not zero, the animation will not occur.
		a->type = 42;
		a->a_unknown2[5] = 0x80;      
		a->a_unknown2[6] = 0x3f;       
		entity_list.QueueCloseClients(this, outapp);
		delete outapp;  

		/* Tell client it can cast again */
		outapp = new APPLAYER;
		outapp->opcode = OP_ManaChange;
		outapp->size = sizeof(ManaChange_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
		pp.mana = pp.mana - mana_used;
		manachange->new_mana = pp.mana;
		manachange->spell_id = spell_id;
		QueuePacket(outapp);
		delete outapp;
		
		if (!spells_loaded) {
			Message(0, "Spells werent loaded on bootup.");
		}
		else {
			switch (spells[spell_id].targettype)
			{
				case ST_Target: {
					if (target_id == 0)
						Message(13, "Error: Spell requires a target");
					else
						SpellOnTarget(spell_id, entity_list.GetID(target_id));
					break;
				}
				case ST_Self: {
					SpellOnTarget(spell_id, this);
					break;
				}
				case ST_AECaster: {
					entity_list.AESpell(this, this, 25, spell_id);
//					Message(0, "I dont know how to do AE's centered around caster yet.");
					break;
				}
				case ST_AETarget: {
					Entity* tar = entity_list.GetID(target_id);
					if (tar->IsMob())
						entity_list.AESpell(this, tar->CastToMob(), 25, spell_id);
					else
						Message(13, "Invalid target for an AETarget spell");
//					Message(0, "I dont know how to do AE's centered around target yet.");
					break;
				}
				case ST_Group: {
					Message(0, "I dont know how to do group spells yet.");
					break;
				}
				default: {
					Message(0, "I dont know that TargetType. 0x%x", spells[spell_id].targettype);
					break;
				}
			}
		}
	}
}

void Mob::SpellOnTarget(int16 spell_id, Entity* spelltar) {
	if (spelltar == 0) {
		Message(13, "You must have a target for this spell.");
		return;
	}
	if (spells[spell_id].targettype == ST_AECaster && spelltar == this) return;
	if (spell_id == 982) { // Cazic Touch, hehe =P
		char tmp[32];
		strcpy(tmp, spelltar->GetName());
		entity_list.Message(0, MT_Shout, "%s shouts, '%s!'", this->GetName(), strupr(tmp));
	}

	APPLAYER* outapp = 0;

	/* Effect of the spell (currently every spell works like heal) */
	outapp = new APPLAYER;
	outapp->opcode = OP_Action;
	outapp->size = sizeof(Action_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	Action_Struct* action = (Action_Struct *)outapp->pBuffer;
	memset(outapp->pBuffer, 0, outapp->size);
	action->damage = 0;
	action->spell = spell_id;
	action->source = id;
	action->target = spelltar->GetID();
	action->type = 0xE7;
	entity_list.QueueCloseClients(spelltar->CastToMob(), outapp, false, 200, this); // send target and people near target
	if (this->IsClient())
		this->CastToClient()->QueuePacket(outapp); // send to caster of the spell
	delete outapp;

	/* Actual cast action */
	outapp = new APPLAYER;
	outapp->opcode = OP_CastOn;
	outapp->size = sizeof(CastOn_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	CastOn_Struct* caston = (CastOn_Struct *)outapp->pBuffer;
	memset(outapp->pBuffer, 0, outapp->size);
	caston->source_id = id;
	caston->target_id = spelltar->GetID();
	caston->action = 231;
	caston->spell_id = spell_id;
	caston->unknown1[0] = 0x34; caston->unknown1[1] = 0x00;
	caston->unknown3[0] = 0x0a; caston->unknown3[1] = 0x00;
	caston->unknown5[0] = 0x00; caston->unknown5[1] = 0x00;

	caston->unknown2[0] = 0x52; caston->unknown2[1] = 0x04;
	caston->unknown4[0] = 0xec; caston->unknown4[1] = 0x43;

//	if (spelltar->IsClient()) {
		entity_list.QueueCloseClients(spelltar->CastToMob(), outapp, false, 200, this); // send target and people near target
		if (this->IsClient())
			this->CastToClient()->QueuePacket(outapp); // send to caster of the spell
//	}
//DumpPacket(outapp);
	delete outapp;
	spelltar->CastToMob()->SpellEffect(this, spell_id, this->GetLevel());
}

// Quagmire - that case above getting to long and spells are gonna have a lot of cases of their own
void Mob::SpellEffect(Mob* caster, int16 spell_id, int8 caster_level) {
	if (!spells_loaded) {
		Message(0, "Spells werent loaded on bootup.");
		return;
	}
	for (int i = 0; i < 12; i++) {
		switch(spells[spell_id].effectid[i]) {
			case SE_CurrentHP: {
				caster->Message(0, "Effect #%i: You changed %s's hp by %+i", i, this->GetName(), CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level));
				this->ChangeHP(caster, CalcSpellValue(spells[spell_id].formula[i], spells[spell_id].base[i], spells[spell_id].max[i], caster_level), spell_id);
				break;
			}
			case SE_ArmorClass: {
				Message(0, "Effect #%i: You cast an AC buff/debuff.", i);
				break;
			}
			case SE_ATK: {
				Message(0, "Effect #%i: You cast an ATK buff/debuff.", i);
				break;
			}
			case SE_MovementSpeed: {
				Message(0, "Effect #%i: You cast an Movement Speed buff/debuff.", i);
				break;
			}
			case SE_STR: {
				Message(0, "Effect #%i: You cast a STR buff/debuff.", i);
				break;
			}
			case SE_DEX: {
				Message(0, "Effect #%i: You cast a DEX buff/debuff.", i);
				break;
			}
			case SE_AGI: {
				Message(0, "Effect #%i: You cast an AGI buff/debuff.", i);
				break;
			}
			case SE_STA: {
				Message(0, "Effect #%i: You cast a STA buff/debuff.", i);
				break;
			}
			case SE_INT: {
				Message(0, "Effect #%i: You cast an INT buff/debuff.", i);
				break;
			}
			case SE_WIS: {
				Message(0, "Effect #%i: You cast a WIS buff/debuff.", i);
				break;
			}
			case SE_CHA: {
				if (spells[spell_id].base[i] != 0)
					Message(0, "Effect #%i: You cast a CHA buff/debuff.", i);
				else {
					// this is used in a lot of spells as a spacer, dunno why
				}
				break;
			}
			case SE_AttackSpeed: {
				Message(0, "Effect #%i:You cast an Attack Speed buff/debuff.", i);
				break;
			}
			case SE_Invisibility: {
				Message(0, "Effect #%i: You cast an Invisibility spell.", i);
				break;
			}
			case SE_SeeInvis: {
				Message(0, "Effect #%i: You cast a See Invis buff.", i);
				break;
			}
			case SE_WaterBreathing: {
				Message(0, "Effect #%i: You cast a Water Breathing buff.", i);
				break;
			}
			case SE_CurrentMana: {
				Message(0, "Effect #%i: You cast an add/subtract mana spell.", i);
				break;
			}
			case SE_AddFaction: {
				Message(0, "Effect #%i: You cast an Add Faction spell.", i);
				break;
			}
			case SE_Stun: {
				Message(0, "Effect #%i: You cast a Stun spell.", i);
				break;
			}
			case SE_Charm: {
				Message(0, "Effect #%i: You cast a Charm spell.", i);
				break;
			}
			case SE_Fear: {
				Message(0, "Effect #%i: You cast a Fear spell.", i);
				break;
			}
			case SE_Stamina: {
				Message(0, "Effect #%i: You cast a Stamina add/subtract spell.", i);
				break;
			}
			case SE_BindAffinity: {
				Message(0, "Effect #%i: You cast a Bind Affinity spell.", i);
				break;
			}
			case SE_Gate: {
				Message(0, "Effect #%i: You cast a Bind Affinity spell.", i);
				break;
			}
			case SE_CancelMagic: {
				Message(0, "Effect #%i: You cast a Cancel Magic spell.", i);
				break;
			}
			case SE_InvisVsUndead: {
				Message(0, "Effect #%i: You cast an Invis Vs Undead spell.", i);
				break;
			}
			case SE_Mez: {
				Message(0, "Effect #%i: You cast a Mez spell.", i);
				break;
			}
			case SE_SummonItem: {
				if (this->IsClient()) {
					Message(0, "Effect #%i: You cast a Summon Item #%i.", i, spells[spell_id].base[i]);
					this->CastToClient()->SummonItem(spells[spell_id].base[i], 1);
				}
				break;
			}
			case SE_SummonPet: {
				Message(0, "Effect #%i: You cast a Summon Pet spell.", i);
				break;
			}
			case SE_DivineAura: {
				Message(0, "Effect #%i: You cast a Divine Aura spell.", i);
				break;
			}
			case SE_ShadowStep: {
				Message(0, "Effect #%i: You cast a Shadow Step spell.", i);
				break;
			}
			case SE_ResistFire: {
				Message(0, "Effect #%i: You cast a Resist Fire spell.", i);
				break;
			}
			case SE_ResistCold: {
				Message(0, "Effect #%i: You cast a Resist Cold spell.", i);
				break;
			}
			case SE_ResistPoison: {
				Message(0, "Effect #%i: You cast a Resist Poison spell.", i);
				break;
			}
			case SE_ResistDisease: {
				Message(0, "Effect #%i: You cast a Resist Disease spell.", i);
				break;
			}
			case SE_ResistMagic: {
				Message(0, "Effect #%i: You cast a Resist Magic spell.", i);
				break;
			}
			case SE_SenseDead: {
				Message(0, "Effect #%i: You cast a Sense Dead spell.", i);
				break;
			}
			case SE_SenseSummoned: {
				Message(0, "Effect #%i: You cast a Sense Summoned spell.", i);
				break;
			}
			case SE_SenseAnimals: {
				Message(0, "Effect #%i: You cast a Sense Animals spell.", i);
				break;
			}
			case SE_Rune: {
				Message(0, "Effect #%i: You cast a Rune spell.", i);
				break;
			}
			case SE_TrueNorth: {
				Message(0, "Effect #%i: You cast a True North spell. UBER!", i);
				break;
			}
			case SE_Levitate: {
				Message(0, "Effect #%i: You cast a Levitate spell.", i);
				break;
			}
			case SE_Illusion: {
				Message(0, "Effect #%i: You cast an Illusion spell.", i);
				break;
			}
			case SE_DamageShield: {
				Message(0, "Effect #%i: You cast a Damage Shield spell.", i);
				break;
			}
			case SE_Identify: {
				Message(0, "Effect #%i: You cast an Identify spell.", i);
				break;
			}
			case SE_WhipeHateList: {
				if (this->IsNPC()) {
					this->CastToNPC()->WhipeHateList();
				}
				Message(13, "Your mind fogs. Who are my friends? Who are my enimies?... it was all so clear a moment ago...");
//				Message(0, "Effect #%i: You cast a Mem Blur spell.", i);
				break;
			}
			case SE_SpinTarget: {
				Message(0, "Effect #%i: You cast a Spin Target spell.", i);
				break;
			}
			case SE_InfaVision: {
				Message(0, "Effect #%i: You cast an InfaVision buff.", i);
				break;
			}
			case SE_UltraVision: {
				Message(0, "Effect #%i: You cast an UltraVision buff.", i);
				break;
			}
			case SE_EyeOfZomm: {
				Message(0, "Effect #%i: You cast an Eye of Zomm spell.", i);
				break;
			}
			case SE_ReclaimPet: {
				Message(0, "Effect #%i: You cast a Reclaim Pet spell.", i);
				break;
			}
			case SE_TotalHP: {
				Message(0, "Effect #%i: You cast an HP buff/debuff.", i);
				break;
			}
			case SE_BindSight: {
				Message(0, "Effect #%i: You cast a Bind Sight spell.", i);
				break;
			}
			case SE_FeignDeath: {
				Message(0, "Effect #%i: You cast a Feign Death spell.", i);
				break;
			}
			case SE_VoiceGraft: {
				Message(0, "Effect #%i: You cast a Voice Graft spell.", i);
				break;
			}
			case SE_Sentinel: {
				Message(0, "Effect #%i: You cast Sentinel. Fuck You.", i);
				break;
			}
			case SE_LocateCorpse: {
				Message(0, "Effect #%i: You cast a Locate Corpse spell.", i);
				break;
			}
			case SE_CurrentHPOnce: {
				Message(0, "Effect #%i: You cast a Heal / Nuke (non-reoccuring) spell.", i);
				break;
			}
			case SE_Revive: {
				Message(0, "Effect #%i: You cast a Revive spell.", i);
				break;
			}
			case SE_Teleport: {
				if (this->IsClient())
					this->CastToClient()->MovePC(spells[spell_id].teleport_zone, spells[spell_id].base[1], spells[spell_id].base[0], spells[spell_id].base[2]*10);
				break;
			}
			case SE_ModelSize: {
				Message(0, "Effect #%i: You cast a Shrink/Grow spell.", i);
				break;
			}
			case SE_Root: {
				Message(0, "Effect #%i: You cast a Root spell.", i);
				break;
			}
			case 0xFE:
			case 0xFF: {
				// this is the code for empty... i think
				break;
			}
			default: {
				Message(0, "Effect #%i: I dont know what this effect is: 0x%x.", i, spells[spell_id].effectid[i]);
			}
		}
	}
}

sint32 CalcSpellValue(int8 formula, sint16 base, sint16 max, int8 caster_level) {
/*
0x01 - 0x63 = level * formulaID

0x64 = min
0x65 = min + level / 2
0x66 = min + level
0x67 = min + level * 2
0x68 = min + level * 3
0x69 = min + level * 4
0x6c = min + level / 3
0x6d = min + level / 4
0x6e = min + level / 5
0x77 = min + level / 8
*/
//cout << "Cast Spell: f=0x" << hex << (int) formula << dec << ", b=" << base << ", m=" << max << ", cl=" << (int) caster_level << endl;
	sint16 ubase = abs(base);
	sint16 result = 0;
	switch(formula) {
		case 0x64:
		case 0x00: {
			result = ubase;
			break;
		}
		case 0x65: {
			result = ubase + (caster_level / 2);
			break;
		}
		case 0x66: {
			result = ubase + caster_level;
			break;
		}
		case 0x67: {
			result = ubase + (caster_level * 2);
			break;
		}
		case 0x68: {
			result = ubase + (caster_level * 3);
			break;
		}
		case 0x69: {
			result = ubase + (caster_level * 4);
			break;
		}
		case 0x6c: {
			result = ubase + (caster_level / 3);
			break;
		}
		case 0x6d: {
			result = ubase + (caster_level / 4);
			break;
		}
		case 0x6e: {
			result = ubase + (caster_level / 5);
			break;
		}
		case 0x77: {
			result = ubase + (caster_level / 8);
			break;
		}
		default: {
			if (formula < 100) {
				result = ubase + (caster_level * formula);
				break;
			}
			else {
				cout << "Unknown spell formula. b=" << base << ", m=" << max << ", f=0x" << hex << formula << dec << endl;
				break;
			}
		}
	}
	if (result >= max && max != 0)
		return max * sign(base);
	else
		return result * sign(base);
}
