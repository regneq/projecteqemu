#include <math.h>
#include "../common/moremath.h"
#ifndef WIN32
	#include <stdlib.h>
	#include <pthread.h>
#endif

#include "npc.h"
#include "client.h"

extern Database database;

NPC::NPC(NPCType* d, void* in_respawn, float x, float y, float z, float heading, bool isgroup)
 : Mob(d->name,
       d->lastname,
       d->max_hp,
       d->max_hp,
       d->gender,
       d->race,
       d->class_,
       d->deity,
       d->level,
	   d->npc_id, // rembrant, Dec. 20, 2001
	   d->skills, // socket 12-29-01
       heading,
       x,
       y,
       z,
       d->light,
       d->equipment)
{
	if (d->npc_id == 0) { // GM created
		respawn = 0;
		respawn2 = 0;
	}
	if (isgroup) {
		respawn =0;
		respawn2 = (Spawn2*) in_respawn;
	}
	else {
		respawn2 =0;
		respawn = (Spawn*) in_respawn;
	}

	itemlist = new ItemList();
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;

	if (d->npc_id != 0) { // check if it's a GM spawn
		database.AddLootTableToNPC(d->loottable_id, itemlist, &copper, &silver, &gold, &platinum);
	}

	movement_timer = new Timer(100);
}

NPC::~NPC()
{
	delete movement_timer;
	delete itemlist;
}

ServerLootItem_Struct* NPC::GetItem(int slot_id) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		ServerLootItem_Struct* item = iterator.GetData();
		if (item->equipSlot == slot_id)
		{
			return item;
		}
		iterator.Advance();
	}
	cout << "no item found for slot: " << slot_id << endl;
	return 0;
}

void NPC::AddItem(Item_Struct* item, int8 charges, uint8 slot)
{
    //cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = item->item_nr;
	(*itemlist).Append(item_data);
}

void NPC::RemoveItem(uint16 item_id)
{
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->item_nr == item_id)
		{
			Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}

	return;
}

void NPC::QueryLoot(Client* to) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements())
	{
		Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
		to->Message(0, "  %d: %s", item->item_nr, item->name);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void NPC::AddCash(int16 copper, int16 silver, int16 gold, int16 platinum)
{
	this->copper = (rand() % 100)+1;
	this->silver = (rand() % 50)+1;
	this->gold = (rand() % 10)+1;
	this->platinum = (rand() % 5)+1;
}

void NPC::RemoveCash()
{
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
}

bool NPC::Process()
{
	if (corpse)
		return true;
	float angle = 0;

	SetTarget(hate_list.GetTop());

	if (target != 0)
	{
		bool sendposupdate = false;
		if (movement_timer->Check()) {
//			movement_timer->Start();
			// NPC can move per "think", this number should be an EQ distance squared
#define NPC_MOVEMENT_PER_TIC		400
			int32 total_move_dist = DistNoRootNoZ(target);
				if (total_move_dist > 75) {
				total_move_dist -= 50;
				if (total_move_dist > NPC_MOVEMENT_PER_TIC)
					total_move_dist = NPC_MOVEMENT_PER_TIC;
//cout << "DEBUG: NPC Movement" << endl;
//cout << "tar->X=" << target->GetX() << ", x_pos=" << x_pos << ", tar->X - x_pos=" << target->GetX() - x_pos << ", pow(tar->X - x_pos, 2)=" << pow(target->GetX() - x_pos, 2) << endl;
//cout << "tar->Y=" << target->GetY() << ", y_pos=" << y_pos << ", tar->Y - y_pos=" << target->GetY() - y_pos << ", pow(tar->Y - y_pos, 2)=" << pow(target->GetY() - y_pos, 2) << endl;
				sint32 x2 = pow(target->GetX() - x_pos, 2);
				sint32 y2 = pow(target->GetY() - y_pos, 2);
				// divide by zero "should" be impossible here because of the DistNoRootNoZ check
				sint32 x_move = total_move_dist * ((float)x2/(x2+y2)); // should be already abs()'d from the square
				sint32 y_move = total_move_dist - x_move;
//cout << "x2=" << x2 << ", x_move=" << x_move << ", sign(target->GetX() - x_pos)=" << (int) sign(target->GetX() - x_pos) << endl;
//cout << "y2=" << y2 << ", y_move=" << y_move << ", sign(target->GetY() - y_pos)=" << (int) sign(target->GetY() - y_pos) << endl;
				x_pos += sqrt((double)x_move) * sign(target->GetX() - x_pos);
				y_pos += sqrt((double)y_move) * sign(target->GetY() - y_pos);
//cout << "sqrt(x_move)=" << sqrt((double)x_move) << ", x_pos=" << x_pos << endl;
//cout << "sqrt(y_move)=" << sqrt((double)y_move) << ", y_pos=" << y_pos << endl;
				sendposupdate = true;
			}
		}
		if (attack_timer->Check()) {
			attack_timer->Start();
			angle = FaceTarget();
			Attack(target);
			sendposupdate = true;
		}
		if (sendposupdate) // dont need to send twice in both of the above, so...
			SendPosUpdate();
	}

    return true;
}

float NPC::FaceTarget()
{
	// TODO: Simplify?

	float angle;

	if (target->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else if (target->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (target->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
//cout << "dX:" << target->GetX()-x_pos;
//cout << "dY:" << target->GetY()-y_pos;
//cout << "Angle:" << angle;

	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;

	heading = 256*(360-angle)/360.0f;
	return angle;

//cout << "Heading:" << (int)heading << endl;
}

void NPC::RemoveFromHateList(Mob* mob)
{
	hate_list.RemoveEnt(mob);
}