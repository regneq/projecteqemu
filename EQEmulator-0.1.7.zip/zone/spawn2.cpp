#include <stdlib.h>
#include "spawn2.h"
#include "entity.h"
#include "npc.h"
#include "zone.h"
#include "spawngroup.h"

extern EntityList entity_list;
extern Zone* zone;


Spawn2::Spawn2(int spawngroup_id, int x, int y, int z, int respawn, int variance)
{
	spawngroup_id_ = spawngroup_id;
	x_ = x;
	y_ = y;
	z_ = z;
    respawn_ = respawn;
	variance_ = variance;

	timer = new Timer( resetTimer() );
	timer->Trigger();
}

Spawn2::~Spawn2()
{
	delete timer;
}

int Spawn2::resetTimer()
{
	int rspawn = respawn_ * 1000;
	int vardir = (rand()%50);
	int variance = (rand()%variance_);
	float varper = variance*0.01;
	float varvalue = varper*(rspawn);
	if (vardir < 50)
	{
	  varvalue = varvalue * -1;
	}

	rspawn += varvalue;


	return (rspawn);

}

void Spawn2::Process()
{
	if (timer->Check())
	{
		timer->Disable();

		int npcid = zone->spawn_group_list->GetSpawnGroup(spawngroup_id_)->GetNPCType();
		if (npcid > 0)
		{
			entity_list.AddNPC(new NPC(zone->GetNPCType(npcid), this, x_, y_, z_, 0, true));
		}
		/* 
		else
		{
			Reset();
		}
		*/
	}
}

void Spawn2::Reset()
{
	timer->Start(resetTimer());
}
