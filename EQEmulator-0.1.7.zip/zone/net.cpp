#include <iostream.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQPacket.h"
#include "../common/EQPacketManager.h"
#include "../common/eq_packet_structs.h"

#include "net.h"
#include "client.h"
#include "zone.h"
#include "worldserver.h"
#include "spdat.h"

NetConnection net;
EntityList    entity_list;
WorldServer*   worldserver = 0;
int32 numclients = 0;
GuildRanks_Struct guilds[512];

#define SPDat_Location	"spdat.eff"
SPDat_Spell_Struct spells[SPDAT_RECORDS];
bool spells_loaded = false;

#ifdef BUILD_FOR_WINDOWS
	Database database;
	#include <process.h>
#else
	Database database("localhost", "user", "pw", "eq");
	#include <pthread.h>
	#define Sleep(x) usleep((x) * 1000)
#endif

Zone* zone;

void Shutdown();
void CatchSignal(int);
bool ZoneBootup(char* zone_name);
void LoadSPDat();

int main(int argc, char** argv)
{
	srand(time(NULL));
	if (argc != 5)
	{
		cerr << "Usage: zone zone_name address port worldaddress" << endl;
		exit(0);
	}

	char* zone_name = argv[1];
	char* address = argv[2];
	int32 port = atoi(argv[3]);
	char* worldaddress = argv[4];

	if (strlen(address) <= 0)
	{
		cerr << "Invalid address" << endl;
		exit(0);
	}
	if (port <= 0)
	{
		cerr << "Bad port specified" << endl;
		exit(0);
	}
	if (strlen(worldaddress) <= 0)
	{
		cerr << "Invalid worldaddress" << endl;
		exit(0);
	}
	if (signal(SIGINT, CatchSignal) == SIG_ERR)
	{
		cerr << "Could not set signal handler" << endl;
	}

	cout << "Loading items...";
	database.LoadItems();
	cout << "done." << endl;
	LoadSPDat();
	cout << "Loading guild ranks...";
	database.LoadGuilds(guilds);
	cout << "done." << endl;

	net.SaveInfo(address, port, worldaddress);
	if (!InitWorldServer()) {
		cerr << "InitWorldServer failed" << endl;
		worldserver=0;
	}
	if (strcmp(zone_name, ".") == 0) {
/*
		if (worldserver == 0) {
			cout << "ERROR: sleep mode specified and worldserver connect failed. Exiting." << endl;
			exit(0);
		} else
*/
			cout << "Entering sleep mode" << endl;
	} else if (!ZoneBootup(zone_name)) {
		cerr << "Zone bootup failed";
		zone = 0;
	}

	Timer InterserverTimer(INTERSERVER_TIMER); // does MySQL pings and auto-reconnect
	while(1)
	{
		Timer::SetCurrentTime();
		if (zone != 0) {
			net.ListenNewClients();
			entity_list.Process();
			zone->Process();
		} else
			Sleep(50);
		if (InterserverTimer.Check()) {
			InterserverTimer.Start();
			database.ping();
			entity_list.UpdateWho();
			if (worldserver == 0) {
#ifdef BUILD_FOR_WINDOWS
				_beginthread(AutoInitWorldServer, 0, NULL);
#else
				pthread_t thread;
				pthread_create(&thread, NULL, AutoInitWorldServer, NULL);
#endif
			}
		}
		Sleep(1);
	}
	Shutdown();
}
	

void CatchSignal(int sig_num)
{
	entity_list.Save();
	cout << "Got signal " << sig_num << endl;
	Shutdown();
}

bool ZoneBootup(char* zone_name) {
	if (zone != 0) {
		cerr << "Error: ZoneBootup call when zone already booted!" << endl;
		return false;
	}
	zone = new Zone(zone_name, net.GetZoneAddress(), net.GetZonePort());
	if (!net.Init()) {
		cerr << "NetConnection::Init failed" << endl;
		return false;
	}
	if (!database.RegisterZoneServer(zone_name, net.GetZoneAddress(), net.GetZonePort())) {
		cerr << "Could not register zone: " << zone_name << endl;
		cerr << "Is this zone already registered?" << endl;
		net.Close();
		delete zone;
		zone = 0;
		return false;
	}
	if (worldserver != 0) {
		worldserver->SetZone(zone_name);
		worldserver->SendEmoteMessage(0, 0, 15, "Zone bootup: %s", zone->GetLongName());
	}

	cout << "-----------" << endl << "Zone server '" << zone_name << "' listening on port:" << net.GetZonePort() << endl << "-----------" << endl;
	return true;
}

void ZoneShutdown() {
	if (worldserver == 0)
		entity_list.ChannelMessageFromWorld(0, 0, 6, 0, 0, "Zone shutdown: Going to sleep mode");
	else
		cout << "Zone shutdown: going to sleep" << endl;
	Sleep(1);
//	if (numclients != 0)
//		entity_list.Process();
	entity_list.Clear();
	Zone* tmp;
	tmp = zone;
	net.Close();
	zone = 0;
	Sleep(0);
	delete tmp;
}

void Shutdown()
{
	WorldServer* tmp = worldserver;
	worldserver = 0;
	if (tmp != 0)
		delete tmp;
	if (zone != 0)
		ZoneShutdown();
	cout << "Shutting down..." << endl;
	exit(0);
}

bool NetConnection::Init()
{
	struct sockaddr_in address;
	int reuse_addr = 1;
	
	#ifdef BUILD_FOR_WINDOWS
		unsigned long nonblocking = 1;
		WORD version = MAKEWORD (1,1);
		WSADATA wsadata;
	#endif

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(ZonePort);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up UDP port for new clients */
	listening_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (listening_socket < 0) 
 	{
	
		return false;
	}

//	setsockopt(listening_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));

	if (bind(listening_socket, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
		#ifdef BUILD_FOR_WINDOWS
			closesocket(listening_socket);
		#else
			close(listening_socket);
		#endif
		
		return false;
	}

	#ifdef BUILD_FOR_WINDOWS
		ioctlsocket (listening_socket, FIONBIO, &nonblocking);
	#else
		fcntl(listening_socket, F_SETFL, O_NONBLOCK);
	#endif
	

	return true;
}

void NetConnection::ListenNewClients()
{
	
    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	#ifdef BUILD_FOR_WINDOWS
		status = recvfrom(listening_socket, (char *) &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, (int *) &fromlen);
	#else
		status = recvfrom(listening_socket, &buffer, sizeof(buffer), 0,(struct sockaddr*) &from, &fromlen);
	#endif
    

    if (status > 1)
    {
		Client* client = 0;

		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		client = entity_list.GetClient(in.s_addr, from.sin_port);
		if (client == 0)
		{
			// If it is a new client make sure it has the starting flag set. Ignore otherwise
			if (buffer[0] & 0x20)
			{
				cout << " New client from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << endl;
				client = new Client(in.s_addr, port, listening_socket);
	    		entity_list.AddClient(client);
				numclients++;
			}
			else
			{
				return;
			}
		}
		else
		{
//cout << Timer::GetCurrentTime() << " Data from ip: " << inet_ntoa(in) << " port:" << ntohs(port) << " length: " << status << endl;
		}
		client->ReceiveData(buffer, status);
	}
}

int32 NetConnection::GetIP()
{
	char     name[255+1];
	size_t   len;
	hostent* host = 0;

	if (gethostname(name, len) < 0 || len <= 0)
	{
		return 0;
	}

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);
}

int32 NetConnection::GetIP(char* name)
{
	hostent* host = 0;

	host = gethostbyname(name);
	if (host == 0)
	{
		return 0;
	}

	return inet_addr(host->h_addr);

}

void NetConnection::SaveInfo(char* address, int32 port, char* waddress) {
	ZoneAddress = new char[strlen(address)+1];
	strcpy(ZoneAddress, address);
	ZonePort = port;
	WorldAddress = new char[strlen(waddress)+1];
	strcpy(WorldAddress, waddress);
}

NetConnection::~NetConnection() {
	if (ZoneAddress != 0)
		delete ZoneAddress;
	if (WorldAddress != 0)
		delete WorldAddress;
}

void NetConnection::Close() {
	#ifdef BUILD_FOR_WINDOWS
		closesocket(listening_socket);
	#else
		close(listening_socket);
	#endif
}

void LoadSPDat() {
	FILE *fp;
	for (int j = 0; j < SPDAT_RECORDS; j++)
		memset((char*) &spells[j], 0, sizeof(SPDat_Spell_Struct));

	if (fp = fopen(SPDat_Location, "rb"))
	{
//		if (_filelength(fp) != SPDAT_SIZE) {
//			cout << "SPDat wrong size ('" << SPDat_Location << "'), spells not loaded." << endl;
//		}
//		else
		{
			for (int i = 0; i < SPDAT_RECORDS; i++) {
				fread(&spells[i], sizeof(SPDat_Spell_Struct), 1, fp);
			}
			spells_loaded = true;
			cout << "Spells loaded from '" << SPDat_Location << "'." << endl;
		}
		fclose(fp);
	}
	else
		cout << "SPDat not found ('" << SPDat_Location << "'), spells not loaded." << endl;
}