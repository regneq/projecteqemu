#ifndef HATELIST_H
#define HATELIST_H

#include "../common/types.h"

class Mob;

class HateListElement
{
private:

	Mob*       ent;
	uint32           amount;
	HateListElement* next;

public:
	HateListElement(Mob* in_ent, uint32 in_amount)
	{
		ent = in_ent;
		amount = in_amount;
		next = 0;
	}

	~HateListElement()
	{
		if (next != 0)
		{
			delete next;
		}
	}

	void AddAmount(uint32 add) { amount += add; }
	uint32 GetAmount() { return amount; }
	Mob* GetEnt() { return ent; }

	HateListElement* GetNext()         { return  next; }
	void SetNext(HateListElement* n)	{ next = n; } 
};

class HateList
{
private:
	HateListElement* first;
public:
	HateList();
	~HateList();

	void Add(Mob* ent, uint32 amount);
	uint32 RemoveEnt(Mob* ent);
	Mob* GetTop();
	void Whipe();
};

#endif
