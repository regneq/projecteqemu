#ifndef NPC_H
#define NPC_H

#include "../common/database.h"
#include "mob.h"
#include "spawn.h"
#include "spawn2.h"
#include "hate_list.h"
#include "loottable.h"

#ifdef BUILD_FOR_WINDOWS
	#define  M_PI	3.141592
#endif

//typedef LinkedList<Item_Struct*> ItemList;

class NPC : public Mob
{
public:
	NPC(NPCType* data, void* respawn, float x, float y, float z, float heading, bool isgroup);
	virtual ~NPC();

	virtual bool IsNPC() { return true; }

	virtual bool Process();

	void Attack(Mob* other);
	void Damage(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);
	void Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);

	float FaceTarget();
	void RemoveFromHateList(Mob* mob);
	void WhipeHateList() { hate_list.Whipe(); }

	void AddItem(Item_Struct* item, int8 charges, uint8 slot);
	void RemoveItem(uint16 item_id);
	ServerLootItem_Struct* GetItem(int slot_id);
	void AddCash(int16 copper, int16 silver, int16 gold, int16 platinum);
	void RemoveCash();
	ItemList* GetItemList() { return itemlist; }
	void QueryLoot(Client* to);

	uint32 GetCopper() { return copper; }
	uint32 GetSilver() { return silver; }
	uint32 GetGold()   { return gold; }
	uint32 GetPlatinum() { return platinum; }
protected:
	HateList hate_list;
	Spawn* respawn;
	Spawn2* respawn2;
	
	uint32 copper;
	uint32 silver;
	uint32 gold;
	uint32 platinum;
	ItemList* itemlist;

	Timer* movement_timer;
};

#endif

