#ifndef TCPCONNECTION_H
#define TCPCONNECTION_H
class TCPConnection
{
public:
	TCPConnection() { }
	~TCPConnection() { }
	virtual void SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...) { }
};

#endif