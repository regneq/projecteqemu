#ifndef BUILD_FOR_WINDOWS
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <netdb.h>
	#include <unistd.h>
	#include <errno.h>
	#include <fcntl.h>
#else
	#include <errno.h>
	#include <fcntl.h>
	#include <windows.h>
	#include <winsock.h>
#endif


const int PORT = 9000;

class NetConnection
{
public:
	NetConnection() { world_locked = false; LoginServerInfo = ReadLoginINI(); }
	~NetConnection() { }
	bool Init();
	void ListenNewClients();

	bool ReadLoginINI();
	bool LoginServerInfo;
	char* GetLoginAddress() { return loginaddress; }
	char* GetWorldName() { return worldname; }
	char* GetWorldAccount() { return worldaccount; }
	char* GetWorldPassword() { return worldpassword; }

	bool world_locked;
private:
	int listening_socket;
	char loginaddress[101];
	char worldname[201];
	char worldaccount[31];
	char worldpassword[31];
};
