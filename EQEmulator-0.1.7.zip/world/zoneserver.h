#ifndef ZONESERVER_H
#define ZONESERVER_H

#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/servertalk.h"
#include "TCPConnection.h"
#include "console.h"

class ClientListEntry;

#ifdef BUILD_FOR_WINDOWS
	void ZoneServerLoop(void *tmp);
#else
	void *ZoneServerLoop(void *tmp);
#endif
void SOPZoneBootup(char* adminname, int32 ZoneServerID, char* zonename);

class ZoneServer : public TCPConnection
{
public:
	ZoneServer(int32 ip, int16 port, int send_socket);
    ~ZoneServer();
	bool SetZone(char* zonename);
	bool SetPort(int16 in_port);
	
	bool Process();
	bool ReceiveData();
	void SendPacket(ServerPacket* pack);
	void SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...);

	char* GetZoneName() { return zone_name; }
	int32 GetIP()    { return ip; }
	int16 GetPort()  { return port; }
	int32 GetID()	 { return ID; }

private:
	int32 ID;
	int send_socket;
	int32 ip;
	int16 port;

	Timer* timeout_timer;

	MyQueue<ServerPacket> ServerOutQueue;
	MyQueue<ServerPacket> ServerSendQueue;
	
	char zone_name[16];
};

class ZSList
{
public:
	ZSList();
	~ZSList();
	ZoneServer* FindByName(char* zonename);
	ZoneServer* FindByID(int32 ZoneID);
	
	void SendChannelMessage(char* from, char* to, int8 chan_num, int8 language, char* message, ...);
	void SendEmoteMessage(char* to, int32 to_guilddbid, int32 type, char* message, ...);

	void ClientUpdate(ZoneServer* zoneserver, char* name, int32 accountid, char* accountname, int8 admin, char* zone, int8 level, int8 class_, int8 race, int8 anon, bool notell, int32 in_guilddbid, int32 in_guildeqid);
	void ClientRemove(char* name, char* zone);

	void SendWhoAll(char* to, int8 admin, TCPConnection* connection);
	void SendZoneStatus(char* to, int8 admin, TCPConnection* connection);
	ClientListEntry* FindCharacter(char* name);
	void CLCheckStale();
	
	void Add(ZoneServer* zoneserver);
	void Process();
	void ReceiveData();
	void SendPacket(ServerPacket* pack);
	int32 GetNextID() { return NextID++; }

#ifdef WIN32
	CRITICAL_SECTION CSListLock;
#else
	pthread_mutex_t CSListLock;
#endif
private:
	int32 NextID;
	LinkedList<ZoneServer*> list;
	LinkedList<ClientListEntry*> clientlist;
};

class ClientListEntry
{
public:
	ClientListEntry(ZoneServer* zoneserver, char* in_name, int32 in_accountid, char* in_accountname, int8 in_admin, char* in_zone, int8 level, int8 class_, int8 race, int8 anon, bool notell, int32 in_guilddbid, int32 in_guildeqid) {
		pzoneserver = zoneserver;
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
		panon = anon;
		pnotell = notell;
		pguilddbid = in_guilddbid;
		pguildeqid = in_guildeqid;
		stale = 0;
		timeout_timer = new Timer(INTERSERVER_TIMER);
	}
	~ClientListEntry() {
		delete timeout_timer;
	}
	bool CheckStale() {
		if (timeout_timer->Check()) {
			if (stale >= 2) {
				return true;
			}
			else {
				stale++;
				return false;
			}
		}
	}
	void Update(ZoneServer* zoneserver, char* in_name, int32 in_accountid, char* in_accountname, int8 in_admin, char* in_zone, int8 level, int8 class_, int8 race, int8 anon, bool notell, int32 in_guilddbid, int32 in_guildeqid) {
		pzoneserver = zoneserver;
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
		panon = anon;
		pnotell = notell;
		pguilddbid = in_guilddbid;
		pguildeqid = in_guildeqid;
		stale = 0;
	}
	ZoneServer* Server() { return pzoneserver; }
	char* name() { return pname; }
	char* zone() { return pzone; }
	char* AccountName() { return paccountname; }
	int32 AccountID() { return paccountid; }
	int8 Admin() { return padmin; }
	int8 level() { return plevel; }
	int8 class_() { return pclass_; }
	int8 race() { return prace; }
	int8 Anon() { return panon; }
	int8 NoTell() { return pnotell; }
	int32 GuildDBID() { return pguilddbid; }
	int32 GuildEQID() { return pguildeqid; }
private:
	ZoneServer* pzoneserver;
	char pzone[30];
	int8 padmin;
	char pname[30];
	int32 paccountid;
	char paccountname[30];
	int8 plevel;
	int8 pclass_;
	int8 prace;
	int8 panon;
	int8 pnotell;
	int32 pguilddbid;
	int32 pguildeqid;

	int8 stale;

	Timer* timeout_timer;
};
#endif
