#ifndef CLIENT_H
#define CLIENT_H

#include "../common/EQPacketManager.h"
#include "../common/linked_list.h"
#include "../common/timer.h"

#define CLIENT_TIMEOUT 30000

class Client
{
public:
	Client(int32 ip, int16 port, int send_socket);
    ~Client();
	
	bool Process();
	void ReceiveData(uchar* buf, int len);

	int32 GetIP()    { return ip; }
	int16 GetPort()  { return port; }

	void SendCharInfo();

private:
	int32 ip;
	int16 port;

	int send_socket;

	CEQPacketManager packet_manager;

	Timer* timeout_timer;
	
	int32 account_id;
	char char_name[16];
	char zone_name[16];
};

class ClientList
{
public:
	ClientList() {}
	~ClientList() {}
	
	void Add(Client* client);
	Client* Get(int32 ip, int16 port);
	void Process();

private:
	LinkedList<Client*> list;
};

#endif
