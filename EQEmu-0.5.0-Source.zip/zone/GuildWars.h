#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/database.h"
#include "mob.h"
#include "npc.h"
#include "client.h"

class GuildWars;
class GuildObjects;
class GuildNPCs;
class GuildLocation;
class GuildLocationList;

class GuildWars
{
public:
	sint32	GetCurrentGuildFaction(Mob* mobone,Mob* mobtwo);
	GuildWars(void);
	~GuildWars(void);
protected:
	friend class GuildLocationList;
};

class GuildObjects
{

};

class GuildNPCs
{
public:
	GuildNPCs(NPC* npc);
	bool	IsAlive() { return alive; }
	NPC*	ToNPC() { return npcpointer; }
private:
	bool	alive;
	NPC*	npcpointer;
};

class GuildLocation
{
public:
	GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild);
	~GuildLocation();

	void	AddNPC(NPC* npc);
	bool	GuardsStillStanding();
	int32	GetLocationID() { return location_id; }
private:
	Timer*	cycle_timer;
	int32	location_id;
	float	x;
	float	y;
	float	z;
	int32	zoneid;
	int8	locationtype;
	int32	guildid;
	LinkedList<GuildNPCs*> guildnpcs;
	LinkedList<GuildObjects*> guildobjects;
};

class GuildLocationList
{
public:
	GuildLocationList(void);
	~GuildLocationList(void);

	bool	RemoveLocation(int32 locid);
	void	AddLocation(GuildLocation* gl);
	void	ClearLocations();

	GuildLocation*	FindLocationByID(int32 locid);
private:
	LinkedList<GuildLocation*> list;
};

#define MAXMEMBERS				20
#define NOGUILDCAPLEVEL			21
#define SETLEVEL				50
#define GAINLEVEL				51
//Experience Rules
#define EXPLOSSLVLDIFF			20
#define EXPHNOCHGLVLDIFF		10
#define EXPLNOCHGLVLDIFF		-25
//Level Restriction Rules (no <= or >= all < or > functions unless using opposite of proper use, then sign + equal to)
#define NORESTRICTIONS			21	// Less Than: No rules, freely do whatever
#define MIDLEVELRESTRICT		20	// Greater Than: if person is not in a guild, cannot buff others in guilds and guilds cannot buff this person (TBD: Lvl 20-30, Slower experience than people in guilds?)
#define MIDHIGHLEVELRESTRICT	29	// Greater Than: cannot level past 30 without guild, cannot buff others in guilds and guilds cannot buff this person.
#define HIGHLEVELRESTRICT		39	// Greater Than: guild is required to level, if no guild, guilds can PvP the target, player cannot be buffed by members in guilds and cannot buff members in guilds.
//Guildwars Faction System
#define GW_ALLY					2000
#define GW_WARMLY				1600
#define GW_KINDLY				1200
#define GW_AMIABLY				800
#define GW_INDIFFERENTLY		400
#define GW_APPREHENSIVE			-1
#define GW_DUBIOUS				-400
#define GW_THREATNINGLY			-800
#define GW_SCOWL				-2000
#define GW_DEFAULTFACTION		-799
#define GW_FACTIONNOTEXIST		-2001