#define EVENT_SAY		1
#define EVENT_ITEM		2
#define EVENT_DEATH		3
#define EVENT_SPAWN		4
#define EVENT_ATTACK	5
#define EVENT_SLAY		6
#define EVENT_WAYPOINT  7
#define EVENT_TIMER     8

