/*  EQEMu:  Everquest Server Emulator
	Copyright (C) 2001-2003  EQEMu Development Team (http://eqemulator.net)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  04111-1307  USA
*/
#ifndef EQ_OPCODES_H
#define EQ_OPCODES_H

// Invalid opcodes have been \t'd out, confirmed have no \t

//////////////////////////////////////
// Zone.exe opcodes:
//////////////////////////////////////
//0x012b ==party exp
//0x007a == Ability change ???
//0x009d == disconnect user
//0x00ca == receive money?
//0x0147 == create guild?
//0x01A6 == another message format?
//0x01f1 == your petition text...
	#define OP_ExpansionSetting	0x0203
	#define OP_IncreaseStats	0x01ef
	#define OP_GainMoney		0x0209
	#define OP_Sacrifice		0x019a
	#define OP_BecomePK			0x0190
	#define OP_Stamina		    0x0161
	#define OP_MobUpdate		0x003b
	#define OP_ClientUpdate		0x0024
	#define OP_ChannelMessage	0x0021
	#define OP_SimpleMessage    0x01dc
	#define OP_FormattedMessage 0x01dd
	#define OP_RaidInvite		0x01e8
	#define OP_RaidJoin			0x01e9

	#define OP_ApplyPoison		0x00b7
	#define OP_Bind_Wound		0x0126
	#define OP_Begging			0x0145
	#define OP_MoveCoin			0x014b
	#define OP_SpawnDoor		0x01b8 // solar 9/1/03
	#define OP_Sneak			0x009a // Clicked sneak - Doodman 10/10/2003
	#define OP_ExpUpdate		0x0076
	#define OP_DumpName			0x0266 //no idea what this is: just tired of looking at it as unknown
		#define OP_UpdateAA			0x0212
	#define OP_RespondAA		0x01ef // AA table
	#define OP_SendAAStats		0x01cd
	#define OP_AAAction         0x01ee // Used for changing percent, buying? and activating skills
		#define OP_BoardBoat		0x00b8
		#define OP_LeaveBoat		0x00b9
#define OP_SendExpZonein		0x0028
#define OP_ZoneInSendName		0x020f
#define OP_ZoneComplete			0x0083 //Client sends upon successful zone in
/*Guild Opcodes*/
	#define OP_GuildLeader		 0x00a5 // /guildleader
	#define OP_GuildPeace		 0x0098 // /guildpeace
	#define OP_GuildRemove		 0x013f // /guildremove
	#define OP_GuildMemberList   0x0056
	#define OP_GuildMemberUpdate 0x0257

		#define OP_GMDelCorpse		0x0199 // /delcorpse

/*Bazaar*/
	#define OP_Trader			0x01ec // /trader
	#define OP_Bazaar			0x01eb // /bazaar search
	#define OP_BecomeTrader		0x01c8
	#define	OP_BazaarInspect	0x01fa
		#define OP_PetCommands		0x01aa	// solar 9/1/03
	#define OP_TradeSkillCombine 0x003f
		#define OP_TraderItemUpdate	0x0069
	#define	OP_TraderDelItem	0x0174
		#define OP_TraderShop		0x01f0	// right-click on a trader in bazaar
	#define OP_TraderBuy		0x01ce	// buy from a trader in bazaar

/*Shops*/
	#define OP_ShopPlayerBuy	0x0062
	#define OP_ShopTakeMoney	0x0062
	#define OP_ShopPlayerSell	0x0067
	#define OP_ShopEndConfirm	0x4541
	#define OP_ShopRequest		0x00f0	// right-click on merchant
	#define OP_ShopEnd			0x0069	// Finished shopping at merchant

	#define OP_LFPCommand		     0x025b	// Looking for player
	#define OP_LFPGetMatchesRequest  0x025c
	#define OP_LFPGetMatchesResponse 0x025e
	#define OP_LFGGetMatchesResponse 0x025d
	#define OP_LFGCommand		     0x0259	// When client issues /LFG command
	#define OP_LFGResponse           0x01af
	#define OP_LFGGetMatchesRequest  0x025a

		#define OP_LFGAppearance	0x01d4	// Some other char in zone turns LFG on/off



	#define OP_TradeMoneyUpdate		0x015b
		#define	OP_MoneyUpdate		0x01be
		#define OP_PetCommands		0x01aa	// solar 9/1/03

		#define OP_LFP				0x028a	// Looking for player
		#define OP_GroupUpdate		0x0233
		#define OP_GroupInvite		0x0248
		#define OP_GroupDisband		0x00f8 // solar 9/1/03 untested
		#define OP_GroupInvite2		0x00cd
		#define OP_GroupFollow		0x0247
		#define OP_GroupFollow2		0x4240
		#define OP_CancelInvite		0x00ce
		#define OP_GroupDelete		0x9721
	#define	OP_GroupAcknowledge	0x025b
	#define OP_ConsiderCorpse	0x01db
	#define OP_SkillUpdate		0x0061
	#define OP_GMEndTrainingResponse 0x0171 
	#define OP_GMEndTraining	0x0130 //
	#define OP_GMTrainSkill		0x016e //
	#define OP_GMTraining		0x012f // solar 9/1/03

	#define OP_ConsumeAmmo		0x0174
		#define OP_CombatAbility	0x016a

		#define OP_TrackUnknown		0x009e
		#define OP_TrackTarget		0x0248
	#define OP_Track			0x026f	// Clicked Track - Doodman 10/10/2003
	#define	OP_ReadBook			0x027e

	#define OP_ItemLinkClick	0x0017
	#define OP_ItemLinkResponse	0x01fa
		#define OP_ItemLinkText		0x01dd

	#define OP_RezzRequest		0x2a41
		#define OP_RezzAnswer		0x00e6
		#define OP_RezzComplete		0x019c

	#define	OP_MoveDoor			0x0121
	#define	OP_ClickDoor		0x0120	// Click door
	#define OP_SendZonepoints	0x0230	// Coords in a zone that will port you to another zone
	#define OP_SetRunMode		0x0089	// Client hit the "run" button (or control+r)
	#define OP_InspectRequest	0x0231
	#define OP_InspectAnswer	0x0232
	#define OP_SenseHeading		0x00c0	// Clicked sense heading button
	#define OP_SenseTraps		0x0187  // Clicked sense traps - @Doodman 10/10/2003
	#define OP_DisarmTraps		0x0186  // Clicked disarm traps - @Doodman 10/10/2003
		#define OP_Assist			0x01c1 // solar 9/1/03 untested
		#define OP_PickPocket		0x0258

	#define OP_LootRequest		0x0112
	#define OP_MoneyOnCorpse	0x0114
	#define OP_ItemOnCorpse		0x02c5
		#define OP_LootComplete		0x0172
	#define OP_EndLootRequest	0x0113
	#define OP_LootItem			0x0133
		#define OP_PlaceItem		0x014a	// Instruct client to put an item in a slot

		#define OP_Disciplines		0x01bb
	#define OP_WhoAllRequest   	0x0053
	#define OP_WhoAllResponse   0x0212
	#define OP_Consume			0x0160 // solar: untested
	#define OP_AutoAttack		0x016b
	#define OP_AutoAttack2		0x017e
	#define OP_TargetMouse		0x016c	// mouse targetting a person (also: Pressing F* key to target)
	#define OP_TargetCommand	0x01c0	// /target user
		#define OP_TargetReject		0x01dc	// When /target fails (// solar: untested)
	#define OP_Hide				0x009b	// Clciked Hide - Doodman 10/10/2003
	#define OP_Forage			0x0127 // Clicked forage  - @Doodman 10/10/2003
	#define OP_Adventure		0x02d7 // /adventure
		#define OP_Summoncorpse		0x029c // /summoncorpse
		#define OP_Feedback			0x015a	// /feedback
		#define OP_Bug				0x022f	// /bug
	#define OP_Emote			0x00eb	// /me goes blah
		#define OP_EmoteAnim		0x0134 // solar: untested
	#define OP_Consider			0x0155
	#define OP_FaceChange		0x01cf	// /face
	#define OP_Petition			0x0065
	#define OP_PDeletePetition	0x01f2
	#define OP_PViewPetition	0x01f1
	#define OP_Report			0x01e3
	#define OP_RandomReq		0x0197
	#define OP_RandomReply		0x0084
	#define OP_CommonMessage	0x0021
	#define OP_Camp				0x01c7
	#define OP_YellForHelp		0x0192
		#define OP_SafePoint		0x00e8
	#define OP_Jump				0x00d0
	#define OP_Buff			0x0150
	#define OP_BuffFadeMsg		0x00bd
		#define OP_SpecialMesg		0x0205	// Communicate textual info to client
	#define OP_Consent			0x000b	// /consent
	#define OP_Stun				0x0165
	#define OP_CastSpell		0x00bb
	#define OP_Death			0x00fe
		#define OP_FeignDeath		0x0257
	#define OP_Illusion			0x0124

	#define OP_LevelUpdate		0x0075
	#define OP_Split			0x0077
		#define OP_SearchCorpse		0x0099
		#define OP_LocateCorpse     0x00d1  //Sent when a client casts Locate Corpse spells?

	#define OP_MemorizeSpell	0x00bf	// Memming a spell from book to spell slot
	#define OP_BeginCast		0x0019
	#define OP_HPUpdate			0x022d	// Update HP % of a PC or NPC
		#define OP_Mend				0x007c

	#define OP_PetitionRefresh	0x0082
	#define OP_GMFind			0x0044	// GM /find			- ?
	#define OP_GMServers		0x0018	// GM /servers		- ?
	#define OP_GMGoto			0x0104	// GM /goto			- Transport to another loc
	#define OP_GMSummon			0x0279	// GM /summon		- Summon PC to self
	#define	OP_GMKick			0x0103	// GM /kick			- Boot player
	#define OP_GMKill			0x0102	// GM /kill			- Insta kill mob/pc
	#define OP_GMLastName		0x00a0	// GM /lastname		- Change user lastname
	#define OP_GMToggle			0x01b1	// GM /toggle		- Toggle ability to receive tells from other PC's
	#define OP_GMEmoteZone		0x01b5	// GM /emotezone	- Send zonewide emote
	#define OP_GMBecomeNPC		0x0071	// GM /becomenpc	- Become an NPC
				// (TODO: Figure out 0x0122, which is also sent with OP_GMBecomeNPC
	#define OP_GMApproval		0x01ae	// GM /approval		- Name approval duty?
	#define OP_NameApproval		0x011f //Name approval
	#define OP_GMSearchCorpse	0x0094	// GM /searchcorpse	- Search all zones for named corpse
	#define OP_GMHideMe			0x00d6	// GM /hideme		- Remove self from spawn lists and make invis
	#define OP_GMInquire		0x00d2	// GM /inquire		- Search soulmark data
	#define	OP_GMSoulmark		0x00d4	// GM /praise /warn	- Add soulmark comment to user file
	#define OP_GMZoneRequest	0x017c	// GM /zone			- Transport to another zone
		#define OP_GMZoneRequest2	0x0222	// GM /zone 2
		#define OP_PetitionUpdate	0x0065	// Updates the Petitions in the Que
		#define OP_PetitionCheckout	0x0072	// Petition Checkout
		#define OP_PetitionDelete	0x008d	// Client Petition Delete Request
		#define OP_PetitionResolve	0x0291	// Client Petition Resolve Request
		#define OP_PetitionCheckIn	0x0070	// Petition Checkin

		#define OP_EnvDamage		0x00e1	// 0.5.0-dr2: 0x00ec (changed to 0x0006 due to conflict)
		#define OP_ConfirmDelete	0x016f	//Client sends this to server to confirm op_deletespawn
	#define OP_Damage			0x00db // TODO: this
	#define OP_Action			0x00fa
	#define OP_NewSpawn			0x0201	// New NPC or PC entering zone
	#define OP_Animation		0x0134  // Might be incorrect still 
	#define OP_MobHealth		0x0217	// health sent when a player clicks on the mob
	#define OP_ZoneChange		0x0136	// Client requesting transfer to a different zone
		#define OP_DeleteSpawn		0x00ec	// Remove a spawn from the current zone
		#define OP_NewCorpse		0x0115
	#define OP_CrashDump		0x0265
		#define OP_CastOn			0x0110
	#define OP_CastBuff			0x00db
	#define OP_ManaChange		0x00bc
		#define OP_ClientError		0x0294
	#define OP_LoadSpellSet		0x02bb
	#define OP_Save				0x00f4	// Client asking server to save user state
	#define OP_Surname			0x0180
	#define OP_SwapSpell		0x018f	// Swapping spell positions within book
	#define OP_ShopItem			0x02c5	// Send merchant item data to client (header = 0x64)

	#define OP_CloseContainer	0x0286	// 10-10-2003	Client closing world container (i.e., forge)
	#define OP_ClickObjectAck	0x0286	// 10-10-2003	Client closing world container (i.e., forge)
	#define OP_CreateObject		0x00f3	// 10-10-2003	Zone objects (pok books, objects on ground, etc)
	#define	OP_ClickObject		0x00f2	// 10-10-2003	Client clicking on object
	#define OP_GuildMOTD		0x01c3	// /guildmotd
		#define OP_GuildManagement	0x005a	// LoY guild mgm't tool
	#define OP_ZoneUnavail		0x024e

	#define OP_ItemPacket		0x02c5	// Variety of ways for sending out item data
	#define OP_MoveItem		0x014a	// Client moving an item from one slot to another (user action)
	//0x0283 hmm
	#define OP_TradeRequest		0x0281	// Client request trade session
	#define OP_TradeRequestAck	0x0034	// Trade request recipient is acknowledging they are able to trade
	#define OP_TradeAcceptClick	0x002a
		#define OP_ItemToTrade		0x002d
	#define OP_TradeCoins		0x0033
	#define OP_CancelTrade		0x002b
	#define OP_FinishTrade		0x002c
	#define OP_ItemTextFile		0x027e	// Used to request textual file data and used on response
	#define OP_Translocate		0x01C6

	#define OP_SaveOnZoneReq    0x009e
	#define OP_Logout           0x0163  // Last opcode seny by server when you zone or camp

//////////////////////////////////////
// Zone.exe opcodes for login sequence:
//////////////////////////////////////
	#define OP_SetDataRate		0x0198	// Client sending datarate.txt value
	#define OP_ZoneEntry		0x0224	// Info about char entering zone..
	#define OP_PlayerProfile	0x0068	// Basic player info (no inventory)
	#define OP_CharInventory	0x01b7	// Full inventory of player
	#define OP_ZoneSpawns		0x0169	// All spawns in current zone
	#define	OP_TimeOfDay		0x0023	// Notify client of current time
	#define OP_Weather			0x0154	// Weather update
	#define OP_ReqNewZone		0x00e5	// Client requesting NewZone_Struct
	#define OP_NewZone			0x00e4	// Info about zone being loaded (exp multiplier, etc)
	#define OP_ReqClientSpawn	0x00f6	// Client requesting spawn data
	#define OP_SpawnAppearance	0x013a	// Sets spawnid/animation/equipment
	#define OP_ReqZoneObjects	0x01bf	// Client requesting zone objects
	#define OP_ClientReady		0x0082	// Client fully connected, finished loading

//////////////////////////////////////
// World.exe opcodes:
//////////////////////////////////////
	#define OP_AckPacket			0x000f	// Appears to be generic ack at the presentation level
	#define OP_ApproveWorld			0x0195
	#define OP_LogServer			0x017f
	#define OP_MOTD					0x01b0	// Server message of the day
	#define OP_SendLoginInfo		0x023a
		#define OP_DeleteCharacter		0x00e3	// Delete character @ char select
	#define OP_SendCharInfo			0x00fb	// Send all chars visible @ char select
	#define OP_ExpansionInfo		0x00da	// Which expansions user has
		#define OP_CharacterCreate		0x00fd	// Create character @ char select
	#define OP_RandomNameGenerator	0x0292	// Returns a random name
	#define OP_GuildsList			0x005a	// Server sending client list of guilds
	#define OP_ApproveName			0x011e	// Approving new character name @ char creation
	#define OP_EnterWorld			0x024a	// Server approval for client to enter world
	#define OP_World_Client_CRC1	0x0153	// Contains a snippet of spell data
	#define OP_World_Client_CRC2	0x0157	// Second client verification packet
	#define OP_SetChatServer		0x0252	// Chatserver? IP,Port,servername.Charname,password(?)
	#define OP_ZoneServerInfo		0x024d	// Zone server? IP,0's,int16?
		#define OP_UserCompInfo		0x029c	// User submitting computer information
	#define OP_GetName				0x0292
	#define OP_DeleteSpell			0x01e0

//////////////////////////////////////
// Zone.exe/World.exe shared opcodes:
//////////////////////////////////////
	#define OP_WearChange		0x0125	// Client texture/color update


////////////////////////////
// OLD opcodes:
////////////////////////////


	#define	OP_RequestDuel		0xcf40
	#define OP_DuelResponse		0xd040
	#define OP_DuelResponse2	0x5d41

	#define OP_GuildInviteAccept 0x1841

	#define OP_GuildWar			0x6f41 // /guildwar
	#define OP_GuildInvite		0x1741 // /guildinvite

	#define OP_GuildUpdate		0x7b41
	#define OP_MultiLineMsg		0x1440
	#define OP_GMNameChange		0xcb40 // /name

	#define OP_SummonedItem		0x7841

	#define OP_InterruptCast	0x3542
	#define OP_HarmTouch		0x7E41
	#define OP_InstillDoubt		0x9c41
	#define OP_WebUpdate		0x3c42
	#define OP_Taunt			0x3b41
	#define OP_ControlBoat		0x2641
	#define OP_Drink			0x4641
	#define OP_SafeFallSuccess	0xab41

	

	#define OP_SetServerFilter	0xff41
	#define OP_SetServerFilterAck 0xc341


	
	#define OP_Medding			0x5841
	#define OP_Charm			0x4442

	#define PET_BACKOFF			1
	#define PET_GETLOST			2
	#define PET_HEALTHREPORT	4
	#define PET_GUARDHERE		5
	#define PET_GUARDME			6
	#define PET_ATTACK			7
	#define PET_FOLLOWME		8
	#define PET_SITDOWN			9
	#define PET_STANDUP			10
	#define PET_TAUNT			11
	#define PET_LEADER			16


// Agz: The following is from the old source I used as base
/************ ENUMERATED PACKET OPCODES ************/
	#define ALL_FINISH                  0x0005
	#define LS_REQUEST_VERSION          0x0059
	#define LS_SEND_VERSION             0x0059
	#define LS_SEND_LOGIN_INFO          0x0001
	#define LS_SEND_SESSION_ID          0x0004
	#define LS_REQUEST_UPDATE           0x0052
	#define LS_SEND_UPDATE              0x0052

	#define LS_REQUEST_SERVERLIST       0x0046
	#define LS_SEND_SERVERLIST          0x0046

	#define LS_REQUEST_SERVERSTATUS     0x0048
	#define LS_SEND_SERVERSTATUS        0x004A
	#define LS_GET_WORLDID              0x0047
	#define LS_SEND_WORLDID             0x0047
	#define WS_SEND_LOGIN_INFO          0x5818
	#define WS_SEND_LOGIN_APPROVED      0x0710
	#define WS_SEND_LOGIN_APPROVED2     0x0180
	#define WS_SEND_CHAR_INFO           0x4720
#endif
