#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>

#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <errno.h>
	#include <stdlib.h>
	#include <pthread.h>

	#include "../common/unix.h"

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1

	extern int errno;
#endif

#include "zoneserver.h"
#include "../common/database.h"
#include "../common/seperator.h"
#include "LoginServer.h"
//#include "../common/serverinfo.h"
#include "status.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

extern Database database;
extern ZSList	zoneserver_list;
extern volatile bool RunLoops;
extern uint32	numzones;
extern LoginServer* loginserver;
volatile bool StatusLoopRunning = false;
Stats stats;

bool Stats::ReadINI() {
	char buf[201], type[201];
	int items[2] = {0, 0};
	FILE *f;

	if (!(f = fopen ("stats.ini", "r"))) {
		printf ("Couldn't open the stats.ini file.\n");
		return false;
	}
	do {
		fgets (buf, 200, f);
		if (feof (f))
		{
			printf ("[Statu] block not found in status.ini.\n");
			fclose (f);
			return false;
		}
	}
	while (strncasecmp (buf, "[stats]\n", 14) != 0 && strncasecmp (buf, "[stats]\r\n", 15) != 0);

	while (!feof (f))
	{
#ifdef WIN32
		if (fscanf (f, "%[^=]=%[^\n]\r\n", type, buf) == 2)
#else
		if (fscanf (f, "%[^=]=%[^\r\n]\n", type, buf) == 2)
#endif
		{
			if (!strncasecmp (type, "interval", 9)) {
				interval = atoi(buf);
				items[0] = 1;
			}
			if (!strncasecmp (type, "fileout", 7)) {
				strncpy (fileout, buf, 200);
				items[1] = 1;
			}
		}
	}

	if (!items[0] || !items[1])
	{
		cout << "Incomplete stats.ini file." << endl;
		fclose (f);
		return false;
	}

	fclose (f);
	loaded = true;
	cout << "stats.ini read." << endl;
	return true;
}
void Stats::WriteXML() {


}

#ifdef WIN32
void StatusLoop(void *tmp) {
#else
void *StatusLoop(void *tmp) {
#endif
	StatusLoopRunning = true;
	while(RunLoops) {
		cout << "Creating XML File: " << fileout << endl;
		stats.WriteXML();
		Sleep(interval*1000);
	}
	StatusLoopRunning = false;
}
