#ifndef EQFRAGMENT_H
#define EQFRAGMENT_H

#include "types.h"
#include "linked_list.h"

/*	Replacement code for FRAGMENT and FRAGMENT_GROUP 
	not for speed, for functionality and readability */

class Fragment
{
public:
	Fragment();
	~Fragment();

	void   SetData(uchar* d, int32 s);

	uchar* GetData() { return data; }
	int32  GetSize() { return size; }

private:
	uchar*	data;
	int32	size;
};

class FragmentGroup
{
public:
	FragmentGroup(int16 seq, int16 opcode, int16 num_fragments);
	~FragmentGroup();

	void Add(int16 frag_id, uchar* data, int32 size);
	uchar* AssembleData(int32* size);

	int16 GetSeq()               { return seq; }
	int16 GetOpcode()            { return opcode; }

private:
	int16 seq;        //Sequence number
	int16 opcode;     //Fragment group's opcode
	int16 num_fragments;
	Fragment* fragment;
};

class FragmentGroupList
{
public:
	void Add(FragmentGroup* add_group);
	FragmentGroup* Get(int16 find_seq);
	void Remove(int16 remove_seq);

private:
	LinkedList<FragmentGroup*> fragment_group_list;
};

#endif
