#include "object.h"
#include "entity.h"
#include "client.h"
#include "../common/database.h"
#include "../common/packet_functions.h"

extern Database database;
extern EntityList entity_list;

Object::Object(int16 type,int16 ItemID,float YPos,float XPos, float ZPos, int8 Heading, char ObjectName[6],int8 Charges) {
	itemid = ItemID;
	charges = Charges;
	dropid = 0;
	ypos = YPos;
	xpos = XPos;
	zpos = ZPos;
	heading = Heading;
	memcpy(objectname,ObjectName,16);
	objecttype = type;
	memset(bagitems,0,sizeof(bagitems));
	memset(bagcharges,0,sizeof(bagcharges));
}

Object::~Object() {}

void Object::CreateSpawnPacket(APPLAYER* app){
	
	app->opcode = OP_CreateObject;
	app->pBuffer = new uchar[sizeof(Object_Struct)];
	memset(app->pBuffer,0,sizeof(Object_Struct));
	app->size = sizeof(Object_Struct);	
	Object_Struct* co = (Object_Struct*) app->pBuffer;		
	co->dropid = this->GetID();
	co->xpos = this->xpos;
	co->ypos = this->ypos;
	co->zpos = this->zpos;
	co->itemid = this->itemid;
	memcpy(co->objectname,this->objectname,16);
	co->heading = this->heading;
}
void Object::CreateDeSpawnPacket(APPLAYER* app){	
	app->opcode = OP_ClickObject;
	app->pBuffer = new uchar[sizeof(ClickObject_Struct)];
	app->size = sizeof(ClickObject_Struct);	
	ClickObject_Struct* co = (ClickObject_Struct*) app->pBuffer;		
	co->objectID = GetID();
	co->PlayerID = 0;
	co->unknown = 0;
}

bool Object::HandleClick(Client* sender,APPLAYER* app){
	int i;
	switch(objecttype)
	{
	case OT_DROPPEDITEM:
		cout << "itemid " << itemid << endl;
		sender->SummonItem(this->itemid,charges);
		entity_list.QueueClients(0,app,false);

		for (i = 0;i != 10;i++){
			if (this->bagitems[i] != 0){
				sender->AddToCursorBag(this->bagitems[i],i,bagcharges[i]); // new code in OP_Moveto will update client			
				cout << "charges : " << (int16)bagcharges[i] <<endl;
			}
		}
		entity_list.RemoveEntity(this->GetID());
		return true;
				
	default:
		return false;
		
	}
}
