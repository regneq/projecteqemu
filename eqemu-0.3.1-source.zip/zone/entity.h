#ifndef ENTITY_H
#define ENTITY_H

#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/database.h"
#include "zonedump.h"

#ifdef WIN32
	class	APPLAYER;
#else
	struct	APPLAYER;
#endif

class Client;
class Mob;
class NPC;
class Corpse;
class Petition;
class Object;
class Group;

void ProcessClientThreadSpawn(void *tmp);

class Entity
{
public:
	Entity();
	virtual ~Entity();

	virtual bool IsClient()			{ return false; }
	virtual bool IsNPC()			{ return false; }
	virtual bool IsMob()			{ return false; }
	virtual bool IsCorpse()			{ return false; }
	virtual bool IsPlayerCorpse()	{ return false; }
	virtual bool IsNPCCorpse()		{ return false; }
	virtual bool IsObject()			{ return false; }
	virtual bool IsGroup()			{ return false; }

	virtual bool Process()  { return false; }
	virtual bool Save() { return true; }
	virtual void Depop(bool StartSpawnTimer = true) {}

	Client* CastToClient();
	NPC*    CastToNPC();
	Mob*    CastToMob();
	Corpse*	CastToCorpse();
	Object* CastToObject();
	Group*	CastToGroup();

	inline int16 GetID()	{ return id; }
	virtual char* GetName() { return ""; }
protected:
	friend class EntityList;
	void SetID(int16 set_id);
private:
	int16 id;
};

class EntityList
{
public:
	EntityList() { last_insert_id = 0; }
	~EntityList() {}

	Entity* GetID(int16 id);
	Mob*	GetMob(int16 id);
	Mob*	GetMob(char* name);
	Client* GetClientByName(char *name); 
	Client* GetClientByAccID(int32 accid);
	Client* GetClient(int32 ip, int16 port);
	Group*	GetGroupByClient(Client* client);
	void ClearClientPetitionQueue();

	void    AddClient(Client*);
	void    AddNPC(NPC*, bool SendSpawnPacket = true);
	void	AddCorpse(Corpse* pc, int32 in_id = 0xFFFFFFFF);
	void    AddObject(Object*, bool SendSpawnPacket = true);
	void    AddGroup(Group*);
	void	Clear();

	void	Message(int32 to_guilddbid, int32 type, char* message, ...);
	void	MessageClose(Mob* sender, bool skipsender, float dist, int32 type, char* message, ...);
	void	ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...);
	void    ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...);
	void	ChannelMessageSend(Mob* to, int8 chan_num, int8 language, char* message, ...);
	void    SendZoneSpawns(Client*);
	void	SendZoneSpawnsBulk(Client* client);
	void    Save();
	void    SendZoneObjects(Client* client);

	void    RemoveFromTargets(Mob* mob);

	void	QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender=false, float dist=200, Mob* SkipThisMob = 0);
	void    QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender=false);
	void	QueueClientsStatus(Mob* sender, APPLAYER* app, bool ignore_sender = false, int8 minstatus = 0, int8 maxstatus = 0);

	void	AESpell(Mob* caster, Mob* center, float dist, int16 spell_id);

	void	UpdateWho();
	void	SendPositionUpdates(Client* client, int32 cLastUpdate = 0, float range = 0, Entity* alwayssend = 0);
	char*	MakeNameUnique(char* name);
	static char*	RemoveNumbers(char* name);

	void	CountNPC(int32* NPCCount, int32* NPCLootCount, int32* gmspawntype_count);
	void	DoZoneDump(ZSDump_Spawn2* spawn2dump, ZSDump_NPC* npcdump, ZSDump_NPC_Loot* npclootdump, NPCType* gmspawntype_dump);
	void    RemoveEntity(int16 id);
	void	SendPetitionToAdmins(Petition* pet);

	void	ListNPCs(Client* client,char* arg1,char* arg2,int isnumber);
	void	ListNPCCorpses(Client* client);
	void	ListPlayerCorpses(Client* client);
	sint32	DeleteNPCCorpses();
	sint32	DeletePlayerCorpses();
	void	WriteEntityIDs();

	bool	AddHateToCloseMobs(NPC* sender, float dist, int social);

    void    Process();

	void	DepopCorpses();

protected:
	friend class Zone;
	void	Depop();
private:
	int16   GetFreeID();


	LinkedList<Entity*> list;
	int16 last_insert_id;
};

#endif

