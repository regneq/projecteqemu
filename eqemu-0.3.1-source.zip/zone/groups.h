#ifndef GROUPS_H
#define GROUPS_H

#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "entity.h"
#include "client.h"

class Group: public Entity
{
public:
	Group::~Group() {}
	Group::Group(Client* leader);
	bool	AddMember(Client* newmember);
	bool	DelMember(Client* oldmember,bool ignoresender = false);
	void	DisbandGroup();
	bool	IsGroupMember(Client* client);
	bool	Process()			{ return true; }
	bool	IsGroup()			{ return true; }
	void	CastGroupSpell(Client* caster,uint16 spellid);
	void	SplitExp(uint32 exp);
	void	GroupMessage(Client* sender,char* message);
private:
Client* members[5];

};

#endif