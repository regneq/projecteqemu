#include "../common/debug.h"
#include "spawngroup.h"
#include <string.h>
#include <stdlib.h>
#include <iostream.h>

SpawnEntry::SpawnEntry( int in_NPCType, int in_chance ) 
{
	NPCType = in_NPCType;
	chance = in_chance;
}

SpawnGroup::SpawnGroup( int in_id, char name[30] )
{
	id = in_id;
	strcpy( name_, name );
}

int SpawnGroup::GetNPCType()
{
	int npcType = -1;
	int totalchance = 0;

	LinkedListIterator<SpawnEntry*> iterator(list_);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		totalchance += iterator.GetData()->chance;
		iterator.Advance();
	}

	int roll = (rand()%totalchance);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (roll < iterator.GetData()->chance)
		{
			npcType = iterator.GetData()->NPCType;
			break;
		}
		else
		{
			roll = roll - iterator.GetData()->chance;
		}
		iterator.Advance();
	}
	//CODER  implement random table
	return npcType;
}

void SpawnGroup::AddSpawnEntry( SpawnEntry* newEntry )
{
	list_.Insert( newEntry );
}

void SpawnGroupList::AddSpawnGroup(SpawnGroup* newGroup)
{
	list_.Insert(newGroup);
}

SpawnGroup* SpawnGroupList::GetSpawnGroup(int in_id)
{
	LinkedListIterator<SpawnGroup*> iterator(list_);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->id == in_id)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
    return 0;  // shouldn't happen, but need to handle it anyway
}
