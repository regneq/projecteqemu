#ifndef CLIENT_H
#define CLIENT_H

#include "../common/EQPacketManager.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "zoneserver.h"

#define CLIENT_TIMEOUT 30000

class Client
{
public:
	Client(int32 ip, int16 port, int send_socket);
    ~Client();
	
	bool	Process();
	void	ReceiveData(uchar* buf, int len);
	void	SendCharInfo();
	void	EnterWorld(bool TryBootup = true);
	void	ZoneUnavail();
	void	QueuePacket(APPLAYER* app, bool ack_req = true);

	int32	GetIP()			{ return ip; }
	int16	GetPort()		{ return port; }
	char*	GetZoneName()	{ return zone_name; }
	int		GetAdmin()		{ return admin; }
	bool	WaitingForBootup()	{ return pwaitingforbootup; }
private:
	int32	ip;
	int16	port;
	int		send_socket;
	int32	account_id;
	char	char_name[30];
	char	zone_name[16];
	Timer*	timeout_timer;
	Timer*	autobootup_timeout;
	int32	pwaitingforbootup;
	int admin;

	MySendPacketStruct*	PMSendQueuePop();
	APPLAYER*			PMOutQueuePop();
	CEQPacketManager	packet_manager;	
	Mutex				MPacketManager;
};

class ClientList
{
public:
	ClientList();
	~ClientList();
	
	void	Add(Client* client);
	Client*	Get(int32 ip, int16 port);
	void	Process();

	void	ZoneBootup(ZoneServer* zs);
private:
	LinkedList<Client*> list;
};

#endif
