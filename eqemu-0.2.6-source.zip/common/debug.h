#ifdef _DEBUG
	#ifndef _CRTDBG_MAP_ALLOC
		#define _CRTDBG_MAP_ALLOC
		#include <stdlib.h>
		#include <crtdbg.h>
		#define new \
        new(_NORMAL_BLOCK, __FILE__, __LINE__) 
	#endif
#endif

#define CURRENT_CHAT_VERSION	"EqEmu 0.2.6 Chat Server - Mickey Mouse"
#define CURRENT_ZONE_VERSION	"EqEmu 0.2.6 Zoneserver - Mickey Mouse"
#define CURRENT_WORLD_VERSION   "EqEmu 0.2.6 Worldserver - Mickey Mouse"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
#define LAST_MODIFIED	__TIME__
#else
#define LAST_MODIFIED	__TIMESTAMP__
#endif
