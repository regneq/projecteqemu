#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#include <process.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include "../common/unix.h"
#endif

#include "client.h"
#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "../common/database.h"
#include "spdat.h"
#include "ClientList.h"
#include "../common/packet_functions.h"
#include "PlayerCorpse.h"
#include "petitions.h"
#include "../common/serverinfo.h"

extern Database database;
extern EntityList entity_list;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern GuildRanks_Struct guilds[512];
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern ClientList client_list;
extern int32 numclients;
extern PetitionList petition_list;

Client::Client(int32 in_ip, int16 in_port, int in_send_socket)
: Mob("No name",	// name
	  "",	// lastname
	  0,	// curhp
	  0,	// maxhp
	  0,	// gender
	  0,	// race
	  0,	// class
	  0,	// deity
	  0,	// level
	  0,	// npctypeid
	  0,	// skills
	  0,	// size
	  0.46,	// walkspeed
	  0.7,	// runspeed
	  0,	// heading
	  0,	// x
	  0,	// y
	  0,	// z
	  0,	// light
	  0,	// equip
	  0xFF,	// texture
	  0xFF,	// helmtexture
	  0,	// ac
	  0,	// atk
	  0,	// str
	  0,	// sta
	  0,	// dex
	  0,	// agi
	  0,	// int
	  0,	// wis
	  0,	// cha
	  0xff,	// Luclin Hair Colour
	  0xff,	// Luclin Beard
	  0xff,	// Luclin Eye1
	  0xff,	// Luclin Eye2
	  0xff,	// Luclin Hair Style
	  0xff,	// Luclin Wode
	  0xff )	// Luclin Face
{
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	client_state = CLIENT_CONNECTING1;
	timeout_timer = new Timer(CLIENT_TIMEOUT);
	timeout_timer->Start();
	account_id = 0;
	admin = 0;
	strcpy(account_name, "");
	packet_manager.SetDebugLevel(0);
	tellsoff = false;
	gmhideme = false;
	LFG = false;

	target = 0;
	auto_attack = false;
	PendingGuildInvite = 0;
	zonesummon_x = -2;
	zonesummon_y = -2;
	zonesummon_z = -2;
	zonesummon_ignorerestrictions = false;
	casting_spell_id = 0;

	position_timer = new Timer(500);
	position_timer->Disable();
	position_timer_counter = 0;
	pLastUpdate = 0;
	// Kaiyodo - initialise haste variable
	HastePercentage = 0;
}

Client::~Client()
{
	client_list.Remove(this);
	UpdateWho(true);
	Save(); // This fails when database destructor is called first on shutdown
	delete timeout_timer;
	delete position_timer;

	// is this needed? Im not sure but it better have it in than not - Merkur
	LinkedListIterator<FactionValue*> iterator(factionvalue_list);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent(false);
	}
}

bool Client::Save()
{
	if (Connected()) {
		pp.x = x_pos;
		pp.y = y_pos;
		pp.z = z_pos;
		pp.heading = heading;
		if (GetHP() <= 0) {
			if (GetMaxHP() > 30000)
				pp.cur_hp = 30000;
			else
				pp.cur_hp = GetMaxHP();
		}
		else if (GetHP() > 30000)
			pp.cur_hp = 30000;
		else
			pp.cur_hp = GetHP();
		pp.mana = cur_mana;

		for (int i=0; i<15; i++) {
			if (buffs[i].spellid <= SPDAT_RECORDS) {
				pp.buffs[i].spellid = buffs[i].spellid;
				pp.buffs[i].duration = buffs[i].ticsremaining;
				pp.buffs[i].level = buffs[i].casterlevel;
			}
			else {
				pp.buffs[i].spellid = 0xFFFF;
				pp.buffs[i].duration = 0;
				pp.buffs[i].level = 0;
			}
		}
 		if (!database.SetPlayerProfile(account_id, name, &pp)) {
			cerr << "Failed to update player profile" << endl;
			return false;
		}
	}
	return true;
}

void Client::SendPacketQueue(bool Block) {
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
	sockaddr_in to;	
	memset((char *) &to, 0, sizeof(to));
	to.sin_family = AF_INET;
	to.sin_port = port;
	to.sin_addr.s_addr = ip;
	if (Block) {
		MPacketManager.lock();
	}
	else if (!MPacketManager.trylock()) {
		return;
	}

	while(p = packet_manager.SendQueue.pop())
	{
		#ifdef WIN32
			sendto(send_socket, (char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif

		safe_delete(p->buffer);
		delete[] p;
	}
	/************ Processing finished ************/

	if (!packet_manager.CheckActive())
	{
		cout << "Client disconnected (!pm.CA): " << GetName() << endl;
		Save();
		client_state = DISCONNECTED;
//		return false;
	}

	packet_manager.CheckTimers();
	MPacketManager.unlock();
}

APPLAYER* Client::PMOutQueuePop() {
	APPLAYER* tmp;
	MPacketManager.lock();
	tmp = packet_manager.OutQueue.pop();
	MPacketManager.unlock();
	return tmp;
}

void Client::PMClose() {
	MPacketManager.lock();
	packet_manager.Close();
	MPacketManager.unlock();
}

void Client::QueuePacket(APPLAYER* app, bool ack_req) 
{	
	while(packet_manager.IsTooMuchPending() && (client_state != DISCONNECTED)){ // Merkur experimental testcode
		MPacketManager.lock();				// will this slow down the whole zone if someone has lag? it should and seems not, but it needs to be tested out :)
		packet_manager.CheckTimers();
		MPacketManager.unlock();
		Sleep(5); 
	}
		

	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size >= 31500) {
			cout << "WARNING: abnormal packet size. n='" << this->GetName() << "', o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	MPacketManager.lock();
	packet_manager.MakeEQPacket(app, ack_req);
	MPacketManager.unlock();
}

void Client::ReceiveData(uchar* buf, int len)
{
	timeout_timer->Start();
	MPacketManager.lock();
	packet_manager.ParceEQPacket(len, buf);
	MPacketManager.unlock();
}

void Client::ChannelMessageReceived(int8 chan_num, int8 language, char* message, char* targetname) 
{
//	cout << "Channel:" << (int)chan_num << " " << message << endl;

	if (message[0] == '#' && chan_num == 8) // Quagmire, changed commands to /say only
	{
		Seperator sep(message);
//		char* arg1 = strchr(message, ' ');

		if ((strcasecmp(sep.arg[0], "#level") == 0) && (admin >= 10))
		{
			if (target == 0 && admin >= 100) {
				Message(0, "Error: #Level: No target");
			}
			else if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #level x");
			}
			else {
				int16 level = atoi(sep.arg[1]);
				if (level > 0 && (level <= 61 || (level <= 100 && admin >= 100))) {
					if (admin >= 100)
						target->SetLevel(level);
					else
						this->SetLevel(level);
				}
				else {
					Message(0, "Error: #Level: Invalid Level");
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#damage") == 0 && (admin >= 100)) {
			if (target==0) {
				Message(0, "Error: #Damage: No Target.");
			}
			else if (!sep.IsNumber(1)) {
				Message(0, "Usage: #damage x.");		
			}
			else {
				sint32 nkdmg = atoi(sep.arg[1]);
				if (nkdmg > 2100000000)
					Message(0, "Enter a value less then 2,100,000,000.");
				else
					target->Damage(this, nkdmg, 0xffff);
			}
		}
		else if (strcasecmp(sep.arg[0], "#heal") == 0 && (admin >= 10)) {
			if (target==0) {
				Message(0, "Error: #Heal: No Target.");
			} else {
				target->Heal();
			}
		}
		else if (strcasecmp(sep.arg[0], "#kill") == 0 && (admin >= 20)) {
			if (target==0) {
				Message(0, "Error: #Kill: No target.");
			} else {
				if ((!target->IsClient()) || target->CastToClient()->Admin() <= this->Admin())
					target->Kill();
			}
		}
		else if(strncasecmp(message,"#timeofday",9) == 0 && admin >= 80) { // image
 			if (!sep.IsNumber(1) || atoi(sep.arg[1]) <= 0 || atoi(sep.arg[1]) >= 25) {
 				Message(0, "Usage: #timeofday <hour>");
 			}
 			else {
 					APPLAYER* outapp = new APPLAYER;
 					outapp = new APPLAYER;
 					outapp->opcode = OP_TimeOfDay;
					outapp->size = sizeof(TimeOfDay_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					memset(outapp->pBuffer, 0, outapp->size);
					TimeOfDay_Struct* tod = (TimeOfDay_Struct*)outapp->pBuffer;
					tod->hour = atoi(sep.arg[1]);
					//TODO: Make this set itself to worldtime.
					tod->minute = 0;
					tod->dayofmonth = 1;
					tod->month = 1;
					tod->year = 1;
 					entity_list.QueueClients(this, outapp);
 					delete outapp;
 			}
 		} //This needs to be added to the database so it updates on login
		else if (strcasecmp(sep.arg[0], "#date")==0 && admin >= 80) {
 			if(sep.arg[5][0] == 0) {
 				Message(0, "Usage: #date <hour (24 hour format)> <minute> <day of month> <month> <year>");
 			}
 			else {
 					APPLAYER* outapp = new APPLAYER;
 					outapp = new APPLAYER;
 					outapp->opcode = OP_TimeOfDay;
					outapp->size = sizeof(TimeOfDay_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					TimeOfDay_Struct* tod = (TimeOfDay_Struct*)outapp->pBuffer;
					tod->hour=atoi(sep.arg[1]);
					tod->minute=atoi(sep.arg[2]);
					tod->dayofmonth=atoi(sep.arg[3]);
					tod->month=atoi(sep.arg[4]);
					tod->year=atoi(sep.arg[5]);
 					entity_list.QueueClients(this, outapp);
 					delete outapp;
 			}
		}
		// Kaiyodo - #haste command to set client attack speed. Takes a percentage (100 = twice normal attack speed)
		else if (strcasecmp(sep.arg[0], "#haste")==0 && admin >= 100)
		{
			if(sep.arg[1][0] != 0)
			{
				int16 Haste = atoi(sep.arg[1]);
				SetHaste(Haste);
				// SetAttackTimer must be called to make this take effect, so player needs to change
				// the primary weapon.
				Message(0, "Haste set to %d%% - Need to re-equip primary weapon before it takes effect", Haste);
			}
			else
			{
				Message(0, "Usage: #haste x");
			}
		}
		else if(strcasecmp(sep.arg[0],"#weather") == 0 && (admin >= 80)) {
			if (!(sep.arg[1][0] == '0' || sep.arg[1][0] == '1' || sep.arg[1][0] == '2' || sep.arg[1][0] == '3')) {
				Message(0, "Usage: #weather <0/1/2/3> - Off/Rain/Snow/Manual.");
			}
			else if(zone->zone_weather == 0) { 
				if(sep.arg[1][0] == '3')	{ // Put in modifications here because it had a very good chance at screwing up the client's weather system if rain was sent during snow -T7
					if(sep.arg[2][0] != 0 && sep.arg[3][0] != 0) { 
						Message(0, "Sending weather packet... TYPE=%s, INTENSITY=%s", sep.arg[2], sep.arg[3]);
						zone->zone_weather = atoi(sep.arg[2]);
						APPLAYER* outapp = new APPLAYER;
						outapp = new APPLAYER;
						outapp->opcode = OP_Weather;
						outapp->pBuffer = new uchar[8];
						memset(outapp->pBuffer, 0, 8);
			   			outapp->size = 8;
						outapp->pBuffer[0] = atoi(sep.arg[2]);
						outapp->pBuffer[4] = atoi(sep.arg[3]); // This number changes in the packets, intensity?
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
					else {
						Message(0, "Manual Usage: #weather 3 <type> <intensity>");
					}
				}
				else if(sep.arg[1][0] == '2')	{
					entity_list.Message(0, 0, "Snowflakes begin to fall from the sky.");
					zone->zone_weather = 2;
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = OP_Weather;
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[0] = 0x01;
					outapp->pBuffer[4] = 0x02; // This number changes in the packets, intensity?
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
				else if(sep.arg[1][0] == '1')	{
					entity_list.Message(0, 0, "Raindrops begin to fall from the sky.");
					zone->zone_weather = 1;
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = OP_Weather;
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[4] = 0x01; // This is how it's done in Fear, and you can see a decent distance with it at this value
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
			else	{
				if(zone->zone_weather == 1)	{ // Doing this because if you have rain/snow on, you can only turn one off.
					entity_list.Message(0, 0, "The sky clears as the rain ceases to fall.");
					zone->zone_weather = 0;
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = OP_Weather;  
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8; // To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
				else if(zone->zone_weather == 2)	{
					entity_list.Message(0, 0, "The sky clears as the snow stops falling.");
					zone->zone_weather = 0;
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = OP_Weather;  
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8; // To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
					outapp->pBuffer[0] = 0x01; // Snow has it's own shutoff packet
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
				else {
					entity_list.Message(0, 0, "The sky clears.");
					zone->zone_weather = 0;
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = OP_Weather;  
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8; // To shutoff weather you send an empty 8 byte packet (You get this everytime you zone even if the sky is clear)
					entity_list.QueueClients(this, outapp);
					delete outapp;
				}
			}
		}		
		else if (strcasecmp(sep.arg[0], "#version") == 0)
		{
			Message(0, "Current version information.");
			Message(0, "  %s", CURRENT_ZONE_VERSION);
			Message(0, "  Compiled on: %s at %s", COMPILE_DATE, COMPILE_TIME);
			Message(0, "  Last modified on: %s", LAST_MODIFIED);
		}
		else if (strcasecmp(sep.arg[0], "#serverinfo") == 0 && admin >= 201) {
			if (strcasecmp(sep.arg[1], "os") == 0 && admin >=201) {
				#ifdef WIN32
					GetOS();
					char intbuffer [sizeof(unsigned long)];
					Message(0, "Operating system information.");
					Message(0, "  %s", Ver_name);
					Message(0, "  Build number: %s", ultoa(Ver_build, intbuffer, 10));
					Message(0, "  Minor version: %s", ultoa(Ver_min, intbuffer, 10));
					Message(0, "  Major version: %s", ultoa(Ver_maj, intbuffer, 10));
					Message(0, "  Platform Id: %s", ultoa(Ver_pid, intbuffer, 10));
				#else
					char os_string[100];
					Message(0, "Operating system information.");
					Message(0, "  %s", GetOS(os_string));
				#endif
			}
			else {
				Message(0, "Usage: #serverinfo <type>");
				Message(0, "  OS - Operating system information.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#shutdown")==0 && admin >= 200)
		{
			CatchSignal(2);
		}
		else if (strcasecmp(sep.arg[0], "#help") == 0) {
			if (!(strcasecmp(sep.arg[1], "normal") == 0 
				|| strcasecmp(sep.arg[1], "privuser") == 0
				|| strcasecmp(sep.arg[1], "vprivuser")== 0 
				|| strcasecmp(sep.arg[1], "gmquest")== 0
				|| strcasecmp(sep.arg[1], "gm")== 0
				|| strcasecmp(sep.arg[1], "leadgm")== 0
				|| strcasecmp(sep.arg[1], "debug")== 0
				|| strcasecmp(sep.arg[1], "serverop")== 0)) {
				Message(0, "Usage: #help <helpfile>");
				Message(0, "  Normal - Normal EQEmu commands.");
				if(admin >= 10)	{	Message(0, "  Privuser - Privileged user commands."); }
				if(admin >= 20)	{	Message(0, "  vPrivuser - Very privileged user commands."); }
				if(admin >= 80)	{	Message(0, "  GMQuest - Quest GM commands."); }
				if(admin >= 100)	{	Message(0, "  GM - Game master commands."); }
				if(admin >= 150)	{	Message(0, "  LeadGM - Lead GM commands."); }
				if(admin >= 200)	{	Message(0, "  ServerOP - Server operator commands."); }
				if(admin >= 201)	{	Message(0, "  Debug - Debugging commands."); }
			}
		else if(strcasecmp(sep.arg[1], "normal") == 0)	
			{
			Message(0, "EQEMu Commands:");
			Message(0, "  #itemsearch [id] - Searches item database.");
			Message(0, "  #summonitem [id] - Summons an item.");
			Message(0, "  #loc - Shows you your current location.");
			Message(0, "  #goto  [x,y,z] - Warps you to specified coordinates.");
			Message(0, "  #zone [zonename] - Zones to safepoint in the specified zone.");
			Message(0, "  #zonestatus - Shows what zones are up.");
			Message(0, "  #guild - Guild commands (type for more info)");
			Message(0, "  #showstats - Shows what the server thinks your stats are.");
		}
		else if(strcasecmp(sep.arg[1], "privuser") == 0 && admin >= 10)
			{
				Message(0, "EQEMu Priviliged User Commands:");
				Message(0, "  #level [id] - Sets your target\'s level.");
				Message(0, "  #heal - (PC only) Completely heals your target.");
				Message(0, "  #mana - (PC only) Replenishes your target\'s mana.");
				Message(0, "  #spawn - Used to spawn NPCs");
				Message(0, "  #dbspawn [npctypeid] - Spawns an NPC type from the database.");
				Message(0, "  #texture [texture] [helmtexture]	(0-255, 255 for show equipment)");
				Message(0, "  #gender [0-2] - (0=male, 1=female, 2=neuter)");
				Message(0, "  #npctypespawn [npctype]");
			}
		else if(strcasecmp(sep.arg[1], "vprivuser") == 0 && admin >= 20)
			{
				Message(0, "EQEMu Very Priviliged User Commands:");
				Message(0, "  #size [size] - Sets your targets size.");
				Message(0, "  #findspell [spellname] - Searches the spell database for [spellname]");
				Message(0, "  #castspell [id] - Casts a spell, use #findspell to determine the id number.");
				Message(0, "  #setskill [skill num (0-73)] [number (0-255)] - Sets the targeted player's skill to number.");
				Message(0, "  #setallskill [0-255] - Sets all of the targeted player's skills to number.");
				Message(0, "  #kill - Kills your selected target.");
				Message(0, "  #flymode - Allows you to move freely on the z axis.");
				Message(0, "  #race [0-255]  (0 for back to normal)");
				Message(0, "  #makepet - Makes a custom pet, #makepet for details.");
			}
		else if(strcasecmp(sep.arg[1], "gmquest") == 0 && admin >= 80) 
			{
				Message(0, "EQEMu Quest Troupe Commands:");
				Message(0, "  #npcloot [show/add/remove] [itemid/all] - Adjusts the items the targeted npc is carrying.");
				Message(0, "  #npcstats - Shows the stats of the targetted NPC.");
				Message(0, "  #zheader [zone name/none] - Change the sky/fog/etc. of the current zone.");
				Message(0, "  #zsky [sky number] - Changes the sky of the current zone.");
				Message(0, "  #zcolor [red] [green] [blue] - Changes the fog colour of the current zone.");
				Message(0, "  #zstats - Shows the zone header data for the current zone.");
				Message(0, "  #timeofday - Sets the date to Monday, Janurary 1st, 1 at the specified time.");
				Message(0, "  #date - Sets the time to the specified date.");
				Message(0, "  #weather <0/1/2> - Off/Rain/Snow.");
				Message(0, "  #permaclass <classnum> - Changes your class.");
				Message(0, "  #permarace <racenum> - Changes your race.");
				Message(0, "  #permagender <0/1/2> - Changes your gender.");
				Message(0, "  #emote - Sends an emotish message, type for syntax.");
				Message(0, "  #invul [1/0] - Makes the targeted player invulnerable to attack");
				Message(0, "  #hideme [0/1]	- Removes you from the spawn list.");
				Message(0, "  #npccast [targetname] [spellid] - Makes the targeted NPC cast on [targetname].");
				Message(0, "  #zclip [min clip] [max clip] - Changes the clipping plane of the current zone.");
			}
		else if(strcasecmp(sep.arg[1], "gm") == 0 && admin >= 100)
			{
				Message(0, "EQEMu GM Commands:");
				Message(0, "  #damage [id] - Inflicts damage upon target.");
				Message(0, "  #setxp - Sets the target\'s experience.");
				Message(0, "  /broadcast [text] - Sends a broadcast message.");
				Message(0, "  /pr [text] - Sends text over GMSAY.");
				Message(0, "  /lastname - Sets a player's lastname.");
				Message(0, "  #depop - Depops targeted NPC.");
				Message(0, "  #depopzone - Depops the zone.");
				Message(0, "  #repop [delay] - Repops the zone, optional delay in seconds.");
				Message(0, "  #zuwcoords [number] - Changes the underworld coordinates of the current zone.");
				Message(0, "  #zsafecoords [x] [y] [z] - Changes the safe coordinates of the current zone.");
				Message(0, "  #ListNPCs - Lists all the NPCs currently spawned in the zone.");
				Message(0, "  #ListNPCCorpses - Lists all NPC corpses in the zone.");
				Message(0, "  #ListPlayerCorpses - Lists all player corpses in the zone.");
				Message(0, "  #DeleteNPCCorpses - Deletes all NPC corpses in the zone.");
				Message(0, "  #showbuffs - Shows the buffs on your current target.");
				Message(0, "  #nukebuffs - Dispells your current target.");
				Message(0, "  #freeze - Freezes your current target.");
				Message(0, "  #unfreeze	- Unfreezes your current target.");
				Message(0, "  #pkill - Makes current target pkill.");
				Message(0, "  #unpkill - Makes current target nonpkill.");
				Message(0, "  #gm [on|off] - Toggles your GM flag.");
			}
		else if(strcasecmp(sep.arg[1], "leadgm") == 0 && admin >= 150)
			{
				Message(0, "EQEMu Lead-GM Commands:");
				Message(0, "  #summon [charname] - Summons a player to you.");
				Message(0, "  #sic [charname] - Make targetted npc attack [charname].");
				Message(0, "  #kick [charname] - Kicks player off of the server.");
				Message(0, "  #zoneshutdown [ZoneID | ZoneName] - Shuts down the zoneserver.");
				Message(0, "  #zonebootup [ZoneID] [ZoneName] - Boots [ZoneName] on the zoneserver specified.");
				Message(0, "  #deletecorpse - Deletes the targeted player\'s corpse.");
				Message(0, "  #DeletePlayerCorpses - Deletes all player corpses in the zone.");
				Message(0, "  #motd [New MoTD Message] - Changes the server's MOTD.");
				Message(0, "  #lock/#unlock - Locks or unlocks the server.");
			}
		else if(strcasecmp(sep.arg[1], "serverop") == 0 && admin >= 200)
			{
				Message(0, "EQEMu ServerOperator Commands:");
				Message(0, "  #shutdown - Shuts down the server.");
				Message(0, "  #worldshutdown - Shuts down the worldserver and all zones.");
				Message(0, "  #flag [name] [status] - Flags an account with GM status.");
				Message(0, "  #createacct [name] [password] [status] - Creates an EQEmu account.");
				Message(0, "  #delacct [name] - Deletes an EQEmu account.");
				Message(0, "  #zsave [file name] - Save the current zone header to ./cfg/<filename>.cfg");
				Message(0, "  #dbspawn2 [spawngroup] [respawn] [variance]");
			}
		else if(strcasecmp(sep.arg[1], "debug") == 0 && admin >= 201)
			{
				Message(0, "EQEMu Debug Commands:");
				Message(0, "  #version [name] - Shows information about the zone executable.");
				Message(0, "  #serverinfo [type] - Shows information about the server, #serverinfo for details.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#setxp") == 0 && (admin >= 100))
		{
			if (sep.IsNumber(1)) {
				if (atoi(sep.arg[1]) > 9999999)
					Message(0, "Error: SetXP: Value too high.");
				else
					AddEXP (atoi(sep.arg[1]));
			}
			else
				Message(0, "Usage: #setxp number");
		}
		else if (strcasecmp(sep.arg[0], "#summonitem") == 0 && admin >= 0)
		{
			if (!sep.IsNumber(1)) {
				Message(0, "Usage: #summonitem x , x is an item number");
			}
			else {
				int16 itemid = atoi(sep.arg[1]);
				if (admin < 100 && ((itemid >= 32768) || (itemid >= 19900 && itemid <= 19943) || (itemid >= 31814 && itemid <= 31815) || (itemid >= 19917 && itemid <= 19928) || (itemid >= 11500 && itemid <= 11535) || (itemid >=32740 && itemid <=32758))) { 					Death(this, 0);
				}
				else
					SummonItem(itemid);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#itemsearch") == 0 || strcasecmp(sep.arg[0], "#search") == 0 || strcasecmp(sep.arg[0], "#finditem") == 0) && admin >= 0) {
			if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #itemsearch item OR #search item");
			} else {
				FindItem(sep.argplus[1]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#spawn") == 0 && (admin >= 10)) { // Image's Spawn Code -- Rewrite by Scruffy
//			cout << "Spawning:" << endl; 
			//Well it needs a name!!! 
			if(sep.arg[1][0] == 0) 
			{ 
				Message(0, "Format: #spawn name race level material hp gender class priweapon secweapon merchantid - spawns a npc those parameters.");
				Message(0, "Name Format: NPCFirstname_NPCLastname - All numbers in a name are stripped and \"_\" characters become a space.");
				Message(0, "Note: Using \"-\" for gender will autoselect the gender for the race. Using \"-\" for HP will use the calculated maximum HP.");
			} 
			else 
			{ 
				//Lets see if someone didn't fill out the whole #spawn function properly 
				sep.arg[1][29] = 0;
				if (!sep.IsNumber(2))
					sprintf(sep.arg[2],"1"); 
				if (!sep.IsNumber(3))
					sprintf(sep.arg[3],"1"); 
				if (!sep.IsNumber(4))
					sprintf(sep.arg[4],"0");
				if (atoi(sep.arg[5]) > 2100000000 || atoi(sep.arg[5]) <= 0)
					sprintf(sep.arg[5],"");
				if (!strcmp(sep.arg[6],"-"))
					sprintf(sep.arg[6],""); 
				if (!sep.IsNumber(6))
					sprintf(sep.arg[6],""); 
				if (!sep.IsNumber(7))
					sprintf(sep.arg[7],"1");
				if (!sep.IsNumber(9))
					sprintf(sep.arg[9],"0");
				if (!sep.IsNumber(10))
					sprintf(sep.arg[10], "0");
				if (!sep.IsNumber(8))
					sprintf(sep.arg[8],"0");
				if (!strcmp(sep.arg[5],"-"))
					sprintf(sep.arg[5],""); 
				//Calc MaxHP if client neglected to enter it...
				if (!sep.IsNumber(5)) {
					//Stolen from Client::GetMaxHP...
					int8 multiplier = 0;
					switch(atoi(sep.arg[6]))
					{
						case WARRIOR:
							if (atoi(sep.arg[3]) < 20)
								multiplier = 22;
							else if (GetLevel() < 30)
								multiplier = 23;
							else if (GetLevel() < 40)
								multiplier = 25;
							else if (GetLevel() < 53)
								multiplier = 27;
							else if (GetLevel() < 57)
								multiplier = 28;
							else
								multiplier = 30;
							break;

						case DRUID:
						case CLERIC:
						case SHAMAN:
							multiplier = 15;
							break;

						case PALADIN:
						case SHADOWKNIGHT:
							if (atoi(sep.arg[3]) < 35)
								multiplier = 21;
							else if (GetLevel() < 45)
								 multiplier = 22;
							else if (GetLevel() < 51)
								 multiplier = 23;
							else if (GetLevel() < 56)
								 multiplier = 24;
							else if (GetLevel() < 60)
								 multiplier = 25;
							else
								 multiplier = 26;
							break;

						case MONK:
						case BARD:
						case ROGUE:
				//		case BEASTLORD:
							if (atoi(sep.arg[3]) < 51)
								multiplier = 18;
							else if (GetLevel() < 58)
								multiplier = 19;
							else
								multiplier = 20;				
							break;

						case RANGER:
							if (atoi(sep.arg[3]) < 58)
								multiplier = 20;
							else
								multiplier = 21;			
							break;

						case MAGICIAN:
						case WIZARD:
						case NECROMANCER:
						case ENCHANTER:
							multiplier = 12;
							break;

						default:
							if (atoi(sep.arg[3]) < 35)
								multiplier = 21;
							else if (atoi(sep.arg[3]) < 45)
								multiplier = 22;
							else if (atoi(sep.arg[3]) < 51)
								multiplier = 23;
							else if (atoi(sep.arg[3]) < 56)
								multiplier = 24;
							else if (atoi(sep.arg[3]) < 60)
								multiplier = 25;
							else
								multiplier = 26;
							break;
					}
					sprintf(sep.arg[5],"%i",5+multiplier*atoi(sep.arg[3])+multiplier*atoi(sep.arg[3])*75/300);
				}

				// Autoselect NPC Gender... (Scruffy)
				if (sep.arg[6][0] == 0) {
					sprintf(sep.arg[6], "%i", (int) Mob::GetDefaultGender(atoi(sep.arg[2])));
				}

				// Well we want everyone to know what they spawned, right? 
				Message(0, "New spawn:"); 
				Message(0, "Name: %s",sep.arg[1]); 
				Message(0, "Race: %s",sep.arg[2]);  
				Message(0, "Level: %s",sep.arg[3]);
				Message(0, "Material: %s",sep.arg[4]);
				Message(0, "Current/Max HP: %s",sep.arg[5]);
				Message(0, "Gender: %s",sep.arg[6]); 
				Message(0, "Class: %s",sep.arg[7]);
				Message(0, "Weapon Item Number: %s",sep.arg[8]); 
				Message(0, "MerchantID: %s",sep.arg[9]); 
				//Time to create the NPC!! 
				NPCType* npc_type = new NPCType;
				memset(npc_type, 0, sizeof(NPCType));
				strcpy(npc_type->name,sep.arg[1]);
				npc_type->cur_hp = atoi(sep.arg[5]); 
				npc_type->max_hp = atoi(sep.arg[5]); 
				npc_type->race = atoi(sep.arg[2]); 
				npc_type->gender = atoi(sep.arg[6]); 
				npc_type->class_ = atoi(sep.arg[7]); 
				npc_type->deity= 1; 
				npc_type->level = atoi(sep.arg[3]); 
				npc_type->npc_id = 0;
				npc_type->loottable_id = 0;
				npc_type->texture = atoi(sep.arg[4]);
				npc_type->light = 0; 
				// Weapons are broke!!
				//npc_type->equipment[13] = atoi(sep.arg[8]);
				//npc_type->equipment[14] = atoi(sep.arg[9]);
				npc_type->merchanttype = atoi(sep.arg[10]);	
				//for (int i=0; i<9; i++) 
				//	npc_type->equipment[i] = atoi(sep.arg[8]); 

				npc_type->STR = 75;
				npc_type->STA = 75;
				npc_type->DEX = 75;
				npc_type->AGI = 75;
				npc_type->INT = 75;
				npc_type->WIS = 75;
				npc_type->CHA = 75;

				NPC* npc = new NPC(npc_type, 0, x_pos, y_pos, z_pos, heading);

				// Disgrace: add some loot to it!
				npc->AddCash();
				int itemcount = (rand()%5) + 1;
				for (int counter=0; counter<itemcount; counter++)
				{
					Item_Struct* item = 0;
					while (item == 0)
						item = database.GetItem(rand() % 33000);						

					npc->AddItem(item, 0, 0);
				}

				entity_list.AddNPC(npc); 
			}
		}
		else if (strcasecmp(sep.arg[0], "#createacct") == 0 && admin >= 200)
		{
			if(sep.arg[3][0] == 0) {
				Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 10=PU, 20=PU2, 100=GM, 150=LGM, 200=ServerOP)");
			} else {
				if (database.CreateAccount(sep.arg[1],sep.arg[2], atoi(sep.arg[3]),0) == 0)
					Message(0, "Unable to create account.");
				else
					Message(0, "The account was created.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#delacct") == 0 && admin >= 200)
		{
			if(sep.arg[1][0] == 0) {
				Message(0, "Format: #delacct accountname");
			} else {
				if (database.DeleteAccount(name) == 0)
					Message(0, "Unable to delete account.");
				else
					Message(0, "The account was deleted."); 
			}
		}
		else if (strcasecmp(sep.arg[0], "#loc") == 0)
		{
			if (target != 0 && admin >= 100) {
				Message(0, "%s's Location: %1.1f, %1.1f, %1.1f, h=%1.1f", target->GetName(), target->GetX(), target->GetY(), target->GetZ(), target->GetHeading());
			}
			else
				Message(0, "Current Location: %1.1f, %1.1f, %1.1f, h=%1.1f", x_pos, y_pos, z_pos, GetHeading());
		}
		else if (strcasecmp(sep.arg[0], "#size") == 0 && (admin >= 20))	{
			if (!sep.IsNumber(1))
				Message(0, "Usage: #size [0 - 255]");
			else {
				float newsize = atof(sep.arg[1]);
				if (newsize > 255)
					Message(0, "Error: #size: Size can not be greater than 255.");
				else if (newsize < 0)
					Message(0, "Error: #size: Size can not be less than 0.");
				else {
					if (target)
						target->ChangeSize(newsize);
					else
						this->ChangeSize(newsize);
				}
			}
		}

		else if (strcasecmp(sep.arg[0], "#goto") == 0) // Pyro's goto function
		{
			if (sep.arg[1][0] == 0 && target != 0) {
				MovePC(0, target->GetX(), target->GetY(), target->GetZ());
			}
			else if (!(sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3))) {
				Message(0, "Usage: #goto [x y z].");
			}
			else {
				MovePC(0, atof(sep.arg[2]), atof(sep.arg[1]), atof(sep.arg[3]));
			}
		}
		else if (strcasecmp(sep.arg[0], "#worldshutdown") == 0 && admin >= 200) {
		// GM command to shutdown world server and all zone servers
			if (worldserver.Connected()) {
				worldserver.SendEmoteMessage(0,0,15,"<SYSTEMWIDE MESSAGE>:SYSTEM MSG:World coming down, everyone log out now.");
				Message(0, "Sending shutdown packet");
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ShutdownAll;
				pack->size=0;
				worldserver.SendPacket(pack);
				delete pack;
			}
			else
				Message(0, "Error: World server disconnected");
		}
		else if (strcasecmp(sep.arg[0], "#chat") == 0 && admin >= 200) {
			// sends any channel message to all zoneservers
			// Dev debug command, for learing channums
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #chat channum message");
			else {
				if (!worldserver.SendChannelMessage(0, 0, (uint8) atoi(sep.arg[1]), 0, 0, sep.argplus[2]))
					Message(0, "Error: World server disconnected");
			}
		}
		else if (strcasecmp(sep.arg[0], "#appearance") == 0 && admin >= 150) {
			// sends any appearance packet
			// Dev debug command, for appearance types
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #appearance type value");
			else {
				if (target != 0) {
					target->SendAppearancePacket(atoi(sep.arg[1]), atoi(sep.arg[2]));
					Message(0, "Sending appearance packet: target=%s, type=%s, value=%s", target->GetName(), sep.arg[1], sep.arg[2]);
				}
				else {
					this->SendAppearancePacket(atoi(sep.arg[1]), atoi(sep.arg[2]));
					Message(0, "Sending appearance packet: target=self, type=%s, value=%s", sep.arg[1], sep.arg[2]);
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#zoneshutdown") == 0 && admin >= 150) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #zoneshutdown zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneShutdown;
				strcpy(s->adminname, this->GetName());
				if (sep.arg[1][0] >= '0' && sep.arg[1][0] <= '9')
					s->ZoneServerID = atoi(sep.arg[1]);
				else
					strcpy(s->zonename, sep.arg[1]);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonebootup") == 0 && admin >= 150) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else if (sep.arg[2][0] == 0) {
				Message(0, "Usage: #zonebootup ZoneServerID# zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneBootup;
				s->ZoneServerID = atoi(sep.arg[1]);
				strcpy(s->adminname, this->GetName());
				strcpy(s->zonename, sep.arg[2]);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonestatus") == 0) {
			if (!worldserver.Connected())
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				pack->opcode = ServerOP_ZoneStatus;
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char *) &pack->pBuffer[1], this->GetName());
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#emote") == 0 && (admin >= 80)) {
			if (sep.arg[3][0] == 0)
				Message(0, "Usage: #emote [name | world | zone] type# message");
			else {
				if (strcasecmp(sep.arg[1], "zone") == 0)
					entity_list.Message(0, atoi(sep.arg[2]), sep.argplus[3]);
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else if (strcasecmp(sep.arg[1], "world") == 0)
					worldserver.SendEmoteMessage(0, 0, atoi(sep.arg[2]), sep.argplus[3]);
				else
					worldserver.SendEmoteMessage(sep.arg[1], 0, atoi(sep.arg[2]), sep.argplus[3]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#zone") == 0) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #zone [zonename]");
			else {
				MovePC(sep.arg[1], -1, -1, -1);
			}
		}
		else if (strcasecmp(sep.arg[0], "#summon") == 0 && (admin >= 100)) {
			if (sep.arg[1][0] == 0) {
				if (target != 0 && target->IsNPC()) {
					target->CastToNPC()->GMMove(x_pos, y_pos, z_pos, heading);
				}
				else if (admin >= 150)
					Message(0, "Usage: #summon [charname]");
				else
					Message(0, "You need a NPC target for this command");
			}
			else if (admin >= 150) {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					Message(0, "Summoning %s to %1.1f, %1.1f, %1.1f", sep.arg[1], this->x_pos, this->y_pos, this->z_pos);
					client->MovePC(0, this->x_pos, this->y_pos, this->z_pos);
				}
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_ZonePlayer;
					pack->size = sizeof(ServerZonePlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
					strcpy(szp->adminname, this->GetName());
					szp->adminrank = this->Admin();
					szp->ignorerestrictions = true;
					strcpy(szp->name, sep.arg[1]);
					strcpy(szp->zone, zone->GetShortName());
					szp->x_pos = x_pos;
					szp->y_pos = y_pos;
					szp->z_pos = z_pos;
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#kick") == 0 && (admin >= 150)) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #kick [charname]");
			else {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					if (client->Admin() <= this->Admin()) {
						client->Message(0, "You have been kicked by %s",this->GetName());
						client->Kick();
						this->Message(0, "Kick: local: kicking %s", sep.arg[1]);
					}
				}
				else if (!worldserver.Connected())
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_KickPlayer;
					pack->size = sizeof(ServerKickPlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
					strcpy(skp->adminname, this->GetName());
					strcpy(skp->name, sep.arg[1]);




					skp->adminrank = this->Admin();
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#guild") == 0 || strcasecmp(sep.arg[0], "#guilds") == 0) {
			GuildCommand(&sep);
		}
		else if (strcasecmp(sep.arg[0], "#flag") == 0)
		{
			if(sep.arg[2][0] == 0 || !(admin >= 200)) {
				this->UpdateAdmin();
				Message(0, "Refreshed your admin flag from DB.");
			}
			else if (!sep.IsNumber(2) || atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > 255)
				Message(0, "Usage: #flag [accname] [status] (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
			else {
				if (atoi(sep.arg[2]) > admin)
					Message(0, "You cannot set people's status to higher than your own");
				else if (!database.SetGMFlag(sep.arg[1], atoi(sep.arg[2])))
					Message(0, "Unable to set GM Flag.");
				else {
					Message(0, "Set GM Flag on account.");
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_FlagUpdate;
					pack->size = strlen(sep.arg[1]) + 1;
					pack->pBuffer = new uchar[pack->size];
					memset(pack->pBuffer, 0, pack->size);
					strcpy((char*) pack->pBuffer, sep.arg[1]);
					worldserver.SendPacket(pack);
					delete pack;
				}
			}
		}
		//Disgrace: a make due function to give you almost full mana (almost accurately..)
		else if (strcasecmp(sep.arg[0], "#mana") == 0 && (admin >= 10))
		{
			if (target == 0)
				this->SetMana(30000);
			else
				target->SetMana(30000);
		}
		else if (strcasecmp(sep.arg[0], "#npcloot") == 0 && admin >= 80) {
			if (target == 0)
				Message(0, "Error: No target");
			// #npcloot show
			if (strcasecmp(sep.arg[1], "show") == 0) {
				if (target->IsNPC())
					target->CastToNPC()->QueryLoot(this);
				else if (target->IsCorpse())
					target->CastToCorpse()->QueryLoot(this);
				else
					Message(0, "Error: Target's type doesnt have loot");
			}
			// #npcloot add
			else if (strcasecmp(sep.arg[1], "add") == 0) {
				
				if (target->IsNPC() && sep.IsNumber(2)) {
					int32 item = atoi(sep.arg[2]);
					if (database.GetItem(item)) {
						target->CastToNPC()->AddItem(item, 0, 0);
						Message(0, "Added item(%i) to the %s's loot.", item, target->GetName());
					}
					else
						Message(0, "Error: #item add: Item(%i) does not exist!", item);
				}
				else if (!sep.IsNumber(2))
					Message(0, "Error: #npcloot add: Itemid must be a number.");
				else
					Message(0, "Error: #npcloot add: This is not a valid target.");
			}
			// #npcloot remove
			else if (strcasecmp(sep.arg[1], "remove") == 0) {
				//#npcloot remove all
				if (strcasecmp(sep.arg[2], "all") == 0)
					Message(0, "Error: #npcloot remove all: Not yet implemented.");
				//#npcloot remove itemid
				else {
					if(target->IsNPC() && sep.IsNumber(2)) {
						int32 item = atoi(sep.arg[2]);
						target->CastToNPC()->RemoveItem(item);
						Message(0, "Removed item(%i) from the %s's loot.", item, target->GetName());
					}
					else if (!sep.IsNumber(2))					
						Message(0, "Error: #npcloot remove: Item must be a number.");
					else
						Message(0, "Error: #npcloot remove: This is not a valid target.");
				}
			}
			else
				Message(0, "Usage: #npcloot [show/add/remove] [itemid/all]");
		}
		else if (strcasecmp(sep.arg[0], "#npcstats") == 0 && admin >= 80) {
			if (target == 0)
				Message(0, "ERROR: No target!");
			else if (!target->IsNPC())
				Message(0, "ERROR: Target is not a NPC!");
			else {
				Message(0, "NPC Stats:");
				Message(0, "  Name: %s",target->GetName()); 
				//Message(0, "  Last Name: %s",sep.arg[2]); 
				Message(0, "  Race: %i",target->GetRace());  
				Message(0, "  Level: %i",target->GetLevel());
				Message(0, "  Material: %i",target->GetTexture());
				Message(0, "  Class: %i",target->GetClass());
				Message(0, "  Current HP: %i", target->GetHP());
				Message(0, "  Max HP: %i", target->GetMaxHP());
				//Message(0, "Weapon Item Number: %s",target->GetWeapNo()); 
				Message(0, "  Gender: %i",target->GetGender()); 
				target->CastToNPC()->QueryLoot(this);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#FindSpell") == 0 || strcasecmp(sep.arg[0], "#spfind") == 0) && admin >= 20) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #FindSpell [spellname]");
			else if (!spells_loaded)
				Message(0, "Spells not loaded");
			else if (Seperator::IsNumber(sep.argplus[1])) {
				int spellid = atoi(sep.argplus[1]);
				if (spellid <= 0 || spellid >= SPDAT_RECORDS) {
					Message(0, "Error: Number out of range");
				}
				else {
					Message(0, "  %i: %s", spellid, spells[spellid].name);
				}
			}
			else {
				int count=0;
				int iSearchLen = strlen(sep.argplus[1])+1;
				char sName[64];
				char sCriteria[65];
				strncpy(sCriteria, sep.argplus[1], 64);
				strupr(sCriteria);
				for (int i = 0; i < SPDAT_RECORDS; i++)
				{
					if (spells[i].name[0] != 0) {
						strcpy(sName, spells[i].name);

						strupr(sName);
						char* pdest = strstr(sName, sCriteria);
						if ((pdest != NULL) && (count <=20)) {
							Message(0, "  %i: %s", i, spells[i].name);
							count++;
						}
						else if (count > 20)
							break;
					}
				}
				if (count > 20)
					Message(0, "20 spells found... max reached.");
				else
					Message(0, "%i spells found.", count);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#CastSpell") == 0 || strcasecmp(sep.arg[0], "#Cast") == 0) && admin >= 20) {
			if (!sep.IsNumber(1))
				Message(0, "Usage: #CastSpell spellid");
			else { 
				int16 spellid = atoi(sep.arg[1]);
				if ((spellid == 982 || spellid == 905) && admin < 100)
					this->SetTarget(this);
				if (spellid >= SPDAT_RECORDS)
					Message(0, "Error: #CastSpell: Arguement out of range");
				else {
					if (target == 0)
						SpellFinished(spellid, 0, 10, 0);
					else
						SpellFinished(spellid, target->GetID(), 10, 0);
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#memspell") == 0 && admin >= 100) {
			if (!(sep.IsNumber(1) && sep.IsNumber(2)))
				Message(0, "Usage: #MemSpell slotid spellid");
			else { 
				int16 slotid = atoi(sep.arg[1]) - 1;
				int16 spellid = atoi(sep.arg[2]);
				if (slotid < 0 || slotid >= 8) {
					Message(0, "Error: #MemSpell: Arguement out of range");
				}
				else if (spellid >= SPDAT_RECORDS)
					Message(0, "Error: #MemSpell: Arguement out of range");
				else {
					pp.spell_memory[slotid] = spellid; 
					Message(0, "Spell slot changed, it'll be there when you relog.");
				}
			}
		}
		else if ((strcasecmp(sep.arg[0], "#invul") == 0 || strcasecmp(sep.arg[0], "#invulnerable") == 0) && admin >= 80) {
			Client* client = this;
			if (target) {
				if (target->IsClient())
					client = target->CastToClient();
			}
			if (sep.arg[1][0] == '1') {
				client->Message(0, "You are now invulnerable from attack.");
				client->invulnerable = true;
			}
			else if (sep.arg[1][0] == '0') {
				client->Message(0, "You are no longer invulnerable from attack.");
				client->invulnerable = false;
			}
			else
				Message(0, "Usage: #invulnerable [1/0]");
		}
		else if (strcasecmp(sep.arg[0], "#setskill") == 0 && (admin >= 20)) {
			if (target == 0) {
				Message(0, "Error: #setskill: No target.");
			}
			else if (!sep.IsNumber(1) || atoi(sep.arg[1]) < 0 || atoi(sep.arg[1]) > 73) {
				Message(0, "Usage: #setskill skill x ");
				Message(0, "       skill = 0 to 73");
				Message(0, "       x = 0 to 255");
				Message(0, "NOTE: skill values greater than 250 may cause the skill to become unusable on the client.");
			}
			else if (!sep.IsNumber(2) || atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > 255) {
				Message(0, "Usage: #setskill skill x ");
				Message(0, "       skill = 0 to 73");
				Message(0, "       x = 0 to 255");
			}
			else {
				//pp.skills[atoi(sep.arg[1])] = (int8)atoi(sep.arg[2]);
				cout << "Setting " << target->GetName() << " skill " << sep.arg[1] << " to " << sep.arg[2] << endl;
				int skill_num = atoi(sep.arg[1]);
				int8 skill_id = (int8)atoi(sep.arg[2]);
				target->SetSkill(skill_num, skill_id);
			}
		}
		else if (strcasecmp(sep.arg[0], "#setallskill") == 0 || strcasecmp(sep.arg[0], "#setskillall") == 0 && (admin >= 20)) {
			if (target == 0) {
				Message(0, "Error: #setallskill: No target.");
			}
			else if (!sep.IsNumber(1) || atoi(sep.arg[1]) < 0 || atoi(sep.arg[1]) > 252) {
				Message(0, "Usage: #setskill value ");
				Message(0, "       value = 0 to 252");
			}
			else {
				//pp.skills[atoi(sep.arg[1])] = (int8)atoi(sep.arg[2]);
				cout << "Setting ALL of " << target->GetName() << "'s skills to " << sep.arg[1] << endl;
				int8 skill_id = atoi(sep.arg[1]);
				for(int skill_num=0;skill_num<74;skill_num++){
					target->SetSkill(skill_num, skill_id);
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#save") == 0 && admin >= 100) {
			if (target == 0)
				Message(0, "Error: no target");
			else if (!target->IsClient())
				Message(0, "Error: target not a client");
			else if	(target->CastToClient()->Save())
				Message(0, "%s successfully saved.", target->GetName());
			else
				Message(0, "Manual save for %s failed.", target->GetName());
		}
		else if (strcasecmp(sep.arg[0], "#showstats") == 0) {
			if (target != 0 && admin >= 100)
				target->ShowStats(this);
			else
				this->ShowStats(this);
		}
		else if (strcasecmp(sep.arg[0], "#iteminfo") == 0) {
			Item_Struct* item = database.GetItem(pp.inventory[0]);
			if (item == 0)
				Message(0, "Error: You need an item on your cursor for this command");
			else {
				Message(0, "ID: %i Name: %s", item->item_nr, item->name);
				Message(0, "  Lore: %s  ND: %i  NS: %i  Type: %i", item->lore, item->nodrop, item->nosave, item->type);
				Message(0, "  IDF: %s  Size: %i  Weight: %i  Flag: %04x  icon_nr: %i  Cost: %i", item->idfile, item->size, item->weight, (int16) item->flag, (int16) item->icon_nr, item->cost);
				if (item->type == 0x02)
					Message(0, "  This item is a Book: %s", item->book.file);
				else {
					if (item->type == 0x01)
						Message(0, "  This item is a container with %i slots", item->common.container.numSlots);
					Message(0, "  Magic: %i  SpellID0: %i  Level0: %i  Charges: %i", item->common.magic, item->common.spellId0, item->common.level0, item->common.charges);
					Message(0, "  SpellId: %i  Level: %i  EffectType: 0x%02x  CastTime: %.2f", item->common.spellId, item->common.level, (int8) item->common.effecttype, (double) item->common.casttime/1000);
					Message(0, "  Material: 0x02%x  Color: 0x%08x", item->common.material, item->common.color);
					Message(0, "  U0187: 0x%02x%02x  U0192: 0x%02x  U0198: 0x%02x%02x  U0204: 0x%02x%02x  U0210: 0x%02x%02x  U0214: 0x%02x%02x%02x", item->common.unknown0187[0], item->common.unknown0187[1], item->common.unknown0192, item->common.unknown0198[0], item->common.unknown0198[1], item->common.unknown0204[0], item->common.unknown0204[1], item->common.unknown0210[0], item->common.unknown0210[1], (int8) item->common.normal.unknown0214[0], (int8) item->common.normal.unknown0214[1], (int8) item->common.normal.unknown0214[2]);
					Message(0, "  U0222[0-9]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0222[0], (int8) item->common.unknown0222[1], (int8) item->common.unknown0222[2], (int8) item->common.unknown0222[3], (int8) item->common.unknown0222[4], (int8) item->common.unknown0222[5], (int8) item->common.unknown0222[6], (int8) item->common.unknown0222[7], (int8) item->common.unknown0222[8], (int8) item->common.unknown0222[9]);
					Message(0, "  U0236[ 0-15]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[0], (int8) item->common.unknown0236[1], (int8) item->common.unknown0236[2], (int8) item->common.unknown0236[3], (int8) item->common.unknown0236[4], (int8) item->common.unknown0236[5], (int8) item->common.unknown0236[6], (int8) item->common.unknown0236[7], (int8) item->common.unknown0236[8], (int8) item->common.unknown0236[9], (int8) item->common.unknown0236[10], (int8) item->common.unknown0236[11], (int8) item->common.unknown0236[12], (int8) item->common.unknown0236[13], (int8) item->common.unknown0236[14], (int8) item->common.unknown0236[15]);
					Message(0, "  U0236[16-31]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[16], (int8) item->common.unknown0236[17], (int8) item->common.unknown0236[18], (int8) item->common.unknown0236[19], (int8) item->common.unknown0236[20], (int8) item->common.unknown0236[21], (int8) item->common.unknown0236[22], (int8) item->common.unknown0236[23], (int8) item->common.unknown0236[24], (int8) item->common.unknown0236[25], (int8) item->common.unknown0236[26], (int8) item->common.unknown0236[27], (int8) item->common.unknown0236[28], (int8) item->common.unknown0236[29], (int8) item->common.unknown0236[30], (int8) item->common.unknown0236[31]);
					Message(0, "  U0236[32-47]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[32], (int8) item->common.unknown0236[33], (int8) item->common.unknown0236[34], (int8) item->common.unknown0236[35], (int8) item->common.unknown0236[36], (int8) item->common.unknown0236[37], (int8) item->common.unknown0236[38], (int8) item->common.unknown0236[39], (int8) item->common.unknown0236[40], (int8) item->common.unknown0236[41], (int8) item->common.unknown0236[42], (int8) item->common.unknown0236[43], (int8) item->common.unknown0236[44], (int8) item->common.unknown0236[45], (int8) item->common.unknown0236[46], (int8) item->common.unknown0236[47]);
					Message(0, "  U0236[48-55]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[48], (int8) item->common.unknown0236[49], (int8) item->common.unknown0236[50], (int8) item->common.unknown0236[51], (int8) item->common.unknown0236[52], (int8) item->common.unknown0236[53], (int8) item->common.unknown0236[54], (int8) item->common.unknown0236[55]);
				}
				Message(0, "  U0103[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[0], (int8) item->unknown0103[1], (int8) item->unknown0103[2], (int8) item->unknown0103[3], (int8) item->unknown0103[4], (int8) item->unknown0103[5], (int8) item->unknown0103[6], (int8) item->unknown0103[7], (int8) item->unknown0103[8], (int8) item->unknown0103[9], (int8) item->unknown0103[10], (int8) item->unknown0103[11]);
				Message(0, "  U0103[12-21]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[12], (int8) item->unknown0103[13], (int8) item->unknown0103[14], (int8) item->unknown0103[15], (int8) item->unknown0103[16], (int8) item->unknown0103[17], (int8) item->unknown0103[18], (int8) item->unknown0103[19], (int8) item->unknown0103[20], (int8) item->unknown0103[21]);
				Message(0, "  U0144[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[0], (int8) item->unknown0144[1], (int8) item->unknown0144[2], (int8) item->unknown0144[3], (int8) item->unknown0144[4], (int8) item->unknown0144[5], (int8) item->unknown0144[6], (int8) item->unknown0144[7], (int8) item->unknown0144[8], (int8) item->unknown0144[9], (int8) item->unknown0144[10], (int8) item->unknown0144[11]);
				Message(0, "  U0144[12-23]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[12], (int8) item->unknown0144[13], (int8) item->unknown0144[14], (int8) item->unknown0144[15], (int8) item->unknown0144[16], (int8) item->unknown0144[17], (int8) item->unknown0144[18], (int8) item->unknown0144[19], (int8) item->unknown0144[20], (int8) item->unknown0144[21], (int8) item->unknown0144[22], (int8) item->unknown0144[23]);
				Message(0, "  U0144[24-27]: 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[24], (int8) item->unknown0144[25], (int8) item->unknown0144[26], (int8) item->unknown0144[27]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#Depop") == 0 && admin >= 100) {
			if (target == 0 || !(target->IsNPC() || target->IsNPCCorpse()))
				Message(0, "You must have a NPC target for this command. (maybe you meant #depopzone?)");
			else {
				Message(0, "Depoping '%s'.", target->GetName());
				target->Depop();
			}
		}
		else if (strcasecmp(sep.arg[0], "#DepopCorpses") == 0 && admin >= 100) {
			entity_list.DepopCorpses();
			Message(0, "NPC corpses depoped.");
		}
		else if (strcasecmp(sep.arg[0], "#DepopZone") == 0 && admin >= 100) {
			zone->Depop();
			Message(0, "Zone depoped.");
		}
		else if (strcasecmp(sep.arg[0], "#Repop") == 0 && admin >= 100) {
			if (sep.IsNumber(1)) {
				zone->Repop(atoi(sep.arg[1])*1000);
				Message(0, "Zone depoped. Repop in %i seconds", atoi(sep.arg[1]));
			}
			else {
				zone->Repop();
				Message(0, "Zone depoped. Repoping now.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#spawnstatus") == 0 && admin >= 100) {
			zone->SpawnStatus(this);
		}
		else if (strcasecmp(sep.arg[0], "#listNPCs") == 0 && admin >= 100) {
			entity_list.ListNPCs(this);
		}
		else if (strcasecmp(sep.arg[0], "#listNPCCorpses") == 0 && admin >= 100) {
			entity_list.ListNPCCorpses(this);
		}
		else if (strcasecmp(sep.arg[0], "#listPlayerCorpses") == 0 && admin >= 100) {
			entity_list.ListPlayerCorpses(this);
		}
		else if (strcasecmp(sep.arg[0], "#deleteNPCCorpses") == 0 && admin >= 100) {
			sint32 tmp = entity_list.DeleteNPCCorpses();
			if (tmp >= 0)
				Message(0, "%i corpses deleted.", tmp);
			else
				Message(0, "DeletePlayerCorpses Error #%i", tmp);
		}
		else if (strcasecmp(sep.arg[0], "#deletePlayerCorpses") == 0 && admin >= 150) {
			sint32 tmp = entity_list.DeletePlayerCorpses();
			if (tmp >= 0)
				Message(0, "%i corpses deleted.", tmp);
			else
				Message(0, "DeletePlayerCorpses Error #%i", tmp);
		}
		else if (strcasecmp(sep.arg[0], "#doanim") == 0) {
			if (!sep.IsNumber(1)) {
				Message(0, "Usage: #DoAnim [number]");
			}
			else {
				if (admin >= 100) {
					if (target == 0)
						Message(0, "Error: You need a target.");
					else
						target->DoAnim(atoi(sep.arg[1]));
				}
				else
					DoAnim(atoi(sep.arg[1]));
			}
		}
		else if (strcasecmp(sep.arg[0], "#showbuffs") == 0 && admin >= 100) {
			if (target == 0)
				this->ShowBuffs(this);
			else
				target->ShowBuffs(this);
		}
		else if (strcasecmp(sep.arg[0], "#nukebuffs") == 0 && admin >= 100) {
			if (target == 0)
				this->BuffFade(0xFFFe);
			else
				target->BuffFade(0xFFFe);
		}
		else if (strcasecmp(sep.arg[0], "#hideme") == 0 && admin >= 80) {
			if ((sep.arg[1][0] != '0' && sep.arg[1][0] != '1') || sep.arg[1][1] != 0)
				Message(0, "Usage: #hideme [0/1]");
			else {
				gmhideme = atoi(sep.arg[1]);
				if (gmhideme) {
					APPLAYER app;
					CreateDespawnPacket(&app);
					entity_list.QueueClientsStatus(this, &app, true, 0, admin-1);
					entity_list.RemoveFromTargets(this);
					Message(13, "Removing you from spawn lists.");
				}
				else {
					APPLAYER app;
					CreateSpawnPacket(&app);
					entity_list.QueueClientsStatus(this, &app, true, 0, admin-1);
					Message(13, "Adding you back to spawn lists.");
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#deletecorpse") == 0 && admin >= 150) {
			if (target == 0 || !target->IsPlayerCorpse())
				Message(0, "Error: Target the player corpse you wish to delete");
			else {
				Message(0, "Deleting %s.", target->GetName());
				target->CastToCorpse()->Delete();
			}
		}
		else if (strcasecmp(sep.arg[0], "#sendzonespawns") == 0 && admin >= 200) {
			entity_list.SendZoneSpawns(this);
		}
		else if (strcasecmp(sep.arg[0], "#flymode") == 0 && admin >= 20) {
			if (strlen(sep.arg[1]) == 1 && !(sep.arg[1][0] == '0' || sep.arg[1][0] == '1' || sep.arg[1][0] == '2')) {
				Message(0, "#flymode [0/1/2]");
			}
			else {
				APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
				SpawnAppearance_Struct* appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
				if (target == 0 || !target->IsClient() || admin < 100) {
					appearance->spawn_id = this->GetID();
					if (sep.arg[1][0] == '1')
						Message(0, "Turning Flymode ON");
					else if (sep.arg[1][0] == '2')
						Message(0, "Turning Flymode LEV");
					else
						Message(0, "Turning Flymode OFF");
				}
				else {
					appearance->spawn_id = target->GetID();
					if (sep.arg[1][0] == '1')
						Message(0, "Turning %s's Flymode ON", target->GetName());
					else if (sep.arg[1][0] == '2')
						Message(0, "Turning %s's Flymode LEV", target->GetName());
					else
						Message(0, "Turning %s's Flymode OFF", target->GetName());
				}
				appearance->parameter = atoi(sep.arg[1]);
				appearance->type = 19;
				entity_list.QueueClients(this, outapp, false);
				delete outapp;
			}
		}
		else if (strcasecmp(sep.arg[0], "#race") == 0 && admin >= 20) {
			if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 255) {
				if ((target) && admin >= 100)
					target->SendIllusionPacket(atoi(sep.arg[1]));
				else
					this->SendIllusionPacket(atoi(sep.arg[1]));
			}
			else
				Message(0, "Usage: #race [0-255]  (0 for back to normal)");
		}
		else if (strcasecmp(sep.arg[0], "#texture") == 0 && admin >= 10) {
			if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 255) {
				int tmp;
				if (sep.IsNumber(2) && atoi(sep.arg[2]) >= 0 && atoi(sep.arg[2]) <= 255) {
					tmp = atoi(sep.arg[2]);
				}
				else if (atoi(sep.arg[1]) == 255) {
					tmp = atoi(sep.arg[1]);
				}
				else if ((GetRace() > 0 && GetRace() <= 12) || GetRace() == 128 || GetRace() == 130)
					tmp = 0;
				else
					tmp = atoi(sep.arg[1]);

				if ((target) && admin >= 100)
					target->SendIllusionPacket(target->GetRace(), 0xFF, atoi(sep.arg[1]), tmp);
				else
					this->SendIllusionPacket(this->GetRace(), 0xFF, atoi(sep.arg[1]), tmp);
			}
			else
				Message(0, "Usage: #texture [texture] [helmtexture]  (0-255, 255 for show equipment)");
		}
		else if (strcasecmp(sep.arg[0], "#gender") == 0 && admin >= 10) {
			if (sep.IsNumber(1) && atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) <= 2) {
				gender = atoi(sep.arg[1]);
				if ((target) && admin >= 100)
					target->SendIllusionPacket(target->GetRace(), gender);
				else
					this->SendIllusionPacket(this->GetRace(), gender);
			}
			else
				Message(0, "Usage: #gender [0-2]  (0=male, 1=female, 2=neuter)");
		}
		else if (strcasecmp(sep.arg[0], "#zheader")==0 && admin >= 80) {
			// sends zhdr packet
			if(sep.arg[1][0]==0) {
				Message(0, "Usage: #zheader <zone name>");
				Message(0, "NOTE: Use \"none\" for zone name to use default header.");
			}
			else {
				if (strcasecmp(sep.argplus[1], "none") == 0) {
					Message(0, "Loading default zone header");
					zone->LoadZoneCFG(0);
				}
				else {
					if (zone->LoadZoneCFG(sep.argplus[1], true))
						Message(0, "Successfully loaded zone header: %s.cfg", sep.argplus[1]);
					else
						Message(0, "Failed to load zone header: %s.cfg", sep.argplus[1]);
				}
				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if(strcasecmp(sep.arg[0], "#zsky") == 0 && admin >= 80) {
			// modifys and resends zhdr packet
			if(sep.arg[1][0]==0)
				Message(0, "Usage: #zsky <sky type>");
			else if(atoi(sep.arg[1])<0||atoi(sep.arg[1])>255)
				Message(0, "ERROR: Sky type can not be less than 0 or greater than 255!");
			else {
				zone->newzone_data.sky = atoi(sep.arg[1]);

				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if((strcasecmp(sep.arg[0], "#zcolor") == 0 || strcasecmp(sep.arg[0], "#zcolour") == 0) && admin >= 80) {
			// modifys and resends zhdr packet
			if(sep.arg[3][0]==0)
				Message(0, "Usage: #zcolor <red> <green> <blue>");
			else if(atoi(sep.arg[1])<0||atoi(sep.arg[1])>255)
				Message(0, "ERROR: Red can not be less than 0 or greater than 255!");
			else if(atoi(sep.arg[2])<0||atoi(sep.arg[2])>255)
				Message(0, "ERROR: Green can not be less than 0 or greater than 255!");
			else if(atoi(sep.arg[3])<0||atoi(sep.arg[3])>255)
				Message(0, "ERROR: Blue can not be less than 0 or greater than 255!");
			else {
				for(int z=1;z<13;z++) {
					if(z<5)
						zone->newzone_data.unknown230[z] = atoi(sep.arg[1]);
					if(z>4 && z<9)
						zone->newzone_data.unknown230[z] = atoi(sep.arg[2]);
					if(z>8)
						zone->newzone_data.unknown230[z] = atoi(sep.arg[3]);
				}

				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if(strcasecmp(sep.arg[0], "#zuwcoords") == 0 && admin >= 100) {
			// modifys and resends zhdr packet
			if(sep.arg[1][0]==0)
				Message(0, "Usage: #zuwcoords <under world coords>");
			else {
				zone->newzone_data.underworld = atof(sep.arg[1]);
//				float newdata = atof(sep.arg[1]);
//				memcpy(&zone->zone_header_data[130], &newdata, sizeof(float));

				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if(strcasecmp(sep.arg[0], "#zsafecoords") == 0 && admin >= 100) {
			// modifys and resends zhdr packet
			if(sep.arg[3][0]==0)
				Message(0, "Usage: #zsafecoords <safe x> <safe y> <safe z>");
			else {
				zone->newzone_data.safe_x = atof(sep.arg[1]);
				zone->newzone_data.safe_y = atof(sep.arg[2]);
				zone->newzone_data.safe_z = atof(sep.arg[3]);
//				float newdatax = atof(sep.arg[1]);
//				float newdatay = atof(sep.arg[2]);
//				float newdataz = atof(sep.arg[3]);
//				memcpy(&zone->zone_header_data[114], &newdatax, sizeof(float));
//				memcpy(&zone->zone_header_data[118], &newdatay, sizeof(float));
//				memcpy(&zone->zone_header_data[122], &newdataz, sizeof(float));
//				zone->SetSafeCoords();

				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if(strcasecmp(sep.arg[0], "#zclip") == 0 && admin >= 80) {
			// modifys and resends zhdr packet
			if(sep.arg[2][0]==0)
				Message(0, "Usage: #zclip <min clip> <max clip>");
			else if(atoi(sep.arg[1])<=0)
				Message(0, "ERROR: Min clip can not be zero or less!");
			else if(atoi(sep.arg[2])<=0)
				Message(0, "ERROR: Max clip can not be zero or less!");
			else if(atoi(sep.arg[1])>atoi(sep.arg[2]))
				Message(0, "ERROR: Min clip is greater than max clip!");
			else {
				zone->newzone_data.minclip = atof(sep.arg[1]);
				zone->newzone_data.maxclip = atof(sep.arg[2]);
//				float newdatamin = atof(sep.arg[1]);
//				float newdatamax = atof(sep.arg[2]);
//				memcpy(&zone->zone_header_data[134], &newdatamin, sizeof(float));
//				memcpy(&zone->zone_header_data[138], &newdatamax, sizeof(float));

				APPLAYER* outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
				memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
				entity_list.QueueClients(this, outapp);
				delete outapp;
			}
		}
		else if(strcasecmp(sep.arg[0], "#zsave") == 0 && admin >= 200) {
			// modifys and resends zhdr packet
			if(sep.arg[1][0]==0)
				Message(0, "Usage: #zsave <file name>");
			else {
				zone->SaveZoneCFG(sep.argplus[1]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#npccast") == 0 && admin >= 80) {
			if (target && target->IsNPC() && sep.arg[1] != 0 && sep.IsNumber(2)) {
				Mob* spelltar = entity_list.GetMob(sep.arg[1]);
				if (spelltar) {
					target->CastSpell(atoi(sep.arg[2]), spelltar->GetID());
				}
				else {
					Message(0, "Error: %s not found", sep.arg[1]);
				}
			}
			else {
				Message(0, "Usage: (needs NPC targeted) #npccast targetname spellid");
			}
		}
		else if (strcasecmp(sep.arg[0], "#dbspawn2") == 0 && (admin >= 200)) // Image's Spawn Code -- Rewrite by Scruffy
		{
			if (sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3)) {
				cout << "Spawning: Database spawn" << endl; 
				database.CreateSpawn2(atoi(sep.arg[1]),pp.current_zone,heading, x_pos, y_pos, z_pos, atoi(sep.arg[2]), atoi(sep.arg[3]));
			}
			else {
				Message(0, "Usage: #dbspawn2 spawngroup respawn variance");
			}
		}
		else if (strcasecmp(sep.arg[0], "#npctypespawn") == 0 && (admin >= 10))
		{
			if (sep.IsNumber(1)) {
				NPCType* tmp = 0;
				if (tmp = database.GetNPCType(atoi(sep.arg[1])))
				{
					NPC* npc = new NPC(tmp, 0, x_pos, y_pos, z_pos, heading);
					entity_list.AddNPC(npc); 
				}
				else
					Message(0, "NPC Type %i not found", atoi(sep.arg[1])); 
			}
			else {
				Message(0, "Usage: #dbspawn npctypeid");
			}
		}
		else if (strcasecmp(sep.arg[0], "#sic") == 0 && admin >= 150) {
			if (target && target->IsNPC() && sep.arg[1] != 0) {
				Mob* sictar = entity_list.GetMob(sep.arg[1]);
				if (sictar) {
					target->CastToNPC()->AddToHateList(sictar, 0, 100000);
				}
				else {
					Message(0, "Error: %s not found", sep.arg[1]);
				}
			}
			else {
				Message(0, "Usage: (needs NPC targeted) #sic targetname");
			}
		}
		else if (strcasecmp(sep.arg[0], "#zstats") == 0 && admin >= 80 ) {
			Message(0, "Zone Header Data:");
			Message(0, "Sky Type: %i", zone->newzone_data.sky);
			Message(0, "Sky Colour: Red: %i; Blue: %i; Green %i", zone->newzone_data.unknown230[1], zone->newzone_data.unknown230[5], zone->newzone_data.unknown230[9]);
			Message(0, "Safe Coords: %f, %f, %f", zone->newzone_data.safe_x, zone->newzone_data.safe_y, zone->newzone_data.safe_z);
			Message(0, "Underworld Coords: %f", zone->newzone_data.underworld);
			Message(0, "Clip Plane: %f - %f", zone->newzone_data.minclip, zone->newzone_data.maxclip);
		}
		else if (strcasecmp(sep.arg[0], "#lock") == 0 && admin >= 150) {
			ServerPacket* outpack = new ServerPacket(ServerOP_Lock, sizeof(ServerLock_Struct));
			ServerLock_Struct* lss = (ServerLock_Struct*) outpack->pBuffer;
			strcpy(lss->myname, this->GetName());
			lss->mode = 1;
			worldserver.SendPacket(outpack);
			delete outpack;
		}
		else if (strcasecmp(sep.arg[0], "#unlock") == 0 && admin >= 150) {
			ServerPacket* outpack = new ServerPacket(ServerOP_Lock, sizeof(ServerLock_Struct));
			ServerLock_Struct* lss = (ServerLock_Struct*) outpack->pBuffer;
			strcpy(lss->myname, this->GetName());
			lss->mode = 0;
			worldserver.SendPacket(outpack);
			delete outpack;
		}
		else if (strcasecmp(sep.arg[0], "#motd") == 0 && admin >= 150) {
			ServerPacket* outpack = new ServerPacket(ServerOP_Motd, sizeof(ServerMotd_Struct));
			ServerMotd_Struct* mss = (ServerMotd_Struct*) outpack->pBuffer;
			strcpy(mss->myname, this->GetName());
			strcpy(mss->motd, sep.argplus[1]);
			worldserver.SendPacket(outpack);
			delete outpack;
		}
		else if (strcasecmp(sep.arg[0], "#uptime") == 0) {
			if (!worldserver.Connected()) {
				Message(0, "Error: World server disconnected");
			}
			else if (sep.IsNumber(1) && atoi(sep.arg[1]) > 0) {
				ServerPacket* pack = new ServerPacket(ServerOP_Uptime, sizeof(ServerUptime_Struct));
				ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
				strcpy(sus->adminname, this->GetName());
				sus->zoneserverid = atoi(sep.arg[1]);
				worldserver.SendPacket(pack);
				delete pack;
			}
			else {
				ServerPacket* pack = new ServerPacket(ServerOP_Uptime, sizeof(ServerUptime_Struct));
				ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
				strcpy(sus->adminname, this->GetName());
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#test1") == 0 && admin >= 200) {
			APPLAYER* outapp = new APPLAYER(OP_Illusion, sizeof(Illusion_Struct));
			Illusion_Struct* is = (Illusion_Struct*) outapp->pBuffer;
			is->spawnid = GetID();
			is->race = this->race;
			is->gender = this->gender;
			is->texture = atoi(sep.arg[1]);
			is->helmtexture = atoi(sep.arg[2]);
			is->unknown008[0] = atoi(sep.arg[3]); // face & eyebrows
			is->unknown008[1] = atoi(sep.arg[4]);
			is->unknown008[2] = atoi(sep.arg[5]); // hairstyle
			is->unknown008[3] = atoi(sep.arg[6]);
			is->unknown008[4] = atoi(sep.arg[7]);
			is->unknown008[5] = atoi(sep.arg[8]);
			is->unknown003 = atoi(sep.arg[9]);
			is->unknown007 = atoi(sep.arg[10]);
			Message(0, "T%i H%i 80:%i 81:%i 82:%i 83:%i 84:%i 85:%i 3:%i 7:%i", is->texture, is->helmtexture, is->unknown008[0], is->unknown008[1], is->unknown008[2], is->unknown008[3], is->unknown008[4], is->unknown008[5], is->unknown003, is->unknown007);
			entity_list.QueueClients(this, outapp);
			DumpPacket(outapp);
			delete outapp;
		}
		else if (strcasecmp(sep.arg[0], "#testspawn") == 0 && admin >= 250) {
			NPC* npc = new NPC(database.GetNPCType(1286), 0, this->GetX(), this->GetY(), this->GetZ(), this->GetHeading());
			entity_list.AddNPC(npc, false);
			APPLAYER* outapp = new APPLAYER(OP_NewSpawn, sizeof(NewSpawn_Struct));
			NewSpawn_Struct* ns = (NewSpawn_Struct*) outapp->pBuffer;
			npc->FillSpawnStruct(ns, 0);
			strcpy(ns->spawn.name, "Test");
			ns->spawn.NPC = 0;
//			ns->spawn.not_linkdead = 1;
			ns->spawn.npc_armor_graphic = 0xFF;
			ns->spawn.npc_helm_graphic = 0xFF;
			ns->spawn.equipment[0] = 3;
			ns->spawn.equipment[1] = 3;
			ns->spawn.equipment[2] = 3;
			ns->spawn.equipment[3] = 3;
			ns->spawn.equipment[4] = 3;
			ns->spawn.equipment[5] = 3;
			ns->spawn.equipment[6] = 3;
			ns->spawn.equipment[7] = 3;
			ns->spawn.equipment[8] = 3;
			uchar* buf = (uchar*) &ns->spawn;
			if (sep.IsNumber(2)) {
				Message(0, "%i = %i", atoi(sep.arg[1]), atoi(sep.arg[2]));
				if (atoi(sep.arg[2]) >= 65536)
					*((int32*) buf[atoi(sep.arg[1])]) = atoi(sep.arg[2]);
				else if (atoi(sep.arg[2]) >= 256)
					*((int16*) buf[atoi(sep.arg[1])]) = atoi(sep.arg[2]);
				else
					buf[atoi(sep.arg[1])] = atoi(sep.arg[2]);
			}
			DumpPacket(buf, sizeof(Spawn_Struct));
			EncryptSpawnPacket(outapp);
			entity_list.QueueClients(0, outapp);
			delete outapp;
		}
		else if (strcasecmp(sep.arg[0],"#makepet") == 0 && admin >= 20) {
			if (!(sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3) && sep.IsNumber(4))) {
				Message(0, "Usage: #makepet level class race texture");
			}
			else {
				this->MakePet(atoi(sep.arg[1]), atoi(sep.arg[2]), atoi(sep.arg[3]), atoi(sep.arg[4]));
			}
		}
		else if (strcasecmp(sep.arg[0], "#ShowPetSpell") == 0 && admin >= 250) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #ShowPetSpells [petsummonstring]");
			else if (!spells_loaded)
				Message(0, "Spells not loaded");
			else if (Seperator::IsNumber(sep.argplus[1])) {
				int spellid = atoi(sep.argplus[1]);
				if (spellid <= 0 || spellid >= SPDAT_RECORDS) {
					Message(0, "Error: Number out of range");
				}
				else {
					Message(0, "  %i: %s, %s", spellid, spells[spellid].teleport_zone, spells[spellid].name);
				}
			}
			else {
				int count=0;
				int iSearchLen = strlen(sep.argplus[1])+1;
				char sName[64];
				char sCriteria[65];
				strncpy(sCriteria, sep.argplus[1], 64);
				strupr(sCriteria);
				for (int i = 0; i < SPDAT_RECORDS; i++)
				{
					if (spells[i].name[0] != 0 && (spells[i].effectid[0] == SE_SummonPet || spells[i].effectid[0] == SE_NecPet)) {
						strcpy(sName, spells[i].teleport_zone);

						strupr(sName);
						char* pdest = strstr(sName, sCriteria);
						if ((pdest != NULL) && (count <=20)) {
							Message(0, "  %i: %s, %s", i, spells[i].teleport_zone, spells[i].name);
							count++;
						}
						else if (count > 20)
							break;
					}
				}
				if (count > 20)
					Message(0, "20 spells found... max reached.");
				else
					Message(0, "%i spells found.", count);
			}
		}
		else if (strcasecmp(sep.arg[0], "#freeze") == 0 && admin >= 100) {
			if (target != 0) {
				target->SendAppearancePacket(14, 102);
			}
			else {
				Message(0, "ERROR: Freeze requires a target.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#unfreeze") == 0 && admin >= 100) {
			if (target != 0) {
				target->SendAppearancePacket(14, 100);
			}
			else {
				Message(0, "ERROR: Unfreeze requires a target.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#pkill") == 0 && admin >= 100) {
			//TODO: Save in PlayerProfile.
			if (target != 0) {
				target->SendAppearancePacket(4, 1);
			}
			else {
				Message(0, "ERROR: Pkill requires a target.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#unpkill") == 0 && admin >= 100) {
			//TODO: Save in PlayerProfile.
			if (target != 0) {
				target->SendAppearancePacket(4, 0);
			}
			else {
				Message(0, "ERROR: Unpkill requires a target.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#permaclass")==0 && admin >= 80) {
			if(sep.arg[1][0]==0) {
				Message(0,"FORMAT: #permaclass <classnum>");
			}
			/*else if(target==0) {
				Message(0, "ERROR: Class requires a target.");
			}*/
			else {
				Message(0, "Setting your class...Sending you to char select.");
				cout << "Class change request.. Class requested: " << sep.arg[1] << endl;
				pp.class_=atoi(sep.arg[1]);
				Kick();
				pp.class_=atoi(sep.arg[1]);
				Save();
			}
		}
		else if (strcasecmp(sep.arg[0], "#permarace")==0 && admin >= 80) {
			if(sep.arg[1][0]==0) {
				Message(0,"FORMAT: #permarace <racenum>");
				Message(0,"NOTE: Not all models are global. If a model is not global, it will appear as a human on character select and in zones without the model.");
			}
			/*else if(target==0) {
				Message(0, "ERROR: Permarace requires a target.");
			}*/
			else {
				Message(0, "Setting your race...Sending you to char select.");
				cout << "Permanant race change request.. Race requested: " << sep.arg[1] << endl;
				int8 tmp = Mob::GetDefaultGender(atoi(sep.arg[1]), pp.gender);
				pp.race=atoi(sep.arg[1]);
				pp.gender=tmp;
				Kick();
				pp.race=atoi(sep.arg[1]);
				pp.gender=tmp;
				Save();
			}
		}
		else if (strcasecmp(sep.arg[0], "#permagender")==0 && admin >= 80) {
			if(sep.arg[1][0]==0) {
				Message(0,"FORMAT: #permagender <gendernum>");
				Message(0,"Gender Numbers: 0=Male, 2=Female, 3=Neuter");
			}
			/*else if(target==0) {
				Message(0, "ERROR: Permagender requires a target.");
			}*/
			else {
				Message(0, "Setting your gender...Sending you to char select.");
				cout << "Permanant gender change request.. Gender requested: " << sep.arg[1] << endl;
				pp.gender=atoi(sep.arg[1]);
				Kick();
				pp.gender=atoi(sep.arg[1]);
				Save();
			}
		}
		else if (strcasecmp(sep.arg[0], "#gm") == 0 && admin >= 100) {
			if ((target != 0) && (target->IsClient())) {
				if(strcasecmp(sep.arg[1], "on") == 0) {
					target->CastToClient()->SetGM(true);
					Message(13, "%s is now a GM!", target->CastToClient()->GetName());
				}
				else if(strcasecmp(sep.arg[1], "off") == 0) {
					target->CastToClient()->SetGM(false);
					Message(13, "%s is no longer a GM!", target->CastToClient()->GetName());
				}
				else {
					Message(0, "Usage: #gm [on|off]");
				}
			}
			else {
				if(strcasecmp(sep.arg[1], "on") == 0) {
					SetGM(true);
				}
				else if(strcasecmp(sep.arg[1], "off") == 0) {
					SetGM(false);
				}
				else {
					Message(0, "Usage: #gm [on|off]");
				}
			}
		}
		else {
			Message(0, "Command does not exist");
		}
	} else {
		if (chan_num == 3 || chan_num == 4) { // Shout, auction
			entity_list.ChannelMessage(this, chan_num, language, message);
		}
		else if (chan_num == 8) {
			entity_list.ChannelMessage(this, chan_num, language, message);
			if (target != 0 && target->IsNPC()) {
				//if (DistNoRootNoZ(target) <= 100) {
					CheckQuests(zone->GetShortName(), message, target->GetNPCTypeID());
				//}
			}
		}
		else if (chan_num == 5) { // Quagmire - moved ooc to worldwide since moved guildsay to, err, guilds
			if (!worldserver.SendChannelMessage(this, 0, 5, 0, language, message))
				Message(0, "Error: World server disconnected");
		}
		else if (chan_num == 0) {
			// 0 = guildsay
			if (guilddbid == 0 || guildeqid >= 512)
				Message(0, "Error: You arent in a guild.");
			else if (!guilds[guildeqid].rank[guildrank].speakgu)
				Message(0, "Error: You dont have permission to speak to the guild.");
			else if (!worldserver.SendChannelMessage(this, targetname, chan_num, guilddbid, language, message))
				Message(0, "Error: World server disconnected");
		}
		else if (chan_num == 7) {
			// 7 = tell
			Mob* mypet = this->GetPet();
			if (mypet != 0 && mypet->IsNPC() && strstr(mypet->GetName(),targetname) != NULL) {
				if (strstr(strupr(message),"ATTACK") != NULL) {
					if (mypet->CastToNPC()->GetHateTop()==0) zone->AddAggroMob(); //merkur
					mypet->CastToNPC()->AddToHateList(target);
				}
				else if (strstr(strupr(message),"REPORT HEALTH") != NULL) {
					Message(10, "I have %d percent of my hps left", (int8)mypet->GetHPRatio());
				}
				else if (strstr(strupr(message), "BACK OFF") != NULL) {
					mypet->CastToNPC()->WhipeHateList();
				}
				else if (strstr(strupr(message),"GET LOST") != NULL) {
					entity_list.MessageClose(mypet, false, 200, 10, "As you wish! Oh great one.");
					mypet->CastToNPC()->Depop();
				}
				printf("* Tried to use a pet command for %s\n", mypet->GetName());
			}
			else if (!worldserver.SendChannelMessage(this, targetname, chan_num, 0, language, message))
				Message(0, "Error: World server disconnected");
		}
		else if (chan_num == 6 || chan_num == 11) {
			// 6 = broadcast, 11 = GMSAY
			if (!(admin >= 80))
				Message(0, "Error: Only GMs can use this channel");
			else if (!worldserver.SendChannelMessage(this, targetname, chan_num, 0, language, message))
				Message(0, "Error: World server disconnected");
		}
		else {
			Message(0, "Channel not implemented");
        } 

	}
}

void Client::ChannelMessageSend(char* from, char* to, int8 chan_num, int8 language, char* message, ...) {
	if ((chan_num == 11 || chan_num == 10) && !(this->Admin() >= 80)) // dont need to send /pr & /pet to everybody
		return;
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER app;

	app.opcode = OP_ChannelMessage;
	app.size = sizeof(ChannelMessage_Struct)+strlen(buffer)+1;
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	ChannelMessage_Struct* cm = (ChannelMessage_Struct*) app.pBuffer;
	if (from == 0)
		strcpy(cm->sender, "ZServer"); 	else if (from[0] == 0)
		strcpy(cm->sender, "ZServer"); 	else
		strcpy(cm->sender, from);
	if (to != 0)
		strcpy((char *) cm->targetname, to);
	else
		cm->targetname[0] = 0;
	cm->language = language;
	cm->chan_num = chan_num;
//cm->cm_unknown4[0] = 0xff;
	cm->cm_unknown4[1] = 0xff; // One of these tells the client how well we know the language
	cm->cm_unknown4[2] = 0xff;
	cm->cm_unknown4[3] = 0xff;
	cm->cm_unknown4[4] = 0xff;
	strcpy(&cm->message[0], buffer);

	if (chan_num == 7 && from != 0) 
	{ 
		strcpy(cm->targetname, pp.name); 
	} 
	QueuePacket(&app);
}

void Client::Message(int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER* app = new APPLAYER;
	app->opcode = OP_SpecialMesg;
	app->size = 4+strlen(buffer)+1;
	app->pBuffer = new uchar[app->size];
	SpecialMesg_Struct* sm=(SpecialMesg_Struct*)app->pBuffer;
	sm->msg_type = type;
	strcpy(sm->message, buffer);
	QueuePacket(app);
	delete app;	
}

void Client::SendHPUpdate()	
{
	APPLAYER* app = new APPLAYER;
	CreateHPPacket(app);
	if (GMHideMe())
		entity_list.QueueClientsStatus(this, app, false, admin);
	else
		entity_list.QueueCloseClients(this, app);
	delete app;
}

void Client::SetMaxHP()
{
	SetHP(CalcMaxHP());
	SendHPUpdate();
	Save();
}

void Client::AddEXP(int32 add_exp)
{
	SetEXP(GetEXP() + add_exp);
}

void Client::SetEXP(int32 set_exp)
{
	int16 check_level = GetLevel()+1;

	while (set_exp > GetEXPForLevel(check_level)) {
		check_level++;
		if (check_level > 100) { // Quagmire - this was happening because GetEXPForLevel returned 0 on unknown race/class combo, Changed it to return 0xFFFFFFFF on error
			check_level = GetLevel()+1;
			break;
		}
	}

	if (GetLevel() != check_level-1)
	{
		if (GetLevel() == check_level-2)
		{
			Message(15, "You have gained a level! Welcome to level %i!", check_level-1);
		}
		else
		{
			Message(15, "Welcome to level %i!", check_level-1);
		}
		SetLevel(check_level-1);
		UpdateWho();
	}
	else
	{
		Message(15, "You gain experience!!");
		APPLAYER app;
		app.opcode = OP_ExpUpdate;
		app.size = sizeof(ExpUpdate_Struct);
		app.pBuffer = new uchar[app.size];
		ExpUpdate_Struct* eu = (ExpUpdate_Struct*)app.pBuffer;
		eu->exp = set_exp;
		QueuePacket(&app);		
	}
	if (admin>=100)
	{
		Message(15, "[GM] You now have %d EXP.", set_exp);
	}

	pp.exp = set_exp;
}

void Client::MovePC(char* zonename, float x, float y, float z, bool ignorerestrictions)
{
	zonesummon_ignorerestrictions = ignorerestrictions;

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_GMSummon;
	outapp->size = sizeof(GMSummon_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	GMSummon_Struct* gms = (GMSummon_Struct*) outapp->pBuffer;
	strcpy(gms->charname, this->GetName());
	strcpy(gms->gmname, this->GetName());
	if (zonename == 0)
		strcpy(gms->zonename, zone->GetFileName());
	else {
		strcpy(gms->zonename, "zonesummon");
		if (strcasecmp(zonename, zone->GetShortName()) != 0) {
			strcpy(zonesummon_name, zonename);
			zonesummon_x = x;
			zonesummon_y = y;
			zonesummon_z = z;
		}
	}
	gms->x = (sint32) x;
	gms->y = (sint32) y;
	gms->z = (sint32) z;
	int8 tmp[16] = { 0x7C, 0xEF, 0xFC, 0x0F, 0x80, 0xF3, 0xFC, 0x0F, 0xA9, 0xCB, 0x4A, 0x00, 0x7C, 0xEF, 0xFC, 0x0F };
	memcpy(gms->unknown2, tmp, 16);
	int8 tmp2[4] = { 0xE0, 0xE0, 0x56, 0x00 };
	memcpy(gms->unknown3, tmp2, 4);
	QueuePacket(outapp);
	delete outapp;
}


void Client::SetLevel(int8 set_level)
{
	if (GetEXPForLevel(set_level) == 0xFFFFFFFF) {
		cout << "Error in SetLevel" << endl;
		return;
	}

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_LevelUpdate;
	outapp->size = sizeof(LevelUpdate_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	LevelUpdate_Struct* lu = (LevelUpdate_Struct*)outapp->pBuffer;
	lu->level = set_level;


	lu->level_old = level;
	lu->exp = GetEXPForLevel(set_level);
	QueuePacket(outapp);
	delete outapp;	
	outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
	appearance->spawn_id = GetID();
	appearance->type = 0x01; // /who level change
	appearance->parameter = set_level;
	entity_list.QueueClients(this, outapp, false);
	delete outapp;

	pp.exp = lu->exp;
	pp.level = set_level;
	level = set_level;

	cout << "Setting Level: " << GetName() << " = " << (int16) set_level << endl;

	Message(15, "Welcome to level %i!", set_level);
	SetHP(CalcMaxHP());		// Why not, lets give them a free heal
	SendHPUpdate();
	SetMana(CalcMaxMana());
	UpdateWho();

//	ChannelMessageSend(0, 0, 7, 0, "Your level changed, please check if your max hp is %i. If not do a bug report with class, level, stamina and max hp", GetMaxHP());
}
//                           hum       bar    eru     elf     hie     def     hef     dwa     tro     ogr     hal    gno     iks,    vah
float  race_modifiers[14] =  {100.0f, 105.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 120.0f, 115.0f, 95.0f, 100.0f, 120.0f, 100.0f}; // Quagmire - Guessed on iks and vah
//                           war  cle  pal  ran  shd  dru  mnk  brd  rog  shm  nec  wiz  mag  enc
float class_modifiers[14] = { 9.0f, 10.0f, 14.0f, 14.0f, 14.0f, 10.0f, 12.0f, 14.0f, 9.05f, 10.0f, 11.0f, 11.0f, 11.0f, 11.0f};

/*
	Note: The client calculates exp separatly, we cant change this function
*/
uint32 Client::GetEXPForLevel(int16 check_level)
{
	int8 tmprace = GetBaseRace();
	if (tmprace == IKSAR) // Quagmire, set these up so they read from array right
		tmprace = 13;
	else if (tmprace == VAHSHIR)
		tmprace = 14;

	tmprace -= 1;
	if (tmprace >= 14 || GetClass() < 1 || GetClass() > 14)
		return 0xFFFFFFFF;

	if (check_level < 31)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]);
	else if (check_level < 36)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.1);
	else if (check_level < 41)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.2);
	else if (check_level < 46)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.3);
	else if (check_level < 52)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.4);
	else if (check_level < 53)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.5);
	else if (check_level < 54)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.6);
	else if (check_level < 55)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.7);
	else if (check_level < 56)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.9);
	else if (check_level < 57)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.1);
	else if (check_level < 58)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.3);
	else if (check_level < 59)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.5);
	else if (check_level < 60)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.7);
	else if (check_level < 61)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.0);
	else
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.1);
}

sint32 Client::CalcMaxHP() {
	max_hp = (CalcBaseHP() + itembonuses->HP + spellbonuses->HP);
	if (cur_hp > max_hp)
		cur_hp = max_hp;
	return max_hp;
}

/*
	Note: The client calculates max hp separatly, we cant change this function
*/
sint32 Client::CalcBaseHP()
{
	int8 multiplier = 0;

	switch(GetClass())
	{
		case WARRIOR:
			if (GetLevel() < 20)
				multiplier = 22;
			else if (GetLevel() < 30)
				multiplier = 23;
			else if (GetLevel() < 40)
				multiplier = 25;
			else if (GetLevel() < 53)
				multiplier = 27;
			else if (GetLevel() < 57)
				multiplier = 28;
			else
				multiplier = 30;
			break;

		case DRUID:
		case CLERIC:
		case SHAMAN:
			multiplier = 15;
			break;

		case PALADIN:
		case SHADOWKNIGHT:
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				 multiplier = 22;
			else if (GetLevel() < 51)
				 multiplier = 23;
			else if (GetLevel() < 56)
				 multiplier = 24;
			else if (GetLevel() < 60)
				 multiplier = 25;
			else
				 multiplier = 26;
			break;

		case MONK:
		case BARD:
		case ROGUE:
		case BEASTLORD:
			if (GetLevel() < 51)
				multiplier = 18;
			else if (GetLevel() < 58)
				multiplier = 19;
			else
				multiplier = 20;				
			break;

		case RANGER:
			if (GetLevel() < 58)
				multiplier = 20;
			else
				multiplier = 21;			
			break;

		case MAGICIAN:
		case WIZARD:
		case NECROMANCER:
		case ENCHANTER:
			multiplier = 12;
			break;

		default:
			//cerr << "Unknown/invalid class in Client::CalcBaseHP" << endl;
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				multiplier = 22;
			else if (GetLevel() < 51)
				multiplier = 23;
			else if (GetLevel() < 56)
				multiplier = 24;
			else if (GetLevel() < 60)
				multiplier = 25;
			else
				multiplier = 26;
			break;
	}

	if (multiplier == 0)
	{
		cerr << "Multiplier == 0 in Client::CalcBaseHP" << endl;
	}

//	cout << "m:" << (int)multiplier << " l:" << (int)GetLevel() << " s:" << (int)GetSTA() << endl;

	base_hp = 5+multiplier*GetLevel()+multiplier*GetLevel()*GetSTA()/300;
	return base_hp;
}

int8 Client::GetSkill(int skill_num)
{
	return pp.skills[skill_num];
}

/* 
	Added 12-29-01 -socket
*/
void Client::SetSkill(int skillid, int8 value)
{
	pp.skills[skillid] = value;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_SkillUpdate;
	outapp->size = sizeof(SkillUpdate_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, sizeof(outapp->size));
	SkillUpdate_Struct* skill = (SkillUpdate_Struct*)outapp->pBuffer;
	skill->skillId=skillid;
	skill->value=value;
	QueuePacket(outapp);
	delete outapp;
}

/*
	This should return the combined AC of all the items the player is wearing.
*/
int16 Client::GetRawItemAC()
{
	Item_Struct* TempItem;
	int16 Total = 0;
	
	for(int x=0; x<=20; x++)
	{
		TempItem = database.GetItem(pp.inventory[x]);
		if (TempItem)
			Total += TempItem->common.AC;
	}

	return Total;
}

/*
	This is a testing formula for AC, the value this returns should be the same value as the one the client shows...
	ac1 and ac2 are probably the damage migitation and damage avoidance numbers, not sure which is which.
	I forgot to include the iksar defense bonus and i cant find my notes now...
	AC from spells are not included (cant even cast spells yet..)
*/
int16 Client::GetCombinedAC_TEST()
{
	int ac1;

	ac1 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac1 = ac1*4/3;
	}
	ac1 += GetSkill(DEFENSE)/3;
	if (GetAGI() > 70)
	{
		ac1 += GetAGI()/20;
	}

	int ac2;

	ac2 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac2 = ac2*4/3;
	}
	ac2 += GetSkill(DEFENSE)*400/255;

	int combined_ac = (ac1+ac2)*1000/847;

	return combined_ac;
}

void Client::UpdateWho(bool remove) {
	if (account_id == 0)
		return;
	if (!worldserver.Connected())
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = remove;
	strcpy(scl->name, this->GetName());
	scl->Admin = this->Admin();
	scl->AccountID = this->AccountID();
	strcpy(scl->AccountName, this->AccountName());
	strcpy(scl->zone, zone->GetShortName());
	scl->race = this->GetRace();
	scl->class_ = GetClass();
	scl->level = GetLevel();
	if (pp.anon == 0)
		scl->anon = 0;
	else if (pp.anon == 1)
		scl->anon = 1;
	else if (pp.anon >= 2)
		scl->anon = 2;
	scl->tellsoff = tellsoff;
	scl->guilddbid = guilddbid;
	scl->guildeqid = guildeqid;
	scl->LFG = LFG;

	worldserver.SendPacket(pack);
	delete pack;
}

// Zone client to spot specified, cords all = 0xFFFF for safe point
/*void Client::MovePC(char* zonename, sint16 x, sint16 y, sint16 z) {
	zonesummon_x = x;
	zonesummon_y = y;
	zonesummon_z = z;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_Translocate;
	outapp->size = 88;
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	if (zonename == 0)
		strcpy((char*) outapp->pBuffer, zone->GetShortName());
	else
		strcpy((char*) outapp->pBuffer, zonename);
	int8 tmp[68] = {
0x10, 0xd2, 0x3f, 0x04, 0x86, 0xf3, 0xc4, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xec, 0x46, 0x00, 0xa0, 0xa0, 0x6d, 0x0d,
0x80, 0x15, 0xd5, 0x06, 0xf4, 0xd2, 0xd2, 0x0c, 0xf5, 0x20, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
0x04, 0x00, 0x00, 0x00, 0xf4, 0xca, 0x84, 0x08, 0x00, 0x00, 0xfa, 0xc6, 0x00, 0x00, 0xfa, 0xc6,
0x00, 0x00, 0xfa, 0xc6 };
	memcpy(&outapp->pBuffer[16], tmp, 68);
	outapp->pBuffer[84] = 1;
	QueuePacket(outapp);
	delete outapp;
}*/

void Client::WhoAll(Who_All_Struct* whom) {
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_Who;
		pack->size = sizeof(ServerWhoAll_Struct);
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, sizeof(pack->pBuffer));
		ServerWhoAll_Struct* whoall = (ServerWhoAll_Struct*) pack->pBuffer;
		whoall->admin = (int8) admin;
		strcpy(whoall->from, this->GetName());
		strcpy(whoall->whom, whom->whom);
		whoall->firstlvl = whom->firstlvl;
		whoall->gmlookup = whom->gmlookup;
		whoall->secondlvl = whom->secondlvl;
		whoall->wclass = whom->wclass;
		whoall->wrace = whom->wrace;
		worldserver.SendPacket(pack);
		delete pack;
	}
}

bool Client::SetGuild(int32 in_guilddbid, int8 in_rank) {
	if (in_guilddbid == 0) {
		// update DB
		if (!database.SetGuild(character_id, 0, GUILD_MAX_RANK))
			return false;
		// clear guildtag
		guilddbid = in_guilddbid;
		guildeqid = 0xFFFFFFFF;
		guildrank = GUILD_MAX_RANK;
		APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
		SpawnAppearance_Struct* appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
		appearance->spawn_id = GetID();
		appearance->type = 22;
		appearance->parameter = 0xFFFFFFFF;
		entity_list.QueueClients(this, outapp, false);
		delete outapp;
		outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
		appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
		appearance->spawn_id = GetID();
		appearance->type = 23;
		appearance->parameter = 3;
		entity_list.QueueClients(this, outapp, false);
		delete outapp;
		UpdateWho();
		return true;
	}
	else {
		int32 tmp = database.GetGuildEQID(in_guilddbid);
		if (tmp != 0xFFFFFFFF) {
			if (!database.SetGuild(character_id, in_guilddbid, in_rank))
				return false;
			APPLAYER* outapp;
			SpawnAppearance_Struct* appearance;
			guildeqid = tmp;
			guildrank = in_rank;
			if (guilddbid != in_guilddbid) {
				guilddbid = in_guilddbid;
				outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
				appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
				appearance->spawn_id = GetID();
				appearance->type = 22;
				appearance->parameter = guildeqid;
				entity_list.QueueClients(this, outapp, false);
				delete outapp;
			}

			outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
			appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
			appearance->spawn_id = GetID();
			appearance->type = 23;
			if (guilds[tmp].rank[in_rank].warpeace || guilds[tmp].leader == account_id)
				appearance->parameter = 2;
			else if (guilds[tmp].rank[in_rank].invite || guilds[tmp].rank[in_rank].remove || guilds[tmp].rank[in_rank].motd)
				appearance->parameter = 1;
			else
				appearance->parameter = 0;
			entity_list.QueueClients(this, outapp, false);
			delete outapp;
			UpdateWho();
			return true;
		}
	}
	UpdateWho();
	return false;
}

void Client::GuildCommand(Seperator* sep) {
	if (strcasecmp(sep->arg[1], "help") == 0) {
		Message(0, "Guild commands:");
		Message(0, "  #guild status [name] - shows guild and rank of target");
		Message(0, "  #guild info guildnum - shows info/current structure");
		Message(0, "  #guild invite [charname]");
		Message(0, "  #guild remove [charname]");
		Message(0, "  #guild promote charname rank");
		Message(0, "  #guild demote charname rank");
		Message(0, "  /guildmotd [newmotd]    (use 'none' to clear)");
		Message(0, "  #guild edit rank title newtitle");
		Message(0, "  #guild edit rank permission 0/1");
		Message(0, "  #guild leader newleader (they must be rank0)");
		if (admin >= 100) {
			Message(0, "GM Guild commands:");
			Message(0, "  #guild list - lists all guilds on the server");
			Message(0, "  #guild create {guildleader charname or AccountID} guildname");
			Message(0, "  #guild delete guildDBID");
			Message(0, "  #guild rename guildDBID newname");
			Message(0, "  #guild set charname guildDBID    (0=no guild)");
			Message(0, "  #guild setrank charname rank");
			Message(0, "  #guild gmedit guilddbid rank title newtitle");
			Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			Message(0, "  #guild setleader guildDBID {guildleader charname or AccountID}");
		}

	}
	else if (strcasecmp(sep->arg[1], "status") == 0 || strcasecmp(sep->arg[1], "stat") == 0) {
		Client* client = 0;
		if (sep->arg[2][0] != 0)
			client = entity_list.GetClientByName(sep->argplus[2]);
		else if (target != 0 && target->IsClient())
			client = target->CastToClient();
		if (client == 0)
			Message(0, "You must target someone or specify a character name");
		else if ((client->Admin() >= 100 && admin < 100) && client->GuildDBID() != guilddbid) // no peeping for GMs, make sure tell message stays the same
			Message(0, "You must target someone or specify a character name.");
		else {
			if (client->GuildDBID() == 0)
				Message(0, "%s is not in a guild.", client->GetName());
			else if (guilds[client->GuildEQID()].leader == client->AccountID())
				Message(0, "%s is the leader of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
			else
				Message(0, "%s is a member of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
		}
	}
	else if (strcasecmp(sep->arg[1], "info") == 0) {
		if (sep->arg[2][0] == 0 && guilddbid == 0)
			if (admin >= 100)
				Message(0, "Usage: #guildinfo guilddbid");
			else
				Message(0, "You're not in a guild");
		else {
			int32 tmp;
			if (sep->arg[2][0] == 0)
				tmp = database.GetGuildEQID(guilddbid);
			else
				tmp = database.GetGuildEQID(atoi(sep->arg[2]));
			if (tmp < 0 || tmp >= 512)
				Message(0, "Guild not found.");
			else {
				database.GetGuildRanks(tmp, &guilds[tmp]);
				Message(0, "Guild info DB# %i, %s", guilds[tmp].databaseID, guilds[tmp].name);
				if (admin >= 100 || guildeqid == tmp) {
					if (account_id == guilds[tmp].leader || guildrank == 0 || admin >= 100) {
						char leadername[32];
						database.GetAccountName(guilds[tmp].leader, leadername);
						Message(0, "Guild Leader: %s", leadername);
					}
					Message(0, "Rank 0: %s", guilds[tmp].rank[0].rankname);
					Message(0, "  All Permissions.");
					for (int i = 1; i <= GUILD_MAX_RANK; i++) {
						Message(0, "Rank %i: %s", i, guilds[tmp].rank[i].rankname);
						Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove, guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
//						Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove);
//						Message(0, "  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
					}
				}
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "leader") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (guilds[guildeqid].leader != account_id)
			Message(0, "You aren't the guild leader.");
		else {
			char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "invite") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].invite)
			Message(0, "You dont have permission to invite.");
		else {
			char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "remove") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if ((!guilds[guildeqid].rank[guildrank].remove) && !(target == this && sep->arg[2][0] == 0))
			Message(0, "You dont have permission to remove.");
		else {
			char* tmptar = 0;
			if (sep->arg[2][0] != 0)
				tmptar = sep->argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildRemove;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "promote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep->arg[2]) == 1 && sep->arg[2][0] >= '0' && sep->arg[2][0] <= '9'))
			Message(0, "Usage: #guild promote rank [charname]");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			char* tmptar = 0;
			if (sep->arg[3][0] != 0)
				tmptar = sep->argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildPromote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep->arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "demote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep->arg[2]) == 1 && sep->arg[2][0] >= '0' && sep->arg[2][0] <= '9'))
			Message(0, "Usage: #guild demote rank [charname]");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			char* tmptar = 0;
			if (sep->arg[3][0] != 0)
				tmptar = sep->argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildDemote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep->arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "motd") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].motd)
			Message(0, "You dont have permission to change the motd.");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			char tmp[255];
			if (strcasecmp(sep->argplus[2], "none") == 0)
				strcpy(tmp, "");
			else
				snprintf(tmp, sizeof(tmp), "%s - %s", this->GetName(), sep->argplus[2]);
			if (database.SetGuildMOTD(guilddbid, tmp)) {
/*
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &guildeqid, 4);
				worldserver.SendPacket(pack);
				delete pack;
*/
			}
			else {
				Message(0, "Motd update failed.");
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "edit") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!sep->IsNumber(2))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep->arg[2]) < 0 || atoi(sep->arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (!guildrank == 0)
			Message(0, "You must be rank %s to use edit.", guilds[guildeqid].rank[0].rankname);
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			if (!GuildEditCommand(guilddbid, guildeqid, atoi(sep->arg[2]), sep->arg[3], sep->argplus[4])) {
				Message(0, "  #guild edit rank title newtitle");
				Message(0, "  #guild edit rank permission 0/1");
			}
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &guildeqid, 4);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "gmedit") == 0 && admin >= 100) {
		if (!sep->IsNumber(2))
			Message(0, "Error: invalid guilddbid.");
		else if (!sep->IsNumber(3))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep->arg[3]) < 0 || atoi(sep->arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 eqid = database.GetGuildEQID(atoi(sep->arg[2]));
			if (eqid == 0xFFFFFFFF)
				Message(0, "Error: Guild not found");
			else if (!GuildEditCommand(atoi(sep->arg[2]), eqid, atoi(sep->arg[3]), sep->arg[4], sep->argplus[5])) {
				Message(0, "  #guild gmedit guilddbid rank title newtitle");
				Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			}
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &eqid, 4);
				worldserver.SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "set") == 0 && admin >= 100) {
		if (!sep->IsNumber(3))
			Message(0, "Usage: #guild set charname guildgbid (0 = clear guildtag)");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSet;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->guilddbid = atoi(sep->arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep->arg[2]);
			worldserver.SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep->arg[1], "setrank") == 0 && admin >= 100) {
		if (!sep->IsNumber(3))
			Message(0, "Usage: #guild setrank charname rank");
		else if (atoi(sep->arg[3]) < 0 || atoi(sep->arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSetRank;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->newrank = atoi(sep->arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep->arg[2]);
			worldserver.SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep->arg[1], "create") == 0 && admin >= 100) {
		if (sep->arg[3][0] == 0)
			Message(0, "Usage: #guild create {guildleader charname or AccountID} guild name");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep->IsNumber(2))
				leader = atoi(sep->arg[2]);
			else
				leader = database.GetAccountIDByChar(sep->arg[2]);

			int32 tmp = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "Guild leader not found.");
			else if (tmp != 0) {
				int32 tmp2 = database.GetGuildEQID(tmp);
				Message(0, "Error: %s already is the leader of DB# %i '%s'.", sep->arg[2], tmp, guilds[tmp2].name);
			}
			else {
				int32 tmpeq = database.CreateGuild(sep->argplus[3], leader);
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild creation failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					database.GetGuildRanks(tmpeq, &guilds[tmpeq]);
					Message(0, "Guild created: Leader: %i, DB# %i, EQ# %i: %s", leader, guilds[tmpeq].databaseID, tmpeq, sep->argplus[3]);
				}

			}
		}
	}
	else if (strcasecmp(sep->arg[1], "delete") == 0 && admin >= 100) {
		if (!sep->IsNumber(2))
			Message(0, "Usage: #guild delete guildDBID");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
			char tmpname[32];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);

			if (!database.DeleteGuild(atoi(sep->arg[2])))
				Message(0, "Guild delete failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild deleted: DB# %i, EQ# %i: %s", atoi(sep->arg[2]), tmpeq, tmpname);
				} else
					Message(0, "Guild deleted: DB# %i", atoi(sep->arg[2]));
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "rename") == 0 && admin >= 100) {
		if ((!sep->IsNumber(2)) || sep->arg[3][0] == 0)
			Message(0, "Usage: #guild rename guildDBID newname");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
			char tmpname[32];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);

			if (!database.RenameGuild(atoi(sep->arg[2]), sep->argplus[3]))
				Message(0, "Guild rename failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild renamed: DB# %i, EQ# %i, OldName: %s, NewName: %s", atoi(sep->arg[2]), tmpeq, tmpname, sep->argplus[3]);
				} else
					Message(0, "Guild renamed: DB# %i, NewName: %s", atoi(sep->arg[2]), sep->argplus[3]);
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "setleader") == 0 && admin >= 100) {
		if (sep->arg[3][0] == 0 || !sep->IsNumber(2))
			Message(0, "Usage: #guild setleader guilddbid {guildleader charname or AccountID}");
		else if (!worldserver.Connected())
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep->IsNumber(3))
				leader = atoi(sep->arg[3]);
			else
				leader = database.GetAccountIDByChar(sep->argplus[3]);

			int32 tmpdb = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "New leader not found.");
			else if (tmpdb != 0) {
				int32 tmpeq = database.GetGuildEQID(tmpdb);
				if (tmpeq >= 512)
					Message(0, "Error: %s already is the leader of DB# %i.", sep->argplus[3], tmpdb);
				else
					Message(0, "Error: %s already is the leader of DB# %i <%s>.", sep->argplus[3], tmpdb, guilds[tmpeq].name);
			}
			else {
				int32 tmpeq = database.GetGuildEQID(atoi(sep->arg[2]));
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild not found.");
				else if (!database.SetGuildLeader(atoi(sep->arg[2]), leader))
					Message(0, "Guild leader change failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					worldserver.SendPacket(pack);
					delete pack;
					Message(0, "Guild leader changed: DB# %s, Leader: %s, Name: <%s>", sep->arg[2], sep->argplus[3], guilds[tmpeq].name);
				}
			}
		}
	}
	else if (strcasecmp(sep->arg[1], "list") == 0 && admin >= 100) {
		int x = 0;
		Message(0, "Listing guilds on the server:");
		char leadername[32];
		for (int i = 0; i < 512; i++) {
			if (guilds[i].databaseID != 0) {
				leadername[0] = 0;
				database.GetAccountName(guilds[i].leader, leadername);
				if (leadername[0] == 0)
					Message(0, "  DB# %i EQ# %i  <%s>", guilds[i].databaseID, i, guilds[i].name);
				else
					Message(0, "  DB# %i EQ# %i  <%s> Leader: %s", guilds[i].databaseID, i, guilds[i].name, leadername);
				x++;
			}
		}
		Message(0, "%i guilds listed.", x);
	}
	else {
		Message(0, "Unknown guild command, try #guild help");
	}
}

bool Client::GuildEditCommand(int32 dbid, int32 eqid, int8 rank, char* what, char* value) {
	struct GuildRankLevel_Struct grl;
	strcpy(grl.rankname, guilds[eqid].rank[rank].rankname);
	grl.demote = guilds[eqid].rank[rank].demote;
	grl.heargu = guilds[eqid].rank[rank].heargu;
	grl.invite = guilds[eqid].rank[rank].invite;
	grl.motd = guilds[eqid].rank[rank].motd;
	grl.promote = guilds[eqid].rank[rank].promote;
	grl.remove = guilds[eqid].rank[rank].remove;
	grl.speakgu = guilds[eqid].rank[rank].speakgu;
	grl.warpeace = guilds[eqid].rank[rank].warpeace;

	if (strcasecmp(what, "title") == 0) {
		if (strlen(value) > 100)
			Message(0, "Error: Title has a maxium length of 100 characters.");
		else
			strcpy(grl.rankname, value);
	}
	else if (rank == 0)
		Message(0, "Error: Rank 0's permissions can not be changed.");
	else {
		if (!(strlen(value) == 1 && (value[0] == '0' || value[0] == '1')))
			return false;
		if (strcasecmp(what, "demote") == 0)
			grl.demote = (value[0] == '1');
		else if (strcasecmp(what, "heargu") == 0)
			grl.heargu = (value[0] == '1');
		else if (strcasecmp(what, "invite") == 0)
			grl.invite = (value[0] == '1');
		else if (strcasecmp(what, "motd") == 0)
			grl.motd = (value[0] == '1');
		else if (strcasecmp(what, "promote") == 0)
			grl.promote = (value[0] == '1');
		else if (strcasecmp(what, "remove") == 0)
			grl.remove = (value[0] == '1');
		else if (strcasecmp(what, "speakgu") == 0)
			grl.speakgu = (value[0] == '1');
		else if (strcasecmp(what, "warpeace") == 0)
			grl.warpeace = (value[0] == '1');
		else
			Message(0, "Error: Permission name not recognized.");
	}
	if (!database.EditGuild(dbid, rank, &grl))
		Message(0, "Error: database.EditGuild() failed");
	return true;
}

sint32 Client::CalcMaxMana()
{
	switch(GetCasterClass())
	{
		case 'I': {
			max_mana = (((GetINT()/5)+2) * GetLevel()) + spellbonuses->Mana + itembonuses->Mana;
			break;
		}
		case 'W': {
			max_mana = (((GetWIS()/5)+2) * GetLevel()) + spellbonuses->Mana + itembonuses->Mana;
			break;
		}
		case 'N': {
			max_mana = 0;
			break;
		}
		default:
		{
			cerr << "Invalid Class in CalcMaxMana" << endl;
			max_mana = 0;
			break;
		}
	}
	if (cur_mana > max_mana) {
		cur_mana = max_mana;
		SendManaUpdatePacket();
	}
	return max_mana;
}

void Client::UpdateAdmin() {
	admin = database.CheckStatus(account_id);
	UpdateWho();

	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
	appearance->spawn_id = GetID();
	appearance->type = 20;
	if (admin >= 100)
		appearance->parameter = 1;
	else
		appearance->parameter = 0;
	entity_list.QueueClients(this, outapp, false);
	delete outapp;
}

void Client::FindItem(char* search_criteria)
{
	int count=0;
	int iSearchLen = strlen(search_criteria)+1;
	char sName[36];
	char sCriteria[255];

	strcpy(sCriteria, search_criteria);
	strupr(sCriteria);
	Item_Struct* item = 0;
	char* pdest;
	for (int i=0; i < database.max_item; i++)
	{
		if (database.item_array[i] != 0)
		{
			item = (Item_Struct*)database.item_array[i];
			
			strcpy(sName, item->name);
			strupr(sName);

			pdest = strstr(sName, sCriteria);
			if (pdest != NULL) {
				Message(0, "  %i: %s", (int) item->item_nr, item->name);
				count++;
			}
			if (count == 20) {
				break;
			}
		}
	}
	if (count == 20)
		Message(0, "20 items shown...too many results.");
	else
		Message(0, "%i items found", count);
}

void Client::SummonItem(int16 item_id, sint8 charges) {
	Item_Struct* item = database.GetItem(item_id);
	if (item == 0) {
		Message(0, "No such item: %i", item_id);
	}
	else {
		pp.inventory[0] = item_id;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_SummonedItem;
		outapp->size = sizeof(SummonedItem_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memcpy(outapp->pBuffer, item, sizeof(Item_Struct));
		Item_Struct* item2 = (Item_Struct*) outapp->pBuffer;
		item2->equipSlot = 0;
		if (item->flag != 0x7669)
			item2->common.charges = charges;
		// This is so GM+ can trade anything to anybody...:)
		// (Marking everything Droppable
		if (this->Admin() >= 100)
			item2->nodrop = 1;
		QueuePacket(outapp);
		delete outapp;
	}
}

sint32 Client::SetMana(sint32 amount) {
	Mob::SetMana(amount);
	SendManaUpdatePacket();
	return cur_mana;
}

void Client::SendManaUpdatePacket() {
	if (!Connected())
		return;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ManaChange;
	outapp->size = sizeof(ManaChange_Struct);
	outapp->pBuffer = new uchar[outapp->size];

	ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
	manachange->new_mana = cur_mana;
	manachange->spell_id = 0;
	QueuePacket(outapp);
	delete outapp;
}

void Client::FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho)
{
	Mob::FillSpawnStruct(ns, ForWho);

	if (guildeqid == 0xFFFFFFFF) {
		ns->spawn.GuildID = 0xFFFF;
		ns->spawn.guildrank = -1;
	}
	else {
		ns->spawn.GuildID = guildeqid;
		if (guilds[guildeqid].rank[guildrank].warpeace || guilds[guildeqid].leader == account_id)
			ns->spawn.guildrank = 2;
		else if (guilds[guildeqid].rank[guildrank].invite || guilds[guildeqid].rank[guildrank].remove || guilds[guildeqid].rank[guildrank].motd)
			ns->spawn.guildrank = 1;
		else
			ns->spawn.guildrank = 0;
	}

	if (ForWho == this)
		ns->spawn.NPC = 10;
	else
		ns->spawn.NPC = 0;
//	ns->spawn.not_linkdead = 1;

	if (pp.gm==1)
		ns->spawn.GM = 1;
	ns->spawn.anon = pp.anon;

	ns->spawn.npc_armor_graphic = texture;
	ns->spawn.npc_helm_graphic = helmtexture;

	Item_Struct* item = 0;
	item = database.GetItem(pp.inventory[2]);
	if (item != 0) {
		ns->spawn.equipment[0] = item->common.material;
		ns->spawn.equipcolors[0] = item->common.color;
	}
	item = database.GetItem(pp.inventory[17]);
	if (item != 0) {
		ns->spawn.equipment[1] = item->common.material;
		ns->spawn.equipcolors[1] = item->common.color;
	}
	item = database.GetItem(pp.inventory[7]);
	if (item != 0) {
		ns->spawn.equipment[2] = item->common.material;
		ns->spawn.equipcolors[2] = item->common.color;
	}
	item = database.GetItem(pp.inventory[10]);
	if (item != 0) {
		ns->spawn.equipment[3] = item->common.material;
		ns->spawn.equipcolors[3] = item->common.color;
	}
	item = database.GetItem(pp.inventory[12]);
	if (item != 0) {
		ns->spawn.equipment[4] = item->common.material;
		ns->spawn.equipcolors[4] = item->common.color;
	}
	item = database.GetItem(pp.inventory[18]);
	if (item != 0) {
		ns->spawn.equipment[5] = item->common.material;
		ns->spawn.equipcolors[5] = item->common.color;
	}
	item = database.GetItem(pp.inventory[19]);
	if (item != 0) {
		ns->spawn.equipment[6] = item->common.material;
		ns->spawn.equipcolors[6] = item->common.color;
	}

	item = database.GetItem(pp.inventory[13]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[7] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[7] = 0;
		}
		ns->spawn.equipcolors[7] = 0;
	}
	item = database.GetItem(pp.inventory[14]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[8] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[8] = 0;
		}
		ns->spawn.equipcolors[8] = 0;
	}
	ns->spawn.haircolor = pp.haircolor;
	ns->spawn.beardcolor = pp.beardcolor;
	ns->spawn.eyecolor1 = pp.eyecolor1;
	ns->spawn.eyecolor2 = pp.eyecolor2;
	ns->spawn.hairstyle = pp.hairstyle;
	ns->spawn.wode = pp.wode;
	ns->spawn.luclinface = pp.luclinface;
}

int16 Client::GetItemAt(int16 in_slot) {
	if (in_slot <= 29) // Worn items and main inventory
		return pp.inventory[in_slot];
	else if (in_slot >= 250 && in_slot <= 329) // Main inventory's containers
		return pp.containerinv[in_slot-250];
	else if (in_slot >= 2000 && in_slot <= 2007) // Bank slots
		return pp.bank_inv[in_slot-2000];
	else if (in_slot >= 2030 && in_slot <= 2109) // Bank's containers
		return pp.bank_cont_inv[in_slot-2030];
	else {
		cerr << "Error: " << GetName() << ": GetItemAt(): Unknown slot: 0x" << hex << setw(4) << setfill('0') << in_slot << dec << endl;
		Message(0, "Error: GetItemAt(): Unknown slot: 0x%04x", in_slot);
	}
	return 0;
}

void Client::DeleteItemInInventory(uint32 slotid) {
	if (slotid <= 29) // Worn items and main inventory
		pp.inventory[slotid] = 0xFFFF;
	else if (slotid >= 250 && slotid <= 329) // Main inventory's containers
		pp.containerinv[slotid-250] = 0xFFFF;
	else if (slotid >= 2000 && slotid <= 2007) // Bank slots
		pp.bank_inv[slotid-2000] = 0xFFFF;
	else if (slotid >= 2030 && slotid <= 2109) // Bank's containers
		pp.bank_cont_inv[slotid-2030] =0xFFFF;
	else {
		cout << "Error in DeleteItemInInventory : Unknown slot" << endl;
		return;
	}
	APPLAYER* outapp = new APPLAYER(OP_MoveItem, sizeof(MoveItem_Struct));
	MoveItem_Struct* delitem = (MoveItem_Struct*)outapp->pBuffer;
	delitem->from_slot = slotid;
	delitem->to_slot = 0xFFFFFFFF;
	delitem->number_in_stack = 0;
//	DumpPacket(outapp);
	QueuePacket(outapp);
	delete outapp;
	Save();	
}

bool Client::GMHideMe(Client* client) {
	if (gmhideme) {
		if (client == 0)
			return true;
		else if (admin > client->Admin())
			return true;
		else
			return false;
	}
	else

		return false;
}

void Client::Duck() {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa_out->spawn_id = GetID();
	sa_out->type = 0x0e;
	sa_out->parameter = 111; // duck
	entity_list.QueueClients(this, outapp);
	delete outapp;
	appearance = 2;
}

void Client::Stand() {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa_out->spawn_id = GetID();
	sa_out->type = 0x0e;
	sa_out->parameter = 100; // stand
	entity_list.QueueClients(this, outapp);
	delete outapp;
	appearance = 0;
}

int16 Client::FindFreeInventorySlot(int16** pointer, bool ForBag, bool TryCursor) {
	int i;
	for (i=22; i<=29; i++) {
		if (pp.inventory[i] == 0xFFFF) {
			if (pointer != 0)
				*pointer = &pp.inventory[i];
			return i;
		}
	}
	if (!ForBag) {
		Item_Struct* item;
		for (i=22; i<=29; i++) {
			item = database.GetItem(pp.inventory[i]);
			if (item != 0 && item->type == 0x01) { // make sure it's a container
				for (int k=0; k<10; k++) {
					if (pp.containerinv[((i-22)*10) + k] == 0xFFFF) {
						if (pointer != 0)
							*pointer = &pp.containerinv[((i-22)*10) + k];
						return 250 + ((i-22)*10) + k;
					}
				}
			}
		}
	}
	if (TryCursor) {
		if (pp.inventory[0] == 0xFFFF) {
			*pointer = &pp.inventory[0];
			return 0;
		}
	}
	return 0xFFFF;
}

bool Client::PutItemInInventory(int16 slotid, int16 itemid, sint8 charges) {
	Item_Struct* item = database.GetItem(itemid);
	if (item == 0)
		return false;
	else
		return PutItemInInventory(slotid, item, charges);
}

bool Client::PutItemInInventory(int16 slotid, Item_Struct* item) {
	return PutItemInInventory(slotid, item, item->common.charges);
}

// Puts an item into the person's inventory
// Does NOT check if an item is already there
bool Client::PutItemInInventory(int16 slotid, Item_Struct* item, sint8 charges) {
	if (slotid <= 29)
		pp.inventory[slotid] = item->item_nr;
	else if (slotid >= 250 && slotid <= 329)
		pp.containerinv[slotid-250] = item->item_nr;
	else if (slotid >= 2000 && slotid <= 2007)
		pp.bank_inv[slotid-2000] = item->item_nr;
	else if (slotid >= 2030 && slotid <= 2109)
		pp.bank_cont_inv[slotid-2030] = item->item_nr;
	else
		return false;

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ItemTradeIn;
	outapp->size = sizeof(Item_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memcpy(outapp->pBuffer, item, outapp->size);
	Item_Struct* outitem = (Item_Struct*) outapp->pBuffer;
	outitem->equipSlot = slotid;
	if (item->flag != 0x7669)
		outitem->common.charges = charges;
	QueuePacket(outapp);
	delete outapp;

	return true;
}

void Client::ChangeLastName(char* in_lastname) {
	memset(pp.last_name, 0, sizeof(pp.last_name));
	if (strlen(in_lastname) >= sizeof(pp.last_name))
		strncpy(pp.last_name, in_lastname, sizeof(pp.last_name) - 1);
	else
		strcpy(pp.last_name, in_lastname);
	strcpy(lastname, pp.last_name);
	// Send name update packet here... once know what it is
}

char Client::GetCasterClass() {
	switch(class_)
	{
		case CLERIC:
		case PALADIN:
		case RANGER:
		case DRUID:
		case SHAMAN:
		case BEASTLORD:
			return 'W';
			break;

		case SHADOWKNIGHT:
		case BARD:
		case NECROMANCER:
		case WIZARD:
		case MAGICIAN:
		case ENCHANTER:
			return 'I';
			break;

		default:
			return 'N';
			break;
	}
}

void Client::SetGM(bool toggle) {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* gm = (SpawnAppearance_Struct*) outapp->pBuffer;
	gm->spawn_id=GetID();
	gm->type=20;
	if(toggle) {
		Save();
		pp.gm=1;
		gm->parameter=1;
		entity_list.QueueClients(this,outapp);
		delete outapp;
		Save();
		Message(13, "You are now a GM.");
	}
	else {
		Save();
		pp.gm=0;
		Save();
		gm->parameter=0;
		entity_list.QueueClients(this,outapp);
		delete outapp;
		Save();
		Message(13, "You are no longer a GM.");
	}
}
void Client::ReadBook(char txtfile[14]) {
	char* booktxt = database.GetBook(txtfile);
	if (booktxt != 0) {
		cout << "Just Sent Book for: " << txtfile << " Text: " << booktxt << endl;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_ReadBook;
		outapp->size = strlen(booktxt)+4;
		outapp->pBuffer = (uchar*) booktxt;
		QueuePacket(outapp);
		delete outapp;
	}
}

void Client::TakeMoneyFromPP(uint32 copper){
	
	sint32 tmp;
	uint32 tmp2 = 0;
	tmp = pp.copper - copper;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.copper = tmp;
		
	tmp = pp.silver - tmp2;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.silver = tmp;

	tmp = pp.gold - tmp2;
	if (tmp < 0){
		tmp2 = (abs(tmp)/10)+1;
		tmp = tmp + (tmp2*10);
	}
	pp.gold = tmp;

	tmp = pp.platinum - tmp2;
	if (tmp < 0){
		cout << "Error! Negativ amount of coins: " << this->name << endl;
		tmp = 0;
	}
	pp.platinum = tmp;
	Save();

	cout << "Debug: Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;
}

void Client::AddMoneyToPP(uint32 copper){
	uint32 tmp;
	uint32 tmp2;
	tmp = copper;
	tmp2 = tmp/1000;
	pp.platinum = pp.platinum + tmp2;
	tmp	= tmp - (tmp2* 1000);
	
	tmp2 = tmp/100;
	pp.gold = pp.gold + tmp2;
	tmp	= tmp - (tmp2* 100);
	
	tmp2 = tmp/10;
	pp.silver = pp.silver + tmp2;
	tmp	= tmp - (tmp2* 10);
	pp.copper = pp.copper + tmp;
	Save();
	cout << "Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;
}
void Client::AddMoneyToPP(uint32 copper, uint32 silver, uint32 gold,uint32 platinum){
	pp.platinum = pp.platinum + platinum;
	pp.gold = pp.gold + gold;
	pp.silver = pp.silver + silver;
	pp.copper = pp.copper + copper;
	Save();	
	cout << "Debug: client should have: plat: " << pp.platinum<<" gold: " << pp.gold << " silver: " << pp.silver << " copper: " << pp.copper << endl;

}
