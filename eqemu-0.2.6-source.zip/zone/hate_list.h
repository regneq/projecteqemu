#ifndef HATELIST_H
#define HATELIST_H

#include "../common/types.h"

class Mob;

class HateListElement
{
private:

	Mob*				ent;
	sint32				damage;
	sint32				hate;
	HateListElement*	next;

public:

	HateListElement(Mob* in_ent, sint32 in_dam, sint32 in_hate)
	{
		ent = in_ent;
		damage = in_dam;
		hate = in_hate;
		next = 0;
	}

	~HateListElement()
	{
		if (next != 0)
		{
			delete next;
		}
	}

	void AddHate(sint32 in_dam, sint32 in_hate) { damage += in_dam; hate += in_hate; }
	sint32 GetHate() { return hate; }
	Mob* GetEnt() { return ent; }

	HateListElement* GetNext()         { return  next; }
	void SetNext(HateListElement* n)	{ next = n; } 
	void DoFactionHits(int32 npc_id);
};

class HateList
{
private:
	HateListElement* first;

	HateListElement* Pop(Mob* in_ent);
public:
	HateList();
	~HateList();

	// Heko - added to return hate of given ent
	sint32 GetEntHate(Mob* ent);
	void Add(Mob* ent, sint32 in_dam = 0, sint32 in_hate = 0xFFFFFFFF);
	void RemoveEnt(Mob* ent);
	Mob* GetTop();
	void Whipe();
	void DoFactionHits(int32 npc_id);
};

#endif
