INSERT INTO variables VALUES ('decaytime 1 54','300');
INSERT INTO variables VALUES ('decaytime 55 100','1800');

alter table npc_types add column helmtexture tinyint(2) unsigned not null default 0 after texture;
alter table spawn2 change column x x float not null default 0;
alter table spawn2 change column y y float not null default 0;
alter table spawn2 change column z z float not null default 0;
alter table spawn2 add column heading float not null default 0 after z;
