#ifndef CLIENT_H
#define CLIENT_H

#include "../common/EQPacketManager.h"
#include "../common/linked_list.h"
#include "../common/timer.h"

#define CLIENT_TIMEOUT 30000

class Client
{
public:
	Client(int32 ip, int16 port, int send_socket);
    ~Client();
	
	bool	Process();
	void	ReceiveData(uchar* buf, int len);
	void	SendCharInfo();
	void	EnterWorld(bool TryBootup = true);
	void	QueuePacket(APPLAYER* app);

	int32	GetIP()			{ return ip; }
	int16	GetPort()		{ return port; }
	char*	GetZoneName()	{ return zone_name; }
	bool	IsWaitingForBootup()	{ return WaitingForBootup; }
private:
	int32	ip;
	int16	port;
	int		send_socket;
	int32	account_id;
	char	char_name[30];
	char	zone_name[16];
	Timer*	timeout_timer;
	bool	WaitingForBootup;

	CEQPacketManager packet_manager;	
};

class ClientList
{
public:
	ClientList();
	~ClientList();
	
	void	Add(Client* client);
	Client*	Get(int32 ip, int16 port);
	void	Process();

	void	ZoneBootup(char* zonename);
private:
#ifdef WIN32
	CRITICAL_SECTION CSListLock;
#else
	pthread_mutex_t CSListLock;
#endif
	LinkedList<Client*> list;
};

#endif
