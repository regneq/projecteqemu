Readme for LoginServer.ini

account and password are assigned by the Admin of your login server, but are not neccessary for operation. (They just let you get a green name and log into your own server when it's locked)

locked is either "true" or "false", for the initial status of your server.

there are two new TCP console commands, "lock" and "unlock".

If you dont want to uplink to the login server, just delete LoginServer.ini.