#include "spawn.h"
#include "entity.h"
#include "npc.h"
#include "zone.h"
#include "../common/database.h"

extern EntityList entity_list;
extern Zone* zone;
extern Database database;

Spawn::Spawn(int in_npc_type, int in_x, int in_y, int in_z, int in_respawn)
{
	npc_type = in_npc_type;
	x = in_x;
	y = in_y;
	z = in_z;

	timer = new Timer(in_respawn);
	timer->Trigger();
}

Spawn::~Spawn()
{
	delete timer;
}

void Spawn::Process()
{
	if (timer->Check())
	{
		timer->Disable();
		entity_list.AddNPC(new NPC(database.GetNPCType(npc_type), this, x, y, z, 0, false));
	}
}

void Spawn::Reset()
{
	timer->Start();
}
