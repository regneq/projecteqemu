#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

// Disgrace: for windows compile
#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
	#include <process.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include "../common/unix.h"
#endif

#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "client.h"
#include "../common/database.h"
#include "spdat.h"
#include "ClientList.h"
#include "../common/packet_functions.h"

extern WorldServer* worldserver;
extern Database database;
extern GuildRanks_Struct guilds[512];
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern ClientList client_list;

void seperation(char string[], char sep[], int ammount, int line);

struct login
{
char line[266];
};

struct login process[666];
char *token;

void seperation(char string[], char sep[], int ammount, int line) 
{ 
	int total = 0; 

	token = strtok(string,sep); 
	sprintf(process[line].line,"%s",token); 
	while(token != NULL && total <= ammount) 
	{ 
		total += 1; 
		/* While there are tokens in "string" */ 
		/* Get next token: */ 
		token = strtok(NULL,sep); 
		sprintf(process[line].line,"%s",token); 
	} 
} 

Client::Client(int32 in_ip, int16 in_port, int in_send_socket)
 : Mob("No name","",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
{
#ifdef WIN32
	InitializeCriticalSection(&CSPacketManager);
#else
/*	pthread_mutexattr_t attr;
	pthread_mutexattr_init(&attr);
	pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutex_init(&CSPacketManager, &attr);
	pthread_mutexattr_destroy(&attr);*/
	pthread_mutex_t CSPacketManager = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
	pthread_mutex_lock(&CSPacketManager);
	pthread_mutex_unlock(&CSPacketManager);
#endif
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	client_state = CLIENT_CONNECTING1;
	timeout_timer = new Timer(CLIENT_TIMEOUT);
	timeout_timer->Start();
	spellend_timer = new Timer(0);
	account_id = 0;
	admin = 0;
	strcpy(account_name, "");
	packet_manager.SetDebugLevel(1);

	target = 0;
	auto_attack = false;
	PendingGuildInvite = 0;
	zonesummon_x = -2;
	zonesummon_y = -2;
	zonesummon_z = -2;
	casting_spell_id = 0;

	position_timer = new Timer(500);
	position_timer->Disable();
	position_timer_counter = 0;
}

Client::~Client()
{
	client_list.Remove(this);
	UpdateWho(true);
	Save(); // This fails when database destructor is called first on shutdown
	delete timeout_timer;
	delete spellend_timer;
	delete position_timer;
#ifdef WIN32
	DeleteCriticalSection(&CSPacketManager);
#else
//	pthread_mutex_destroy(&CSPacketManager);
#endif
	return;
}

bool Client::Save()
{
	if (Connected()) {
		pp.x = x_pos;
		pp.y = y_pos;
		pp.z = z_pos; // Pyro: Fixed Z save bug
		pp.heading = heading;
		if (GetHP() <= 0 || GetHP() > 30000)
			pp.cur_hp = GetMaxHP();
		else
			pp.cur_hp = GetHP();
		if (!database.SetPlayerProfile(account_id, name, &pp))
		{
			cerr << "Failed to update player profile" << endl;
			return false;
		}
	}
	return true;
}

void Client::SendPacketQueue(bool Block) {
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
	sockaddr_in to;	
	memset((char *) &to, 0, sizeof(to));
	to.sin_family = AF_INET;
	to.sin_port = port;
	to.sin_addr.s_addr = ip;
#ifdef WIN32
// Quagmire - this didnt work, i think it's because i need the VC++ service pack5 for it...
//	if (Block) {
		EnterCriticalSection(&CSPacketManager);
/*	}
	else {
		if (!TryEnterCriticalSection(&CSPacketManager)) {
			return;
		}
	}*/
#else
	pthread_mutex_lock(&CSPacketManager);
#endif
	while(p = packet_manager.SendQueue.pop())
	{
		#ifdef BUILD_FOR_WINDOWS
			sendto(send_socket, (char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif

		delete[] p;
	}
	/************ Processing finished ************/

	if (!packet_manager.CheckActive())
	{
		cout << "Client disconnected (!pm.CA): " << GetName() << endl;
		client_state = DISCONNECTED;
//		return false;
	}

	packet_manager.CheckTimers();
	#ifdef WIN32
		LeaveCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_unlock(&CSPacketManager);
	#endif
}

APPLAYER* Client::PMOutQueuePop() {
	APPLAYER* tmp;
	#ifdef WIN32
		EnterCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_lock(&CSPacketManager);
	#endif
	tmp = packet_manager.OutQueue.pop();
	#ifdef WIN32
		LeaveCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_unlock(&CSPacketManager);
	#endif
	return tmp;
}

void Client::QueuePacket(APPLAYER* app, bool ack_req)
{
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
#ifdef LUCLIN
/*
	if (app != 0) {
		cout << " Sent opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << " size:" << app->size << endl;
		if (app->size > 0) DumpPacket(app);
	}
	else
		cout << " Sent closing packet" << endl;
*/
#endif
	if (app != 0) {
		if (app->size >= 31500) {
			cout << "WARNING: abnormal packet size. n='" << this->GetName() << "', o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	#ifdef WIN32
		EnterCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_lock(&CSPacketManager);
	#endif
	packet_manager.MakeEQPacket(app, ack_req);
	#ifdef WIN32
		LeaveCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_unlock(&CSPacketManager);
	#endif
}

void Client::ReceiveData(uchar* buf, int len)
{
	timeout_timer->Start();
	#ifdef WIN32
		EnterCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_lock(&CSPacketManager);
	#endif
	packet_manager.ParceEQPacket(len, buf);
	#ifdef WIN32
		LeaveCriticalSection(&CSPacketManager);
	#else
		pthread_mutex_unlock(&CSPacketManager);
	#endif
}

void Client::ChannelMessageReceived(int8 chan_num, int8 language, char* message, char* targetname) 
{
	cout << "Channel:" << (int)chan_num << " " << message << endl;

	if (message[0] == '#' && chan_num == 8) // Quagmire, changed commands to /say only
	{
		Seperator sep(message);
//		char* arg1 = strchr(message, ' ');

		if ((strcasecmp(sep.arg[0], "#level") == 0) && (admin >= 1))
		{
			if (target == 0)
			{
				Message(0, "Error: #Level: No target");
			}
			else if (sep.arg[1][0] == 0)
			{
				Message(0, "Usage: #level x");
			}
			else
			{
				int16 level = atoi(sep.arg[1]);
				if (level > 0 && level <= 100) {
					target->SetLevel(level);
				}
				else {
					Message(0, "Error: #Level: Invalid Level");
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#damage") == 0 && (admin >= 2)) {
			if (target==0) {
				Message(0, "Error: #Damage: No Target.");
			}
			else if (!sep.IsNumber(1)) {
				Message(0, "Usage: #damage x.");		
			}
			else {
				int16 nkdmg = atoi(sep.arg[1]);
				if (nkdmg > 32000)
					Message(0, "Enter a value less then 32000.");
				else
					target->Damage(this, nkdmg, 0xffff);
			}
		}
		else if (strcasecmp(sep.arg[0], "#heal") == 0 && (admin >= 1)) {
			if (target==0) {
				Message(0, "Error: #Heal: No Target.");
			} else {
				target->Heal();
			}
		}
		else if (strcasecmp(sep.arg[0], "#kill") == 0 && (admin >= 2)) {
			if (target==0) {
				Message(0, "Error: #Kill: No target.");
			} else {
				target->Death(this,32000,0xffff);
			}
		}
		else if(strncasecmp(message,"#timeofday",9) == 0 && admin >= 2) { // image
 			if(sep.arg[1][0] == 0) {
 				Message(0, "Usage: #timeofday <hour>");
 			}
 			else {
 					APPLAYER* outapp = new APPLAYER;
 					outapp = new APPLAYER;
 					outapp->opcode = OP_TimeOfDay;
 					outapp->pBuffer = new uchar[6];
 					outapp->size = 6;
 					outapp->pBuffer[0] = atoi(sep.arg[1]);
 					entity_list.QueueClients(this, outapp);
 					delete outapp;
 			}
 		} //This needs to be added to the database so it updates on login
		else if(strcasecmp(sep.arg[0],"#rain") == 0 && (admin >= 2)) {
			if (!(sep.arg[1][0] == '0' || sep.arg[1][0] == '1')) {
				Message(0, "Usage: #rain <0/1>. (0 = Off, 1 = On)");
			}
			else {
				if(sep.arg[1][0] == '1')	{
					Message(0, "Rain is being turned on.");
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Unknown
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x31; // rain
					entity_list.QueueClients(this, outapp);
					delete outapp;
					int weather = 0;
					weather = database.SetZoneWeather(zone->GetShortName(), sep.arg[1]);
					if(weather == 0) {
						Message(0, "Unable to update weather on database.");
					}
				}
				if(sep.arg[1][0] == '0')
				{
					Message(0, "Rain is being turned off.");
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Rain opcode
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x00; // rain
					entity_list.QueueClients(this, outapp);
					int weather = 0;
					weather = database.SetZoneWeather(zone->GetShortName(), sep.arg[1]);
					if(weather == 0)
					{
						Message(0, "Unable to update weather on database.");
					}
				}
			}
		}		
		else if (strcasecmp(sep.arg[0], "#shutdown")==0 && admin >= 4)
		{
			CatchSignal(2);
		}
		else if (strcasecmp(sep.arg[0], "#help") ==0)
		{
			Message(0, "EQEMu Commands:");
			Message(0, "  #itemsearch [id]  searches item database");
			Message(0, "  #summonitem [id]  summon item");
			Message(0, "  #goto  [x,y,z]    warps you to coords");
			Message(0, "  #zone [zonename]  zones to safepoint in zonename");
			Message(0, "  #zonestatus       shows what zones are up");
			Message(0, "  #guild            guild commands (type for more info)");
			Message(0, "  #showstats        Shows what the server thinks your stats are");
			Message(0, "  #iteminfo         Info about the item on your cursor");
			if(admin >= 1)
			{
				Message(0, "EQEMu Priviliged User Commands:");
				Message(0, "  #level  [id]    sets target level.");
				Message(0, "  #heal   (PC ONLY) completely heals target");
				Message(0, "  #spawn   lets you spawn a creature");
				Message(0, "  #mana               replenishes target PC mana");
			}
			if(admin >= 2)
			{
				Message(0, "EQEMu GM Commands:");
				Message(0, "  #damage [id]   inflicts damage upon target.");
				Message(0, "  #kill   (NPC ONLY) kills your selected target");
				Message(0, "  #showloot    shows the loot the targeted npc is packing");
				Message(0, "  #setxp   sets target exp");
				Message(0, "  #emote   sends emotish message, type for syntax");
				Message(0, "  #size [size]        sets your targets size");
				Message(0, "  /broadcast [text]   broadcasts text");
				Message(0, "  /pr [text]          sends text over GMSAY");
				Message(0, "  #FindSpell [spellname]");
				Message(0, "  #CastSpell [id]");
				Message(0, "  #Depop              Depops targeted NPC");
				Message(0, "  #DepopZone          Depops the zone");
				Message(0, "  #Repop [delay]      Repops the zone, optional delay in seconds");
			}
			if(admin >= 3)
			{
				Message(0, "EQEMu Lead-GM Commands:");
				Message(0, "  #summon [charname]  summons a player to you");
				Message(0, "  #kick [charname]    kicks player off of the server");
				Message(0, "  #invul [1/0]        makes the targeted player invul to attack");
				Message(0, "  #zoneshutdown [ZoneID | ZoneName]  shuts down the zoneserver");
				Message(0, "  #zonebootup [ZoneID] [ZoneName]    boots ZoneName on the zoneserver specified");
			}
			if(admin >= 4)
			{
				Message(0, "EQEMu ServerOP Commands:");
				Message(0, "  #shutdown        shuts down the server.");
				Message(0, "  #worldshutdown   shuts down the worldserver and all zones");
				Message(0, "  #flag [name] [status]  flags account with GM status");
				Message(0, "  #createacct [name] [password] [status]   creates a Everquest account.");
				Message(0, "  #delacct [name]   deletes an EQEmu account.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#setxp") == 0 && (admin >= 2))
		{
			if (sep.IsNumber(1)) {
				if (atoi(sep.arg[1]) > 9999999)
					Message(0, "Error: SetXP: Value too high.");
				else
					AddEXP (atoi(sep.arg[1]));
			}
			else
				Message(0, "Usage: #setxp number");
		}
		else if (strcasecmp(sep.arg[0], "#summonitem") == 0)
		{
			if (!sep.IsNumber(1)) {
				Message(0, "Usage: #summonitem x , x is an item number");
			}
			else {
				SummonItem(atoi(sep.arg[1]));
			}
		}
		else if ((strcasecmp(sep.arg[0], "#itemsearch") == 0) || (strcasecmp(sep.arg[0], "#search") == 0) || (strcasecmp(sep.arg[0], "#finditem") == 0))
		{
			if (sep.arg[1][0] == 0)
			{
				Message(0, "Usage: #itemsearch item OR #search item");
			} else {
				FindItem(sep.argplus[1]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#spawn") == 0 && (admin >= 1)) // Image's Spawn Code
		{
			cout << "Spawning:" << endl; 
			//Well it needs a name!!! 
			if(sep.arg[1][0] == 0) 
			{ 
				Message(0, "Format: #spawn firstname lastname(put (null) for no last name) race gender class level hp weaponnumber: spawns a npc those parameters."); 
			} 
			else 
			{ 
				//Lets see if someone didn't fill out the whole #spawn function properly 
				if ((!strcmp(sep.arg[2],"(null)")) || sep.arg[2][0] == 0)
					sprintf(sep.arg[2],""); 
				if (!sep.IsNumber(3))
					sprintf(sep.arg[3],"1"); 
				if (!sep.IsNumber(4))
					sprintf(sep.arg[4],"1"); 
				if (!sep.IsNumber(5))
					sprintf(sep.arg[5],"1"); 
				if (!sep.IsNumber(6))
					sprintf(sep.arg[6],"1"); 
				if (!sep.IsNumber(7))
					sprintf(sep.arg[7],"100"); 
				if (atoi(sep.arg[7]) > 32000)
					sprintf(sep.arg[7],"32000");
				if (!sep.IsNumber(8))
					sprintf(sep.arg[8],"0"); 

				char fullname[500];
				if (sep.arg[2][0] == 0)
					strcpy(fullname, sep.arg[1]);
				else
					sprintf(fullname,"%s_%s",sep.arg[1],sep.arg[2]); 

				// Well we want everyone to know what they spawned, right? 
				Message(0, "New spawn:"); 
				Message(0, "  First Name: %s",sep.arg[1]); 
				Message(0, "  Last Name: %s",sep.arg[2]); 
				Message(0, "  Race: %s",sep.arg[3]); 
				Message(0, "  Gender: %s",sep.arg[4]); 
				Message(0, "  Class: %s",sep.arg[5]); 
				Message(0, "  Level: %s",sep.arg[6]); 
				Message(0, "  Current/Max HP: %s",sep.arg[7]); 
				Message(0, "  Weapon Item Number: %s",sep.arg[8]); 
		
				//Time to create the NPC!! 
				NPCType* npc_type = new NPCType;
				memset(npc_type, 0, sizeof(NPCType));
				strcpy(npc_type->name,fullname); 
				strcpy(npc_type->lastname,sep.arg[2]); 
				npc_type->cur_hp = atoi(sep.arg[7]); 
				npc_type->max_hp = atoi(sep.arg[7]); 
				npc_type->race = atoi(sep.arg[3]); 
				npc_type->gender = atoi(sep.arg[4]); 
				npc_type->class_ = atoi(sep.arg[5]); 
				npc_type->deity= 1; 
				npc_type->level = atoi(sep.arg[6]); 
				npc_type->npc_id = 0;
				npc_type->loottable_id = 0;
				npc_type->texture = 0; // add this to be defineable when we find it in the packet
				npc_type->light = 0; 
				for (int i=0; i<9; i++) 
					npc_type->equipment[i] = atoi(sep.arg[8]); 
				

				NPC* npc = new NPC(npc_type, 0, x_pos, y_pos, z_pos, heading, false);

				// Disgrace: add some loot to it!
				npc->AddCash();
				int itemcount = (rand()%5) + 1;
				for (int counter=0; counter<itemcount; counter++)
				{
					Item_Struct* item = 0;
					while (item == 0)
						item = database.GetItem(rand() % 33000);						

					npc->AddItem(item, 0, 0);
				}
				
				entity_list.AddNPC(npc); 
			}
		}
		else if (strcasecmp(sep.arg[0], "#createacct") == 0 && admin >= 4)
		{
			if(sep.arg[4][0] == 0) {
				Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
			} else {
				if (database.CreateAccount(sep.arg[1],sep.arg[2],sep.arg[3]) == 0)
					Message(0, "Unable to create account.");
				else
					Message(0, "The account was created.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#delacct") == 0 && admin >= 4)
		{
			if(sep.arg[1][0] == 0) {
				Message(0, "Format: #delacct accountname");
			} else {
				if (database.DeleteAccount(name) == 0)
					Message(0, "Unable to delete account.");
				else
					Message(0, "The account was deleted."); 
			}
		}
		else if (strcasecmp(sep.arg[0], "#loc") == 0)
		{
			if (target != 0 && admin >= 2) {
				Message(0, "%s's Location: %1.1f, %1.1f, %1.1f, h=%1.1f", target->GetName(), target->GetX(), target->GetY(), target->GetZ(), target->GetHeading());
			}
			else
				Message(0, "Current Location: %1.1f, %1.1f, %1.1f, h=%1.1f", x_pos, y_pos, z_pos, GetHeading());
		}
		else if (strcasecmp(sep.arg[0], "#size") == 0 && (admin >= 2))	{
			if (!sep.IsNumber(1))
				Message(0, "Usage: #size [1 - 50]");
			else {
				int8 newsize = atoi(sep.arg[1]);
				if (newsize >= 85)
					Message(0, "Error: #size: Too large a size specified");
				else {
					APPLAYER* outapp = new APPLAYER;
					outapp->opcode = OP_SpawnAppearance;
					outapp->size = sizeof(SpawnAppearance2_Struct);
					outapp->pBuffer = new uchar[outapp->size];

					SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
					if (target != 0)
						appearance->spawn_id = target->GetID();
					else
						appearance->spawn_id = id;
					appearance->parameter = newsize;
					appearance->type = 29;
					entity_list.QueueClients(this, outapp, false);
					delete outapp;

					cout << "Changed size to: " << atoi(sep.arg[1]) << endl;
				}
			}
		}

		else if (strcasecmp(sep.arg[0], "#goto") == 0) // Pyro's goto function
		{
				if (!(sep.IsNumber(1) && sep.IsNumber(2) && sep.IsNumber(3)))
				{
					Message(0, "Usage: #goto [x y z].");
				} else {
					MovePC(0, atoi(sep.arg[1]), atoi(sep.arg[2]), (int16) atof(sep.arg[3])*10);
				}
		}
		else if (strcasecmp(sep.arg[0], "#worldshutdown") == 0 && admin >= 4) {
		// GM command to shutdown world server and all zone servers
			if (worldserver != 0) {
				Message(0, "Sending shutdown packet");
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ShutdownAll;
				pack->size=0;
				worldserver->SendPacket(pack);
				delete pack;
			}
			else
				Message(0, "Error: World server disconnected");
		}
		else if (strcasecmp(sep.arg[0], "#connectworldserver") == 0 && admin >= 2) {
		// GM command to reconnect to worldserver if connection is lost
#ifdef BUILD_FOR_WINDOWS
			_beginthread(ClientInitWorldServer, 0, this);
#else
			pthread_t thread;
			pthread_create(&thread, NULL, ClientInitWorldServer, this);
#endif
		}
		else if (strcasecmp(sep.arg[0], "#chat") == 0 && admin >= 4) {
			// sends any channel message to all zoneservers
			// Dev debug command, for learing channums
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #chat channum message");
			else {
				if (worldserver != 0)
					worldserver->SendChannelMessage(0, 0, (uint8) atoi(sep.arg[1]), 0, 0, sep.argplus[2]);
				else
					Message(0, "Error: World server disconnected");
			}
		}
		else if (strcasecmp(sep.arg[0], "#appearance") == 0 && admin >= 3) {
			// sends any appearance packet
			// Dev debug command, for appearance types
			if (sep.arg[2][0] == 0)
				Message(0, "Usage: #appearance type value");
			else {
				APPLAYER* outapp = new APPLAYER;
				outapp->opcode = OP_SpawnAppearance;
				outapp->size = sizeof(SpawnAppearance2_Struct);
				outapp->pBuffer = new uchar[outapp->size];

				SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
				if (target != 0) {
					appearance->spawn_id = target->GetID();
					Message(0, "Sending appearance packet: target=%s, type=%s, value=%s", target->GetName(), sep.arg[1], sep.arg[2]);
				}
				else {
					appearance->spawn_id = id;
					Message(0, "Sending appearance packet: target=self, type=%s, value=%s", sep.arg[1], sep.arg[2]);
				}
				appearance->parameter = atoi(sep.arg[2]);
				appearance->type = atoi(sep.arg[1]);
				entity_list.QueueClients(this, outapp, false);
				delete outapp;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zoneshutdown") == 0 && admin >= 3) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else if (sep.arg[1][0] == 0) {
				Message(0, "Usage: #zoneshutdown zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneShutdown;
				strcpy(s->adminname, this->GetName());
				if (sep.arg[1][0] >= '0' && sep.arg[1][0] <= '9')
					s->ZoneServerID = atoi(sep.arg[1]);
				else
					strcpy(s->zonename, sep.arg[1]);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonebootup") == 0 && admin >= 3) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else if (sep.arg[2][0] == 0) {
				Message(0, "Usage: #zonebootup ZoneServerID# zoneshortname");
			} else {
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneBootup;
				s->ZoneServerID = atoi(sep.arg[1]);
				strcpy(s->adminname, this->GetName());
				strcpy(s->zonename, sep.arg[2]);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#zonestatus") == 0) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				pack->opcode = ServerOP_ZoneStatus;
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char *) &pack->pBuffer[1], this->GetName());
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#emote") == 0 && (admin >= 3)) {
			if (sep.arg[3][0] == 0)
				Message(0, "Usage: #emote [name | world | zone] type# message");
			else {
				if (strcasecmp(sep.arg[1], "zone") == 0)
					entity_list.Message(0, atoi(sep.arg[2]), sep.argplus[3]);
				else if (worldserver == 0)
					Message(0, "Error: World server disconnected");
				else if (strcasecmp(sep.arg[1], "world") == 0)
					worldserver->SendEmoteMessage(0, 0, atoi(sep.arg[2]), sep.argplus[3]);
				else
					worldserver->SendEmoteMessage(sep.arg[1], 0, atoi(sep.arg[2]), sep.argplus[3]);
			}
		}
		else if (strcasecmp(sep.arg[0], "#zone") == 0) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #zone [zonename]");
			else if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ZonePlayer;
				pack->size = sizeof(ServerZonePlayer_Struct);
				pack->pBuffer = new uchar[pack->size];
				ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
				strcpy(szp->adminname, this->GetName());
				strcpy(szp->name, this->GetName());
				strcpy(szp->zone, sep.arg[1]);
				// Quagmire - set locs to escape code for safe point
				szp->x_pos = -1;
				szp->y_pos = -1;
				szp->z_pos = -1;
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
		else if (strcasecmp(sep.arg[0], "#summon") == 0 && (admin >= 2)) {
			if (sep.arg[1][0] == 0) {
				if (target != 0 && target->IsNPC()) {
					target->CastToNPC()->GMMove(x_pos, y_pos, z_pos, heading);
				}
				else if (admin >= 3)
					Message(0, "Usage: #summon [charname]");
				else
					Message(0, "You need a NPC target for this command");
			}
			else if (admin >= 3) {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					client->Message(15, "You have been summoned by the gods!");
					Message(0, "Summoning %s to %1.1f, %1.1f, %1.1f", sep.arg[1], this->x_pos, this->y_pos, this->z_pos);
					client->MovePC(0, this->x_pos, this->y_pos, this->z_pos);
				}
				else if (worldserver == 0)
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_ZonePlayer;
					pack->size = sizeof(ServerZonePlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
					strcpy(szp->adminname, this->GetName());
					strcpy(szp->name, sep.arg[1]);
					strcpy(szp->zone, zone->GetShortName());
					szp->x_pos = x_pos;
					szp->y_pos = y_pos;
					szp->z_pos = z_pos;
					worldserver->SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#kick") == 0 && (admin >= 3)) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #kick [charname]");
			else {
				Client* client = entity_list.GetClientByName(sep.arg[1]);
				if (client != 0) {
					client->Message(0, "You have been kicked by %s",this->GetName());
					client->Kick();
					this->Message(0, "Kick: local: kicking %s", sep.arg[1]);
				}
				else if (worldserver == 0)
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_KickPlayer;
					pack->size = sizeof(ServerKickPlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
					strcpy(skp->adminname, this->GetName());
					strcpy(skp->name, sep.arg[1]);
					worldserver->SendPacket(pack);
					delete pack;
				}
			}
		}
		else if (strcasecmp(sep.arg[0], "#guild") == 0 || strcasecmp(sep.arg[0], "#guilds") == 0) {
			GuildCommand(sep);
		}
		else if (strcasecmp(sep.arg[0], "#flag") == 0)
		{
			if(sep.arg[2][0] == 0 || !(admin >= 4)) {
				this->UpdateAdmin();
				Message(0, "Refreshed your admin flag from DB.");
			}
			else if (!sep.IsNumber(2) || atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > 255)
				Message(0, "Usage: #flag [accname] [status] (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
			else {
				if (!database.SetGMFlag(sep.arg[1], sep.arg[2]))
					Message(0, "Unable to set GM Flag.");
				else {
					Message(0, "Set GM Flag on account.");
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_FlagUpdate;
					pack->size = strlen(sep.arg[1]) + 1;
					pack->pBuffer = new uchar[pack->size];
					memset(pack->pBuffer, 0, pack->size);
					strcpy((char*) pack->pBuffer, sep.arg[1]);
					worldserver->SendPacket(pack);
					delete pack;
				}
			}
		}
		//Disgrace: a make due function to give you almost full mana (almost accurately..)
		else if (strcasecmp(sep.arg[0], "#mana") == 0 && (admin >= 1))
		{
			if (target == 0 || !target->IsClient())
				this->GMRestoreMana();
			else
				target->CastToClient()->GMRestoreMana();
		}
		else if (strcasecmp(sep.arg[0], "#showloot") == 0 && admin >= 2) {
			if (target == 0)
				Message(0, "Error: No target");
			else if (!target->IsNPC())
				Message(0, "Error: Target isnt a npc");
			else
				target->CastToNPC()->QueryLoot(this);
		}
		else if (strcasecmp(sep.arg[0], "#time") == 0) {
			Message(0, "Timer::GetCurrentTime() = %d", Timer::GetCurrentTime());
		}
		else if (strcasecmp(sep.arg[0], "#FindSpell") == 0 && admin >= 2) {
			if (sep.arg[1][0] == 0)
				Message(0, "Usage: #FindSpell [spellname]");
			else if (!spells_loaded)
				Message(0, "Spells not loaded");
			else {
				int count=0;
				int iSearchLen = strlen(sep.argplus[1])+1;
				char sName[64];
				char sCriteria[65];
				strncpy(sCriteria, sep.argplus[1], 64);
				strupr(sCriteria);
				for (int i = 0; i < SPDAT_RECORDS; i++)
				{
					if (spells[i].name[0] != 0) {
						strcpy(sName, spells[i].name);

						strupr(sName);
						char* pdest = strstr(sName, sCriteria);
						if ((pdest != NULL) && (count <=20)) {
							Message(0, "  %i: %s", i, spells[i].name);
							count++;
						}
						else if (count > 20)
							break;
					}
				}
				if (count > 20)
					Message(0, "20 spells found... max reached.");
				else
					Message(0, "%i spells found.", count);
			}
		}
		else if ((strcasecmp(sep.arg[0], "#CastSpell") == 0 || strcasecmp(sep.arg[0], "#Cast") == 0) && admin >= 2) {
			if (!sep.IsNumber(1))
				Message(0, "Usage: #CastSpell spellid");
			else { 
				int16 spellid = atoi(sep.arg[1]);
				if (spellid >= SPDAT_RECORDS)
					Message(0, "Error: #CastSpell: Arguement out of range");
				else {
					if (target == 0)
						SpellFinished(spellid, 0, 10, 0);
					else
						SpellFinished(spellid, target->GetID(), 10, 0);
				}
			}
		}
		else if ((strcasecmp(sep.arg[0], "#invul") == 0 || strcasecmp(sep.arg[0], "#invulnerable") == 0) && admin >= 3) {
			Client* client = this;
			if (target) {
				if (target->IsClient())
					client = target->CastToClient();
			}
			if (sep.arg[1][0] == '1') {
				client->Message(0, "You are now invulnerable from attack.");
				client->invulnerable = true;
			}
			else if (sep.arg[1][0] == '0') {
				client->Message(0, "You are no longer invulnerable from attack.");
				client->invulnerable = false;
			}
			else
				Message(0, "Usage: #invulnerable [1/0]");
		}
		else if (strcasecmp(sep.arg[0], "#setskill") == 0 && (admin >= 2)) {
			if (target == 0) {
				Message(0, "Error: #setskill: No target.");
			}
			else if (!sep.IsNumber(1)) {
				Message(0, "Usage: #setskill skill x ");
				Message(0, "       skill = 0 to 74");
				Message(0, "       x = 0 to 255");
			}
			else if (!sep.IsNumber(2)) {
				Message(0, "Usage: #setskill skill x ");
				Message(0, "       skill = 0 to 74");
				Message(0, "       x = 0 to 255");
			}
			else {
				//pp.skills[atoi(sep.arg[1])] = (int8)atoi(sep.arg[2]);
				cout << "Setting " << target->GetName() << " skill " << sep.arg[1] << " to " << sep.arg[2] << endl;
				int skill_num = atoi(sep.arg[1]);
				int8 skill_id = (int8)atoi(sep.arg[2]);
				target->SetSkill(skill_num, skill_id);
			}
		}
		else if (strcasecmp(sep.arg[0], "#save") == 0 && admin >= 2) {
			if (target == 0)
				Message(0, "Error: no target");
			else if (!target->IsClient())
				Message(0, "Error: target not a client");
			else if	(target->CastToClient()->Save())
				Message(0, "%s successfully saved.", target->GetName());
			else
				Message(0, "Manual save for %s failed.", target->GetName());
		}
		else if (strcasecmp(sep.arg[0], "#showstats") == 0) {
			if (target != 0 && admin >= 2)
				target->ShowStats(this);
			else
				this->ShowStats(this);
		}
		else if (strcasecmp(sep.arg[0], "#iteminfo") == 0) {
			Item_Struct* item = database.GetItem(pp.inventory[0]);
			if (item == 0)
				Message(0, "Error: You need an item on your cursor for this command");
			else {
				Message(0, "ID: %i Name: %s", item->item_nr, item->name);
				Message(0, "  Lore: %s  ND: %i  NS: %i", item->lore, item->nodrop, item->nosave);
				Message(0, "  IDF: %s  Size: %i  Weight: %i  Flag: %04x  icon_nr: %i", item->idfile, item->size, item->weight, (int16) item->flag, (int16) item->icon_nr);
				if (item->flag == 0x7669)
					Message(0, "  This item is a Book: %s", item->book.file);
				else {
					Message(0, "  Magic: %i  SpellID0: %i  Level0: %i  Charges: %i", item->common.magic, item->common.spellId0, item->common.level0, item->common.charges);
					Message(0, "  SpellId: %i  Level: %i  EffectType: 0x%02x  CastTime: %.2f", item->common.spellId, item->common.level, (int8) item->common.effecttype, (double) item->common.casttime/1000);
					Message(0, "  Material: 0x02%x  Color: 0x%08x", item->common.material, item->common.color);
					Message(0, "  U0187: 0x%02x%02x  U0192: 0x%02x  U0198: 0x%02x%02x  U0204: 0x%02x%02x  U0210: 0x%02x%02x  U0214: 0x%02x%02x%02x", item->common.unknown0187[0], item->common.unknown0187[1], item->common.unknown0192, item->common.unknown0198[0], item->common.unknown0198[1], item->common.unknown0204[0], item->common.unknown0204[1], item->common.unknown0210[0], item->common.unknown0210[1], (int8) item->common.normal.unknown0214[0], (int8) item->common.normal.unknown0214[1], (int8) item->common.normal.unknown0214[2]);
					Message(0, "  U0222[0-9]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0222[0], (int8) item->common.unknown0222[1], (int8) item->common.unknown0222[2], (int8) item->common.unknown0222[3], (int8) item->common.unknown0222[4], (int8) item->common.unknown0222[5], (int8) item->common.unknown0222[6], (int8) item->common.unknown0222[7], (int8) item->common.unknown0222[8], (int8) item->common.unknown0222[9]);
					Message(0, "  U0236[ 0-15]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[0], (int8) item->common.unknown0236[1], (int8) item->common.unknown0236[2], (int8) item->common.unknown0236[3], (int8) item->common.unknown0236[4], (int8) item->common.unknown0236[5], (int8) item->common.unknown0236[6], (int8) item->common.unknown0236[7], (int8) item->common.unknown0236[8], (int8) item->common.unknown0236[9], (int8) item->common.unknown0236[10], (int8) item->common.unknown0236[11], (int8) item->common.unknown0236[12], (int8) item->common.unknown0236[13], (int8) item->common.unknown0236[14], (int8) item->common.unknown0236[15]);
					Message(0, "  U0236[16-31]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[16], (int8) item->common.unknown0236[17], (int8) item->common.unknown0236[18], (int8) item->common.unknown0236[19], (int8) item->common.unknown0236[20], (int8) item->common.unknown0236[21], (int8) item->common.unknown0236[22], (int8) item->common.unknown0236[23], (int8) item->common.unknown0236[24], (int8) item->common.unknown0236[25], (int8) item->common.unknown0236[26], (int8) item->common.unknown0236[27], (int8) item->common.unknown0236[28], (int8) item->common.unknown0236[29], (int8) item->common.unknown0236[30], (int8) item->common.unknown0236[31]);
					Message(0, "  U0236[32-47]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[32], (int8) item->common.unknown0236[33], (int8) item->common.unknown0236[34], (int8) item->common.unknown0236[35], (int8) item->common.unknown0236[36], (int8) item->common.unknown0236[37], (int8) item->common.unknown0236[38], (int8) item->common.unknown0236[39], (int8) item->common.unknown0236[40], (int8) item->common.unknown0236[41], (int8) item->common.unknown0236[42], (int8) item->common.unknown0236[43], (int8) item->common.unknown0236[44], (int8) item->common.unknown0236[45], (int8) item->common.unknown0236[46], (int8) item->common.unknown0236[47]);
					Message(0, "  U0236[48-55]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->common.unknown0236[48], (int8) item->common.unknown0236[49], (int8) item->common.unknown0236[50], (int8) item->common.unknown0236[51], (int8) item->common.unknown0236[52], (int8) item->common.unknown0236[53], (int8) item->common.unknown0236[54], (int8) item->common.unknown0236[55]);
				}
				Message(0, "  U0103[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[0], (int8) item->unknown0103[1], (int8) item->unknown0103[2], (int8) item->unknown0103[3], (int8) item->unknown0103[4], (int8) item->unknown0103[5], (int8) item->unknown0103[6], (int8) item->unknown0103[7], (int8) item->unknown0103[8], (int8) item->unknown0103[9], (int8) item->unknown0103[10], (int8) item->unknown0103[11]);
				Message(0, "  U0103[12-21]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0103[12], (int8) item->unknown0103[13], (int8) item->unknown0103[14], (int8) item->unknown0103[15], (int8) item->unknown0103[16], (int8) item->unknown0103[17], (int8) item->unknown0103[18], (int8) item->unknown0103[19], (int8) item->unknown0103[20], (int8) item->unknown0103[21]);
				Message(0, "  U0144[ 0-11]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[0], (int8) item->unknown0144[1], (int8) item->unknown0144[2], (int8) item->unknown0144[3], (int8) item->unknown0144[4], (int8) item->unknown0144[5], (int8) item->unknown0144[6], (int8) item->unknown0144[7], (int8) item->unknown0144[8], (int8) item->unknown0144[9], (int8) item->unknown0144[10], (int8) item->unknown0144[11]);
				Message(0, "  U0144[12-23]: 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x 0x%02x%02x", (int8) item->unknown0144[12], (int8) item->unknown0144[13], (int8) item->unknown0144[14], (int8) item->unknown0144[15], (int8) item->unknown0144[16], (int8) item->unknown0144[17], (int8) item->unknown0144[18], (int8) item->unknown0144[19], (int8) item->unknown0144[20], (int8) item->unknown0144[21], (int8) item->unknown0144[22], (int8) item->unknown0144[23]);
				Message(0, "  U0144[24-27]: 0x%02x%02x 0x%02x%02x  U0129: 0x%02x", (int8) item->unknown0144[24], (int8) item->unknown0144[25], (int8) item->unknown0144[26], (int8) item->unknown0144[27], (int8) item->unknown0129);
			}
		}
		else if (strcasecmp(sep.arg[0], "#Depop") == 0 && admin >= 2) {
			if (target == 0 || !target->IsNPC())
				Message(0, "You must have a target for this command. (maybe you meant #depopzone?)");
			else {
				Message(0, "Depoping '%s'.", target->GetName());
				target->CastToNPC()->Depop();
			}
		}
		else if (strcasecmp(sep.arg[0], "#DepopZone") == 0 && admin >= 2) {
			zone->Depop();
			Message(0, "Zone depoped.");
		}
		else if (strcasecmp(sep.arg[0], "#Repop") == 0 && admin >= 2) {
			if (sep.IsNumber(1)) {
				zone->Repop(atoi(sep.arg[1])*1000);
				Message(0, "Zone depoped. Repop in %i seconds", atoi(sep.arg[1]));
			}
			else {
				zone->Repop();
				Message(0, "Zone depoped. Repoping now.");
			}
		}
		else if (strcasecmp(sep.arg[0], "#spawnstatus") == 0 && admin >= 2) {
			zone->SpawnStatus(this);
		}
		else if (strcasecmp(sep.arg[0], "#doanim") == 0) {
			if (!sep.IsNumber(1)) {
				Message(0, "Usage: #DoAnim [number]");
			}
			else {
				if (admin >= 2) {
					if (target == 0)
						Message(0, "Error: You need a target.");
					else
						target->DoAnim(atoi(sep.arg[1]));
				}
				else
					DoAnim(atoi(sep.arg[1]));
			}
		}
		else {
			Message(0, "Command does not exist");
		}
	} else {
		if (chan_num == 3 || chan_num == 4 || chan_num == 8) // Shout, auction, say
		{
			entity_list.ChannelMessage(this, chan_num, language, message);
		}
		else if (chan_num == 5) // Quagmire - moved ooc to worldwide since moved guildsay to, err, guilds
		{
			entity_list.ChannelMessage(this, chan_num, language, message);
		}
		else if (chan_num == 7 && strcasecmp(targetname, "Broadcast") == 0) {
			// Cant get GM flag clientside for /broadcast
			// This is a workaround so you can use "/tell broadcast"
			if (worldserver == 0)
				Message(0, "Error: World server dirconnected");
			else if (!(admin >= 2))
				Message(0, "Error: Only GMs can use broadcast");
			else {
				char tmpName[23];
				tmpName[0] = ' '; // add a space before your name so you can see your own /broad
				strcpy(&tmpName[1], this->GetName());
				worldserver->SendChannelMessage(tmpName, 0, 6, 0, language, message);
			}
		}
		else if (chan_num == 0) {
			// 0 = guildsay
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else if (guilddbid == 0 || guildeqid >= 512)
				Message(0, "Error: You arent in a guild.");
			else if (!guilds[guildeqid].rank[guildrank].speakgu)
				Message(0, "Error: You dont have permission to speak to the guild.");
			else
				worldserver->SendChannelMessage(this->GetName(), targetname, chan_num, guilddbid, language, message);
		}
		else if (chan_num == 7) {
			// 7 = tell
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else
				worldserver->SendChannelMessage(this->GetName(), targetname, chan_num, 0, language, message);
		}
		else if (chan_num == 6 || chan_num == 11) {
			// 6 = broadcast, 11 = GMSAY
			if (worldserver == 0)
				Message(0, "Error: World server dirconnected");
			else if (!(admin >= 2))
				Message(0, "Error: Only GMs can use this channel");
			else
				worldserver->SendChannelMessage(this->GetName(), targetname, chan_num, 0, language, message);
		}
		else {
			Message(0, "Channel not implemented");
        } 

	}
}

void Client::ChannelMessageSend(char* from, char* to, int8 chan_num, int8 language, char* message, ...) {
	if ((chan_num == 11 || chan_num == 10) && !(this->Admin() >= 2)) // dont need to send /pr & /pet to everybody
		return;
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER app;

	app.opcode = OP_ChannelMessage;
	app.size = sizeof(ChannelMessage_Struct)+strlen(buffer)+1;
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	ChannelMessage_Struct* cm = (ChannelMessage_Struct*) app.pBuffer;
	if (from == 0)
		strcpy(cm->sender, "ZServer");
	else if (from[0] == 0)
		strcpy(cm->sender, "ZServer");
	else
		strcpy(cm->sender, from);
	if (to != 0)
		strcpy((char *) cm->targetname, to);
	else
		cm->targetname[0] = 0;
	cm->language = language;
	cm->chan_num = chan_num;
//cm->cm_unknown4[0] = 0xff;
	cm->cm_unknown4[1] = 0xff; // One of these tells the client how well we know the language
	cm->cm_unknown4[2] = 0xff;
	cm->cm_unknown4[3] = 0xff;
	cm->cm_unknown4[4] = 0xff;
	strcpy(&cm->message[0], buffer);

	if (chan_num == 7 && from != 0) 
	{ 
		strcpy(cm->targetname, pp.name); 
	} 
	QueuePacket(&app);
}

void Client::Message(int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER* app = new APPLAYER;
	app->opcode = OP_SpecialMesg;
	app->size = 4+strlen(buffer)+1;
	app->pBuffer = new uchar[app->size];
	SpecialMesg_Struct* sm=(SpecialMesg_Struct*)app->pBuffer;
	sm->msg_type = type;
	strcpy(sm->message, buffer);
	QueuePacket(app);
	delete app;	
}

void Client::SendHPUpdate()	
{
	APPLAYER* app = new APPLAYER;
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnHPUpdate_Struct* shu = (SpawnHPUpdate_Struct*)app->pBuffer;
	shu->spawn_id = id;
	shu->shu_unknown1 = 0;
// Quagmire - this is fucked up, but it's the way live servers do it
// not sure if need to subtract HP from stam buffs and
// also not sure if need to subtract from max hp or not
	shu->cur_hp = GetHP() - bonuses->HP;
	shu->shu_unknown2 = 0;
	shu->max_hp = max_hp;
	shu->shu_unknown3 = 0;

/*
	app->opcode = OP_SpawnAppearance;
	app->size = sizeof(SpawnAppearance_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
	sa->spawn_id = id;
sa->sa_unknown1 = 0;
	sa->type = 0x11;
sa->sa_unknown2 = 0xc34a;
	sa->parameter = GetHP();
*/
	entity_list.QueueClients(this, app);
	QueuePacket(app);
	delete app;
}

void Client::SetMaxHP()
{
	APPLAYER* app = new APPLAYER;
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnHPUpdate_Struct* shu = (SpawnHPUpdate_Struct*)app->pBuffer;
	shu->shu_unknown1 = 0;
	max_hp = GetMaxHP();
	SetHP(GetMaxHP());
	shu->shu_unknown2 = 0;
	shu->shu_unknown3 = 0;
	SendHPUpdate();
	Save();
	QueuePacket(app);
	delete app;
}

void Client::AddEXP(int32 add_exp)
{
	SetEXP(GetEXP() + add_exp);
}

void Client::SetEXP(int32 set_exp)
{
	int16 check_level = GetLevel()+1;

	while (set_exp > GetEXPForLevel(check_level)) {
		check_level++;
		if (check_level > 100) { // Quagmire - this was happening because GetEXPForLevel returned 0 on unknown race/class combo, Changed it to return 0xFFFFFFFF on error
			check_level = GetLevel()+1;
			break;
		}
	}

	if (GetLevel() != check_level-1)
	{
		if (GetLevel() == check_level-2)
		{
			Message(15, "You have gained a level! Welcome to level %i!", check_level-1);
		}
		else
		{
			Message(15, "Welcome to level %i!", check_level-1);
		}
		SetLevel(check_level-1);
		UpdateWho();
	}
	else
	{
		Message(15, "You gain experience!!");
		APPLAYER app;
		app.opcode = OP_ExpUpdate;
		app.size = sizeof(ExpUpdate_Struct);
		app.pBuffer = new uchar[app.size];
		ExpUpdate_Struct* eu = (ExpUpdate_Struct*)app.pBuffer;
		eu->exp = set_exp;
		QueuePacket(&app);		
	}

	pp.exp = set_exp;
}

void Client::MovePC(char* zonename, sint16 x, sint16 y, sint16 z)
{        
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_GMSummon;
	outapp->size = sizeof(GMSummon_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	GMSummon_Struct* gms = (GMSummon_Struct*) outapp->pBuffer;
	strcpy(gms->charname, this->GetName());
	strcpy(gms->gmname, this->GetName());
	if (zonename == 0)
		strcpy(gms->zonename, zone->GetShortName());
	else {
		strcpy(gms->zonename, zonename);
		if (strcasecmp(zonename, zone->GetShortName()) != 0) {
			zonesummon_x = x;
			zonesummon_y = y;
			zonesummon_z = z;
		}
	}
	gms->x = x;
	gms->y = y;
	gms->z = z/10;
	int8 tmp[16] = { 0x7C, 0xEF, 0xFC, 0x0F, 0x80, 0xF3, 0xFC, 0x0F, 0xA9, 0xCB, 0x4A, 0x00, 0x7C, 0xEF, 0xFC, 0x0F };
	memcpy(gms->unknown2, tmp, 16);
	int8 tmp2[4] = { 0xE0, 0xE0, 0x56, 0x00 };
	memcpy(gms->unknown3, tmp2, 4);
	QueuePacket(outapp);
	delete outapp;
}


void Client::SetLevel(int8 set_level)
{
	if (GetEXPForLevel(set_level) == 0xFFFFFFFF) {
		cout << "Error in SetLevel" << endl;
	}

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_LevelUpdate;
	outapp->size = sizeof(LevelUpdate_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	LevelUpdate_Struct* lu = (LevelUpdate_Struct*)outapp->pBuffer;
	lu->level = set_level;
	lu->level_old = level;
	lu->exp = GetEXPForLevel(set_level);
	QueuePacket(outapp);
	delete outapp;	
	outapp = new APPLAYER;
	outapp->opcode = OP_SpawnAppearance;
	outapp->size = sizeof(SpawnAppearance2_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
	appearance->spawn_id = id;
	appearance->type = 0x01; // /who level change
	appearance->parameter = set_level;
	entity_list.QueueClients(this, outapp, false);
	delete outapp;

	pp.exp = lu->exp;
	pp.level = set_level;
	level = set_level;

	cout << "Setting Level: " << GetName() << " = " << (int16) set_level << endl;

	Message(15, "Welcome to level %i!", set_level);
	UpdateWho();

//	ChannelMessageSend(0, 0, 7, 0, "Your level changed, please check if your max hp is %i. If not do a bug report with class, level, stamina and max hp", GetMaxHP());
}
//                           hum       bar    eru     elf     hie     def     hef     dwa     tro     ogr     hal    gno     iks,    vah
float  race_modifiers[14] =  {100.0f, 105.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 100.0f, 120.0f, 115.0f, 95.0f, 100.0f, 120.0f, 100.0f}; // Quagmire - Guessed on iks and vah
//                           war  cle  pal  ran  shd  dru  mnk  brd  rog  shm  nec  wiz  mag  enc
float class_modifiers[14] = { 9.0f, 10.0f, 14.0f, 14.0f, 14.0f, 10.0f, 12.0f, 14.0f, 9.05f, 10.0f, 11.0f, 11.0f, 11.0f, 11.0f};

/*
	Note: The client calculates exp separatly, we cant change this function
*/
uint32 Client::GetEXPForLevel(int16 check_level)
{
int8 tmprace = GetRace();
	if (tmprace == IKSAR) // Quagmire, set these up so they read from array right
		tmprace = 13;
	else if (tmprace == VAHSHIR)
		tmprace = 14;

	tmprace -= 1;
	if (GetRace() < 1 || GetRace() > 14 || GetClass() < 1 || GetClass() > 14)
		return 0xFFFFFFFF;

	if (check_level < 31)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]);
	else if (check_level < 36)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.1);
	else if (check_level < 41)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.2);
	else if (check_level < 46)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.3);
	else if (check_level < 52)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.4);
	else if (check_level < 53)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.5);
	else if (check_level < 54)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.6);
	else if (check_level < 55)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.7);
	else if (check_level < 56)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*1.9);
	else if (check_level < 57)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.1);
	else if (check_level < 58)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.3);
	else if (check_level < 59)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.5);
	else if (check_level < 60)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*2.7);
	else if (check_level < 61)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.0);
	else
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[tmprace]*3.1);
}

/*
	Note: The client calculates max hp separatly, we cant change this function
*/
sint32 Client::GetBaseHP()
{
	int8 multiplier = 0;

	switch(GetClass())
	{
		case WARRIOR:
			if (GetLevel() < 20)
				multiplier = 22;
			else if (GetLevel() < 30)
				multiplier = 23;
			else if (GetLevel() < 40)
				multiplier = 25;
			else if (GetLevel() < 53)
				multiplier = 27;
			else if (GetLevel() < 57)
				multiplier = 28;
			else
				multiplier = 30;
			break;

		case DRUID:
		case CLERIC:
		case SHAMAN:
			multiplier = 15;
			break;

		case PALADIN:
		case SHADOWKNIGHT:
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				 multiplier = 22;
			else if (GetLevel() < 51)
				 multiplier = 23;
			else if (GetLevel() < 56)
				 multiplier = 24;
			else if (GetLevel() < 60)
				 multiplier = 25;
			else
				 multiplier = 26;
			break;

		case MONK:
		case BARD:
		case ROGUE:
//		case BEASTLORD:
			if (GetLevel() < 51)
				multiplier = 18;
			else if (GetLevel() < 58)
				multiplier = 19;
			else
				multiplier = 20;				
			break;

		case RANGER:
			if (GetLevel() < 58)
				multiplier = 20;
			else
				multiplier = 21;			
			break;

		case MAGICIAN:
		case WIZARD:
		case NECROMANCER:
		case ENCHANTER:
			multiplier = 12;
			break;

		default:
			cerr << "Invalid class in Client::GetMaxHP" << endl;
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				multiplier = 22;
			else if (GetLevel() < 51)
				multiplier = 23;
			else if (GetLevel() < 56)
				multiplier = 24;
			else if (GetLevel() < 60)
				multiplier = 25;
			break;
	}

	if (multiplier == 0)
	{
		cerr << "Multiplier == 0 in Client::GetMaxHP" << endl;
	}

//	cout << "m:" << (int)multiplier << " l:" << (int)GetLevel() << " s:" << (int)GetSTA() << endl;

	return 5+multiplier*GetLevel()+multiplier*GetLevel()*GetSTA()/300;
}

int8 Client::GetSkill(int skill_num)
{
	return pp.skills[skill_num];
}

/* 
	Added 12-29-01 -socket
*/
void Client::SetSkill(int skill_num, int8 skill_id)
{
	pp.skills[skill_num] = skill_id;
}

/*
	This should return the combined AC of all the items the player is wearing.
*/
int16 Client::GetRawItemAC()
{
	return 0;
}

/*
	This is a testing formula for AC, the value this returns should be the same value as the one the client shows...
	ac1 and ac2 are probably the damage migitation and damage avoidance numbers, not sure which is which.
	I forgot to include the iksar defense bonus and i cant find my notes now...
	AC from spells are not included (cant even cast spells yet..)
*/
int16 Client::GetCombinedAC_TEST()
{
	int ac1;

	ac1 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac1 = ac1*4/3;
	}
	ac1 += GetSkill(DEFENSE)/3;
	if (GetAGI() > 70)
	{
		ac1 += GetAGI()/20;
	}

	int ac2;

	ac2 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac2 = ac2*4/3;
	}
	ac2 += GetSkill(DEFENSE)*400/255;

	int combined_ac = (ac1+ac2)*1000/847;

	return combined_ac;
}

void Client::UpdateWho(bool remove) {
	if (worldserver == 0)
		return;
	if (account_id == 0)
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = remove;
	strcpy(scl->name, this->GetName());
	scl->Admin = this->Admin();
	scl->AccountID = this->AccountID();
	strcpy(scl->AccountName, this->AccountName());
	strcpy(scl->zone, zone->GetShortName());
	scl->race = this->GetRace();
	scl->class_ = GetClass();
	scl->level = GetLevel();
	scl->anon = 0;
	scl->notell = 0;
	scl->guilddbid = guilddbid;
	scl->guildeqid = guildeqid;

	worldserver->SendPacket(pack);
	delete pack;
}

// Zone client to spot specified, cords all = 0xFFFF for safe point
/*void Client::MovePC(char* zonename, sint16 x, sint16 y, sint16 z) {
	zonesummon_x = x;
	zonesummon_y = y;
	zonesummon_z = z;
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_Translocate;
	outapp->size = 88;
	outapp->pBuffer = new uchar[outapp->size];
	memset(outapp->pBuffer, 0, outapp->size);
	if (zonename == 0)
		strcpy((char*) outapp->pBuffer, zone->GetShortName());
	else
		strcpy((char*) outapp->pBuffer, zonename);
	int8 tmp[68] = {
0x10, 0xd2, 0x3f, 0x04, 0x86, 0xf3, 0xc4, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xec, 0x46, 0x00, 0xa0, 0xa0, 0x6d, 0x0d,
0x80, 0x15, 0xd5, 0x06, 0xf4, 0xd2, 0xd2, 0x0c, 0xf5, 0x20, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
0x04, 0x00, 0x00, 0x00, 0xf4, 0xca, 0x84, 0x08, 0x00, 0x00, 0xfa, 0xc6, 0x00, 0x00, 0xfa, 0xc6,
0x00, 0x00, 0xfa, 0xc6 };
	memcpy(&outapp->pBuffer[16], tmp, 68);
	outapp->pBuffer[84] = 1;
	QueuePacket(outapp);
	delete outapp;
}*/

void Client::WhoAll() {
	if (worldserver == 0)
		Message(0, "Error: World server disconnected");
	else {
		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_Who;
		pack->size = strlen(this->GetName())+2;
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, pack->size);
		memset(pack->pBuffer, (int8) admin, 1);
		strcpy((char*) &pack->pBuffer[1], this->GetName());
		worldserver->SendPacket(pack);
		delete pack;
	}
}

bool Client::SetGuild(int32 in_guilddbid, int8 in_rank) {
	if (in_guilddbid == 0) {
		// update DB
		if (!database.SetGuild(character_id, 0, GUILD_MAX_RANK))
			return false;
		// clear guildtag
		guilddbid = in_guilddbid;
		guildeqid = 0xFFFFFFFF;
		guildrank = GUILD_MAX_RANK;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_SpawnAppearance;
		outapp->size = sizeof(SpawnAppearance2_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
		appearance->spawn_id = id;
		appearance->type = 22;
		appearance->parameter = 0xFFFFFFFF;
		entity_list.QueueClients(this, outapp, false);
		delete outapp;
		outapp = new APPLAYER;
		outapp->opcode = OP_SpawnAppearance;
		outapp->size = sizeof(SpawnAppearance2_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
		appearance->spawn_id = id;
		appearance->type = 23;
		appearance->parameter = 3;
		entity_list.QueueClients(this, outapp, false);
		delete outapp;
		UpdateWho();
		return true;
	}
	else {
		int32 tmp = database.GetGuildEQID(in_guilddbid);
		if (tmp != 0xFFFFFFFF) {
			if (!database.SetGuild(character_id, in_guilddbid, in_rank))
				return false;
			APPLAYER* outapp;
			SpawnAppearance2_Struct* appearance;
			guildeqid = tmp;
			guildrank = in_rank;
			if (guilddbid != in_guilddbid) {
				guilddbid = in_guilddbid;
				outapp = new APPLAYER;
				outapp->opcode = OP_SpawnAppearance;
				outapp->size = sizeof(SpawnAppearance2_Struct);
				outapp->pBuffer = new uchar[outapp->size];
				appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
				appearance->spawn_id = id;
				appearance->type = 22;
				appearance->parameter = guildeqid;
				entity_list.QueueClients(this, outapp, false);
				delete outapp;
			}

			outapp = new APPLAYER;
			outapp->opcode = OP_SpawnAppearance;
			outapp->size = sizeof(SpawnAppearance2_Struct);
			outapp->pBuffer = new uchar[outapp->size];
			appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
			appearance->spawn_id = id;
			appearance->type = 23;
			if (guilds[tmp].rank[in_rank].warpeace || guilds[tmp].leader == account_id)
				appearance->parameter = 2;
			else if (guilds[tmp].rank[in_rank].invite || guilds[tmp].rank[in_rank].remove || guilds[tmp].rank[in_rank].motd)
				appearance->parameter = 1;
			else
				appearance->parameter = 0;
			entity_list.QueueClients(this, outapp, false);
			delete outapp;
			UpdateWho();
			return true;
		}
	}
	UpdateWho();
	return false;
}

void Client::GuildCommand(Seperator sep) {
	if (strcasecmp(sep.arg[1], "help") == 0) {
		Message(0, "Guild commands:");
		Message(0, "  #guild status [name] - shows guild and rank of target");
		Message(0, "  #guild info guildnum - shows info/current structure");
		Message(0, "  #guild invite [charname]");
		Message(0, "  #guild remove [charname]");
		Message(0, "  #guild promote charname rank");
		Message(0, "  #guild demote charname rank");
		Message(0, "  /guildmotd [newmotd]    (use 'none' to clear)");
		Message(0, "  #guild edit rank title newtitle");
		Message(0, "  #guild edit rank permission 0/1");
		Message(0, "  #guild leader newleader (they must be rank0)");
		if (admin >= 2) {
			Message(0, "GM Guild commands:");
			Message(0, "  #guild list - lists all guilds on the server");
			Message(0, "  #guild create {guildleader charname or AccountID} guildname");
			Message(0, "  #guild delete guildDBID");
			Message(0, "  #guild rename guildDBID newname");
			Message(0, "  #guild set charname guildDBID    (0=no guild)");
			Message(0, "  #guild setrank charname rank");
			Message(0, "  #guild gmedit guilddbid rank title newtitle");
			Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			Message(0, "  #guild setleader guildDBID {guildleader charname or AccountID}");
		}

	}
	else if (strcasecmp(sep.arg[1], "status") == 0 || strcasecmp(sep.arg[1], "stat") == 0) {
		Client* client = 0;
		if (sep.arg[2][0] != 0)
			client = entity_list.GetClientByName(sep.argplus[2]);
		else if (target != 0 && target->IsClient())
			client = target->CastToClient();
		if (client == 0)
			Message(0, "You must target someone or specify a character name");
		else if ((client->Admin() >= 2 && admin <= 1) && client->GuildDBID() != guilddbid) // no peeping for GMs, make sure tell message stays the same
			Message(0, "You must target someone or specify a character name.");
		else {
			if (client->GuildDBID() == 0)
				Message(0, "%s is not in a guild.", client->GetName());
			else if (guilds[client->GuildEQID()].leader == client->AccountID())
				Message(0, "%s is the leader of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
			else
				Message(0, "%s is a member of <%s> rank: %s", client->GetName(), guilds[client->GuildEQID()].name, guilds[client->GuildEQID()].rank[client->GuildRank()].rankname);
		}
	}
	else if (strcasecmp(sep.arg[1], "info") == 0) {
		if (sep.arg[2][0] == 0 && guilddbid == 0)
			if (admin >= 2)
				Message(0, "Usage: #guildinfo guilddbid");
			else
				Message(0, "You're not in a guild");
		else {
			int32 tmp;
			if (sep.arg[2][0] == 0)
				tmp = database.GetGuildEQID(guilddbid);
			else
				tmp = database.GetGuildEQID(atoi(sep.arg[2]));
			if (tmp < 0 || tmp >= 512)
				Message(0, "Guild not found.");
			else {
				database.GetGuildRanks(tmp, &guilds[tmp]);
				Message(0, "Guild info DB# %i, %s", guilds[tmp].databaseID, guilds[tmp].name);
				if (admin >= 2 || guildeqid == tmp) {
					if (account_id == guilds[tmp].leader || guildrank == 0 || admin >= 2) {
						char leadername[32];
						database.GetAccountName(guilds[tmp].leader, leadername);
						Message(0, "Guild Leader: %s", leadername);
						Message(0, "Rank 0: %s", guilds[tmp].rank[0].rankname);
						Message(0, "  All Permissions.");
					}
					for (int i = 1; i <= GUILD_MAX_RANK; i++) {
						Message(0, "Rank %i: %s", i, guilds[tmp].rank[i].rankname);
						Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove, guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
//						Message(0, "  HearGU: %i  SpeakGU: %i  Invite: %i  Remove: %i", guilds[tmp].rank[i].heargu, guilds[tmp].rank[i].speakgu, guilds[tmp].rank[i].invite, guilds[tmp].rank[i].remove);
//						Message(0, "  Promote: %i  Demote: %i  MOTD: %i  War/Peace: %i", guilds[tmp].rank[i].promote, guilds[tmp].rank[i].demote, guilds[tmp].rank[i].motd, guilds[tmp].rank[i].warpeace);
					}
				}
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "leader") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (guilds[guildeqid].leader != account_id)
			Message(0, "You aren't the guild leader.");
		else {
			char* tmptar = 0;
			if (sep.arg[2][0] != 0)
				tmptar = sep.argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "invite") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].invite)
			Message(0, "You dont have permission to invite.");
		else {
			char* tmptar = 0;
			if (sep.arg[2][0] != 0)
				tmptar = sep.argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildInvite;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "remove") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if ((!guilds[guildeqid].rank[guildrank].remove) && !(target == this && sep.arg[2][0] == 0))
			Message(0, "You dont have permission to remove.");
		else {
			char* tmptar = 0;
			if (sep.arg[2][0] != 0)
				tmptar = sep.argplus[2];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildRemove;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "promote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep.arg[2]) == 1 && sep.arg[2][0] >= '0' && sep.arg[2][0] <= '9'))
			Message(0, "Usage: #guild promote rank [charname]");
		else if (atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			char* tmptar = 0;
			if (sep.arg[3][0] != 0)
				tmptar = sep.argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildPromote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep.arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "demote") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!(strlen(sep.arg[2]) == 1 && sep.arg[2][0] >= '0' && sep.arg[2][0] <= '9'))
			Message(0, "Usage: #guild demote rank [charname]");
		else if (atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			char* tmptar = 0;
			if (sep.arg[3][0] != 0)
				tmptar = sep.argplus[3];
			else if (tmptar == 0 && target != 0 && target->IsClient())
				tmptar = target->CastToClient()->GetName();
			if (tmptar == 0)
				Message(0, "You must target someone or specify a character name.");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_GuildDemote;
				pack->size = sizeof(ServerGuildCommand_Struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
				sgc->guilddbid = guilddbid;
				sgc->guildeqid = guildeqid;
				sgc->fromrank = guildrank;
				sgc->fromaccountid = account_id;
				sgc->admin = admin;
				sgc->newrank = atoi(sep.arg[2]);
				strcpy(sgc->from, name);
				strcpy(sgc->target, tmptar);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "motd") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!guilds[guildeqid].rank[guildrank].motd)
			Message(0, "You dont have permission to change the motd.");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			char tmp[255];
			if (strcasecmp(sep.argplus[2], "none") == 0)
				strcpy(tmp, "");
			else
				snprintf(tmp, sizeof(tmp), "%s - %s", this->GetName(), sep.argplus[2]);
			if (database.SetGuildMOTD(guilddbid, tmp)) {
/*
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &guildeqid, 4);
				worldserver->SendPacket(pack);
				delete pack;
*/
			}
			else {
				Message(0, "Motd update failed.");
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "edit") == 0) {
		if (guilddbid == 0)
			Message(0, "You arent in a guild!");
		else if (!sep.IsNumber(2))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep.arg[2]) < 0 || atoi(sep.arg[2]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (!guildrank == 0)
			Message(0, "You must be rank %s to use edit.", guilds[guildeqid].rank[0].rankname);
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			if (!GuildEditCommand(guilddbid, guildeqid, atoi(sep.arg[2]), sep.arg[3], sep.argplus[4])) {
				Message(0, "  #guild edit rank title newtitle");
				Message(0, "  #guild edit rank permission 0/1");
			}
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &guildeqid, 4);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "gmedit") == 0 && admin >= 2) {
		if (!sep.IsNumber(2))
			Message(0, "Error: invalid guilddbid.");
		else if (!sep.IsNumber(3))
			Message(0, "Error: invalid rank #.");
		else if (atoi(sep.arg[3]) < 0 || atoi(sep.arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			int32 eqid = database.GetGuildEQID(atoi(sep.arg[2]));
			if (eqid == 0xFFFFFFFF)
				Message(0, "Error: Guild not found");
			else if (!GuildEditCommand(atoi(sep.arg[2]), eqid, atoi(sep.arg[3]), sep.arg[4], sep.argplus[5])) {
				Message(0, "  #guild gmedit guilddbid rank title newtitle");
				Message(0, "  #guild gmedit guilddbid rank permission 0/1");
			}
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_RefreshGuild;
				pack->size = 5;
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &eqid, 4);
				worldserver->SendPacket(pack);
				delete pack;
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "set") == 0 && admin >= 2) {
		if (!sep.IsNumber(3))
			Message(0, "Usage: #guild set charname guildgbid (0 = clear guildtag)");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSet;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->guilddbid = atoi(sep.arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep.arg[2]);
			worldserver->SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep.arg[1], "setrank") == 0 && admin >= 2) {
		if (!sep.IsNumber(3))
			Message(0, "Usage: #guild setrank charname rank");
		else if (atoi(sep.arg[3]) < 0 || atoi(sep.arg[3]) > GUILD_MAX_RANK)
			Message(0, "Error: invalid rank #.");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_GuildGMSetRank;
			pack->size = sizeof(ServerGuildCommand_Struct);
			pack->pBuffer = new uchar[pack->size];
			memset(pack->pBuffer, 0, pack->size);
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			sgc->newrank = atoi(sep.arg[3]);
			sgc->admin = admin;
			strcpy(sgc->from, name);
			strcpy(sgc->target, sep.arg[2]);
			worldserver->SendPacket(pack);
			delete pack;
		}
	}
	else if (strcasecmp(sep.arg[1], "create") == 0 && admin >= 2) {
		if (sep.arg[3][0] == 0)
			Message(0, "Usage: #guild create {guildleader charname or AccountID} guild name");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep.IsNumber(2))
				leader = atoi(sep.arg[2]);
			else
				leader = database.GetAccountIDByChar(sep.arg[2]);

			int32 tmp = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "Guild leader not found.");
			else if (tmp != 0) {
				int32 tmp2 = database.GetGuildEQID(tmp);
				Message(0, "Error: %s already is the leader of DB# %i '%s'.", sep.arg[2], tmp, guilds[tmp2].name);
			}
			else {
				int32 tmpeq = database.CreateGuild(sep.argplus[3], leader);
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild creation failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver->SendPacket(pack);
					delete pack;
					database.GetGuildRanks(tmpeq, &guilds[tmpeq]);
					Message(0, "Guild created: Leader: %i, DB# %i, EQ# %i: %s", leader, guilds[tmpeq].databaseID, tmpeq, sep.argplus[3]);
				}

			}
		}
	}
	else if (strcasecmp(sep.arg[1], "delete") == 0 && admin >= 2) {
		if (!sep.IsNumber(2))
			Message(0, "Usage: #guild delete guildDBID");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep.arg[2]));
			char tmpname[32];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);

			if (!database.DeleteGuild(atoi(sep.arg[2])))
				Message(0, "Guild delete failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver->SendPacket(pack);
					delete pack;
					Message(0, "Guild deleted: DB# %i, EQ# %i: %s", atoi(sep.arg[2]), tmpeq, tmpname);
				} else
					Message(0, "Guild deleted: DB# %i", atoi(sep.arg[2]));
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "rename") == 0 && admin >= 2) {
		if ((!sep.IsNumber(2)) || sep.arg[3][0] == 0)
			Message(0, "Usage: #guild rename guildDBID newname");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			int32 tmpeq = database.GetGuildEQID(atoi(sep.arg[2]));
			char tmpname[32];
			if (tmpeq != 0xFFFFFFFF)
				strcpy(tmpname, guilds[tmpeq].name);

			if (!database.RenameGuild(atoi(sep.arg[2]), sep.argplus[3]))
				Message(0, "Guild rename failed.");
			else {
				if (tmpeq != 0xFFFFFFFF) {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver->SendPacket(pack);
					delete pack;
					Message(0, "Guild renamed: DB# %i, EQ# %i, OldName: %s, NewName: %s", atoi(sep.arg[2]), tmpeq, tmpname, sep.argplus[3]);
				} else
					Message(0, "Guild renamed: DB# %i, NewName: %s", atoi(sep.arg[2]), sep.argplus[3]);
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "setleader") == 0 && admin >= 2) {
		if (sep.arg[3][0] == 0 || !sep.IsNumber(2))
			Message(0, "Usage: #guild setleader guilddbid {guildleader charname or AccountID}");
		else if (worldserver == 0)
			Message(0, "Error: World server dirconnected");
		else {
			int32 leader = 0;
			if (sep.IsNumber(3))
				leader = atoi(sep.arg[3]);
			else
				leader = database.GetAccountIDByChar(sep.argplus[3]);

			int32 tmpdb = database.GetGuildDBIDbyLeader(leader);
			if (leader == 0)
				Message(0, "New leader not found.");
			else if (tmpdb != 0) {
				int32 tmpeq = database.GetGuildEQID(tmpdb);
				if (tmpeq >= 512)
					Message(0, "Error: %s already is the leader of DB# %i.", sep.argplus[3], tmpdb);
				else
					Message(0, "Error: %s already is the leader of DB# %i <%s>.", sep.argplus[3], tmpdb, guilds[tmpeq].name);
			}
			else {
				int32 tmpeq = database.GetGuildEQID(atoi(sep.arg[2]));
				if (tmpeq == 0xFFFFFFFF)
					Message(0, "Guild not found.");
				else if (!database.SetGuildLeader(atoi(sep.arg[2]), leader))
					Message(0, "Guild leader change failed.");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					worldserver->SendPacket(pack);
					delete pack;
					Message(0, "Guild leader changed: DB# %s, Leader: %s, Name: <%s>", sep.arg[2], sep.argplus[3], guilds[tmpeq].name);
				}
			}
		}
	}
	else if (strcasecmp(sep.arg[1], "list") == 0 && admin >= 2) {
		int x = 0;
		Message(0, "Listing guilds on the server:");
		char leadername[32];
		for (int i = 0; i < 512; i++) {
			if (guilds[i].databaseID != 0) {
				leadername[0] = 0;
				database.GetAccountName(guilds[i].leader, leadername);
				if (leadername[0] == 0)
					Message(0, "  DB# %i EQ# %i  <%s>", guilds[i].databaseID, i, guilds[i].name);
				else
					Message(0, "  DB# %i EQ# %i  <%s> Leader: %s", guilds[i].databaseID, i, guilds[i].name, leadername);
				x++;
			}
		}
		Message(0, "%i guilds listed.", x);
	}
	else {
		Message(0, "Unknown guild command, try #guild help");
	}
}

bool Client::GuildEditCommand(int32 dbid, int32 eqid, int8 rank, char* what, char* value) {
	struct GuildRankLevel_Struct grl;
	strcpy(grl.rankname, guilds[eqid].rank[rank].rankname);
	grl.demote = guilds[eqid].rank[rank].demote;
	grl.heargu = guilds[eqid].rank[rank].heargu;
	grl.invite = guilds[eqid].rank[rank].invite;
	grl.motd = guilds[eqid].rank[rank].motd;
	grl.promote = guilds[eqid].rank[rank].promote;
	grl.remove = guilds[eqid].rank[rank].remove;
	grl.speakgu = guilds[eqid].rank[rank].speakgu;
	grl.warpeace = guilds[eqid].rank[rank].warpeace;
	if (strcmp(what, "title") == 0) {
		if (strlen(value) > 100)
			Message(0, "Error: Title has a maxium length of 100 characters.");
		else
			strcpy(grl.rankname, value);
	}
	else if (rank == 0)
		Message(0, "Error: Rank 0's permissions can not be changed.");
	else {
		if (!(strlen(value) == 1 && (value[0] == '0' || value[0] == '1')))
			return false;
		if (strcmp(what, "demote") == 0)
			grl.demote = (value[0] == '1');
		else if (strcmp(what, "heargu") == 0)
			grl.heargu = (value[0] == '1');
		else if (strcmp(what, "invite") == 0)
			grl.invite = (value[0] == '1');
		else if (strcmp(what, "motd") == 0)
			grl.motd = (value[0] == '1');
		else if (strcmp(what, "promote") == 0)
			grl.promote = (value[0] == '1');
		else if (strcmp(what, "remove") == 0)
			grl.remove = (value[0] == '1');
		else if (strcmp(what, "speakgu") == 0)
			grl.speakgu = (value[0] == '1');
		else if (strcmp(what, "warpeace") == 0)
			grl.warpeace = (value[0] == '1');
		else
			Message(0, "Error: Permission name not recognized.");
	}
	if (!database.EditGuild(dbid, rank, &grl))
		Message(0, "Error: database.EditGuild() failed");
	return true;
}

int16 Client::GetMaxMana()
{
	switch(GetCasterClass())
	{
		case 'I': return ((GetINT()/5)+2) * GetLevel();
		case 'W': return ((GetWIS()/5)+2) * GetLevel();
		default:
		{
			cerr << "Invalid Class in GetMaxMana" << endl;
			return 0;
		}
	}	

}

void Client::UpdateAdmin() {
	admin = database.CheckStatus(account_id);
	UpdateWho();

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_SpawnAppearance;
	outapp->size = sizeof(SpawnAppearance2_Struct);
	outapp->pBuffer = new uchar[outapp->size];
	SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
	appearance->spawn_id = id;
	appearance->type = 20;
	if (admin >= 2)
		appearance->parameter = 1;
	else
		appearance->parameter = 0;
	entity_list.QueueClients(this, outapp, false);
	delete outapp;
}

void Client::FindItem(char* search_criteria)
{
	int count=0;
	int iSearchLen = strlen(search_criteria)+1;
	char sName[36];
	char sCriteria[255];

	strcpy(sCriteria, search_criteria);
	strupr(sCriteria);
	Item_Struct* item = 0;
	char* pdest;
	for (int i=0; i < database.max_item; i++)
	{
		if (database.item_array[i] != 0)
		{
			item = (Item_Struct*)database.item_array[i];
			
			strcpy(sName, item->name);
			strupr(sName);

			pdest = strstr(sName, sCriteria);
			if (pdest != NULL) {
				Message(0, "  %i: %s", (int) item->item_nr, item->name);
				count++;
			}
			if (count == 20) {
				break;
			}
		}
	}
	if (count == 20)
		Message(0, "20 items shown...too many results.");
	else
		Message(0, "%i items found", count);
}

void Client::SummonItem(int16 item_id, sint8 charges) {
	Item_Struct* item = database.GetItem(item_id);
	if (item == 0) {
		Message(0, "No such item: %i", item_id);
	}
	else {
		pp.inventory[0] = item_id;
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_SummonedItem;
		outapp->size = sizeof(SummonedItem_Struct);
		outapp->pBuffer = new uchar[outapp->size];
		memcpy(outapp->pBuffer, item, sizeof(Item_Struct));
		Item_Struct* item2 = (Item_Struct*) outapp->pBuffer;
		item2->equipSlot = 0;
		if (item->flag != 0x7669)
			item2->common.charges = charges;
		QueuePacket(outapp);
		delete outapp;
	}
}

void Client::GMRestoreMana() {
	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ManaChange;
	outapp->size = sizeof(ManaChange_Struct);
	outapp->pBuffer = new uchar[outapp->size];

	ManaChange_Struct* manachange = (ManaChange_Struct*)outapp->pBuffer;
	pp.mana = GetMaxMana();
	manachange->new_mana = pp.mana;
	manachange->spell_id = 0;
	QueuePacket(outapp);
	delete outapp;
}

void Client::CreateSpawnPacket(APPLAYER* app, Mob* ForWho)
{
	app->opcode = OP_NewSpawn;
	app->pBuffer = new uchar[sizeof(NewSpawn_Struct)];
	app->size = sizeof(NewSpawn_Struct);

	memset(app->pBuffer, 0, sizeof(NewSpawn_Struct));
	NewSpawn_Struct* ns = (NewSpawn_Struct*)app->pBuffer;

	ns->spawn.heading = heading;
	ns->spawn.x_pos = x_pos;
	ns->spawn.y_pos = y_pos;
	ns->spawn.z_pos = z_pos * 10;
	ns->spawn.spawn_id = id;
	ns->spawn.max_hp = 0x64;
	ns->spawn.race = race;

	if (guildeqid == 0xFFFFFFFF)
		ns->spawn.GuildID = 0xFFFF;
	else
		ns->spawn.GuildID = guildeqid;

	if (ForWho == this)
		ns->spawn.NPC = 10;
	else
		ns->spawn.NPC = 0;
	ns->spawn.not_linkdead = 1;
	if (corpse)
		ns->spawn.NPC = 3;

	ns->spawn.class_ = class_;
	ns->spawn.gender = gender;
	ns->spawn.level = level;
	ns->spawn.anim_type = 0x64;
	ns->spawn.light = light;

	if (admin >= 2)
		ns->spawn.GM = 1;

	ns->spawn.npc_armor_graphic = 0xFF;
	ns->spawn.npc_helm_graphic = 0xFF;

	Item_Struct* item = 0;
	item = database.GetItem(pp.inventory[2]);
	if (item != 0) {
		ns->spawn.equipment[0] = item->common.material;
		ns->spawn.equipcolors[0] = item->common.color;
	}
	item = database.GetItem(pp.inventory[17]);
	if (item != 0) {
		ns->spawn.equipment[1] = item->common.material;
		ns->spawn.equipcolors[1] = item->common.color;
	}
	item = database.GetItem(pp.inventory[7]);
	if (item != 0) {
		ns->spawn.equipment[2] = item->common.material;
		ns->spawn.equipcolors[2] = item->common.color;
	}
	item = database.GetItem(pp.inventory[10]);
	if (item != 0) {
		ns->spawn.equipment[3] = item->common.material;
		ns->spawn.equipcolors[3] = item->common.color;
	}
	item = database.GetItem(pp.inventory[12]);
	if (item != 0) {
		ns->spawn.equipment[4] = item->common.material;
		ns->spawn.equipcolors[4] = item->common.color;
	}
	item = database.GetItem(pp.inventory[18]);
	if (item != 0) {
		ns->spawn.equipment[5] = item->common.material;
		ns->spawn.equipcolors[5] = item->common.color;
	}
	item = database.GetItem(pp.inventory[19]);
	if (item != 0) {
		ns->spawn.equipment[6] = item->common.material;
		ns->spawn.equipcolors[6] = item->common.color;
	}
	item = database.GetItem(pp.inventory[13]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[7] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[7] = 0;
		}
		ns->spawn.equipcolors[7] = 0;
	}
	item = database.GetItem(pp.inventory[14]);
	if (item != 0) {
		if (strlen(item->idfile) >= 3) {
			ns->spawn.equipment[8] = (int8) atoi(&item->idfile[2]);
		}
		else {
			ns->spawn.equipment[8] = 0;
		}
		ns->spawn.equipcolors[8] = 0;
	}

	strcpy(ns->spawn.name, name);
	strcpy(ns->spawn.lastname, lastname);
	ns->spawn.deity = deity;

	EncryptSpawnPacket(app);
}

int16 Client::GetItemAt(int16 in_slot) {
	if (in_slot <= 29) // Worn items and main inventory
		return pp.inventory[in_slot];
	else if (in_slot >= 250 && in_slot <= 329) // Main inventory's containers
		return pp.containerinv[in_slot-250];
	else if (in_slot >= 2000 && in_slot <= 2007) // Bank slots
		return pp.bank_inv[in_slot-2000];
	else if (in_slot >= 2030 && in_slot <= 2109) // Bank's containers
		return pp.bank_cont_inv[in_slot-2030];
	else {
		cerr << "Error: " << GetName() << ": GetItemAt(): Unknown slot: 0x" << hex << setw(4) << setfill('0') << in_slot << dec << endl;
		Message(0, "Error: GetItemAt(): Unknown slot: 0x%04x", in_slot);
	}
	return 0;
}

