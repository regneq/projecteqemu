#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#ifdef WIN32
	#include <process.h>
#else
	#include <pthread.h>
#endif

#include "entity.h"
#include "npc.h"
#include "client.h"
#include "worldserver.h"

#ifdef BUILD_FOR_WINDOWS
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp	_stricmp
#endif

extern WorldServer* worldserver;
extern GuildRanks_Struct guilds[512];
extern int32 numclients;

Entity::Entity()
{
}

Entity::~Entity()
{
}

void Entity::SetID(int16 set_id)
{
	id = set_id;
}

int16 Entity::GetID()
{
	return id;
}

Client* Entity::CastToClient()
{
#ifdef DEBUG
	if(!IsClient())
	{	
		cout << "CastToClient error" << endl;
		return 0;
	}
#endif
	return static_cast<Client*>(this);
}

NPC* Entity::CastToNPC()
{
#ifdef DEBUG
	if(!IsNPC())
	{	
		cout << "CastToNPC error" << endl;
		return 0;
	}
#endif
	return static_cast<NPC*>(this);
}

Mob* Entity::CastToMob()
{
#ifdef DEBUG
	if(!IsMob())
	{	
		cout << "CastToMob error" << endl;
		return 0;
	}
#endif
	return static_cast<Mob*>(this);
}

void EntityList::AddClient(Client* client)
{
	client->SetID(GetFreeID());

	list.Insert(client);
}

void EntityList::AddNPC(NPC* npc)
{
	LinkedListIterator<Entity*> iterator(list);
	APPLAYER app;

	npc->SetID(GetFreeID());
	npc->CreateSpawnPacket(&app);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->QueuePacket(&app);
		}
		iterator.Advance();
	}

	list.Insert(npc);
};

Entity* EntityList::GetID(int16 get_id)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == get_id)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

int16 EntityList::GetFreeID()
{
	while(1)
	{
		last_insert_id++;
		if (GetID(last_insert_id) == 0)
		{
			return last_insert_id;
		}
	}
}

void EntityList::ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (chan_num != 8 || client->Dist(from) < 100) // Only say is limited in range
			{
					client->ChannelMessageSend(from->GetName(), 0, chan_num, language, buffer);
			}
		}
		iterator.Advance();
	}
}

void EntityList::ChannelMessageSend(Mob* to, int8 chan_num, int8 language, char* message, ...)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (client->GetID() == to->GetID()) {
				client->ChannelMessageSend(0, 0, chan_num, language, buffer);
				break;
			}
		}
		iterator.Advance();
	}
}

void EntityList::SendZoneSpawns(Client* client)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	APPLAYER* app;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob())
		{
			if (iterator.GetData()->IsClient() && !iterator.GetData()->CastToClient()->Connected())
			{
				iterator.Advance();
				continue;
			}
			app = new APPLAYER;
			iterator.GetData()->CastToMob()->CreateSpawnPacket(app); // TODO: Use zonespawns opcode instead
			client->QueuePacket(app);
			delete app;
		}
		iterator.Advance();
	}	
}

void EntityList::Save()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->Save();
		}
		iterator.Advance();
	}	
}

void EntityList::RemoveFromTargets(Mob* mob)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsNPC())
		{
			iterator.GetData()->CastToNPC()->RemoveFromHateList(mob);
		}
		if (iterator.GetData()->IsMob() && iterator.GetData()->CastToMob()->GetTarget() == mob)
		{
			iterator.GetData()->CastToMob()->SetTarget(0);			
		}
		iterator.Advance();
	}	
}

#ifdef BUILD_FOR_WINDOWS
void EntityList::QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender, float dist, Mob* SkipThisMob)
#else
void EntityList::QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender=false, float dist=200, Mob* SkipThisMob = 0)
#endif
{
	LinkedListIterator<Entity*> iterator(list);

	dist=dist*dist*dist;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->DistNoRoot(sender) <= dist && (!ignore_sender || iterator.GetData() != sender) && (iterator.GetData() != SkipThisMob))
		{
//ChannelMessage(0, 8, 0, "Sending a message [%04x:%i] to %s", app->opcode, app->size, iterator.GetData()->CastToClient()->GetName());
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}

#ifdef BUILD_FOR_WINDOWS
void EntityList::QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender)
#else
void EntityList::QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender=false)
#endif

{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && (!ignore_sender || iterator.GetData() != sender))
		{
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}

void EntityList::AESpell(Mob* caster, Mob* center, float dist, int16 spell_id) {
	LinkedListIterator<Entity*> iterator(list);

	dist = dist*dist;

//cout << "AE Spell Cast: c=" << center->GetName() << ", d=" << dist << ", x=" << center->GetX() << ", y=" << center->GetY() << endl;
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob() && iterator.GetData()->CastToMob()->DistNoRootNoZ(center) <= dist)
		{
//cout << "AE Spell Hit: t=" << iterator.GetData()->GetName() << ", d=" << iterator.GetData()->CastToMob()->DistNoRoot(center) << ", x=" << iterator.GetData()->CastToMob()->GetX() << ", y=" << iterator.GetData()->CastToMob()->GetY() << endl;
			caster->SpellOnTarget(spell_id, iterator.GetData());
		}
		iterator.Advance();
	}	
}

Client* EntityList::GetClientByName(char *checkname) 
{ 
       LinkedListIterator<Entity*> iterator(list); 
        
       iterator.Reset(); 
       while(iterator.MoreElements()) 
       { 
           if (iterator.GetData()->IsClient()) 
           { 
			   if (strcasecmp(iterator.GetData()->CastToClient()->GetName(), checkname) == 0) {
                   return iterator.GetData()->CastToClient();
			   }
           } 
           iterator.Advance(); 
       } 
       return 0; 
} 

Client* EntityList::GetClientByAccID(int32 accid) 
{ 
       LinkedListIterator<Entity*> iterator(list); 
        
       iterator.Reset(); 
       while(iterator.MoreElements()) 
       { 
           if (iterator.GetData()->IsClient()) 
           { 
			   if (iterator.GetData()->CastToClient()->AccountID() == accid) {
                   return iterator.GetData()->CastToClient();
			   }
           } 
           iterator.Advance(); 
       } 
       return 0; 
} 

void EntityList::ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message: " << (int) chan_num << " " << (int) guilddbid << ": " << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
//cout << "DEBUG: chan=" << chan_num << ", client->GuildDBID()=" << client->GuildDBID() << ", guilddbid=" << guilddbid << ", client->GuildEQID()=" << client->GuildEQID() << ", client->GuildRank()=" << client->GuildRank() << ", heargu=" << guilds[client->GuildEQID()].rank[client->GuildRank()].heargu << endl;
			if (chan_num != 0 || (client->GuildDBID() == guilddbid && client->GuildEQID() != 0xFFFFFF && guilds[client->GuildEQID()].rank[client->GuildRank()].heargu))
				client->ChannelMessageSend(from, to, chan_num, language, buffer);
		}
		iterator.Advance();
	}
}

void EntityList::Message(int32 to_guilddbid, int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (to_guilddbid == 0 || client->GuildDBID() == to_guilddbid)
				client->Message(type, buffer);
		}
		iterator.Advance();
	}
}

void EntityList::MessageClose(Mob* sender, bool skipsender, float dist, int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->DistNoRoot(sender) <= dist && (!skipsender || iterator.GetData() != sender)) {
			iterator.GetData()->CastToClient()->Message(type, buffer);
		}
		iterator.Advance();
	}
}


// Safely removes all entities before zone shutdown
void EntityList::Clear()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->Save();
		}
		iterator.RemoveCurrent();
	}	
}

void EntityList::UpdateWho()
{
	if (worldserver == 0 || zone == 0)
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = true;
	strcpy(scl->zone, zone->GetShortName());
	worldserver->SendPacket(pack);
	delete pack;

	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->UpdateWho(false);
		}
		iterator.Advance();
	}	
}

void EntityList::RemoveEntity(int16 id)
{
	LinkedListIterator<Entity*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->CastToMob()->GetID() == id)
		{
			cout << "spawn deleted" << endl;
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}

	cout << "error deleting spawn" << endl;
}

void EntityList::Process()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			if (iterator.GetData()->IsClient()) {
				struct in_addr	in;
				in.s_addr = iterator.GetData()->CastToClient()->GetIP();
				cout << "Dropping client: Process=false, ip=" << inet_ntoa(in) << ", port=" << ntohs(iterator.GetData()->CastToClient()->GetPort()) << endl;
				numclients--;
			}
			zone->StartShutdownTimer();
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

void EntityList::CountNPC(int32* NPCCount, int32* NPCLootCount, int32* gmspawntype_count) {
	LinkedListIterator<Entity*> iterator(list);
	*NPCCount = 0;
	*NPCLootCount = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		if (iterator.GetData()->IsNPC()) {
			(*NPCCount)++;
			(*NPCLootCount) += iterator.GetData()->CastToNPC()->CountLoot();
			if (iterator.GetData()->CastToNPC()->GetNPCTypeid() == 0)
				(*gmspawntype_count)++;
		}
		iterator.Advance();
	}
}

void EntityList::DoZoneDump(ZSDump_Spawn2* spawn2_dump, ZSDump_NPC* npc_dump, ZSDump_NPC_Loot* npcloot_dump, NPCType* gmspawntype_dump) {
	int32 spawn2index = 0;
	int32 NPCindex = 0;
	int32 NPCLootindex = 0;
	int32 gmspawntype_index = 0;

	if (npc_dump != 0) {
		LinkedListIterator<Entity*> iterator(list);
		NPC* npc = 0;
		iterator.Reset();
		while(iterator.MoreElements())	
		{
			if (iterator.GetData()->IsNPC()) {
				npc = iterator.GetData()->CastToNPC();
				if (spawn2_dump != 0)
					npc_dump[NPCindex].spawn2_dump_index = zone->DumpSpawn2(spawn2_dump, &spawn2index, npc->respawn2);
				npc_dump[NPCindex].npctype_id = npc->GetNPCTypeid();
				npc_dump[NPCindex].cur_hp = npc->GetHP();
				npc_dump[NPCindex].corpse = npc->IsCorpse();
				if (npc_dump[NPCindex].corpse) {
					npc_dump[NPCindex].decay_time_left = npc->GetDecayTime();
				}
				else {
					npc_dump[NPCindex].decay_time_left = 0xFFFFFFFF;
				}
				npc_dump[NPCindex].x = npc->GetX();
				npc_dump[NPCindex].y = npc->GetY();
				npc_dump[NPCindex].z = npc->GetZ();
				npc_dump[NPCindex].heading = npc->GetHeading();
				npc_dump[NPCindex].copper = npc->copper;
				npc_dump[NPCindex].silver = npc->silver;
				npc_dump[NPCindex].gold = npc->gold;
				npc_dump[NPCindex].platinum = npc->platinum;
				if (npcloot_dump != 0)
					npc->DumpLoot(NPCindex, npcloot_dump, &NPCLootindex);
				if (gmspawntype_dump != 0) {
					if (npc->GetNPCTypeid() == 0) {
						memcpy(&gmspawntype_dump[gmspawntype_index], npc->NPCTypedata, sizeof(NPCType));
						npc_dump[NPCindex].gmspawntype_index = gmspawntype_index;
						gmspawntype_index++;
					}
				}
				NPCindex++;
			}
			iterator.Advance();
		}
	}
	if (spawn2_dump != 0)
		zone->DumpAllSpawn2(spawn2_dump, &spawn2index);
}

void EntityList::Depop() {
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsNPC()) {
			iterator.GetData()->CastToNPC()->Depop(false);
		}
		iterator.Advance();
	}
}


#define MAX_SPAWN_UPDATES_PER_PACKET	50
/*
Bulk spawn update packet, to be requested by the client on a timer.
0 range = whole zone.
Does 50 updates per packet, can fine tune that if neccessary

-Quagmire
*/
void EntityList::SendPositionUpdates(Client* client, float range, Entity* alwayssend) {
	range = range * range;
	LinkedListIterator<Entity*> iterator(list);

	APPLAYER* outapp = 0;
	SpawnPositionUpdates_Struct* spus = 0;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (outapp == 0) {
			outapp = new APPLAYER;
			outapp->opcode = OP_MobUpdate;
			outapp->size = sizeof(SpawnPositionUpdates_Struct) + (sizeof(SpawnPositionUpdate_Struct) * MAX_SPAWN_UPDATES_PER_PACKET);
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			spus = (SpawnPositionUpdates_Struct*) outapp->pBuffer;
		}
		if (iterator.GetData()->IsMob() && iterator.GetData() != client) {
			if (range == 0 || iterator.GetData() == alwayssend || iterator.GetData()->CastToMob()->DistNoRootNoZ(client) <= range) {
				iterator.GetData()->CastToMob()->MakeSpawnUpdate(&spus->spawn_update[spus->num_updates]);
				spus->num_updates++;
			}
		}
		if (spus->num_updates >= MAX_SPAWN_UPDATES_PER_PACKET) {
			client->QueuePacket(outapp, false);
			delete outapp;
			outapp = 0;
		}
		iterator.Advance();
	}
	if (outapp != 0) {
		if (spus->num_updates > 0) {
			outapp->size = sizeof(SpawnPositionUpdates_Struct) + (sizeof(SpawnPositionUpdate_Struct) * spus->num_updates);
			client->QueuePacket(outapp, false);
		}
		delete outapp;
		outapp = 0;
	}
}