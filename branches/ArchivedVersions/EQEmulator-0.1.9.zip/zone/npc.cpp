#include <math.h>
#include "../common/moremath.h"
#include "stdio.h"

#ifdef WIN32
	#define snprintf	_snprintf
#else
	#include <stdlib.h>
	#include <pthread.h>
#endif

#include "npc.h"
#include "client.h"
#include "map.h"

extern Database database;
extern Map* map;

NPC::NPC(NPCType* d, void* in_respawn, float x, float y, float z, float heading, bool isgroup, bool IsCorpse)
 : Mob(d->name,
       d->lastname,
       d->max_hp,
       d->max_hp,
       d->gender,
       d->race,
       d->class_,
       d->deity,
       d->level,
	   d->npc_id, // rembrant, Dec. 20, 2001
	   d->skills, // socket 12-29-01
       heading,
       x,
       y,
       z,
       d->light,
       d->equipment,
	   d->texture,
	   d->helmtexture,
	   d->AC,
	   d->ATK,
	   d->STR,
	   d->STA,
	   d->DEX,
	   d->AGI,
	   d->INT,
	   d->WIS,
	   d->CHA)
{
	NPCTypedata = d;
	if (d->npc_id == 0) { // GM created
//		respawn = 0;
		respawn2 = 0;
	}
	else if (isgroup) {
//		respawn =0;
		respawn2 = (Spawn2*) in_respawn;
	}
//	else {
//		respawn2 =0;
//		respawn = (Spawn*) in_respawn;
//	}

	itemlist = new ItemList();
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;

	movement_timer = new Timer(100);
	walking_timer = 0;
	if (map != 0)
		walking_timer  = new Timer(5000);
	org_x = x;
	org_y = y;

	if (IsCorpse) {
		corpse = true;
		snprintf(name, sizeof(name), "%s's_corpse", name);
		corpse_decay_timer->Start();
	}
	p_depop = false;
	loottable_id = d->loottable_id;
}

NPC::~NPC()
{
	delete movement_timer;
	safe_delete(walking_timer);
	delete itemlist;
	if (NPCTypedata->npc_id == 0)
		delete NPCTypedata;
}

ServerLootItem_Struct* NPC::GetItem(int slot_id) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		ServerLootItem_Struct* item = iterator.GetData();
		if (item->equipSlot == slot_id)
		{
			return item;
		}
		iterator.Advance();
	}
	cout << "no item found for slot: " << slot_id << endl;
	return 0;
}

void NPC::AddItem(Item_Struct* item, int8 charges, uint8 slot)
{
    //cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = item->item_nr;
	(*itemlist).Append(item_data);
}

void NPC::AddItem(int32 itemid, int8 charges, uint8 slot)
{
    //cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = itemid;
	(*itemlist).Append(item_data);
}

void NPC::AddLootTable() {
	if (npc_id != 0) { // check if it's a GM spawn
		database.AddLootTableToNPC(loottable_id, itemlist, &copper, &silver, &gold, &platinum);
	}
}

void NPC::RemoveItem(uint16 item_id)
{
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->item_nr == item_id)
		{
			Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}

	return;
}

void NPC::ClearItemList() {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements()) {
		iterator.RemoveCurrent();
	}
}

void NPC::QueryLoot(Client* to) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements())
	{
		Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
		to->Message(0, "  %d: %s", item->item_nr, item->name);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void NPC::AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum)
{
	copper = in_copper;
	silver = in_silver;
	gold = in_gold;
	platinum = in_platinum;
}

void NPC::AddCash()
{
	copper = (rand() % 100)+1;
	silver = (rand() % 50)+1;
	gold = (rand() % 10)+1;
	platinum = (rand() % 5)+1;
}

void NPC::RemoveCash()
{
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
}

bool NPC::Process()
{
	if (p_depop)
		return false;
	if (corpse) {
		if(corpse_decay_timer->Check()) {
			entity_list.Message(0, 10, "%s decays into a pile of dust...", name);
			/*APPLAYER* outapp; // It isn't needed... *shrug*
			outapp = new APPLAYER;
			outapp->opcode = OP_DeleteSpawn;
			outapp->size = sizeof(DeleteSpawn_Struct);
			outapp->pBuffer = new uchar[outapp->size];
			DeleteSpawn_Struct* delspawn = (DeleteSpawn_Struct*)outapp->pBuffer;
			delspawn->spawn_id = this->GetID();
			delspawn->ds_unknown1 = 0;
			entity_list.QueueClients(this, outapp, false);
			delete outapp;*/
			return false;
		}
		return true;
	}

	float angle = 0;

	SetTarget(hate_list.GetTop());

	if (target != 0)
	{
		appearance = 0;
		bool sendposupdate = false;
		if (movement_timer->Check()) {
//			movement_timer->Start();
			// NPC can move per "think", this number should be an EQ distance squared
#define NPC_MOVEMENT_PER_TIC		400
			int32 total_move_dist = (int32) DistNoRootNoZ(target);
				if (total_move_dist > 75) {
				total_move_dist -= 50;
				if (total_move_dist > NPC_MOVEMENT_PER_TIC)
					total_move_dist = NPC_MOVEMENT_PER_TIC;
//cout << "DEBUG: NPC Movement" << endl;
//cout << "tar->X=" << target->GetX() << ", x_pos=" << x_pos << ", tar->X - x_pos=" << target->GetX() - x_pos << ", pow(tar->X - x_pos, 2)=" << pow(target->GetX() - x_pos, 2) << endl;
//cout << "tar->Y=" << target->GetY() << ", y_pos=" << y_pos << ", tar->Y - y_pos=" << target->GetY() - y_pos << ", pow(tar->Y - y_pos, 2)=" << pow(target->GetY() - y_pos, 2) << endl;
				sint32 x2 = (sint32) pow(target->GetX() - x_pos, 2);
				sint32 y2 = (sint32) pow(target->GetY() - y_pos, 2);
				// divide by zero "should" be impossible here because of the DistNoRootNoZ check
				sint32 x_move = (sint32) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
				sint32 y_move = (sint32) (total_move_dist - x_move);
//cout << "x2=" << x2 << ", x_move=" << x_move << ", sign(target->GetX() - x_pos)=" << (int) sign(target->GetX() - x_pos) << endl;
//cout << "y2=" << y2 << ", y_move=" << y_move << ", sign(target->GetY() - y_pos)=" << (int) sign(target->GetY() - y_pos) << endl;
				x_pos += (sint16) sqrt((double)x_move) * sign(target->GetX() - x_pos);
				y_pos += (sint16) sqrt((double)y_move) * sign(target->GetY() - y_pos);
//cout << "sqrt(x_move)=" << sqrt((double)x_move) << ", x_pos=" << x_pos << endl;
//cout << "sqrt(y_move)=" << sqrt((double)y_move) << ", y_pos=" << y_pos << endl;
				sendposupdate = true;
			}
		}
		if (attack_timer->Check()) {
			attack_timer->Start();
			angle = FaceTarget();
			Attack(target);
			sendposupdate = true;
		}
		if (sendposupdate) // dont need to send twice in both of the above, so...
			SendPosUpdate();
	}
	else {
		if (walking_timer && walking_timer->Check()) {
			float delta_x = (rand()%100) - 50;
			float delta_y = (rand()%100) - 50;
			SendTo(org_x + delta_x, org_y + delta_y);
		}
	}

    return true;
}

float NPC::FaceTarget()
{
	// TODO: Simplify?

	float angle;

	if (target->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else if (target->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (target->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
//cout << "dX:" << target->GetX()-x_pos;
//cout << "dY:" << target->GetY()-y_pos;
//cout << "Angle:" << angle;

	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;

	heading = (sint8) (256*(360-angle)/360.0f);
	return angle;

//cout << "Heading:" << (int)heading << endl;
}

void NPC::RemoveFromHateList(Mob* mob)
{
	hate_list.RemoveEnt(mob);
}

int32 NPC::CountLoot() {
	if (itemlist == 0)
		return 0;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	int32 count = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		count++;
		iterator.Advance();
	}
	return count;
}

void NPC::DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex) {
	if (itemlist == 0)
		return;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	int32 count = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		npclootdump[*NPCLootindex].npc_dump_index = npcdump_index;
		npclootdump[*NPCLootindex].itemid = iterator.GetData()->item_nr;
		npclootdump[*NPCLootindex].charges = iterator.GetData()->charges;
		npclootdump[*NPCLootindex].equipSlot = iterator.GetData()->equipSlot;
		(*NPCLootindex)++;
		iterator.RemoveCurrent();
	}
}

void NPC::SetDecayTimer(int32 decaytime) {
	if (corpse) {
		if (decaytime == 0)
			corpse_decay_timer->Trigger();
		else
			corpse_decay_timer->Start(decaytime);
	}
	else {
		if (decaytime == 0)
			corpse_decay_timer->SetTimer(1);
		else
			corpse_decay_timer->SetTimer(decaytime);
	}
}

void NPC::Depop(bool StartSpawnTimer) {
	p_depop = true;
	if (StartSpawnTimer && !corpse) {
/*
		if (respawn !=0) {
			respawn->Reset();
		}
		else if (respawn2 != 0)
*/
		if (respawn2 != 0) {
			respawn2->Reset();
		}
	}
}

void NPC::GMMove(float x, float y, float z, float heading) {
	this->x_pos = x;
	this->y_pos = y;
	this->z_pos = z;
	if (heading != 0)
		this->heading = heading;
	SendPosUpdate();
}

void NPC::SendTo(float new_x, float new_y) {
	if (map == 0)
		return;

	float angle;
	float dx = new_x-x_pos;
	float dy = new_y-y_pos;
// 0.09 is a perfect magic number for a human pnj's
	walking_timer->Start( ( sqrt( dx*dx + dy*dy ) * 0.09f ) * 1000 );

	if (new_x-x_pos > 0)
		angle = - 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
	else {
		if (new_x-x_pos < 0)	
			angle = + 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
		else { // Added?
			if (new_y-y_pos > 0)
				angle = 0;
			else
				angle = 180;
		}
	}
	if (angle < 0)
		angle += 360;
	if (angle > 360	)
		angle -= 360;

	heading	= 256*(360-angle)/360.0f;
	appearance = 5;
//	SendPosUpdate();
	x_pos = new_x;
	y_pos = new_y;

	PNODE pnode  = map->SeekNode( map->GetRoot(), x_pos, y_pos );
	// Quagmire - Not sure if this is the right thing to do, but it stops the crashing
	if (pnode == 0) return;

	int  *iface  = map->SeekFace( pnode, x_pos, y_pos );
	while(*iface != -1)
	{
		z_pos = map->GetFaceHeight( *iface, x_pos, y_pos );
		iface++;
	}
}
