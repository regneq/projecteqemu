#ifndef CLIENT_H
#define CLIENT_H
class Client;

#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/EQPacketManager.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/database.h"
#include "errno.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "../common/deity.h"
#include "mob.h"
#include "npc.h"
#include "zone.h"
#include "../common/seperator.h"

extern Database database;
extern EntityList entity_list;
extern Zone* zone;

#define CLIENT_TIMEOUT 90000

#define CLIENT_CONNECTING1	0
#define CLIENT_CONNECTING2	1
#define CLIENT_CONNECTING3	2
#define CLIENT_CONNECTING4	3
#define CLIENT_CONNECTING5	4
#define CLIENT_CONNECTED	5
#define CLIENT_KICKED		6
#define DISCONNECTED		7

class Client : public Mob
{
public:
	Client(int32 ip, int16 port, int send_socket);
    ~Client();

	virtual bool IsClient() { return true; }

	void	CreateSpawnPacket(APPLAYER* app, Mob* ForWho = 0);
	virtual bool Process();
	void	ReceiveData(uchar* buf, int len);
	void	SendPacketQueue(bool Block = true);
	void	QueuePacket(APPLAYER* app, bool ack_req = true);

	void	ChannelMessageReceived(int8 chan_num, int8 language, char* message, char* targetname);
//	void	ChannelMessageReceived(int8 chan_num, int8 language, char* message);
	void	ChannelMessageSend(char* from, char* to, int8 chan_num, int8 language, char* message, ...);
	void	Message(int32 type, char* message, ...);

	int32	GetIP()			{ return ip; }
	int16	GetPort()		{ return port; }

	bool	Save();

	bool	Connected()		{ return (client_state == CLIENT_CONNECTED); }
	void	Kick() { Save(); client_state = CLIENT_KICKED; }

	void	Attack(Mob* other);
	void	SetAttackTimer();
	void	Heal();
	void	Damage(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);
	void	Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill = 0x04);

	void	SendHPUpdate();
	void	SetMaxHP();

	int8	GetDeity()		{ return DEITY_AGNOSTIC; }
	int8	GetRace()		{ return pp.race; }
	int8	GetClass()		{ return pp.class_; }
	int8	GetGender()		{ return pp.gender; }
	int8	GetLevel()		{ return pp.level; }
	int16	GetMaxMana();
	int16	GetMana()		{ return pp.mana; }

	int8	GetBaseSTR()	{ return pp.STR; }
	int8	GetBaseSTA()	{ return pp.STA; }
	int8	GetBaseCHA()	{ return pp.CHA; }
	int8	GetBaseDEX()	{ return pp.DEX; }
	int8	GetBaseINT()	{ return pp.INT; }
	int8	GetBaseAGI()	{ return pp.AGI; }
	int8	GetBaseWIS()	{ return pp.WIS; }
	int8	GetLanguageSkill(int8 n)	{ return pp.languages[n]; }

	int16	GetAC()			{ return GetRawItemAC() + bonuses->AC; } // Quagmire - this is NOT the right math on this
	sint16	GetSTR()		{ return GetBaseSTR() + bonuses->STR; }
	sint16	GetSTA()		{ return GetBaseSTA() + bonuses->STA; }
	sint16	GetDEX()		{ return GetBaseDEX() + bonuses->DEX; }
	sint16	GetAGI()		{ return GetBaseAGI() + bonuses->AGI; }
	sint16	GetINT()		{ return GetBaseINT() + bonuses->INT; }
	sint16	GetWIS()		{ return GetBaseWIS() + bonuses->WIS; }
	sint16	GetCHA()		{ return GetBaseCHA() + bonuses->CHA; }

	uint32	GetEXP()		{ return pp.exp; }

	sint32	GetHP()			{ return cur_hp; }
	sint32	GetMaxHP()		{ return GetBaseHP() + bonuses->HP; }
	sint32	GetBaseHP();

	void	AddEXP(uint32 add_exp);
	void	SetEXP(uint32 set_exp);
	virtual void SetLevel(uint8 set_level);
//	void	MovePC(sint16 move_x, sint16 move_y, sint16 move_z);
	void	MovePC(char* zonename, sint16 x, sint16 y, sint16 z);
	void	WhoAll();
	void	SummonItem(int16 item_id, sint8 charges = 1);

	int8	GetFactionLevel(int32 char_id, int32 npc_id, int32 p_race, int32 p_class, int32 p_deity);
	void	SetFactionLevel(int32 char_id, int32 npc_id, int8 char_class, int8 char_race, int8 char_deity);

	int8	GetSkill(int skill_num);
	virtual void SetSkill(int skill_num, int8 skill_id); // socket 12-29-01
	int16	GetRawItemAC();
	int16	GetCombinedAC_TEST();

	int32	CharacterID()	{ return character_id; }
	int32	AccountID()		{ return account_id; }
	char*	AccountName()	{ return account_name; }
	int8	Admin()			{ return admin; }
	void	UpdateAdmin();
	void	UpdateWho(bool remove = false);

	int32	GuildEQID()		{ return guildeqid; }
	int32	GuildDBID()		{ return guilddbid; }
	int8	GuildRank()		{ return guildrank; }
	bool	SetGuild(int32 in_guilddbid, int8 in_rank);

	void	CastSpell(int16 spell_id, int16 target_id, int16 slot, int32 casttime = 0xFFFFFFFF);
	void	InterruptSpell();
	void	GMRestoreMana();

    // Disgrace: currently set from database.CreateCharacter. 
	// Need to store in proper position in PlayerProfile...
	int8	GetFace()		{ return pp.pp_unknown2[0]; } 
	int32	PendingGuildInvite; // Used for /guildinvite

	int16	GetItemAt(int16 in_slot);
protected:
	friend class Mob;
	void CalcItemBonuses(StatBonuses* newbon);
private:
	void SpellFinished(int16 spell_id, int32 target_id, int16 slot = 10, int16 mana_used = 0);
    void FindItem(char* search_criteria);
	Timer* spellend_timer;
	int16 casting_spell_id;
	int16 casting_spell_targetid;
	int16 casting_spell_slot;
	int16 casting_spell_mana;

	APPLAYER* PMOutQueuePop();
#ifdef WIN32
	CRITICAL_SECTION CSPacketManager;
#else
	pthread_mutex_t CSPacketManager;
#endif

	int32            ip;
	int16            port;
	int8             client_state;
	int              send_socket;
	CEQPacketManager packet_manager;
	Timer*           timeout_timer;
	int32			 character_id;
	int32            account_id;
	char			 account_name[30];
	int8			 admin;
	int32			 guilddbid; // guild's ID in the database
	int8			 guildrank; // player's rank in the guild, 0-GUILD_MAX_RANK

	bool             auto_attack;

	PlayerProfile_Struct pp;

	void GuildCommand(Seperator sep);
	bool GuildEditCommand(int32 dbid, int32 eqid, int8 rank, char* what, char* value);
	uint32 GetEXPForLevel(uint16 level);

	//Disgrace: make due for now...
	char GetCasterClass() { return 'I'; }

	sint16 zonesummon_x;
	sint16 zonesummon_y;
	sint16 zonesummon_z;

	Timer*	position_timer;
	int8	position_timer_counter;
};

#endif

