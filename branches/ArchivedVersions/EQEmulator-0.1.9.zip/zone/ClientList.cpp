#include "ClientList.h"
#ifndef WIN32
	#include <pthread.h>
	#include "../common/unix.h"
#endif

ClientList client_list;

ClientList::ClientList() {
#ifdef WIN32
	InitializeCriticalSection(&CSListLock);
#else
/*	pthread_mutexattr_t attr;
	pthread_mutexattr_init(&attr);
	pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutex_init(&CSListLock, &attr);
	pthread_mutexattr_destroy(&attr);*/
	pthread_mutex_t CSListLock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
	pthread_mutex_lock(&CSListLock);
	pthread_mutex_unlock(&CSListLock);
#endif
}

ClientList::~ClientList() {
	RemoveAll();
#ifdef WIN32
	DeleteCriticalSection(&CSListLock);
#else
//	pthread_mutex_destroy(&CSListLock);
#endif
}

void ClientList::Add(Client* client)
{
	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	list.Insert(client);
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

void ClientList::SendPacketQueues() {
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->SendPacketQueue(false);
		iterator.Advance();
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

void ClientList::Remove(Client* client) {
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData() == client) {
			iterator.RemoveCurrent(false);
			break;
		}
		iterator.Advance();
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

void ClientList::RemoveAll() {
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent(false);
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
}

bool ClientList::RecvData(int32 ip, int16 port, uchar* buffer, int len) {
	LinkedListIterator<Client*> iterator(list);

	#ifdef WIN32
		EnterCriticalSection(&CSListLock);
	#else
		pthread_mutex_lock(&CSListLock);
	#endif
	iterator.Reset();
	while(iterator.MoreElements())
	{
		Client* client = iterator.GetData()->CastToClient();
		if (client->GetIP() == ip && client->GetPort() == port) {
			client->ReceiveData(buffer, len);
			#ifdef WIN32
				LeaveCriticalSection(&CSListLock);
			#else
				pthread_mutex_unlock(&CSListLock);
			#endif
			return true;
		}
		iterator.Advance();
	}
	#ifdef WIN32
		LeaveCriticalSection(&CSListLock);
	#else
		pthread_mutex_unlock(&CSListLock);
	#endif
	return false;
}
