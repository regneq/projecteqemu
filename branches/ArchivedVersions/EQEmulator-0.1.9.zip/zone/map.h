#pragma once

typedef struct _vertex{
	unsigned int order;
	float	x, y, z;
}VERTEX, *PVERTEX;

typedef struct _face{
	unsigned int	a, b, c;
	float nx, ny, nz, nd;
}FACE, *PFACE;

typedef struct _node{
	float						minx, miny, maxx, maxy;
	int							nfaces;
	unsigned int *	pfaces;
	char						mask;
	struct  _node	*	node1, *node2, *node3, *node4;
}NODE, *PNODE;

class Map{
private:
	unsigned int		m_Vertex;
	unsigned int		m_Faces;
	PVERTEX					mFinalVertex;
	PFACE						mFinalFaces;
	PNODE						mRoot;
	int							mCandFaces[100];

	void	RecLoadNode( PNODE	_node, void *l_f );
	void	RecFreeNode( PNODE	_node						 );
public:
	static Map* Map::LoadMapfile(char* in_zonename);
	Map										(FILE* fp);
	~Map									();
	PNODE		SeekNode( PNODE _node, float x, float y );
	int		 *SeekFace( PNODE _node, float x, float y );
	float		GetFaceHeight( int _idx, float x, float y );
	inline unsigned int		GetVertexNumber( ) {return m_Vertex; }
	inline unsigned int		GetFacesNumber( ) { return m_Faces; }
	inline PVERTEX	GetVertex( int _idx ) {return mFinalVertex + _idx;	}
	inline PFACE		GetFace( int _idx) {return mFinalFaces + _idx;		}
	inline PNODE		GetRoot( ) { return mRoot; }
};
