#include <stdlib.h>

#include "npc.h"
#include "client.h"
#include "../common/eq_packet_structs.h"
#include <stdio.h>
#include "skills.h"

#ifdef BUILD_FOR_WINDOWS
	#define snprintf	_snprintf
#endif

extern EntityList entity_list;

void Client::Attack(Mob* other)
{
	int skillinuse;
	int8 attack_skill;

	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;

	a->spawn_id = id;
	// lets determine the animation type based on whats in the primary slot
	uint16 item_id = pp.inventory[13];
	Item_Struct* item = database.GetItem(item_id);
	if (item) 
	{
		if (item->flag != 0x7669) 
		{
			//cout << "skill = " << (int)item->common.skill << endl;
			// 1h slashing
			if (item->common.skill == 0x00) 
			{
				attack_skill = 0x01;
				skillinuse = 0;
				a->type = 5;
			}
			// 2h slashing
			if (item->common.skill == 0x01) 
			{
				attack_skill = 0x01;
				skillinuse = 1;
				a->type = 3;
			}
			// Piercing
			if (item->common.skill == 0x02) 
			{
				attack_skill = 0x24;
				skillinuse = 2;
				a->type = 2;
			}
			// 1h blunt
			if (item->common.skill == 0x03) 
			{
				attack_skill = 0x00;
				skillinuse = 3;
				a->type = 5;
			}
			// 2h blunt
			if (item->common.skill == 0x04) 
			{
				attack_skill = 0x00;
				skillinuse = 4;
				a->type = 4;
			}
			// 2h Piercing
			if (item->common.skill == 0x35) 
			{
				attack_skill = 0x24;
				skillinuse = 35;
				a->type = 4;
			}
		}
		else 
		{
/*
			// player has a non-weapon in primary
			skillinuse = 80;
			a->type = 32; // using 32 since it doesn't seem to do anything
*/
			// Lets still let them attack, but only hit for 1 =P
			attack_skill = 0x04;
			skillinuse = 80;
			a->type = 8;
		}
	}
	else 
	{
		// player does not have anything in primary
		// use hand to hand
		attack_skill = 0x04;
		skillinuse = 28;
		a->type = 8;
	}
	// end animation determination
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;

	entity_list.QueueCloseClients(this, &app);

	int damage = 0;
	float skillmodifier = 0.0;
	float hitmodifier = 0.0;

	// Determine players ability to hit based on:
	// mob level difference, skillinuse, randomness
	if (skillinuse == 80) {
		damage = 1;
	}
	else
	{
		if ((int)pp.skills[skillinuse] != 0) 
		{
			float hitsuccess = (float)other->GetLevel() - (float)level;
			// cout << "1 - " << hitsuccess << endl;
			if(level > other->GetLevel() || level == other->GetLevel())
			{
				hitsuccess -= level;
				hitsuccess -= 4;
				hitsuccess *= 6;
			}
			if(other->GetLevel() > level)
			{
				hitsuccess -= level;
				hitsuccess *= (level+other->GetLevel()/other->GetLevel());
			}
			if ((int)hitsuccess >= 91)
			{
				hitsuccess *= 4.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 40 && hitsuccess <= 90)
			{
				hitsuccess *= 3.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 10 && hitsuccess <= 39)
			{
				hitsuccess /= 10.0;
				hitmodifier = 0.25;
			}
			else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
			{
				hitsuccess = 0.5;
				hitmodifier = 0.5;
			}
			else if ((int)hitsuccess <= -1)
			{
				hitsuccess = 0;
				hitmodifier = 0.8;
			}
			// cout << "2 - " << hitsuccess << endl;
			if ((int)pp.skills[skillinuse] >= 100)
			{
				skillmodifier = 0.1;
			}
			else if ((int)pp.skills[skillinuse] >= 200)
			{
				skillmodifier = 0.2;
			}
			hitsuccess -= ((float)pp.skills[skillinuse]/10000) + skillmodifier;
			// cout << "3 - " << hitsuccess << endl;
			hitsuccess += (float)rand()/RAND_MAX;
			// cout << "4 - " << hitsuccess << endl;

			if((float)rand()/RAND_MAX < 0.2)
			{
				if((int)pp.skills[skillinuse] < 255)
				{
					int skill = pp.skills[skillinuse];
					skill += 1;
					pp.skills[skillinuse] = skill;
					Message(MT_Skills, "Your fighting skills go up (%d)",(int)pp.skills[skillinuse]);
				}
				else {
					Message(MT_Skills, "Your skill in %d is maxed out, and the skill cannot go up any further.",skillinuse);
				}
			}
			if (hitsuccess <= hitmodifier)
			{
				
				// Now lets determine how much the player will hit for based on:
				// player's lvl, mob lvl, skill, weapon damage, str
				int weapon_damage = 0;
				if (skillinuse == 28) // weapon is hand-to-hand
				{
					weapon_damage = abs((int)GetSkill(skillinuse)/100);
					if (weapon_damage < 1) {
						weapon_damage = 1;
					}
				}
				else {
					weapon_damage = (int)item->common.damage;
					if (weapon_damage < 1) {
						weapon_damage = 1;
					}
				}
				int hit_modifier = (int)((int)level - (int)other->GetLevel())/10;
				int max_hit = 0;
				int min_hit = 0;
				min_hit = (int)abs((((int)level - 3)/3) + hit_modifier);
				max_hit = (int)abs(((((int)GetSTR() + (int)GetSkill(skillinuse) + (int)level)/10) + hit_modifier)*weapon_damage/2);
/*
cout << GetName() << "'s Attack Stats:" << endl;
cout << " skill level in use = " << (int)pp.skills[skillinuse] << endl;
cout << " STR = " << (int)GetSTR() << endl;
cout << " weapon_damage = " << weapon_damage << endl;
cout << " hit_modifier = " << hit_modifier << endl;
cout << " min_hit = " << min_hit << endl;
cout << " max_hit = " << max_hit << endl;
*/
				if (max_hit == min_hit)
					damage = min_hit;
				else
					damage = (int32)min_hit+rand()%(max_hit-min_hit)+1;
			}
		}
	}

	other->Damage(this, damage, 0xffff, attack_skill);
}

void Client::Heal()
{
	SetMaxHP();
    APPLAYER app;
    app.opcode = OP_Action;
    app.size = sizeof(Action_Struct);
    app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
    Action_Struct* a = (Action_Struct*)app.pBuffer;

    a->target = id;
    a->source = id;
    a->type = 231; // 1
    a->spell = 0x000d; //spell_id
    a->damage = -10000;

    entity_list.QueueCloseClients(this, &app);
    APPLAYER hp_app;
    CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, true);
    SendHPUpdate();

    cout << name << " healed via #heal" << endl; // Pyro: Why say damage?
}

void Client::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill) {
	if (invulnerable)
		return;

	if ((GetHP() - damage) <= -11) {
		Death(other, damage, spell_id, attack_skill);
		return;
	}

	SetHP(GetHP()-damage);

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = id;
	a->source = other->GetID();
	a->type = attack_skill;
	a->spell = spell_id;
	a->damage = damage;

	entity_list.QueueCloseClients(this, &app);
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, true); // Dont send this hp update to the client that got hurt
	SendHPUpdate();                                     // Use this different message instead?

    if (damage != 0) // Pyro: Why log this message if no damage is inflicted
    {
            cout << name << " hit for " << damage << ", " << GetHP() << " left." << endl; // More intuitive console output
    }
}

void Client::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (corpse)
		return;
	SetHP(-100);
	corpse = true;
	entity_list.RemoveFromTargets(this);
	// zonesummon = -3 = death
	zonesummon_x = -3;
	zonesummon_y = -3;
	zonesummon_z = -3;

	pp.x = x_pos;
	pp.y = y_pos;
	pp.z = z_pos;
	pp.heading = heading;
	cout << "Player " << name << " has died." << endl;
	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->spawn_id = id;
	d->killer_id = other->GetID();
	d->damage = damage;
	d->spell_id = spell;
	d->type = attack_skill;
	entity_list.QueueClients(this, &app);
}

void NPC::Attack(Mob* other)
{
	if (DistNoRootNoZ(other) > 10*10)
	{
		return;
	}


	int skillinuse;
	int8 attack_skill;
	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;

	a->spawn_id = id;
	// lets determine the animation type based on whats in the primary slot.
	// TODO: since the NPC's primary slot is just a graphic, we will need to
	//		 set the weapons properties and ensure correct graphic is displayed.

	// I only implemented weapons 0-8 for now (4=bow, 6=flute)
	if ((int)GetEquipment(7) != 0) 
	{
		// 1h Slashing weapons
		if ((int)GetEquipment(7) == 1 || (int)GetEquipment(7) == 3)
		{
			attack_skill = 0x01;
			skillinuse = 0;
			a->type = 5;
		}
		// 2h Slashing weapons
		else if ((int)GetEquipment(7) == 2)
		{
			attack_skill = 0x01;
			skillinuse = 1;
			a->type = 3;
		}
		// Piercing
		else if ((int)GetEquipment(7) == 5)
		{
			attack_skill = 0x24;
			skillinuse = 2;
			a->type = 2;
		}
		// 1h Blunt
		else if ((int)GetEquipment(7) == 7)
		{
			attack_skill = 0x00;
			skillinuse = 3;
			a->type = 5;
		}
		// 2h Blunt
		else if ((int)GetEquipment(7) == 8)
		{
			attack_skill = 0x00;
			skillinuse = 4;
			a->type = 4;
		}
		else {
			attack_skill = 0x04;
			skillinuse = 80;
			a->type = 8;
		}
	}
	else 
	{
		// NPC does not have anything in primary
		// use hand to hand
		attack_skill = 0x04;
		skillinuse = 28;
		a->type = 8;
	}
	// end animation determination
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;

	entity_list.QueueCloseClients(this, &app);

	int damage = 0;
	float skillmodifier = 0.0;
	float hitmodifier = 0.0;

	// Determine NPC's ability to hit based on:
	// mob level difference, skillinuse, randomness
	if (skillinuse != 80)
	{
		// TODO: Set npc's skill levels!!
		SetSkill(skillinuse, 0xff); // all mobs have 255 skill -socket
		if ((int)GetSkill(skillinuse) != 0) 
		{
			float hitsuccess = (float)other->GetLevel() - (float)level;
			// cout << "1 - " << hitsuccess << endl;
			if(level > other->GetLevel() || level == other->GetLevel())
			{
				hitsuccess -= level;
				hitsuccess -= 4;
				hitsuccess *= 8;
			}
			if(level >= other->GetLevel())
			{
				hitsuccess += 4;
				hitsuccess *= 14;
			}
			if(other->GetLevel() > level)
			{
				hitsuccess += level;
				hitsuccess *= level/other->GetLevel();
			}
			if ((int)hitsuccess >= 91)
			{
				hitsuccess *= 4.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 40 && hitsuccess <= 90)
			{
				hitsuccess *= 3.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 10)
			{
				hitsuccess /= 10.0;
				hitmodifier = 1.3;
			}
			else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
			{
				hitsuccess = 0.5;
				hitmodifier = 0.8;
			}
			else if ((int)hitsuccess <= -1)
			{
				hitsuccess = 0;
				hitmodifier = 0.4;
			}
			// cout << "2 - " << hitsuccess << endl;
			if ((int)GetSkill(skillinuse) >= 100)
			{
				skillmodifier = 0.1;
			}
			else if ((int)GetSkill(skillinuse) >= 200)
			{
				skillmodifier = 0.2;
			}
			hitsuccess -= ((float)GetSkill(skillinuse)/100000) + skillmodifier;
			// cout << "3 - " << hitsuccess << endl;
			hitsuccess += (float)rand()/RAND_MAX;
			// cout << "4 - " << hitsuccess << endl;
			if (hitsuccess <= hitmodifier)
			{
				// Now lets determine how much the NPC will hit for based on:
				// player's lvl, mob lvl, skill, weapon damage, str
				int weapon_damage = 0;
				if (skillinuse == 28) // weapon is hand-to-hand
				{
					weapon_damage = abs((int)GetSkill(skillinuse)/100);
					if (weapon_damage < 1) 
					{
						weapon_damage = 1;
					}
				}
				else 
				{
					// TODO: Set NPC's weapon damage
					weapon_damage = (4*(int)level)/3;
					if (weapon_damage < 1) 
					{
						weapon_damage = 1;
					}
				}
				int hit_modifier = (int)((int)level - (int)other->GetLevel())/10;
				int max_hit = 0;
				int min_hit = 0;
				min_hit = (int)abs((((int)level - 20)/3) + hit_modifier * level/5);
				// TODO: Add STR to mobs (right now all mobs have 255 STR) -socket
				max_hit = (int)abs((((255 + (int)GetSkill(skillinuse) + (int)level)/100) + hit_modifier)*(weapon_damage*level/2));
/*
cout << GetName() << "'s Attack Stats:" << endl;
cout << " skill level in use = " << (int)GetSkill(skillinuse) << endl;
cout << " STR = " << "255" << endl;
cout << " weapon_damage = " << weapon_damage << endl;
cout << " hit_modifier = " << hit_modifier << endl;
cout << " min_hit = " << min_hit << endl;
cout << " max_hit = " << max_hit << endl;
*/
				if (max_hit == min_hit)
					damage = min_hit;
				else
					damage = (int32)min_hit+rand()%(max_hit-min_hit)+1;
			}
		}
	}

//	if ((float)rand()/RAND_MAX < 0.4)
//	{
//		damage = 2*level;
//	}
	other->Damage(this, damage, 0xffff, attack_skill);
}

void NPC::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill)
{
	if (damage >= GetHP())
	{
		SetHP(0);
		Death(other, damage, spell_id, attack_skill);
		return;
	}


	SetHP(GetHP() - damage);

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = id;
	a->source = other->GetID();
	a->type = attack_skill; // was 0x1c
	a->spell = spell_id;
	a->damage = damage;

	a->unknown4[0] = 0xcd;
	a->unknown4[1] = 0xcc;

	a->unknown4[2] = 0xcc;
	a->unknown4[3] = 0x3d;

	a->unknown4[4] = 0x71;
	a->unknown4[5] = 0x6b;

	a->unknown4[6] = 0x3d;
	a->unknown4[7] = 0x41;

	entity_list.QueueCloseClients(this, &app);

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app);

	hate_list.Add(other, damage);
}

void NPC::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (corpse)
		return;
	SetHP(0);
	corpse = true;
	// Quagmire - Lets set the name right, "npc's_corpse"
	snprintf(name, sizeof(name), "%s's_corpse", name);

	entity_list.RemoveFromTargets(this);

	corpse_decay_timer->Enabled();
//	corpse_decay_timer = new Timer(180000);
	corpse_decay_timer->Start();

	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->spawn_id = id;
	d->killer_id = other->GetID();
	d->spell_id = spell;
	d->type = attack_skill;
	d->damage = damage;
	entity_list.QueueCloseClients(this, &app, false, 200, other);
	if (other->IsClient())
		other->CastToClient()->QueuePacket(&app);

	hate_list.Add(other, damage);

	if (hate_list.GetTop() != 0 && hate_list.GetTop()->IsClient())
	{
		hate_list.GetTop()->CastToClient()->AddEXP(level*level*75); // Pyro: Comment this if NPC death crashes zone
		if (other->IsClient())
			hate_list.GetTop()->CastToClient()->SetFactionLevel(other->CastToClient()->CharacterID(), npc_id, other->CastToClient()->GetClass(), other->CastToClient()->GetRace(), other->CastToClient()->GetDeity());
	}

/*
	if (respawn !=0)
	{
		respawn->Reset();
	}
	else if (respawn2 != 0)
*/
	if (respawn2 != 0)
	{
		respawn2->Reset();
	}
}

void Mob::ChangeHP(Mob* other, sint32 amount, int16 spell_id)
{
	if (corpse) {
		other->Message(0, "Leave the dead alone bully!");
		return;
	}
	
	if (amount == -20000) {
		SetHP(-100);
		this->Death(other, abs(amount), spell_id, 0xFF);
		return;
	}
	else if (amount == +10000) {
		SetHP(GetMaxHP());
	}
	else if (!invulnerable) {
		if (amount < 0) {
			this->Damage(other, abs(amount), spell_id, 0xFF);
			return;
		}
		else
			SetHP(GetHP() + amount);
	}

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, true);	// Dont send this hp update to the client that got hurt
	if (this->IsClient())
		this->CastToClient()->SendHPUpdate();			// Use this different message instead?
}

void Mob::MonkSpecialAttack(Mob* other, int8 type) {
	sint32 ndamage = 0;
	PlayerProfile_Struct pp;
	float hitsuccess = (float)other->GetLevel() - (float)level;
	float hitmodifier = 0.0;
	float skillmodifier = 0.0;
	if(level > other->GetLevel())
	{
		hitsuccess += 2;
		hitsuccess *= 14;
	}
	if ((int)hitsuccess >= 40)
	{
		hitsuccess *= 3.0;
		hitmodifier = 1.1;
	}
	if ((int)hitsuccess >= 10 && hitsuccess <= 39)
	{
		hitsuccess /= 4.0;
		hitmodifier = 0.25;
	}
	else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
	{
		hitsuccess = 0.5;
		hitmodifier = 1.5;
	}
	else if ((int)hitsuccess <= -1)
	{
		hitsuccess = 0.1;
		hitmodifier = 1.8;
	}
	// cout << "2 - " << hitsuccess << endl;
	if ((int)pp.skills[type] >= 100)
	{
		skillmodifier = 1;
	}
	else if ((int)pp.skills[type] >= 200)
	{
		skillmodifier = 2;
	}

	hitsuccess -= ((float)pp.skills[type]/10000) + skillmodifier;
	// cout << "3 - " << hitsuccess << endl;
	hitsuccess += (float)rand()/RAND_MAX;
	// cout << "4 - " << hitsuccess << endl;
	float ackwardtest = 2.4;
	float random = (float)rand()/RAND_MAX;
	if(random <= 0.2)
	{
		ackwardtest = 4.5;
	}
	if(random > 85 && random < 400.0)
	{
		ackwardtest = 3.2;
	}
	if(random > 400 && random < 800.0)
	{
		ackwardtest = 3.7;
	}
	if(random > 900 && random < 1400.0)
	{
		ackwardtest = 1.9;
	}
	if(random > 1400 && random < 14000.0)
	{
		ackwardtest = 2.3;
	}
	if(random > 14000 && random < 24000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 24000 && random < 34000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 990000)
	{
		ackwardtest = 1.2;
	}
	if(random < 0.2)
	{
		ackwardtest = 0.8;
	}

	ackwardtest += (float)rand()/RAND_MAX;
	ackwardtest = abs(ackwardtest);
	if (type == 0x1A) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (FLYING_KICK + GetSTR() + level) / 700);
		if ((float)rand()/RAND_MAX < 0.2) {
			ndamage = ndamage * 4.2;
			if(ndamage <= 0)
			{
			entity_list.MessageClose(this, false, 200, 10, "%s misses at an attempt to thunderous kick %s!",name,other->name);
			}
			else
			{
			entity_list.MessageClose(this, false, 200, 10, "%s lands a thunderous kick!(%d)", name, ndamage);
			}
		}
		other->Damage(this, ndamage, 0xffff, 0x1A);
		DoAnim(45);
	}
	else if (type == 0x34) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (2 * ackwardtest) * (TIGER_CLAW + GetSTR() + level) / 900);
		other->Damage(this, ndamage, 0xffff, 0x34);
		DoAnim(46);
	}
	else if (type == 0x26) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (ROUND_KICK + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x26);
		DoAnim(11);
	}
	else if (type == 0x17) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (EAGLE_STRIKE + GetSTR() + level) / 1000);
		other->Damage(this, ndamage, 0xffff, 0x17);
		DoAnim(47);
	}
	else if (type == 0x15) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (5 * ackwardtest) * (DRAGON_PUNCH + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x15);
		DoAnim(7);
	}
	else if (type == 0x1E) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (KICK + GetSTR() + level) / 1200);
		other->Damage(this, ndamage, 0xffff, 0x1e);
		DoAnim(1);
	}
}

