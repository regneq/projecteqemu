#ifndef ZONE_H
#define ZONE_H

#define ZONE_AUTOSHUTDOWN_DELAY		5000

#include "../common/linked_list.h"
#include "../common/types.h"
#include "../common/database.h"
//#include "spawn.h"
#include "mob.h"
#include "zonedump.h"

struct ZonePoint {
	float x;
	float y;
	float z;
	float target_x;
	float target_y;
	float target_z;
	char  target_zone[16];
};

extern EntityList entity_list;

class Zone
{
public:
	Zone(char* in_short_name, char* in_address, int16 in_port);
	~Zone();

	char* GetAddress() { return address; }
	char* GetLongName() { return long_name; }
	char* GetShortName() { return short_name; }
	int16 GetPort() { return port; }

	int32	CountSpawn2();
	ZonePoint* GetClosestZonePoint(float x, float y, float z, char* to_name);
	SpawnGroupList* spawn_group_list;

//	NPCType* GetNPCType(uint16 id);
//	Item_Struct* GetItem(uint16 id);

	bool	Process();
	void	DumpAllSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index);
	int32	DumpSpawn2(ZSDump_Spawn2* spawn2dump, int32* spawn2index, Spawn2* spawn2);

	void	Depop();
	void	Repop(int32 delay = 0);
	void	SpawnStatus(Mob* client);
	void	StartShutdownTimer(int32 set_time = ZONE_AUTOSHUTDOWN_DELAY);
protected:
	friend class database;
	LinkedList<Spawn2*> spawn2_list; // CODER new spawn list
private:
	char* short_name;
	char* long_name;
	char* address;
	int16 port;

	Timer*	autoshutdown_timer;

//	LinkedList<Spawn*> spawn_list;
	LinkedList<ZonePoint*> zone_point_list;

#ifdef WIN32
	CRITICAL_SECTION CSZoneLock;
#else
	pthread_mutex_t CSZoneLock;
#endif
};

#endif

