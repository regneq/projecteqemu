#ifndef EQ_OPCODES_H
#define EQ_OPCODES_H

// Disgrace: for item looting
#define OP_ItemTradeIn	   0x3120
#define OP_LootComplete    0x4421
#define OP_EndLootRequest  0x4F20
#define OP_MoneyOnCorpse   0x5020
#define OP_ItemOnCorpse    0x5220
#define OP_LootItem        0xA020
#define OP_LootRequest     0x4e20

// Quagmire: Guild /-commands
#define OP_GuildInviteAccept 0x1821
#define OP_GuildLeader     0x9521 // /guildleader
#define OP_GuildPeace      0x9121 // /guildpeace
#define OP_GuildWar        0x6f21 // /guildwar
#define OP_GuildInvite     0x1721 // /guildinvite
#define OP_GuildRemove     0x1921 // /guildremove
#define OP_GuildMOTD	   0x0322 // /guildmotd
#define OP_GuildUpdate     0x7b21
#define OP_GuildsList      0x9221

#define OP_Petition		   0x0e20
#define OP_GMFlagged       0x1120 // Pyro - this is spammed when flagged GM (tired of seeing it)
#define OP_GMZoneRequest   0x4f21 // Quagmire - client sends this when you use /zone
#define OP_GMZoneRequest2  0x0822
#define OP_GMGoto		   0x6e20 // /goto
#define OP_GMSummon		   0xc520
#define OP_GMNameChange	   0xcb20 // /name
#define OP_GMKill		   0x6c20 // /kill
#define OP_GMLastName	   0x6e21 // /lastname
#define OP_Translocate     0x0622
#define OP_Jump	           0x2020
#define OP_MovementUpdate  0x1F20
#define OP_SenseHeading    0x8721
#define OP_SafePoint	   0x2420
#define OP_Surname         0xc421
#define OP_YellForHelp     0xda21
#define OP_ZoneServerInfo  0x0480
#define OP_ChannelMessage  0x0721
#define OP_Camp            0x0722
#ifdef LUCLIN
	#define OP_ZoneEntry		0x2920
	#define OP_DeleteSpawn		0x2a20
#else
	#define OP_ZoneEntry		0x2a20
	#define OP_DeleteSpawn		0x2b20
#endif
#define OP_MoveItem        0x2c21
#ifdef LUCLIN
	#define OP_PlayerProfile	0x3620
#else
	#define OP_PlayerProfile	0x2d20
#endif
#define OP_Save            0x2e20
#define OP_Consider        0x3721
#define OP_SendCharInfo    0x4720
#define OP_NewSpawn        0x4921
#define OP_Death           0x4a20
#define OP_AutoAttack      0x5121
#define OP_Consume         0x5621
#define OP_Stamina         0x5721
#define OP_AutoAttack2     0x6021 /*Why 2?*/
#define OP_SendLoginInfo   0x5818
#define OP_Action          0x5820
#define OP_DeleteCharacter 0x5a20
#define OP_NewZone         0x5b20
#define OP_CombatAbility   0x5f21
#define OP_ClientTarget    0x6221
#define OP_SummonedItem    0x7821
#define OP_SpecialMesg     0x8021
#define OP_Sneak           0x8521
#define OP_Hide            0x8621
#define OP_SenseTraps      0x8821
#define OP_WearChange      0x9220
#define OP_Forage          0x9420
#define OP_DropCoin		   0x0720
#define OP_LevelUpdate     0x9821
#define OP_ExpUpdate       0x9921
#define OP_Mend            0x9d21
#ifdef LUCLIN
	#define OP_Attack			0xa120
	#define OP_MobUpdate		0x9f20
#else
	#define OP_Attack			0x9f20
	#define OP_MobUpdate		0xa120
#endif
#define OP_ZoneChange      0xa320
#define OP_HPUpdate        0xb220
#define OP_TimeOfDay       0xf220
#define OP_ClientUpdate    0xf320
#define OP_DisarmTraps     0xf321
#define OP_WhoAll          0xf420
#define OP_SpawnAppearance 0xf520
#define OP_BeginCast       0xa920
#define OP_CastSpell       0x7e21
#define OP_Buff            0x3221
#define OP_CastOn          0x4620
#define OP_InterruptCast   0xd321
#define OP_HarmTouch	   0x7E21
#define OP_ManaChange      0x7f21
#define OP_MemorizeSpell   0x8221 
#define OP_SwapSpell       0xce21 
#define OP_MonkAtk		   0x5f21
#define OP_FeignDeath	   0xac20
#ifdef LUCLIN
	// Dunno what Instill doubt was changed to, but 9f20 is MobUpdate now so....
	#define OP_InstillDoubt		0xFFFF
#else
	#define OP_InstillDoubt    0x9f20
#endif
#define OP_GiveItem			0xd120
#define OP_ExpansionInfo	0xd821
#define OP_GMHideMe			0xd421
#define OP_Random			0xe721

// Agz: The following is from the old source I used as base
/************ ENUMERATED PACKET OPCODES ************/
#define ALL_FINISH                  0x0500
#define LS_REQUEST_VERSION          0x5900
#define LS_SEND_VERSION             0x5900
#define LS_SEND_LOGIN_INFO          0x0100
#define LS_SEND_SESSION_ID          0x0400
#define LS_REQUEST_UPDATE           0x5200
#define LS_SEND_UPDATE              0x5200
#define LS_REQUEST_SERVERLIST       0x4600
#define LS_SEND_SERVERLIST          0x4600
#define LS_REQUEST_SERVERSTATUS     0x4800
#define LS_SEND_SERVERSTATUS        0x4A00
#define LS_GET_WORLDID              0x4700
#define LS_SEND_WORLDID             0x4700
#define WS_SEND_LOGIN_INFO          0x5818
#define WS_SEND_LOGIN_APPROVED      0x0710
#define WS_SEND_LOGIN_APPROVED2     0x0180
#define WS_SEND_CHAR_INFO           0x4720
#endif
