/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef CLIENT_H
#define CLIENT_H

#include "../common/EQNetwork.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "zoneserver.h"

#define CLIENT_TIMEOUT 30000

class Client
{
public:
	Client(EQNetworkConnection* ieqnc);
    ~Client();
	
	bool		Process();
	void		ReceiveData(uchar* buf, int len);
	void		SendCharInfo();
	void		EnterWorld(bool TryBootup = true);
	void		ZoneUnavail();
	void		QueuePacket(APPLAYER* app, bool ack_req = true);

	int32		GetIP()				{ return ip; }
	int16		GetPort()			{ return port; }
	const char*	GetZoneName()		{ return zone_name; }
	int			GetAdmin()			{ return admin; }
	bool		WaitingForBootup()	{ return pwaitingforbootup; }
	bool		GenPassKey(char* key);
private:
	int32	ip;
	int16	port;
	int32	account_id;
	char	char_name[64];
	char	zone_name[25];
	Timer*	autobootup_timeout;
	int32	pwaitingforbootup;
	int admin;

	EQNetworkConnection* eqnc;
};

class ClientList
{
public:
	ClientList();
	~ClientList();
	
	void	Add(Client* client);
	Client*	Get(int32 ip, int16 port);
	void	Process();

	void	ZoneBootup(ZoneServer* zs);
private:
	LinkedList<Client*> list;
};

#endif
