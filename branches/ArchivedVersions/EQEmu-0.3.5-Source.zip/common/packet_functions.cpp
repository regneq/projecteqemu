/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <zlib.h>
#include <assert.h>

#include "EQCheckTable.h"
#include "EQNetwork.h"
#include "packet_functions.h"

#ifndef WIN32
#include <netinet/in.h>
#endif

void SetEQChecksum(uchar* in_data, int32 in_length)
{
	unsigned long data;
    unsigned long check = 0xffffffff;

assert(in_length >= 4 && in_data);

    for(int i=4; i<in_length; i++)
    {
        data = in_data[i];
        data = data ^ (check);
        data = data & 0x000000ff;
        check = check >> 8;
        data = check_table[data];
        check = check ^ data;
    }

    memcpy(in_data, (char*)&check, 4);
}

/*
	This is current release as of 23/okt
*/
void EncryptProfilePacket(APPLAYER* app) {
	int32* data=(int32*)app->pBuffer;
	int32 crypt = 0x65e7;
	int32 next_crypt;

	int32 swap = data[0];
	data[0] = data[app->size/8];
	data[app->size/8] = swap;

    for(int i=0; i<app->size/4;i++)
    {
		next_crypt = crypt+data[i]-0x37a9;
		data[i] = ((data[i]<<0x07)|(data[i]>>0x19))+0x37a9;
		data[i] =  (data[i]<<0x0f)|(data[i]>>0x11);
		data[i] = data[i] - crypt;
		crypt = next_crypt;
    }
}

void EncryptSpawnPacket(APPLAYER* app) {
	EncryptSpawnPacket(app->pBuffer, app->size);
}

void EncryptSpawnPacket(uchar* pBuffer, int32 size) {
	int32* data = (int32*) pBuffer;
	int32 len = size >> 2;		// number of int32's
	int32 crypt = 0;
	int32 next_crypt;
	for (int i=0; i<len; i++) {
		next_crypt = crypt + data[i] - 0x65e7;
		data[i] = ((data[i] << 0x09) | (data[i] >> 0x17)) + 0x65E7;
		data[i] = ((data[i] << 0x0d) | (data[i] >> 0x13)) - crypt;
		crypt = next_crypt;
	}
}

void EncryptZoneSpawnPacket(APPLAYER* app) {
	EncryptZoneSpawnPacket(app->pBuffer, app->size);
}

void EncryptZoneSpawnPacket(uchar* pBuffer, int16 size) {
	int32* data=(int32*)pBuffer;
	int32 crypt = 0x0000;
	int32 next_crypt;
	int32 swap = data[0];
	data[0] = data[size/8];
	data[size/8] = swap;
    for(int i=0; i<size/4;i++) {
		next_crypt = crypt+data[i]-0x65e7;
		data[i] = ((data[i]<<0x09)|(data[i]>>0x17))+0x65e7;
		data[i] =  (data[i]<<0x0d)|(data[i]>>0x13);
		data[i] = data[i] - crypt;
		crypt = next_crypt;
    }
}

int DeflatePacket(unsigned char* in_data, int in_length, unsigned char* out_data, int max_out_length) {
	z_stream zstream;
    int zerror;

	zstream.next_in   = in_data;
	zstream.avail_in  = in_length;
	zstream.zalloc    = Z_NULL;
	zstream.zfree     = Z_NULL;
	zstream.opaque    = Z_NULL;
	deflateInit(&zstream, Z_FINISH);
	zstream.next_out  = out_data;
	zstream.avail_out = max_out_length;
	zerror = deflate(&zstream, Z_FINISH);

	if (zerror == Z_STREAM_END)
	{
		deflateEnd(&zstream);
//		cout << "Unpacked size:" << in_length << " Packed size:" << zstream.total_out << endl;
		return zstream.total_out;
	}
	else
	{
		zerror = deflateEnd(&zstream);
//		cout << "Unpack error:" << zerror << endl;
		return 0;
	}
}

uint32 InflatePacket(uchar* indata, uint32 indatalen, uchar* outdata, uint32 outdatalen) {
	z_stream zstream;
	int zerror = 0;
	int i;

	zstream.next_in		= indata;
	zstream.avail_in	= indatalen;
	zstream.next_out	= outdata;
	zstream.avail_out	= outdatalen;
	zstream.zalloc		= Z_NULL;
	zstream.zfree		= Z_NULL;
	zstream.opaque		= Z_NULL;
	
	i = inflateInit2( &zstream, 15 ); 
	if (i != Z_OK) { 
		return 0;
	}

	zerror = inflate( &zstream, Z_FINISH );

	if(zerror == Z_STREAM_END) {
		inflateEnd( &zstream );
		return zstream.total_out;
	}
	else {
		cout << "Error: InflatePacket: inflate() returned " << zerror << " '";
		if (zstream.msg)
			cout << zstream.msg;
		cout << "'" << endl;
		if (zerror == -4 && zstream.msg == 0)
			return 0;
		zerror = inflateEnd( &zstream );
		return 0;
	}	
}

int32 RoL(int32 in, int32 bits) {
	int32 temp, out;

	temp = in;
	temp >>= (32 - bits);
	out = in;
	out <<= bits;
	out |= temp;

	return out;
}

int32 CRCLookup(uchar idx) {
	if (idx == 0)
		return 0x00000000;

	if (idx == 1)
		return 0x77073096;

	if (idx == 2)
		return RoL(CRCLookup(1), 1);

	if (idx == 4)
		return 0x076DC419;
    
	for (uchar b=7; b>0; b--) {
		uchar bv = 1 << b;

		if (!(idx ^ bv)) {
			/* bit is only one set */
			return ( RoL(CRCLookup (4), b - 2) );
		}

		if (idx&bv) {
			/* bit is set */
			return( CRCLookup(bv) ^ CRCLookup(idx&(bv - 1)) );
		}
	}
	//Failure
	return false;
}

uint32 GenerateCRC(int32 b, int32 bufsize, uchar *buf) {
	int32 CRC = (b ^ 0xFFFFFFFF);
	int32 bufremain = bufsize;
	uchar* bufptr = buf;

	while (bufremain--) {
		CRC = CRCLookup((uchar)(*(bufptr++)^ (CRC&0xFF))) ^ (CRC >> 8);
	}

	return (htonl (CRC ^ 0xFFFFFFFF));
}
