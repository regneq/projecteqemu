/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <iomanip.h>
#include <time.h>
#include <stdlib.h>

#ifdef WIN32
	#include <process.h>
	#include <windows.h>
	#include <winsock.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp	_stricmp
	#define	execl		_execl
#else // Pyro: fix for linux
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <pthread.h>
	#include <errno.h>
	#include <unistd.h>

	#include "../common/unix.h"

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1
	extern int errno;
#endif

#include "../common/servertalk.h"
#include "worldserver.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "mob.h"
#include "zone.h"
#include "client.h"
#include "entity.h"
#include "net.h"
#include "petitions.h"
#include "../common/packet_functions.h"
#include "PlayerCorpse.h"

extern Database database;
extern EntityList    entity_list;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern void CatchSignal(int);
extern WorldServer worldserver;
extern NetConnection net;
extern PetitionList petition_list;
extern GuildRanks_Struct guilds[512];
extern volatile bool RunLoops;
bool WorldLoopRunning = false;

WorldServer::WorldServer() {
	ip = 0;
	port = 0;
	send_socket = SOCKET_ERROR;
	timeout_timer = new Timer(SERVER_TIMEOUT);
	ReconnectTimer = new Timer(INTERSERVER_TIMER);
	connection_state = WSCS_Construction;
	recvbuf = 0;
}

WorldServer::~WorldServer() {
	safe_delete(timeout_timer);
	safe_delete(ReconnectTimer);
	safe_delete(recvbuf);
}

bool WorldServer::Init() {
	if (GetState() == WSCS_Construction) {
#ifdef WIN32
		_beginthread(WorldServerLoop, 0, NULL);
#else
		pthread_t thread;
		pthread_create(&thread, NULL, WorldServerLoop, NULL);
#endif
		return Connect(true);
	}
	else {
		return Connect();
	}
}

void WorldServer::SetZone(const char* zonename) {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_SetZone;
	pack->size = strlen(zonename) + 1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	memcpy(pack->pBuffer, zonename, strlen(zonename));
	SendPacket(pack);
	delete pack;
}

void WorldServer::SetConnectInfo() {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_SetConnectInfo;
	pack->size = sizeof(ServerConnectInfo);
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerConnectInfo* sci = (ServerConnectInfo*) pack->pBuffer;
	sci->port = net.GetZonePort();
	strcpy(sci->address, net.GetZoneAddress());
	SendPacket(pack);
	delete pack;
}

void WorldServer::Process()
{
	if (this == 0) return;
	if (!Connected()) return;
#ifdef WIN32
    SOCKADDR_IN to;
#else
    struct sockaddr_in to;
#endif

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	ServerPacket *pack = 0;
	while(pack = ServerRecvQueuePop())
	{
		adverrornum = pack->opcode;
		switch(pack->opcode) {
		case 0: {
			break;
		}
		case ServerOP_KeepAlive: {
			// ignore this
			break;
		}
		case ServerOP_ChannelMessage:
		{
			if (!ZoneLoaded) break;
			ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;
			if (scm->deliverto[0] == 0) {
				entity_list.ChannelMessageFromWorld(scm->from, scm->to, scm->chan_num, scm->guilddbid, scm->language, scm->message);
			}
			else {
				Client* client;
				client = entity_list.GetClientByName(scm->deliverto);
				if (client != 0) {
					if (client->Connected()) {
						client->ChannelMessageSend(scm->from, scm->to, scm->chan_num, scm->language, scm->message);
						if (!scm->noreply) {
							// if it's a tell, echo back so it shows up
							scm->noreply = true;
							scm->chan_num = 14;
							memset(scm->deliverto, 0, sizeof(scm->deliverto));
							strcpy(scm->deliverto, scm->from);
							SendPacket(pack);
						}
					}
				}
			}
			break;
		}
		case ServerOP_EmoteMessage: {
			if (!ZoneLoaded) break;
			ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
			if (sem->to[0] != 0) {
				if (strcasecmp(sem->to, zone->GetShortName()) == 0)
					entity_list.Message(sem->guilddbid, sem->type, sem->message);
				else {
					Client* client = entity_list.GetClientByName(sem->to);
					if (client != 0)
						client->Message(sem->type, sem->message);
				}
			}
			else
				entity_list.Message(sem->guilddbid, sem->type, sem->message);
			break;
		}
		case ServerOP_ShutdownAll: {
			entity_list.Save();
			CatchSignal(2);
			break;
		}
		case ServerOP_ZoneShutdown: {
			// Annouce the change to the world
			if (!ZoneLoaded) {
				SetZone("");
			}
			else {
				worldserver.SendEmoteMessage(0, 0, 15, "Zone shutdown: %s", zone->GetLongName());

				ServerZoneStateChange_struct* zst = (ServerZoneStateChange_struct *) pack->pBuffer;
				cout << "Zone shutdown by " << zst->adminname << endl;
				Zone::Shutdown();
			}
			break;
		}
		case ServerOP_ZoneBootup: {
			ServerZoneStateChange_struct* zst = (ServerZoneStateChange_struct *) pack->pBuffer;
			if (ZoneLoaded) {
				SetZone(zone->GetShortName());
				if (strcasecmp(zst->zonename, zone->GetShortName()) == 0) {
					// This packet also doubles as "incomming client" notification, lets not shut down before they get here
					zone->StartShutdownTimer(AUTHENTICATION_TIMEOUT * 1000);
				}
				else {
					worldserver.SendEmoteMessage(zst->adminname, 0, 0, "Zone bootup failed: Already running '%s'", zone->GetShortName());
				}
				break;
			}

			if (zst->adminname[0] != 0)
				cout << "Zone bootup by " << zst->adminname << endl;

			if (!(Zone::Bootup(zst->zonename))) {
				worldserver.SendChannelMessage(0, 0, 10, 0, 0, "%s:%i Zone::Bootup failed: %s", net.GetZoneAddress(), net.GetZonePort(), zst->zonename);
			}
// Moved annoucement to ZoneBootup() - Quagmire
//			else
//				worldserver.SendEmoteMessage(0, 0, 15, "Zone bootup: %s", zone->GetLongName());
			break;
		}
		case ServerOP_ZonePlayer: {
			ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(szp->name);
			if (client != 0) {
				if (strcasecmp(szp->adminname, szp->name) == 0)
					client->Message(0, "Zoning to: %s", szp->zone);
				else if (client->GetAnon() == 1 && client->Admin() > szp->adminrank)
					break;
				else {
					worldserver.SendEmoteMessage(szp->adminname, 0, 0, "Summoning %s to %s %1.1f, %1.1f, %1.1f", szp->name, szp->zone, szp->x_pos, szp->y_pos, szp->z_pos);
				}
				client->MovePC(szp->zone, szp->x_pos, szp->y_pos, szp->z_pos, szp->ignorerestrictions, true);
			}
			break;
		}
		case ServerOP_KickPlayer: {
			ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(skp->name);
			if (client != 0) {
				if (skp->adminrank >= client->Admin()) {
					client->WorldKick();
					if (ZoneLoaded)
						worldserver.SendEmoteMessage(skp->adminname, 0, 0, "Remote Kick: %s booted in zone %s.", skp->name, zone->GetShortName());
					else
						worldserver.SendEmoteMessage(skp->adminname, 0, 0, "Remote Kick: %s booted.", skp->name);
				}
				else if (client->GetAnon() != 1)
					worldserver.SendEmoteMessage(skp->adminname, 0, 0, "Remote Kick: Your avatar level is not high enough to kick %s", skp->name);
			}
			break;
		}
		case ServerOP_KillPlayer: {
			ServerKillPlayer_Struct* skp = (ServerKillPlayer_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(skp->target);
			if (client != 0) {
				if (skp->admin >= client->Admin()) {
					client->GMKill();
					if (ZoneLoaded)
						worldserver.SendEmoteMessage(skp->gmname, 0, 0, "Remote Kill: %s killed in zone %s.", skp->target, zone->GetShortName());
					else
						worldserver.SendEmoteMessage(skp->gmname, 0, 0, "Remote Kill: %s killed.", skp->target);
				}
				else if (client->GetAnon() != 1)
					worldserver.SendEmoteMessage(skp->gmname, 0, 0, "Remote Kill: Your avatar level is not high enough to kill %s", skp->target);
			}
			break;
		}
		case ServerOP_RefreshGuild: {
			if (pack->size == 5) {
				int32 guildeqid = 0;
				memcpy(&guildeqid, pack->pBuffer, 4);
				database.GetGuildRanks(guildeqid, &guilds[guildeqid]);
				if (pack->pBuffer[4] == 1) {
					APPLAYER* outapp = new APPLAYER;
					outapp->opcode = OP_GuildUpdate;
	   				outapp->size = 64;
					outapp->pBuffer = new uchar[outapp->size];
					memset(outapp->pBuffer, 0, outapp->size);
					GuildUpdate_Struct* gu = (GuildUpdate_Struct*) outapp->pBuffer;
					gu->guildID = guildeqid;
					gu->entry.guildID = guildeqid;
					if (guilds[guildeqid].databaseID == 0) {
						gu->entry.exists = 0; // = 0x01 if exists, 0x00 on empty
					}
					else {
						strcpy(gu->entry.name, guilds[guildeqid].name);
						gu->entry.exists = 1; // = 0x01 if exists, 0x00 on empty
					}
					gu->entry.unknown1[0] = 0xFF;
					gu->entry.unknown1[1] = 0xFF;
					gu->entry.unknown1[2] = 0xFF;
					gu->entry.unknown1[3] = 0xFF;
					gu->entry.unknown3[0] = 0xFF;
					gu->entry.unknown3[1] = 0xFF;
					gu->entry.unknown3[2] = 0xFF;
					gu->entry.unknown3[3] = 0xFF;

					entity_list.QueueClients(0, outapp, false);
					delete outapp;
				}
			}
			else
				cout << "Wrong size: ServerOP_RefreshGuild. size=" << pack->size << endl;
			break;
		}
		case ServerOP_GuildLeader: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (client->GuildRank() != 0)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is not rank 0.", client->GetName());
			else {
				if (database.SetGuildLeader(sgc->guilddbid, client->AccountID())) {
					worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s is now the leader of your guild.", client->GetName());
					ServerPacket* pack2 = new ServerPacket;
					pack2->opcode = ServerOP_RefreshGuild;
					pack2->size = 4;
					pack2->pBuffer = new uchar[pack->size];
					memcpy(pack2->pBuffer, &sgc->guildeqid, 4);
					worldserver.SendPacket(pack2);
					delete pack2;
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Guild leadership transfer failed.");
			}
			break;
		}
		case ServerOP_GuildInvite: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (!guilds[sgc->guildeqid].rank[sgc->fromrank].invite)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to invite.");
			else if (client->GuildDBID() != 0)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is already in another guild.", client->GetName());
			else if (client->PendingGuildInvite != 0 && !(client->PendingGuildInvite == sgc->guilddbid))
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s has another pending guild invite.", client->GetName());
			else {
				client->PendingGuildInvite = sgc->guilddbid;
				APPLAYER* outapp = new APPLAYER;
				outapp->opcode = OP_GuildInvite;
				outapp->size = sizeof(GuildCommand_Struct);
				outapp->pBuffer = new uchar[outapp->size];
				memset(outapp->pBuffer, 0, outapp->size);
				GuildCommand_Struct* gc = (GuildCommand_Struct*) outapp->pBuffer;
				gc->guildeqid = sgc->guildeqid;
				strcpy(gc->othername, sgc->target);
				strcpy(gc->myname, sgc->from);
				client->QueuePacket(outapp);
/*				
				if (client->SetGuild(sgc->guilddbid, GUILD_MAX_RANK))
					worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has joined the guild. Rank: %s.", client->GetName(), guilds[sgc->guildeqid].rank[GUILD_MAX_RANK].rankname);
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Guild invite failed.");
*/
			}
			break;
		}
		case ServerOP_GuildRemove: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if ((!guilds[sgc->guildeqid].rank[sgc->fromrank].remove) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to remove.");
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (client->GuildRank() <= sgc->fromrank && !(sgc->fromaccountid == guilds[sgc->guildeqid].leader) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s's rank is too high for you to remove them.", client->GetName());
			else {
				if (client->SetGuild(0, GUILD_MAX_RANK)) {
					if (strcasecmp(sgc->from, sgc->target) == 0)
						worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has left the guild.", client->GetName());
					else {
						worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been removed from the guild by %s.", client->GetName(), sgc->from);
						client->Message(MT_Guild, "You have been removed from the guild by %s.", sgc->from);
					}
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Guild remove failed.");
			}
			break;
		}
		case ServerOP_GuildPromote: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if ((!guilds[sgc->guildeqid].rank[sgc->fromrank].promote) && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to promote.");
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s isnt in your guild.", client->GetName());
			else if (client->GuildRank() <= sgc->newrank)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is already rank %i.", client->GetName(), client->GuildRank());
			else if (sgc->newrank <= sgc->fromrank && sgc->fromaccountid != guilds[sgc->guildeqid].leader)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You cannot promote people to a greater or equal rank than yourself.");
			else {
				if (client->SetGuild(sgc->guilddbid, sgc->newrank)) {
					worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been promoted to %s by %s.", client->GetName(), guilds[sgc->guildeqid].rank[sgc->newrank].rankname, sgc->from);
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Guild promote failed");
			}
			break;
		}
		case ServerOP_GuildDemote: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);

			if (client == 0) {
				// do nothing
			}
			else if (client->GuildDBID() != sgc->guilddbid)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is not in your guild.", client->GetName());
			else if (!guilds[sgc->guildeqid].rank[sgc->fromrank].demote)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You dont have permission to demote.");
			else if (client->GuildRank() >= sgc->newrank)
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "%s is already rank %i.", client->GetName(), client->GuildRank());
			else if (sgc->newrank <= sgc->fromrank && sgc->fromaccountid != guilds[sgc->guildeqid].leader && !(strcasecmp(sgc->from, sgc->target) == 0))
				worldserver.SendEmoteMessage(sgc->from, 0, 0, "You cannot demote people with a greater or equal rank than yourself.");
			else {
				if (client->SetGuild(sgc->guilddbid, sgc->newrank)) {
					worldserver.SendEmoteMessage(0, sgc->guilddbid, MT_Guild, "%s has been demoted to %s by %s.", client->GetName(), guilds[sgc->guildeqid].rank[sgc->newrank].rankname, sgc->from);
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Guild demote failed");
			}
			break;
		}
		case ServerOP_GuildGMSet: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);
			if (client != 0) {
				if (client->GuildDBID() == 0 || sgc->guilddbid == 0) {
					if (!client->SetGuild(sgc->guilddbid, GUILD_MAX_RANK))
						worldserver.SendEmoteMessage(sgc->from, 0, 0, "Error: Guild #%i not found", sgc->guilddbid);
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Error: %s is already in a guild", sgc->target);
			}
			break;
		}
		case ServerOP_GuildGMSetRank: {
			ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(sgc->target);
			if (client != 0) {
				if (client->GuildDBID() != 0) {
					if (!client->SetGuild(client->GuildDBID(), sgc->newrank))
						worldserver.SendEmoteMessage(sgc->from, 0, 0, "Error: SetRank failed.", sgc->guilddbid);
				}
				else
					worldserver.SendEmoteMessage(sgc->from, 0, 0, "Error: %s is not in a guild", sgc->target);
			}
			break;
		}
		case ServerOP_FlagUpdate: {
			Client* client = entity_list.GetClientByAccID(database.GetAccountIDByName((char*) pack->pBuffer));
			if (client != 0) {
				client->UpdateAdmin();
			}
			break;
		}
		case ServerOP_GMGoto: {
			if (pack->size != sizeof(ServerGMGoto_Struct)) {
				cout << "Wrong size on ServerOP_GMGoto. Got: " << pack->size << ", Expected: " << sizeof(ServerGMGoto_Struct) << endl;
				break;
			}
			if (!ZoneLoaded) break;
			ServerGMGoto_Struct* gmg = (ServerGMGoto_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(gmg->gotoname);
			if (client != 0) {
				worldserver.SendEmoteMessage(gmg->myname, 0, 13, "Summoning you to: %s @ %s, %1.1f, %1.1f, %1.1f", client->GetName(), zone->GetShortName(), client->GetX(), client->GetY(), client->GetZ());
				ServerPacket* outpack = new ServerPacket;
				outpack->opcode = ServerOP_ZonePlayer;
				outpack->size = sizeof(ServerZonePlayer_Struct);
				outpack->pBuffer = new uchar[outpack->size];
				memset(outpack->pBuffer, 0, outpack->size);
				ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) outpack->pBuffer;
				strcpy(szp->adminname, gmg->myname);
				strcpy(szp->name, gmg->myname);
				strcpy(szp->zone, zone->GetShortName());
				szp->x_pos = client->GetX();
				szp->y_pos = client->GetY();
				szp->z_pos = client->GetZ();
				worldserver.SendPacket(outpack);
				delete outpack;
			}
			else {
				worldserver.SendEmoteMessage(gmg->myname, 0, 13, "Error: %s not found", gmg->gotoname);
			}
			break;
		}
		case ServerOP_MultiLineMsg: {
			ServerMultiLineMsg_Struct* mlm = (ServerMultiLineMsg_Struct*) pack->pBuffer;
			Client* client = entity_list.GetClientByName(mlm->to);
			if (client) {
				APPLAYER* outapp = new APPLAYER(OP_MultiLineMsg, strlen(mlm->message));
				strcpy((char*) outapp->pBuffer, mlm->message);
				client->QueuePacket(outapp);
				delete outapp;
			}
			break;
		}
		case ServerOP_Uptime: {
			if (pack->size != sizeof(ServerUptime_Struct)) {
				cout << "Wrong size on ServerOP_Uptime. Got: " << pack->size << ", Expected: " << sizeof(ServerUptime_Struct) << endl;
				break;
			}
			ServerUptime_Struct* sus = (ServerUptime_Struct*) pack->pBuffer;
			int32 ms = Timer::GetCurrentTime();
			int32 d = ms / 86400000;
			ms -= d * 86400000;
			int32 h = ms / 3600000;
			ms -= h * 3600000;
			int32 m = ms / 60000;
			ms -= m * 60000;
			int32 s = ms / 1000;
			if (d)
				this->SendEmoteMessage(sus->adminname, 0, 0, "Zone #%i Uptime: %02id %02ih %02im %02is", sus->zoneserverid, d, h, m, s);
			else if (h)
				this->SendEmoteMessage(sus->adminname, 0, 0, "Zone #%i Uptime: %02ih %02im %02is", sus->zoneserverid, h, m, s);
			else
				this->SendEmoteMessage(sus->adminname, 0, 0, "Zone #%i Uptime: %02im %02is", sus->zoneserverid, m, s);
		}
		case ServerOP_Petition: {
			cout << "Got Server Requested Petition List Refresh" << endl;
			ServerPetitionUpdate_Struct* sus = (ServerPetitionUpdate_Struct*) pack->pBuffer;
			if (sus->status = 0) petition_list.ReadDatabase();
			else if (sus->status = 1) petition_list.ReadDatabase(); // Until I fix this to be better....
			break;
		}
		case ServerOP_RezzPlayer: {
			RezzPlayer_Struct* srs = (RezzPlayer_Struct*) pack->pBuffer;
			Resurrect_Struct* rezz = (Resurrect_Struct*) srs->packet;			
			if (srs->rezzopcode == OP_RezzRequest){
				Client* client =entity_list.GetClientByName(rezz->your_name);
				if (client){
					//client->SetZoneSummonCoords(srs->x_pos, srs->y_pos, srs->z_pos/10);
					client->pendingrezzexp = srs->exp;
					APPLAYER* outapp = new APPLAYER(srs->rezzopcode, sizeof(Resurrect_Struct));
					memcpy(outapp->pBuffer,srs->packet, sizeof(srs->packet));
					client->QueuePacket(outapp);
					delete outapp;
				}
			}
			if (srs->rezzopcode == OP_RezzComplete){
				Mob* corpse =entity_list.GetMob(rezz->corpse_name);
				if (corpse && corpse->IsCorpse())
					corpse->CastToCorpse()->CompleteRezz();
				
			}
			
			break;
		}
		case ServerOP_ZoneReboot: {
			cout << "Got Server Requested Zone reboot" << endl;
			ServerZoneReboot_Struct* zb = (ServerZoneReboot_Struct*) pack->pBuffer;

#ifdef WIN32
			char buffer[200];
			snprintf(buffer,200,". %s %i %s",zb->ip2, zb->port ,zb->ip1);
			cout << "excecuting: " << net.GetZoneFileName() << " " << buffer; 
			ShellExecute(0,"Open",net.GetZoneFileName(), buffer, 0, SW_SHOWDEFAULT);
#else
			char buffer[5];
			snprintf(buffer,5,"%i",zb->port); //just to be sure that it will work on linux			
			execl(net.GetZoneFileName(),net.GetZoneFileName(),".",zb->ip2, buffer,zb->ip1, NULL);
#endif
			break;
		}
		default:
		{
			cout << " Unknown ZSopcode:" << (int)pack->opcode;
			cout << " size:" << pack->size << endl;
DumpPacket(pack->pBuffer, pack->size);
			break;
		}
		}
		pack->opcode = 0;
		delete pack;
	}

	return;
}

bool WorldServer::SendPacket(ServerPacket* pack) {
	SPackSendQueue* spsq = (SPackSendQueue*) new uchar[sizeof(SPackSendQueue) + pack->size + 4];
	if (pack->pBuffer != 0 && pack->size != 0)
		memcpy((char *) &spsq->buffer[4], (char *) pack->pBuffer, pack->size);
	memcpy((char *) &spsq->buffer[0], (char *) &pack->opcode, 2);
	spsq->size = pack->size+4;
	memcpy((char *) &spsq->buffer[2], (char *) &spsq->size, 2);
	if (Connected()) {
		MQueueLock.lock();
		ServerSendQueue.push(spsq);
		MQueueLock.unlock();
		return true;
	}
	else {
		delete spsq;
		return false;
	}
}

SPackSendQueue* WorldServer::ServerSendQueuePop(bool block) {
	SPackSendQueue* ret = 0;
	if (block) {
		MQueueLock.lock();
	}
	else if (!MQueueLock.trylock()) {
		return 0;
	}
	ret = ServerSendQueue.pop();
	MQueueLock.unlock();
	return ret;
}

ServerPacket* WorldServer::ServerRecvQueuePop(bool block) {
	ServerPacket* ret = 0;
	if (block) {
		MQueueLock.lock();
	}
	else if (!MQueueLock.trylock()) {
		return 0;
	}
	ret = ServerRecvQueue.pop();
	MQueueLock.unlock();
	return ret;
}

bool WorldServer::SendChannelMessage(Client* from, const char* to, int8 chan_num, int32 guilddbid, int8 language, const char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->size = sizeof(ServerChannelMessage_Struct) + strlen(buffer) + 1;
	pack->pBuffer = new uchar[pack->size];
    memset(pack->pBuffer, 0, pack->size);
	ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;

	pack->opcode = ServerOP_ChannelMessage;
	if (from == 0)
		strcpy(scm->from, "ZServer");
	else {
		strcpy(scm->from, from->GetName());
		scm->fromadmin = from->Admin();
	}
	if (to == 0)
		scm->to[0] = 0;
	else {
		strcpy(scm->to, to);
		strcpy(scm->deliverto, to);
	}
	scm->chan_num = chan_num;
	scm->guilddbid = guilddbid;
	scm->language = language;
	strcpy(&scm->message[0], buffer);

	bool ret = SendPacket(pack);
	delete pack;
	return ret;
}

bool WorldServer::SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);
	
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_EmoteMessage;
	pack->size = sizeof(ServerEmoteMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
	sem->type = type;
	if (to != 0)
		strcpy(sem->to, to);
	sem->guilddbid = to_guilddbid;
	strcpy(sem->message, buffer);

	bool ret = SendPacket(pack);
	delete pack;
	return ret;
}
bool WorldServer::RezzPlayer(APPLAYER* rpack,int32 rezzexp, int16 opcode) {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_RezzPlayer;
	pack->size = sizeof(RezzPlayer_Struct);
	pack->pBuffer = new uchar[sizeof(RezzPlayer_Struct)];
	memset(pack->pBuffer, 0, pack->size);
	RezzPlayer_Struct* sem = (RezzPlayer_Struct*) pack->pBuffer;
	sem->rezzopcode = opcode;
	memcpy(sem->packet,rpack->pBuffer,sizeof(sem->packet));
	sem->exp = rezzexp;
	bool ret = SendPacket(pack);
	delete pack;
	return ret;
}
bool WorldServer::SendPacketQueue(bool block) {
	/************ Get first send packet on queue and send it! ************/
	SPackSendQueue* p = 0;    
	int status = 0;
	while(p = ServerSendQueuePop(block))
	{
//		cout << "Worldserver packet sent: OPcode=" << p->opcode << " size=" << p->size << endl;

#ifdef WIN32
		status = send(send_socket, (const char *) p->buffer, p->size, 0);
#else
		status = send(send_socket, p->buffer, p->size, 0);
#endif
		delete p;
		if (status == SOCKET_ERROR) {
#ifdef WIN32
    		cout << "Worldserver send(): status=" << status  << ", Errorcode: " << WSAGetLastError() << endl;
#else
    		cout << "Worldserver send(): status=" << status  << ", Errorcode: " << strerror(errno) << endl;
#endif
			return false;
		}
	}
    if (timeout_timer->Check())
    {
		// Keepalive packet doesnt actually do anything
		// just makes sure that send() still works, if not connection is dead
		// actual timeout is handeled by the TCP stack
		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_KeepAlive;
		pack->size = 0;
		SendPacket(pack);
		delete pack;
    }
	return true;
}

bool WorldServer::ReceiveData() {
	struct timeval tvtimeout = { 0, 0 };
	fd_set fds;
	FD_ZERO(&fds);
	FD_SET(send_socket, &fds);
#ifndef WIN32
	if (select(FD_SETSIZE, &fds, NULL, NULL, &tvtimeout) == 0) {
#else
	if (select(0, &fds, NULL, NULL, &tvtimeout) == 0) {
#endif
		// no data to receive
		return true;
	}
	LockMutex lock(&MQueueLock);
	uchar* tmpbuf;
	if (recvbuf == 0) {
		recvbuf = new uchar[5120];
		recvbuf_size = 5120;
		recvbuf_used = 0;
	}
	else if ((recvbuf_size - recvbuf_used) < 2048) {
		tmpbuf = new uchar[recvbuf_size + 5120];
		memcpy(tmpbuf, recvbuf, recvbuf_used);
		recvbuf_size += 5120;
		delete recvbuf;
		recvbuf = tmpbuf;
	}
    int status = recv(send_socket, (char *) &recvbuf[recvbuf_used], (recvbuf_size - recvbuf_used), 0);
    if (status >= 1) {
		timeout_timer->Start();
		recvbuf_used += status;
		int32 base = 0;
		int32 size = 4;
		uchar* buffer;
		ServerPacket* pack = 0;
		while ((recvbuf_used - base) >= size) {
			buffer = &recvbuf[base];
			memcpy(&size, &buffer[2], 2);
			if ((recvbuf_used - base) >= size) {
				// ok, we got enough data to make this packet!
				pack = new ServerPacket;
				memcpy(&pack->opcode, &buffer[0], 2);
				pack->size = size - 4;
/*				if () { // TODO: Checksum or size check or something similar
					// Datastream corruption, get the hell outta here!
					delete pack;
					return false;
				}*/
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &buffer[4], pack->size);
				ServerRecvQueue.push(pack);
				base += size;
				size = 4;
			}
		}
		if (base != 0) {
			if (base >= recvbuf_used) {
				safe_delete(recvbuf);
			}
			else {
				tmpbuf = new uchar[recvbuf_size - base];
				memcpy(tmpbuf, &recvbuf[base], recvbuf_used - base);
				delete recvbuf;
				recvbuf = tmpbuf;
				recvbuf_used -= base;
				recvbuf_size -= base;
			}
		}
    } else if (status == SOCKET_ERROR) {
#ifdef WIN32
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
#else
		if (!(errno == EWOULDBLOCK)) {
#endif
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Worldserver connection lost: " << inet_ntoa(in) << ":" << GetPort() << endl;
			return false;
		}
	}
	return true;
}

int8 WorldServer::GetState() {
	LockMutex lock(&MStateLock);
	int8 ret = connection_state;
	return ret;
}

void WorldServer::SetState(int8 in_state)	{
	LockMutex lock(&MStateLock);
	connection_state = in_state;
}

bool WorldServer::Connect(bool FromInit) {
	MStateLock.lock();
	if (!FromInit && connection_state != WSCS_Ready) {
		cout << "Error: WorldServer::Connect() while not ready" << endl;
		MStateLock.unlock();
		return false;
	}
	connection_state = WSCS_Connecting;
	MStateLock.unlock();
//	unsigned long nonblocking = 1;
    struct sockaddr_in	server_sin;
    struct in_addr	in;
#ifdef WIN32
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;
	PHOSTENT phostent = NULL;

	WSAStartup (version, &wsadata);
#else
	struct hostent *phostent = NULL;
#endif

	if ((send_socket = socket (AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)	{
#ifdef WIN32
		cout << "WorldServer connect: Allocating socket failed. Error: " << WSAGetLastError();
#else
		cout << "WorldServer connect: Allocating socket failed. Error: " << strerror(errno);
#endif
		SetState(WSCS_Ready);
		return false;
	}


	server_sin.sin_family = AF_INET;

	if ((phostent = gethostbyname(net.GetWorldAddress())) == NULL) {
#ifdef WIN32
		cout << "Unable to get the host name. Error: " << WSAGetLastError();
	    closesocket(send_socket);
#else
		cout << "Unable to get the host name. Error: " << strerror(errno);
	    close(send_socket);
#endif
		SetState(WSCS_Ready);
		return false;
	}
#ifdef WIN32
	memcpy ((char FAR *)&(server_sin.sin_addr), phostent->h_addr, phostent->h_length);
#else
	memcpy ((char*)&(server_sin.sin_addr), phostent->h_addr, phostent->h_length);
#endif
	server_sin.sin_port = htons(PORT);

	// Establish a connection to the server socket.
#ifdef WIN32
	if (connect (send_socket, (PSOCKADDR) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		cout << "WorldServer connect: Connecting to the server failed. Error: " << WSAGetLastError() << endl;
		closesocket(send_socket);
#else
	if (connect (send_socket, (struct sockaddr *) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		cout << "WorldServer connect: Connecting to the server failed. Error: " << strerror(errno) << endl;
		close(send_socket);
#endif
		SetState(WSCS_Ready);
		return false;
	}	
/*#ifdef WIN32
	ioctlsocket (send_socket, FIONBIO, &nonblocking);
#else
	fcntl(send_socket, F_SETFL, O_NONBLOCK);
#endif*/

// had to put a mini-receivedata here to handel switching the TCP
// connection to Zoneserver mode when enabled console commands
	int status = 0;
	uchar buffer[1024];
	memset(buffer, 0, sizeof(buffer));
	Timer con_timeout(15000);
	con_timeout.Start();
	SetState(WSCS_Authenticating);
	while (1) {
		if (!RunLoops) {
#ifdef WIN32
			closesocket(send_socket);
#else
			close(send_socket);
#endif
			SetState(WSCS_Ready);
			return false;
		}
		if (FromInit)
			Timer::SetCurrentTime();
		status = recv(send_socket, (char*) buffer, sizeof(buffer), 0);
		if (status >= 1) {
//DumpPacket(buffer, status);
			if (strncmp((char*) buffer, "Username: ", 10) == 0) {
				send(send_socket, "*ZONESERVER*\r\n", 14, 0);
			}
			else if (strncmp((char*) buffer, "ZoneServer Mode", 15) == 0 || strncmp((char*) buffer, "*ZONESERVER*\r\nZoneServer Mode", 29) == 0) {
				// Connection successful
				break;
			}
			else if (strncmp((char*) buffer, "Not Authorized.", 15) == 0 || strncmp((char*) buffer, "*ZONESERVER*\r\nNot Authorized.", 29) == 0) {
				// Connection failed. Worldserver said get lost
#ifdef WIN32
				closesocket(send_socket);
#else
				close(send_socket);
#endif
				SetState(WSCS_Ready);
				return false;
			}
			else if (strncmp((char*) buffer, "*ZONESERVER*\r\n", 14) == 0) {
				// Catch the echo, wait for next packet
			}
			else {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Unexpected response." << endl;
DumpPacket(buffer, status);
#ifdef WIN32
				closesocket(send_socket);
#else
				close(send_socket);
#endif
				SetState(WSCS_Ready);
				return false;
			}
		}
		else if (status == SOCKET_ERROR) {
#ifdef WIN32
			if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Error: " << WSAGetLastError() << endl;
				closesocket(send_socket);
#else // Pyro: fix for linux
			if (!(errno == EWOULDBLOCK)) {
				cout << "WorldServer connect: Connecting to the server failed: switch stage. Error: " << strerror(errno) << endl;
				close(send_socket);
#endif
				SetState(WSCS_Ready);
				return false;
			}
		}
		if (con_timeout.Check()) {
			cout << "WorldServer connect: Connecting to the server failed: switch stage. Time out." << endl;
#ifdef WIN32
			closesocket(send_socket);
#else
			close(send_socket);
#endif
			SetState(WSCS_Ready);
			return false;
		}
		if (GetState() != WSCS_Authenticating) {
#ifdef WIN32
			closesocket(send_socket);
#else
			close(send_socket);
#endif
			SetState(WSCS_Ready);
			return false;
		}
		Sleep(1);
	}

	if (GetState() != WSCS_Authenticating) {
#ifdef WIN32
		closesocket(send_socket);
#else
		close(send_socket);
#endif
		SetState(WSCS_Ready);
		return false;
	}

	in.s_addr = server_sin.sin_addr.s_addr;
	cout << "Connected to worldserver: " << inet_ntoa(in) << ":" << ntohs(server_sin.sin_port) << endl;
	ip = in.s_addr;
	port = server_sin.sin_port;
	SetState(WSCS_Connected);
	this->SetConnectInfo();
	if (ZoneLoaded) {
		this->SetZone(zone->GetShortName());
		entity_list.UpdateWho();
		this->SendEmoteMessage(0, 0, 15, "Zone connect: %s", zone->GetLongName());
	}
	return true;
}

void WorldServer::Disconnect() {
	ReconnectTimer->Start();
	LockMutex lock(&MStateLock);
	if (connection_state == WSCS_Ready || connection_state == WSCS_Construction) {
		return;
	}
	else if (connection_state == WSCS_Connected) {
		this->SendPacketQueue(true);
		shutdown(send_socket, 0x02);
#ifdef WIN32
		closesocket(send_socket);
#else
		close(send_socket);
#endif
		connection_state = WSCS_Ready;
	}
	else {
		connection_state = WSCS_Disconnecting;
	}
}

// this should always be called in a new thread
#ifdef WIN32
	void WorldServerLoop(void *tmp) {
#else
	void *WorldServerLoop(void *tmp) {
#endif
	WorldLoopRunning = true;
	while(RunLoops) {
		if (worldserver.Connected()) {
			if (!(worldserver.ReceiveData() && worldserver.SendPacketQueue())) {
				worldserver.Disconnect();
			}
		}
		else if (worldserver.GetState() == WSCS_Ready) {
			if (worldserver.ReconnectTimer->Check())
				worldserver.Connect();
		}
		Sleep(1);
	}
	WorldLoopRunning = false;
#ifndef WIN32
	return 0;
#endif
}
