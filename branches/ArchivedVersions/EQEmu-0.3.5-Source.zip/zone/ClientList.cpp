#include "../common/debug.h"
#include "ClientList.h"
#ifndef WIN32
	#include <pthread.h>
	#include "../common/unix.h"
#endif

ClientList client_list;

ClientList::ClientList() {
	list = new LinkedList<Client*>;
}

ClientList::~ClientList() {
	RemoveAll();
	delete list;
}

void ClientList::Add(Client* client)
{
	MListLock.lock();
	list->Insert(client);
	MListLock.unlock();
}

void ClientList::SendPacketQueues(bool block) {
	LockMutex lock(&MListLock);
	LinkedListIterator<Client*> iterator(*list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->SendPacketQueue(block);
		iterator.Advance();
	}
}

void ClientList::Remove(Client* client) {
	LockMutex lock(&MListLock);
	LinkedListIterator<Client*> iterator(*list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData() == client) {
			iterator.RemoveCurrent(false);
			break;
		}
		iterator.Advance();
	}
}

void ClientList::RemoveAll() {
	LockMutex lock(&MListLock);
	LinkedListIterator<Client*> iterator(*list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent(false);
	}
}

bool ClientList::RecvData(int32 ip, int16 port, uchar* buffer, int len) {
	LockMutex lock(&MListLock);
	LinkedListIterator<Client*> iterator(*list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		Client* client = iterator.GetData()->CastToClient();
		if (client->GetIP() == ip && client->GetPort() == port) {
			client->ReceiveData(buffer, len);
			return true;
		}
		iterator.Advance();
	}
	return false;
}

