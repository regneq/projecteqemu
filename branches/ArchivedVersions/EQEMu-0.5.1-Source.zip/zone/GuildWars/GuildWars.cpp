/*GuildWars� EverQuest Modification by Image (Dominic Micale)
**GuildWars� project began on September 24th, 2003
**Original ideas from GuildWars project which was released Feb of 2003
*/
#include "GuildWars.h"
#include "zone.h"

extern Zone* zone;

GuildLocationList location_list;
GuildWars	guildwars;

sint32 GuildWars::GetCurrentGuildFaction(Mob* mobone,Mob* mobtwo)
{
int32 targetguildid,otherguildid;
		if(mobone->IsClient())
			targetguildid = mobone->CastToClient()->GuildDBID();
		else
			targetguildid = mobone->CastToNPC()->GetGuildID();
		if(mobtwo->IsClient())
			otherguildid = mobtwo->CastToClient()->GuildDBID();
		else
			otherguildid = mobtwo->CastToNPC()->GetGuildID();

if(targetguildid == 0 || otherguildid == 0) // Somethings wrong, make sure they can't attack each other
return GW_ALLY;

return database.GetCurrentGuildFaction(targetguildid,otherguildid);
}

bool GuildWars::PurchaseNPC(Client* clientloc,int32 locid,int32 npcid)
{
	const NPCType* tmp = 0;
	if (tmp = database.GetNPCType(npcid)) {
	NPC* npc = new NPC(tmp, 0, clientloc->GetX(), clientloc->GetY(), clientloc->GetZ(), clientloc->GetHeading());
	entity_list.AddNPC(npc);
	int32 spawnid = database.NPCSpawnDB(1,zone->GetShortName(),npc,0);  //Insert it into the database
	database.InsertPurchasedNPC(clientloc->GuildDBID(),locid,spawnid);
	delete npc;
}
return true;
}

GuildWars::GuildWars(void)
{
}

GuildWars::~GuildWars(void)
{
}

GuildLocationList::GuildLocationList(void)
{
}

GuildLocationList::~GuildLocationList(void)
{
}

void GuildLocationList::ProcessLocations()
{
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
	if(!iterator.GetData()->Process())
		iterator.RemoveCurrent();
	iterator.Advance();
	}
}

GuildLocation* GuildLocationList::FindLocationByID(int32 locid)
{
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
		return iterator.GetData();
		}
		iterator.Advance();
	}
return 0;
}

void GuildLocationList::AddLocation(GuildLocation* gl)
{
list.Insert(gl);
}

bool GuildLocationList::RemoveLocation(int32 locid)
{
	if (locid == 0)
		return 0;
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
			iterator.RemoveCurrent();
			return true;
		}
		iterator.Advance();
	}
	return false;
}

void GuildLocationList::ClearLocations()
{
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
		iterator.Advance();
	}
}

GuildLocation::GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild)
{
location_id = locid;
x = xcoord;
y = ycoord;
z = zcoord;
zoneid = zone;
locationtype = type;
guildid = guild;
continueprocess = true;
takeover_delay = new Timer(1800000);
takeover_delay->Start();
takeover_check = new Timer(60000);
takeover_check->Start();
}

GuildLocation::~GuildLocation()
{
ResetNPCs();
ResetObjects();
delete takeover_delay;
delete takeover_check;
}

bool GuildLocation::Process()
{
if(!continueprocess)
return false;

if(takeover_delay->Check() && takeover_check->Check() && !GuardsStillStanding())
TakeOverProcess();

return true;
}

bool GuildLocation::TakeOverProcess()
{
//First need to see who killed the most guards, since there may be multiple guilds fighting for this city this determines who gets the land
int8 guardskilled[512];

	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(!iterator.GetData()->IsAlive())
		{
		int32 guildid = iterator.GetData()->GetKilledByLastGuildID();
		guardskilled[guildid]++;
		}
		iterator.Advance();
	}
int32 highestguild = 0;
for(int i=0;i<512;i++)
{
if(guardskilled[i] > guardskilled[highestguild])
highestguild = i;
}

if(guardskilled[highestguild] == 0)
return false;
else
TakeOverLocation(guildid);

return true;
}

void GuildLocation::TakeOverLocation(int32 guildid)
{
//If a city does not have any NPCs protecting it, then it can be openly claimed through a shout (this still needs to be programmed)
//If location is a camp, tower or a guild house, it is destroyed.
if(GetLocationType() == CAMP || GetLocationType() == GUILDHOUSE || GetLocationType() == TOWER)
{
database.RemoveLocation(GetLocationID()); // Remove location would foward to the deletion of NPCs and objects
continueprocess = false;
return;
}
//City just deletes NPCs and objects through database and location
ResetObjects();
ResetNPCs();
//City also resets the location timer (which allows it to be taken over, set a 30 minute delay)
takeover_delay->Start();
}

void GuildLocation::AddNPC(NPC* npc)
{
GuildNPCs* tempref = FindGuildNPCBySpawnID(npc->respawn2->GetID()); // Check if the NPC was earlier inserted into the listing, if true update its pointer
if(tempref != 0)
tempref->UpdateReferences(npc);
else
{
GuildNPCs* guildnpc = new GuildNPCs(npc);
guildnpcs.Insert(guildnpc);
}
}

int8 GuildLocation::GuardsSpotsRemaining()
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	
	iterator.Reset();
	int8 total = 0;
	while(iterator.MoreElements())
	{
		if(iterator.GetData())
			total++;
		iterator.Advance();
	}
	switch(GetLocationType())
	{
	case CITY:
		{
		total = MAXCITYNPCS - total;
		break;
		}
	case CAMP:
		{
		total = MAXCAMPNPCS - total;
		break;
		}
	case GUILDHOUSE:
		{
		total = MAXGUILDHOUSENPCS - total;
		break;
		}
	case TOWER:
		{
		total = MAXTOWERNPCS - total;
		break;
		}
	default:
		total = 0;
	}
return total;
}

bool GuildLocation::GuardsStillStanding()
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->IsAlive())
			return true;
		iterator.Advance();
	}
		return false;
}

GuildNPCs* GuildLocation::FindGuildNPCBySpawnID(int32 spawn_id)
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->NPCSpawnID() == spawn_id)
			return iterator.GetData();
		iterator.Advance();
	}
		return 0;
}

void GuildLocation::ResetNPCs()
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
		iterator.Advance();
	}
}

void GuildLocation::ResetObjects()
{
	LinkedListIterator<GuildObjects*> iterator(guildobjects);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
		iterator.Advance();
	}
}

GuildNPCs::GuildNPCs(NPC* npc)
{
npcpointer = npc;
spawn_id = npc->respawn2->GetID();
start_x = npc->GetX();
start_y = npc->GetY();
start_z = npc->GetZ();
alive = true; // Well since we are constructing it, it must be alive!
}

void GuildNPCs::UpdateReferences(NPC* npc) // When an NPC dies, it respawns with a new NPC construct
{
npcpointer = npc;
spawn_id = npc->respawn2->GetID();
start_x = npc->GetX();
start_y = npc->GetY();
start_z = npc->GetZ();
alive = true; // Since we are updating reference it must be alive.
}