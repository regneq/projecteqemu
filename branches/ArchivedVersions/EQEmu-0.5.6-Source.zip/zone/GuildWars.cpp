/*GuildWars� EverQuest Modification by Image (Dominic Micale)
**GuildWars� project began on September 24th, 2003
**Original ideas from GuildWars project which was released Feb of 2003
*/
#include "GuildWars.h"
#include "zone.h"
#include <math.h>
#include "worldserver.h"
#include "entity.h"

extern Zone* zone;
extern WorldServer worldserver;
extern EntityList entity_list;

GuildLocationList location_list;
GuildWars guildwars;
GuildFactionList guildfaction_list;
GuildApprovalList guildapproval_list;

//DB Includes
#include <iostream>
using namespace std;
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errmsg.h>
#include <windows.h>
#define snprintf	_snprintf
#define strncasecmp	_strnicmp
#define strcasecmp	_stricmp
#include "../common/guilds.h"
#include "StringIDs.h"
#include "../common/database.h"
extern GuildRanks_Struct guilds[512];

void GuildWars::Construct()
{
SetZoneStatus(1);
database.UpdateZoneOnlineStatus(GetCurrentZone(),GetZoneStatus());
database.GetZSStats(GetCurrentZone());
}

void GuildWars::Deconstruct()
{
SetCurrentUsers(0);
SetZoneStatus(0);
database.UpdateZoneOnlineStatus(GetCurrentZone(),GetZoneStatus());
database.UpdateZoneServerStats(GetCurrentZone(),GetCurrentUsers(),GetMaxUsers(),GetCampsCount(),GetTownsCount(),GetCitiesCount());
//Do final update of database, set status to be down, set current users = 0.
}

void GuildWars::Update()
{
database.UpdateZoneServerStats(GetCurrentZone(),GetCurrentUsers(),GetMaxUsers(),GetCampsCount(),GetTownsCount(),GetCitiesCount());
Construct();
guildfaction_list.ClearFactions();
}

sint32 GuildWars::CalculateFactionDecrease(Mob* killed,Mob* killedby)
{
if(!killed || !killedby)
return 0;

sint32 calc = 0;
calc += killed->GetLevel()*2;
if(killed->IsClient())
{
if(killed->CastToClient()->GuildRank() == 2)
calc += killed->GetLevel()*2;
else if(killed->CastToClient()->GuildRank() < 2)
calc += killed->GetLevel();
else
calc += killed->GetLevel()/2;
}
calc *= -1;

return calc;
}

sint32 GuildWars::CalculateFactionIncrease(Mob* killed,Mob* killedby)
{
if(!killed || !killedby)
return 0;

sint32 calc = 0;
calc += killed->GetLevel()/4;
if(killed->IsClient())
{
if(killed->CastToClient()->GuildRank() == 2)
calc += killed->GetLevel()/2;
else if(killed->CastToClient()->GuildRank() < 2)
calc += killed->GetLevel()/4;
else
calc += killed->GetLevel()/6;
}

return calc;
}

bool GuildWars::SpecialAttackPrivs(Mob* main, Mob* defend)
{
Client* client = 0;
Client* second = 0;
Group* clientgroup = 0;
Group* secondgroup = 0;
if(main->IsClient())
client = main->CastToClient();
else if(main->IsNPC() && main->GetOwner() != 0 && main->GetOwner()->IsClient())
client = main->GetOwner()->CastToClient();
if(defend->IsClient())
second = defend->CastToClient();
else if(defend->IsNPC() && defend->GetOwner() != 0 && defend->GetOwner()->IsClient())
second = defend->GetOwner()->CastToClient();

if(!client || !second)
return false;
else
{
if(!client->permitflag || !second->permitflag)
return false;
else
{
clientgroup = entity_list.GetGroupByClient(client);
secondgroup = entity_list.GetGroupByClient(second);
if(clientgroup == secondgroup)
return false;
else
return true;
}
}
return false;
}

bool GuildWars::SpecialCastPrivs(Mob* main, Mob* defend)
{
Client* client = 0;
Client* second = 0;
Group* clientgroup = 0;
Group* secondgroup = 0;
if(main->IsClient())
client = main->CastToClient();
else if(main->IsNPC() && main->GetOwner() != 0 && main->GetOwner()->IsClient())
client = main->GetOwner()->CastToClient();
if(defend->IsClient())
second = defend->CastToClient();
else if(defend->IsNPC() && defend->GetOwner() != 0 && defend->GetOwner()->IsClient())
second = defend->GetOwner()->CastToClient();

if(!client || !second)
return false;
else
{
if(!client->permitflag || !second->permitflag)
return false;
else
{
clientgroup = entity_list.GetGroupByClient(client);
secondgroup = entity_list.GetGroupByClient(second);
if(clientgroup == secondgroup)
return true;
else
return false;
}
}
return false;
}

char* GuildWars::GetRandomName()
{
	char	guardfirstnames[40][64] = { "Nolan", "Hue", "Marcel", "Marlin", "Edyth", "Jackson", "Hal", "Alvaro", "Jeffry", "Marvis", "Elwood", "Darius", "Franklyn", "Jerrell", "Joseph", "Garret", "Thu", "Leigh", "Del", "Wes", "Jeramy", "Waylon", "Gayle", "Colton", "Willian", "Mose", "Frerrann", "Edenad", "Drilawan", "Chardo", "Woadus", "Cilakath", "Gwerin", "Abeagan" };
	char	guardlastnames[40][64] = { "Zarlengo", "Humbird", "Schwieterman", "Dekay", "Blasingim", "Deuser", "Dalphonse", "Briston", "Lindel", "Chay", "Singson", "Cotterman", "Lisboa", "McCloud", "Moure", "Cossin", "Halprin", "Kachmar", "Primas", "Rieffenberg", "Kenning", "Donerson", "Consuegra", "Hennesy", "Ahles", "Maltez", "Hilderman", "Kermes", "Mcleskey", "Malinak" };

int8 first = MakeRandomInt(0,33);
int8 last = MakeRandomInt(0,29);

printf("First: %i Last: %i\n",first,last);

char name[64];
snprintf(name,64,"%s %s",guardfirstnames[first],guardlastnames[last]);

printf("RandomName: %s\n",name);

return name;
}

sint32 GuildWars::GetCurrentGuildFaction(Mob* mobone,Mob* mobtwo)
{

	int32 targetguildid,otherguildid;

	if(!mobone || !mobtwo)
		return GW_FACTIONNOTEXIST;
	if(mobone->GetOwner() != 0)
		mobone = mobone->GetOwner();
	if(mobtwo->GetOwner() != 0)
		mobtwo = mobtwo->GetOwner();

	if(mobone->IsClient())
		targetguildid = mobone->CastToClient()->GuildDBID();
	else
		targetguildid = mobone->CastToNPC()->GetGuildID();

	if(mobtwo->IsClient())
		otherguildid = mobtwo->CastToClient()->GuildDBID();
	else
		otherguildid = mobtwo->CastToNPC()->GetGuildID();

	if(targetguildid == 0 || otherguildid == 0) // Somethings wrong, make sure they can't attack each other
		return GW_FACTIONNOTEXIST;

	GuildFaction* gf = guildfaction_list.FindGuildFaction(targetguildid,otherguildid);
	sint32 factionreturn = GW_FACTIONNOTEXIST;
	if(gf)
	factionreturn = gf->GetFaction();
	else
	{
	factionreturn = database.GetGuildFaction(targetguildid,otherguildid);
	if(factionreturn != GW_FACTIONNOTEXIST)
	guildfaction_list.AddFaction(targetguildid,otherguildid,factionreturn);
	}

	return factionreturn;
}

sint32 GuildWars::GetCurrentGuildFactionByID(int32 targetguildid,int32 otherguildid)
{
	if(targetguildid == 0 || otherguildid == 0) // Somethings wrong, make sure they can't attack each other
		return GW_FACTIONNOTEXIST;

	GuildFaction* gf = guildfaction_list.FindGuildFaction(targetguildid,otherguildid);
	sint32 factionreturn = GW_FACTIONNOTEXIST;
	if(gf)
	factionreturn = gf->GetFaction();
	else
	{
	factionreturn = database.GetGuildFaction(targetguildid,otherguildid);
	if(factionreturn != GW_FACTIONNOTEXIST)
	guildfaction_list.AddFaction(targetguildid,otherguildid,factionreturn);
	}

	return factionreturn;
}

bool GuildWars::CanEnterZone(int32 guild_id, sint16 admin)
{
if(admin > 0)
return true;

GuildLocation* gl = 0;
if(location_one != 0)
{
gl = location_list.FindLocationByID(location_one);
if(gl != 0 && gl->GetLocationType() != MISC && gl->GetGuildOwner() != guild_id)
return false;
}
if(location_two != 0)
{
gl = location_list.FindLocationByID(location_two);
if(gl != 0 && gl->GetLocationType() != MISC && gl->GetGuildOwner() != guild_id)
return false;
}
if(location_three != 0)
{
gl = location_list.FindLocationByID(location_three);
if(gl != 0 && gl->GetLocationType() != MISC && gl->GetGuildOwner() != guild_id)
return false;
}
if(location_four != 0)
{
gl = location_list.FindLocationByID(location_four);
if(gl != 0 && gl->GetLocationType() != MISC && gl->GetGuildOwner() != guild_id)
return false;
}
return true;
}

bool GuildWars::BindAffinityAllowed()
{
if(location_one != 0 || location_two != 0 || location_three != 0 || location_four != 0)
return false;

return true;
}

void GuildWars::UpdateGuildWarsPoints(int32 charid,sint32 points)
{
sint32	guildcolumns[6] = { 0,0,0,0,0,0 };
sint32 purchase[4] = { 0,0,0,0 };
if(points < 0)
purchase[2] = points*-1;
else
purchase[1] = points;

database.UpdatePointsTable(charid,0,points,guildcolumns,purchase);
}

void GuildWars::EnteringMessages(Client* client)
{
if(client->profit != 0)
{
char val1[20]={0};
client->Message_StringID(0,RECEIVED_PLATINUM,client->ConvertArray(client->profit,val1),zone->GetLongName());
client->profit = 0;
}
int32 melee = client->meleepercentbonus*100;
int32 cast = client->castpercentbonus*100;
client->Message(0,"You currently receive a %i percent melee bonus and a %i percent casting bonus on damage for owned locations.",melee,cast);
client->Message(0,"You currently have %i PVP points available to spend on Adventure Merchants.",client->GetLDoNPoints());
if(client->GetLDoNPoints() > 0)
client->UpdateLDoNPoints(0,0);
}

void GuildWars::DeathPointUpdate(int32 attackerid,int32 defenderid)
{
				sint32	guildcolumns[6] = { 0,0,0,0,0,0 };
				sint32 playattacker[4] = { 1,0,0,0 }; //Adds 1 kill to their kills
				database.UpdatePointsTable(attackerid,0,0,guildcolumns,playattacker);
				sint32 playdefender[4] = { 0,0,0,1 }; // Adds 1 death to their deaths
				database.UpdatePointsTable(defenderid,0,0,guildcolumns,playdefender);
}

bool GuildWars::PurchaseNPC(Client* clientloc,int32 npcid)
{
#ifdef GWDEBUG
					printf("PurchaseNPC %i\n",npcid);
#endif
	//First, find the guildlocation that the client is currently located in (If one is even in range), then assign the NPC to it bleh bleh
	if(clientloc->GuildDBID() == 0 || clientloc->GuildRank() == 0)
	{
		clientloc->Message(0,"Only guild officers and leaders can create guards.");
		return false;
	}
#ifdef GWDEBUG
					printf("FindClosestLocation\n");
#endif
	GuildLocation* gl = location_list.FindClosestLocationByClient(clientloc);
	if(gl != 0 && gl->GetGuildOwner() == clientloc->GuildDBID())
	{
		const NPCType* tmp = 0;
#ifdef GWDEBUG
					printf("Check for Remaining GuardSpots & Permittable Guard Distance\n",npcid);
#endif
		if(gl->GuardsSpotsRemaining() == 0)
		{
			clientloc->Message(0,"This location has the max guards it can support.");
			return false;
		}
		else if(!gl->PermittableGuardDistance(clientloc))
		{
			clientloc->Message(0,"You are too close to another guard to spawn the NPC.");
			return false;
		}
		else if (tmp = database.GetNPCType(npcid)) {
#ifdef GWDEBUG
					printf("Setting up NPC\n",npcid);
#endif
			NPC* npc = new NPC(tmp, 0, clientloc->GetX(), clientloc->GetY(), clientloc->GetZ(), (clientloc->GetHeading()));
			int32 spawnid = database.NPCSpawnDB(1,zone->GetShortName(),npc,0);  //Insert it into the database
			if(spawnid != 0)
			database.InsertPurchasedNPC(clientloc->GuildDBID(),gl->GetLocationID(),spawnid);
			safe_delete(npc);
			return true;
		}
		else
		{
			clientloc->Message(0,"Unable to spawn guard, unknown reason.");
			return false;
		}
	}
	clientloc->Message(0,"Unable to find a location in this area which is controlled by your guild.");
	return false;
}

GuildWars::GuildWars(void)
{

}

GuildWars::~GuildWars(void)
{

}

GuildLocationList::GuildLocationList(void)
{
}

GuildLocationList::~GuildLocationList(void)
{
ClearLocations();
guildapproval_list.ClearGuilds();
}

int32 GuildLocationList::GetGuildProfit(int32 guildid)
{
	LinkedListIterator<GuildLocation*> iterator(list);
	int32 profit = 0;
	iterator.Reset();
	while(iterator.MoreElements())
	{
	if(iterator.GetData()->GetGuildOwner() == guildid && iterator.GetData()->GetProfit() != 0)
	profit += iterator.GetData()->GetProfit();
	iterator.Advance();
	}
return 0;
}

float GuildLocationList::GetMeleeAttackBonus(int32 guildid)
{
#ifdef GWDEBUG
	printf("GetMeleeAttackBonus: %i\n",guildid);
#endif
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	float bonus = 0.0;
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->GetGuildOwner() == guildid)
		{
			switch(iterator.GetData()->GetLocationType())
			{
			case CITY:
				{
					bonus += MELEECITYBONUS;
					break;
				}
			case CAMP:
				{
					bonus += MELEECAMPBONUS;
					break;
				}
			case GUILDHOUSE:
				{
					bonus += MELEEGUILDHOUSEBONUS;
					break;
				}
			case TOWER:
				{
					bonus += MELEETOWERBONUS;
					break;
				}
			}
		}
		iterator.Advance();
	}
	if(bonus < 0)
		bonus = 0;
	else if(bonus>.25)
		bonus = .25;

	return bonus;
}

float GuildLocationList::GetCasterAttackBonus(int32 guildid)
{
#ifdef GWDEBUG
	printf("GetCasterAttackBonus: %i\n",guildid);
#endif
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	float bonus = 0.0;
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->GetGuildOwner() == guildid)
		{
			switch(iterator.GetData()->GetLocationType())
			{
			case CITY:
				{
					bonus += CASTERCITYBONUS;
					break;
				}
			case CAMP:
				{
					bonus += CASTERCAMPBONUS;
					break;
				}
			case GUILDHOUSE:
				{
					bonus += CASTERGUILDHOUSEBONUS;
					break;
				}
			case TOWER:
				{
					bonus += CASTERTOWERBONUS;
					break;
				}
			}
		}
		iterator.Advance();
	}
		if(bonus < 0)
		bonus = 0;
	else if(bonus>.25)
		bonus = .25;

	return bonus;
}

void GuildLocationList::ProcessLocations()
{
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(!iterator.GetData()->Process())
			iterator.RemoveCurrent();
		iterator.Advance();
	}
	guildapproval_list.Process();
}

GuildLocation* GuildLocationList::FindLocationByID(int32 locid)
{
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

GuildLocation* GuildLocationList::FindClosestLocationByClient(Client* client)
{
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(zone->GetZoneID() == iterator.GetData()->GetZoneID())
		{
			int8 locationtype = iterator.GetData()->GetLocationType();
			float dist = 0;
			if(locationtype != CITY)
				dist = GetDistance(client->GetX(),client->GetY(),client->GetZ(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ());
#ifdef GWDEBUG
			printf("ClosestLocationDist: %f\n",dist);
#endif
			switch(locationtype)
			{
			case CITY:
				{
					//If you own a city in the zone, you can't have other property in that zone
					return iterator.GetData();
					break;
				}
			case CAMP:
				{
					if(dist <= OUTTERCAMPRADIUS && dist >= INNERCAMPRADIUS)
						return iterator.GetData();
					break;
				}
			case GUILDHOUSE:
				{
					if(dist <= OUTTERGUILDHOUSERADIUS && dist >= INNERGUILDHOUSERADIUS)
						return iterator.GetData();
					break;
				}
			case TOWER:
				{
					if(dist <= OUTTERTOWERRADIUS && dist >= INNERTOWERRADIUS)
						return iterator.GetData();
					break;
				}
			case MISC:
				{
					return iterator.GetData();
					break;
				}
			}
		}
		iterator.Advance();
	}
	return 0;
}

float GuildLocationList::GetDistance(float x1,float y1, float z1, float x2, float y2, float z2)
{
#ifdef GWDEBUG
	printf("GetDistance: %f %f %f / %f %f %f\n",x1,y1,z1,x2,y2,z2);
#endif
	double xDiff = x2 - x1;
	double yDiff = y2 - y1;
	double zDiff = z2 - z1;

	return sqrt( (xDiff * xDiff) 
	           + (yDiff * yDiff) 
		       + (zDiff * zDiff) );
}

void GuildLocationList::AddLocation(GuildLocation* gl)
{
	GuildLocation* possible = 0;
	if(possible = FindLocationByID(gl->GetLocationID()))
	{
	if(gl->GetGuildOwner() != possible->GetGuildOwner())
		possible->SetGuildOwner(gl->GetGuildOwner());
	if(gl->GetProfit() != possible->GetProfit())
		possible->SetProfit(gl->GetProfit());
	safe_delete(gl);
	}
	else
	list.Insert(gl);
}

bool GuildLocationList::RemoveLocation(int32 locid)
{
	if (locid == 0)
		return 0;
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
			iterator.RemoveCurrent();
			return true;
		}
		iterator.Advance();
	}
	return false;
}

void GuildLocationList::ClearLocations()
{
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
	}
	list.Clear();
}

void GuildLocationList::SendLocationInformation(Client* client, bool zoneonly)
{
	LinkedListIterator<GuildLocation*> iterator(list);

	iterator.Reset();
	if(!zoneonly)
		client->Message(13,"Please note that the information for guardspotsremaining and profit may be incorrect for locations not in this zone.");
	
	int count = 0;
	while(iterator.MoreElements())
	{
			if(zoneonly && iterator.GetData()->GetZoneID() != zone->GetZoneID())
			{
				iterator.Advance();
				continue;
			}

		count++;
		switch(iterator.GetData()->GetLocationType())
		{
		case CITY:
			{
			client->Message(0,"%i) Type: City, X: %f, Y: %f, Z: %f, Owner: %i, SpotsRemaining: %i, SS: %i, Profit: %ipp, Zone: %s",iterator.GetData()->GetLocationID(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ(),iterator.GetData()->GetGuildOwner(),iterator.GetData()->GuardsSpotsRemaining(),iterator.GetData()->GuardsStillStanding(),(iterator.GetData()->GetProfit()/1000),database.GetZoneName(iterator.GetData()->GetZoneID()));
			break;
			}
		case CAMP:
			{
			client->Message(0,"%i) Type: Camp, X: %f, Y: %f, Z: %f, Owner: %i, SpotsRemaining: %i, SS: %i, Zone: %s",iterator.GetData()->GetLocationID(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ(),iterator.GetData()->GetGuildOwner(),iterator.GetData()->GuardsSpotsRemaining(),iterator.GetData()->GuardsStillStanding(),database.GetZoneName(iterator.GetData()->GetZoneID()));
			break;
			}
		case TOWER:
			{
			client->Message(0,"%i) Type: Tower, X: %f, Y: %f, Z: %f, Owner: %i, SpotsRemaining: %i, SS: %i, Zone: %s",iterator.GetData()->GetLocationID(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ(),iterator.GetData()->GetGuildOwner(),iterator.GetData()->GuardsSpotsRemaining(),iterator.GetData()->GuardsStillStanding(),database.GetZoneName(iterator.GetData()->GetZoneID()));
			break;
			}
		case GUILDHOUSE:
			{
				client->Message(0,"%i) Type: GuildHouse, X: %f, Y: %f, Z: %f, Owner: %i, SpotsRemaining: %i, SS: %i, Zone: %s",iterator.GetData()->GetLocationID(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ(),iterator.GetData()->GetGuildOwner(),iterator.GetData()->GuardsSpotsRemaining(),iterator.GetData()->GuardsStillStanding(),database.GetZoneName(iterator.GetData()->GetZoneID()));
			break;
			}
		case MISC:
			{
				client->Message(0,"%i) Type: Misc, X: %f, Y: %f, Z: %f, Zone: %s",iterator.GetData()->GetLocationID(),iterator.GetData()->GetX(),iterator.GetData()->GetY(),iterator.GetData()->GetZ(),database.GetZoneName(iterator.GetData()->GetZoneID()));
			break;
			}
		}
		iterator.Advance();
	}
	if(count == 0)
		client->Message(13,"No locations found.");
}

GuildLocation::GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild)
{
	location_id = locid;
	x = xcoord;
	y = ycoord;
	z = zcoord;
	zoneid = zone;
	locationtype = type;
	guildid = guild;
	continueprocess = true;
	takeover_delay = new Timer(300000); //1800000
	takeover_delay->Start();
	takeover_check = new Timer(60000);
	takeover_check->Start();
	profit_timer = new Timer(1800000);
	profit_timer->Start();
	takeoverprocess = false;
}

GuildLocation::~GuildLocation()
{
	ResetNPCs();
	ResetObjects();
	delete takeover_delay;
	delete takeover_check;
	delete profit_timer;
}

bool GuildLocation::Process()
{
	if(!continueprocess)
		return false;

	if(GetZoneID() != zone->GetZoneID() || GetLocationType() == MISC)
		return true;

	if(takeover_delay->Check())
	{
#ifdef GWDEBUG
		printf("TakeOverTimer disabled.\n");
#endif
		takeover_delay->Disable();
		profit_timer->Start();
	}
	else if(takeover_delay->Enabled())
		return true;

	if(profit_timer->Check())
	{
		switch(GetLocationType())
		{
		case CITY:
			{
				profit += CITYPROFIT;
				if(profit >= 30000000)
					profit = 30000000;
				break;
			}
		case CAMP:
			{
				profit += CAMPPROFIT;
				break;
			}
		case GUILDHOUSE:
			{
				profit += GUILDHOUSEPROFIT;
				break;
			}
		case TOWER:
			{
				profit += TOWERPROFIT;
				break;
			}
		}
		database.SetLocationProfit(GetLocationID(),profit);
		//Update database with new profit information
	}
	if(takeover_check->Check())
	{
		if(GuardsStillStanding())
		{
		warntic++;
		if(warntic < 5)
		return true;
		else
		warntic = 1;

		switch(GetLocationType())
		{
	case CITY:
		{
			Client* client = entity_list.FindEnemiesAtLocation(GetX(),GetY(),GetZ(),OUTTERCITYRADIUS,GetGuildOwner());
			if(client != 0 && client->GuildDBID() != 0 && guildwars.GetCurrentGuildFactionByID(client->GuildDBID(),GetGuildOwner()) < GW_ALLY)
		worldserver.SendChannelMessage(0, 0, 0, GetGuildOwner(), 0, "The city of %s is in danger of attack by the guild %s!",zone->GetLongName(),guilds[database.GetGuildEQID(client->GuildDBID())].name);
			break;
		}
	case CAMP:
		{
			Client* client = entity_list.FindEnemiesAtLocation(GetX(),GetY(),GetZ(),OUTTERCAMPRADIUS,GetGuildOwner());
			if(client != 0 && client->GuildDBID() != 0 && guildwars.GetCurrentGuildFactionByID(client->GuildDBID(),GetGuildOwner()) < GW_ALLY)
		worldserver.SendChannelMessage(0, 0, 0, GetGuildOwner(), 0, "A camp in %s is in danger of attack by %s!",zone->GetLongName(),guilds[database.GetGuildEQID(client->GuildDBID())].name);
			break;
		}
	case GUILDHOUSE:
		{
			Client* client = entity_list.FindEnemiesAtLocation(GetX(),GetY(),GetZ(),OUTTERCAMPRADIUS,GetGuildOwner());
			if(client != 0 && client->GuildDBID() != 0 && guildwars.GetCurrentGuildFactionByID(client->GuildDBID(),GetGuildOwner()) < GW_ALLY)
		worldserver.SendChannelMessage(0, 0, 0, GetGuildOwner(), 0, "A guildhouse in %s is in danger of attack by %s!",zone->GetLongName(),guilds[database.GetGuildEQID(client->GuildDBID())].name);
			break;
		}
	case TOWER:
		{
			Client* client = entity_list.FindEnemiesAtLocation(GetX(),GetY(),GetZ(),OUTTERCAMPRADIUS,GetGuildOwner());
			if(client != 0 && client->GuildDBID() != 0 && guildwars.GetCurrentGuildFactionByID(client->GuildDBID(),GetGuildOwner()) < GW_ALLY)
		worldserver.SendChannelMessage(0, 0, 0, GetGuildOwner(), 0, "A tower in %s is in danger of attack by %s!",zone->GetLongName(),guilds[database.GetGuildEQID(client->GuildDBID())].name);
			break;
		}
		}
		}
		else
		{
		int8 guardspots = GuardsSpotsRemaining();
		switch(GetLocationType())
		{
	case CITY:
		{
			if(MAXCITYNPCS == guardspots)
			{
			Client* client = entity_list.FindRankingOfficialByLocation(GetX(),GetY(),GetZ(),OUTTERCITYRADIUS);
			if(client != 0 && client->GuildDBID() != GetGuildOwner())
				TakeOverLocation(client->GuildDBID());
			return true;
			}
			break;
		}
	case CAMP:
		{
			if(MAXCAMPNPCS == guardspots)
			{
			Client* client = entity_list.FindRankingOfficialByLocation(GetX(),GetY(),GetZ(),OUTTERCAMPRADIUS);
			if(client != 0 && client->GuildDBID() != GetGuildOwner())
				TakeOverLocation(client->GuildDBID());
			return true;
			}
			break;
		}
	case GUILDHOUSE:
		{
			if(MAXGUILDHOUSENPCS == guardspots)
			{
			Client* client = entity_list.FindRankingOfficialByLocation(GetX(),GetY(),GetZ(),OUTTERGUILDHOUSERADIUS);
			if(client != 0 && client->GuildDBID() != GetGuildOwner())
				TakeOverLocation(client->GuildDBID());
			return true;
			}
			break;
		}
	case TOWER:
		{
			if(MAXTOWERNPCS == guardspots)
			{
			Client* client = entity_list.FindRankingOfficialByLocation(GetX(),GetY(),GetZ(),OUTTERTOWERRADIUS);
			if(client != 0 && client->GuildDBID() != GetGuildOwner())
				TakeOverLocation(client->GuildDBID());
			return true;
			}
			break;
		}
		}
		TakeOverProcess();
	}
	}
	return true;
}

bool GuildLocation::TakeOverProcess()
{
#ifdef GWDEBUG
	printf("TakeOverProcess() called.\n");
#endif
	//First need to see who killed the most guards, since there may be multiple guilds fighting for this city this determines who gets the land
	int8 guardskilled[512];
	memset(guardskilled,0,sizeof(guardskilled));

	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(!iterator.GetData()->IsAlive())
		{
			int32 guildid = iterator.GetData()->GetKilledByLastGuildID();
			if(guildid != 0)
			{
#ifdef GWDEBUG
			printf("KilledByGuildID: %i\n",guildid);
#endif
			guardskilled[guildid] += 1;
			}
		}
		iterator.Advance();
	}
	int32 highestguild = 0;
	for(int i=0;i<512;i++)
	{
		if((guardskilled[i] > 0 && highestguild == 0) || (guardskilled[i] > guardskilled[highestguild]))
			highestguild = i;
	}

	if(highestguild == 0 || guardskilled[highestguild] == 0)
		return false;
	else
		TakeOverLocation(highestguild);

	return true;
}

void GuildLocation::TakeOverLocation(int32 guildid)
{
#ifdef GWDEBUG
	printf("TakeOverLocation(%i) called. (LocationType: %i LocationID: %i)\n",guildid,GetLocationType(),GetLocationID());
#endif
	takeoverprocess = true;
	//If a city does not have any NPCs protecting it, then it can be openly claimed through a shout (this still needs to be programmed)
	//If location is a camp, tower or a guild house, it is destroyed.
	// Camps, etc. do not destroy, new method
/*	if(GetLocationType() == CAMP || GetLocationType() == GUILDHOUSE || GetLocationType() == TOWER)
	{
#ifdef GWDEBUG
	printf("LocationType() == CAMP,GUILDHOUSE,TOWER\n");
#endif
		ResetObjects();
		ResetNPCs();
		database.RemovePurchasedNPCsByLocation(GetLocationID());
		database.RemoveLocation(GetLocationID());
		//Need to send a packet to the other zone servers telling them to remove the location
		ServerPacket* outpack = new ServerPacket(ServerOP_GWLocation, sizeof(GuildWarsLocationUpdate_Struct));
		GuildWarsLocationUpdate_Struct* gwl = (GuildWarsLocationUpdate_Struct*) outpack->pBuffer;
		gwl->updatetype = 0; // Remove = 0
		gwl->target_locationid = GetLocationID();
		gwl->current_zone = zone->GetZoneID();
		worldserver.SendPacket(outpack);
		safe_delete(outpack);
		takeoverprocess = false;
		continueprocess = false;
		return;
	}*/
	//Finds a guild officer/leader of this guild in the zone and gives him the guild slips to start the new city, if it can't find a guild officer/leader, the city is not handed over
	//Need to send a packet updating the new guild id
#ifdef GWDEBUG
	printf("FindRankingOfficialCall(%i)\n",guildid);
#endif
	Client* client = 0;
	client = entity_list.FindRankingOfficial(guildid);
	if(client != 0)
	{
#ifdef GWDEBUG
		printf("Found Ranking Official: %s\n",client->GetName());
#endif
	ServerPacket* outpack = new ServerPacket(ServerOP_GWLocation, sizeof(GuildWarsLocationUpdate_Struct));
	GuildWarsLocationUpdate_Struct* gwl = (GuildWarsLocationUpdate_Struct*) outpack->pBuffer;
	gwl->updatetype = 2; // Update Guild Owner = 0
	gwl->target_locationid = GetLocationID();
	gwl->current_zone = zone->GetZoneID();
	gwl->player_guildid = guildid;
	worldserver.SendPacket(outpack);
	safe_delete(outpack);
	//City just deletes NPCs and objects through database and location,updates database with new guildid information,tells other zones to update the guildid on this location
	ResetNPCs();
	database.RemovePurchasedNPCsByLocation(GetLocationID());
	database.SetLocationOwner(guildid,GetLocationID());
	SetGuildOwner(guildid);
	//ResetObjects();
	profit = 0;
	database.SetLocationProfit(GetLocationID(),0);
	//Update database with reset profit
	//City also resets the location timer (which allows it to be taken over, set a 30 minute delay)
	takeover_delay->Start();
#ifdef GWDEBUG
	printf("TakeOverProcess() complete.\n");
#endif
	if(GetLocationType() != CITY)
		worldserver.SendChannelMessage(0, 0, 0, guildid, 0, "Your guild has successfully taken over a location in %s",zone->GetLongName());
	else
		worldserver.SendChannelMessage(0, 0, 0, guildid, 0, "Your guild has successfully taken over %s",zone->GetLongName());
	}
	else
		worldserver.SendChannelMessage(0, 0, 0, guildid, 0, "Your guild is unable to take over %s because there is no officer or leader present.",zone->GetLongName());
	takeoverprocess = false;
}

void GuildLocation::AddNPC(NPC* npc)
{
	GuildNPCs* tempref = FindGuildNPCBySpawnID(npc->respawn2->GetID()); // Check if the NPC was earlier inserted into the listing, if true update its pointer
	if(tempref != 0)
		tempref->UpdateReferences(npc);
	else
	{
		GuildNPCs* guildnpc = new GuildNPCs(npc);
		guildnpcs.Insert(guildnpc);
	}
}

int8 GuildLocation::GuardsSpotsRemaining()
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);

	iterator.Reset();
	int8 total = 0;
	while(iterator.MoreElements())
	{
		if(iterator.GetData())
			total++;
		iterator.Advance();
	}
	switch(GetLocationType())
	{
	case CITY:
		{
			total = MAXCITYNPCS - total;
			break;
		}
	case CAMP:
		{
			total = MAXCAMPNPCS - total;
			break;
		}
	case GUILDHOUSE:
		{
			total = MAXGUILDHOUSENPCS - total;
			break;
		}
	case TOWER:
		{
			total = MAXTOWERNPCS - total;
			break;
		}
	default:
		total = 0;
	}
	return total;
}

bool GuildLocation::PermittableGuardDistance(Client* clientloc)
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);

	iterator.Reset();
	int8 total = 0;
	while(iterator.MoreElements())
	{
		float dist = location_list.GetDistance(clientloc->GetX(),clientloc->GetY(),clientloc->GetZ(),iterator.GetData()->GetStartX(),iterator.GetData()->GetStartY(),iterator.GetData()->GetStartZ());
#ifdef GWDEBUG
		printf("PermittableGuardDistance: %f (%i)\n",dist,iterator.GetData()->NPCSpawnID());
#endif
		if(dist < NPCTONPCRADIUS)
			return false;
		iterator.Advance();
	}
	return true;
}

bool GuildLocation::GuardsStillStanding()
{
#ifdef GWDEBUG
printf("GuardsStillstanding()\n");
#endif
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->IsAlive() && iterator.GetData()->ToNPC() != 0)
		{
#ifdef GWDEBUG
			printf("GuardStillStanding(): %i\n",iterator.GetData()->NPCSpawnID());
#endif
			return true;
		}
		iterator.Advance();
	}
#ifdef GWDEBUG
	printf("GuardsStillStanding(): No guards remaining.\n");
#endif
	return false;
}

GuildNPCs* GuildLocation::FindGuildNPCBySpawnID(int32 spawn_id)
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->NPCSpawnID() == spawn_id)
			return iterator.GetData();
		iterator.Advance();
	}
	return 0;
}

void GuildLocation::ResetNPCs()
{
	LinkedListIterator<GuildNPCs*> iterator(guildnpcs);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(takeoverprocess)
		{
			if(iterator.GetData()->ToNPC())
				entity_list.RemoveEntity(iterator.GetData()->ToNPC()->GetID());

			zone->RemoveSpawnEntry(iterator.GetData()->NPCSpawnID());
			zone->RemoveSpawnGroup(iterator.GetData()->SpawnGroupID());
		}
		iterator.RemoveCurrent();
	}
}

void GuildLocation::ResetObjects()
{
	LinkedListIterator<GuildObjects*> iterator(guildobjects);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
	}
}

GuildNPCs::GuildNPCs(NPC* npc)
{
	npcpointer = npc;
	spawn_id = npc->respawn2->GetID();
	start_x = npc->GetX();
	start_y = npc->GetY();
	start_z = npc->GetZ();
	spawn_group_id = npc->GetSp2();
	alive = true; // Well since we are constructing it, it must be alive!
	KilledByGuildID(0);
}

void GuildNPCs::UpdateReferences(NPC* npc) // When an NPC dies, it respawns with a new NPC construct
{
	npcpointer = npc;
	spawn_id = npc->respawn2->GetID();
	start_x = npc->GetX();
	start_y = npc->GetY();
	start_z = npc->GetZ();
	spawn_group_id = npc->GetSp2();
	alive = true; // Since we are updating reference it must be alive.
	KilledByGuildID(0);
}

GuildFaction::GuildFaction(int32 guildid, int32 otherguildid, sint32 faction)
{
guild_id = guildid;
other_guild_id = otherguildid;
set_faction = faction;
}

void GuildFactionList::AddFaction(int32 guildid, int32 otherguildid, sint32 faction)
{
GuildFaction* faction_add = new GuildFaction(guildid,otherguildid,faction);
list.Insert(faction_add);
}

void GuildFactionList::ClearFactions()
{
list.Clear();
}

GuildFactionList::~GuildFactionList(void)
{
ClearFactions();
}

GuildFaction* GuildFactionList::FindGuildFaction(int32 guildid, int32 other_guild_id)
{
	LinkedListIterator<GuildFaction*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->GetGuildID() == guildid && iterator.GetData()->GetOtherGuildID() == other_guild_id)
			return iterator.GetData();
		iterator.Advance();
	}
return 0;
}

GuildApproval::GuildApproval(const char* guildname, Client* owner,int32 id)
{
deletion_timer = new Timer(1800000);
strcpy(guild,guildname);
this->owner = owner;
this->refid = id;
if(owner)
owner->Message(0,"You can now start getting your guild approved, tell your 5 members to #guildapprove %i, you have 30 minutes to create your guild.",GetID());
for(int i=0;i<5;i++)
members[i] = 0;
}

GuildApproval::~GuildApproval()
{
safe_delete(deletion_timer);
}

bool GuildApproval::AddMember(Client* addition)
{
for(int i=0;i<5;i++)
{
if(members[i] && members[i] == addition)
return false;
}

for(int i=0;i<5;i++)
{
if(!members[i])
{
members[i] = addition;
int z=0;
for(int i=0;i<5;i++)
{
if(members[i])
z++;
}
if(z==5)
GuildApproved();

return true;
}
}
return false;
}

void GuildApproval::ApprovedMembers(Client* requestee)
{
for(int i=0;i<5;i++)
{
	if(members[i])
	requestee->Message(0,"%i: %s",i,members[i]->GetName());
}
}

void GuildApproval::GuildApproved()
{
	if(!owner)
		return;
					database.CreateGuild(guild, owner->AccountID());
					int32 tmpeq = database.GetGuildDBIDbyLeader(owner->AccountID());
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_RefreshGuild;
					pack->size = 5;
					pack->pBuffer = new uchar[pack->size];
					memcpy(pack->pBuffer, &tmpeq, 4);
					pack->pBuffer[4] = 1;
					worldserver.SendPacket(pack);
					safe_delete(pack);
					owner->Message(0, "Please send a petition in with the guild name that you have created and that you would like to be set as the leader of the guild.");

owner = 0;
}

bool GuildApproval::Process()
{
if(owner && owner->GuildDBID() != 0)
{
owner->Message(10,"You are already in a guild!  Guild request deleted.");
return false;
}
if(deletion_timer->Check() || !owner)
{
if(owner)
owner->Message(0,"You took too long! Your guild request has been deleted.");
return false;
}

return true;
}

GuildApprovalList::~GuildApprovalList()
{
ClearGuilds();
}

void GuildApprovalList::AddGuild(const char* guildname,Client* owner)
{
GuildApproval* tmp = new GuildApproval(guildname,owner,GetFreeID());
list.Insert(tmp);
}

void GuildApprovalList::AddMember(int32 refid,Client* name)
{
GuildApproval* tmp = FindGuildByID(refid);
if(tmp != 0)
{
if(!tmp->AddMember(name))
name->Message(0,"Unable to add to list.");
else
{
name->Message(0,"Added to list.");
}
}
else
name->Message(0,"Unable to find guild reference id.");
}

void GuildApprovalList::ClearGuilds()
{
list.Clear();
}

GuildApproval* GuildApprovalList::FindGuildByID(int32 refid)
{
	LinkedListIterator<GuildApproval*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->GetID() == refid)
			return iterator.GetData();
		iterator.Advance();
	}
return 0;
}

GuildApproval* GuildApprovalList::FindGuildByOwner(Client* owner)
{
	LinkedListIterator<GuildApproval*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(iterator.GetData()->GetOwner() == owner)
			return iterator.GetData();
		iterator.Advance();
	}
return 0;
}

void GuildApprovalList::Process()
{
	LinkedListIterator<GuildApproval*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if(!iterator.GetData()->Process())
			iterator.RemoveCurrent();
		iterator.Advance();
	}
}


















bool Database::InsertPurchasedNPC(int32 guildid,int32 locationid,int32 spawnid)
{
#ifdef GWDEBUG
	printf("Inserting Purchased NPC: GuildID: %i LocationID: %i SpawnID: %i\n",guildid,locationid,spawnid);
#endif

	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "Insert into purchasednpc set guildid=%i, locationid=%i, spawnid=%i",guildid,locationid,spawnid), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

void Database::RemovePurchasedNPC(int32 spawnid)
{

}

void Database::RemovePurchasedNPCsByLocation(int32 locationid)
{
#ifdef GWDEBUG
	printf("RemovePurchasedNPCsByLocation: LocationID: %i\n",locationid);
#endif
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	MYSQL_RES* result;
	MYSQL_ROW row;
	bool ret = false;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT spawnid from purchasednpc where locationid=%i",locationid), errbuf, &result)) {
		safe_delete_array(query);
		while ((row = mysql_fetch_row(result))) {
			int32 spawnid = atoi(row[0]);
			if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM spawn2 WHERE id='%i'", spawnid), errbuf,0)) {
				delete query;
			}
			if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM spawngroup WHERE id='%i'", spawnid), errbuf,0)) {
				delete query;
			}
			if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM spawnentry WHERE spawngroupID='%i'", spawnid), errbuf,0)) {
				delete query;
			}
			safe_delete_array(query);
		}
		mysql_free_result(result);
	}
	else
	{
		safe_delete_array(query);
	}
	if (RunQuery(query, MakeAnyLenString(&query, "delete from purchasednpc where locationid=%i",locationid), errbuf)) {
		safe_delete_array(query);
	}
	else
	{
		safe_delete_array(query);
	}

}

int32 Database::GetNPCGuildID(int32 spawnid)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	MYSQL_RES* result;
	MYSQL_ROW row;
	bool ret = false;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT guildid from purchasednpc where spawnid=%i",spawnid), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		int32 guildid = atoi(row[0]);
		mysql_free_result(result);
		return guildid;
		}
	}
	else
	{
		safe_delete_array(query);
	}
return 0;
}

int32 Database::GetNPCLocationID(int32 spawnid)
{
#ifdef GWDEBUG
	printf("Getting npc location id for: spawnid: %i\n",spawnid);
#endif
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	MYSQL_RES* result;
	MYSQL_ROW row;
	bool ret = false;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT locationid from purchasednpc where spawnid=%i",spawnid), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		int32 locid = atoi(row[0]);
		mysql_free_result(result);
		return locid;
		}
	}
	else
	{
		safe_delete_array(query);
	}
return 0;
}

bool Database::LoadGuildNPCTitles()
{
#ifdef GWDEBUG
					printf("Loading GuildNPCTitles\n");
#endif
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = 0;
    MYSQL_RES* result;
    MYSQL_ROW row;
	bool ret = false;
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT npcid, title from guildnpctitles"), errbuf, &result)) {
		safe_delete_array(query);
		while ((row = mysql_fetch_row(result))) {
			if(strlen(row[1]) > 0 && atoi(row[0]) != 0)
			{
			int8 length = strlen(row[1]);
			char* convert = 0;
			convert = new char[length+1];
			memset(convert,0,length+1);
			strcpy(convert,row[1]);
#ifdef GWDEBUG
			printf("GuildNPCTitleAdd: %i %s",atoi(row[0]),convert);
#endif
			GuildNPCs.insert(GuildInsertPair(atoi(row[0]),convert));
			}
			}
		mysql_free_result(result);
	}
	else
	{
		safe_delete_array(query);
		return false;
	}
		return true;
}

bool Database::SetupPointsTable(int32 specifiedid,int8 type)
{
#ifdef GWDEBUG
					printf("SetupPointsTable: %i/%i\n",specifiedid,type);
#endif
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT into guildpointlog SET uniqueid=%i, type=%i",specifiedid,type), errbuf)) {
		cerr << "Error in SetupPointsTable query '" << query << "' " << errbuf << endl;
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

bool Database::UpdatePointsTable(int32 specifiedid,int8 type,sint32 points,sint32 guildcolumns[6],sint32 playercolumns[4])
{
#ifdef GWDEBUG
	printf("UpdatePointsTable: %i\n",specifiedid);
#endif
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "update guildpointlog set points=points+%i, currentcities=currentcities+%i, lostcities=lostcities+%i, totalcities=totalcities+%i, currentfortifications=currentfortifications+%i, lostfortifications=lostfortifications+%i, totalfortifications=totalfortifications+%i, totalkills=totalkills+%i, totalpoints=totalpoints+%i, pointsused=pointsused+%i,totaldeaths=totaldeaths+%i where uniqueid=%i and type=%i",
		points,guildcolumns[0],guildcolumns[1],guildcolumns[2],guildcolumns[3],guildcolumns[4],guildcolumns[5],playercolumns[0],playercolumns[1],playercolumns[2],playercolumns[3],specifiedid,type), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

sint32 Database::GetAvailablePoints(int32 specifiedid, int8 type)
{
#ifdef GWDEBUG
	printf("GetAvailablePts for: %i\n",specifiedid);
#endif
char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT points from guildpointlog where uniqueid=%i and type=%i",specifiedid,type), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		sint32 points = atoi(row[0]);
		mysql_free_result(result);
		return points;
		}
	}
		safe_delete_array(query);
		return -9999999;
}

sint32 Database::GetUsedPoints(int32 specifiedid, int8 type)
{
char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT usedpoints from guildpointlog where uniqueid=%i and type=%i",specifiedid,type), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		sint32 points = atoi(row[0]);
		mysql_free_result(result);
		return points;
		}
	}
		safe_delete_array(query);
		return -9999999;
}

sint32 Database::GetTotalPoints(int32 specifiedid, int8 type)
{
#ifdef GWDEBUG
	printf("GettotalPoints: %i\n",specifiedid);
#endif
char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT totalpoints from guildpointlog where uniqueid=%i and type=%i",specifiedid,type), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		sint32 points = atoi(row[0]);
		mysql_free_result(result);
		return points;
		}
	}
		safe_delete_array(query);
		return -9999999;
}

bool Database::UpdateZoneServerStats(int32 zoneid, int32 currentusers, int32 maxusers, int32 camps, int32 towns, int32 cities)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "update zsstatistics set currentusers=%i, maxusers=%i, camps=%i, towns=%i, cities=%i where zoneid=%i",
		currentusers,maxusers,camps,towns,cities,zoneid), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

bool Database::UpdateZoneOnlineStatus(int32 zoneid,int8 online)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "update zsstatistics set status=%i where zoneid=%i",online,zoneid), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

bool Database::ClearZoneOnlineStatus()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "update zsstatistics set status=0"), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
return true;
}

void Database::GetZSStats(int32 zone_id)
{
char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT maxusers,minlevel,pvpability,location_requirement_one,location_requirement_two,location_requirement_three,location_requirement_four from zsstatistics where zoneid=%i",zone_id), errbuf, &result)) {
		safe_delete_array(query);	
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		guildwars.SetMaxUsers(atoi(row[0]));
		guildwars.SetMinimumLevel(atoi(row[1]));
		guildwars.SetPVPAbility(atoi(row[2]));
		guildwars.SetLocationOne(atoi(row[3]));
		guildwars.SetLocationTwo(atoi(row[4]));
		guildwars.SetLocationThree(atoi(row[5]));
		guildwars.SetLocationFour(atoi(row[6]));
		mysql_free_result(result);
		}
	}
	else
	{
		safe_delete_array(query);
	}
}

int32 Database::InsertGuildEventLog(int8 type,char* logone,char* logtwo,int32 levelone,int32 leveltwo)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
		int32 insertid = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "Insert into guildeventlog set eventtype=%i, logone='%s',logtwo='%s',levelone=%i,leveltwo=%i",type,logone,logtwo,levelone,leveltwo), errbuf, 0, &affected_rows, &insertid)) {
		safe_delete_array(query);
		return false;
	}

	safe_delete_array(query);
	return insertid;
}

int32 Database::CreateLocation(int32 guildid,int8 locationtype,int32 x,int32 y,int32 z,int32 zoneid)
{
	//Todo: Set a default locationname
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
		int32 insertid = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "Insert into guildlocations set locationtype=%i, guildid=%i,x=%i,y=%i,z=%i,zoneid=%i",locationtype,guildid,x,y,z,zoneid), errbuf, 0, &affected_rows, &insertid)) {
		safe_delete_array(query);
		return false;
	}

	safe_delete_array(query);
	return insertid;
}

bool Database::RemoveLocation(int32 location_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	MYSQL_RES* result;
	MYSQL_ROW row;
	bool ret = false;

	if (RunQuery(query, MakeAnyLenString(&query, "delete from guildlocations where locationid=%i",location_id), errbuf)) {
		safe_delete_array(query);
	}
	else
	{
		safe_delete_array(query);
	}
	return true;
}

bool Database::SetLocationOwner(int32 guildid,int32 location_id) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "Update guildlocations set guildid=%i where locationid=%i",guildid,location_id), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
	return true;
}

bool Database::SetLocationProfit(int32 location_id,int32 profit) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "Update guildlocations set profit=%i where locationid=%i",profit,location_id), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
	return true;
}

void Database::LoadLocationInformation()
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];
	int32 count = 0;
	location_list.ClearLocations();
	MakeAnyLenString(&query, "Select locationid, x, y, z, zoneid, locationtype, guildid, profit from guildlocations order by locationid");	
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		safe_delete_array(query);
		while((row = mysql_fetch_row(result)))
		{
		GuildLocation* location = new GuildLocation(atoi(row[0]),atoi(row[1]),atoi(row[2]),atoi(row[3]),atoi(row[4]),atoi(row[5]),atoi(row[6]));
		location->SetProfit(atoi(row[7]));
		location_list.AddLocation(location);
		}
		mysql_free_result(result);
	}
	else
	{
		safe_delete_array(query);
	}
}

int32 Database::GetLocationGuildOwned(int32 location_id,int32 zone_id)
{
	//Gets the owner of a location
	return false;
}

void Database::KillFactionModify(Client* killer, int32 guildid, int32 killedguildid, sint32 subtractfaction, sint32 addfaction) {
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	query = new char[256];

	if(guildid <= 0)
		return;

	MakeAnyLenString(&query, "SELECT guildone FROM guildfactions where guildtwo=%i and faction<-400 order by faction asc limit 3",killedguildid);	
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		safe_delete_array(query);
		while((row = mysql_fetch_row(result)))
		{
		if(atoi(row[0]) > 0 && strlen(guilds[database.GetGuildEQID(atoi(row[0]))].name) > 0)
		{
		sint32 faction = GetCurrentGuildFaction(guildid,atoi(row[0]));
		if(faction < GW_ALLY)
		{
		faction += addfaction;
		ModifyGuildFaction(guildid,atoi(row[0]),faction);
		killer->Message_StringID(0,FACTION_BETTER,guilds[database.GetGuildEQID(atoi(row[0]))].name);
		//killer->Message(0,"Your faction with %s has gone up!",guilds[atoi(row[0])].name);
		}
		}
		}
		mysql_free_result(result);
	}
	else
	{
		safe_delete_array(query);
	}
	MakeAnyLenString(&query, "SELECT guildtwo FROM guildfactions where guildone=%i and faction>800 order by faction desc limit 2",killedguildid);	
	if (RunQuery(query, strlen(query), errbuf, &result))
	{
		safe_delete_array(query);
		while((row = mysql_fetch_row(result)))
		{
		if(atoi(row[0]) > 0 && strlen(guilds[database.GetGuildEQID(atoi(row[0]))].name) > 0)
		{
		sint32 faction = GetCurrentGuildFaction(guildid,atoi(row[0]));
		if(faction < GW_ALLY)
		{
		faction += subtractfaction;
		ModifyGuildFaction(guildid,atoi(row[0]),faction);
		killer->Message_StringID(0,FACTION_WORSE,guilds[database.GetGuildEQID(atoi(row[0]))].name);
		//killer->Message(0,"Your faction with %s has gone down!",guilds[atoi(row[0])].name);
		}
		}
		}
		mysql_free_result(result);
	}
	else
	{
		safe_delete_array(query);
	}
}

//Please note this function does not ADD faction it SETS faction!!  Need to put == ALLY checks before using this function
bool Database::ModifyGuildFaction(int32 targetguildid,int32 otherguildid,sint32 faction,bool insert) {
if(faction >= GW_ALLY)
faction = GW_ALLY-1;
else if(faction < GW_SCOWL)
faction = GW_SCOWL;
if(insert)
InsertGuildFaction(targetguildid,otherguildid,faction);
else
UpdateGuildFaction(targetguildid,otherguildid,faction);

return true;
}

bool Database::UpdateGuildFaction(int32 targetguildid,int32 otherguildid,sint32 faction)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "Update guildfactions set faction=%i where guildone=%i AND guildtwo=%i",faction,targetguildid,otherguildid), errbuf, 0, &affected_rows)) {
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
	return true;
}
/*Explination of faction setup:
**Two guilds, guild one and guild two
**Guild one has a faction of 140 towards guild two, Guild two has a faction of 480 towards guild one
**Guild one cons a member of guild two, it returns 480
**Guild two cons a member of guild one, it returns 140
**This pretty much can be said is it is returning what the other guild thinks of you, not what your standing is with them.
**Assisting could look like:
**A npc sees a client, the npc checks its own faction (what it thinks of you) so it would be clientguildid,npcguildid
*/
bool Database::InsertGuildFaction(int32 targetguildid,int32 otherguildid,sint32 faction)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	int32	affected_rows = 0;
	if (!RunQuery(query, MakeAnyLenString(&query, "Insert into guildfactions set guildone=%i, guildtwo=%i, faction=%i",targetguildid,otherguildid,faction), errbuf, 0, &affected_rows)) {
		cerr << "Error in InsertGuildFaction query '" << query << "' " << errbuf << endl;
		safe_delete_array(query);
		return false;
	}
	safe_delete_array(query);
	return true;
}

sint32 Database::GetCurrentGuildFaction(int32 targetguildid,int32 otherguildid)
{
if(targetguildid == 0 || otherguildid == 0)
return GW_FACTIONNOTEXIST;
else if(targetguildid == otherguildid)
return GW_ALLY;

char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT faction from guildfactions where guildone=%i and guildtwo=%i",targetguildid,otherguildid), errbuf, &result)) {
		safe_delete_array(query);
		if (mysql_num_rows(result) == 1)
		{
		row = mysql_fetch_row(result);
		sint32 faction = atoi(row[0]);
		mysql_free_result(result);
		return faction;
		}
	}
	else
	{
		safe_delete_array(query);
	}
		return GW_FACTIONNOTEXIST;
}

sint32 Database::GetGuildFaction(int32 targetguildid,int32 otherguildid)
{
sint32 current = GetCurrentGuildFaction(targetguildid,otherguildid);
sint32 other = GetCurrentGuildFaction(otherguildid,targetguildid);
if(current == GW_FACTIONNOTEXIST)
{
//Faction does not exist, need to create it
if(otherguildid == 1)
current = GW_APPREHENSIVE;
else
current = GW_DEFAULTFACTION;
ModifyGuildFaction(targetguildid,otherguildid,current,true);
}
if(other == GW_FACTIONNOTEXIST)
{
//Faction does not exist, need to create it
ModifyGuildFaction(otherguildid,targetguildid,current,true);
}
return current;
}