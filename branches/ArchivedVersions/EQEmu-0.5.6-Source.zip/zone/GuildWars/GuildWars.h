#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/database.h"
#include "mob.h"
#include "npc.h"
#include "client.h"

class GuildWars;
class GuildObjects;
class GuildNPCs;
class GuildLocation;
class GuildLocationList;

class GuildWars
{
public:
	bool	PurchaseNPC(Client* clientloc,int32 locid,int32 npcid);
	sint32	GetCurrentGuildFaction(Mob* mobone,Mob* mobtwo);
	GuildWars(void);
	~GuildWars(void);
protected:
	friend class GuildLocationList;
};

class GuildObjects
{

};

class GuildNPCs
{
public:
	GuildNPCs(NPC* npc);
	bool	IsAlive() { return alive; }
	NPC*	ToNPC() { return npcpointer; }
	int32	NPCSpawnID() { return spawn_id; }
	void	UpdateReferences(NPC* npc);
	float	GetStartX() { return start_x; }
	float	GetStartY() { return start_y; }
	float	GetStartZ() { return start_z; }
	int32	GetKilledByLastGuildID() { return killedlastbyguildid; }
private:
	bool	alive;
	NPC*	npcpointer;
	int32	spawn_id;
	int32	killedlastbyguildid;
	float	start_x;
	float	start_y;
	float	start_z;
};

class GuildLocation
{
public:
	GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild);
	~GuildLocation();

	void	AddNPC(NPC* npc);
	bool	GuardsStillStanding();
	int32	GetLocationID() { return location_id; }
	int8	GetLocationType() { return locationtype; }

	bool	Process();
	bool	TakeOverProcess();
	void	TakeOverLocation(int32 guildid);
	void	ResetNPCs();
	void	ResetObjects();

	int8	GuardsSpotsRemaining();

	GuildNPCs*	FindGuildNPCBySpawnID(int32 spawn_id);
private:
	Timer*	takeover_delay; // This timer is for the 30 minute delay of taking over a city
	Timer*	takeover_check;	// This timer is to slow down the number of checks, maybe once per minute
	int32	location_id;
	float	x;
	float	y;
	float	z;
	int32	zoneid;
	int8	locationtype;
	int32	guildid;
	bool	continueprocess;
	LinkedList<GuildNPCs*> guildnpcs;
	LinkedList<GuildObjects*> guildobjects;
};

class GuildLocationList
{
public:
	GuildLocationList(void);
	~GuildLocationList(void);

	bool	RemoveLocation(int32 locid);
	void	AddLocation(GuildLocation* gl);
	void	ClearLocations();
	void	ProcessLocations();

	GuildLocation*	FindLocationByID(int32 locid);
private:
	LinkedList<GuildLocation*> list;
};

#define MAXMEMBERS				20
#define NOGUILDCAPLEVEL			21
#define SETLEVEL				50
#define GAINLEVEL				51
//Experience Rules
#define EXPLOSSLVLDIFF			20
#define EXPHNOCHGLVLDIFF		10
#define EXPLNOCHGLVLDIFF		-25
//Level Restriction Rules (no <= or >= all < or > functions unless using opposite of proper use, then sign + equal to)
#define NORESTRICTIONS			21	// Less Than: No rules, freely do whatever
#define MIDLEVELRESTRICT		20	// Greater Than: if person is not in a guild, cannot buff others in guilds and guilds cannot buff this person (TBD: Lvl 20-30, Slower experience than people in guilds?)
#define MIDHIGHLEVELRESTRICT	29	// Greater Than: cannot level past 30 without guild, cannot buff others in guilds and guilds cannot buff this person.
#define HIGHLEVELRESTRICT		39	// Greater Than: guild is required to level, if no guild, guilds can PvP the target, player cannot be buffed by members in guilds and cannot buff members in guilds.
//Guildwars Faction System
#define GW_ALLY					2000
#define GW_WARMLY				1600
#define GW_KINDLY				1200
#define GW_AMIABLY				800
#define GW_INDIFFERENTLY		400
#define GW_APPREHENSIVE			-1
#define GW_DUBIOUS				-400
#define GW_THREATNINGLY			-800
#define GW_SCOWL				-2000
#define GW_DEFAULTFACTION		-799
#define GW_FACTIONNOTEXIST		-2001
//Guildwars location flags
#define CITY					0
#define CAMP					1
#define GUILDHOUSE				2
#define	TOWER					3
//Guildwars Radius Restrictions
#define NPCTONPCRADIUS			2500
#define	OUTTERCITYRADIUS		120000 // Probably will be no restriction at all, thats why its such a large number
#define OUTTERCAMPRADIUS		30000
#define	OUTTERGUILDHOUSERADIUS	15000
#define OUTTERTOWERRADIUS		10000
#define	INNERCITYRADIUS			0
#define	INNERCAMPRADIUS			1000
#define	INNERGUILDHOUSERADIUS	5000 // Force players to spawn NPCs outside the guild house, because it is locked, dont' want NPCs protected because they are hiding and casting inside a house.
#define	INNERTOWERRADIUS		0
//Guildwars hard coded npc limits
#define MAXCITYNPCS				35
#define	MAXCAMPNPCS				20
#define	MAXGUILDHOUSENPCS		5
#define	MAXTOWERNPCS			3