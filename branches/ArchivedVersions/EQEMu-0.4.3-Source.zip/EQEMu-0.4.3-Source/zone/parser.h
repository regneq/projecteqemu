#ifndef PARSER_H
#define PARSER_H

#include "../common/Kaiyodo-LList.h"
//#include "../common/linked_list.h"

#define Parser_MaxVars	1024

struct Events {
	int index;
	int npcid;
	char event[100][100];
	char command[100][1024];
};

struct vars {
	char name[Parser_MaxVars];
	char value[Parser_MaxVars];
	int NextIndex;
};


class Parser
{
public:
	Parser();
	~Parser();

	MyList <Events> EventList;
	vars * varlist;
	char * ParseVars(char * string);
	void HandleVars(char * varname, char * varparms, char * origstring, char * format);
	void AddVar(const char *varname, const char * varval);
	int GetVar(const char * varname);
	void Replace(char* string, const char * repstr, const char * rep, int all=0);
	void LoadCommands(const char * filename);
	void LoadScript(int npcid, const char * zone);
	void scanformat(char *string, const char *format, char arg[10][1024]);
	void GetCommandName(char * command1, char * arg);
	void EnumerateVars(char * string);
	int ParseIf(char * string);
	int numtok(char * sting, const char *tok);
	char * gettok(char *string, int chara, int pos);
	char * strrstr(char* string, const char * sub);
	void MakeVars(const char * string);
	void Event(int event, int32 npcid, const char * data, Mob* mob, Client* client);
	void SendCommands(const char * event, int32 npcid, Mob* mob, Client* client);
	void CommandEx(char * command, int32 npcid, Mob* other, Client* client);
	int pcalc(char * string);

	void	ClearEventsByNPCID(int32 iNPCID);
	bool	SetNPCqstID(int32 iNPCID, int32 iValue);
	bool	LoadAttempted(int32 iNPCID);
	void	ClearCache();
	int32	GetNPCqstID(int32 iNPCID);
private:

	int32	pMaxNPCID;
	int32*	pNPCqstID;
};

extern Parser* parse;

#endif

