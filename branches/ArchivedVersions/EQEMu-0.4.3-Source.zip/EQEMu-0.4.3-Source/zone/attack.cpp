/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../common/debug.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <iostream.h>

#include "client.h"
#include "npc.h"
#include "NpcAI.h"
#include "../common/packet_dump.h"
#include "../common/eq_packet_structs.h"
#include "skills.h"
#include "PlayerCorpse.h"
#include "spdat.h"
#include "zone.h"
#include "groups.h"

#ifdef WIN32
#define snprintf	_snprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#endif

extern Database database;
extern EntityList entity_list;
#ifndef NEW_LoadSPDat
	extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
#endif

#if defined(GOTFRAGS) || defined(_DEBUG)
	#define REDUCE_BATTLE_SPAM
#endif

extern Zone* zone;

bool Mob::AttackAnimation(int &attack_skill, int &skillinuse, int Hand, const Item_Struct* weapon)
{
	// Determine animation
	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;
	
	a->spawn_id = GetID();
	if(weapon)
	{
		switch(weapon->common.skill)
		{
		case 0: // 1H Slashing
        {
		    attack_skill = 1;
			skillinuse = _1H_SLASHING;
			a->type = 5;
			break;
		}
		case 1: // 2H Slashing
		{
		    attack_skill = 1;
			skillinuse = _2H_SLASHING;
			a->type = 3;
			break;
		}
		case 2: // Piercing
		{
		    attack_skill = 36;
			skillinuse = PIERCING;
			a->type = 2;
			break;
		}
		case 3: // 1H Blunt
		{
		    attack_skill = 0;
			skillinuse = _1H_BLUNT;
			a->type = 5;
			break;
		}
		case 4: // 2H Blunt
		{
		    attack_skill = 0;
			skillinuse = _2H_BLUNT;
			a->type = 4;
			break;
		}
		case 35: // 2H Piercing
		{
		    attack_skill = 36;
			skillinuse = PIERCING;
			a->type = 4;
			break;
		}
		case 45:
		{
		    attack_skill = 4;
            skillinuse = HAND_TO_HAND;
			a->type = 8;
			break;
		}
		default:
		{
			attack_skill = 4;
			skillinuse = HIGHEST_SKILL+1;
			a->type = 8;
			break;
		}
		}// switch
	}
	else
	{
		attack_skill = 4;
		skillinuse = HAND_TO_HAND;
		a->type = 8;
	}
	// Kaiyodo - If we're attacking with the seconary hand, play the duel wield anim
	if(Hand == 14)	// DW anim
		a->type = 6;
	
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;
	app.priority = 1;
	entity_list.QueueCloseClients(this, &app);
    return true;
}





bool Mob::AvoidDamage(sint32 &damage, int16 spell_id, int8 attack_skill)
{
	float skill = 0.0f;

	// if we fight against spell we cant avoid it
	if ( spell_id != 0xFFFF )
        	return false;

	//////////////////////////////////////////////////////////
	// make enrage same as riposte
	/////////////////////////////////////////////////////////
	if (IsEnraged())
		damage = -3;	

	/////////////////////////////////////////////////////////
	// riposte
	/////////////////////////////////////////////////////////
	if (damage > 0 && CanThisClassRiposte() )
	{
	if (IsClient()) {
        skill = GetSkill(RIPOSTE);
        this->CastToClient()->CheckIncreaseSkill(RIPOSTE);
	} else {
        	skill = this->MaxSkill(RIPOSTE);
	}
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"Riposte skill is : %i", (int)skill);
#endif
	if(((float)rand()/RAND_MAX) < skill/2500.0)
		damage = -3;
	}
	
	///////////////////////////////////////////////////////	
	// block
	///////////////////////////////////////////////////////
	if (damage > 0 && (
			class_==MONK ||
			class_==BEASTLORD ||
			class_==MONKGM ||
			class_==BEASTLORDGM ))
	{
	if (IsClient()) {
        skill = GetSkill(BLOCK);
        this->CastToClient()->CheckIncreaseSkill(BLOCK);
	} else {
        	skill = this->MaxSkill(BLOCK);
	}
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"Block skill is : %i", (int)skill);
#endif

	if (( (float)rand()/RAND_MAX ) < skill/2500.0)
		damage = -1;
	}
	
	//////////////////////////////////////////////////////		
	// parry
	//////////////////////////////////////////////////////
	if (damage > 0 && CanThisClassParry() )
	{
        
	if (IsClient()) {
        skill = GetSkill(PARRY);
        this->CastToClient()->CheckIncreaseSkill(PARRY); 
	} else {
        	skill = this->MaxSkill(PARRY);
	}
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"Parry skill is : %i", (int)skill);
#endif
	if(( (float) rand()/RAND_MAX ) < skill/3500.0)
		damage = -2;
	}
	
	////////////////////////////////////////////////////////
	// dodge
	////////////////////////////////////////////////////////
	if (damage > 0 && CanThisClassDodge() )
	{
	
	if (IsClient()) {
        skill = GetSkill(DODGE);
        this->CastToClient()->CheckIncreaseSkill(DODGE);
	} else {
        	skill = this->MaxSkill(DODGE);
	}
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"Dodge skill is : %i", (int)skill);
#endif
	if(((float)rand()/RAND_MAX) < skill/3500.0)
		damage = -4;
	}
	
	////////////////////////////////////////////////////////

	if (damage < 0)
	return true;
	else
	return false;
}

bool Client::Attack(Mob* other, int Hand, bool bRiposte)
{
    SetAttackTimer();
    if(!other)
        return false;
	
	if((IsClient() && CastToClient()->dead) || (other->IsClient() && other->CastToClient()->dead))
		return false;
	
	if(GetHP() < 0)
		return false;
#ifdef GUILDWARS
	if(target->IsNPC() && target->CastToNPC()->IsCityController())
		return false;
#endif

	if(!IsAttackAllowed(other))
        return false;
	
    // add to hate list even if we miss the attack
	if(other != 0 && other->IsNPC())
	    other->CastToNPC()->AddToHateList(this, 1, 0);

    const Item_Struct* weapon = 0;
	int skillinuse = HIGHEST_SKILL+1;

	int attack_skill=4;
    if (Hand==13)	// Kaiyodo - Pick weapon from the attacking hand
		weapon = weapon1;
	else
		weapon = weapon2;
    
    // calculate attack_skill and skillinuse depending on hand and weapon
    // also send Packet to near clients
    AttackAnimation(attack_skill, skillinuse, Hand, weapon);
	
	/// Now figure out damage
	int damage = 0;
	
	int8 otherlevel = other->GetLevel();
	int8 mylevel = this->GetLevel();
	int8 mydex = this->GetDEX();
	
	otherlevel = otherlevel ? otherlevel : 1;
	mylevel = mylevel ? mylevel : 1;
	
	// Determine players ability to hit based on:
	// mob level difference, skillinuse, randomness
	if (skillinuse == HIGHEST_SKILL+1) // the fallthru, only do 1 damage
	{
		damage = 1;
	}
	else
	{
		if ( damage >= 0 )
		{
			//int32 atkbonus = 0; //TODO: Find where the luclin atk bonus is held
			//int32 attacker = ((mylevel/2) * (( mydex/6)+this->GetSTR()+atkbonus+this->pp.skills[skillinuse]));
			//int32 defender = (otherlevel/2) * ((otherlevel * 3000/otherlevel+90) +(pp.skills[DEFENSE]/2)+other->GetINT()+other->GetAGI());
			//float hitsuccess = (attacker / defender); // Change to hit *image*
			
//			float skillfactor = 1.0;
//			int32 chanceskill = (int32)(255*skillfactor) - ((GetSkill(skillinuse)/10) * (1+(mylevel-otherlevel)));
//			int chanceskill2 = chanceskill;
//			if (chanceskill2 == 750)
//				chanceskill2--;
//			int chancetest = (int32)chanceskill+(rand()%(750-chanceskill2))-50;
			CheckIncreaseSkill(skillinuse);
			CheckIncreaseSkill(OFFENSE, -5);
			//int rndqa = 0;
			//int defender2 = 0;
			//Something got bugged, taking out chance code for now...
			// Kaiyodo - new weapon damage calc code
			//
			//  MaximumDamageMain = WeaponDamage * ((Strength + WeaponSkill) / 100) + DamageBonus
			//  MaximumDamageOff = WeaponDamage * ((Strength + WeaponSkill) / 100)
			
			int weapon_damage = 0;
			
			if(skillinuse == 28) // weapon is hand-to-hand
			{
				if(GetClass() == MONK || GetClass() == BEASTLORD)
					weapon_damage = GetMonkHandToHandDamage();	// Damage changes based on level
				else
					weapon_damage = 2;
			}
			else
			{
				weapon_damage = (int)weapon->common.damage;
				if(weapon_damage < 1)
					weapon_damage = 1;
			}
			
			int min_hit = 1;
			int max_hit = weapon_damage * ((GetSTR() + GetSkill(skillinuse)+ mylevel) / 100);	// Apply damage formula
			
			// Only apply the damage bonus to the main hand
			if(Hand == 13)		// Kaiyodo - If we're not using the DWDA stuff, will always be the primary hand
			{
				int damage_bonus = GetWeaponDamageBonus(weapon);	// Can be NULL, will then assume fists
				min_hit += damage_bonus;
				max_hit += damage_bonus;
			}
			
			if(max_hit <= min_hit)
				damage = min_hit;
			else
				damage = (int32)min_hit + (rand()%(max_hit-min_hit)+1);
#ifdef DEBUG
  LogFile->write(EQEMuLog::Debug,"Client::Attack(): min_hit:%i max_hit:%i weapon_damage:%i damage:%i ss_mod:%f lmod:%f",
        min_hit, max_hit, weapon_damage, damage, (float)((GetSTR() + GetSkill(skillinuse) + mylevel) / 100), (float)( ((mylevel-25)/3) >= 1.0) ? (((mylevel-25)/3)+1):1);
#endif
		}
	}

    if (other)
        other->AvoidDamage(damage, 0xFFFF, attack_skill);
    if (bRiposte && damage == -3)
        return false;

/////////////////////////////////////////////////////////////	
///// chance to hit
////////////////////////////////////////////////////////////
	float chancetohit = GetSkill(skillinuse) / 3.75;
	if ( mylevel - otherlevel < 0)
	{
		// based on leveldiff
		chancetohit -= (float)(( otherlevel - mylevel ) * ( otherlevel - mylevel ))/4;
	}
	
	int16 targetagi = other->GetAGI();
	targetagi = (targetagi <= 200) ? targetagi:targetagi + ((targetagi-200)/5);

	//Quagmire: Take into account offense/defense skill
	chancetohit += (float)GetSkill(OFFENSE) * 0.10;
	chancetohit -= (float)other->GetSkill(DEFENSE) * 0.09;
	
	chancetohit -= (float)targetagi*0.05;
	chancetohit += (float)(this->itembonuses->DEX + this->spellbonuses->DEX)/5;

	//Trumpcard:  Give a mild skew for characters below 20th level.
	if (mylevel <=10)
			chancetohit = (chancetohit > 0) ? chancetohit+50:50;
	else if (mylevel <=20)
		chancetohit = (chancetohit > 0) ? chancetohit+40:40;
	else
		chancetohit = (chancetohit > 0) ? chancetohit+30:30;

	chancetohit = chancetohit > 95 ? 95 : chancetohit; /* cap to 95% */
	
	//  char temp[100];
	//  snprintf(temp, 100, "Chance to hit %s: %f", other->GetName(), chancetohit);
	//  ChannelMessageSend(0,0,7,0,temp);
	
    if (damage > 0) {
    		///Check if it's a hit or miss
		if (((float)rand()/RAND_MAX)*100 > chancetohit) {
				damage = 0;
    			other->Damage(this, damage, 0xffff, attack_skill);
				return false;
		}

//////////////////////////////////////////////////////////
/////////	Finishing Blow
/////////////////////////////////////////////////////////
		uint8 *aa_item = &(((uint8 *)&aa)[32]);
		if(damage > 0 && *aa_item>0 && other->GetHPRatio() < 10) {
			int tempchancerand =rand()%100;
			if(*aa_item==1 && (tempchancerand<=3)) {	  
				other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");
			}
			else if(*aa_item==2 && (tempchancerand<=6)) {	  
				other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");
			}
			else if(*aa_item==3 && (tempchancerand<=10)) {	  
				other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");
			}
			else
				{//Message(0,"Wtf? You can\'t have more than 3 points in finishing blow");}
		}
	}

///////////////////////////////////////////////////
/////   Critical Hits
//////////////////////////////////////////////////
	uint8 *aa_item2 = &(((uint8 *)&aa)[30]);
	int amount1 = *aa_item2;
	if (damage > 0 && GetClass() == WARRIOR && mylevel >= 11)
	{
		int amount = *aa_item2;
		amount = (amount*5)+5;
		int Critchance = mydex - amount;
		int Critical = 0;
		if (Critchance != 0) // Quag: Divide by zero protection
			Critical = rand()%Critchance;
		int FinalChance = Critchance-amount;
		if (Critical > FinalChance)
		{
			int RAND_CRIT = rand()%5;
			if (this->berserk)
				RAND_CRIT = rand()%10;
			damage += ((( mylevel / 4) + (weapon ? weapon->common.damage : 0)) * RAND_CRIT);
			if (this->berserk)
				entity_list.MessageClose(this, false, 200, 10, "%s lands a crippling blow!(%d)", name,damage);
			else
				entity_list.MessageClose(this, false, 200, 10, "%s scores a critical hit!(%d)", name,damage);
		}
	}
	else if (damage > 0)
	{
		if (amount1 != 0)
		{
			int amount = amount1*5;
			int Critchance = mydex - amount;
			int Critical = 0;
			if (Critchance != 0) // Quag: Divide by zero protection
				Critical = rand()%Critchance;
			int FinalChance = Critchance-amount;
			if (Critical > FinalChance)
			{
				int RAND_CRIT = rand()%5;
				damage += ((( mylevel / 4) + (weapon ? weapon->common.damage : 0)) * RAND_CRIT);
				entity_list.MessageClose(this, false, 200, 10, "%s scores a critical hit!(%d)", name,damage);
			}
		}
	}


    }

///////////////////////////////////////////////////////////
//////    Normal Attack
///////////////////////////////////////////////////////////
    other->Damage(this, damage, 0xffff, attack_skill);

////////////////////////////////////////////////////////////
////////  PROC CODE
////////  Kaiyodo - Check for proc on weapon based on DEX
///////////////////////////////////////////////////////////
	if(HasProcs() || ( weapon && (weapon->common.spellId < 65535ul) && (weapon->common.effecttype == 0)) && other && other->GetHP() > 0)
	{
        int16 usedspellID = 0xFFFF;
		float dexmod = (float) GetDEX() / 100;
        for (int i = 0; i < MAX_PROCS; i++) {
            if (PermaProcs[i].spellID != 0xFFFF) {
                if (rand()%100 < (PermaProcs[i].chance * dexmod))
                {
                    usedspellID = PermaProcs[i].spellID;
                    break;
                }
            }
            if (SpellProcs[i].spellID != 0xFFFF) {
                if (rand()%100 < (SpellProcs[i].chance * dexmod))
                {
                    usedspellID = SpellProcs[i].spellID;
                    break;
                }
            }
        }

        if (usedspellID == 0xFFFF && weapon && (weapon->common.spellId < 65535ul) && (weapon->common.effecttype == 0)) {
            float ProcChance = (float)rand()/RAND_MAX;
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"ProcChance is : %i", ProcChance);
#endif
    		if(ProcChance < ((float) mydex / 3020.0f))	// 255 dex = 0.084 chance of proc. No idea what this number should be really.
	    	{
                usedspellID = weapon->common.spellId;
		    	if(weapon->common.level >  mylevel )
			    {
	    			Message(13, "Your will is not sufficient to command this weapon.");
                    usedspellID = 0xFFFF;
    			}
            }
        }


		// Trumpcard: Changed proc targets to look up based on the spells goodEffect flag.
		// This should work for the majority of weapons.
		if ( usedspellID != 0xFFFF && !(other->IsClient() && other->CastToClient()->dead) )
		{
			if ( IsBeneficial(usedspellID) )
				SpellFinished(usedspellID, GetID(), 10, 0);
			else
				SpellFinished(usedspellID, other->GetID(), 10, 0);
		}

	}
	
    if( other->IsEnraged() || damage == -3)
	{
		//other->CastToNPC()->FaceTarget(); //Causes too much lag?? Disabled. -image
		other->Attack(this, 13, true);
        return false;
	}

    if (damage > 0)
        return true;
    else
        return false;
}

void Mob::Heal() {
	SetMaxHP();
/*	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;
	
	a->target = GetID();
	a->source = GetID();
	a->type = 231; // 1
	a->spell = 0x000d; //spell_id
	a->damage = -10000;
	
	entity_list.QueueCloseClients(this, &app);*/
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 1;
	entity_list.QueueCloseClients(this, &hp_app, true);
	
    LogFile->write(EQEMuLog::Normal,"%s healed via #heal", name);

}

void Client::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill, bool avoidable, sint8 buffslot, bool iBuffTic) {
	adverrorinfo = 411;
	
    // if we got a pet, thats not already fighting something send it into battle
    Mob *pet = GetPet();
    if (other && pet && !pet->IsEngaged() && other->GetID() != GetID())
    {
        if (pet)
            pet->AddToHateList(other, 1, 0, iBuffTic);
        else
        {
            // todo: do whatever is necessary for clients as pets
        }
        pet->SetTarget(other);
        Message(10,"%s tells you, 'Attacking %s, Master.'", pet->GetName(), other->GetName());
    }
	
	if( spell_id != 0xFFFF || other == 0 )
        avoidable = false;
	
    if (invulnerable)
        damage=-5;
	
    // damage shield calls this function with spell_id set, so its unavoidable
	if (other && damage > 0 && avoidable) {
		this->DamageShield(other);
	}

    if (spell_id != 0xFFFF || (attack_skill>200 && attack_skill<250)) {
        // todo: exchange that for EnvDamage-Packets when we know how to do it
        Message(4,"%s was hit by non-melee for %d points of damage.", GetName(), damage);
    }
	
	if (damage > 0 && GetRune() > 0) {
		damage = ReduceDamage(damage, GetRune());
	}

	if (damage > 0 && (GetHP() - damage) <= 0) {
		Death(other, damage, spell_id, attack_skill);
		return;
	}
	if (damage > 1 && avoidable){
		//Reduce Dmg based on AC
		//.5 less damage at 1000 AC
		double damage2=damage;
		double calc1=(1000+this->GetAC())/1000+.5;
		double calc2=(damage2/calc1);
		damage=damage-(sint32)calc2;
	}
	if (damage > 0)
		SetHP(GetHP()-damage);
	if (other && other->IsNPC())
		CheckIncreaseSkill(DEFENSE, -5);
	APPLAYER* outapp = new APPLAYER(OP_Action, sizeof(Action_Struct));
	Action_Struct* a = (Action_Struct*)outapp->pBuffer;
	adverrorinfo = 412;
	a->target = GetID();
	
	if (other == 0)
		a->source = 0;
	else if (other->IsClient() && other->CastToClient()->GMHideMe())
		a->source = 0;
	else
		a->source = other->GetID();
		
	a->type = attack_skill;
	a->spell = spell_id;
	a->damage = damage;
	outapp->priority = 4;
	entity_list.QueueCloseClients(this, outapp, false, 200, other);
	if (other && other->IsClient())
		other->CastToClient()->QueuePacket(outapp);
	delete outapp;
	adverrorinfo = 413;
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 1;
	entity_list.QueueCloseClients(this, &hp_app);
	SendHPUpdate();
	
	if (damage != 0)
	{ // Pyro: Why log this message if no damage is inflicted
		if (IsMezzed())
			this->BuffFadeByEffect(SE_Mez);
		if (attack_skill == BASH && GetLevel() < 56) {
			Stun(0);
		}
		if (IsRooted() && spell_id != 0xFFFF) { // neotoyko: only spells cancel root
			if ((float)rand()/RAND_MAX > 0.8f)
				this->BuffFadeByEffect(SE_Root, buffslot); // buff slot is passed through so a root w/ dam doesnt cancel itself
		}
		if(this->casting_spell_id != 0) {
			// client: 30 = basechance
			int16 channelchance = (int16)(30+((float)this->GetSkill(CHANNELING)/400)*100);
			if (((float)rand()/RAND_MAX)*100 > channelchance) {
				this->isattacked = true;
				this->isinterrupted = true;
			}
			else {
				this->isattacked = true;
			}
		}
		
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug," %s hit for %i, %i left", name, damage, GetHP());
#endif
		adverrorinfo = 41;
	}
}

void Client::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (other && other->IsNPC())
		CheckQuests(zone->GetShortName(),"%%KILLED%%",other->GetNPCTypeID(),0,other);
	SetHP(-100);
	entity_list.RemoveFromTargets(this);
	zonesummon_x = -3;
	zonesummon_y = -3;
	zonesummon_z = -3;
	
	SetPet(0);
	
	pp.x = x_pos;
	pp.y = y_pos;
	pp.z = z_pos;
	pp.heading = heading;
	int i;

	BuffFade(0xFFFe);

    //
    // Xorlac: A bad assumption here is that other will be set.
    //         For instance, spontaneous death due to lore items will not have set other
    //

    if (other != NULL)
    {
        if(other->IsClient() && other->CastToClient()->IsDueling() && other->CastToClient()->GetDuelTarget() == GetID())
        {
	        other->CastToClient()->SetDueling(false);
	        other->CastToClient()->SetDuelTarget(0);
        }
    }
	
    LogFile->write(EQEMuLog::Normal,"Player %s has died", name);
	//We are going to strip the spells off the player now....
	for(i=0; i<BUFF_COUNT; i++)
        buffs[i].spellid = 0xFFFF;
	APPLAYER app(OP_Death, sizeof(Death_Struct));
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	//  d->unknown011 = 0x05;
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->damage = damage;
	d->spell_id = spell;

	d->type = attack_skill;
	d->unknownds016 = pp.bind_point_zone;
	int32 exploss = (int32)(GetLevel()*((float)GetLevel()/18)*8000);
	if (GetLevel() > 9 &&  !GetGM() && GetEXP() >= 0 && (other == 0 || !other->IsClient()))
		SetEXP((int32)(GetEXP() - GetLevel()*((float)GetLevel()/18)*8000 > 0)? (int32)(GetEXP() - GetLevel()*((float)GetLevel()/18)*8000) : 1,GetAAXP());
	entity_list.QueueClients(this, &app);
#ifdef GUILDWARS
	if(other != 0 && other->IsClient() && IsAttackAllowed(other))
	{
		char msg[400];
		sprintf(msg,"%s:%i:%i:%i",zone->GetShortName(),GuildDBID(),other->CastToClient()->GuildDBID(),other->GetHP());
		database.InsertNewsPost(1,name,other->GetName(),2,msg);
		if (other->CastToClient()->isgrouped && entity_list.GetGroupByClient(other->CastToClient()) != 0)
			entity_list.GetGroupByClient(other->CastToClient())->SplitExp((uint32)(level*level*125*3.5f), GetLevel());
		else
			other->CastToClient()->AddEXP((uint32)(level*level*350*3.5f));
	}
#endif
	if(IsBecomeNPC() == true)
	{
		if (other != NULL && other->IsClient())

		{
			if (other->CastToClient()->isgrouped && entity_list.GetGroupByMob(other) != 0)
				entity_list.GetGroupByMob(other->CastToClient())->SplitExp((uint32)(level*level*75*3.5f), GetLevel());
			else
				other->CastToClient()->AddEXP((uint32)(level*level*75*3.5f)); // Pyro: Comment this if NPC death crashes zone
			//hate_list.DoFactionHits(GetNPCFactionID());
		}
	}
	Save();
	MakeCorpse(exploss);
}

void Client::MakeCorpse(int32 exploss) {
	if (this->GetID() == 0)
		return;
	
	if (!GetGM() && pp.level > 9)
	{
		// Check to see if we are suppose to make a corpse
		// Via the database setting (anything in leavecorpses)
		char tmp[20];
		memset(tmp,0,sizeof(tmp));
		database.GetVariable("leavecorpses",tmp, 20);
		int8 tmp2 = atoi(tmp);
		if (tmp2 >= 1) {
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"Creating corpse for %s at x=%d y=%d z=%d h=%d", GetName(), GetX(), GetY(), GetZ(), GetHeading());
#endif
			entity_list.AddCorpse(new Corpse(this, &pp, exploss, tmp2), this->GetID());
			this->SetID(0);
		}
	}
}

bool NPC::Attack(Mob* other, int Hand, bool bRiposte)	 // Kaiyodo - base function has changed prototype, need to update overloaded version
{
	int damage = 0;

    if (!other)
    {
        SetTarget(NULL);
        return false;
    }

    if (!target)
        SetTarget(other);

    SetAttackTimer();
#ifdef GUILDWARS
    if((other->GetHP() <= -11) || (other->IsClient() && other->CastToClient()->dead) || ((CastToNPC()->IsCityController()) || (target->IsNPC() && target->CastToNPC()->IsCityController())))
#else
   if((other->GetHP() <= -11) || (other->IsClient() && other->CastToClient()->dead))
#endif
	{
		RemoveFromHateList(other);
		return false;
	}

    if (!IsAttackAllowed(other)) {
		if (this->GetOwnerID())
			entity_list.MessageClose(this, 1, 200, 10, "%s says, 'That is not a legal target master.'", this->GetName());
		this->WhipeHateList();
		return false;
	}
	else
	{
		int skillinuse;
		int attack_skill;

        const Item_Struct *weapon = NULL;
        if (Hand == 13 && equipment[7] > 0)
            weapon = database.GetItem(equipment[7]);
        else if (equipment[8])
            weapon = database.GetItem(equipment[8]);
        AttackAnimation(attack_skill, skillinuse, Hand, weapon);

		int8 otherlevel = other->GetLevel();
		int8 mylevel = this->GetLevel();
		
		otherlevel = otherlevel ? otherlevel : 1;
		mylevel = mylevel ? mylevel : 1;

		float dmgbonusmod = 0;
		float clmod = (float)GetClassLevelFactor()/22;
		float basedamage;


		if(max_dmg != 0 && min_dmg <= max_dmg)
			basedamage = RandomTimer(min_dmg,max_dmg)+1;
		else if (other->GetOwnerID()!=0) //pet
			basedamage = mylevel*2.8f*clmod;
		else
			basedamage = mylevel*3.1f*clmod;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		NPC Damage Tweak.  
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if(mylevel >= 60) // Darogar : NPCs Over lvl. 60 hit for very high damages 
			basedamage = mylevel*18.0f*clmod; 
		else if (mylevel >= 51 && mylevel <= 60) // Darogar : NPCs between lvl. 51 and 59 hit for high damage. 
			basedamage = mylevel*9.50f*clmod; 
		else 
			basedamage = mylevel*6.5f*clmod; // Darogar : Original modifier was 4.0f, raised to 6.5f to match the EQlive normal damage. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

		dmgbonusmod += (float)(this->itembonuses->STR + this->spellbonuses->STR)/3;
		dmgbonusmod += (float)(this->spellbonuses->ATK + this->itembonuses->ATK)/5;
		basedamage += (float)basedamage/100*dmgbonusmod;

		float basedefend;
		if (other->GetOwnerID()!=0) //pet
			basedefend = (float) (1.118f * other->GetLevel());
		else
			basedefend = (float) 1.118f * sqrt(other->GetAC());
		
		float currenthit;
#ifdef DEBUG
    LogFile->write(EQEMuLog::Debug,"NPC::Attack() basedamage:%f basedefend:%f dmgbonusmod:%f clmod:%f", basedamage, basedefend, dmgbonusmod, clmod);
#endif
        if(min_dmg != 0 && max_dmg != 0 && min_dmg <= max_dmg)
		{
			if (max_dmg <= min_dmg)
				currenthit = damage = min_dmg;
			else
				currenthit = min_dmg + ((float)rand()/RAND_MAX)*(max_dmg-min_dmg);
		}
		else
			currenthit = (float)basedamage-basedamage/100*25 + ((float)rand()/RAND_MAX) * basedamage/100*50;
		damage = (int)(currenthit - (float)basedamage/100*basedefend);

		if(min_dmg != 0 && damage < min_dmg)
			damage = min_dmg;
      if(max_dmg != 0 && damage > max_dmg)
          damage = max_dmg;
		// chance to hit
		float chancetohit = 0;
		if (mylevel-otherlevel >= 0)
		{
			// 83% (+30) basechance, if target if lower then me
			chancetohit = 68;
		}
		else
		{
			// based on leveldiff
			chancetohit = 68-(float)(( otherlevel - mylevel )*( otherlevel - mylevel ))/4;
		}
		int16 targetagi = other->GetAGI();
		targetagi = (targetagi <= 200) ? targetagi:targetagi + ((targetagi-200)/5);
		chancetohit -= (float)targetagi*0.05;
		chancetohit += (float)(this->itembonuses->DEX + this->spellbonuses->DEX)/5;
		chancetohit = (chancetohit > 0) ? chancetohit+30:30;
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug,"NPC::Attack() chancetohit:%d", chancetohit);
#endif
		if (((float)rand()/RAND_MAX)*100 > chancetohit)
			damage = 0;
		if (damage < 0)
			damage = 0;

        if (other)
            other->AvoidDamage(damage, 0xFFFF, attack_skill);
        if (bRiposte && damage == -3)
            return false;
		adverrorinfo = 1292;
		if(other != 0 && this != 0 && GetHP() > 0 && other->GetHP() > 0)
		    other->Damage(this, damage, 0xffff, attack_skill);
		adverrorinfo = 1293;
    }
    
    // Kaiyodo - Check for proc on weapon based on DEX
	if(HasProcs() && other && other->GetHP() > 0)
	{
        int16 usedspellID = 0xFFFF;
		float dexmod = (float) GetDEX() / 100;
        for (int i = 0; i < MAX_PROCS; i++)
        {
            if (PermaProcs[i].spellID != 0xFFFF)
            {
                if (rand()%100 < (PermaProcs[i].chance * dexmod))
                {
                    usedspellID = PermaProcs[i].spellID;
                    break;
                }
            }
            if (SpellProcs[i].spellID != 0xFFFF)
            {
                if (rand()%100 < (SpellProcs[i].chance * dexmod))
                {
                    usedspellID = SpellProcs[i].spellID;
                    break;
                }
            }
        }

	// Trumpcard: Changed proc targets to look up based on the spells goodEffect flag.
	// This should work for the majority of weapons.
	if ( usedspellID != 0xFFFF )
	{
		if ( IsBeneficial(usedspellID) )
			SpellFinished(usedspellID, GetID(), 10, 0);				
		else
			SpellFinished(usedspellID, other->GetID(), 10, 0);
	}

}
    
    // now check ripostes
    if (other && damage == -3) // riposting
	{
		other->Attack(this, 13, true);
        // todo: double riposte
        return false;
	}
    if (damage > 0)
        return true;
    else
        return false;
}

void NPC::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill, bool avoidable, sint8 buffslot, bool iBuffTic) {
    // now add done damage to the hate list
    if (!other)
      return;
    if(other) {
        if (attack_skill == 0x07)
	        AddToHateList(other, 1, damage, iBuffTic); // almost no aggro for archery
        else if (spell_id != 0xFFFF)
	        AddToHateList(other, damage / 2 , damage, iBuffTic); // half aggro for spells
        else
	        AddToHateList(other, damage, damage, iBuffTic);   // normal aggro for everything else
    }

    // only apply DS if physical damage (no spell damage)
    if (other && damage > 0 && spell_id == 0xFFFF) {
		this->DamageShield(other);
	}
	if (spell_id != 0xFFFF || (attack_skill>200 && attack_skill<250))
    {
        // todo: exchange that for EnvDamage-Packets when we know how to do it
		if (other && other->IsClient())
			other->CastToClient()->Message(4,"%s was hit by non-melee for %d points of damage.", this->GetName(), damage);
    }
		
	// if spell is lifetap add hp to the caster
	if (other && IsLifetapSpell( spell_id ))
	{
		int32 healedhp;

		// check if healing would be greater than max hp
		// use temp var to store actual healing value
		if ( other && other->GetHP() + damage > other->GetMaxHP())
		{
			healedhp = other->GetMaxHP() - other->GetHP();
			other->SetHP(other->GetMaxHP());
		}
		else
		{
			healedhp = damage;
			if(other != 0)
    			other->SetHP(other->GetHP() + damage);
		}

        // not sure if i need to send this or not. didnt hurt yet though ;-)
		APPLAYER hp_app;
		other->CreateHPPacket(&hp_app);

		// if client was casting the spell there need to be some messages
		if (other->IsClient())
		{
			other->CastToClient()->Message(4,"You have been healed for %d points of damage.", healedhp);
			other->CastToClient()->QueuePacket(&hp_app);
		}
			
		// emote goes with every one ... even npcs
		entity_list.MessageClose(this, true, 300, MT_Emote, "%s beams a smile at %s", other->GetName(), this->GetName() );
#ifndef REDUCE_BATTLE_SPAM
		entity_list.QueueCloseClients(this, &hp_app, false, 600, other);
#endif
	}

    if (damage > 0 && GetRune() > 0)
	{
		damage = ReduceDamage(damage, GetRune());
	}

	if (damage >= GetHP())
	{
		SetHP(-100);
		Death(other, damage, spell_id, attack_skill);
		return;
	}
		
	SetHP(GetHP() - damage);
	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;
	a->target = GetID();
	if (other == 0)
		a->source = 0;
	else if (other->IsClient() && other->CastToClient()->GMHideMe())
		a->source = 0;
	else
		a->source = other->GetID();
		
    a->type = attack_skill; // was 0x1c
    if (attack_skill == 231)
   		a->spell = 0xFFFF;
    else
   		a->spell = spell_id;
	a->damage = damage;
			
	a->unknown4[0] = 0xcd;
	a->unknown4[1] = 0xcc;
	a->unknown4[2] = 0xcc;
	a->unknown4[3] = 0x3d;
	a->unknown4[4] = 0x71;
	a->unknown4[5] = 0x6b;
	a->unknown4[6] = 0x3d;
	a->unknown4[7] = 0x41;
			
	app.priority = 5;
#ifndef REDUCE_BATTLE_SPAM
	entity_list.QueueCloseClients(this, &app, false, 200, other);
#endif
	if (other && other->IsClient())
		other->CastToClient()->QueuePacket(&app);
#ifndef REDUCE_BATTLE_SPAM
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 1;
	entity_list.QueueCloseClients(this, &hp_app, false, 200, 0, false);
#endif
	if (!IsEngaged())
        zone->AddAggroMob();
    if (other && damage > 0)
        AddRampage(other);
			
	if (damage > 0)
	{
		if (IsMezzed()) {
			this->BuffFadeByEffect(SE_Mez);
		}
		if (attack_skill == BASH && GetLevel() < 56) {
			Stun(0);
		}
		if (IsRooted() && spell_id != 0xFFFF) // neotoyko: only spells cancel root
		{
			if ((float)rand()/RAND_MAX > 0.8f)
				this->BuffFadeByEffect(SE_Root, buffslot);
		}
		if(this->casting_spell_id != 0)
		{
		    // neotokyo: made interrupting NPCs very hard (base chance > 80%)
            int16 channelling = GetSkill(CHANNELING);
            if (channelling < 225)
                channelling = 225;
			float channelchance = (float)channelling/255.0f;
			if (((float)rand()/RAND_MAX) > channelchance)
			{
				this->isattacked = true;
				this->isinterrupted = true;
			}
			else
				this->isattacked = true;
		}
	}
}

void NPC::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (other && other->IsClient())
		parse->Event(EVENT_DEATH, this->GetNPCTypeID(),0, this, other->CastToClient());
	if (this->IsEngaged())
	{
		zone->DelAggroMob();
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug,"NPC::Death() Mobs currently Aggro %i", zone->MobsAggroCount());
#endif
	}
	SetHP(0);
	SetPet(0);
	Mob* killer = GetHateDamageTop(this);
	
	entity_list.RemoveFromTargets(this);
	
	APPLAYER app;
	app.opcode = OP_Death;
	
	BuffFade(0xFFFe);
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->spell_id = spell;
	d->type = attack_skill;
	d->damage = damage;
	entity_list.QueueCloseClients(this, &app, false, 600, other);
	if (other)
	{
		if (other->IsClient())
			other->CastToClient()->QueuePacket(&app);
		hate_list.Add(other, damage);
	}
	
	if (killer && killer->IsClient())
	{
		if (killer->CastToClient()->isgrouped && entity_list.GetGroupByClient(killer->CastToClient()) != 0)
			entity_list.GetGroupByClient(killer->CastToClient())->SplitExp((uint32)(level*level*75*3.5f), GetLevel());
		else
        {
            if (killer->GetLevelCon(GetLevel()) != CON_GREEN && MerchantType == 0)
            {
#ifdef GUILDWARS
			    killer->CastToClient()->AddEXP((uint32)(level*level*200*3.5f));
#else
			    killer->CastToClient()->AddEXP((uint32)(level*level*75*3.5f)); // Pyro: Comment this if NPC death crashes zone
#endif
            }
		}
		hate_list.DoFactionHits(GetNPCFactionID());
	}
	
	if (respawn2 != 0)
	{
		respawn2->Reset();
	}
	
	if (class_ != 32 && this->ownerid == 0 && this->flag[3]!=3 && CastToNPC()->MerchantType == 0) {
		Corpse* corpse = new Corpse(this, &itemlist, GetNPCTypeID(), &NPCTypedata);
		entity_list.AddCorpse(corpse, this->GetID());
		this->SetID(0);
		if(killer != 0 && killer->IsClient()) {
			corpse->AllowMobLoot(killer->GetName(), 0);
			if(killer->CastToClient()->isgrouped) {
				Group* group = entity_list.GetGroupByClient(killer->CastToClient());
				if(group != 0) {
					for(int i=0;i<6;i++) { // Doesnt work right, needs work
						if(group->members[i] != NULL) {
							corpse->AllowMobLoot(group->members[i]->GetName(),i);
						}
					}
				}
			}
		}
	}
	this->WhipeHateList();
	p_depop = true;
}

bool Mob::ChangeHP(Mob* other, sint32 amount, int16 spell_id, sint8 buffslot, bool iBuffTic) {
	if (IsCorpse())
		return false;
	if (spell_id == 982)		/* Cazic Touch */
	{
		SetHP(-100);
		this->Death(other, abs(amount), spell_id, 231);
		return true;
	}
	else if (spell_id == 13) {	/* Complete Healing */
		SetHP(GetMaxHP());
	}
	else if (!invulnerable)
	{
		if (amount < 0)
		{
			this->Damage(other, abs(amount), spell_id, 231, false, buffslot, iBuffTic);
			return true;
		}
		else
			SetHP(GetHP() + amount);
	}
	
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 2;
	entity_list.QueueCloseClients(this, &hp_app, false, 600, other);
	if (other != 0 && other->IsClient())
		other->CastToClient()->QueuePacket(&hp_app);
	return false;
}

void Mob::MonkSpecialAttack(Mob* other, int8 type)
{
	sint32 ndamage = 0;
	//PlayerProfile_Struct pp;
	float hitsuccess = (float)other->GetLevel() - (float)level;
	float hitmodifier = 0.0;
	float skillmodifier = 0.0;
	if(level > other->GetLevel())
	{
		hitsuccess += 2;
		hitsuccess *= 14;
	}
	if ((int)hitsuccess >= 40)
	{
		hitsuccess *= 3.0;
		hitmodifier = 1.1;
	}
	if ((int)hitsuccess >= 10 && hitsuccess <= 39)
	{
		hitsuccess /= 4.0;
		hitmodifier = 0.25;
	}
	else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
	{
		hitsuccess = 0.5;
		hitmodifier = 1.5;
	}
	else if ((int)hitsuccess <= -1)
	{
		hitsuccess = 0.1;
		hitmodifier = 1.8;
	}
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug,"MonkSpecialAttack() 2 - %d", hitsuccess);
#endif
	if ((int)GetSkill(type) >= 100)
	{
		skillmodifier = 1;
	}
	else if ((int)GetSkill(type) >= 200)
	{
		skillmodifier = 2;
	}
	
	hitsuccess -= ((float)GetSkill(type)/10000) + skillmodifier;
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug,"MonkSpecialAttack() 3 - %d", hitsuccess);
#endif
	hitsuccess += (float)rand()/RAND_MAX;
#if DEBUG >= 11
    LogFile->write(EQEMuLog::Debug,"MonkSpecialAttack() 4 - %d", hitsuccess);
#endif
	float ackwardtest = 2.4;
	float random = (float)rand()/RAND_MAX;
	if(random <= 0.2)
	{
		ackwardtest = 4.5;
	}
	if(random > 85 && random < 400.0)
	{
		ackwardtest = 3.2;
	}
	if(random > 400 && random < 800.0)
	{
		ackwardtest = 3.7;
	}
	if(random > 900 && random < 1400.0)
	{
		ackwardtest = 1.9;
	}
	if(random > 1400 && random < 14000.0)
	{
		ackwardtest = 2.3;
	}
	if(random > 14000 && random < 24000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 24000 && random < 34000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 990000)
	{
		ackwardtest = 1.2;
	}
	if(random < 0.2)
	{
		ackwardtest = 0.8;
	}
	
	ackwardtest += (float)rand()/RAND_MAX;
	ackwardtest = abs((long)ackwardtest);
	if (type == 0x1A) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (FLYING_KICK + GetSTR() + level) / 700);
		if ((float)rand()/RAND_MAX < 0.2) {
			ndamage = (sint32) (ndamage * 4.2);
			if(ndamage <= 0) {
				entity_list.MessageClose(this, false, 200, 10, "%s misses at an attempt to thunderous kick %s!",name,other->name);
			}
			else {
				entity_list.MessageClose(this, false, 200, 10, "%s lands a thunderous kick!(%d)", name, ndamage);
			}
		}
		other->Damage(this, ndamage, 0xffff, 0x1A);
		DoAnim(45);
	}
	else if (type == 0x34) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (2 * ackwardtest) * (TIGER_CLAW + GetSTR() + level) / 900);
		other->Damage(this, ndamage, 0xffff, 0x34);
		DoAnim(46);
	}
	else if (type == 0x26) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (ROUND_KICK + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x26);
		DoAnim(11);
	}
	else if (type == 0x17) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (EAGLE_STRIKE + GetSTR() + level) / 1000);
		other->Damage(this, ndamage, 0xffff, 0x17);
		DoAnim(47);
	}
	else if (type == 0x15) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (5 * ackwardtest) * (DRAGON_PUNCH + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x15);
		DoAnim(7);
	}
	else if (type == 0x1E) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (KICK + GetSTR() + level) / 1200);
		other->Damage(this, ndamage, 0xffff, 0x1e);
		DoAnim(1);
	}
}

void Mob::AddToHateList(Mob* other, sint32 hate, sint32 damage, bool iYellForHelp, bool bFrenzy, bool iBuffTic) {
    assert(other != NULL);
    if (other == this)
        return;
	if (other)
	{
		bool wasengaged = IsEngaged();
		Mob* owner = other->GetOwner();
		Mob* mypet = this->GetPet();
        Mob* myowner = this->GetOwner();
		if (other == myowner)
			return;
		if (owner) {
			hate_list.Add(other, hate, 0, bFrenzy, !iBuffTic);
			hate_list.Add(owner, 1, damage, false, !iBuffTic);
		}
		else {
			hate_list.Add(other, hate, damage, false, !iBuffTic);
		}
		if (mypet) {
			mypet->hate_list.Add(other, 1, 0, bFrenzy);
		}
        else if (myowner) {
            if (myowner->IsAIControlled())
                myowner->hate_list.Add(other, 1, 0, bFrenzy);
        }
		if (!wasengaged) {
			AI_Event_Engaged(other, iYellForHelp);
			adverrorinfo = 8293;
//			other->CastToClient()->CheckQuests(zone->GetShortName(), "%%ATTACK%%", GetNPCTypeID(), 0, this); // This causes crashes
		}
	}
}

void Mob::DamageShield(Mob* other)
{
    int DS = 0;
    int DSRev = 0;
    int spellid = 0xFFFF;
	for (int i=0; i < BUFF_COUNT; i++)
	{
		if (buffs[i].spellid != 0xFFFF)
		{
			for (int z=0; z < 12; z++)
			{
				switch(spells[buffs[i].spellid].effectid[z])
				{
				case SE_DamageShield:
                {
                    int dmg = CalcSpellValue(spells[buffs[i].spellid].formula[z], spells[buffs[i].spellid].base[z], spells[buffs[i].spellid].max[z], GetLevel(), buffs[i].spellid);
                    DS += dmg;
                    spellid = buffs[i].spellid;
					break;
                }
				case SE_ReverseDS:
                    {
                    int dmg = CalcSpellValue(spells[buffs[i].spellid].formula[z], spells[buffs[i].spellid].base[z], spells[buffs[i].spellid].max[z], GetLevel(), buffs[i].spellid);
                    DSRev+=dmg;
                    spellid = buffs[i].spellid;
                    break;
                    }
				}
			}
		}
	}
    if (DS)
    {
        other->ChangeHP(this, DS, spellid);
        // todo: send EnvDamage packet to the other
		//entity_list.MessageClose(other, 0, 200, 10, "%s takes %d damage from %s's damage shield (%s)", other->GetName(), -spells[buffs[i].spellid].base[1], this->GetName(), spells[buffs[i].spellid].name);
    }
    if (DSRev)
    {
        this->ChangeHP(other, DSRev, spellid);
    }
}

int Mob::GetWeaponDamageBonus(const Item_Struct *Weapon)
{
	// Kaiyodo - Calculate the damage bonus for a weapon on the main hand
	if(GetLevel() < 28)
		return(0);
	
	// Check we're on of the classes that gets a damage bonus
	if ( !IsWarriorClass() )
		return 0;
	
	int BasicBonus = ((GetLevel() - 25) / 3) + 1;
	
	// If we have no weapon, or only a single handed weapon, just return the default
	// damage bonus of (Level - 25) / 3
	if(!Weapon || Weapon->common.skill == 0 || Weapon->common.skill == 2 || Weapon->common.skill == 3)
		return(BasicBonus);
	
	// Things get more complicated with 2 handers, the bonus is based on the delay of
	// the weapon as well as a number stored inside the weapon.
	int WeaponBonus = 0;	// How do you find this out?
	
	// Data for this, again, from www.monkly-business.com
	if(Weapon->common.delay <= 27)
		return(WeaponBonus + BasicBonus + 1);
	if(Weapon->common.delay <= 39)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4));
	if(Weapon->common.delay <= 42)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + 1);
	// Weapon must be > 42 delay
	return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + ((Weapon->common.delay-34) / 3));
}

int Mob::GetMonkHandToHandDamage(void)
{
	// Kaiyodo - Determine a monk's fist damage. Table data from www.monkly-business.com
    // saved as static array - this should speed this function up considerably
    static int damage[66] = {
    //   0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19
        99, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7,
         8, 8, 8, 8, 8, 9, 9, 9, 9, 9,10,10,10,10,10,11,11,11,11,11,
        12,12,12,12,12,13,13,13,13,13,14,14,14,14,14,14,14,14,14,14,
        15,15,16,16,17,18 };
	
	// Have a look to see if we have epic fists on
	if (IsClient() && CastToClient()->pp.inventory[12] == 10652)
		return(9);
	else
	{
		int Level = GetLevel();
        if (Level > 65)
		    return(19);
        else
            return damage[Level];
	}
}

int Mob::GetMonkHandToHandDelay(void)
{
	// Kaiyodo - Determine a monk's fist delay. Table data from www.monkly-business.com
    // saved as static array - this should speed this function up considerably
    static int delayshuman[66] = {
    //  0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19
        99,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,
        36,36,36,36,36,35,35,35,35,35,34,34,34,34,34,33,33,33,33,33,
        32,32,32,32,32,31,31,31,31,31,30,30,30,29,29,29,28,28,28,27,
        27,26,26,25,25,25 };
    static int delaysiksar[66] = {
    //  0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19
        99,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,
        36,36,36,36,36,36,36,36,36,36,35,35,35,35,35,34,34,34,34,34,
        33,33,33,33,33,32,32,32,32,32,31,31,31,30,30,30,29,29,29,28,
        28,27,27,26,26,26 };

    // Have a look to see if we have epic fists on
	if (IsClient() && CastToClient()->pp.inventory[12] == 10652)
		return(16);
	else
	{
		int Level = GetLevel();
		if (GetRace() == HUMAN)
		{
            if (Level > 65)
			    return(24);
            else
                return delayshuman[Level];
		}
		else	//heko: iksar table
		{
            if (Level > 65)
			    return(25);
            else
                return delaysiksar[Level];
		}
	}
}

//heko: backstab
void Mob::RogueBackstab(Mob* other, const Item_Struct *weapon1, int8 bs_skill)
{
	int ndamage = 0;
	int max_hit, min_hit;
	float skillmodifier = 0.0;
	int8 primaryweapondamage;
	if (weapon1)
		primaryweapondamage = weapon1->common.damage; //backstab uses primary weapon
	else
		primaryweapondamage = this->GetLevel() % 10; // fallback incase it's a npc without a weapon
	
    // catch a divide by zero error
    if (!bs_skill)
        return;

	skillmodifier = (float)bs_skill/25.0;	//formula's from www.thesafehouse.org
	
	// formula is (weapon damage * 2) + 1 + (level - 25)/3 + (strength+skill)/100
	max_hit = (int)(((float)primaryweapondamage * 2.0) + 1.0 + ((level - 25)/3.0) + ((GetSTR()+GetSkill(BACKSTAB))/100));
	max_hit *= (int)skillmodifier;
	
	// determine minimum hits
	if (level < 51)
	{
		min_hit = 0;
	}
	else
	{
		// Trumpcard:  Replaced switch statement with formula calc.  This will give minhit increases all the way to 65.
		min_hit= (int)( level * ( 1.5 + ( (level - 51) * .05 ) ));
	}
	if (max_hit < min_hit)
		max_hit = min_hit;
	ndamage = (int)min_hit + (rand()%((max_hit-min_hit)+1));	// TODO: better formula, consider mob level vs player level, strength/atk
	other->Damage(this, ndamage, 0xffff, 0x08);	//0x08 is backstab
	DoAnim(2);	//piercing animation
}


// solar - assassinate
void Mob::RogueAssassinate(Mob* other)
{
	other->Damage(this, 32000, 0xffff, 0x08);	//0x08 is backstab
	DoAnim(2);	//piercing animation
	entity_list.Message(0, MT_Shout, "%s ASSASSINATES their victim.", this->GetName());
}

// neotokyo 14-Nov-02
// Helperfunction to check for Lifetaps
bool Mob::IsLifetapSpell(int16 spell_id)
{
	// filter out invalid spell_ids
	if (spell_id <= 0 || spell_id >= 0xffff)
		return false;
	
	// if database says its a tap, i am sure its right
	if (spells[spell_id].targettype == ST_Tap)
		return true;
	
	// now check some additional lifetaps just to make sure
	// i.e. lifebane isnt recognized since type == target not tap
	switch(spell_id)
	{
	case 1613:
	case 341:
	case 445:
	case 502:
	case 447:
	case 525:
	case 2115: // Ancient: Lifebane
	case 446:
	case 524:
	case 1618: 
	case 1393: // Gangrenous touch of zu'muul
	case 1735: // trucidation
		return true;
	}
	return false;
}

sint16 Mob::ReduceMagicalDamage(sint16 damage, int16 in_rune)
{
	if (in_rune >= abs(damage))
	{
		in_rune -= abs(damage);
		damage = 0;
	}
	else
	{
		damage += in_rune;
		in_rune = 0;
        int slot = GetBuffSlotFromType(SE_AbsorbMagicAtt);
        if (slot >= 0)
            BuffFadeBySlot(slot);
	}
	SetMagicRune(in_rune);
	return damage;
}

sint16 Mob::ReduceDamage(sint16 damage, int16 in_rune)
{
	if (in_rune >= damage)
	{
		in_rune -= damage;
		damage = -6;
	}
	else
	{
		damage -= in_rune;
		in_rune = 0;
        int slot = GetBuffSlotFromType(SE_Rune);
		LogFile->write(EQEMuLog::Normal, "Fading rune from slot %d",slot);
        if (slot >= 0)
            BuffFadeBySlot(slot);
	}
	SetRune(in_rune);
	return damage;
}

bool Mob::HasProcs()
{
    for (int i = 0; i < MAX_PROCS; i++)
        if (PermaProcs[i].spellID != 0xFFFF || SpellProcs[i].spellID != 0xFFFF)
            return true;
    return false;
}
