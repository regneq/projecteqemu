#include <iostream.h>
#include "entity.h"

extern Database database;
extern EntityList entity_list;

void DispatchFinishedDBAsync(DBAsyncWork* dbaw) {
	uint32_breakdown workpt;
	workpt = dbaw->WPT();
	switch (workpt.b4()) {
/*		case DBA_b4_Main: {
			switch (workpt.i24_1()) {
				case DBA_i24_1_Main_LoadVariables: {
					char errbuf[MYSQL_ERRMSG_SIZE];
					MYSQL_RES* result;
					DBAsyncQuery* dbaq = dbaw->PopAnswer();
					if (dbaq->GetAnswer(errbuf, result))
						database.LoadVariables_result(result);
					else
						cout << "Async DB.LoadVariables() failed: '" << errbuf << "'" << endl;
					break;
				}
				default: {
					cout << "Error: DispatchFinishedDBAsync(): Unknown workpt.b4" << endl;
					break;
				}
			}
		}*/
		case DBA_b4_Entity: {
			Entity* entity = entity_list.GetID(workpt.w2_3());
			if (!entity)
				break;
			entity->DBAWComplete(workpt.b1(), dbaw);
			break;
		}
		default: {
			cout << "Error: DispatchFinishedDBAsync(): Unknown workpt.b4: " << (int) workpt.b4() << ", workpt=" << workpt << endl;
			break;
		}
	}
	safe_delete(dbaw);
}

