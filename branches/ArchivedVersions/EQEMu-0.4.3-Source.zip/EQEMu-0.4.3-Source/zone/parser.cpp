// Quest Parser written by Wes, Leave this here =P

//#include <tchar.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <iostream.h>

#include "../common/debug.h"
#include "client.h"
#include "entity.h"

#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "../common/database.h"
#include "spdat.h"
#include "../common/packet_functions.h"
#include "PlayerCorpse.h"
#include "spawn2.h"
#include "zone.h"
#include "event_codes.h"

extern Database database;
extern Zone* zone;
extern WorldServer worldserver;

Parser* parse = 0;
Client* gClient = 0;

#define Parser_DEBUG 0

const char *notin = "() ,=!&|<>";

const char * charIn = "`~1234567890-=!@#$%^&*()_+qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP|ASDFGHJKL:ZXCVBNM<>?";

char * getargs ( char * string) {
	static char temp[100];
	memset(temp,0x0,100);
	int pos = 0;
	int paren = 0;
	for ( unsigned int i = 0; i <= strlen(string); i++ )
	{
		if (paren >= 1) {
			temp[pos] = string[i];
			pos++;
		}

		if (string[i] == '(') {
			paren++;
		}
		if (string[i] == ')' || i == strlen(string)) {
			paren--;
			if ( paren == 0 || paren == -1) {
				if ( temp[strlen(temp) - 1] == ')' )
				temp[strlen(temp) - 1] = '\0';
				return temp;
			}
		}
	}
	return 0;
}

int calc(char * stuff) {
	int plus = 0, minus = 0, divide = 0, mul = 0;
	int temp = 0;
	int final = 0;
	int i=0;
	char tempa[6];
	final = atoi(stuff);
	strn0cpy(tempa,itoa(final,tempa,10), sizeof(tempa));
	stuff += strlen(tempa);
	memset(tempa, 0, sizeof(tempa));
	for (;;) {
		i++;
		if (*stuff >= 48 && *stuff <= 57) {
			if (plus) { final = final + atoi(stuff); plus = 0; }
			if (minus) { final = final - atoi(stuff); minus = 0; }
			if (mul) { final = final * atoi(stuff); mul = 0; }
			if (divide) { final = final / atoi(stuff); divide = 0; }
			temp = atoi(stuff);
			strn0cpy(tempa, itoa(temp,tempa,10), sizeof(tempa));
			stuff += strlen(tempa);
			memset(tempa, 0, sizeof(tempa));
		}
		else if (*stuff == '+') { plus = 1; stuff++; }
		else if (*stuff == '-') { minus = 1; stuff++; }
		else if (*stuff == '*') { mul = 1; stuff++; }
		else if (*stuff == '/') { divide = 1; stuff++; }
		else { stuff++; }
		if (stuff[0] == 0) { return final; }
	}
	return 0;
}

int Parser::pcalc(char * string) {
	char temp[100];
	memset(temp, 0, sizeof(temp));
	char temp2[100];
	memset(temp2, 0, sizeof(temp2));
	int p =0;
	char temp3[100];
	memset(temp3, 0, sizeof(temp3));
	char temp4[100];
	memset(temp4, 0, sizeof(temp4));
	while (strrchr(string,'(')) {
		strn0cpy(temp,strrchr(string,'('), sizeof(temp));
		for ( unsigned int i=0;i < strlen(temp); i++ ) {
			if (temp[i] != '(' && temp[i] != ')') {
				temp2[p] = temp[i];
				p++;
			}
			else if (temp[i] == ')') {
				snprintf(temp3, sizeof(temp3), "(%s)", temp2);
				Replace(string,temp3,itoa(calc(temp2),temp4,10),0);
#if Parser_DEBUG >= 9
				printf("Replacing %s with %d and %s\n", temp3,calc(temp2), string);
#endif
				memset(temp, 0, sizeof(temp));
				memset(temp2, 0, sizeof(temp2));
				memset(temp3, 0, sizeof(temp3));
				memset(temp4, 0, sizeof(temp4));
				p=0;
			}
		}
	}
	return calc(string);
}

char * Parser::strrstr(char* string, const char * sub) {
	static char temp[1000];
	memset(temp, 0, sizeof(temp));
	char temp2[1000];
	memset(temp2, 0, sizeof(temp2));
	int32 pchlen = strlen(string) + 1;
	char *pchbak, *pch = pchbak = new char[pchlen];
	memset(pch, 0, pchlen);
	strn0cpy(pch, string, pchlen);
	while(( pch = strstr(pch, sub))) {
		strn0cpy(temp2, strstr(pch, sub), sizeof(temp2));
		pch+=strlen(sub);

		if (strstr(pch, sub)) {
			strn0cpy(temp, strstr(pch, sub), sizeof(temp));
		}
		else if (strstr(temp2,sub)) {
			strn0cpy(temp, strstr(temp2, sub), sizeof(temp));
		}

	}
	safe_delete(pchbak);
	if (strstr(temp, sub))
		return temp;
	else
		return 0;
}

void Parser::MakeVars(const char * string) {
	char temp[100];
	memset(temp, 0, sizeof(temp));
	char temp2[100];
	memset(temp2, 0, sizeof(temp2));

	int tmpfor = numtok((char*)string, " ")+1;
	for ( int i=0; i < tmpfor; i++) {
		memset(temp2, 0, sizeof(temp2));
		strn0cpy(temp2, gettok((char*)string, 32, i), sizeof(temp2));
		snprintf(temp, sizeof(temp), "%s", itoa(i+1 ,temp, 10));
		AddVar(temp, temp2);
		memset(temp, 0, sizeof(temp));
		snprintf(temp, sizeof(temp), "%s-", itoa(i+1, temp, 10));
		AddVar(temp, strstr(string, temp2));
	}
}

void Parser::Event(int event, int32 npcid, const char * data, Mob* mob, Client* client) {
#if Parser_DEBUG >= 5
	cout << "Parser::Event(" << event << ", " << npcid << ", '";
	if (data)
		cout << data;
	else
		cout << "data=0";
	cout << "', mob=" << ((bool) mob != 0) << ", client=" << ((bool) client != 0) << ")" << endl;
#endif
	if (npcid == 0)
		return;
//	EventList.ClearListAndData();
	LoadScript(npcid, zone->GetShortName());
	int32 qstID = GetNPCqstID(npcid);
	if ((qstID == 0 && pNPCqstID[0] >= 0xFFFFFFF0) || qstID >= 0xFFFFFFF0)
		return;
	char temp[100];
	memset(temp, 0, sizeof(temp));
	int8 fac = 0;
	if (client) AddVar("userid", itoa(client->GetID(),temp,10));
	if (client) AddVar("ulevel", itoa(client->GetLevel(),temp,10));
	if (client) AddVar("name", client->GetName());
	if (client) AddVar("race", GetRaceName(client->GetRace()));
	if (client) AddVar("class", GetEQClassName(client->GetClass()));
	if (client) AddVar("mobid", itoa(mob->GetNPCTypeID(),temp,10));
	if (client) AddVar("mlevel", itoa(mob->GetLevel(),temp,10));
	if (client) gClient = client;
	if (client) fac = client->GetFactionLevel(client->GetID(), mob->GetID(), client->GetRace(), client->GetClass(), DEITY_AGNOSTIC, mob->CastToNPC()->GetPrimaryFaction(), mob);
	if (fac) AddVar("faction", itoa(fac,temp,10));
	if (zone) AddVar("zonesn",zone->GetShortName()); 
	if (zone) AddVar("zoneln",zone->GetLongName());

#ifdef CATCH_CRASH
	try {
#endif
	switch (event) {
		case EVENT_SAY: {
			MakeVars(data);
			SendCommands("EVENT_SAY", qstID, mob, client);
			break;
		}
		case EVENT_DEATH: {
			SendCommands("EVENT_DEATH", qstID, mob, client);
			break;
		}
		case EVENT_ITEM: {
			SendCommands("EVENT_ITEM", qstID, mob, client);
			break;
		}
		case EVENT_SPAWN: {
			SendCommands("EVENT_SPAWN", qstID, mob, client);
			break;
		}
		case EVENT_ATTACK: {
			SendCommands("EVENT_ATTACK", qstID, mob, client);
			break;
		}
		default: {
			// should we do anything here?
			break;
		}
	}
#ifdef CATCH_CRASH
	}
	catch(char* errstr) {
		LogFile->write(EQEMuLog::Error, "Parser crash caught: event: %i  npcid: %u  qstID: %u  '%s'", event, npcid, qstID, errstr);
		worldserver.SendEmoteMessage(0, 0, 100, 13, "Parser error caught on ZSPID: %i, EventID: %i, NPCID: %u, qstID: %u", getpid(), event, npcid, qstID);
	}
	catch(...) {
		LogFile->write(EQEMuLog::Error, "Parser crash caught: event: %i  npcid: %u  qstID: %u", event, npcid, qstID);
		worldserver.SendEmoteMessage(0, 0, 100, 13, "Parser error caught on ZSPID: %i, EventID: %i, NPCID: %u, qstID: %u", getpid(), event, npcid, qstID);
	}
#endif
}

char * Parser::gettok(char * string, int chara, int pos) {
	static char * pch;
	static char temp[100];
	static char ty[100];
	memset(temp, 0, sizeof(temp));
	memset(ty, 0, sizeof(ty));
	ty[0] = chara;
	strn0cpy(temp, string, sizeof(temp));
	pch = strtok(temp,ty);
	for (int i=0; i < pos; i++) {
		if (pos == i) break;
		pch = strtok(NULL,ty);
	}
	return pch;
}

int Parser::numtok(char * string, const char * tok) {
	int q = 0;
	int32 tmpStringLen = strlen(string);
	for (unsigned int i=0;i<tmpStringLen;i++) {
		if (string[i] == tok[0])
			q++;
	}
	return q;
}

Parser::Parser() {
	pMaxNPCID = database.GetMaxNPCType();
	pNPCqstID = new int32[pMaxNPCID+1];
	for (int32 i=0; i<pMaxNPCID+1; i++)
		pNPCqstID[i] = 0xFFFFFFFF;
	varlist = new vars[512];
	varlist->NextIndex = 0;
}

Parser::~Parser() {
	EventList.ClearListAndData();
	safe_delete(pNPCqstID);
	safe_delete(varlist);
}

bool Parser::LoadAttempted(int32 iNPCID) {
	if (iNPCID > pMaxNPCID)
		return false;
	return (bool) (pNPCqstID[iNPCID] != 0xFFFFFFFF);
}

bool Parser::SetNPCqstID(int32 iNPCID, int32 iValue) {
	if (iNPCID > pMaxNPCID)
		return false;
	pNPCqstID[iNPCID] = iValue;
	return true;
}

int32 Parser::GetNPCqstID(int32 iNPCID) {
	if (iNPCID > pMaxNPCID || iNPCID == 0)
		return 0xFFFFFFFE;
	return pNPCqstID[iNPCID];
}

void Parser::ClearCache() {
#if Parser_DEBUG >= 2
	cout << "Parser::ClearCache" << endl;
#endif
	for (int32 i=0; i<pMaxNPCID+1; i++)
		pNPCqstID[i] = 0xFFFFFFFF;
}

void Parser::SendCommands(const char * event, int32 npcid, Mob* mob, Client* client) {
	MyListItem <Events> * Ptr = EventList.First;

	while (Ptr) {
		if ( (int32)Ptr->Data->npcid == npcid) {
			for (int i=0; i <= Ptr->Data->index; i++) {
				if (!strcmp(Ptr->Data->event[i],event)) {
//					printf("Debug3 %s command: %s\n",Ptr->Data[i].event,Ptr->Data[i].command);
					CommandEx(Ptr->Data->command[i], npcid, mob, client);
				}
			}
		}
		Ptr = Ptr->Next;
	}
	
}

void Parser::scanformat(char *string, const char *format, char arg[10][1024])
{
	int increment_arglist = 0;
	int argnum = 0;
	int i = 0;
	char lookfor = 0;

	// someone forgot to set string or format
	if(!format)
		return;
	if(!string)
		return;

	for(;;)
	{
		// increment while they're the same (and not NULL)
		while(*format && *string && *format == *string) {
			format++;
			string++;
		}

		// format string is gone
		if(!format)
			break;
		// string is gone while the format string is still there (ERRor)
		if(!string)
			return;

		// the format string HAS to be equal to � or else things are messed up
		if(*format != '�')
			return;

		format++;
		lookfor = *format;  // copy until we find char after 'y'
		format++;

		if(!lookfor)
			break;

		// start on a new arg
		if(increment_arglist) {
			arg[argnum][i] = 0;
			argnum++;
		}

		increment_arglist = 1; // we found the first crazy y
		i = 0;  // reset index

		while(*string && *string != lookfor)
			arg[argnum][i++] = *string++;
		string++;
	}

	// final part of the string
	if(increment_arglist) {
		arg[argnum][i] = 0;
		argnum++;
		i = 0;
	}

	while(*string)
		arg[argnum][i++] = *string++;

	arg[argnum][i] = 0;
}


void Parser::EnumerateVars(char * string) {
	char varname[100];
	char varval[100];
	char buffer[100];
	char temp[100];
	int pos = 0;
	int pos2 = 0;
	int record = 0;
	int equal = 0;
	memset(buffer, 0, sizeof(buffer));
	memset(varname, 0, sizeof(varname));
	memset(varval, 0, sizeof(varval));
	memset(temp, 0, sizeof(temp));
	for (int i=0; i < strlen(string); i++) {
		if ( record || string[i] == '%') {
			buffer[pos2] = string[i];
			pos2++;
		}
		if (record) {
			if (string[i] != '=' && string[i] != ';') {
				temp[pos] = string[i];
				pos++;
			}
			if (string[i] == '=' && string[i-1] != '>' && string[i-1] != '<' && (string[i+1] != '=' && string[i-1] != '=') && string[i-1] != '!') {
				strn0cpy(varname, temp, sizeof(varname));
				memset(temp, 0, sizeof(temp));
				pos = 0;
				equal = 1;
			}
			if (string[i] == ';' && equal == 1) {
				strn0cpy(varval, temp, sizeof(varval));
#if Parser_DEBUG >= 9
				printf("Now it's %s\n", temp);
#endif
				if (strstr(varval,"$calc"))
					ParseVars(varval);
				AddVar(varname,varval);
#if Parser_DEBUG >= 9
				printf("Adding %s and %s\n", varname, varval);
#endif
				Replace(string,buffer,"");
#if Parser_DEBUG >= 9
				printf("New string: %s\n", string);
#endif
				memset(temp, 0, sizeof(temp));
				memset(buffer, 0, sizeof(buffer));
				memset(varname, 0, sizeof(varname));
				memset(varval, 0, sizeof(varval));
				pos2 = 0;
				pos = 0;
				i=-1;
				record = 0;
				equal = 0;
			}
			if (string[i+1] == '%' && equal == 0) {
				memset(temp, 0, sizeof(temp));
				memset(buffer, 0, sizeof(buffer));
				pos = 0;
				pos2 = 0;
				record = 0;
			}
		}
		else {
			if (string[i] == '%') {
				record = 1;
			}
		}
	}
}

char * postring (char * string, int pos) {
	static char temp[1024];
	memset(temp, 0, sizeof(temp));
	int p=0;
	int tmpStringLen = strlen(string);
	for (int i=pos; i < tmpStringLen; i++) {
		temp[p] = string[i];
		p++;
	}
	return temp;
}


void Parser::CommandEx(char * command, int32 npcid, Mob* other, Client* client) {
	char temp[1024];
	char arg1[1024];
	char tempBuff1[2048];
	char varstat[2048];
	memset(temp, 0, sizeof(temp));
	memset(arg1, 0, sizeof(arg1));
	memset(tempBuff1, 0, sizeof(tempBuff1));
	memset(varstat, 0, sizeof(varstat));
	int ty = 0;
	int a = 0;
	int ignore = 0;
	int numargs = 0;
	//int8 fac = 0;
	int while2 = 0;
	char arglist[10][1024];
	memset(arglist, 0, sizeof(arglist));

	strn0cpy(tempBuff1, command, sizeof(tempBuff1));
	EnumerateVars(tempBuff1);
	ParseVars(tempBuff1);
//	tempBuff1[strlen(tempBuff1) - 2] = '\0';
#if Parser_DEBUG >= 9
	printf("TempBuff: %s\n", tempBuff1);
#endif
	int number = numtok(tempBuff1,"�");
	int while1 = 0;

	for (int i=0; i <= (int)strlen(tempBuff1); i++)
//	for (int i=0; i < 2; i++)
	{
		temp[ty] = tempBuff1[i];
		ty++;
		if (tempBuff1[i] == '�')  {
#if Parser_DEBUG >= 9
			printf("While1: %d\n", while1);
#endif
			if (!while2) {
				a++;
#if Parser_DEBUG >= 9
				printf("Splitting at %s - %d - %d\n", temp, ignore, while1);
#endif
				ignore = 0;
			}
			else {
				memset(tempBuff1, 0, sizeof(tempBuff1));
				char t1[1000];
				memset(t1, 0, sizeof(t1));
				strn0cpy(t1, postring(command, while1), sizeof(t1));
				strn0cpy(tempBuff1, strstr(t1, "while("), sizeof(tempBuff1));
#if Parser_DEBUG >= 9
				printf("Test-While: %s\n", tempBuff1);
#endif
				EnumerateVars(tempBuff1);
				ParseVars(tempBuff1);
#if Parser_DEBUG >= 9
				printf("TempBuff-2: %s\n", tempBuff1);
#endif
				number = numtok(tempBuff1,"�");
				i = -1;
				a=0;
			}
			memset(temp, 0, sizeof(temp));
			ty = 0;
		}

		if (!ignore && (tempBuff1[i] == ')' || i == (int)strlen(tempBuff1)-1)) {
			numargs = numtok(temp,",") + 1;
			sprintf(varstat,"�(");


			if (numargs > 1) {
				for (int h=0; h < numargs; h++)
					snprintf(varstat, sizeof(varstat), "%s�,", varstat);
				snprintf(varstat, sizeof(varstat), "%s)", varstat);
			}
			else {
				snprintf(varstat, sizeof(varstat), "%s�)", varstat);
			}
			memset(arglist, 0, sizeof(arglist));
			scanformat(temp, varstat, arglist);
#if Parser_DEBUG >= 9
			printf("Finished: %s and %s\n", varstat, arglist[0]);
//			printf("Finished:\n");
#endif
			memset(varstat, 0, sizeof(varstat));
			memset(temp, 0, sizeof(temp));
			ty = 0;

			if (strstr(strlwr(arglist[0]),"if") && numargs == 1) {
				int GoOn = ParseIf(arglist[1]);
				if (!GoOn && (a <= number))
					ignore = 1;
			}
			else if (strstr(strlwr(arglist[0]),"if") && numargs > 1) {
				char tempa[100];
				memset(tempa, 0, sizeof(tempa));
				for (int t=1; t <= numargs; t++)
					snprintf(tempa, sizeof(tempa), "%s%s", tempa,arglist[t]);
				tempa[strlen(tempa) - 1] = '\0';
				int GoOn = ParseIf(tempa);
				if (!GoOn && (a <= number))
					ignore = 1;
			}
			else if (!strcmp(strlwr(arglist[0]),"break") && numargs == 1) {
				break;
			}
			else if (!strcmp(strlwr(arglist[0]),"while") && numargs == 1) {
				int GoOn = ParseIf(arglist[1]);
#if Parser_DEBUG >= 9
				printf("Temp: %s and %d\n", arglist[1], GoOn);
#endif
				if (GoOn) {
//					printf("Test-TempBuffarg: %s\n", postring(tempBuff1,i-(strlen(arglist[1])+strlen("while("))));
					while1 = i-(strlen(arglist[1])+strlen("while("));
					while2 = 1;
#if Parser_DEBUG >= 9
					printf("Test-TempBuffarg: %d\n", while1);
#endif
				}
				else {
					ignore = 1;
					while1 = 0;
					while2 = 0;
				}
			}
			else if (!strcmp(strlwr(arglist[0]),"spawn") && numargs == 6) {
				//char tempa[100];
				const NPCType* tmp = 0;
				int16 grid = atoi(arglist[2]);
				int8 guildwarset = atoi(arglist[3]);
				if ((tmp = database.GetNPCType(atoi(arglist[1])))) {
					NPC* npc = new NPC(tmp, 0, atof(arglist[4]), atof(arglist[5]), atof(arglist[6]), client->GetHeading());
					npc->AddLootTable();
					entity_list.AddNPC(npc,true,true);
					// Quag: Sleep in main thread? ICK!
					// Sleep(200);
					// Quag: check is irrelevent, it's impossible for npc to be 0 here
					// (we're in main thread, nothing else can possibly modify it)
//					if(npc != 0) {
						if(grid > 0)
							npc->AssignWaypoints(grid);
#ifdef GUILDWARS
						if(guildwarset > 0 && guildwarset == 1 && client->GuildDBID() > 0)
							npc->SetGuildOwner(client->GuildDBID());
#endif
						npc->SendPosUpdate();
//					}
				}
			}
			else if (strstr(strlwr(arglist[0]),"echo") && numargs == 1) {
				printf("%s\n", arglist[1]);
			}
			else if (strstr(strlwr(arglist[0]),"summonitem") && numargs == 1) {
				client->SummonItem(atoi(arglist[1]));
			}
			else if (strstr(strlwr(arglist[0]),"castspell") && numargs == 2) {
				other->CastSpell(atoi(arglist[2]), atoi(arglist[1]));
			}
			else if (strstr(strlwr(arglist[0]),"say") && numargs == 1) {
				entity_list.NPCMessage(other, false, 400, 0, "%s says, '%s'", other->GetName(), arglist[1]);
			}
			else if (strstr(strlwr(arglist[0]),"emote") && numargs == 1) {
				entity_list.NPCMessage(other, false, 400, 0, "%s %s", other->GetName(), arglist[1]);
			}
			else if (strstr(strlwr(arglist[0]),"shout") && numargs == 1) {
				entity_list.NPCMessage(other, false, 0, 13, "%s shouts, '%s'", other->GetName(), arglist[1]);
			}
			else if (strstr(strlwr(arglist[0]),"depop") && numargs == 1) {
				other->CastToNPC()->Depop();
			}
			else if (strstr(strlwr(arglist[0]),"cumflag") && numargs == 1) {
				other->flag[50] = other->flag[50] + 1;
			}
			else if (strstr(strlwr(arglist[0]),"flagnpc") && numargs == 1) {
				int32 tmpFlagNum = atoi(arglist[1]);
				if (tmpFlagNum >= (sizeof(other->flag) / sizeof(other->flag[0])))
					other->flag[tmpFlagNum] = atoi(arglist[2]);
				else {
					// Quag: TODO: Script error here, handle it somehow?
				}
			}
			else if (strstr(strlwr(arglist[0]),"flagclient") && numargs == 1) {
				if (client)
					client->flag[atoi(arglist[1])] = atoi(arglist[2]);
			}
			else if (strstr(strlwr(arglist[0]),"exp") && numargs == 1) {
				if (client)
					client->AddEXP(atoi(arglist[1]));
			}
			else if (strstr(strlwr(arglist[0]),"level") && numargs == 1) {
				if (client)
					client->SetLevel(atoi(arglist[1]), true);
			}
			else if (strstr(strlwr(arglist[0]),"safemove") && numargs == 1) {
				if (client)
					client->MovePC(zone->GetShortName(),database.GetSafePoint(zone->GetShortName(),"x"),database.GetSafePoint(zone->GetShortName(),"y"),database.GetSafePoint(zone->GetShortName(),"z"));
			}
			else if (strstr(strlwr(arglist[0]),"rain") && numargs == 1) {
				zone->zone_weather = atoi(arglist[1]);
				APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
				*((int32*) outapp->pBuffer[4]) = atoi(arglist[1]); // Why not just use 0x01/2/3?
				entity_list.QueueClients(other, outapp);
				delete outapp;
			}
			else if (strstr(strlwr(arglist[0]),"snow") && numargs == 1) {
				zone->zone_weather = atoi(arglist[1]) + 1;
				APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
				outapp->pBuffer[0] = 0x01;
				*((int32*) outapp->pBuffer[4]) = atoi(arglist[1]);
				entity_list.QueueClients(client, outapp);
				delete outapp;
			}
			else if (strstr(strlwr(arglist[0]),"givecash") && numargs == 4) {
				APPLAYER* outapp = new APPLAYER(OP_MoneyOnCorpse, sizeof(moneyOnCorpseStruct));
				moneyOnCorpseStruct* d = (moneyOnCorpseStruct*) outapp->pBuffer;
		
				d->response		= 1;
				d->unknown1		= 0x5a;
				d->unknown2		= 0x40;
				if (client) { 
					d->copper		= atoi(arglist[1]);
					d->silver		= atoi(arglist[2]);
					d->gold			= atoi(arglist[3]);
					d->platinum		= atoi(arglist[4]);
					client->AddMoneyToPP(d->platinum, d->gold, d->silver, d->copper);
					client->QueuePacket(outapp); 
				}
				delete outapp;
			}
			else if (strstr(strlwr(strlwr(arglist[0])),"pvp") && numargs == 1) {
				if (!strcmp(strlwr(arglist[1]),"on") != NULL)
					client->SetPVP(true);
				else
					client->SetPVP(false);
			}
			else if (strstr(strlwr(arglist[0]),"doanim") && numargs == 1) {
				other->DoAnim(atoi(arglist[1]));
			}
			else if (strstr(strlwr(arglist[0]),"addskill") && numargs == 2) {
				if (client) client->AddSkill(atoi(arglist[1]), atoi(arglist[2]));
			}
			else if (strstr(strlwr(arglist[0]),"flagcheck") && numargs == 1) {
				int32 tmpFlagNum1 = atoi(arglist[1]);
				int32 tmpFlagNum2 = atoi(arg1);
				if (tmpFlagNum1 >= (sizeof(other->flag) / sizeof(other->flag[0])) || tmpFlagNum2 >= (sizeof(other->flag) / sizeof(other->flag[0]))) {
					if (client->flag[tmpFlagNum1] != 0)
						client->flag[tmpFlagNum2] = 0;
				}
				else {
					// Quag: TODO: Script error here, handle it somehow?
				}
				// Quag: Orignal code, not sure how this is supposed to work
//				if (client->flag[atoi(arglist[1])] != 0)
//					client->flag[atoi(arg1)] = 0;
			}
			else {
				printf("Unrecognized command: %s\n", strlwr(arglist[0]));
			}
			numargs = 0;
		}
    }
}

void Parser::ClearEventsByNPCID(int32 iNPCID) {
	MyListItem<Events>* Ptr = EventList.First;
	MyListItem<Events>* next = 0;
	while (Ptr) {
		next = Ptr->Next;
		if ( (int32)Ptr->Data->npcid == iNPCID) {
			EventList.DeleteItemAndData(Ptr);
		}
		Ptr = next;
	}
}

void Parser::LoadScript(int npcid, const char *zone) {
#if Parser_DEBUG >= 4
	cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') LoadAttempted(): " << LoadAttempted(npcid) << endl;
#endif
	if (LoadAttempted(npcid))
		return;
	SetNPCqstID(npcid, npcid);
	ClearEventsByNPCID(npcid);
	FILE *input;
	char *buffer;

	int bracket = 0;
	int size = 0;
	int quote = 0;
	//int ignore = 0;

	char temp[1024];
	char finish[1024];

	int p = 0;

	char strnpcid[25] = "default";
	if (npcid)
		snprintf(strnpcid, sizeof(strnpcid), "%u", npcid);

	char filename[100];
	memset(filename, 0, sizeof(filename));
	snprintf(filename, sizeof(filename),"quests/%s/%s.qst", zone, strnpcid);
	#if Parser_DEBUG >= 8
		cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') Attempting: " << filename << endl;
	#endif
	input = fopen(filename,"rb");
	if (input == NULL) {
		memset(filename, 0, sizeof(filename));
		snprintf(filename, sizeof(filename), "quests/all/%s.qst", strnpcid);
		#if Parser_DEBUG >= 8
			cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') Attempting: " << filename << endl;
		#endif
		input = fopen(filename,"rb");
		if (input == NULL) {
			if (npcid) {
				SetNPCqstID(npcid, 0);
				LoadScript(0, zone);
			}
			else
				SetNPCqstID(0, 0xFFFFFFFE);
			#if Parser_DEBUG >= 3
				cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') No Scripts found, abandoning. " << endl;
			#endif
			return;
		}
		#if Parser_DEBUG >= 3
			else {
				cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') Loaded: " << filename << endl;
			}
		#endif
	}
	#if Parser_DEBUG >= 3
		else {
			cout << "Parser::LoadScript(" << npcid << ", '" << zone << "') Loaded: " << filename << endl;
		}
	#endif
	Events* NewEventList = new Events;
	fseek(input, 0, SEEK_END);
    size = ftell(input);
	rewind(input);
	buffer = new char[size];
	memset(buffer, 0, size);
	fread(buffer, 1, size, input);

	NewEventList->index = -1;
	NewEventList->npcid = npcid;
	memset(finish, 0, sizeof(finish));
	memset(temp, 0, sizeof(temp));

	for (int i=0; i < size; i++) {
		if (strrchr(charIn,buffer[i]) || (quote == 1 && buffer[i] != '\"')) {
			temp[p] = buffer[i];
			p++;
		}
		if (buffer[i] == '\"') {
			if (!quote)
				quote = 1;
			else
				quote = 0;
		}
		if (buffer[i] == '{') {
			if (strstr(temp,"EVENT")) {
				NewEventList->index += 1;
#if Parser_DEBUG >= 9
				printf("New Event: %s - Index: %d\n", temp, NewEventList->index);
#endif
				strcpy(NewEventList->event[NewEventList->index],temp);
				memset(temp, 0, sizeof(temp));
				p = 0;
			}
			bracket++;
		}
		if (buffer[i] == '}') {
			bracket--;
			if (bracket == 1) {
				if (strstr(finish,"�"))
					snprintf(finish, sizeof(finish), "%s%s�", finish, temp);
				else
					snprintf(finish, sizeof(finish), "%s�", temp);
				memset(temp, 0, sizeof(temp));
				p = 0;
			}
			else if (bracket == 0) {
				if (temp[0] != 0) {
					snprintf(finish, sizeof(finish), "%s%s�", finish, temp);
#if Parser_DEBUG >= 9
					printf("Finishadd: %s\n", temp);
#endif
					memset(temp, 0, sizeof(temp));
					p = 0;
				}
#if Parser_DEBUG >= 9
				printf("New Command: %s - Index: %d\n", finish, NewEventList->index);
#endif
				strn0cpy(NewEventList->command[NewEventList->index], finish, sizeof(NewEventList->command[0]));
				memset(finish, 0, sizeof(temp));
			}
		}
	}
	EventList.AddItem(NewEventList);
	fclose(input);
	safe_delete(buffer);
}


void Parser::Replace(char * string, const char * repstr, const char * rep, int all) {
	int position = 0;
	int32 templen = strlen(string)+1;
	char *temp, *tempdel = temp = new char[templen];
	memset(temp, 0, templen);
	while (strrstr(string, repstr) != NULL && strn0cpy(temp, strrstr(string,repstr), templen)) {
		position = (strlen(string) - strlen(strrstr(string, repstr)));
		temp += strlen(repstr);
		string[position] = 0;
		char* temp2 = strcpy(new char[strlen(string)+1], string);
		sprintf(string,"%s%s%s", temp2, rep, temp);
		delete temp2;
		if (!all)
			break;
	}
	safe_delete(tempdel);
}


int Parser::GetVar(const char * varname) {
	for (int i=0; i < varlist->NextIndex; i++) {
		if (strcmp(varlist[i].name,varname) == 0) {
			return i;
		}
	}
	return -1;
}

void Parser::AddVar(const char *varname, const char * varval) {
	if (varlist->NextIndex == 0) {
		strcpy(varlist[varlist->NextIndex].name, varname);
		strcpy(varlist[varlist->NextIndex].value, varval);
    	varlist->NextIndex += 1;
	}
	int tmpVar = GetVar(varname);
	if (tmpVar != -1) {
		memset(varlist[tmpVar].value, 0, sizeof(varlist[tmpVar].value));
		strcpy(varlist[tmpVar].value,varval);
	}
	else {
		if (varlist->NextIndex >= Parser_MaxVars)
			ThrowError("parser.cpp: AddVar(): varlist->index > Parser_MaxVars");
		strn0cpy(varlist[varlist->NextIndex].name, varname, sizeof(varlist[varlist->NextIndex].name));
		strn0cpy(varlist[varlist->NextIndex].value, varval, sizeof(varlist[varlist->NextIndex].value));
		varlist->NextIndex += 1;
	}
}

void Parser::HandleVars(char * varname, char * varparms, char * origstring, char * format)
{
	char arglist[10][1024];
	memset(arglist, 0,sizeof(arglist));
	char varstat[200];
	memset(varstat, 0, sizeof(varstat));

	int numargs = 0;
	if (varparms) {
		numargs = numtok(varparms,",") + 1;

		if (numargs > 1) {
			for (int h=0; h < numargs; h++)
				sprintf(varstat,"%s�,",varstat);
		}
		else {
			sprintf(varstat,"%s",varparms);
		}

		scanformat(varparms,varstat,arglist);
#if Parser_DEBUG >= 9
		printf("Test: %s\n", arglist[0]);
		printf("Varparms: %s\n", varparms);
#endif
	}

	if (!strcmp(varname,"mid") && numargs == 3) {
		char temp[1024];
		int a = 0;
		int pos = 0;
		int index = 0;
		char arg1[1024];
		memset(arg1, 0, sizeof(arg1));
		index = atoi(arglist[1]);
		pos = atoi(arglist[2]);
		memset(temp, 0, sizeof(temp));
		strn0cpy(arg1, arglist[0], sizeof(arg1));
		for ( int i=0; i< (int)strlen(arglist[1]); i++) {
			if (index >= i) {
				temp[a] = arg1[i];
				a++;
				if (a == pos)
					break;
			}
		}
		Replace(origstring,format,temp);
	}
	else if (!strcmp(varname,"+")) {
		int32 templen = strlen(format)+2;
		char* temp = new char[templen];
		snprintf(temp, templen, " %s ", format);
		Replace(origstring, temp, " REPLACETHISSHIT ");
		safe_delete(temp);
	}
	else if (!strcmp(varname,"replace") && numargs == 3) {
		char temp[1024];
		memset(temp, 0, sizeof(temp));
		strn0cpy(temp, arglist[0], sizeof(temp));
		Replace(temp, arglist[1], arglist[2],1);
		Replace(origstring, format, temp);
	}
	else if (!strcmp(varname,"calc")) {
		char temp[100];
		memset(temp, 0, sizeof(temp));
		Replace(origstring,format,itoa(pcalc(varparms),temp,10));
#if Parser_DEBUG >= 9
		printf("New string calc: %s\n", origstring);
#endif
	}
	else if (!strcmp(varname,"status")) {
		char temp[6];
		memset(temp, 0, sizeof(temp));
		Replace(origstring,format,itoa(gClient->Admin(),temp,10));
	}
	else if (!strcmp(varname,"hasitem")) {
		int has=0;
		for (int i=0; i<=30;i++) {
			if (gClient->GetItemAt(i) == atoi(varparms)) {
				Replace(origstring,format,"true");
				has = 1;
				break;
			}
		}
		if (!has)
			Replace(origstring,format,"false");
	}

	else if (!strcmp(varname,"strlen") && numargs == 1) {
		char temp[6];
		memset(temp, 0, sizeof(temp));
		Replace(origstring,format,itoa(strlen(varparms),temp,10));
	}
	else if (!strcmp(varname,"chr") && numargs == 1) {
		char temp[2];
		memset(temp, 0, sizeof(temp));
		temp[0] = atoi(varparms);
		Replace(origstring,format,temp);
	}
	else if (!strcmp(varname,"asc") && numargs == 1) {
		char temp[10];
		Replace(origstring,format,itoa(varparms[0],temp,10));
	}
	else if (!strcmp(varname,"gettok") && numargs == 3) {
		Replace(origstring,format,gettok(arglist[0],atoi(arglist[1]),atoi(arglist[2])));
	}
	else {
		int result = GetVar(varname);
		if (result == -1) {
			Replace(origstring,format,"NULL");
		}
		else {
			Replace(origstring,format,varlist[result].value);
		}
	}
}

char * Parser::ParseVars(char * string)
{
	if (!strstr(string,"$") && !strstr(string,"%"))
		return string;
	char * pch;
	char buffer[500];
	char buffer2[500];
	char varname[20];
	char params[500];
	char eh[500];
	char eh1[500];
	int scalar = 0;
	int paren = 0;
	int pos = 0;
	int pos2 = 0;
	int record = 0;
	memset(buffer, 0, sizeof(buffer));
	memset(buffer2, 0, sizeof(buffer2));
	memset(varname, 0, sizeof(varname));
	memset(params, 0, sizeof(params));
	memset(eh, 0, sizeof(eh));
	memset(eh1, 0, sizeof(eh1));

#if Parser_DEBUG >= 9
	printf("About to parse: %s\n", string);
#endif

	while((pch = strrchr(string,'%'))) {
//		if (pch == NULL)
//			return string;

		for (unsigned int i=0; i<strlen(pch);i++) {
			eh[pos2] = pch[i];
			pos2++;
			if (scalar && !strrchr(notin,pch[i])) {
				varname[pos] = pch[i];
				pos++;
			}

			if (record == 1)
			{
				buffer[pos] = pch[i];
				pos++;
			}

			if (pch[i] == '(')
			{
				scalar = 0;
				paren = 1;
				pos = 0;
				record = 1;
			}
			if (pch[i] == ')')
			{
				paren--;
				if (paren == 0 || paren == -1)
				{
					if (eh[strlen(eh) - 2] != '(')
						eh[strlen(eh) - 1] = '\0';
#if Parser_DEBUG >= 9
					printf("Varname: %s - Parms: %s - Format: %s\n", varname, buffer, eh);
#endif
					HandleVars(varname, buffer, string, eh);
					memset(varname, 0, sizeof(varname));
					memset(buffer, 0, sizeof(buffer));
					memset(eh, 0, sizeof(eh));
					pos = 0;
					pos2 = 0;
					scalar = 0;
					paren = 0;
					break;
				}
			}
			else {
				if (strrchr(notin,pch[i]) && paren == 0) {
					eh[strlen(eh) - 1] = '\0';
#if Parser_DEBUG >= 9
					printf("Varname: %s - Format: %s\n", varname, eh);
#endif
					HandleVars(varname, 0, string, eh);
					memset(varname, 0, sizeof(varname));
					memset(buffer, 0, sizeof(buffer));
					memset(eh, 0, sizeof(eh));
					pos = 0;
					pos2 = 0;
					scalar = 0;
					break;
				}
			}
			if (pch[i] == '%')
				scalar = 1;
		}
	}

	scalar = 0;
	paren = 0;
	pos = 0;
	pos2 = 0;
	record = 0;
	memset(buffer, 0, sizeof(buffer));
	memset(buffer2, 0, sizeof(buffer2));
	memset(varname, 0, sizeof(varname));
	memset(params, 0, sizeof(params));
	memset(eh, 0, sizeof(eh));
	memset(eh1, 0, sizeof(eh1));


	while(strrchr(string,'$')) {
		pch = strrchr(string,'$');
		if (pch == NULL) return string;

		for (unsigned int i=0; i<strlen(pch);i++) {
			eh[pos2] = pch[i];
			pos2++;
			if (scalar && !strrchr(notin,pch[i])) {
				varname[pos] = pch[i];
				pos++;
			}

			if (record == 1 && pch[i] != ')')
			{
				buffer[pos] = pch[i];
				pos++;
			}

			if (pch[i] == '(')
			{
				scalar = 0;
				paren = 1;
				pos = 0;
				record = 1;
			}
			if (pch[i] == ')')
			{
#if Parser_DEBUG >= 9
				printf("test Varname: %s - Parms: %s - Format: %s test too %d\n", varname, buffer, eh, paren);
#endif
				paren--;
				if (paren == 0 || paren == -1)
				{
					if (eh[strlen(eh) - 2] != '(' && paren == -1)
						eh[strlen(eh) - 1] = '\0';
#if Parser_DEBUG >= 9
					printf("Varname: %s - Parms: %s - Format: %s\n", varname, buffer, eh);
#endif
					HandleVars(varname, buffer, string, eh);
					memset(varname, 0, sizeof(varname));
					memset(buffer, 0, sizeof(buffer));
					memset(eh, 0, sizeof(eh));
					pos = 0;
					pos2 = 0;
					scalar = 0;
					paren = 0;
					record = 0;
					break;
				}
			}
			else {
				if (strrchr(notin,pch[i]) && paren == 0) {
					eh[strlen(eh) - 1] = '\0';
#if Parser_DEBUG >= 9
					printf("Varname: %s - Format: %s\n", varname, eh);
#endif
					HandleVars(varname, 0, string, eh);
					memset(varname, 0, sizeof(varname));
					memset(buffer, 0, sizeof(buffer));
					memset(eh, 0, sizeof(eh));
					pos = 0;
					pos2 = 0;
					scalar = 0;
					record = 0;
					break;
				}
			}
			if (pch[i] == '$')
				scalar = 1;
		}
	}
	Replace(string," REPLACETHISSHIT ","");
	return 0;
}	

int Parser::ParseIf(char * string) {
	int equal = 0;
	int nequal = 0;
	int por = 0;
	int pos = 0;
	//int pos2 = 0;
	//int pos3 = 0;
	char buffer[100];
	char buffer2[100];
	char buffer3[100];
	char condition[100];
	char condition2[100];
	memset(condition, 0, sizeof(condition));
	memset(condition2, 0, sizeof(condition2));
	memset(buffer, 0, sizeof(buffer));
	memset(buffer2, 0, sizeof(buffer2));
	memset(buffer3, 0, sizeof(buffer3));
	for (unsigned int i=0; i < strlen(string); i++)	{
		if (string[i] != '!' && string[i] != '|' && string[i] != '&' && string[i] != '=') {
			buffer[pos] = string[i];
			pos++;
		}
		if (string[i] == '=' && string[i+1] == '=') {
			condition[0] = string[i];
			condition[1] = string[i+1];
			equal = 1;
			i++;
			strn0cpy(buffer2, buffer, sizeof(buffer2));
			memset(buffer, 0, sizeof(buffer));
			pos = 0;
		}
		else if (string[i] == '=' && string[i+1] == '~') {
			condition[0] = string[i];
			condition[1] = string[i+1];
			equal = 1;
			i++;
			strn0cpy(buffer2, buffer, sizeof(buffer2));
			memset(buffer, 0, sizeof(buffer));
			pos = 0;
		}
		else if (string[i] == '!' && string[i+1] == '=') {
			condition[0] = string[i];
			condition[1] = string[i+1];
			nequal = 1;
			i++;
			strn0cpy(buffer2, buffer, sizeof(buffer2));
			memset(buffer, 0, sizeof(buffer));
			pos = 0;
		}
		else if (string[i] == '<' || string[i] == '>') {
			condition[0] = string[i];
			if (string[i+1] == '=') {
				condition[1] = string[i+1];
				i++;
			}

#if Parser_DEBUG >= 9
			printf("Test condition: %s\n", condition);
#endif
			strn0cpy(buffer2, buffer, sizeof(buffer2));
			memset(buffer, 0, sizeof(buffer));
			pos = 0;
		}
		else if (string[i] == '&' && string[i+1] == '&') {
			if (!strcmp(condition2,"||"))
				por = 1;
			condition2[0] = string[i];
			condition2[1] = string[i+1];
			strn0cpy(buffer3, buffer, sizeof(buffer3));
			if (!strcmp(condition,"==")) {
				if (strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"!=")) {
				if (!strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"=~")) {
				if (!strstr(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<")) {
				if ((atoi(buffer2) > atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">")) {
				if ((atoi(buffer2) < atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<=")) {
				if ((atoi(buffer2) >= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">=")) {
				if ((atoi(buffer2) <= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
			memset(buffer, 0, sizeof(buffer));
			memset(buffer2, 0, sizeof(buffer2));
			memset(buffer3, 0, sizeof(buffer3));
			memset(condition, 0, sizeof(condition));
			pos = 0;
			if (por)
				por = 0;
			i++;
		}
		else if (string[i] == '|' && string[i+1] == '|') {
			strn0cpy(buffer3, buffer, sizeof(buffer3));
			if (!strcmp(condition2,"||") || condition2[0] == 0)
				por = 1;
			condition2[0] = string[i];
			condition2[1] = string[i+1];
			if (!strcmp(condition,"==")) {
				if (strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"!=")) {
				if (!strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"=~")) {
				if (!strstr(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<")) {
				if ((atoi(buffer2) > atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">")) {
				if ((atoi(buffer2) < atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<=")) {
				if ((atoi(buffer2) >= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">=")) {
				if ((atoi(buffer2) <= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
			memset(condition, 0, sizeof(condition));
			memset(buffer, 0, sizeof(buffer));
			memset(buffer2, 0, sizeof(buffer2));
			memset(buffer3, 0, sizeof(buffer3));
			pos = 0;
			por = 0;
			i++;
		}
		else if (i == (strlen(string) - 1)) {
			strn0cpy(buffer3,buffer, sizeof(buffer3));
			if (!strcmp(condition2,"||"))
				por = 1;
			if (!strcmp(condition,"==")) {
				if (strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"!=")) {
				if (!strcmp(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"=~")) {
				if (!strstr(buffer2,buffer3) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<")) {
				if ((atoi(buffer2) > atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">")) {
				if ((atoi(buffer2) < atoi(buffer3) || atoi(buffer2) == atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,"<=")) {
				if ((atoi(buffer2) >= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
			else if (!strcmp(condition,">=")) {
				if ((atoi(buffer2) <= atoi(buffer3) && atoi(buffer2) != atoi(buffer3)) && !por)
					return 0;
			}
		}
	}
	return 1;
}
