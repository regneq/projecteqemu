#include "../common/types.h"
#ifdef WIN32
	#include <windows.h>
#endif

class MMF {
public:
	struct MMF_Struct {
		bool	Loaded;
		int32	datasize;
		int8	data[0];
	};

	MMF();
	virtual ~MMF();

			bool	Open(const char* iName, int32 iSize);
			void	Close();
	const	void*	GetHandle() { if (IsLoaded()) { return SharedMemory->data; } return 0; }
			void*	GetWriteableHandle() { if (!IsLoaded() && CanWrite()) { return SharedMemory->data; } return 0; }

	inline	bool	IsOpen()		{ return (bool) (SharedMemory != 0); }
	inline	bool	IsLoaded()		{ if (SharedMemory) { return SharedMemory->Loaded; } return false; }
			bool	SetLoaded()		{ if (SharedMemory && CanWrite()) { SharedMemory->Loaded = true; return true; } return false; }
	inline	bool	CanWrite()		{ if (SharedMemory) { return pCanWrite; } return false; }
private:
	bool		pCanWrite;
	MMF_Struct* SharedMemory;
#ifdef WIN32
	HANDLE		hMapObject;
	LPVOID		lpvMem;
#else
	void*		lpvMem;
#endif
};
