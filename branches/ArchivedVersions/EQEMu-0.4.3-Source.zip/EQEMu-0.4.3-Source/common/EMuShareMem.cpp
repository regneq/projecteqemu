#include <iostream.h>
#include "../common/types.h"

#include "EMuShareMem.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp

	#define EmuLibName "EMuShareMem"
#else
	#define EmuLibName "libEMuShareMem.so"

	#include "../common/unix.h"
	#include <dlfcn.h>
    #define GetProcAddress(a,b) dlsym(a,b)
	#define LoadLibrary(a) dlopen(a, RTLD_NOW) 
	#define  FreeLibrary(a) dlclose(a)
	#define GetLastError() dlerror()
#endif

LoadEMuShareMemDLL EMuShareMemDLL;

LoadEMuShareMemDLL::LoadEMuShareMemDLL() {
	hDLL = 0;
	Items.GetItem = 0;
	Items.IterateItems = 0;
	Items.cbAddItem = 0;
	Items.DLLLoadItems = 0;
	NPCTypes.GetNPCType = 0;
	NPCTypes.cbAddNPCType = 0;
	NPCTypes.DLLLoadNPCTypes = 0;
	Doors.GetDoor = 0;
	Doors.cbAddDoor = 0;
	Doors.DLLLoadDoors = 0;
	NPCFactionList.DLLLoadNPCFactionLists = 0;
	NPCFactionList.GetNPCFactionList = 0;
	NPCFactionList.cbAddNPCFactionList = 0;
	NPCFactionList.cbSetFaction = 0;
}

LoadEMuShareMemDLL::~LoadEMuShareMemDLL() {
	Unload();
}

bool LoadEMuShareMemDLL::Load() {
#ifdef WIN32
	DWORD load_error;
#else
	char* load_error;
#endif
	if (Loaded())
	{
		return true;
	}
	hDLL = LoadLibrary(EmuLibName);
#ifdef WIN32
	if(!hDLL || ((load_error = GetLastError()) != 0) ) {
#else
	if(!hDLL || ((load_error = GetLastError()) != NULL) ) {
#endif
		cerr<<"LoadEMuShareMemDLL::Load() failed error="<<load_error<<endl;
	    return false;
	}
	if (Loaded()) {
		Items.GetItem = (DLLFUNC_GetItem) GetProcAddress(hDLL, "GetItem");
		Items.IterateItems = (DLLFUNC_IterateItems) GetProcAddress(hDLL, "IterateItems");
		Items.cbAddItem = (DLLFUNC_AddItem) GetProcAddress(hDLL, "AddItem");
		Items.DLLLoadItems = (DLLFUNC_DLLLoadItems) GetProcAddress(hDLL, "DLLLoadItems");
		NPCTypes.GetNPCType = (DLLFUNC_GetNPCType) GetProcAddress(hDLL, "GetNPCType");
		NPCTypes.cbAddNPCType = (DLLFUNC_AddNPCType) GetProcAddress(hDLL, "AddNPCType");
		NPCTypes.DLLLoadNPCTypes = (DLLFUNC_DLLLoadNPCTypes) GetProcAddress(hDLL, "DLLLoadNPCTypes");
		Doors.GetDoor = (DLLFUNC_GetDoor) GetProcAddress(hDLL, "GetDoor");
		Doors.cbAddDoor = (DLLFUNC_AddDoor) GetProcAddress(hDLL, "AddDoor");
		Doors.DLLLoadDoors = (DLLFUNC_DLLLoadDoors) GetProcAddress(hDLL, "DLLLoadDoors");
		Spells.DLLLoadSPDat = (DLLFUNC_DLLLoadSPDat) GetProcAddress(hDLL, "DLLLoadSPDat");
		NPCFactionList.DLLLoadNPCFactionLists = (DLLFUNC_DLLLoadNPCFactionLists) GetProcAddress(hDLL, "DLLLoadNPCFactionLists");
		NPCFactionList.GetNPCFactionList = (DLLFUNC_GetNPCFactionList) GetProcAddress(hDLL, "GetNPCFactionList");
		NPCFactionList.cbAddNPCFactionList = (DLLFUNC_AddNPCFactionList) GetProcAddress(hDLL, "AddNPCFactionList");
		NPCFactionList.cbSetFaction = (DLLFUNC_SetFaction) GetProcAddress(hDLL, "SetNPCFaction");
		if ((!Items.GetItem)
			|| (!Items.IterateItems)
			|| (!Items.cbAddItem)
			|| (!Items.DLLLoadItems)
			|| (!NPCTypes.GetNPCType)
			|| (!NPCTypes.cbAddNPCType)
			|| (!NPCTypes.DLLLoadNPCTypes)
			|| (!Doors.GetDoor)
			|| (!Doors.cbAddDoor)
			|| (!Doors.DLLLoadDoors)
			|| (!Spells.DLLLoadSPDat)
			|| (!NPCFactionList.DLLLoadNPCFactionLists)
			|| (!NPCFactionList.GetNPCFactionList)
			|| (!NPCFactionList.cbAddNPCFactionList)
			|| (!NPCFactionList.cbSetFaction)
#ifdef WIN32
			|| ((load_error = GetLastError()) != 0)
#else
			|| ((load_error = GetLastError()) != NULL)
#endif
			) {
			Unload();
			cerr<<"LoadEMuShareMemDLL::Load() failed error="<<load_error<<endl;
			return false;
		}
		cout << "EMuShareMem.dll loaded." << endl;
		return true;
	}
	else {
#ifdef WIN32
		if ((load_error = GetLastError()) != 0)
#else
		if ((load_error = GetLastError()) != NULL)
#endif 
			cout << "LoadLibrary() FAILED! error="<< load_error << endl;
		else
			cout << "LoadLibrary() FAILED! error= Unknown error" << endl;
	}
	return false;
}

void LoadEMuShareMemDLL::Unload() {
	Items.GetItem = 0;
	Items.IterateItems = 0;
	Items.cbAddItem = 0;
	Items.DLLLoadItems = 0;
	NPCTypes.GetNPCType = 0;
	NPCTypes.cbAddNPCType = 0;
	NPCTypes.DLLLoadNPCTypes = 0;
	Doors.GetDoor = 0;
	Doors.cbAddDoor = 0;
	Doors.DLLLoadDoors = 0;
	NPCFactionList.DLLLoadNPCFactionLists = 0;
	NPCFactionList.GetNPCFactionList = 0;
	NPCFactionList.cbAddNPCFactionList = 0;
	NPCFactionList.cbSetFaction = 0;
	if (this->hDLL) {
		FreeLibrary(this->hDLL);
#ifdef WIN32
	DWORD error;
		if ((error = GetLastError()) != 0)
#else
	char* error;
		if ((error = GetLastError()) != NULL)
#endif
			cerr<<"FreeLibrary() error = "<<error<<endl;
	}
	hDLL = 0;
}
