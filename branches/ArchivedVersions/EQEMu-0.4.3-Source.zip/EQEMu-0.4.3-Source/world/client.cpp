#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <sys/socket.h>
#ifdef FREEBSD //Timothy Whitman - January 7, 2003
	#include <sys/types.h>
#endif
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "LoginServer.h"
#include "zoneserver.h"
#include "net.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];
extern ZSList zoneserver_list;
extern LoginServer loginserver;
extern uint32 numclients;
extern NetConnection net;
extern volatile bool RunLoops;

Client::Client(EQNetworkConnection* ieqnc) {
	eqnc = ieqnc;
	eqnc->SetDataRate(7);
	ip = eqnc->GetrIP();
	port = ntohs(eqnc->GetrPort());

	autobootup_timeout = new Timer(10000);
	autobootup_timeout->Disable();
	
	CLE_keepalive_timer = new Timer(15000);
	firstlogin = true;
	seencharsel = false;

	cle = 0;
	zoneID = 0;
	char_name[0] = 0;
	charid = 0;
	pwaitingforbootup = 0;
	numclients++;
}

Client::~Client() {
	if (RunLoops && cle && zoneID == 0)
		cle->SetOnline(CLE_Status_Offline);
	eqnc->Free();
	safe_delete(autobootup_timeout);
	safe_delete(CLE_keepalive_timer);
	numclients--;
}

void Client::SendCharInfo() {
	if (cle)
		cle->SetOnline(CLE_Status_CharSelect);
	seencharsel = true;
	APPLAYER *outapp;
	outapp = new APPLAYER(OP_SendCharInfo, sizeof(CharacterSelect_Struct));
	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(GetAccountID(), cs_struct);

	QueuePacket(outapp);
	delete outapp;
}

bool Client::HandlePacket(const APPLAYER *app) {
#if DEBUG == 9
    cout<<"Client::HandlePacket() ";
    cout << "opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec <<endl;
#endif
	bool ret = true;

	if (!eqnc->CheckActive()) {
		cout << "Client disconnected" << endl;
		return false;
	}

		switch(app->opcode)
		{
		case OP_SendLoginInfo:
		{

			// Quagmire - max len for name is 18, pass 15
			char name[19];
			char password[16];
			memset(name, 0, sizeof(name));
			memset(password, 0, sizeof(password));

			strncpy(name, (char*)app->pBuffer, 18);
			if (app->size < strlen(name)+2) {
				ret = false;
				break;
			}
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 15);

//cerr << "u='" << name << "', p='" << password << "'" << endl;
			if (strncasecmp(name, "LS#", 3) == 0) {
				if (loginserver.Connected() == false) {
					cout << "Error: Login server login while not connected to login server." << endl;
					ret = false;
					break;
				}
				if ((cle = zoneserver_list.CheckAuth(atoi(&name[3]), password))) {
//cout << "Client from LS: id=" << lsa->lsaccount_id << ", n=" << lsa->name << ", k=" << lsa->key << endl;
					if (cle->AccountID() == 0) {
						ret = false;
						break;
					}
					firstlogin = (bool)(cle->Online() == CLE_Status_Never);
					cle->SetOnline();
//					loginserver.RemoveAuth(lsa->lsaccount_id);
//cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << ", k=" << password << endl;
					cout << "Logged in: ";
					if (firstlogin)
						cout << "FirstLogin ";
					cout << "LS#" << cle->LSID() << ": " << cle->LSName() << endl;
				}
				else {
					// TODO: Find out how to tell the client wrong username/password
//cerr << "Bad/expired session key: " << name << ", k=" << password << endl;
					cerr << "Bad/expired session key: " << name << endl;
					ret = false;
					break;
				}
			}
			else if (strlen(password) <= 1) {
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Login without a password" << endl;
				ret = false;
				break;
			}
			else {
				cle = zoneserver_list.CheckAuth(name, password);
//				account_id = database.CheckLogin(name,password);
				if (cle == 0)
				{
					// TODO: Find out how to tell the client wrong username/password
					struct in_addr	in;
					in.s_addr = ip;
					cerr << inet_ntoa(in) << ": Wrong name/pass: name='" << name << "'" << endl;
					ret = false;
					break;
				}
				cout << "Logged in: Local: " << name << endl;
			}
			if (!cle)
				break;
			cle->SetIP(GetIP());

			APPLAYER *outapp;
			outapp = new APPLAYER(0x5941, 0);
			QueuePacket(outapp);
			delete outapp;

	/*		outapp = new APPLAYER(0xc341, 180);
			QueuePacket(outapp);
			delete outapp;*/

			outapp = new APPLAYER(0x0710, 1);
			QueuePacket(outapp);
			delete outapp;
			if(!firstlogin) {
		/*		outapp = new APPLAYER(0xe541, 544);
				QueuePacket(outapp);
				delete outapp;		*/

				APPLAYER *outapp;
				char cname[64];
				if (database.GetLiveChar(GetAccountID(), cname)) {
					cout << "Telling client to continue session with: " << cname << endl;
					outapp = new APPLAYER(OP_EnterWorld, strlen(cname)+1);
					memcpy(outapp->pBuffer,cname,strlen(cname));
					QueuePacket(outapp);
					delete outapp;
				}
				else {
					outapp = new APPLAYER(OP_EnterWorld, 1);
					QueuePacket(outapp);
					delete outapp;
				}

				outapp = new APPLAYER(0x3441,8);
				outapp->pBuffer[0] = 0x01;
				QueuePacket(outapp);
				delete outapp;
			}

			if(firstlogin) {
				outapp = new APPLAYER(OP_EnterWorld, 1);
				QueuePacket(outapp);
				delete outapp;

				// Quagmire - Enabling expansions. Pretty sure this is bitwise
				outapp = new APPLAYER(OP_ExpansionInfo, 4);
				char tmp[4];
				outapp->pBuffer[0] = 15;
				if (database.GetVariable("Expansions", tmp, 3)) {
					outapp->pBuffer[0] = atoi(tmp);
				}
				QueuePacket(outapp);
				delete outapp;
			}

		/*	if (sendguilds) {
cout << "Sending list of guilds" << endl;
				// Quagmire - tring to send list of guilds

			}*/

			// We are logging in and want to see character select

		    break;
		}
		case 0x2340: {
			QueuePacket(app);
			break;
		}
		case OP_GuildsList: {
			SendCharInfo(); // Putting this before hopefully stopping the delay of getting char information
			SendGuildList();
		}
		case 0xe541: {
			break;
		}
		case OP_ApproveName: //Name approval
		{
			if (GetAccountID() == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				ret = false;
				break;
			}
		    char name[64];
			snprintf(name, 64, "%s", (char*)app->pBuffer);
		    uchar race = app->pBuffer[64];
		    uchar clas = app->pBuffer[68];
			
		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = OP_ApproveName;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.CheckNameFilter(name)) {
				outapp->pBuffer[0] = 0;
			}
			else if (database.ReserveName(GetAccountID(), name)) {
				outapp->pBuffer[0] = 1;
			}
			else {
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;
		    break;			
		}
		case OP_CharacterCreate: //Char create
		{
			if (GetAccountID() == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				ret = false;
				break;
			}
			// Quag: This packet seems to be the PlayerProfile struct w/o the space for the checksum at the beginning
			// Scruffy: And some of the end data. *shrug*
			// T7g: But some of the values are messed up now, For example-> in PP face is 162, in CC it's 174...
			if (app->size != sizeof(PlayerProfile_Struct)-8) {
				cout << "Wrong size on OP_CharacterCreate. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) - 8 << endl;
				break;
			}
			// TODO: Sanity check in data
			PlayerProfile_Struct cc;
			memset(&cc, 0, sizeof(PlayerProfile_Struct));
			memcpy((char*) &cc.unknown0004, app->pBuffer, sizeof(PlayerProfile_Struct)-8); //test -8
			//These defines do not exist in PlayerProfile anymore...
			//memset(cc.invitemproperties,0,sizeof(cc.invitemproperties));
			//memset(cc.bagitemproperties,0,sizeof(cc.bagitemproperties));
			//memset(cc.cursorbagitemproperties,0,sizeof(cc.cursorbagitemproperties));
			//memset(cc.bankinvitemproperties,0,sizeof(cc.bankinvitemproperties));
			//memset(cc.bankbagitemproperties,0,sizeof(cc.bankbagitemproperties));
			
			/* Clearing Unknown Variables */
			memset(cc.unknown0004, 0, sizeof(cc.unknown0004));
			cc.unknown0141 = 0;
//			memset(cc.unknown0145, 0, sizeof(cc.unknown0145));
			cc.unknown0147 = 0;
			cc.unknown0149 = 0;
			memset(cc.unknown0150, 0, sizeof(cc.unknown0150));
			memset(cc.unknown0310, 0, sizeof(cc.unknown0310));
			memset(cc.unknown2374, 0, sizeof(cc.unknown2374));
			memset(cc.unknown2920, 0, sizeof(cc.unknown2920));
			memset(cc.unknown2956, 0, sizeof(cc.unknown2956));
			memset(cc.unknown3134, 0, sizeof(cc.unknown3134));
			memset(cc.unknown3448, 0, sizeof(cc.unknown3448));
			memset(cc.unknown3656, 0, sizeof(cc.unknown3656));
			cc.bind_point_zone = cc.current_zone;
			cc.bind_location[0][0] = cc.x;
			cc.bind_location[1][0] = cc.y;
			cc.bind_location[2][0] = cc.z;
			//memset(cc.unknown4736, 0, sizeof(cc.unknown4736));
//			memset(cc.unknown4740, 0, sizeof(cc.unknown4740));
            cc.BirthdayTime = 0; // todo: see how birthtime is coded
            cc.Unknown_4952 = 0;
            cc.TimePlayedMin = 0;
            memset(cc.Unknown_4960, 0, sizeof(cc.Unknown_4960));
            cc.Fatigue = 0;
			cc.unknown4756 = 0;
			cc.unknown4756 = 0;
			//cc.unknown4758 = 0;
			memset(cc.unknown4760, 0, sizeof(cc.unknown4760));
			memset(cc.unknown5225, 0, sizeof(cc.unknown5225));
			/* ************************** */

			//Lyenu - This is the call to add starting items
			database.SetStartingItems(&cc, (int16)cc.race, (int8)cc.class_, (char*)&cc.name, GetAdmin()); 


			//If the player has a 100+ avatar level, flag the character GM automagically.
			if(GetAdmin()>=100) {
				cc.gm=1;
			}

			//If server is PVP by default, make all character set to it.
			if(database.GetServerType() == 1)
				cc.pvp = 1;
			else
				cc.pvp = 0;
	
			// T7g - Face fix, this fixes faces so the face you choose on character creation is the face thats stored in player profile.
			cc.face = app->pBuffer[174];
			// Luclin Eye Color
			cc.eyecolor1 = app->pBuffer[5424];
			cc.eyecolor2 = app->pBuffer[5425];
			// Luclin Hair Type
			cc.hairstyle = app->pBuffer[5426];
			// Luclin Hair Color
			cc.haircolor = app->pBuffer[5422];
			// Luclin Beard Type
			cc.beard_t = app->pBuffer[5427];
			// Luclin Beard Color
			cc.beardcolor = app->pBuffer[5423];


/*		    char name[64];
		    strncpy(name, cc->name, 16);

			int16 gender = cc->gender;
			int16 race = cc->race;
			int16 class_ = cc->class_;
			int8 face = cc->face;
			int8 str = cc->STR;
			int8 sta = cc->STA;
			int8 cha = cc->CHA;
			int8 dex = cc->DEX;
			int8 int_ = cc->INT;
			int8 agi = cc->AGI;
			int8 wis = cc->WIS; // TODO: Find out where deity,face and starting location is located
*/

//			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			if (!database.CreateCharacter(GetAccountID(), &cc))
			{
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp = new APPLAYER(OP_ApproveName, 1);
				outapp->pBuffer[0] = 0;
				QueuePacket(outapp);
				delete outapp;
				ret = false;
				break;
			}

			cout << "Char create:" << cc.name << endl;
			SendCharInfo();

		    break;
		}
		case OP_EnterWorld: // Enter world
		{
			if (GetAccountID() == 0) {
				cerr << "Enter world with no logged in account" << endl;
				eqnc->Close();
				break;
			}
            strncpy(char_name,(char*)app->pBuffer,64);


			APPLAYER *outapp;

			int32 tmpaccid = 0;
			charid = database.GetCharacterInfo(char_name, &tmpaccid, &zoneID);
			if (charid == 0) {
				cerr << "Could not get CharInfo for " << char_name << endl;
				eqnc->Close();
				break;
			}

			// Make sure this account owns this character
			if (tmpaccid != GetAccountID()) {
				cerr << "This account does not own this character" << endl;
				eqnc->Close();
				break;
			}

			if (zoneID == 0 || !database.GetZoneName(zoneID)) {
				// This is to save people in an invalid zone, once it's removed from the DB
				database.MoveCharacterToZone(charid, "arena");
			}

			if(firstlogin) {
				outapp = new APPLAYER(OP_MOTD); // This is message of the day?
				char tmp[500];memset(tmp,0,500);
				if (database.GetVariable("MOTD", tmp, 500)) {
					outapp->size = strlen(tmp)+1;
					outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer,0,outapp->size);
					strcpy((char*)outapp->pBuffer, tmp);
				} else {
					//char DefaultMOTD[] = "Welcome to EQ Emu(tm)!";
					//outapp->size = strlen(DefaultMOTD) + 1;
					//outapp->pBuffer = new uchar[outapp->size];
					//strcpy((char*)outapp->pBuffer, DefaultMOTD);
					// Null Message of the Day. :)
					outapp->size = 1;
					outapp->pBuffer = new uchar[outapp->size];
					outapp->pBuffer[0] = 0;
				}
				QueuePacket(outapp);
				delete outapp;
			}
			firstlogin = false;

			EnterWorld();
			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
				ret = false;
				break;
			}
			SendCharInfo();
			break;
		}
		case 0x3541:
		case 0x3941: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			break;
		}
#if 0
		case 0x7642:{

			cout << "Compressed packet data\n";
			DumpPacket(app);
			cout << "\n";

			z_stream t;
			APPLAYER *tmper,*tmp2;
			tmper = new APPLAYER(0, 1024);

			if (app->pBuffer[0] == 0xff)
			{
				cout << "We found a 0xff\n";
				t.next_in = app->pBuffer + 5;
				t.avail_in = app->size - 5;
			}
			else
			{
				cout << "No 0xff\n";
				t.next_in = app->pBuffer + 3;
				t.avail_in = app->size - 3;
			}

			t.next_out = tmper->pBuffer;
			t.avail_out = tmper->size;
			t.zalloc = (alloc_func)0;
			t.zfree = (free_func)0;
			
			inflateInit(&t);
			inflate(&t, Z_FINISH);

			cout << t.total_out << '\n';

			int16 *intptr   = (int16*) app->pBuffer;

			uint16 OpCode = ntohs(*intptr); 

			tmp2 = new APPLAYER(OpCode, t.total_out);
			memcpy(tmp2->pBuffer, tmper->pBuffer, t.total_out);
			inflateEnd(&t);

			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << tmp2->opcode << dec;
			cout << " size:" << tmp2->size << endl;			
			DumpPacket(tmp2);

			// This will push the packet onto the stack for processing
			HandlePacket(tmp2);
			delete tmp2;
			delete tmper;
#ifdef DEBUG_
			cout << "END DECOMPRESSION\n";
#endif
			break;
		}
#endif
		default: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app);
			break;
		}
		}
	return ret;
}

bool Client::Process() {
	bool ret = true;
	//bool sendguilds = true;
	//bool firstlogin = true;
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;

	if (autobootup_timeout->Check()) {
		ZoneUnavail();
	}

	if (CLE_keepalive_timer->Check()) {
		if (cle)
			cle->KeepAlive();
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(ret && (app = eqnc->PopPacket())) {
		// Is it compressed?
		if ((app->opcode & 0x0080) && app->Inflate())
			app->opcode = htons(app->opcode & ~0x0080);
		ret = HandlePacket(app);
		delete app;
	}    

	if (!eqnc->CheckActive()) {
		cout << "Client disconnected" << endl;
		return false;
	}

	return ret;
}

void Client::EnterWorld(bool TryBootup) {
	//int16 zone_port;
	//char zone_address[255];
	if (zoneID == 0)
		return;

	ZoneServer* zs = zoneserver_list.FindByZoneID(zoneID);
	if (zs) {
		// warn the world we're comming, so it knows not to shutdown
		zs->IncommingClient(this);
	}
	else {
		if (TryBootup) {
			autobootup_timeout->Start();
			cout << "Attempting autobootup of " << database.GetZoneName(zoneID, true) << " (" << zoneID << ") for " << char_name << endl;
			if (!(pwaitingforbootup = zoneserver_list.TriggerBootup(zoneID))) {
				cout << "Error: No zoneserver to bootup " << database.GetZoneName(zoneID, true) << " (" << zoneID << ") for " << char_name << endl;
				ZoneUnavail();
			}
			return;
		}
		else {
			cout << "Error: Player '" << char_name << "' requested zone status for " << database.GetZoneName(zoneID, true) << " (" << zoneID << ") but it's not up." << endl;
			ZoneUnavail();
			return;
		}
	}
	pwaitingforbootup = 0;

	cle->SetChar(charid, char_name);
	database.UpdateLiveChar(char_name, GetAccountID());
	cout << "Enter world: " << char_name << ": " << database.GetZoneName(zoneID, true) << " (" << zoneID << ")" << endl;
//	database.SetAuthentication(account_id, char_name, zone_name, ip);

	if (seencharsel) {
		if (GetAdmin() < 80 && zoneserver_list.IsZoneLocked(zoneID)) {
			ZoneUnavail();
			return;
		}

		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_AcceptWorldEntrance;
		pack->size = sizeof(WorldToZone_Struct);
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, pack->size);
		WorldToZone_Struct* wtz = (WorldToZone_Struct*) pack->pBuffer;
		wtz->account_id = GetAccountID();
		wtz->response = 0;
		zs->SendPacket(pack);
		delete pack;
	}
	else { // if they havent seen character select screen, we can assume this is a zone to zone movement, which should be preauthorized before they leave the previous zone
		Clearance(1);
	}
}

void Client::Clearance(sint8 response)
{
    ZoneServer* zs = zoneserver_list.FindByZoneID(zoneID);

    if(zs == 0 || response == -1 || response == 0)
    {
        if (zs == 0)
        {
            cout << "Unable to find zoneserver in Client::Clearance!!" << endl;
        }

        ZoneUnavail();
        return;
    }

	APPLAYER* outapp;
	/*outapp = new APPLAYER(0x0980,41);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	QueuePacket(outapp);
	delete outapp;*/

	outapp = new APPLAYER(OP_ZoneServerInfo,130); //no memste = BAD -kathgar
    memset(outapp->pBuffer, 0, 130);

	//outapp->opcode = OP_ZoneServerInfo;//0x0480;
	//outapp->pBuffer = new uchar[130];
	//outapp->size = 130;
//	strcpy((char*) outapp->pBuffer,     zone_address);

    if (zs->GetCAddress() == NULL) {
        cout << "Unable to do zs->GetCAddress() in Client::Clearance!!" << endl;
        ZoneUnavail();
        return;    
    }

    if (zoneID == 0) {
        cout << "zoneID is NULL in Client::Clearance!!" << endl;
        ZoneUnavail();
        return;
    }

	const char* zonename = database.GetZoneName(zoneID);
    if (zonename == 0) {
        cout << "zonename is NULL in Client::Clearance!!" << endl;
        ZoneUnavail();
        return;
    }

	strcpy((char*) outapp->pBuffer, zs->GetCAddress());
	strcpy((char*)&outapp->pBuffer[75], zonename);
	/*for(int i=75;i<128;i++)
	{
	outapp->pBuffer[i] = 1;
	}*/
	*((int16*)&outapp->pBuffer[128]) = ntohs(zs->GetCPort());

	QueuePacket(outapp);
	delete outapp;
//	if (cle)
//		cle->SetOnline(CLE_Status_Zoning);
}

void Client::ZoneUnavail() {
	APPLAYER* outapp = new APPLAYER(OP_ZoneUnavail, sizeof(ZoneUnavail_Struct));
	ZoneUnavail_Struct* ua = (ZoneUnavail_Struct*)outapp->pBuffer;
	const char* zonename = database.GetZoneName(zoneID);
	if (zonename)
		strcpy(ua->zonename, zonename);
	QueuePacket(outapp);
	delete outapp;

	zoneID = 0;
	pwaitingforbootup = 0;
	autobootup_timeout->Disable();
}

bool Client::GenPassKey(char* key) {
	char* passKey=NULL;
	*passKey += ((char)('A'+((int)(rand()%26))));
	*passKey += ((char)('A'+((int)(rand()%26))));
	memcpy(key, passKey, strlen(passKey));
	return true;
}

void Client::QueuePacket(const APPLAYER* app, bool ack_req) {
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size > 49156) {
			cout << "WARNING: abnormal packet size. o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	eqnc->QueuePacket(app, ack_req);
}

void Client::SendGuildList() {
	APPLAYER *outapp;
	cout << "Sending list of guilds" << endl;
	outapp = new APPLAYER(OP_GuildsList, sizeof(GuildsList_Struct));
	GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

	for (int i=0; i < 512; i++) {
		gl->Guilds[i].guildID = 0xFFFFFFFF;
		gl->Guilds[i].guildIDx = 0xFFFFFFFF;
		gl->Guilds[i].unknown6[0] = 0xFF;
		gl->Guilds[i].unknown6[1] = 0xFF;
		gl->Guilds[i].unknown6[2] = 0xFF;
		gl->Guilds[i].unknown6[3] = 0xFF;
		gl->Guilds[i].exists = 0;
		gl->Guilds[i].unknown10[0] = 0xFF;
		gl->Guilds[i].unknown10[1] = 0xFF;
		gl->Guilds[i].unknown10[2] = 0xFF;
		gl->Guilds[i].unknown10[3] = 0xFF;
		if (guilds[i].databaseID != 0) {
			gl->Guilds[i].guildID = i;
			gl->Guilds[i].guildIDx = i;
			gl->Guilds[i].unknown4[1] = 0x75;
			gl->Guilds[i].unknown4[2] = 0x5B;
			gl->Guilds[i].unknown4[3] = 0xF6;
			gl->Guilds[i].unknown4[4] = 0x77;
			gl->Guilds[i].unknown4[5] = 0x5C;
			gl->Guilds[i].unknown4[6] = 0xEC;
			gl->Guilds[i].unknown4[7] = 0x12;
			gl->Guilds[i].unknown4[9] = 0xD4;
			gl->Guilds[i].unknown4[10] = 0x2C;
			gl->Guilds[i].unknown4[11] = 0xF9;
			gl->Guilds[i].unknown4[12] = 0x77;
			gl->Guilds[i].unknown4[13] = 0x90;
			gl->Guilds[i].unknown4[14] = 0xD7;
			gl->Guilds[i].unknown4[15] = 0xF9;
			gl->Guilds[i].unknown4[16] = 0x77;
			gl->Guilds[i].regguild[1] = 0xFF;
			gl->Guilds[i].regguild[2] = 0xFF;
			gl->Guilds[i].regguild[3] = 0xFF;
			gl->Guilds[i].regguild[4] = 0xFF;
			gl->Guilds[i].regguild[5] = 0x6C;
			gl->Guilds[i].regguild[6] = 0xEC;
			gl->Guilds[i].regguild[7] = 0x12;
			strcpy(gl->Guilds[i].name, guilds[i].name);
			gl->Guilds[i].exists = 1;
		}
	}
	
	QueuePacket(outapp);
	delete outapp;
}

ClientList::ClientList() {
}

ClientList::~ClientList() {
}

void ClientList::Add(Client* client) {
	list.Insert(client);
}

Client* ClientList::FindByAccountID(int32 account_id) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		LogFile->write(EQEMuLog::Debug, "World: ClientList[0x%08x]::FindByAccountID(0x%08x) iterator.GetData()[0x%08x]", (int32) this, account_id, iterator.GetData());
		if (iterator.GetData()->GetAccountID() == account_id) {
			Client* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			Client* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

void ClientList::Process() {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (!iterator.GetData()->Process()) {
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << iterator.GetData()->GetPort() << endl;
			iterator.RemoveCurrent();
		}
		else
			iterator.Advance();
	}
}

void ClientList::ZoneBootup(ZoneServer* zs) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->WaitingForBootup()) {
			if (iterator.GetData()->GetZoneID() == zs->GetZoneID()) {
				iterator.GetData()->EnterWorld(false);
			}
			else if (iterator.GetData()->WaitingForBootup() == zs->GetID()) {
				iterator.GetData()->ZoneUnavail();
			}
		}
		iterator.Advance();
	}
}

void ClientList::RemoveCLEReferances(ClientListEntry* cle) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->GetCLE() == cle) {
			iterator.GetData()->SetCLE(0);
		}
		iterator.Advance();
	}
}

bool Database::SetStartingItems(PlayerProfile_Struct *cc, int16 si_race, int8 si_class, char* si_name, sint16 GM_FLAG) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	int i = 22;
	MYSQL_RES *result;
	MYSQL_ROW row;
	
	if(GM_FLAG < 100) {
//cout<< "Loading starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 2 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while((row = mysql_fetch_row(result))) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	else {
//cout<< "Loading *GM* starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 0 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while((row = mysql_fetch_row(result))) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
}
