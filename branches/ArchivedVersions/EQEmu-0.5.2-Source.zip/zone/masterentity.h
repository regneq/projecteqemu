//Trumpcard:  EntityLists are composed of multiple list types.  This is the 
//master that includes all types.  When entity.h is required, many of these are as well.

#include "groups.h"
#include "client.h"
#include "object.h"
#include "PlayerCorpse.h"
#include "doors.h"
#include "mob.h"
