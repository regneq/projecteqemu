/*GuildWars� EverQuest Modification by Image (Dominic Micale)
**GuildWars� project began on September 24th, 2003
**Original ideas from GuildWars project which was released Feb of 2003
*/
#include "GuildWars.h"

GuildLocationList location_list;

GuildWars::GuildWars(void)
{
}

GuildWars::~GuildWars(void)
{
}

GuildLocationList::GuildLocationList(void)
{
}

GuildLocationList::~GuildLocationList(void)
{
}

GuildLocation* GuildLocationList::FindLocationByID(int32 locid)
{
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
		return iterator.GetData();
		}
		iterator.Advance();
	}
return 0;
}

void GuildLocationList::AddLocation(GuildLocation* gl)
{
list.Insert(gl);
}

bool GuildLocationList::RemoveLocation(int32 locid)
{
	if (locid == 0)
		return 0;
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetLocationID() == locid)
		{
			iterator.RemoveCurrent();
			return true;
		}
		iterator.Advance();
	}
	return false;
}

void GuildLocationList::ClearLocations()
{
	LinkedListIterator<GuildLocation*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.RemoveCurrent();
		iterator.Advance();
	}
}

GuildLocation::GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild)
{
location_id = locid;
x = xcoord;
y = ycoord;
z = zcoord;
zoneid = zone;
locationtype = type;
guildid = guild;
}

GuildLocation::~GuildLocation()
{
}