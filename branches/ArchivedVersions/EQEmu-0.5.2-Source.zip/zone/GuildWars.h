#include "../common/types.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/database.h"
class GuildWars;
class GuildObjects;
class GuildNPCs;
class GuildLocation;
class GuildLocationList;

class GuildWars
{
public:
	GuildWars(void);
	~GuildWars(void);
protected:
	friend class GuildLocationList;
};

class GuildObjects
{

};

class GuildNPCs
{

};

class GuildLocation
{
public:
	GuildLocation(int32 locid, float xcoord, float ycoord, float zcoord,int32 zone,int8 type,int32 guild);
	~GuildLocation();

	int32	GetLocationID() { return location_id; }
private:
	Timer*	cycle_timer;
	int32	location_id;
	float	x;
	float	y;
	float	z;
	int32	zoneid;
	int8	locationtype;
	int32	guildid;
	LinkedList<GuildNPCs*> guildnpcs;
	LinkedList<GuildObjects*> guildobjects;
};

class GuildLocationList
{
public:
	GuildLocationList(void);
	~GuildLocationList(void);

	bool	RemoveLocation(int32 locid);
	void	AddLocation(GuildLocation* gl);
	void	ClearLocations();

	GuildLocation*	FindLocationByID(int32 locid);
private:
	LinkedList<GuildLocation*> list;
};

#define MAXMEMBERS 20
#define NOGUILDCAPLEVEL 21
#define SETLEVEL 50
#define GAINLEVEL 51