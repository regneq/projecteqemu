#ifndef _CRC16_H
#define _CRC16_H

unsigned long CRC16(const unsigned char *buf, int size, int key);

#endif
