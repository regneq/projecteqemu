#ifndef _EQPROTOCOL_H

#define _EQPROTOCOL_H

#include <string>
#include <vector>
#include <map>
#include <set>
#ifndef WIN32
#include <netinet/in.h>
#endif
#include "EQPacket.h"
#include "EQLoginPacket.h"
#include "EQChatPacket.h"
#include "EQMailPacket.h"
#include "EQZonePacket.h"
#include "EQWorldPacket.h"
#include "Mutex.h"
#include "../common/opcodemgr.h"
#include "../common/misc.h"
#include "../common/Condition.h"

using namespace std;

typedef enum {
	ESTABLISHED,
	CLOSING,
	CLOSED
} EQStreamState;

#define FLAG_COMPRESSED	0x01
#define FLAG_ENCODED	0x04

#define RATEBASE	1048576 // 1 MB
#define DECAYBASE	78642	// RATEBASE/10

#pragma pack(1)
struct SessionRequest {
	uint32 UnknownA;
	uint32 Session;
	uint32 MaxLength;
};

struct SessionResponse {
        uint32 Session;
	uint32 Key;
	uint8 UnknownA;
	uint8 Format;
	uint8 UnknownB;
	uint32 MaxLength;
	uint32 UnknownD;
};

//Deltas are in ms, representing round trip times
struct SessionStats {
/*000*/	uint16 RequestID;
/*002*/	uint32 last_local_delta;
/*006*/	uint32 average_delta;
/*010*/	uint32 low_delta;
/*014*/	uint32 high_delta;
/*018*/	uint32 last_remote_delta;
/*022*/	uint64 packets_sent;
/*030*/	uint64 packets_recieved;
/*038*/
};
	
#pragma pack()

class OpcodeManager;    
extern OpcodeManager *EQNetworkOpcodeManager;

class EQStreamFactory;

typedef enum {
	UnknownStream=0,
	LoginStream,
	WorldStream,
	ZoneStream,
	ChatOrMailStream,
	ChatStream,
	MailStream
} EQStreamType;

class EQStream {
	protected:
		uint32 remote_ip;
		uint16 remote_port;
		uint8 buffer[8192];
		unsigned char *oversize_buffer;
		uint32 oversize_offset,oversize_length;
		uint8 app_opcode_size;
		EQStreamType StreamType;
		bool compressed,encoded;

		//uint32 buffer_len;

		uint32 Session, Key;
		uint16 NextInSeq;
		uint16 NextOutSeq;
		uint32  MaxLen;
		uint16 MaxSends;

		uint8 active_users;	//how many things are actively using this
		Mutex MInUse;

		EQStreamState State;
		Mutex MState;

		uint32 LastPacket;
		Mutex MVarlock;

		EQApplicationPacket* CombinedAppPacket;
		Mutex MCombinedAppPacket;

		long LastSeqSent;
		Mutex MLastSeqSent;
		void SetLastSeqSent(uint32);

		// Ack sequence tracking.
		long MaxAckReceived,NextAckToSend,LastAckSent;
		long GetMaxAckReceived();
		long GetNextAckToSend();
		long GetLastAckSent();
		void SetMaxAckReceived(uint32 seq);
		void SetNextAckToSend(uint32);
		void SetLastAckSent(uint32);

		Mutex MAcks;

		// Packets waiting to be sent
		vector<EQProtocolPacket *> NonSequencedQueue;
		map<uint16, EQProtocolPacket *> SequencedQueue;
		Mutex MOutboundQueue;

		// Packes waiting to be processed
		vector<EQApplicationPacket *> InboundQueue;
		Mutex MInboundQueue;

		static uint16 MaxWindowSize;

		sint32 BytesWritten;

		Mutex MRate;
		sint32 RateThreshold;
		sint32 DecayRate;

#ifdef COLLECTOR
		map<unsigned short,EQProtocolPacket *> PacketQueue;
#endif

		EQStreamFactory *Factory;

		EQApplicationPacket *MakeApplicationPacket(EQProtocolPacket *p);
		EQApplicationPacket *MakeApplicationPacket(const unsigned char *buf, uint32 len);

	public:
		EQStream() { init(); remote_ip = 0; remote_port = 0; State=CLOSED; StreamType=UnknownStream; compressed=true; encoded=false; app_opcode_size=2; }
		EQStream(sockaddr_in addr) { init(); remote_ip=addr.sin_addr.s_addr; remote_port=addr.sin_port; State=CLOSED; StreamType=UnknownStream; compressed=true; encoded=false; app_opcode_size=2; }
		virtual ~EQStream() { RemoveData(); }
		inline void SetFactory(EQStreamFactory *f) { Factory=f; }
		void init();
		void SetMaxLen(uint32 length) { MaxLen=length; }

		void QueuePacket(const EQApplicationPacket *p, bool ack_req=true);
		void FastQueuePacket(EQApplicationPacket **p, bool ack_req=true);
		void FlushCombinedPacket();
		void SendPacket(EQApplicationPacket *p);
		void QueuePacket(EQProtocolPacket *p);
		void SendPacket(EQProtocolPacket *p);
		vector<EQProtocolPacket *> convert(EQApplicationPacket *p);
		void NonSequencedPush(EQProtocolPacket *p);
		void SequencedPush(EQProtocolPacket *p);
		void Write(int eq_fd);

		void WritePacket(int fd,EQProtocolPacket *p);

		uint32 GetKey() { return Key; }
		void SetKey(uint32 k) { Key=k; }
		void SetSession(uint32 s) { Session=s; }
		void SetLastPacketTime(uint32 t) {LastPacket=t;}

		void Process(const unsigned char *data, const uint32 length);
		void ProcessPacket(EQProtocolPacket *p);
		virtual void DispatchPacket(EQApplicationPacket *p) { p->DumpRaw(); }

		void SendSessionResponse();
		void SendSessionRequest();
		void SendDisconnect();
		void SendAck(uint16 seq);
		void SendOutOfOrderAck(uint16 seq);
		void SendSessionStatResponse(SessionStats *Stat);

		bool CheckTimeout(uint32 now, uint32 timeout=30) { return  (LastPacket && (now-LastPacket) > timeout); }
		bool Stale(uint32 now, uint32 timeout=30) { return  (LastPacket && (now-LastPacket) > timeout); }

		void InboundQueuePush(EQApplicationPacket *p);
		EQApplicationPacket *PopPacket(); // InboundQueuePop
		EQApplicationPacket *EQStream::PeekPacket();
		void InboundQueueClear();

		void OutboundQueueClear();
		bool HasOutgoingData();

		void RemoveData() { InboundQueueClear(); OutboundQueueClear(); if (CombinedAppPacket) delete CombinedAppPacket; }

		//
		inline bool IsInUse() { bool flag; MInUse.lock(); flag=(active_users>0); MInUse.unlock(); return flag; }
		inline void PutInUse() { MInUse.lock(); active_users++; MInUse.unlock(); }
		inline void ReleaseFromUse() { MInUse.lock(); if(active_users > 0) active_users--; MInUse.unlock(); }
		
		inline EQStreamState GetState() { EQStreamState s; MState.lock(); s=State; MState.unlock(); return s; }
		inline void SetState(EQStreamState state) { MState.lock(); State=state; MState.unlock(); }

		inline uint32 GetRemoteIP() { return remote_ip; }
		inline uint32 GetrIP() { return remote_ip; }
		inline uint16 GetRemotePort() { return remote_port; }
		inline uint16 GetrPort() { return remote_port; }


		static EQProtocolPacket *Read(int eq_fd, sockaddr_in *from);
		static sint8 CompareSequence(uint16 expected_seq , uint16 seq);

		void Close() { SendDisconnect(); }
		bool CheckActive() { return GetState()==ESTABLISHED; }
		bool CheckClosed() { return GetState()==CLOSED; }
		void SetOpcodeSize(uint8 s) { app_opcode_size = s; }
		void SetStreamType(EQStreamType t);
		inline const EQStreamType GetStreamType() const { return StreamType; }
		static string EQStream::StreamTypeString(EQStreamType t);

		void EQStream::Decay();
		void EQStream::AdjustRates(uint32 average_delta);

#ifdef COLLECTOR
		void ProcessQueue();
		EQProtocolPacket *RemoveQueue(uint16 seq);
#endif
};

#endif
