/* 
	Copyright (C) 2005 Michael S. Finger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "EQMailPacket.h"

using namespace std;

OpcodeManager *MailOpcodeManager=NULL;

EQMailPacket::EQMailPacket(const unsigned char *buf, uint32 len) : EQApplicationPacket(MailOpcodeManager)
{
uint32 offset=0;

	opcode=*buf;
	offset+=1;

	if ((len-offset)>0) {
		pBuffer=new unsigned char[len-offset];
		memcpy(pBuffer,buf+offset,len-offset);
		size=len-offset;
	} else {
		pBuffer=NULL;
		size=0;
	}
	
	emu_opcode = OP_Unknown;
	app_opcode_size=1;
}

EQMailPacket *EQProtocolPacket::MakeMailPacket() const {
	EQMailPacket *res = new EQMailPacket;
	res->pBuffer= new unsigned char[size];
	memcpy(res->pBuffer,pBuffer,size);
	res->opcode=opcode;
	res->size=size;
	res->copyInfo(this);
	return(res);
}
