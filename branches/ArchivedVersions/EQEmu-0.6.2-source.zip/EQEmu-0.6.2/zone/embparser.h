//extends the parser to include perl
//Eglin

#ifndef EMBPARSER_H
#define EMBPARSER_H

#ifdef EMBPERL

#include "client.h"
#include "parser.h"
#include "embperl.h"
#include "features.h"

#include <map>
#include <queue>
using namespace std;

class Seperator;

typedef enum {
	questDefault = 1,
	questByName,
	questTemplate,
	questByID
} questMode;

struct EventRecord {
	QuestEventID event;
	int32 npcid;
	string data;
	NPC* npcmob;
	Mob* mob;
};

class PerlembParser : public Parser
{
protected:
	
	//could prolly get rid of this map now, since I check for the
	//actual subroutine in the quest package as opposed to just seeing
	//if they do not have a quest or the default.
	map<int32, questMode> hasQuests;	//npcid -> questMode
	
	queue<EventRecord> eventQueue;		//for events that happen when perl is in use.
	bool eventQueueProcessing;
	
	void HandleQueue();
	
	Embperl * perl;
	//export a symbol table of sorts
	virtual void map_funs();
public:
	PerlembParser(void);
	~PerlembParser();
	Embperl * getperl(void) { return perl; };
	//todo, consider making the following two methods static (need to check for perl!=null, first, then)
	bool isloaded(const char *packagename) const { return perl->geti(std::string("$").append(packagename).append("::isloaded").c_str()); }
//	bool isdefault(const char *packagename) const { return perl->geti(std::string("$").append(packagename).append("::isdefault").c_str()); }
	void Event(QuestEventID event, int32 npcid, const char * data, NPC* npcmob, Mob* mob);
	int LoadScript(int npcid, const char * zone, Mob* activater=0);
	
	//expose a var to the script (probably parallels addvar))
	//i.e. exportvar("qst1234", "name", "somemob"); 
	//would expose the variable $name='somemob' to the script that handles npc1234
	void ExportVar(const char * pkgprefix, const char * varname, const char * value) const;
	void ExportVar(const char * pkgprefix, const char * varname, int value) const;
	void ExportVar(const char * pkgprefix, const char * varname, unsigned int value) const;
	void ExportVar(const char * pkgprefix, const char * varname, double value) const;
	//I don't escape the strings, so use caution!!
	//Same as export var, except value is not quoted, and is evaluated as perl
	void ExportVarComplex(const char * pkgprefix, const char * varname, const char * value) const;
	
	//get an appropriate namespage/packagename from an npcid
	std::string GetPkgPrefix(int32 npcid, bool defaultOK = true);
	//call the appropriate perl handler. afterwards, parse and dispatch the command queue
	//SendCommands("qst1234", "EVENT_SAY") would trigger sub EVENT_SAY() from the qst1234.pl file
	virtual void SendCommands(const char * pkgprefix, const char *event, int32 npcid, NPC* other, Mob* mob);
	void ReloadQuests();
	
	int	HasQuestFile(int32 npcid);
	
	bool HasQuestSub(int32 npcid, const char *subname);
	
#ifdef EMBPERL_COMMANDS
	void ExecCommand(Client *c, Seperator *sep);
#endif
	
};

#endif //EMBPERL

#endif //EMBPARSER_H
