/*  EQEMu:  Everquest Server Emulator
	Copyright (C) 2001-2005  EQEMu Development Team (http://eqemulator.net)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "../common/eq_packet_structs.h"
#include "masterentity.h"
#include "titles.h"

/*

CREATE TABLE tasks (
	id INT NOT NULL AUTO_INCREMENT,
	id3 INT NOT NULL,
	name VARCHAR(255) NOT NULL,
	desc TEXT NOT NULL,
	reward_item INT NOT NULL,
	PRIMAEY KEY(id)
);

CREATE TABLE task_activites (
	task_id INT NOT NULL,
	activity_id INT NOT NULL,
	name VARCHAR(255) NOT NULL,		#do we need this? could use goal_id to find it.
	type INT NOT NULL,
	goal_count INT NOT NULL,
	goal_id INT NOT NULL,
	PRIMARY KEY(task_id, activity_id)
);

CREATE TABLE task_progress (
	character_id INT NOT NULL,
	task_id INT NOT NULL,
	activity_id INT NOT NULL,
	goal_count INT NOT NULL,
	PRIMARY KEY(character_id, task_id, activity_id)
);

CREATE TABLE task_completion (
	character_id INT NOT NULL,
	task_id INT NOT NULL,
	completed_time INT UNSIGNED NOT NULL,
	PRIMARY KEY(character_id, task_id)
);
	

*/


TaskManager::TaskManager() {
}
	
//load the tasks from the database
bool TaskManager::LoadTasks() {
}

//loads a client's task state
bool TaskManager::LoadClientState(Client *c, ClientTaskState *state) {
}

//Packet building routines
//build all task packets to send to a client during zone in
void TaskManager::MakeAllTaskDescriptions(ClientTaskState *state, EQStream *into) {
	map<uint32, ClientTaskState::TaskProgress>::iterator cur_ct, end_ct;
	map<uint32, Task>::iterator task;
}

//build all task packets for a specific task.
void TaskManager::MakeTaskDescriptions(uint32 task_id, EQStream *into) {
	vector<TaskActivity>::iterator cur_ta,end_ta;
	vector<ClientTaskState::ActivityProgress>::iterator cur_ap, end_ap;
}

//build a task history packet for this client state
EQZonePacket *TaskManager::MakeHistoryPacket(ClientTaskState *state) {
	map<uint32, uint32>::iterator cur_ct, end_ct;
	map<uint32, Task>::iterator task, task_end;
	
	
	cur_ct = state->completed.begin();
	end_ct = state->completed.end();
	task_end = tasks.end();
	for(; cur_ct != end_ct; cur_ct++) {
		task = tasks.find(cur_ct->first);
		if(task == task_end) {
			//unable to find the task in our task list...
			continue;
		}
		
	}
}

EQZonePacket *TitleManager::MakeTitlesPacket(Client *who) {
	EQZonePacket *outapp = NULL;
	vector<TitleEntry>::iterator cur,end;
	vector< vector<TitleEntry>::iterator > avaliable;
	uint32 len;

	cur = titles.begin();
	end = titles.end();
	for(; cur != end; cur++) {
		uint32 v = who->GetSkill(cur->skill_id);
		if(v < cur->skill_value)
			continue;	//not high enough
		avaliable.push_back(cur);
		len += cur->title.length() + 1;
	}

	uint32 count = avaliable.size();
	if(count == 0) {
		//no titles avaliable...
		outapp = new EQZonePacket(OP_Titles,4);
		return(outapp);
	}
	
	uint32 pos = 0;
	uint32 total_len = sizeof(Titles_Struct) + sizeof(TitleEntry_Struct)*count + len;
	outapp = new EQZonePacket(OP_Titles, total_len);
	
	Titles_Struct *header = (Titles_Struct *) outapp->pBuffer;
	header->title_count = count;
	pos += sizeof(Titles_Struct);

	TitleEntry_Struct *e;
	vector< vector<TitleEntry>::iterator >::iterator cura, enda;
	cura = avaliable.begin();
	enda = avaliable.end();
	for(; cura != enda; cura++) {
		//get the current entry
		cur = *cura;
		e = (TitleEntry_Struct *) (outapp->pBuffer + pos);
		
		//fill out the packet
		e->skill_id = cur->skill_id;
		e->skill_value = cur->skill_value;
		len = cur->title.length()+1;
		strncpy(e->title, cur->title.c_str(), len);
		
		//advance our position in the buffer
		pos += sizeof(TitleEntry_Struct) + len;
	}
	return(outapp);
}
	
bool TitleManager::IsValidTitle(Client *for, const char *title) {
	vector<TitleEntry>::iterator cur,end;
	uint32 len;

	cur = titles.begin();
	end = titles.end();
	for(; cur != end; cur++) {
		if(cur->title != title)
			continue;	//not this title.
		uint32 v = who->GetSkill(cur->skill_id);
		if(v < cur->skill_value) {
			return(false);	//requirement not met
		}
		return(true);	//requirement met
	}
	//title not found
	return(false);
}














