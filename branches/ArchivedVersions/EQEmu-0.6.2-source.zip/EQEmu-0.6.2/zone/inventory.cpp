/*  EQEMu:  Everquest Server Emulator
	Copyright (C) 2001-2003  EQEMu Development Team (http://eqemulator.net)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "masterentity.h"
#include "worldserver.h"
#include "net.h"
#include "../common/database.h"
#include "spdat.h"
#include "../common/packet_dump.h"
#include "../common/packet_functions.h"
#include "petitions.h"
#include "../common/serverinfo.h"
#include "../common/ZoneNumbers.h"
#include "../common/moremath.h"
#include "../common/guilds.h"
#include "StringIDs.h"
#include "NpcAI.h"

#ifdef GUILDWARS
#include "../GuildWars/GuildWars.h"
extern GuildWars guildwars;
#endif

#ifdef RAIDADDICTS
#include "RaidAddicts.h"
extern RaidAddicts raidaddicts;
#endif

extern Database database;

// @merth: this needs to be touched up
uint32 Client::NukeItem(uint32 itemnum) {
	if (itemnum == 0)
		return 0;
	uint32 x = 0;
	
	int i;
	for (i=0; i<=29; i++) { // Equipped and personal inventory
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	for (i=251; i<=339; i++) { // Main inventory's and cursor's containers
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	for (i=2000; i<=2015; i++) { // Bank slots
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	for (i=2030; i<=2109; i++) { // Bank's containers
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	for (i=2500; i<=2501; i++) { // Shared bank
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	for (i=2531; i<=2550; i++) { // Shared bank's containers
		if (GetItemIDAt(i) == itemnum || (itemnum == 0xFFFE && GetItemIDAt(i) != INVALID_ID)) {
			DeleteItemInInventory(i, 0, true);
			x++;
		}
	}
	
	return x;
}


bool Client::CheckLoreConflict(const Item_Struct* item) {
	if (!item)
		return false;
	if (!(item->LoreFlag))
		return false;
	
	return (m_inv.HasItem(item->ID) != SLOT_INVALID);
}

void Client::SummonItem(uint32 item_id, sint8 charges, uint32 aug1, uint32 aug2, uint32 aug3, uint32 aug4, uint32 aug5) {
	const Item_Struct* item = database.GetItem(item_id);
	
	if (item == NULL) {
		Message(0, "No such item: %i", item_id);
		return;
	}
	// Checking to see if the Item is lore or not.
	bool foundlore = CheckLoreConflict(item);
	
	// Checking to see if it is a GM only Item or not.
	//bool foundgm = (item->gm && (this->Admin() < 100));
	bool foundgm = false;
	
	if (!foundlore && !foundgm) { // Okay, It isn't LORE, or if it is, it is not in player's inventory.
		ItemInst* inst = ItemInst::Create(item, charges);
		if (inst) {
			// Custom logic for SummonItem
			if ((inst->GetCharges()==0))// && inst->IsStackable())
				inst->SetCharges(1);
			if ((inst->GetCharges()>0))
				inst->SetCharges(inst->GetCharges());
			if (aug1) {
				ItemCommonInst aug(aug1);
				((ItemCommonInst *)inst)->PutAugment(1,aug1);
			}
			if (aug2) {
				ItemCommonInst aug(aug2);
				((ItemCommonInst *)inst)->PutAugment(2,aug2);
			}
			if (aug3) {
				ItemCommonInst aug(aug3);
				((ItemCommonInst *)inst)->PutAugment(3,aug3);
			}
			if (aug4) {
				ItemCommonInst aug(aug4);
				((ItemCommonInst *)inst)->PutAugment(4,aug4);
			}
			if (aug5) {
				ItemCommonInst aug(aug5);
				((ItemCommonInst *)inst)->PutAugment(5,aug5);
			}
			//inst->SetCharges(
			PushItemOnCursor(*inst);
			// Send item packet to user
			SendItemPacket(SLOT_CURSOR, inst, ItemPacketSummonItem);
			safe_delete(inst);
		}
	}
	else { // Item was already in inventory & is a LORE item or was a GM only item.  Give them a message about it.
		if (foundlore){
			Message_StringID(0,PICK_LORE);
			//Message(0, "You already have a %s (%i) in your inventory!", item->Name, item_id);
		}
		else if (foundgm)
			Message(0, "You are not a GM to summon this item");
	}
}

// Drop item from inventory to ground (generally only dropped from SLOT_CURSOR)
void Client::DropItem(sint16 slot_id)
{
	// Take control of item in client inventory
	ItemInst* inst = m_inv.PopItem(slot_id);
	
	if (!inst) {
		// Item doesn't exist in inventory!
		Message(13, "Error: Item not found in slot %i", slot_id);
		return;
	}
	
	// Save client inventory change to database
	if (slot_id==SLOT_CURSOR) {
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		database.SaveCursor(CharacterID(), s, e);
	} else
		database.SaveInventory(CharacterID(), NULL, slot_id);
	if (inst->GetItem()->NoDrop == 0)
	{
		Message(0, "You can't drop a no drop item.");
		return;
	}
	// Package as zone object
	Object* object = new Object(this, inst);
	entity_list.AddObject(object, true);
	object->StartDecay();
	object->Save();
	
	safe_delete(inst);
}

// Drop inst
void Client::DropInst(const ItemInst* inst)
{
	if (!inst) {
		// Item doesn't exist in inventory!
		Message(13, "Error: Item not found");
		return;
	}


	if (inst->GetItem()->NoDrop == 0)
	{
		Message(13, "This item is NODROP. Deleting.");
		return;
	}

	// Package as zone object
	Object* object = new Object(this, inst);
	entity_list.AddObject(object, true);
	object->StartDecay();
	object->Save();
}

// Returns a slot's item ID (returns INVALID_ID if not found)
uint32 Client::GetItemIDAt(sint16 slot_id) {
	const ItemInst* inst = m_inv[slot_id];
	if (inst)
		return inst->GetItem()->ID;
	
	// None found
	return INVALID_ID;
}

// Remove item from inventory
void Client::DeleteItemInInventory(sint16 slot_id, sint8 quantity, bool client_update) {
	#if (EQDEBUG >= 5)
		LogFile->write(EQEMuLog::Debug, "DeleteItemInInventory(%i, %i, %s)", slot_id, quantity, (client_update) ? "true":"false");
	#endif
	
	// Nuke from inventory
	m_inv.DeleteItem(slot_id, quantity);
	
	const ItemInst* inst=NULL;
	if (slot_id==SLOT_CURSOR) {
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		database.SaveCursor(character_id, s, e);
	} else {
		// Save change to database
		inst = m_inv[slot_id];
		database.SaveInventory(character_id, inst, slot_id);
	}
	
	
	if(client_update)
	{
/*
		EQZonePacket *outapp = new EQZonePacket(OP_MoveItem, sizeof(MoveItem_Struct));
		MoveItem_Struct *mi = (MoveItem_Struct *)outapp->pBuffer;
		mi->from_slot = slot_id;
		mi->to_slot = 256;
		mi->number_in_stack = quantity;
		QueuePacket(outapp);
		safe_delete(outapp);
*/
		if (inst && inst->GetCharges()) {
			EQZonePacket* outapp = new EQZonePacket(OP_DeleteItem, sizeof(MoveItem_Struct));
			DeleteItem_Struct* delitem	= (DeleteItem_Struct*)outapp->pBuffer;
			delitem->from_slot			= slot_id;
			delitem->to_slot			= 0xFFFFFFFF;
			delitem->number_in_stack	= 0xFFFFFFFF;
			for(int loop=0;loop<quantity;loop++)
				QueuePacket(outapp);
			safe_delete(outapp);
		}
		else {
			EQZonePacket* outapp = new EQZonePacket(OP_MoveItem, sizeof(MoveItem_Struct));
			MoveItem_Struct* delitem	= (MoveItem_Struct*)outapp->pBuffer;
			delitem->from_slot			= slot_id;
			delitem->to_slot			= 0xFFFFFFFF;
			delitem->number_in_stack	= 0xFFFFFFFF;
			QueuePacket(outapp);
			safe_delete(outapp);
		}
	}
}

// Puts an item into the person's inventory
// Any items already there will be removed from user's inventory
// (Also saves changes back to the database: this may be optimized in the future)
// client_update: Sends packet to client
bool Client::PushItemOnCursor(const ItemInst& inst, bool client_update)
{
	m_inv.PushCursor(inst);
	
	if (client_update && inst) {
		SendItemPacket(SLOT_CURSOR, &inst, ItemPacketSummonItem);
	}
	
	list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
	return database.SaveCursor(CharacterID(), s, e);
}

bool Client::PutItemInInventory(sint16 slot_id, const ItemInst& inst, bool client_update)
{
	m_inv.PutItem(slot_id, inst);
	
	if (client_update && inst) {
		SendItemPacket(slot_id, &inst, ItemPacketSummonItem);
	}
	
	if (slot_id==SLOT_CURSOR) {
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		return database.SaveCursor(this->CharacterID(), s, e);
	} else
		return database.SaveInventory(this->CharacterID(), &inst, slot_id);
}

void Client::PutLootInInventory(sint16 slot_id, const ItemInst &inst, ServerLootItem_Struct** bag_item_data)
{
	m_inv.PutItem(slot_id, inst);
	SendLootItemInPacket(&inst, slot_id);
	if (slot_id==SLOT_CURSOR) {
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		database.SaveCursor(this->CharacterID(), s, e);
	} else
		database.SaveInventory(this->CharacterID(), &inst, slot_id);

	if(bag_item_data)	// bag contents
	{
		sint16 interior_slot;
		// solar: our bag went into slot_id, now let's pack the contents in
		for(int i = 0; i < 10; i++)
		{
			if(bag_item_data[i])
			{
				const ItemInst *bagitem = ItemInst::Create(bag_item_data[i]->item_id, bag_item_data[i]->charges);
				interior_slot = Inventory::CalcSlotId(slot_id, i);
				PutLootInInventory(interior_slot, *bagitem);
			}
		}
	}
	CalcBonuses();
}
bool Client::TryStacking(ItemInst* item, int8 type, bool try_worn, bool try_cursor){
	if(!item || !item->IsStackable() || item->GetCharges()>=20)
		return false;
	sint16 i;
	int32 item_id = item->GetItem()->ID;
	for (i = 22; i <= 29; i++)
	{
		ItemInst* tmp_inst = m_inv.GetItem(i);	
		if(tmp_inst && tmp_inst->GetItem()->ID == item_id && tmp_inst->GetCharges() < ITEM_MAX_STACK){
			MoveItemCharges(*item, i, type);
			CalcBonuses();
			if(item->GetCharges())	// we didn't get them all
				return AutoPutLootInInventory(*item, try_worn, try_cursor, 0);
			return true;
		}
	}
	for (i = 22; i <= 29; i++)
	{
		for (uint8 j = 0; j < 10; j++)
		{
			int16 slotid = Inventory::CalcSlotId(i, j);
			ItemInst* tmp_inst = m_inv.GetItem(slotid);

			if(tmp_inst && tmp_inst->GetItem()->ID == item_id && tmp_inst->GetCharges() < ITEM_MAX_STACK){
				MoveItemCharges(*item, slotid, type);
				CalcBonuses();
				if(item->GetCharges())	// we didn't get them all
					return AutoPutLootInInventory(*item, try_worn, try_cursor, 0);
				return true;
			}
		}
	}
	return false;
}
// Locate an available space in inventory to place an item
// and then put the item there
// The change will be saved to the database
bool Client::AutoPutLootInInventory(ItemInst& inst, bool try_worn, bool try_cursor, ServerLootItem_Struct** bag_item_data)
{
	// #1: Try to auto equip
	if (try_worn && inst.IsEquipable(GetRace(), GetClass()) && inst.GetItem()->Common.ReqLevel<=level)

	{
		for (sint16 i = 0; i < 22; i++)
		{
			if (!m_inv[i])
			{
				if( i == SLOT_PRIMARY && inst.IsWeapon() ) // If item is primary slot weapon
				{
					if( (inst.GetItem()->Common.ItemType == ItemType2HS) || (inst.GetItem()->Common.ItemType == ItemType2HB) || (inst.GetItem()->Common.ItemType == ItemType2HPierce) ) // and uses 2hs \ 2hb \ 2hp
					{
						if( m_inv[SLOT_SECONDARY] ) // and if secondary slot is not empty
						{
							continue; // Can't auto-equip
						}
					}
				}
				if( i== SLOT_SECONDARY && m_inv[SLOT_PRIMARY]) // check to see if primary slot is a two hander
				{
					int8 use = m_inv[SLOT_PRIMARY]->GetItem()->Common.ItemType;
					if(use == ItemType2HS || use == ItemType2HB || use == ItemType2HPierce)
						continue;
				}
				if
				(
					i == SLOT_SECONDARY &&
					inst.IsWeapon() &&
					!CanThisClassDualWield()
				)
				{
					continue;
				}

				if (inst.IsEquipable(i))	// Equippable at this slot?
				{
					PutLootInInventory(i, inst);
					return true;
				}
			}
		}
	}
		
	// #2: Stackable item?
	if (inst.IsStackable())
	{
		if(TryStacking(&inst, ItemPacketTrade, try_worn, try_cursor))
			return true;
	}

	// #3: put it in inventory
	sint16 slot_id = m_inv.FindFreeSlot(inst.IsType(ItemClassContainer), try_cursor, inst.GetItem()->Size);
	if (slot_id != SLOT_INVALID)
	{
		PutLootInInventory(slot_id, inst, bag_item_data);
		return true;
	}
	
	return false;
}

// solar: helper function for AutoPutLootInInventory
void Client::MoveItemCharges(ItemInst &from, sint16 to_slot, int8 type)
{
	ItemInst *tmp_inst = m_inv.GetItem(to_slot);

	if(tmp_inst && tmp_inst->GetCharges() < ITEM_MAX_STACK)
	{
		// this is how much room is left on the item we're stacking onto
		int charge_slots_left = ITEM_MAX_STACK - tmp_inst->GetCharges();
		// this is how many charges we can move from the looted item to
		// the item in the inventory
		int charges_to_move =
			from.GetCharges() < charge_slots_left ?
				from.GetCharges() :
				charge_slots_left;

		tmp_inst->SetCharges(tmp_inst->GetCharges() + charges_to_move);
		from.SetCharges(from.GetCharges() - charges_to_move);
		SendLootItemInPacket(tmp_inst, to_slot);
		if (to_slot==SLOT_CURSOR){
			list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
			database.SaveCursor(this->CharacterID(), s, e);
		} else
			database.SaveInventory(this->CharacterID(), tmp_inst, to_slot);
	}
}


void Client::SendItemLink(const ItemInst* inst, bool send_to_all)
{
/*

this stuff is old, live dosent do this anymore. they send a much smaller
packet with the item number in it, but I cant seem to find it right now

*/
	if (!inst)
		return;
	
	const Item_Struct* item = inst->GetItem();
	const char* name2 = &item->Name[0];
	EQZonePacket* outapp = new EQZonePacket(OP_ItemLinkText,strlen(name2)+68);
	char buffer2[135] = {0};
	char itemlink[135] = {0};
	sprintf(itemlink,"%c0%06u0%05u-%05u-%05u-%05u-%05u00000000%c",
		0x12,
		item->ID,
		inst->GetAugmentItemID(0),
		inst->GetAugmentItemID(1),
		inst->GetAugmentItemID(2),
		inst->GetAugmentItemID(3),
		inst->GetAugmentItemID(4),
		0x12);
	sprintf(buffer2,"%c%c%c%c%c%c%c%c%c%c%c%c%s",0x00,0x00,0x00,0x00,0xD3,0x01,0x00,0x00,0x1E,0x01,0x00,0x00,itemlink);
	memcpy(outapp->pBuffer,buffer2,outapp->size);
	QueuePacket(outapp);
	safe_delete(outapp);
	if (send_to_all==false)
		return;
	const char* charname = this->GetName();
	outapp = new EQZonePacket(OP_ItemLinkText,strlen(itemlink)+14+strlen(charname));
	char buffer3[150] = {0};
	sprintf(buffer3,"%c%c%c%c%c%c%c%c%c%c%c%c%6s%c%s",0x00,0x00,0x00,0x00,0xD2,0x01,0x00,0x00,0x00,0x00,0x00,0x00,charname,0x00,itemlink);
	memcpy(outapp->pBuffer,buffer3,outapp->size);
	entity_list.QueueCloseClients(this->CastToMob(),outapp,true,200,0,false);
	safe_delete(outapp);
}

void Client::SendLootItemInPacket(const ItemInst* inst, sint16 slot_id)
{
	SendItemPacket(slot_id,inst, ItemPacketTrade);
}

// Moves items around both internally and in the database
// In the future, this can be optimized by pushing all changes through one database REPLACE call
bool Client::SwapItem(MoveItem_Struct* move_in) {
	if (move_in->from_slot == move_in->to_slot)
		return true; // Item summon, no further proccessing needed
	
	if (move_in->to_slot == (uint32)SLOT_INVALID) {
		DeleteItemInInventory(move_in->from_slot);
		return true; // Item deletetion
	}
	if(auto_attack && (move_in->from_slot == SLOT_PRIMARY || move_in->from_slot == SLOT_SECONDARY || move_in->from_slot == SLOT_RANGE))
		SetAttackTimer();
	else if(auto_attack && (move_in->to_slot == SLOT_PRIMARY || move_in->to_slot == SLOT_SECONDARY || move_in->to_slot == SLOT_RANGE))
		SetAttackTimer();
	// Step 1: Variables
	sint16 src_slot_id = (sint16)move_in->from_slot;
	sint16 dst_slot_id = (sint16)move_in->to_slot;
	
	if (shield_target && (move_in->from_slot == 14 || move_in->to_slot == 14))
	{
		entity_list.MessageClose(this,false,100,0,"%s ceases shielding %s.",GetName(),shield_target->GetName());
		for (int y = 0; y < 2; y++)
		{
			if (shield_target->shielder[y].shielder_id == GetID())
			{
				shield_target->shielder[y].shielder_id = 0;
				shield_target->shielder[y].shielder_bonus = 0;
			}
		}
	}
	
	//Setup
	uint32 srcitemid = 0;
	uint32 dstitemid = 0;
	ItemInst* src_inst = m_inv.GetItem(src_slot_id);
	ItemInst* dst_inst = m_inv.GetItem(dst_slot_id);
	if (src_inst){
		srcitemid = src_inst->GetItem()->ID;
		SetTint(dst_slot_id,src_inst->GetColor());
		if (src_inst->GetCharges() > 0 && (src_inst->GetCharges() < (sint16)move_in->number_in_stack || move_in->number_in_stack > 20))
		{
			Message(13,"Error: Insufficent number in stack.");
			return false;
		}
	}
	if (dst_inst) {
		dstitemid = dst_inst->GetItem()->ID;
	}
	if (Trader && srcitemid>0){
		ItemInst* srcbag;
		uint32 srcbagid =0;
		if (src_slot_id>=250 && src_slot_id<330){
			srcbag=m_inv.GetItem(((int)(src_slot_id/10))-3);
			if(srcbag)
				srcbagid=srcbag->GetItem()->ID;
		}
		
		if (srcitemid==17899 || srcbagid==17899){
			this->Trader_EndTrader();
			this->Message(15,"You cannot move items while trading!");
		}
	}
	
	// Step 2: Validate item in from_slot
	// After this, we can assume src_inst is a valid ptr
	if (!src_inst && (src_slot_id<4000 || src_slot_id>4009) ) {
		Message(13, "Error: Server found no item in slot %i (->%i), Deleting Item!", src_slot_id, dst_slot_id);
		LogFile->write(EQEMuLog::Debug, "Error: Server found no item in slot %i (->%i), Deleting Item!", src_slot_id, dst_slot_id);
		this->DeleteItemInInventory(dst_slot_id,0,true);
		return false;
	}
	//verify shared bank transactions in the database
	if(src_inst && src_slot_id >= 2500 && src_slot_id <= 2550) {
		if(!database.VerifyInventory(account_id, src_slot_id, src_inst)) {
			LogFile->write(EQEMuLog::Error, "Player %s on account %s was found exploting the shared bank. They have been banned until further review.\n", account_name, GetName());
			DeleteItemInInventory(dst_slot_id,0,true);
			return(false);
		}
	}
	
	// Step 3: Check for interaction with World Container (tradeskills)
	if(m_tradeskill_object != NULL) {
		if (src_slot_id>=4000 && src_slot_id<=4009) {
			// Picking up item from world container
			ItemInst* inst = m_tradeskill_object->PopItem(Inventory::CalcBagIdx(src_slot_id));
			if (inst) {
				PutItemInInventory(dst_slot_id, *inst, false);
				safe_delete(inst);
			}
			
			return true;
		}
		else if (dst_slot_id>=4000 && dst_slot_id<=4009) {
			// Putting item into world container, which may swap (or pile onto) with existing item
			uint8 world_idx = Inventory::CalcBagIdx(dst_slot_id);
			ItemInst* world_inst = m_tradeskill_object->PopItem(world_idx);
			
			// Case 1: No item in container, unidirectional "Put"
			if (world_inst == NULL) {
				m_tradeskill_object->PutItem(world_idx, src_inst);
				m_inv.DeleteItem(src_slot_id);
			}
			else {
				const Item_Struct* world_item = world_inst->GetItem();
				const Item_Struct* src_item = src_inst->GetItem();
				if (world_item && (int32)world_item!=0xFEEEFEEE && src_item) {
					// Case 2: Same item on cursor, stacks, transfer of charges needed
					if ((world_item->ID == src_item->ID) && src_inst->IsStackable()) {
						sint8 world_charges = world_inst->GetCharges();
						sint8 src_charges = src_inst->GetCharges();
						
						// Fill up destination stack as much as possible
						world_charges += src_charges;
						if (world_charges > ITEM_MAX_STACK) {
							src_charges = world_charges - ITEM_MAX_STACK;
							world_charges = ITEM_MAX_STACK;
						}
						else {
							src_charges = 0;
						}
						
						world_inst->SetCharges(world_charges);
						m_tradeskill_object->Save();
						
						if (src_charges == 0) {
							m_inv.DeleteItem(src_slot_id); // DB remove will occur below
						}
						else {
							src_inst->SetCharges(src_charges);
						}
					}
					else {
						// Case 3: Swap the item on user with item in world container
						// World containers don't follow normal rules for swapping
						ItemInst* inv_inst = m_inv.PopItem(src_slot_id);
						m_tradeskill_object->PutItem(world_idx, inv_inst);
						m_inv.PutItem(src_slot_id, *world_inst);
						safe_delete(inv_inst);
					}
				}
			}
			
			safe_delete(world_inst);
			if (src_slot_id==SLOT_CURSOR) {
				list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
				database.SaveCursor(character_id, s, e);
			} else
				database.SaveInventory(character_id, m_inv[src_slot_id], src_slot_id);
			return true;
		}
	}
	
	// Step 4: Check for entity trade
	Mob* with = trade->With();
	if (with && dst_slot_id>=3000 && dst_slot_id<=3007) {

#if EQDEBUG>=5
			LogFile->write(EQEMuLog::Debug, "Trade: %s adding item(s) to trade session with %s", GetName(), with->GetName());
#endif		
		// Fill Trade list with items from cursor
		if (!m_inv[SLOT_CURSOR]) {
			Message(13, "Error: Cursor item not located on server!");
			return false;
		}
		if (with->IsClient() && src_inst->GetItem()->NoDrop == 0) {
			Message(13, "This item is NODROP.");
			return false;
		}
		
		// Add cursor item to trade bucket
		// Also sends trade information to other client of trade session
		trade->AddEntity(src_slot_id, dst_slot_id);
		return true;
	}
	
	// Step 5: Swap (or stack) items
	if (move_in->number_in_stack > 0) {
		// Determine if charged items can stack
		if ((dst_inst) && (src_inst->GetItem()==dst_inst->GetItem()) && (dst_inst->GetCharges() < 20)) {
			// Charges can be emptied into dst
			uint8 usedcharges = 20 - dst_inst->GetCharges();
			if (usedcharges > move_in->number_in_stack)
				usedcharges = move_in->number_in_stack;
			
			dst_inst->SetCharges(dst_inst->GetCharges() + usedcharges);
			src_inst->SetCharges(src_inst->GetCharges() - usedcharges);
			
			// Depleted all charges?
			if (src_inst->GetCharges() < 1)
			{
				database.SaveInventory(CharacterID(),NULL,src_slot_id);
				m_inv.DeleteItem(src_slot_id);
			}
		}
		else {
			// Nothing in destination slot: split stack into two
			if ((sint16)move_in->number_in_stack >= src_inst->GetCharges()) {
				// Move entire stack
				m_inv.SwapItem(src_slot_id, dst_slot_id);
			}
			else {
				// Split into two
				src_inst->SetCharges(src_inst->GetCharges() - move_in->number_in_stack);
				ItemInst* inst = ItemInst::Create(src_inst->GetItem(), move_in->number_in_stack);
				m_inv.PutItem(dst_slot_id, *inst);
				safe_delete(inst);
			}
		}
	}
	else {
		// Not dealing with charges - just do direct swap
		if(src_inst && dst_slot_id<22 && dst_slot_id>0)
			SetMaterial(dst_slot_id,src_inst->GetItem()->ID);
		m_inv.SwapItem(src_slot_id, dst_slot_id);
	}
	
	int matslot = SlotConvert2(dst_slot_id);
	if (dst_slot_id<22 && matslot != 0) {
		SendWearChange(matslot);
	}
	
	// Step 7: Save change to the database
	if (src_slot_id==SLOT_CURSOR){ 
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		database.SaveCursor(character_id, s, e);
	} else
		database.SaveInventory(character_id, m_inv.GetItem(src_slot_id), src_slot_id);
	if (dst_slot_id==SLOT_CURSOR) {
		list<ItemInst*>::const_iterator s=m_inv.cursor_begin(),e=m_inv.cursor_end();
		database.SaveCursor(character_id, s, e);
	} else
		database.SaveInventory(character_id, m_inv.GetItem(dst_slot_id), dst_slot_id);
	
	// Step 8: Re-calc stats
	CalcBonuses();
	return true;
}

void Client::DyeArmor(DyeStruct* dye){
	sint16 slot=0;
	for(int i=0;i<7;i++){
		if(m_pp.item_tint[i].rgb.blue!=dye->dye[i].rgb.blue ||
			m_pp.item_tint[i].rgb.red!=dye->dye[i].rgb.red ||
			m_pp.item_tint[i].rgb.green != dye->dye[i].rgb.green){
			slot = m_inv.HasItem(32557, 1, invWherePersonal);
			if(slot != SLOT_INVALID){
				DeleteItemInInventory(slot,1,true);
				int8 slot2=SlotConvert(i);
				ItemInst* inst = this->m_inv.GetItem(slot2);
				if(inst){
					inst->SetColor((dye->dye[i].rgb.red*65536)+(dye->dye[i].rgb.green*256)+(dye->dye[i].rgb.blue));
					database.SaveInventory(CharacterID(),inst,slot2);
					m_pp.item_tint[i].rgb.use_tint = 1;
				}
				m_pp.item_tint[i].rgb.blue=dye->dye[i].rgb.blue;
				m_pp.item_tint[i].rgb.red=dye->dye[i].rgb.red;
				m_pp.item_tint[i].rgb.green=dye->dye[i].rgb.green;
				SendWearChange(i);
			}
			else{
				Message(13,"Could not locate A Vial of Prismatic Dye.");
				return;
			}
		}
	}
	EQZonePacket* outapp=new EQZonePacket(OP_Dye,0);
	QueuePacket(outapp);
	safe_delete(outapp);
	Save();
}

/*bool Client::DecreaseByItemType(int32 type, int8 amt) {
	const Item_Struct* TempItem = 0;
	ItemInst* ins;
	int x;
	for(x=0; x <= 30; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if (ins)
			TempItem = ins->GetItem();
		if (TempItem && TempItem->Common.ItemType == type)
		{
			if (ins->GetCharges() < amt)
			{
				amt -= ins->GetCharges();
				DeleteItemInInventory(x,amt,true);
			}
			else
			{
				DeleteItemInInventory(x,amt,true);
				amt = 0;
			}
			if (amt < 1)
				return true;
		}
	}
	for(x=251; x < 331; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if (ins)
			TempItem = ins->GetItem();
		if (TempItem && TempItem->Common.ItemType == type)
		{
			if (ins->GetCharges() < amt)
			{
				amt -= ins->GetCharges();
				DeleteItemInInventory(x,amt,true);
			}
			else
			{
				DeleteItemInInventory(x,amt,true);
				amt = 0;
			}
			if (amt < 1)
				return true;
		}
	}
	return false;
}*/

bool Client::DecreaseByID(int32 type, int8 amt) {
	const Item_Struct* TempItem = 0;
	ItemInst* ins;
	int x;
	int num = 0;
	for(x=0; x < 331; x++)
	{
		if (x == 31)
			x = 251;
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if (ins)
			TempItem = ins->GetItem();
		if (TempItem && TempItem->ID == type)
		{
			num += ins->GetCharges();
			if (num >= amt)
				break;
		}
	}
	if (num < amt)
		return false;
	for(x=0; x < 331; x++)
	{
		if (x == 31)
			x = 251;
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if (ins)
			TempItem = ins->GetItem();
		if (TempItem && TempItem->ID == type)
		{
			if (ins->GetCharges() < amt)
			{
				amt -= ins->GetCharges();
				DeleteItemInInventory(x,amt,true);
			}
			else
			{
				DeleteItemInInventory(x,amt,true);
				amt = 0;
			}
			if (amt < 1)
				break;
		}
	}
	return true;
}


void Client::RemoveNoRent() {
	const Item_Struct* TempItem = 0;
	ItemInst* ins;
	int x;
	
	//personal inventory
	for(x=0; x <= 30; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
	
	//containers
	for(x=251; x <= 330; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
	for(x=2000; x <= 2015; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
	for(x=2031; x <= 2190; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
	for(x=2500; x <= 2501; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
	for(x=2531; x <= 2550; x++)
	{
		TempItem = 0;
		ins = GetInv().GetItem(x);
		if(!ins)
			continue;
		TempItem = ins->GetItem();
		if(!TempItem)
			continue;
		if(TempItem->NoRent == 0)
			DeleteItemInInventory(x,0,true);
	}
}

// these functions operate with a material slot, which is from 0 to 8
sint32 Client::GetEquipment(int8 material_slot)
{
	int invslot;
	const ItemInst *item;

	if(material_slot > 8)
	{
		return -1;
	}

	invslot = Inventory::CalcSlotFromMaterial(material_slot);
	if(invslot == -1)
	{
		return -1;
	}
	
	item = m_inv.GetItem(invslot);

	if(item != 0)
	{
		return item->GetItem()->ID;
	}

	return -1;
}

/*
sint32 Client::GetEquipmentMaterial(int8 material_slot)
{
	const Item_Struct *item;
	
	item = database.GetItem(GetEquipment(material_slot));
	if(item != 0)
	{
		return item->Common.Material;
	}

	return 0;
}
*/

sint32 Client::GetEquipmentColor(int8 material_slot)
{
	const Item_Struct *item;

	if(material_slot > 8)
	{
		return -1;
	}

	item = database.GetItem(GetEquipment(material_slot));
	if(item != 0)
	{
		return m_pp.item_tint[material_slot].rgb.use_tint ?
			m_pp.item_tint[material_slot].color :
			item->Common.Color;
	}

	return 0;
}

bool Client::LootToStack(int32 itemid) {  //Loots stackable items to existing stacks - Wiz
	// @merth: Need to do loot code with new inventory struct
	/*
	const Item_Struct* item;
	int i;
	for (i=22; i<=29; i++) {
		item = GetItemAt(i);
		if (item) {
			if (m_pp.invitemproperties[i].charges < 20 && item->ID == itemid)
			{
				m_pp.invitemproperties[i].charges += 1;
				EQZonePacket* outapp = new EQZonePacket(OP_PlaceItem, sizeof(Item_Struct));
				memcpy(outapp->pBuffer, item, outapp->size);
				Item_Struct* outitem = (Item_Struct*) outapp->pBuffer;
				outitem->equipSlot = i;
				outitem->common.charges = m_pp.invitemproperties[i].charges;
				QueuePacket(outapp);
				safe_delete(outapp);
				return true;
			}
		}
	}
	for (i=0; i<=pp_containerinv_size; i++) {
		if (m_pp.containerinv[i] != 0xFFFF) {
			item = database.GetItem(m_pp.containerinv[i]);
			if (m_pp.bagitemproperties[i].charges < 20 && item->ID == itemid)
			{
				m_pp.bagitemproperties[i].charges += 1;

				EQZonePacket* outapp = new EQZonePacket(OP_PlaceItem, sizeof(Item_Struct));
				memcpy(outapp->pBuffer, item, outapp->size);
				Item_Struct* outitem = (Item_Struct*) outapp->pBuffer;
				outitem->equipSlot = 250+i;
				outitem->common.charges = m_pp.bagitemproperties[i].charges;
				QueuePacket(outapp);
				safe_delete(outapp);
				return true;
			}
		}
	}
	*/
	return false;
}

// Send an item packet (including all subitems of the item)
void Client::SendItemPacket(sint16 slot_id, const ItemInst* inst, ItemPacketType packet_type)
{
	if (!inst)
		return;
	
	// Serialize item into |-delimited string
	string packet = inst->Serialize(slot_id);
	
	EmuOpcode opcode = OP_Unknown;
	EQZonePacket* outapp = NULL;
	ItemPacket_Struct* itempacket = NULL;
	
	// Construct packet
	opcode = (packet_type==ItemPacketViewLink) ? OP_ItemLinkResponse : OP_ItemPacket;
	outapp = new EQZonePacket(opcode, packet.length()+sizeof(ItemPacket_Struct));
	itempacket = (ItemPacket_Struct*)outapp->pBuffer;
	memcpy(itempacket->SerializedItem, packet.c_str(), packet.length());
	itempacket->PacketType = packet_type;
	
#if EQDEBUG >= 9
		DumpPacket(outapp);
#endif
	//DumpPacket(outapp);
	FastQueuePacket(&outapp);
}

EQZonePacket* Client::ReturnItemPacket(sint16 slot_id, const ItemInst* inst, ItemPacketType packet_type)
{
	if (!inst)
		return 0;
	
	// Serialize item into |-delimited string
	string packet = inst->Serialize(slot_id);
	
	EmuOpcode opcode = OP_Unknown;
	EQZonePacket* outapp = NULL;
	BulkItemPacket_Struct* itempacket = NULL;
	
	// Construct packet
	opcode = OP_ItemPacket;
	outapp = new EQZonePacket(opcode, packet.length()+1);
	itempacket = (BulkItemPacket_Struct*)outapp->pBuffer;
	memcpy(itempacket->SerializedItem, packet.c_str(), packet.length());

#if EQDEBUG >= 9
		DumpPacket(outapp);
#endif

	return outapp;
}


