/*  EQEMu:  Everquest Server Emulator
	Copyright (C) 2001-2003  EQEMu Development Team (http://eqemulator.net)
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; version 2 of the License.
	
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	
	client_packet.cpp:
	Handles client login sequence and packets sent from client to zone
*/
#include "../common/debug.h"
#include <iostream>
#include <iomanip>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <zlib.h>
#include <assert.h>

#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <unistd.h>
#endif

#include "masterentity.h"
#include "../common/database.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
#include "worldserver.h"
#include "../common/rdtsc.h"
#include "../common/packet_dump_file.h"
#include "../common/MiscFunctions.h"
#include "spdat.h"
#include "petitions.h"
#include "NpcAI.h"
#include "../common/skills.h"
#include "forage.h"
#include "zone.h"
#include "event_codes.h"
#include "faction.h"
#include "../common/crc32.h"
#include "StringIDs.h"
#include "map.h"
#include "titles.h"
#include "pets.h"
using namespace std;

#ifdef GUILDWARS
#include "../GuildWars/GuildWars.h"
extern GuildWars guildwars;
extern GuildLocationList location_list;
extern int32 numclients;
#endif

#ifdef RAIDADDICTS
#include "RaidAddicts.h"
extern RaidAddicts raidaddicts;
#endif

extern Database database;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern GuildRanks_Struct guilds[512];
#ifndef NEW_LoadSPDat
	extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
#endif
extern bool spells_loaded;
extern PetitionList petition_list;
extern EntityList entity_list;

typedef void (Client::*ClientPacketProc)(const EQZonePacket *app);

//Use a map for connecting opcodes since it dosent get used a lot and is sparse
map<uint32, ClientPacketProc> ConnectingOpcodes;
//Use a static array for connected, for speed
ClientPacketProc ConnectedOpcodes[_maxEmuOpcode];

void MapOpcodes() {
	ConnectingOpcodes.clear();
	memset(ConnectedOpcodes, 0, sizeof(ConnectedOpcodes));
	
	//Now put all the opcodes into their home...
	//Begin Connecting opcodes:
//	ConnectingOpcodes[OP_SetDataRate] = &Client::Handle_Connect_OP_SetDataRate;
	ConnectingOpcodes[OP_ZoneEntry] = &Client::Handle_Connect_OP_ZoneEntry;
	ConnectingOpcodes[OP_SetServerFilter] = &Client::Handle_Connect_OP_SetServerFilter;
	ConnectingOpcodes[OP_SendAATable] = &Client::Handle_Connect_OP_SendAATable;
	ConnectingOpcodes[OP_ReqClientSpawn] = &Client::Handle_Connect_OP_ReqClientSpawn;
	ConnectingOpcodes[OP_SendExpZonein] = &Client::Handle_Connect_OP_SendExpZonein;
	ConnectingOpcodes[OP_ZoneComplete] = &Client::Handle_Connect_OP_ZoneComplete;
	ConnectingOpcodes[OP_ReqNewZone] = &Client::Handle_Connect_OP_ReqNewZone;
	ConnectingOpcodes[OP_SpawnAppearance] = &Client::Handle_Connect_OP_SpawnAppearance;
	ConnectingOpcodes[OP_WearChange] = &Client::Handle_Connect_OP_WearChange;
	ConnectingOpcodes[OP_ClientUpdate] = &Client::Handle_Connect_OP_ClientUpdate;
	ConnectingOpcodes[OP_ClientError] = &Client::Handle_Connect_OP_ClientError;
	ConnectingOpcodes[OP_ApproveZone] = &Client::Handle_Connect_OP_ApproveZone;
	ConnectingOpcodes[OP_TGB] = &Client::Handle_Connect_OP_TGB;
	ConnectingOpcodes[OP_SendTributes] = &Client::Handle_Connect_OP_SendTributes;
	ConnectingOpcodes[OP_SendGuildTributes] = &Client::Handle_Connect_OP_SendGuildTributes;
	ConnectingOpcodes[OP_SendGuildTributes] = &Client::Handle_Connect_OP_SendGuildTributes;
	ConnectingOpcodes[OP_SendAAStats] = &Client::Handle_Connect_OP_SendAAStats;
	ConnectingOpcodes[OP_ClientReady] = &Client::Handle_Connect_OP_ClientReady;
//temporary hack:
	ConnectingOpcodes[OP_GetGuildsList] = &Client::Handle_OP_GetGuildsList;

	//Begin Connected opcodes:
	ConnectedOpcodes[OP_ClientUpdate] = &Client::Handle_OP_ClientUpdate;
	ConnectedOpcodes[OP_AutoAttack] = &Client::Handle_OP_AutoAttack;
	ConnectedOpcodes[OP_AutoAttack2] = &Client::Handle_OP_AutoAttack2;
	ConnectedOpcodes[OP_Consent] = &Client::Handle_OP_Consent;
	ConnectedOpcodes[OP_ConsentDeny] = &Client::Handle_OP_ConsentDeny;
	ConnectedOpcodes[OP_TargetMouse] = &Client::Handle_OP_TargetMouse;
	ConnectedOpcodes[OP_TargetCommand] = &Client::Handle_OP_TargetCommand;
	ConnectedOpcodes[OP_Shielding] = &Client::Handle_OP_Shielding;
	ConnectedOpcodes[OP_Jump] = &Client::Handle_OP_Jump;
	ConnectedOpcodes[OP_AdventureInfoRequest] = &Client::Handle_OP_AdventureInfoRequest;
	ConnectedOpcodes[OP_AdventureRequest] = &Client::Handle_OP_AdventureRequest;
	ConnectedOpcodes[OP_LDoNButton] = &Client::Handle_OP_LDoNButton;
	ConnectedOpcodes[OP_LeaveAdventure] = &Client::Handle_OP_LeaveAdventure;
	ConnectedOpcodes[OP_Consume] = &Client::Handle_OP_Consume;
	ConnectedOpcodes[OP_AdventureMerchantRequest] = &Client::Handle_OP_AdventureMerchantRequest;
	ConnectedOpcodes[OP_AdventureMerchantPurchase] = &Client::Handle_OP_AdventureMerchantPurchase;
	ConnectedOpcodes[OP_ConsiderCorpse] = &Client::Handle_OP_ConsiderCorpse;
	ConnectedOpcodes[OP_Consider] = &Client::Handle_OP_Consider;
	ConnectedOpcodes[OP_Begging] = &Client::Handle_OP_Begging;
	ConnectedOpcodes[OP_TestBuff] = &Client::Handle_OP_TestBuff;
	ConnectedOpcodes[OP_Surname] = &Client::Handle_OP_Surname;
	ConnectedOpcodes[OP_YellForHelp] = &Client::Handle_OP_YellForHelp;
	ConnectedOpcodes[OP_Assist] = &Client::Handle_OP_Assist;
	ConnectedOpcodes[OP_GMTraining] = &Client::Handle_OP_GMTraining;
	ConnectedOpcodes[OP_GMEndTraining] = &Client::Handle_OP_GMEndTraining;
	ConnectedOpcodes[OP_GMTrainSkill] = &Client::Handle_OP_GMTrainSkill;
	ConnectedOpcodes[OP_DuelResponse] = &Client::Handle_OP_DuelResponse;
	ConnectedOpcodes[OP_DuelResponse2] = &Client::Handle_OP_DuelResponse2;
	ConnectedOpcodes[OP_RequestDuel] = &Client::Handle_OP_RequestDuel;
	ConnectedOpcodes[OP_SpawnAppearance] = &Client::Handle_OP_SpawnAppearance;
	ConnectedOpcodes[OP_BazaarInspect] = &Client::Handle_OP_BazaarInspect;
	ConnectedOpcodes[OP_Death] = &Client::Handle_OP_Death;
	ConnectedOpcodes[OP_MoveCoin] = &Client::Handle_OP_MoveCoin;
	ConnectedOpcodes[OP_ItemLinkClick] = &Client::Handle_OP_ItemLinkClick;
	ConnectedOpcodes[OP_MoveItem] = &Client::Handle_OP_MoveItem;
	ConnectedOpcodes[OP_Camp] = &Client::Handle_OP_Camp;
	ConnectedOpcodes[OP_Logout] = &Client::Handle_OP_Logout;
//	ConnectedOpcodes[OP_SenseHeading] = &Client::Handle_OP_SenseHeading;
	ConnectedOpcodes[OP_FeignDeath] = &Client::Handle_OP_FeignDeath;
	ConnectedOpcodes[OP_Sneak] = &Client::Handle_OP_Sneak;
	ConnectedOpcodes[OP_Hide] = &Client::Handle_OP_Hide;
	ConnectedOpcodes[OP_ChannelMessage] = &Client::Handle_OP_ChannelMessage;
	ConnectedOpcodes[OP_WearChange] = &Client::Handle_OP_WearChange;
	ConnectedOpcodes[OP_ZoneChange] = &Client::Handle_OP_ZoneChange;
	ConnectedOpcodes[OP_DeleteSpawn] = &Client::Handle_OP_DeleteSpawn;
	ConnectedOpcodes[OP_SaveOnZoneReq] = &Client::Handle_OP_SaveOnZoneReq;
	ConnectedOpcodes[OP_Save] = &Client::Handle_OP_Save;
	ConnectedOpcodes[OP_WhoAllRequest] = &Client::Handle_OP_WhoAllRequest;
	ConnectedOpcodes[OP_GMZoneRequest] = &Client::Handle_OP_GMZoneRequest;
	ConnectedOpcodes[OP_GMZoneRequest2] = &Client::Handle_OP_GMZoneRequest2;
	ConnectedOpcodes[OP_EndLootRequest] = &Client::Handle_OP_EndLootRequest;
	ConnectedOpcodes[OP_LootRequest] = &Client::Handle_OP_LootRequest;
	ConnectedOpcodes[OP_Dye] = &Client::Handle_OP_Dye;
	ConnectedOpcodes[OP_LootItem] = &Client::Handle_OP_LootItem;
	ConnectedOpcodes[OP_GuildDelete] = &Client::Handle_OP_GuildDelete;
	ConnectedOpcodes[OP_GuildPublicNote] = &Client::Handle_OP_GuildPublicNote;
	ConnectedOpcodes[OP_GetGuildsList] = &Client::Handle_OP_GetGuildsList;
	ConnectedOpcodes[OP_SetGuildMOTD] = &Client::Handle_OP_SetGuildMOTD;
	ConnectedOpcodes[OP_GuildPeace] = &Client::Handle_OP_GuildPeace;
	ConnectedOpcodes[OP_GuildWar] = &Client::Handle_OP_GuildWar;
	ConnectedOpcodes[OP_GuildLeader] = &Client::Handle_OP_GuildLeader;
	ConnectedOpcodes[OP_GuildDemote] = &Client::Handle_OP_GuildDemote;
	ConnectedOpcodes[OP_GuildInvite] = &Client::Handle_OP_GuildInvite;
	ConnectedOpcodes[OP_GuildRemove] = &Client::Handle_OP_GuildRemove;
	ConnectedOpcodes[OP_GuildInviteAccept] = &Client::Handle_OP_GuildInviteAccept;
	ConnectedOpcodes[OP_ManaChange] = &Client::Handle_OP_ManaChange;
	ConnectedOpcodes[OP_MemorizeSpell] = &Client::Handle_OP_MemorizeSpell;
	ConnectedOpcodes[OP_SwapSpell] = &Client::Handle_OP_SwapSpell;
	ConnectedOpcodes[OP_CastSpell] = &Client::Handle_OP_CastSpell;
	ConnectedOpcodes[OP_DeleteItem] = &Client::Handle_OP_DeleteItem;
	ConnectedOpcodes[OP_CombatAbility] = &Client::Handle_OP_CombatAbility;
	ConnectedOpcodes[OP_Taunt] = &Client::Handle_OP_Taunt;
	ConnectedOpcodes[OP_InstillDoubt] = &Client::Handle_OP_InstillDoubt;
	ConnectedOpcodes[OP_RezzAnswer] = &Client::Handle_OP_RezzAnswer;
	ConnectedOpcodes[OP_GMSummon] = &Client::Handle_OP_GMSummon;
	ConnectedOpcodes[OP_TradeRequest] = &Client::Handle_OP_TradeRequest;
	ConnectedOpcodes[OP_TradeRequestAck] = &Client::Handle_OP_TradeRequestAck;
	ConnectedOpcodes[OP_CancelTrade] = &Client::Handle_OP_CancelTrade;
	ConnectedOpcodes[OP_TradeAcceptClick] = &Client::Handle_OP_TradeAcceptClick;
	ConnectedOpcodes[OP_BoardBoat] = &Client::Handle_OP_BoardBoat;
	ConnectedOpcodes[OP_LeaveBoat] = &Client::Handle_OP_LeaveBoat;
	ConnectedOpcodes[OP_RandomReq] = &Client::Handle_OP_RandomReq;
	ConnectedOpcodes[OP_Buff] = &Client::Handle_OP_Buff;
	ConnectedOpcodes[OP_GMHideMe] = &Client::Handle_OP_GMHideMe;
	ConnectedOpcodes[OP_GMNameChange] = &Client::Handle_OP_GMNameChange;
	ConnectedOpcodes[OP_GMKill] = &Client::Handle_OP_GMKill;
	ConnectedOpcodes[OP_GMLastName] = &Client::Handle_OP_GMLastName;
	ConnectedOpcodes[OP_GMToggle] = &Client::Handle_OP_GMToggle;
	ConnectedOpcodes[OP_LFGCommand] = &Client::Handle_OP_LFGCommand;
	ConnectedOpcodes[OP_GMGoto] = &Client::Handle_OP_GMGoto;
	ConnectedOpcodes[OP_TraderShop] = &Client::Handle_OP_TraderShop;
	ConnectedOpcodes[OP_ShopRequest] = &Client::Handle_OP_ShopRequest;
	ConnectedOpcodes[OP_Bazaar] = &Client::Handle_OP_Bazaar;
	ConnectedOpcodes[OP_ShopPlayerBuy] = &Client::Handle_OP_ShopPlayerBuy;
	ConnectedOpcodes[OP_ShopPlayerSell] = &Client::Handle_OP_ShopPlayerSell;
	ConnectedOpcodes[OP_ShopEnd] = &Client::Handle_OP_ShopEnd;
	ConnectedOpcodes[OP_CloseContainer] = &Client::Handle_OP_CloseContainer;
	ConnectedOpcodes[OP_ClickObject] = &Client::Handle_OP_ClickObject;
	ConnectedOpcodes[OP_RecipesFavorite] = &Client::Handle_OP_RecipesFavorite;
	ConnectedOpcodes[OP_RecipesSearch] = &Client::Handle_OP_RecipesSearch;
	ConnectedOpcodes[OP_RecipeDetails] = &Client::Handle_OP_RecipeDetails;
	ConnectedOpcodes[OP_RecipeAutoCombine] = &Client::Handle_OP_RecipeAutoCombine;
	ConnectedOpcodes[OP_TradeSkillCombine] = &Client::Handle_OP_TradeSkillCombine;
	ConnectedOpcodes[OP_ItemName] = &Client::Handle_OP_ItemName;
	ConnectedOpcodes[OP_AugmentItem] = &Client::Handle_OP_AugmentItem;
	ConnectedOpcodes[OP_ClickDoor] = &Client::Handle_OP_ClickDoor;
	ConnectedOpcodes[OP_GroundSpawn] = &Client::Handle_OP_CreateObject;
	ConnectedOpcodes[OP_FaceChange] = &Client::Handle_OP_FaceChange;
	ConnectedOpcodes[OP_GroupInvite] = &Client::Handle_OP_GroupInvite;
	ConnectedOpcodes[OP_GroupInvite2] = &Client::Handle_OP_GroupInvite2;
	ConnectedOpcodes[OP_GroupAcknowledge] = &Client::Handle_OP_GroupAcknowledge;
	ConnectedOpcodes[OP_GroupCancelInvite] = &Client::Handle_OP_GroupCancelInvite;
	ConnectedOpcodes[OP_GroupFollow] = &Client::Handle_OP_GroupFollow;
	ConnectedOpcodes[OP_GroupFollow2] = &Client::Handle_OP_GroupFollow2;
	ConnectedOpcodes[OP_GroupDisband] = &Client::Handle_OP_GroupDisband;
	ConnectedOpcodes[OP_GroupDelete] = &Client::Handle_OP_GroupDelete;
	ConnectedOpcodes[OP_GMEmoteZone] = &Client::Handle_OP_GMEmoteZone;
	ConnectedOpcodes[OP_InspectRequest] = &Client::Handle_OP_InspectRequest;
	ConnectedOpcodes[OP_InspectAnswer] = &Client::Handle_OP_InspectAnswer;
//	ConnectedOpcodes[OP_Medding] = &Client::Handle_OP_Medding;
	ConnectedOpcodes[OP_DeleteSpell] = &Client::Handle_OP_DeleteSpell;
	ConnectedOpcodes[OP_PetitionBug] = &Client::Handle_OP_PetitionBug;
	ConnectedOpcodes[OP_Bug] = &Client::Handle_OP_Bug;
	ConnectedOpcodes[OP_Petition] = &Client::Handle_OP_Petition;
	ConnectedOpcodes[OP_PetitionCheckIn] = &Client::Handle_OP_PetitionCheckIn;
	ConnectedOpcodes[OP_PetitionResolve] = &Client::Handle_OP_PetitionResolve;
	ConnectedOpcodes[OP_PetitionDelete] = &Client::Handle_OP_PetitionDelete;
	ConnectedOpcodes[OP_PetCommands] = &Client::Handle_OP_PetCommands;
	ConnectedOpcodes[OP_PetitionUnCheckout] = &Client::Handle_OP_PetitionUnCheckout;
	ConnectedOpcodes[OP_PetitionQue] = &Client::Handle_OP_PetitionQue;
	ConnectedOpcodes[OP_PDeletePetition] = &Client::Handle_OP_PDeletePetition;
	ConnectedOpcodes[OP_PetitionCheckout] = &Client::Handle_OP_PetitionCheckout;
	ConnectedOpcodes[OP_PetitionRefresh] = &Client::Handle_OP_PetitionRefresh;
	ConnectedOpcodes[OP_ReadBook] = &Client::Handle_OP_ReadBook;
	ConnectedOpcodes[OP_Emote] = &Client::Handle_OP_Emote;
	ConnectedOpcodes[OP_Animation] = &Client::Handle_OP_Animation;
	ConnectedOpcodes[OP_SetServerFilter] = &Client::Handle_OP_SetServerFilter;
	ConnectedOpcodes[OP_GMDelCorpse] = &Client::Handle_OP_GMDelCorpse;
	ConnectedOpcodes[OP_GMKick] = &Client::Handle_OP_GMKick;
	ConnectedOpcodes[OP_GMServers] = &Client::Handle_OP_GMServers;
	ConnectedOpcodes[OP_Illusion] = &Client::Handle_OP_Illusion;
	ConnectedOpcodes[OP_GMBecomeNPC] = &Client::Handle_OP_GMBecomeNPC;
	ConnectedOpcodes[OP_Fishing] = &Client::Handle_OP_Fishing;
	ConnectedOpcodes[OP_Forage] = &Client::Handle_OP_Forage;
	ConnectedOpcodes[OP_Mend] = &Client::Handle_OP_Mend;
	ConnectedOpcodes[OP_EnvDamage] = &Client::Handle_OP_EnvDamage;
	ConnectedOpcodes[OP_Damage] = &Client::Handle_OP_Damage;
	ConnectedOpcodes[OP_AAAction] = &Client::Handle_OP_AAAction;
	ConnectedOpcodes[OP_TraderBuy] = &Client::Handle_OP_TraderBuy;
	ConnectedOpcodes[OP_Trader] = &Client::Handle_OP_Trader;
	ConnectedOpcodes[OP_GMFind] = &Client::Handle_OP_GMFind;
	ConnectedOpcodes[OP_PickPocket] = &Client::Handle_OP_PickPocket;
	ConnectedOpcodes[OP_Bind_Wound] = &Client::Handle_OP_Bind_Wound;
	ConnectedOpcodes[OP_TrackTarget] = &Client::Handle_OP_TrackTarget;
	ConnectedOpcodes[OP_Track] = &Client::Handle_OP_Track;
	ConnectedOpcodes[OP_TrackUnknown] = &Client::Handle_OP_TrackUnknown;
	ConnectedOpcodes[OP_0x0193] = &Client::Handle_0x0193;
	ConnectedOpcodes[OP_ClientError] = &Client::Handle_OP_ClientError;
	ConnectedOpcodes[OP_ReloadUI] = &Client::Handle_OP_ReloadUI;
	ConnectedOpcodes[OP_TGB] = &Client::Handle_OP_TGB;
	ConnectedOpcodes[OP_Split] = &Client::Handle_OP_Split;
	ConnectedOpcodes[OP_SenseTraps] = &Client::Handle_OP_SenseTraps;
	ConnectedOpcodes[OP_DisarmTraps] = &Client::Handle_OP_DisarmTraps;
	ConnectedOpcodes[OP_StartTribute] = &Client::Handle_OP_StartTribute;
	ConnectedOpcodes[OP_TributeItem] = &Client::Handle_OP_TributeItem;
	ConnectedOpcodes[OP_TributeMoney] = &Client::Handle_OP_TributeMoney;
	ConnectedOpcodes[OP_SelectTribute] = &Client::Handle_OP_SelectTribute;
	ConnectedOpcodes[OP_TributeUpdate] = &Client::Handle_OP_TributeUpdate;
	ConnectedOpcodes[OP_TributeToggle] = &Client::Handle_OP_TributeToggle;
	ConnectedOpcodes[OP_TributeNPC] = &Client::Handle_OP_TributeNPC;
	ConnectedOpcodes[OP_ConfirmDelete] = &Client::Handle_OP_ConfirmDelete;
	ConnectedOpcodes[OP_CrashDump] = &Client::Handle_OP_CrashDump;
	ConnectedOpcodes[OP_ControlBoat] = &Client::Handle_OP_ControlBoat;
	ConnectedOpcodes[OP_DumpName] = &Client::Handle_OP_DumpName;
	ConnectedOpcodes[OP_SetRunMode] = &Client::Handle_OP_SetRunMode;
	ConnectedOpcodes[OP_SafeFallSuccess] = &Client::Handle_OP_SafeFallSuccess;
	ConnectedOpcodes[OP_Heartbeat] = &Client::Handle_OP_Heartbeat;
	ConnectedOpcodes[OP_SafePoint] = &Client::Handle_OP_SafePoint;
	ConnectedOpcodes[OP_FindPersonRequest] = &Client::Handle_OP_FindPersonRequest;
	ConnectedOpcodes[OP_BankerChange] = &Client::Handle_OP_BankerChange;
	ConnectedOpcodes[OP_LeadershipExpToggle] = &Client::Handle_OP_LeadershipExpToggle;
	ConnectedOpcodes[OP_PurchaseLeadershipAA] = &Client::Handle_OP_PurchaseLeadershipAA;
	ConnectedOpcodes[OP_SetTitle] = &Client::Handle_OP_SetTitle;
	ConnectedOpcodes[OP_SenseHeading] = &Client::Handle_OP_Ignore;
	ConnectedOpcodes[OP_FloatListThing] = &Client::Handle_OP_Ignore;
	ConnectedOpcodes[OP_WorldUnknown001] = &Client::Handle_OP_Ignore;
	
}

int Client::HandlePacket(const EQZonePacket *app)
{
	_ZP(Client_HandlePacket);
	
	EmuOpcode opcode = app->GetOpcode();
	if (opcode == OP_AckPacket) {
    	return true;
	}
	
	#if EQDEBUG >= 9
		cout << "Received 0x" << hex << setw(4) << setfill('0') << opcode << ", size=" << dec << app->size << endl;
	#endif
	
	#ifdef SOLAR
		if(0 && opcode != OP_ClientUpdate)
		{
			LogFile->write(EQEMuLog::Debug,"HandlePacket() OPCODE debug enabled client %s", GetName());
			cerr << "OPCODE: " << hex << setw(4) << setfill('0') << opcode << dec << ", size: " << app->size << endl;
			DumpPacket(app);
		}
	#endif

	switch(client_state) {
	case CLIENT_CONNECTING: {
		if(ConnectingOpcodes.count(opcode) != 1) {
//TODO: replace this 0 with the EQ opcode
			LogFile->write(EQEMuLog::Error, "HandlePacket() Opcode error: Unexpected packet during CLIENT_CONNECTING: opcode: %s (#%d eq=0x%04x), size: %i", OpcodeNames[opcode], opcode, 0, app->size);
#if EQDEBUG >= 9
			cout << "Unexpected packet during CLIENT_CONNECTING: OpCode: 0x" << hex << setw(4) << setfill('0') << opcode << dec << ", size: " << app->size << endl;
			DumpPacket(app);
#endif
			break;
		}
		
		ClientPacketProc p;
		p = ConnectingOpcodes[opcode];
		
		//call the processing routine
		(this->*p)(app);
		
		//special case where connecting code needs to boot client...
		if(client_state == CLIENT_KICKED) {
			return(false);
		}
		
		break;
	}
	case CLIENT_CONNECTED: {
		ClientPacketProc p;
		p = ConnectedOpcodes[opcode];
		if(p == NULL) {
//TODO: replace this 0 with the EQ opcode
			LogFile->write(EQEMuLog::Error, "Unhandled incoming opcode: %s (#%d, eq=0x%04x), size: %i, Client: %s", OpcodeNames[opcode], opcode, 0, app->size, GetName());
			if(app->size<1000)
				DumpPacket(app->pBuffer, app->size);
			else{
				cout << "Dump limited to 1000 characters:\n";
				DumpPacket(app->pBuffer, 1000);
			}
			break;
		}
		
		//call the processing routine
		(this->*p)(app);
		break;
	}
	case CLIENT_KICKED:
	case DISCONNECTED:
	case CLIENT_LINKDEAD:
		break;
	default:
		LogFile->write(EQEMuLog::Debug, "Unknown client_state: %d\n", client_state);
		break;
	}

	return(true);
}



/*void Client::Handle_Connect_OP_SetDataRate(const EQZonePacket *app)
{
	// Set client datarate
	//if (app->size != sizeof(float)) {
		//LogFile->write(EQEMuLog::Error,"Wrong size on OP_SetDatarate. Got: %i, Expected: %i", app->size, sizeof(float));
		//return;
	//}
	//LogFile->write(EQEMuLog::Debug, "HandlePacket() OP_SetDataRate request : %f",  *(float*) app->pBuffer);
	//float tmpDR = *(float*) app->pBuffer;
	//if (tmpDR <= 0.0f) {
		//LogFile->write(EQEMuLog::Error,"HandlePacket() OP_SetDataRate INVALID request : %f <= 0", tmpDR);
		//LogFile->write(EQEMuLog::Normal,"WARNING: Setting datarate for client to 5.0 expect a client lock up =(");
		//tmpDR = 5.0f;
	//}
	//if (tmpDR > 25.0f)
		//tmpDR = 25.0f;
	//eqs->SetDataRate(tmpDR);
	return;
}*/

void Client::Handle_Connect_OP_ZoneEntry(const EQZonePacket *app)
{
	if(app->size != sizeof(ClientZoneEntry_Struct))
		return;
	ClientZoneEntry_Struct *cze = (ClientZoneEntry_Struct *) app->pBuffer;
	
	if(strlen(cze->char_name) > 63)
		return;
	
	conn_state = ReceivedZoneEntry;
	
	// Quagmire - Antighost code
	// tmp var is so the search doesnt find this object
	Client* client = entity_list.GetClientByName(cze->char_name);
	if (!zone->GetAuth(ip, cze->char_name, &WID, &account_id, &character_id, &admin, lskey, &tellsoff)) {
		LogFile->write(EQEMuLog::Error, "GetAuth() returned false kicking client");
		if (client != 0)
		{
			client->Save();
			client->Kick();
		}
		//ret = false; // TODO: Can we tell the client to get lost in a good way
		client_state = CLIENT_KICKED;
		return;
	}
	
	strcpy(name, cze->char_name);
	if (client != 0) {
		struct in_addr ghost_addr;
		ghost_addr.s_addr = eqs->GetrIP();
		
		LogFile->write(EQEMuLog::Error,"Ghosting client: Account ID:%i Name:%s Character:%s IP:%s",
							client->AccountID(), client->AccountName(), client->GetName(), inet_ntoa(ghost_addr));
		client->Save();
		client->Disconnect();
	}
	
	char* query = 0;
	uint32_breakdown workpt;
	workpt.b4() = DBA_b4_Entity;
	workpt.w2_3() = GetID();
	workpt.b1() = DBA_b1_Entity_Client_InfoForLogin;
	DBAsyncWork* dbaw = new DBAsyncWork(MTdbafq, workpt, DBAsync::Read);
	dbaw->AddQuery(1, &query, MakeAnyLenString(&query, "SELECT status,name,lsaccount_id,gmspeed,revoked,hideme FROM account WHERE id=%i", account_id));
	dbaw->AddQuery(2, &query, MakeAnyLenString(&query, "SELECT id,profile,zonename,x,y,z,guild,guildrank,extprofile FROM character_ WHERE id=%i", character_id));
	dbaw->AddQuery(3, &query, MakeAnyLenString(&query, "SELECT faction_id,current_value FROM faction_values WHERE char_id = %i", character_id));
	if (!(pDBAsyncWorkID = dbasync->AddWork(&dbaw))) {
		safe_delete(dbaw);
		LogFile->write(EQEMuLog::Error,"dbasync->AddWork() returned false, client crash");
		client_state = CLIENT_KICKED;
		return;
	}
	return;
}

void Client::Handle_Connect_OP_SetServerFilter(const EQZonePacket *app)
{
	SetServerFilter_Struct* filter=(SetServerFilter_Struct*)app->pBuffer;
	ServerFilter(filter);
	return;
}

void Client::Handle_Connect_OP_SendAATable(const EQZonePacket *app)
{
	for(int a=0; a < MAX_PP_AA_ARRAY; a++){
		aa[a] = &m_pp.aa_array[a];
		int32 id = aa[a]->AA;
		if(aa[a]->value>1)
			aa_points[(id - aa[a]->value +1)] = aa[a]->value;
		else
			aa_points[id] = aa[a]->value;
	}
	SendAAList();
	return;
}

void Client::Handle_Connect_OP_SendTributes(const EQZonePacket *app)
{
	SendTributes();
	return;
}

void Client::Handle_Connect_OP_SendGuildTributes(const EQZonePacket *app)
{
	SendGuildTributes();
	return;
}

void Client::Handle_Connect_OP_SendAAStats(const EQZonePacket *app)
{
	SendAATimers();
	EQZonePacket* outapp = new EQZonePacket(OP_SendAAStats, 0);
	QueuePacket(outapp);
	safe_delete(outapp);
	return;
}

//void Client::Handle_Connect_0x3e33(const EQZonePacket *app)
//{
/*OP_0x0380 = 0x642c*/
	//EQZonePacket* outapp = new EQZonePacket(OP_0x0380, sizeof(int32)); // Dunno
	//QueuePacket(outapp);
	//safe_delete(outapp);
	//return;
//}

void Client::Handle_Connect_OP_ReqClientSpawn(const EQZonePacket *app)
{
	conn_state = ClientSpawnRequested;
	
	EQZonePacket* outapp = new EQZonePacket;
	
	// Send Zone Doors
	if (entity_list.MakeDoorSpawnPacket(outapp)) {
		//DumpPacket(outapp);
		QueuePacket(outapp);
	}
	safe_delete(outapp);
	
	// Send Zone Objects
	entity_list.SendZoneObjects(this);
	
	// Send Zone Points
	if (zone->numzonepoints > 0) {
		int32 zpsize = sizeof(ZonePoints) + ((zone->numzonepoints+1) * sizeof(ZonePoint_Entry));
		EQZonePacket* outapp = new EQZonePacket(OP_SendZonepoints,zpsize);
		ZonePoints* zp = (ZonePoints*)outapp->pBuffer;
		memset(zp, 0, zpsize);
		LinkedListIterator<ZonePoint*> iterator(zone->zone_point_list);
		iterator.Reset();
		zp->count = zone->numzonepoints;
		int32 count = 0;
		
		while(iterator.MoreElements())
		{
			ZonePoint* data = iterator.GetData();
			zp->zpe[count].iterator = data->number;
			zp->zpe[count].x = data->target_x;
			zp->zpe[count].y = data->target_y;
			zp->zpe[count].z = data->target_z;
			zp->zpe[count].heading=data->target_heading;
			zp->zpe[count].zoneid = data->target_zone_id;
			iterator.Advance();
			count++;
		}
		QueuePacket(outapp);
		safe_delete(outapp);
	}
	
	// Live does this - Doodman
	outapp = new EQZonePacket(OP_SendAAStats, 0);
	QueuePacket(outapp);
	safe_delete(outapp);

	// Tell client they can continue we're done
	outapp = new EQZonePacket(OP_SendExpZonein, 0);
	QueuePacket(outapp);
	safe_delete(outapp);

	if(strncasecmp(zone->GetShortName(),"bazaar",6)==0)
		SendBazaarWelcome();
	if(GetAdventureID()>0){
		AdventureInfo ai=database.GetAdventureInfo(GetAdventureID());
		if(zone->GetZoneID() == ai.zoneid) {
			SendAdventureRequestData(entity_list.GetGroupByClient(this),false,true);
		}
		else if(zone->GetZoneID() == ai.zonedungeonid && 
			database.IsLDoNDungeon(zone->GetZoneID()) ){
			SendAdventureRequestData(entity_list.GetGroupByClient(this),true,false);
		}
		else
			SendAdventureRequestData(NULL,false,false,true);
	}
	
	conn_state = ZoneContentsSent;
	
	return;
}

void Client::Handle_Connect_OP_ReqNewZone(const EQZonePacket *app)
{
	conn_state = NewZoneRequested;
	
	EQZonePacket* outapp;
	
	/////////////////////////////////////
	// New Zone Packet
	outapp = new EQZonePacket(OP_NewZone, sizeof(NewZone_Struct));
	NewZone_Struct* nz = (NewZone_Struct*)outapp->pBuffer;
	memcpy(outapp->pBuffer, &zone->newzone_data, sizeof(NewZone_Struct));
	strcpy(nz->char_name, m_pp.name);
	FastQueuePacket(&outapp);
	
	/////////////////////////////////////
	// Titles Packet
	//this is where live is sending titles... im not sure why
	outapp = title_manager.MakeTitlesPacket(this);
	if(outapp != NULL)
		FastQueuePacket(&outapp);
	
	return;
}

void Client::Handle_Connect_OP_SendExpZonein(const EQZonePacket *app)
{
	//////////////////////////////////////////////////////
	// Spawn Appearance Packet
	EQZonePacket* outapp = new EQZonePacket(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa->type = AT_SpawnID;			// Is 0x10 used to set the player id?
	sa->parameter = GetID();	// Four bytes for this parameter...
	outapp->priority = 6;
	QueuePacket(outapp);
	safe_delete(outapp);
	
	// Inform the world about the client
	outapp = new EQZonePacket();
	
	CreateSpawnPacket(outapp);
	outapp->priority = 6;
	entity_list.QueueClients(this, outapp, true);
	safe_delete(outapp);
	
	//Send AA Exp packet:
	if(GetLevel() >= 51)
		SendAAStats();
	
	// Send exp packets
	outapp = new EQZonePacket(OP_ExpUpdate, sizeof(ExpUpdate_Struct));
	ExpUpdate_Struct* eu = (ExpUpdate_Struct*)outapp->pBuffer;
	int32 tmpxp1 = GetEXPForLevel(GetLevel()+1);
	int32 tmpxp2 = GetEXPForLevel(GetLevel());

	// Quag: crash bug fix... Divide by zero when tmpxp1 and 2 equalled each other, most likely the error case from GetEXPForLevel() (invalid class, etc)
	if (tmpxp1 != tmpxp2 && tmpxp1 != 0xFFFFFFFF && tmpxp2 != 0xFFFFFFFF) {
		double tmpxp = (double) ( (double) m_pp.exp-tmpxp2 ) / ( (double) tmpxp1-tmpxp2 );
		eu->exp = (uint32)(330.0f * tmpxp);
		outapp->priority = 6;
		QueuePacket(outapp);
	}
	safe_delete(outapp);

	if(GetLevel() >= 51)
		SendAATimers();

	outapp = new EQZonePacket(OP_SendExpZonein, 0);
	QueuePacket(outapp);
	safe_delete(outapp);

	outapp = new EQZonePacket(OP_RaidUpdate, sizeof(ZoneInSendName_Struct));
	ZoneInSendName_Struct* zonesendname=(ZoneInSendName_Struct*)outapp->pBuffer;
	strcpy(zonesendname->name,m_pp.name);
	strcpy(zonesendname->name2,m_pp.name);
	zonesendname->unknown0=0x0A;
	QueuePacket(outapp);
	safe_delete(outapp);
	
	/* this is actually the guild MOTD
	outapp = new EQZonePacket(OP_ZoneInSendName2, sizeof(ZoneInSendName_Struct2));
	ZoneInSendName_Struct2* zonesendname2=(ZoneInSendName_Struct2*)outapp->pBuffer;
	strcpy(zonesendname2->name,m_pp.name);
	QueuePacket(outapp);
	safe_delete(outapp);*/
	
	int32 guildid = GuildDBID();
	if(guildid!=0 && guildid!=0xFFFFFFFF) {
		SendGuildMembers(guildid, true);
		
		outapp = new EQZonePacket(OP_GuildMOTD, sizeof(GuildMOTD_Struct));
		GuildMOTD_Struct *motd = (GuildMOTD_Struct *) outapp->pBuffer;
		motd->unknown0 = 0;
		strncpy(motd->name, m_pp.name, 64);
		string motd_str = database.GetGuildMOTD(guildid);
		strncpy(motd->motd, motd_str.c_str(), 512);
		
		FastQueuePacket(&outapp);
	} else {
		//No idea why live sends this if were not in a guild
		outapp = new EQZonePacket(OP_GuildMOTD, sizeof(GuildMOTD_Struct));
		GuildMOTD_Struct *motd = (GuildMOTD_Struct *) outapp->pBuffer;
		motd->unknown0 = 0;
		strncpy(motd->name, m_pp.name, 64);
		//motd->setby_name[0] = '\0';
		motd->motd[0] = '\0';	//just to be sure
		
		FastQueuePacket(&outapp);
	}
	
	
	return;
}

void Client::Handle_Connect_OP_ZoneComplete(const EQZonePacket *app)
{
	EQZonePacket* outapp = new EQZonePacket(OP_0x0347, 0);
	QueuePacket(outapp);
	safe_delete(outapp);
	return;
}

void Client::Handle_Connect_OP_SpawnAppearance(const EQZonePacket *app)
{
	return;
}

void Client::Handle_Connect_OP_WearChange(const EQZonePacket *app)
{
	//not sure what these are supposed to mean to us.
	return;
}

void Client::Handle_Connect_OP_ClientUpdate(const EQZonePacket *app)
{
	//Once we get this, the client thinks it is connected
	//So give it the benefit of the doubt and move to connected
	
	Handle_Connect_OP_ClientReady(app);
}

void Client::Handle_Connect_OP_ClientReady(const EQZonePacket *app)
{
	conn_state = ClientReadyReceived;
	
	CompleteConnect();
	SendHPUpdate();
}

void Client::Handle_Connect_OP_ClientError(const EQZonePacket *app)
{
	// Client reporting error to server
	ClientError_Struct* error = (ClientError_Struct*)app->pBuffer;
	LogFile->write(EQEMuLog::Error, "Client error: %s", error->character_name);
	LogFile->write(EQEMuLog::Error, "Error message: %s", error->message);
	Message(13, error->message);
#if (EQDEBUG>=5)
    DumpPacket(app);
#endif
	return;
}

void Client::Handle_Connect_OP_ApproveZone(const EQZonePacket *app)
{
	ApproveZone_Struct* azone =(ApproveZone_Struct*)app->pBuffer;
	azone->approve=1;
	QueuePacket(app);
	return;
}

void Client::Handle_Connect_OP_TGB(const EQZonePacket *app)
{
	OPTGB(app);
	return;
}

void Client::Handle_OP_ClientUpdate(const EQZonePacket *app)
{
	if (IsAIControlled())
		return;
	
	if (app->size != sizeof(PlayerPositionUpdateClient_Struct)) {
		LogFile->write(EQEMuLog::Error, "OP size error: OP_ClientUpdate expected:%i got:%i", sizeof(PlayerPositionUpdateClient_Struct), app->size);
		return;
	}
	PlayerPositionUpdateClient_Struct* ppu = (PlayerPositionUpdateClient_Struct*)app->pBuffer;
	
	if(ppu->spawn_id != GetID())
		return;
	
	
	float dist = 0;
	float tmp;
	tmp = x_pos - ppu->x_pos;
	dist += tmp*tmp;
	tmp = y_pos - ppu->y_pos;
	dist += tmp*tmp;
	tmp = z_pos - ppu->z_pos;
	dist += tmp*tmp;
	if(dist > 50.0f*50.0f) {
		printf("%s: Large position change: %f units\n", GetName(), sqrt(dist));
		printf("Coords: (%.4f, %.4f, %.4f) -> (%.4f, %.4f, %.4f)\n",
			x_pos, y_pos, z_pos, ppu->x_pos, ppu->y_pos, ppu->z_pos);
		printf("Deltas: (%.2f, %.2f, %.2f) -> (%.2f, %.2f, %.2f)\n",
			delta_x, delta_y, delta_z, ppu->delta_x, ppu->delta_y, ppu->delta_z);
	}
	
	// solar: a very low chance to improve at sense heading, since
	// the client doesn't send an opcode for the key anymore, ever
	// since they made it useless on live
	//
	// this checking of heading/x_pos is cheap, and the result is
	// subtle, but you'll notice your sense heading improve as you
	// travel around
	if(
		( (heading != ppu->heading) && !((int)heading % 3) ) ||	// turning
		( (x_pos != ppu->x_pos) && !((int)x_pos % 6) )					// moving
	)
	{
		CheckIncreaseSkill(SENSE_HEADING, -20);
	}
	
	if(proximity_timer.Check()) {
		entity_list.ProcessMove(this, ppu->x_pos, ppu->y_pos, ppu->z_pos);
		proximity_x = ppu->x_pos;
		proximity_y = ppu->y_pos;
		proximity_z = ppu->z_pos;
	}

	// Update internal state
	delta_x			= ppu->delta_x;
	delta_y			= ppu->delta_y;
	delta_z			= ppu->delta_z;
	delta_heading	= ppu->delta_heading;
	heading			= EQ19toFloat(ppu->heading);

	if(IsTracking && ((x_pos!=ppu->x_pos) || (y_pos!=ppu->y_pos))){
		if(MakeRandomFloat(0, 100) < 70)//should be good
			CheckIncreaseSkill(TRACKING,-10);
	}
	x_pos			= ppu->x_pos;
	y_pos			= ppu->y_pos;
	z_pos			= ppu->z_pos;
	animation		= ppu->animation;
	
#ifdef GUILDWARS
	if(animation > 65 && admin<80 && CheckCheat()){
		if(cheater || cheatcount>0){
			Message(15,"Cheater log updated...yup your busted,its not nice to cheat.");
			char descript[50]={0};
			sprintf(descript,"%s: %i","Player using a movement of",ppu->animation);
			database.logevents(this->AccountName(),this->AccountID(),admin,this->GetName(),"none","Movement speed cheat",descript,15);
			Damage(this,200,0,4,false);
			if(cheater==false){
				worldserver.SendEmoteMessage(0,0,0,13,"<Cheater Locator> We have found a cheater.  %s (Acct: %s) was just caught hacking, please show them what we think of hackers...",this->GetName(),this->AccountName());
				cheater=true;
			}
			cheatcount=0;
		}
		else
			cheatcount++;
	}
	else
		cheatcount=0;
	cheat_x=x_pos;
	cheat_y=y_pos;
#endif
	
		//printf("animation: %i\n",ppu->animation);
	// Outgoing client packet
	if (ppu->y_pos != y_pos || ppu->x_pos != x_pos || ppu->heading != heading || ppu->animation != animation)
	{
		EQZonePacket* outapp = new EQZonePacket(OP_ClientUpdate, sizeof(PlayerPositionUpdateServer_Struct));
		PlayerPositionUpdateServer_Struct* ppu = (PlayerPositionUpdateServer_Struct*)outapp->pBuffer;
		MakeSpawnUpdate(ppu);
		if (gmhideme)
			entity_list.QueueClientsStatus(this,outapp,true,Admin(),250);
		else
#ifdef PACKET_UPDATE_MANAGER
			entity_list.QueueManaged(this,outapp,true,false);
#else
			entity_list.QueueCloseClients(this,outapp,true,300,NULL,false);
#endif
		safe_delete(outapp);
	}
	return;
}

void Client::Handle_OP_AutoAttack(const EQZonePacket *app)
{
	if (app->size != 4) {
		LogFile->write(EQEMuLog::Error, "OP size error: OP_AutoAttack expected:4 got:%i", app->size);
		return;
	}
	
	if (app->pBuffer[0] == 0) {
		auto_attack = false;
		if (IsAIControlled())
			return;
		attack_timer.Disable();
		ranged_timer.Disable();
		attack_dw_timer.Disable();
	}
	else if (app->pBuffer[0] == 1) {
		auto_attack = true;
		if (IsAIControlled())
			return;
		SetAttackTimer();
	}
}

void Client::Handle_OP_AutoAttack2(const EQZonePacket *app)
{
	return;
}

void Client::Handle_OP_Consent(const EQZonePacket *app)
{
	if(app->size<64){
		Consent_Struct* c = (Consent_Struct*)app->pBuffer;
		Client* client = entity_list.GetClientByName(c->name);
		if(client && client!=this){
			consent_list.push_back(client);
			EQZonePacket* outapp = new EQZonePacket(OP_ConsentResponse, sizeof(ConsentResponse_Struct));
			ConsentResponse_Struct* crs = (ConsentResponse_Struct*)outapp->pBuffer;
			strcpy(crs->grantname,client->GetName());
			strcpy(crs->ownername,GetName());
			crs->permission=1;
			strcpy(crs->zonename,"all zones");
			client->QueuePacket(outapp);
			QueuePacket(outapp);
			safe_delete(outapp);
		}
		else if(client==this)
			Message_StringID(0,CONSENT_YOURSELF);
		else
			Message_StringID(0,CONSENT_INVALID_NAME);
	}
	return;
}

void Client::Handle_OP_ConsentDeny(const EQZonePacket *app)
{
	if(app->size<64){
		Consent_Struct* c = (Consent_Struct*)app->pBuffer;
		Client* client = entity_list.GetClientByName(c->name);
		if(client){
			consent_list.remove(client);
			EQZonePacket* outapp = new EQZonePacket(OP_ConsentResponse, sizeof(ConsentResponse_Struct));
			ConsentResponse_Struct* crs = (ConsentResponse_Struct*)outapp->pBuffer;
			strcpy(crs->grantname,client->GetName());
			strcpy(crs->ownername,GetName());
			crs->permission=0;
			strcpy(crs->zonename,"all zones");
			client->QueuePacket(outapp);
			QueuePacket(outapp);
			safe_delete(outapp);
		}
		else
			Message_StringID(0,TARGET_NOT_FOUND);
	}
	return;
}

void Client::Handle_OP_TargetMouse(const EQZonePacket *app)
{
	Handle_OP_TargetCommand(app);
}

void Client::Handle_OP_TargetCommand(const EQZonePacket *app)
{
	if (app->size != sizeof(ClientTarget_Struct)) {
		LogFile->write(EQEMuLog::Error, "OP size error: OP_TargetMouse expected:%i got:%i", sizeof(ClientTarget_Struct), app->size);
		return;
	}
	if(target)
		target->IsTargeted(false);

	// Locate and cache new target
	ClientTarget_Struct* ct=(ClientTarget_Struct*)app->pBuffer;
	pClientSideTarget = ct->new_target;
	if (!IsAIControlled())
		target = entity_list.GetMob(ct->new_target);
	
	//ensure LOS to the target (image)
	if((Admin() < 80) && (target != this && !CheckLosFN(target)))
		return;
	
	// For /target, send reject or success packet
	if (app->GetOpcode() == OP_TargetCommand) {
		if (target && !target->CastToMob()->IsInvisible(this) && DistNoRoot(*target) <= TARGETING_RANGE*TARGETING_RANGE) {
			QueuePacket(app);
			EQZonePacket hp_app;
			target->IsTargeted(true);
			target->CreateHPPacket(&hp_app);
			QueuePacket(&hp_app, false);
		} else {
			EQZonePacket* outapp = new EQZonePacket(OP_TargetReject, sizeof(TargetReject_Struct));
			outapp->pBuffer[0] = 0x2f;
			outapp->pBuffer[1] = 0x01;
			outapp->pBuffer[4] = 0x0d;
			if(target)
				target->IsTargeted(false);
			QueuePacket(outapp);
			safe_delete(outapp);
		}
	}
	else{
		if(target)
			target->IsTargeted(true);
	}
	return;
}

void Client::Handle_OP_Shielding(const EQZonePacket *app)
{
	if (shield_target)
	{
		entity_list.MessageClose(this,false,100,0,"%s ceases shielding %s.",GetName(),shield_target->GetName());
		for (int y = 0; y < 2; y++)
		{
			if (shield_target->shielder[y].shielder_id == GetID())
			{
				shield_target->shielder[y].shielder_id = 0;
				shield_target->shielder[y].shielder_bonus = 0;
			}
		}
	}
	Shielding_Struct* shield = (Shielding_Struct*)app->pBuffer;
	shield_target = entity_list.GetMob(shield->target_id);
	bool ack = false;
	ItemInst* inst = GetInv().GetItem(14);
	if (!shield_target)
		return;
	if (inst)
	{
		const Item_Struct* shield = inst->GetItem();
		if (shield && shield->Common.ItemType == ItemTypeShield)
		{
			for (int x = 0; x < 2; x++)
			{
				if (shield_target->shielder[x].shielder_id == 0)
				{
					entity_list.MessageClose(this,false,100,0,"%s uses their shield to guard %s.",GetName(),shield_target->GetName());
					shield_target->shielder[x].shielder_id = GetID();
					int shieldbonus = shield->Common.AC*2;
					switch (GetAA(197))
					{
						case 1:
							shieldbonus = shieldbonus * 115 / 100;
							break;
						case 2:
							shieldbonus = shieldbonus * 125 / 100;
							break;
						case 3:
							shieldbonus = shieldbonus * 150 / 100;
							break;
					}
					shield_target->shielder[x].shielder_bonus = shieldbonus;
					shield_timer.Start();
					ack = true;
					break;
				}
			}
		}
		else
		{
			Message(0,"You must have a shield equipped to shield a target!");
			shield_target = 0;
			return;
		}
	}
	else
	{
		Message(0,"You must have a shield equipped to shield a target!");
		shield_target = 0;
		return;
	}
	if (!ack)
	{
		Message(0,"No more than two warriors may shield the same being.");
		shield_target = 0;
		return;
	}
	return;
}

void Client::Handle_OP_Jump(const EQZonePacket *app)
{
	// neotokyo: here we could reduce fatigue, if we knew how
	/*
	m_pp.fatigue += 10;
	if(m_pp.fatigue > 100)
		m_pp.fatigue = 100;
	*/
	return;
}

void Client::Handle_OP_AdventureInfoRequest(const EQZonePacket *app)
{
	SendAdventureInfoRequest(app);
	return;
}

void Client::Handle_OP_AdventureRequest(const EQZonePacket *app)
{
	SendAdventureRequest();
	return;
}

void Client::Handle_OP_LDoNButton(const EQZonePacket *app)
{
	bool* p=(bool*)app->pBuffer;
	if(*p == true ) {
		Group* group=entity_list.GetGroupByClient(this);
		SendAdventureRequestData(group);
	}
	else
		SetAdventureID(0);
	return;
}

void Client::Handle_OP_LeaveAdventure(const EQZonePacket *app)
{
	uchar lol[4]={0x3F,0x2A,0x00,0x00};
	EQZonePacket* outapp=new EQZonePacket(OP_AdventureFinish,4); // Doodman: Dunno if this is right or now
	uchar* x=(uchar*)outapp->pBuffer;
	memcpy(x,lol,4);
	QueuePacket(outapp);
	safe_delete(outapp);

	EQZonePacket* outapp2=new EQZonePacket(OP_SimpleMessage,sizeof(SimpleMessage_Struct));
	SimpleMessage_Struct *msg=(SimpleMessage_Struct *)outapp->pBuffer;
	msg->string_id=5135;
	msg->color=0x000d;
	FastQueuePacket(&outapp2);

	SendAdventureFinish(0,0);
	return;

}

void Client::Handle_OP_Consume(const EQZonePacket *app)
{
	if (app->size != sizeof(Consume_Struct))
	{
		LogFile->write(EQEMuLog::Error, "OP size error: OP_Consume expected:%i got:%i", sizeof(Consume_Struct), app->size);
		return;
	}
	Consume_Struct* pcs = (Consume_Struct*)app->pBuffer;
	
	ItemInst *myitem = GetInv().GetItem(pcs->slot);
	if(myitem == NULL) {
		LogFile->write(EQEMuLog::Error, "Consuming from empty slot %d", pcs->slot);
		return;
	}
	
	const Item_Struct* eat_item = myitem->GetItem();
	if (pcs->type == 0x01) {
#if EQDEBUG >= 1
		LogFile->write(EQEMuLog::Debug, "Eating from slot:%i", (int)pcs->slot);
#endif
		m_pp.hunger_level += eat_item->Common.CastTime*30; //roughly 1 item per 10 minutes
		DeleteItemInInventory(pcs->slot, 1, false);
		
		entity_list.MessageClose_StringID(this, true, 50, 0, EATING_MESSAGE, GetName(), eat_item->Name);
	}
	else if (pcs->type == 0x02) {
#if EQDEBUG >= 1
		LogFile->write(EQEMuLog::Debug, "Drinking from slot:%i", (int)pcs->slot);
#endif
		// 6000 is the max. value
		//m_pp.thirst_level += 1000;
		m_pp.thirst_level += eat_item->Common.CastTime*30; //roughly 1 item per 10 minutes
		DeleteItemInInventory(pcs->slot, 1, false);
		
		entity_list.MessageClose_StringID(this, true, 50, 0, DRINKING_MESSAGE, GetName(), eat_item->Name);
	}
	else {
		LogFile->write(EQEMuLog::Error, "OP_Consume: unknown type, type:%i", (int)pcs->type);
		return;
	}
	if (m_pp.hunger_level > 6000)
		m_pp.hunger_level = 6000;
	if (m_pp.thirst_level > 6000)
		m_pp.thirst_level = 6000;
	EQZonePacket *outapp;
	outapp = new EQZonePacket(OP_Stamina, sizeof(Stamina_Struct));
	Stamina_Struct* sta = (Stamina_Struct*)outapp->pBuffer;
	sta->food = m_pp.hunger_level;
	sta->water = m_pp.thirst_level;

	QueuePacket(outapp);
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_AdventureMerchantRequest(const EQZonePacket *app)
{
	// Packet contains entity id
	char msg[16000];
	memset(msg,0,16000);
	int8 count = 0;
	AdventureMerchant_Struct* eid = (AdventureMerchant_Struct*)app->pBuffer;
	int32 merchantid = 0;
	//DumpPacket(app);

	Mob* tmp = entity_list.GetMob(eid->entity_id);
	if (tmp == 0 || !tmp->IsNPC() || tmp->GetClass() != ADVENTUREMERCHANT)
		return;
	
	//you have to be somewhat close to them to be properly using them
	if(DistNoRoot(*tmp) > USE_NPC_RANGE2)
		return;
	
	merchantid=tmp->CastToNPC()->MerchantType;
	tmp->CastToNPC()->FaceTarget(this->CastToMob());

	const Item_Struct *item = 0;
	std::list<MerchantList> merlist = zone->merchanttable[merchantid];
	std::list<MerchantList>::const_iterator itr;
	for(itr = merlist.begin();itr != merlist.end() && count<80;itr++){
		MerchantList ml = *itr;
		item = database.GetItem(ml.item);
		if(item)
		{
			//its possible that the 0 and 1 in here are supposed to be 'count'
			sprintf(msg,"%s^%s,%i,%i,%i,0,1,32767,32767",msg,item->Name,item->ID,item->Common.LDoNPrice,item->Common.LDoNTheme);
			count++;
		}
	}
	//Count
	//^Item Name,Item ID,Cost in Points,Theme (0=none),0,1,32767,32767
	EQZonePacket* outapp = new EQZonePacket(OP_AdventureMerchantResponse,strlen(msg)+2);
	outapp->pBuffer[0] = count;
	strncpy((char*)&outapp->pBuffer[1],msg,strlen(msg));
	//DumpPacket(outapp);
	QueuePacket(outapp);
	safe_delete(outapp);
}

void Client::Handle_OP_AdventureMerchantPurchase(const EQZonePacket *app)
{
	Adventure_Purchase_Struct* aps = (Adventure_Purchase_Struct*)app->pBuffer;
/*
	Get item apc->itemid (can check NPC if thats necessary), ldon point theme check only if theme is not 0 (I am not sure what 1-5 are though for themes)
	if(ldon_available_points >= item ldonpointcost)
	{
	give item (67 00 00 00 for the packettype using opcode 0x02c5)
	ldon_available_points -= ldonpointcost;
	}
*/
	int32 merchantid = 0;
	Mob* tmp = entity_list.GetMob(aps->npcid);
	if (tmp == 0 || !tmp->IsNPC() || tmp->GetClass() != ADVENTUREMERCHANT)
		return;
	
	//you have to be somewhat close to them to be properly using them
	if(DistNoRoot(*tmp) > USE_NPC_RANGE2)
		return;
	
	merchantid = tmp->CastToNPC()->MerchantType;

	const Item_Struct* item = 0;
	std::list<MerchantList> merlist = zone->merchanttable[merchantid];
	std::list<MerchantList>::const_iterator itr;

	for(itr = merlist.begin();itr != merlist.end();itr++){
		MerchantList ml = *itr;
	    item = database.GetItem(ml.item);
		if(item && item->ID == aps->itemid) //This check to make sure that the item is actually on the NPC, people attempt to inject packets to get items summoned...
			break;
		else if(item && item->ID != aps->itemid)
			item = 0;
	}
	if (!item) {
		Message(13, "Error: The item you purchased does not exist!");
		return;
	}
	
	if(m_pp.ldon_points_available >= item->Common.LDoNPrice)
	{
		sint8 charges=1;
			charges=item->Common.MaxCharges;
		ItemInst* inst = ItemInst::Create(item,charges);
		if (inst) {
			sint16 openslot = m_inv.FindFreeSlot(false,true, item->Size);
			if(openslot == SLOT_INVALID)
				return;
			sint32 requiredpts = (sint32)item->Common.LDoNPrice*-1;
			if(!UpdateLDoNPoints(requiredpts,item->Common.LDoNPrice))
				return;
			if(charges != 0)
				inst->SetCharges(charges);
			else
				inst->SetCharges(1);
			SendItemPacket(openslot, inst, ItemPacketTrade);
			PutItemInInventory(openslot,*inst);
			safe_delete(inst);
		}
	}
	
	//DumpPacket(app);
}

void Client::Handle_OP_ConsiderCorpse(const EQZonePacket *app)
{
	if (app->size != sizeof(Consider_Struct))
	{
		LogFile->write(EQEMuLog::Debug, "Size mismatch in Consider corpse expected %i got %i", sizeof(Consider_Struct), app->size);
		return;
	}
	Consider_Struct* conin = (Consider_Struct*)app->pBuffer;
	Corpse* tcorpse = entity_list.GetCorpseByID(conin->targetid);
	if (tcorpse && tcorpse->IsNPCCorpse()) {
		Message(10, "This corpse regards you sadly. Noone asked what i wanted my tombstone to say!");
		int32 min; int32 sec; int32 ttime;
		if ((ttime = tcorpse->GetDecayTime()) != 0) {
			sec = (ttime/1000)%60; // Total seconds
			min = (ttime/60000)%60; // Total seconds / 60 drop .00
			//Message(10,  "This corpse will decay in %i minutes, %i seconds.", min, sec);
			char val1[20]={0};
			char val2[20]={0};
			Message_StringID(10,CORPSE_DECAY1,ConvertArray(min,val1),ConvertArray(sec,val2));
		}
		else {
			Message_StringID(10,CORPSE_DECAY_NOW);
			//Message(10,  "This corpse is waiting to expire.");
		}
	}
	else if (tcorpse && tcorpse->IsPlayerCorpse()) {
		Message(10, "This corpse glares at you threateningly! I told you that wasn't going to work");
		int32 min; int32 sec; int32 ttime;
		if ((ttime = tcorpse->GetDecayTime()) != 0) {
			sec = (ttime/1000)%60; // Total seconds
			min = (ttime/60000)%60; // Total seconds / 60 drop .00
			//Message(10,  "This corpse will decay in %i minutes, %i seconds.", min, sec);
			char val1[20]={0};
			char val2[20]={0};
			Message_StringID(10,CORPSE_DECAY1,ConvertArray(min,val1),ConvertArray(sec,val2));
		}
		else {
			//Message(10,  "This corpse is waiting to expire.");
			Message_StringID(10,CORPSE_DECAY_NOW);
		}
	}
}

void Client::Handle_OP_Consider(const EQZonePacket *app)
{
	if (app->size != sizeof(Consider_Struct))
	{
		LogFile->write(EQEMuLog::Debug, "Size mismatch in Consider expected %i got %i", sizeof(Consider_Struct), app->size);
		return;
	}
	Consider_Struct* conin = (Consider_Struct*)app->pBuffer;
	Mob* tmob = entity_list.GetMob(conin->targetid);
	if (tmob == 0)
		return;
	EQZonePacket* outapp = new EQZonePacket(OP_Consider, sizeof(Consider_Struct));
	Consider_Struct* con = (Consider_Struct*)outapp->pBuffer;
	con->playerid = GetID();
	con->targetid = conin->targetid;
	if(tmob->IsNPC())
		con->faction = GetFactionLevel(character_id, tmob->GetNPCTypeID(), race, class_, deity,(tmob->IsNPC()) ? tmob->CastToNPC()->GetPrimaryFaction():0, tmob); // rembrant, Dec. 20, 2001; TODO: Send the players proper deity
	else
		con->faction = 1;
	con->level = GetLevelCon(tmob->GetLevel());
	if(zone->IsPVPZone()) {
		if (!tmob->IsNPC() )
			con->pvpcon = tmob->CastToClient()->GetPVP();
	}

	// Mongrel: If we're feigned show NPC as indifferent 
	if (tmob->IsNPC()) 
	{ 
		if (GetFeigned()) 
			con->faction = FACTION_INDIFFERENT; 
	} 

	QueuePacket(outapp);
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_Begging(const EQZonePacket *app)
{
	if(GetSkill(BEGGING)>0){
	int ran=MakeRandomInt(0,100);
	int chancetoattack=0;
	if(this->GetLevel() > this->GetTarget()->GetLevel())
		chancetoattack=MakeRandomInt(0,15);
	else
		chancetoattack=MakeRandomInt(((this->GetTarget()->GetLevel() - this->GetLevel())*10)-5,((this->GetTarget()->GetLevel() - this->GetLevel())*10));
	if(chancetoattack<0)
		chancetoattack=-chancetoattack;
	if(ran<chancetoattack){
		this->GetTarget()->Attack(this);
		return;
	}
	float chancetobeg=((float)(GetSkill(BEGGING)/700.0f) + 0.15f) * 100;

	if(ran<chancetobeg)
	{
		EQZonePacket* outapp = new EQZonePacket(OP_MoneyOnCorpse, sizeof(moneyOnCorpseStruct)); 
		moneyOnCorpseStruct* d = (moneyOnCorpseStruct*) outapp->pBuffer; 
		d->copper=MakeRandomInt(1,3);
		d->silver=MakeRandomInt(1,1);
		d->platinum=0;
		d->gold=0;
		d->response      = 1; 
		d->unknown1      = 0x5a; 
		d->unknown2      = 0x40; 
		d->unknown3      = 0; 
		AddMoneyToPP(d->copper, d->silver, d->gold, d->platinum,true); 
		QueuePacket(outapp);
		safe_delete(outapp);
		Message(0,"Begging success!.Received %i silver and %i copper!",d->silver,d->copper);
	}
	else
		Message(0,"Your attempt to beg was not succesful.");
	}
	return;
}

void Client::Handle_OP_TestBuff(const EQZonePacket *app)
{
}

void Client::Handle_OP_Surname(const EQZonePacket *app)
{
	if (app->size != sizeof(Surname_Struct))
	{
		LogFile->write(EQEMuLog::Debug, "Size mismatch in Surname expected %i got %i", sizeof(Surname_Struct), app->size);
		return;
	}
	Surname_Struct* surname = (Surname_Struct*) app->pBuffer;
	char *c = surname->lastname;
	int found_bad_char = 0;

	// solar: fix name so first letter is capital, the rest is lowercase
	// and check for illegal chars too
	for(c = surname->lastname; *c; c++)
	{
		if(!isalpha(*c))
		{
			found_bad_char = 1;
			break;
		}
		if(c == surname->lastname)	// first letter
			*c = toupper(*c);
		else
			*c = tolower(*c);
	}

	if(!strcasecmp(surname->lastname,"ld") || !strcasecmp(surname->lastname,"afk"))
		found_bad_char = 1;
	
	if (found_bad_char) {
		Message(13, "Surnames may only contain alphabet characters.");
		return;
	}
	else if (strlen(surname->lastname)>=20) {
		Message_StringID(10,STRING_SURNAME_TOO_LONG);
		return;
	}
	ChangeLastName(surname->lastname);
	
	EQZonePacket* outapp = new EQZonePacket(OP_GMLastName, sizeof(GMLastName_Struct));
	GMLastName_Struct* lnc = (GMLastName_Struct*) outapp->pBuffer;
	strcpy(lnc->name, surname->name);
	strcpy(lnc->lastname, surname->lastname);
	strcpy(lnc->gmname, "SurnameOP");
	lnc->unknown[0] = 1;
	lnc->unknown[1] = 1;
	entity_list.QueueClients(this, outapp, false);
	safe_delete(outapp);
	
	outapp = app->Copy();
	surname = (Surname_Struct*) outapp->pBuffer;
	surname->unknown0064=1;
	FastQueuePacket(&outapp);
	return;
}

void Client::Handle_OP_YellForHelp(const EQZonePacket *app)
{
	entity_list.QueueCloseClients(this,app, true, 100.0);
	return;
}

void Client::Handle_OP_Assist(const EQZonePacket *app)
{
	if (app->size != sizeof(EntityId_Struct)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_Assist expected %i got %i", sizeof(EntityId_Struct), app->size);
		return;
	}

	EntityId_Struct* eid = (EntityId_Struct*)app->pBuffer;
	Entity* entity = entity_list.GetID(eid->entity_id);
	
	EQZonePacket* outapp = app->Copy();
	eid = (EntityId_Struct*)outapp->pBuffer;
	eid->entity_id = GetID();
	if(entity && entity->IsMob())
	{
		Mob *assistee = entity->CastToMob();
		if(!assistee->IsInvisible(this) && assistee->GetTarget())
		{
			Mob *new_target = assistee->GetTarget();
			if
			(
				new_target &&
				!new_target->IsInvisible(this) &&
				Dist(*assistee) <= TARGETING_RANGE &&
				Dist(*new_target) <= TARGETING_RANGE
			)
			{
				eid->entity_id = new_target->GetID();
			}
		}
	}
	
	FastQueuePacket(&outapp);
	return;
}

void Client::Handle_OP_GMTraining(const EQZonePacket *app)
{
	if (app->size != sizeof(GMTrainee_Struct)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_GMTraining expected %i got %i", sizeof(GMTrainee_Struct), app->size);
		DumpPacket(app);
		return;
	}
	OPGMTraining(app);
	return;
}

void Client::Handle_OP_GMEndTraining(const EQZonePacket *app)
{
	if (app->size != sizeof(GMTrainEnd_Struct)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_GMEndTraining expected %i got %i", sizeof(GMTrainEnd_Struct), app->size);
		DumpPacket(app);
		return;
	}
	OPGMEndTraining(app);
	return;
}

void Client::Handle_OP_GMTrainSkill(const EQZonePacket *app)
{
	if (app->size != sizeof(GMSkillChange_Struct)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_GMTrainSkill expected %i got %i", sizeof(GMSkillChange_Struct), app->size);
		DumpPacket(app);
		return;
	}
	OPGMTrainSkill(app);
	return;
}

void Client::Handle_OP_DuelResponse(const EQZonePacket *app)
{
	if(app->size != sizeof(DuelResponse_Struct))
		return;
	DuelResponse_Struct* ds = (DuelResponse_Struct*) app->pBuffer;
	Entity* entity = entity_list.GetID(ds->target_id);
	Entity* initiator = entity_list.GetID(ds->entity_id);
	if(!entity->IsClient() || !initiator->IsClient())
		return;
	
	entity->CastToClient()->SetDuelTarget(0);
	entity->CastToClient()->SetDueling(false);
	initiator->CastToClient()->SetDuelTarget(0);
	initiator->CastToClient()->SetDueling(false);
	if(GetID() == initiator->GetID())
		entity->CastToClient()->Message_StringID(10,DUEL_DECLINE,initiator->GetName());
	else
		initiator->CastToClient()->Message_StringID(10,DUEL_DECLINE,entity->GetName());
	return;
}

void Client::Handle_OP_DuelResponse2(const EQZonePacket *app)
{
	if(app->size != sizeof(Duel_Struct))
		return;
	
	Duel_Struct* ds = (Duel_Struct*) app->pBuffer;
	Entity* entity = entity_list.GetID(ds->duel_target);
	Entity* initiator = entity_list.GetID(ds->duel_initiator);
	
	if (entity && initiator && entity == this && initiator->IsClient()) {
		EQZonePacket* outapp = new EQZonePacket(OP_RequestDuel, sizeof(Duel_Struct));
		Duel_Struct* ds2 = (Duel_Struct*) outapp->pBuffer;
		
		ds2->duel_initiator = entity->GetID();
		ds2->duel_target = entity->GetID();
		initiator->CastToClient()->QueuePacket(outapp);
		
		outapp->SetOpcode(OP_DuelResponse2);
		ds2->duel_initiator = initiator->GetID();

		initiator->CastToClient()->QueuePacket(outapp);
		
		QueuePacket(outapp);
		SetDueling(true);
		initiator->CastToClient()->SetDueling(true);
		SetDuelTarget(ds->duel_initiator);
		safe_delete(outapp);

		if (IsCasting())
			InterruptSpell();
		if (initiator->CastToClient()->IsCasting())
			initiator->CastToClient()->InterruptSpell();
	}
	return;
}

void Client::Handle_OP_RequestDuel(const EQZonePacket *app)
{
	if(app->size != sizeof(Duel_Struct))
		return;
	
	EQZonePacket* outapp = app->Copy();
	Duel_Struct* ds = (Duel_Struct*) outapp->pBuffer;
	int32 duel = ds->duel_initiator;
	ds->duel_initiator = ds->duel_target;
	ds->duel_target = duel;
	Entity* entity = entity_list.GetID(ds->duel_target);
	if(GetID() != ds->duel_target && entity->IsClient() && (entity->CastToClient()->IsDueling() && entity->CastToClient()->GetDuelTarget() != 0)) {
		Message_StringID(10,DUEL_CONSIDERING,entity->GetName());
		return;
	}
	if(IsDueling()) {
		Message_StringID(10,DUEL_INPROGRESS);
		return;
	}
	
	if(GetID() != ds->duel_target && entity->IsClient() && GetDuelTarget() == 0 && !IsDueling() && !entity->CastToClient()->IsDueling() && entity->CastToClient()->GetDuelTarget() == 0) {
		SetDuelTarget(ds->duel_target);
		entity->CastToClient()->SetDuelTarget(GetID());
		ds->duel_target = ds->duel_initiator;
		entity->CastToClient()->FastQueuePacket(&outapp);
		entity->CastToClient()->SetDueling(false);
		SetDueling(false);
	}
	else
		safe_delete(outapp);
	return;
}

void Client::Handle_OP_SpawnAppearance(const EQZonePacket *app)
{
	if (app->size != sizeof(SpawnAppearance_Struct)) {
		cout << "Wrong size on OP_SpawnAppearance. Got: " << app->size << ", Expected: " << sizeof(SpawnAppearance_Struct) << endl;
		return;
	}
	SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
	
	if(sa->spawn_id != GetID())
		return;

	if (sa->type == AT_Invis) { 
		this->invisible = (sa->parameter == 1);
		entity_list.QueueClients(this, app, true);
		return;
	}
	else if (sa->type == AT_Anim) {
		if (IsAIControlled())
			return;
		if (sa->parameter == ANIM_STAND) {
			SetAppearance(0);
			playeraction = 0;
			SetFeigned(false);
			BindWound(this, false, true);
			camp_timer.Disable();
		}
		else if (sa->parameter == ANIM_SIT) {
			SetAppearance(1);
			playeraction = 1;
			if(!UseBardSpellLogic())
				InterruptSpell();
			SetFeigned(false);
			BindWound(this, false, true);
		}
		else if (sa->parameter == ANIM_CROUCH) {
			if(!UseBardSpellLogic())
				InterruptSpell();
			SetAppearance(2);
			playeraction = 2;
			SetFeigned(false);
			StopSong();
		}
		else if (sa->parameter == ANIM_DEATH) { // feign death too
			SetAppearance(3);
			playeraction = 3;
			InterruptSpell();
			StopSong();
		}
		else if (sa->parameter == ANIM_LOOT) {
			SetAppearance(4);
			playeraction = 4;
			SetFeigned(false);
		}

		// @merth: This is from old code
		// I have no clue what it's for
		/*
		else if (sa->parameter == 0x05) {
			// Illusion
			cout << "Illusion packet recv'd:" << endl;
			DumpPacket(app);
		}
		*/
		else {
			cerr << "Client " << name << " unknown apperance " << (int)sa->parameter << endl;
			return;
		}
		
		entity_list.QueueClients(this, app, true);
	}
	else if (sa->type == AT_Anon) {
		// For Anon/Roleplay
		if (sa->parameter == 1) { // Anon
			m_pp.anon = 1;
		}
		else if ((sa->parameter == 2) || (sa->parameter == 3)) { // This is Roleplay, or anon+rp
			m_pp.anon = 2;
		}
		else if (sa->parameter == 0) { // This is Non-Anon
			m_pp.anon = 0;
		}
		else {
			cerr << "Client " << name << " unknown Anon/Roleplay Switch " << (int)sa->parameter << endl;
			return;
		}
#ifdef GUILDWARS
		if(Admin() == 0)
		{
			m_pp.anon = 0;
			sa->parameter = 0;
		}
#endif
		entity_list.QueueClients(this, app, true);
		UpdateWho();
	}
	else if ((sa->type == AT_HP) && (dead == 0)) {
		return;
	}
	else if (sa->type == AT_AFK) {
		this->AFK = (sa->parameter == 1);
		entity_list.QueueClients(this, app, true);
	}
	//Father Nitwit:
	else if (sa->type == AT_Split) {
		auto_split = (sa->parameter == 1);
	}
	else if (sa->type == AT_Sneak) {
		this->sneaking = (sa->parameter == 1);
		entity_list.QueueClients(this, app, true);
	}
	else if (sa->type == AT_Size)
	{
		entity_list.QueueClients(this, app, false);
	}
	else if (sa->type == AT_Light)	// client emitting light (lightstone, shiny shield)
	{
		entity_list.QueueClients(this, app, false);
	}
	else if (sa->type == AT_Levitate)
	{
		// don't do anything with this, we tell the client when it's
		// levitating, not the other way around
	}
	else {
		cout << "Unknown SpawnAppearance type: 0x" << hex << setw(4) << setfill('0') << sa->type << dec
			<< " value: 0x" << hex << setw(8) << setfill('0') << sa->parameter << dec << endl;
	}
	return;
}

void Client::Handle_OP_BazaarInspect(const EQZonePacket *app)
{
	if (app->size != sizeof(BazaarInspect_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for BazaarInspect_Struct: Expected %i, Got %i",
			sizeof(BazaarInspect_Struct), app->size);
		return;
	}
	
	BazaarInspect_Struct* bis = (BazaarInspect_Struct*)app->pBuffer;
	const Item_Struct* item = database.GetItem(bis->item_id);

	if (!item) {
		Message(13, "Error: This item does not exist!");
		return;
	}
	
	ItemInst* inst = ItemInst::Create(item);
	if (inst) {
		SendItemPacket(0, inst, ItemPacketViewLink);
		safe_delete(inst);
	}
	
	return;
}

void Client::Handle_OP_Death(const EQZonePacket *app)
{
	if(app->size != sizeof(Death_Struct))
		return;
	
	Death_Struct* ds = (Death_Struct*)app->pBuffer;
	
	if(GetHP() > 0)
		return;
	
	Mob* killer = entity_list.GetMob(ds->killer_id);
	Death(killer, ds->damage, ds->spell_id, ds->attack_skill);
	return;
}

void Client::Handle_OP_MoveCoin(const EQZonePacket *app)
{
	if(app->size != sizeof(MoveCoin_Struct)){
		LogFile->write(EQEMuLog::Error, "Wrong size on OP_MoveCoin.  Got: %i, Expected: %i", app->size, sizeof(MoveCoin_Struct));
		DumpPacket(app);
		return;
	}
	OPMoveCoin(app);
	return;
}

void Client::Handle_OP_ItemLinkClick(const EQZonePacket *app)
{
	if(app->size != sizeof(ItemViewRequest_Struct)){
		LogFile->write(EQEMuLog::Error, "Wrong size on OP_ItemLinkClick.  Got: %i, Expected: %i", app->size, sizeof(ItemViewRequest_Struct));
		DumpPacket(app);
		return;
	}
	DumpPacket(app);
	ItemViewRequest_Struct* ivrs = (ItemViewRequest_Struct*)app->pBuffer;
	
	const Item_Struct* item = database.GetItem(ivrs->item_id);
	if (!item) {
		Message(13, "Error: The item for the link you have clicked on does not exist!");
		return;
	}
	
	ItemInst* inst = ItemInst::Create(item);
	if (inst) {
		SendItemPacket(0, inst, ItemPacketViewLink);
		safe_delete(inst);
	}
	return;
}

void Client::Handle_OP_MoveItem(const EQZonePacket *app)
{
	if(this->CharacterID()==0)
		return;
	if (app->size != sizeof(MoveItem_Struct)) {
		LogFile->write(EQEMuLog::Error, "Wrong size: OP_MoveItem, size=%i, expected %i", app->size, sizeof(MoveItem_Struct));
		return;
	}
	
	MoveItem_Struct* mi = (MoveItem_Struct*)app->pBuffer;
	SwapItem(mi);
	return;
}

void Client::Handle_OP_Camp(const EQZonePacket *app)
{
	//LogFile->write(EQEMuLog::Debug, "%s sent a camp packet.", GetName());
	if(GetAdventureID() > 0)
		DeleteCharInAdventure(CharacterID(), GetAdventureID());
	Save();
	LeaveGroup();
	if (GetGM()) {
		OnDisconnect(true);
	}
	camp_timer.Start(29000,true);
	return;
}

void Client::Handle_OP_Logout(const EQZonePacket *app)
{
	//LogFile->write(EQEMuLog::Debug, "%s sent a logout packet.", GetName());
	//we will save when we get destroyed soon anyhow
	//Save();
	
	EQZonePacket *outapp = new EQZonePacket(OP_LogoutReply);
	FastQueuePacket(&outapp);
	
	Disconnect();
	return;
}

#if 0	//solar: this isn't used anymore, the client doesn't send a packet
void Client::Handle_OP_SenseHeading(const EQZonePacket *app)
{
	if (rand()%100 <= 15 && (GetSkill(SENSE_HEADING) < 200) && (GetSkill(SENSE_HEADING) < this->GetLevel()*5+5)) {
		this->SetSkill(SENSE_HEADING, GetRawSkill(SENSE_HEADING) + 1);
	}
	return;
}
#endif

void Client::Handle_OP_FeignDeath(const EQZonePacket *app)
{
	if(GetClass() != MONK)
		return;
	if(!p_timers.Expired(pTimerFeignDeath, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	int reuse = FeignDeathReuseTime;
	switch (GetAA(aaRapidFeign))
	{
		case 1:
			reuse = 9;
			break;
		case 2:
			reuse = 7;
			break;
		case 3:
			reuse = 5;
			break;
	}
	p_timers.Start(pTimerFeignDeath, reuse-1);
	
	//BreakInvis();
	
	int16 primfeign = GetSkill(FEIGN_DEATH);
	int16 secfeign = GetSkill(FEIGN_DEATH);
	if (primfeign > 100) {
		primfeign = 100;
		secfeign = secfeign - 100;
		secfeign = secfeign / 2;
	}
	else
		secfeign = 0;
	
	int16 totalfeign = primfeign + secfeign;
	if (MakeRandomFloat(0, 160) > totalfeign) {
		SetFeigned(false);
		entity_list.MessageClose_StringID(this, false, 200, 10, STRING_FEIGNFAILED, GetName());
	}
	else {
		SetFeigned(true);
	}
	//what is this doing? why is it doing this and CheckIncreaseSkill??
	if ((uint16)MakeRandomInt(0, 300) > GetSkill(FEIGN_DEATH) && MakeRandomFloat(0, 4) == 1 && GetSkill(FEIGN_DEATH) < 200 && GetSkill(FEIGN_DEATH) < (uint16)(GetLevel()*5+5) ) {
		SetSkill(FEIGN_DEATH, GetRawSkill(FEIGN_DEATH) + 1);
	}

	CheckIncreaseSkill(FEIGN_DEATH);
	return;
}

void Client::Handle_OP_Sneak(const EQZonePacket *app)
{
	if(GetSkill(SNEAK) < 1) {
		return; //You cannot sneak if you do not have sneak
	}
	
	if(!p_timers.Expired(pTimerSneak, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	p_timers.Start(pTimerSneak, SneakReuseTime-1);
	
	bool was = sneaking;
	if (sneaking){
		sneaking = false;
	}
	else {
		CheckIncreaseSkill(SNEAK,15);
	}
	float hidechance = ((GetSkill(SNEAK)/300.0f) + .25) * 100;
	float random = MakeRandomFloat(0, 100);
	if(!was && random < hidechance) {
		sneaking = true;
	}
	EQZonePacket* outapp = new EQZonePacket(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
	sa_out->spawn_id = GetID();
	sa_out->type = 0x0F;
	sa_out->parameter = sneaking;
	QueuePacket(outapp);
	safe_delete(outapp);
	if(GetClass() == ROGUE){
		outapp = new EQZonePacket(OP_SimpleMessage,12);
		SimpleMessage_Struct *msg=(SimpleMessage_Struct *)outapp->pBuffer;
		msg->color=0x010E;
		if (sneaking){
			msg->string_id=347;
		}
		else {
			msg->string_id=348;
		}
		FastQueuePacket(&outapp);
	}
	return;
}

void Client::Handle_OP_Hide(const EQZonePacket *app)
{
	if(GetSkill(HIDE) < 1) {
		return; //You cannot hide if you do not have hide
	}
	
	if(!p_timers.Expired(pTimerHide, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	int reuse = HideReuseTime - GetAA(209);
	p_timers.Start(pTimerHide, reuse-1);
	
	float hidechance = ((GetSkill(HIDE)/300.0f) + .25) * 100;
	float random = MakeRandomFloat(0, 100);
	CheckIncreaseSkill(HIDE,15);					
	if (random < hidechance) {
		EQZonePacket* outapp = new EQZonePacket(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
		SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
		sa_out->spawn_id = GetID();
		sa_out->type = 0x03;
		this->invisible = true;
		sa_out->parameter = 1;
		entity_list.QueueClients(this, outapp, true);
		safe_delete(outapp);
		invisible = true;
	}
	if(GetClass() == ROGUE){
		EQZonePacket *outapp = new EQZonePacket(OP_SimpleMessage,sizeof(SimpleMessage_Struct));
		SimpleMessage_Struct *msg=(SimpleMessage_Struct *)outapp->pBuffer;
		msg->color=0x010E;
		if (!auto_attack && entity_list.Fighting(this)) {
			if (MakeRandomInt(0, 300) < (int)GetSkill(HIDE)) {
				msg->string_id=343;
				entity_list.RemoveFromHateLists(this,true);
			} else {
				msg->string_id=344;
			}
		} else {
			if (invisible){
				msg->string_id=347;
			}
			else {
				msg->string_id=348;
			}
		}
		FastQueuePacket(&outapp);
	}
	return;
}

void Client::Handle_OP_ChannelMessage(const EQZonePacket *app)
{
	ChannelMessage_Struct* cm=(ChannelMessage_Struct*)app->pBuffer;
	
	if (app->size < sizeof(ChannelMessage_Struct)) {
		cout << "Wrong size " << app->size << ", should be " << sizeof(ChannelMessage_Struct) << "+ on 0x" << hex << setfill('0') << setw(4) << app->GetOpcode() << dec << endl;
		return;
	}
	if (IsAIControlled()) {
		Message(13, "You try to speak but cant move your mouth!");
		return;
	}
	
	ChannelMessageReceived(cm->chan_num, cm->language, cm->message, cm->targetname);
	return;
}

void Client::Handle_OP_WearChange(const EQZonePacket *app)
{
	if (app->size != sizeof(WearChange_Struct)) {
		cout << "Wrong size: OP_WearChange, size=" << app->size << ", expected " << sizeof(WearChange_Struct) << endl;
		//DumpPacket(app);
		return;
	}

	WearChange_Struct* wc=(WearChange_Struct*)app->pBuffer;
	//printf("Wearchange:\n");
	//DumpPacket(app);
	if(wc->spawn_id != GetID())
		return;

	// we could maybe ignore this and just send our own from moveitem
	entity_list.QueueClients(this, app, true);
	return;
}

//in zoning.cpp
//void Client::Handle_OP_ZoneChange(const EQZonePacket *app) {
//}

void Client::Handle_OP_DeleteSpawn(const EQZonePacket *app)
{
	// The client will send this with his id when he zones, maybe when he disconnects too?
	RemoveData(); // Flushing the queue of packet data to allow for proper zoning -Kasai
	
	EQZonePacket* outapp = new EQZonePacket(OP_DeleteSpawn, sizeof(EntityId_Struct));
	EntityId_Struct* eid = (EntityId_Struct*)outapp->pBuffer;
	eid->entity_id = GetID();
	
	entity_list.QueueClients(this, outapp, false);
	safe_delete(outapp);
	
	hate_list.RemoveEnt(this->CastToMob());

	Disconnect();
	return;
}

void Client::Handle_OP_SaveOnZoneReq(const EQZonePacket *app)
{
	Handle_OP_Save(app);
}

void Client::Handle_OP_Save(const EQZonePacket *app)
{
	// The payload is 192 bytes - Not sure what is contained in payload
	Save();
	return;
}

void Client::Handle_OP_WhoAllRequest(const EQZonePacket *app)
{
	if (app->size != sizeof(Who_All_Struct)) {
		cout << "Wrong size on OP_WhoAll. Got: " << app->size << ", Expected: " << sizeof(Who_All_Struct) << endl;
		//DumpPacket(app);
		return;
	}
	Who_All_Struct* whoall = (Who_All_Struct*) app->pBuffer;
	WhoAll(whoall);
	return;
}

void Client::Handle_OP_GMZoneRequest(const EQZonePacket *app)
{
	if (app->size != sizeof(GMZoneRequest_Struct)) {
		cout << "Wrong size on OP_GMZoneRequest. Got: " << app->size << ", Expected: " << sizeof(GMZoneRequest_Struct) << endl;
		return;
	}
	if (this->Admin() < minStatusToBeGM) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/zone");
		return;
	}
	
	GMZoneRequest_Struct* gmzr = (GMZoneRequest_Struct*)app->pBuffer;
	float tarx = -1, tary = -1, tarz = -1;
	
	sint16 minstatus = 0;
	int8 minlevel = 0;
	char tarzone[32];
	uint16 zid = gmzr->zone_id;
	if (gmzr->zone_id == 0)
		zid = zonesummon_id;
	const char * zname = database.GetZoneName(zid);
	if(zname == NULL)
		tarzone[0] = 0;
	else
		strcpy(tarzone, zname);
	
	// this both loads the safe points and does a sanity check on zone name
	if (!database.GetSafePoints(tarzone, &tarx, &tary, &tarz, &minstatus, &minlevel)) {
		tarzone[0] = 0;
	}
	
	EQZonePacket* outapp = new EQZonePacket(OP_GMZoneRequest, sizeof(GMZoneRequest_Struct));
	GMZoneRequest_Struct* gmzr2 = (GMZoneRequest_Struct*) outapp->pBuffer;
	strcpy(gmzr2->charname, this->GetName());
	gmzr2->zone_id = gmzr->zone_id;
	gmzr2->x = tarx;
	gmzr2->y = tary;
	gmzr2->z = tarz;
	// Next line stolen from ZoneChange as well... - This gives us a nicer message than the normal "zone is down" message...
	if (tarzone[0] != 0 && admin >= minstatus && GetLevel() >= minlevel)
		gmzr2->success = 1;
	else {
		cout << "GetZoneSafeCoords failed. zoneid = " << gmzr->zone_id << "; czone = " << zone->GetZoneID() << endl;
		gmzr2->success = 0;
	}
	
	QueuePacket(outapp);
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_GMZoneRequest2(const EQZonePacket *app)
{
	if (this->Admin() < minStatusToBeGM) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/zone");
		return;
	}
	
	int32 zonereq = *((int32 *)app->pBuffer);
	GoToSafeCoords(zonereq);
	return;
}

void Client::Handle_OP_EndLootRequest(const EQZonePacket *app)
{
	if (app->size != sizeof(int32)) {
		cout << "Wrong size: OP_EndLootRequest, size=" << app->size << ", expected " << sizeof(int32) << endl;
		return;
	}
	
	Entity* entity = entity_list.GetID(*((int16*)app->pBuffer));
	if (entity == 0) {
		//DumpPacket(app);
		Message(13, "Error: OP_EndLootRequest: Corpse not found (ent = 0)");
		Corpse::SendLootReqErrorPacket(this);
		return;
	}
	else if (!entity->IsCorpse()) {
		Message(13, "Error: OP_EndLootRequest: Corpse not found (!entity->IsCorpse())");
		Corpse::SendLootReqErrorPacket(this);
		return;
	}
	else {
		entity->CastToCorpse()->EndLoot(this, app);
	}
	return;
}

void Client::Handle_OP_LootRequest(const EQZonePacket *app)
{
	if (app->size != sizeof(int32)) {
		cout << "Wrong size: OP_LootRequest, size=" << app->size << ", expected " << sizeof(int32) << endl;
		return;
	}
	
	Entity* ent = entity_list.GetID(*((int32*)app->pBuffer));
	if (ent == 0) {
		Message(13, "Error: OP_LootRequest: Corpse not found (ent = 0)");
		Corpse::SendLootReqErrorPacket(this);
		return;
	}
	if (ent->IsCorpse()) {
		ent->CastToCorpse()->MakeLootRequestPackets(this, app);
		return;
	}
	else {
		cout << "npc == 0 LOOTING FOOKED3" << endl;
		Message(13, "Error: OP_LootRequest: Corpse not a corpse?");
		Corpse::SendLootReqErrorPacket(this);
	}
	return;
}

void Client::Handle_OP_Dye(const EQZonePacket *app)
{
	if(app->size!=sizeof(DyeStruct))
		printf("Wrong size of DyeStruct, Got: %i, Expected: %i\n",app->size,sizeof(DyeStruct));
	else{
		DyeStruct* dye = (DyeStruct*)app->pBuffer;
		DyeArmor(dye);
	}
	return;
}

void Client::Handle_OP_ConfirmDelete(const EQZonePacket* app){
	return;
}

void Client::Handle_OP_LootItem(const EQZonePacket *app)
{
	if (app->size != sizeof(LootingItem_Struct)) {
		LogFile->write(EQEMuLog::Error, "Wrong size: OP_LootItem, size=%i, expected %i", app->size, sizeof(LootingItem_Struct));
		return;
	}
	/*
	** Disgrace:
	**	fixed the looting code so that it sends the correct opcodes
	**	and now correctly removes the looted item the player selected
	**	as well as gives the player the proper item.
	**	Also fixed a few UI lock ups that would occur.
	*/
	
	EQZonePacket* outapp = 0;
	Entity* entity = entity_list.GetID(*((int16*)app->pBuffer));
	if (entity == 0) {
		Message(13, "Error: OP_LootItem: Corpse not found (ent = 0)");
		outapp = new EQZonePacket(OP_LootComplete, 0);
		QueuePacket(outapp);
		safe_delete(outapp);
		return;
	}
	
	if (entity->IsCorpse()) {
		entity->CastToCorpse()->LootItem(this, app);
		return;
	}
	else {
		Message(13, "Error: Corpse not found! (!ent->IsCorpse())");
		Corpse::SendEndLootErrorPacket(this);
	}
	
	return;
}

void Client::Handle_OP_GuildDelete(const EQZonePacket *app)
{
	if(GuildRank() != 2 || GuildDBID() == 0)
		Message(0,"You are not a guild leader or not in a guild.");
	else{
		if (!database.DeleteGuild(guilddbid))
			Message(0, "Guild delete failed.");
		else {
			int32 tmpeq = database.GetGuildEQID(guilddbid);
			if (tmpeq != GUILD_NONE) {
				ServerPacket* pack = new ServerPacket(ServerOP_RefreshGuild,5);
				memcpy(pack->pBuffer, &tmpeq, 4);
				pack->pBuffer[4] = 1;
				worldserver.SendPacket(pack);
				safe_delete(pack);
			}
			Message(0, "Guild successfully deleted.");
		}
	}
	return;
}

void Client::Handle_OP_GuildPublicNote(const EQZonePacket *app)
{
	GuildUpdate_PublicNote* gpn=(GuildUpdate_PublicNote*)app->pBuffer;
	database.SetPublicNote(guilddbid,gpn->target,gpn->note);
	SendGuildMembers(guilddbid, true);
	return;
}

void Client::Handle_OP_GetGuildsList(const EQZonePacket *app)
{
	EQZonePacket *outapp;
	outapp = new EQZonePacket(OP_GuildsList, sizeof(GuildsList_Struct));
	memset(outapp->pBuffer,0,sizeof(GuildsList_Struct));
	GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;
	uint32 max_id=database.GetMaxGuildID();
	const char *ptr;
	
	strcpy((char *)gl->head,GetName());
	for (uint32 i=1; i <= max_id; i++) {
		if ((ptr=database.GetGuild(i))!=NULL) {
			strcpy(gl->Guilds[i].name, ptr);
		}
	}
	FastQueuePacket(&outapp);
}

void Client::Handle_OP_SetGuildMOTD(const EQZonePacket *app)
{
	char tmp[600]={0};
	if (app->size !=sizeof(GuildMOTD_Struct)) {
		// client calls for a motd on login even if they arent in a guild
		printf("Error: app size of %i != size of GuildMOTD_Struct of %i\n",app->size,sizeof(GuildMOTD_Struct));
		return;
	}
	GuildMOTD_Struct* gmotd=(GuildMOTD_Struct*)app->pBuffer;
	if ((GuildRank()>0) && (strlen(gmotd->motd)>0)) {
		sprintf(tmp,"%s - %s",gmotd->name,gmotd->motd);
		if (!database.SetGuildMOTD(guilddbid, tmp)) {
			Message(0, "Motd update failed.");
		}
		else{
			EQZonePacket *outapp = new EQZonePacket(OP_GuildMOTD, sizeof(GuildMOTD_Struct));
			GuildMOTD_Struct *motd = (GuildMOTD_Struct *) outapp->pBuffer;
			motd->unknown0 = 0;
			strncpy(motd->name, m_pp.name, 64);
			string motd_str = database.GetGuildMOTD(GuildDBID());
			strncpy(motd->motd, motd_str.c_str(), 512);
			entity_list.QueueClientsGuild(this, outapp, false, GuildEQID());
		}
		
		//worldserver.SendEmoteMessage(0, guilddbid, MT_Guild, "Guild MOTD: %s", tmp);
		
	}
	else {
		/*string str = database.GetGuildMOTD(guilddbid);
		if (str.length() > 0)
			Message_StringID(MT_Guild,GENERIC_STRING,str.c_str());
			//Message(MT_Guild, "Guild MOTD: %s", tmp);
		//Message(MT_Guild, "Guild MOTD Disabled for now");
		*/
		//Handle_OP_GetGuildMOTD(app);
	}
	
	return;
}

void Client::Handle_OP_GuildPeace(const EQZonePacket *app)
{
	return;
}

void Client::Handle_OP_GuildWar(const EQZonePacket *app)
{
	return;
}

void Client::Handle_OP_GuildLeader(const EQZonePacket *app)
{
	if (app->size <= 1)
		return;
	app->pBuffer[app->size-1] = 0;
	GuildMakeLeader* gml=(GuildMakeLeader*)app->pBuffer;
	if (guilddbid == 0)
		Message(0, "Error: You arent in a guild!");
	else if (GuildRank()!=2)
		Message(0, "Error: You arent the guild leader!");
	else if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		Client* newleader=entity_list.GetClientByName(gml->target);
		if(newleader){
			if(database.SetGuildLeader(guilddbid,newleader->AccountID())){
				newleader->GuildChangeRank(GuildEQID(),newleader->GuildRank(),2);
				newleader->SetGuild(guilddbid,2);
				GuildChangeRank(GuildEQID(),2,1);
				SetGuild(guilddbid,1);
				Message(0,"Successfully Transfered Leadership to %s.",gml->target);
				newleader->Message(15,"%s has transfered the guild leadership into your hands.",GetName());
			}
			else
				Message(0,"Could not change leadership at this time.");
		}
		else
			Message(0,"Failed to change leader, could not find target.");
	}
	SendGuildMembers(guilddbid, true);
	return;
}

void Client::Handle_OP_GuildDemote(const EQZonePacket *app)
{
	if(app->size==sizeof(GuildDemoteStruct)){
		GuildDemoteStruct* demote = (GuildDemoteStruct*)app->pBuffer;
		Client* client=entity_list.GetClientByName(demote->target);
		if(client){
			client->GuildChangeRank(GuildEQID(),1,0);
			client->SetGuild(guilddbid,0);
		}
		else{
			GuildChangeRank(demote->target,GuildEQID(),1,0);
			database.SetGuild(demote->target,guilddbid,0);
		}
		Message(0,"Successfully demoted %s.",demote->target);
	}
	SendGuildMembers(guilddbid, true);
	return;
}

void Client::Handle_OP_GuildInvite(const EQZonePacket *app)
{
	if (app->size != sizeof(GuildCommand_Struct)) {
		cout << "Wrong size: OP_GuildInvite, size=" << app->size << ", expected " << sizeof(GuildCommand_Struct) << endl;
		return;
	}
	if (guilddbid == 0)
		Message(0, "Error: You arent in a guild!");
	else if (GuildRank()==0)
		Message(0, "You dont have permission to invite.");
	else if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		#ifdef GUILDWARS
			if (database.NumberInGuild(guilddbid)>MAXMEMBERS){
				Message(15,"Your Guild has reached its Guildwars size limit.  You cannot invite any more people.");
				return;
			}
		#endif
		
		GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
		Client* client=entity_list.GetClientByName(gc->othername);
		if(client){
			if(client->GuildDBID() != 0 && (client->GuildDBID() != GuildDBID()))
			{
				Message(0,"Player is in a guild.");
				return;
			}
			if(gc->guildeqid==0)
				gc->guildeqid=GuildEQID();
			client->QueuePacket(app);
		}
		else
			Message(0,"You must be in the same zone as the person you are inviting.");
	}
	SendGuildMembers(guilddbid, true);
	return;
}

void Client::Handle_OP_GuildRemove(const EQZonePacket *app)
{
	if (app->size != sizeof(GuildCommand_Struct)) {
		cout << "Wrong size: OP_GuildRemove, size=" << app->size << ", expected " << sizeof(GuildCommand_Struct) << endl;
		return;
	}
	GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
	if (guilddbid == 0)
		Message(0, "Error: You arent in a guild!");
	else if (GuildRank()==0 && strcasecmp(gc->othername,GetName()))
		Message(0, "You dont have permission to remove.");
	else if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		Client* client=entity_list.GetClientByName(gc->othername);
		if(client && (client->GuildDBID() != GuildDBID()))
		{
			Message(0,"You aren't in the same guild, what do you think you are doing?");
			return;
		}
		if(database.SetGuild(gc->othername,0,0) || client){
			EQZonePacket* outapp = new EQZonePacket(OP_GuildManageRemove,sizeof(GuildManageRemove_Struct));
			GuildManageRemove_Struct* gm=(GuildManageRemove_Struct*)outapp->pBuffer;
			gm->guildeqid=GuildEQID();
			strcpy(gm->member,gc->othername);
			if(client)
				client->SetGuild(0,0);
			Message(0,"%s successfully removed from your guild.",gc->othername);
			entity_list.QueueClientsGuild(this,outapp,false,GuildEQID());
			safe_delete(outapp);
		}
		else
			Message(0,"Unable to remove %s from your guild.",gc->othername);
	}
	SendGuildMembers(guilddbid, true);
	return;
}

void Client::Handle_OP_GuildInviteAccept(const EQZonePacket *app)
{
	if (app->size != sizeof(GuildInviteAccept_Struct)) {
		cout << "Wrong size: OP_GuildInviteAccept, size=" << app->size << ", expected " << sizeof(GuildJoin_Struct) << endl;
		return;
	}
	GuildInviteAccept_Struct* gj = (GuildInviteAccept_Struct*) app->pBuffer;
	if (gj->response == 5 || gj->response == 4) {
		worldserver.SendEmoteMessage(gj->inviter, 0, 0, "%s has declined to join the guild.", this->GetName());
	}
	else{
		//int32 tmpeq = gj->guildeqid;
		if (guilddbid != 0 && gj->response==GuildRank())
			Message(0, "Error: You're already in a guild!");
		else if (!worldserver.Connected())
			Message(0, "Error: World server disconnected");
		else {
			if(gj->guildeqid==GuildEQID()){//already in guild, need to promote or demote
				/*EQZonePacket* outapp = new EQZonePacket(OP_GuildManageRemove,sizeof(GuildManageRemove_Struct));
				GuildManageRemove_Struct* gm=(GuildManageRemove_Struct*)outapp->pBuffer;
				gm->guildeqid=GuildEQID();
				strcpy(gm->member,GetName());
				entity_list.QueueClientsGuild(this,outapp,false,GuildEQID());
				safe_delete(outapp);*/
				if(gj->response<2){
					SetGuild(guilddbid,1);
					GuildChangeRank(GuildEQID(),0,1);
				}
				else{
					SetGuild(guilddbid,0);
					GuildChangeRank(GuildEQID(),1,0);
				}
				return;
			}
			GuildJoin_Struct* gj2= new GuildJoin_Struct;
			gj2->class_=GetClass();
			gj2->guildid=gj->guildeqid;
			gj2->level=GetLevel();
			strcpy(gj2->name,GetName());
			gj2->rank=gj->response;
			gj2->zoneid=zone->GetZoneID();
			if(gj->response>1)
				SetGuild(guilds[gj->guildeqid].databaseID,0);
			else
				SetGuild(guilds[gj->guildeqid].databaseID,gj->response);
			worldserver.SendGuildJoin(gj2);
			SendGuildMembers(guilds[gj->guildeqid].databaseID, true);
			safe_delete(gj2);
		}
	}
	return;
}

void Client::Handle_OP_ManaChange(const EQZonePacket *app)
{
	if(app->size == 0) {
		// i think thats the sign to stop the songs
		InterruptSpell(SONG_ENDS, 0x121);
		return;
	}
	else	// solar: i don't think the client sends proper manachanges
	{			// with a length, just the 0 len ones for stopping songs
		//ManaChange_Struct* p = (ManaChange_Struct*)app->pBuffer;
		printf("OP_ManaChange from client:\n");
		DumpPacket(app);
	}
	return;
}

void Client::Handle_OP_MemorizeSpell(const EQZonePacket *app)
{
	OPMemorizeSpell(app);
	return;
}

void Client::Handle_OP_SwapSpell(const EQZonePacket *app)
{
	if (app->size != sizeof(SwapSpell_Struct)) {
		cout << "Wrong size on OP_SwapSpell. Got: " << app->size << ", Expected: " << sizeof(SwapSpell_Struct) << endl;
		return;
	}
	const SwapSpell_Struct* swapspell = (const SwapSpell_Struct*) app->pBuffer;
	int swapspelltemp;

	if(swapspell->from_slot < 0 || swapspell->from_slot > MAX_PP_SPELLBOOK || swapspell->to_slot < 0 || swapspell->to_slot > MAX_PP_SPELLBOOK)
		return;
	
	swapspelltemp = m_pp.spell_book[swapspell->from_slot];
	m_pp.spell_book[swapspell->from_slot] = m_pp.spell_book[swapspell->to_slot];
	m_pp.spell_book[swapspell->to_slot] = swapspelltemp;
	
	QueuePacket(app);
	return;
}

void Client::Handle_OP_CastSpell(const EQZonePacket *app)
{
	if (app->size != sizeof(CastSpell_Struct)) {
		cout << "Wrong size: OP_CastSpell, size=" << app->size << ", expected " << sizeof(CastSpell_Struct) << endl;
		return;
	}
	if (IsAIControlled()) {
		this->Message_StringID(13,NOT_IN_CONTROL);
		//Message(13, "You cant cast right now, you arent in control of yourself!");
		return;
	}
	
	CastSpell_Struct* castspell = (CastSpell_Struct*)app->pBuffer;

#ifdef _EQDEBUG
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: %u %i", (uint8)castspell->cs_unknown[0], castspell->cs_unknown[0]);
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: %u %i", (uint8)castspell->cs_unknown[1], castspell->cs_unknown[1]);
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: %u %i", (uint8)castspell->cs_unknown[2], castspell->cs_unknown[2]);
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: %u %i", (uint8)castspell->cs_unknown[3], castspell->cs_unknown[3]);
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: 32 %p %u", &castspell->cs_unknown, *(uint32*) castspell->cs_unknown );
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: 32 %p %i", &castspell->cs_unknown, *(int32*) castspell->cs_unknown );
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: 16 %p %u %u", &castspell->cs_unknown, *(uint16*) castspell->cs_unknown, *(uint16*) castspell->cs_unknown+sizeof(uint16) );
		LogFile->write(EQEMuLog::Debug, "cs_unknown2: 16 %p %i %i", &castspell->cs_unknown, *(int16*) castspell->cs_unknown, *(int16*) castspell->cs_unknown+sizeof(int16) );
#endif
LogFile->write(EQEMuLog::Debug, "OP CastSpell: slot=%d, spell=%d, target=%d, inv=%lx", castspell->slot, castspell->spell_id, castspell->target_id, castspell->inventoryslot);

	if (castspell->slot == USE_ITEM_SPELL_SLOT)	// this means item
	{
		//discipline, using the item spell slot
		if(castspell->inventoryslot == 0xFFFFFFFF) {
			if(!UseDiscipline(castspell->spell_id, castspell->target_id)) {
				LogFile->write(EQEMuLog::Debug, "Unknown ability being used by %s, spell being cast is: %i\n",GetName(),castspell->spell_id);
				InterruptSpell(castspell->spell_id);
			}
			return;
		}
		else if (castspell->inventoryslot < 30)	// sanity check
		{
			const ItemInst* inst = m_inv[castspell->inventoryslot]; //@merth: slot values are sint16, need to check packet on this field
			//bool cancast = true;
			if (inst && inst->IsType(ItemClassCommon))
			{
				const Item_Struct* item = inst->GetItem();
				if(item->Common.Click.Effect != (int32)castspell->spell_id)
				{
					InterruptSpell(castspell->spell_id);	//CHEATER!!
					return;
				}
				//delete a charge from the item
				EQZonePacket* outapp = new EQZonePacket(OP_TraderDelItem,sizeof(TraderDelItem_Struct));
				TraderDelItem_Struct* tdi = (TraderDelItem_Struct*)outapp->pBuffer;
				tdi->quantity=0xFFFFFFFF;
				tdi->unknown=0xFFFFFFFF;
				tdi->slotid=castspell->slot;
				QueuePacket(outapp);
				safe_delete(outapp);
				if ((item->Common.Click.Type == ET_ClickEffect) || (item->Common.Click.Type == ET_Expendable) || (item->Common.Click.Type == ET_EquipClick) || (item->Common.Click.Type == ET_ClickEffect2))
				{
					CastSpell(item->Common.Click.Effect, castspell->target_id, castspell->slot, item->Common.CastTime, 0, 0, castspell->inventoryslot);
				}
				else
				{
					Message(0, "Error: unknown item->Common.Click.Type (0x%02x)", item->Common.Click.Type);
				}
			}
			else
			{
				Message(0, "Error: item not found in inventory slot #%i", castspell->inventoryslot);
				InterruptSpell(castspell->spell_id);
			}
		}
		else
		{
			Message(0, "Error: castspell->inventoryslot >= 30 (0x%04x)", castspell->inventoryslot);
			InterruptSpell(castspell->spell_id);
		}
	}
	else	// ability, or regular memmed spell
	{
		int16 spell_to_cast = 0;
		
		//current client seems to send LH in slot 8 now...
		if(castspell->slot == ABILITY_SPELL_SLOT &&
			castspell->spell_id == SPELL_LAY_ON_HANDS && GetClass() == PALADIN) {
			if(!p_timers.Expired(pTimerLayHands)) {
				Message(13,"Ability recovery time not yet met.");
				return;
			}
			spell_to_cast = SPELL_LAY_ON_HANDS;
			p_timers.Start(pTimerLayHands, LayOnHandsReuseTime);
			//database.UpdateAATimers(CharacterID(),LayOnHandsReuseTime,0, 87);//72 minutes
			AbilityTimer=true;
			
		} else if(castspell->slot == ABILITY_SPELL_SLOT &&
			(castspell->spell_id == SPELL_HARM_TOUCH
				|| castspell->spell_id == SPELL_HARM_TOUCH2
			) && GetClass() == SHADOWKNIGHT) {
			
			if(!p_timers.Expired(pTimerHarmTouch)) {
				Message(13,"Ability recovery time not yet met.");
				return;
			}
			
			if(GetLevel() < 40)
				spell_to_cast = SPELL_HARM_TOUCH;
			else
				spell_to_cast = SPELL_HARM_TOUCH2;
			p_timers.Start(pTimerHarmTouch, HarmTouchReuseTime);
			//database.UpdateAATimers(CharacterID(),HarmTouchReuseTime,0, 89);//72 minutes
			AbilityTimer=true;
		}
		
		//handle disciplines, OLD, they keep changing this
		if(castspell->slot == DISCIPLINE_SPELL_SLOT) {
			if(!UseDiscipline(castspell->spell_id, castspell->target_id)) {
				printf("Unknown ability being used by %s, spell being cast is: %i\n",GetName(),castspell->spell_id);
				InterruptSpell(castspell->spell_id);
			}
			return;
		}
		
		if(castspell->slot < MAX_PP_MEMSPELL)
		{
			spell_to_cast = m_pp.mem_spells[castspell->slot];
			if(spell_to_cast != castspell->spell_id)
			{
				InterruptSpell(castspell->spell_id); //CHEATER!!!
				return;
			}
		}
		/*
		these are coming through with slot 8 now...
		else if(castspell->slot == 9)	//discipline, LoH, HT, etc
		{
			if(GetClass() == PALADIN && castspell->spell_id == SPELL_LAY_ON_HANDS)
			{
				spell_to_cast = SPELL_LAY_ON_HANDS;
				p_timers.Start(pTimerLayHands, LayOnHandsReuseTime);
				CastSpell(spell_to_cast, castspell->target_id, castspell->slot);
			}
			else if(GetClass() == SHADOWKNIGHT
				&& (castspell->spell_id == SPELL_HARM_TOUCH || castspell->spell_id == SPELL_HARM_TOUCH2))
			{
				if(GetLevel() < 40)
					spell_to_cast = SPELL_HARM_TOUCH;
				else
					spell_to_cast = SPELL_HARM_TOUCH2;
				p_timers.Start(pTimerHarmTouch, HarmTouchReuseTime);
			}
			else*/
			//try disciplines
		AbilityTimer=true;
		
		CastSpell(spell_to_cast, castspell->target_id, castspell->slot);
	}
	return;
}

void Client::Handle_OP_DeleteItem(const EQZonePacket *app)
{
	if (app->size != sizeof(DeleteItem_Struct)) {
		cout << "Wrong size on OP_DeleteItem. Got: " << app->size << ", Expected: " << sizeof(DeleteItem_Struct) << endl;
		return;
	}
	
	DeleteItem_Struct* alc = (DeleteItem_Struct*) app->pBuffer;
	const ItemInst *inst = GetInv().GetItem(alc->from_slot);
	if (inst && inst->GetItem()->Common.ItemType == ItemTypeAlcohol) {
		//TODO: grant alcohol bonuses..?
		CheckIncreaseSkill(ALCOHOL_TOLERANCE,200);
	}
	DeleteItemInInventory(alc->from_slot, 1);
	
	return;
}

void Client::Handle_OP_CombatAbility(const EQZonePacket *app)
{
	if (app->size != sizeof(CombatAbility_Struct)) {
		cout << "Wrong size on OP_CombatAbility. Got: " << app->size << ", Expected: " << sizeof(CombatAbility_Struct) << endl;
		return;
	}
	OPCombatAbility(app);			
	return;
}

void Client::Handle_OP_Taunt(const EQZonePacket *app)
{
	if (app->size != sizeof(ClientTarget_Struct)) {
		cout << "Wrong size on OP_Taunt. Got: " << app->size << ", Expected: "<< sizeof(ClientTarget_Struct) << endl;
		return;
	}
	
	if(!p_timers.Expired(pTimerTaunt, false)) {
				Message(13,"Ability recovery time not yet met.");
				return;
	}
	p_timers.Start(pTimerTaunt, TauntReuseTime-1);
	
	if(GetTarget() == NULL || !GetTarget()->IsNPC())
		return;
	
	Taunt(GetTarget()->CastToNPC(), false);
	return;
}

void Client::Handle_OP_InstillDoubt(const EQZonePacket *app)
{
	//packet is empty as of 12/14/04
	
	if(!p_timers.Expired(pTimerInstillDoubt, false)) {
				Message(13,"Ability recovery time not yet met.");
				return;
	}
	p_timers.Start(pTimerInstillDoubt, InstillDoubtReuseTime-1);
	
	InstillDoubt(target);
	return;
}

void Client::Handle_OP_RezzAnswer(const EQZonePacket *app)
{
	OPRezzAnswer(app);
	return;
}

void Client::Handle_OP_GMSummon(const EQZonePacket *app)
{
	if (app->size != sizeof(GMSummon_Struct)) {
		cout << "Wrong size on OP_GMSummon. Got: " << app->size << ", Expected: " << sizeof(GMSummon_Struct) << endl;
		return;
	}
	OPGMSummon(app);
	return;
}

void Client::Handle_OP_TradeRequest(const EQZonePacket *app)
{
	// Client requesting a trade session from an npc/client
	// Trade session not started until OP_TradeRequestAck is sent
	TradeRequest_Struct* msg = (TradeRequest_Struct*) app->pBuffer;
	trade->Start(msg->to_mob_id);
	
	BreakInvis();
	
	// Pass trade request on to recipient
	Mob* with = trade->With();
	if (with && with->IsClient()) {
		with->CastToClient()->QueuePacket(app);
	}
	else if (with) {
		//npcs always accept
		EQZonePacket* outapp = new EQZonePacket(OP_TradeRequestAck, sizeof(TradeRequest_Struct));
		TradeRequest_Struct* acc = (TradeRequest_Struct*) outapp->pBuffer;
		acc->from_mob_id = msg->to_mob_id;
		acc->to_mob_id = msg->from_mob_id;
		FastQueuePacket(&outapp);
		safe_delete(outapp);
	}
	return;
}

void Client::Handle_OP_TradeRequestAck(const EQZonePacket *app)
{
	// Trade request recipient is acknowledging they are able to trade
	// After this, the trade session has officially started
	//TradeRequest_Struct* msg = (TradeRequest_Struct*) app->pBuffer;
	
	// Send ack on to trade initiator if client
	Mob* with = trade->With();
	if (with && with->IsClient()) {
		with->CastToClient()->QueuePacket(app);
	}
	return;
}

void Client::Handle_OP_CancelTrade(const EQZonePacket *app)
{
	Mob* with = trade->With();
	if (with && with->IsClient()) {
		CancelTrade_Struct* msg = (CancelTrade_Struct*) app->pBuffer;
		
		// Forward cancel packet to other client
		msg->fromid = with->GetID();
		//msg->action = 1;
	
		with->CastToClient()->QueuePacket(app);
		
		// Put trade items/cash back into inventory
		FinishTrade(this);
		trade->Reset();
	}
	else if(with){
		CancelTrade_Struct* msg = (CancelTrade_Struct*) app->pBuffer;
		msg->fromid = with->GetID();
		QueuePacket(app);
		FinishTrade(this);
		trade->Reset();
	}
	return;
}

void Client::Handle_OP_TradeAcceptClick(const EQZonePacket *app)
{
	Mob* with = trade->With();
	trade->state = TradeAccepted;
	if (with && with->IsClient()) {
		// Have both accepted?
		Client* other = with->CastToClient();
		other->QueuePacket(app);
		
		if (other->trade->state == trade->state) {
			other->trade->state = TradeCompleting;
			trade->state = TradeCompleting;
			
			if (CheckTradeLoreConflict(other) || other->CheckTradeLoreConflict(this))
			{
				Message_StringID(13,104);
				other->Message_StringID(13,104);
				this->FinishTrade(this);
				other->FinishTrade(other);
				other->trade->Reset();
				trade->Reset();
			} else {
				// Audit trade to database for both trade streams
				other->trade->LogTrade();
				trade->LogTrade();
			
				// Perform actual trade
				this->FinishTrade(other);
				other->FinishTrade(this);
				other->trade->Reset();
				trade->Reset();
			}
			// All done
			EQZonePacket* outapp = new EQZonePacket(OP_FinishTrade, 0);
			other->QueuePacket(outapp);
			this->FastQueuePacket(&outapp);
		}
	}
	else if(with){
		EQZonePacket* outapp = new EQZonePacket(OP_FinishTrade,0);
		QueuePacket(outapp);
		safe_delete(outapp);
		FinishTrade(with->CastToNPC());						
	}
	
	return;
}

void Client::Handle_OP_BoardBoat(const EQZonePacket *app)
{
	char *boatname;
	this->IsOnBoat=true;
	boatname = new char[app->size-4];
	memset(boatname, 0, app->size-4);
	memcpy(boatname, app->pBuffer, app->size-4);
	printf("%s has gotten on the boat %s\n",GetName(),boatname);
	Mob* boat = entity_list.GetMob(boatname);
	if (boat){
		boat->CastToNPC()->passengers=true;
	}
	safe_delete(boatname);
	return;
}

void Client::Handle_OP_LeaveBoat(const EQZonePacket *app)
{
	this->IsOnBoat=false;
	return;
}

void Client::Handle_OP_RandomReq(const EQZonePacket *app)
{
	const RandomReq_Struct* rndq = (const RandomReq_Struct*) app->pBuffer;
	uint32 randLow=rndq->low > rndq->high?rndq->high:rndq->low;
	uint32 randHigh=rndq->low > rndq->high?rndq->low:rndq->high;
	uint32 randResult;

	if(randLow==0 && randHigh==0)
	{	// defaults
		randLow=0;
		randHigh=100;
	}
	randResult=MakeRandomInt(randLow, randHigh);

	EQZonePacket* outapp = new EQZonePacket(OP_RandomReply, sizeof(RandomReply_Struct));
	RandomReply_Struct* rr = (RandomReply_Struct*)outapp->pBuffer;
	rr->low=randLow;
	rr->high=randHigh;
	rr->result=randResult;
	strcpy(rr->name, GetName());
	entity_list.QueueCloseClients(this, outapp, false, 400);
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_Buff(const EQZonePacket *app)
{
	if (app->size != sizeof(SpellBuffFade_Struct))
	{
		LogFile->write(EQEMuLog::Error, "Size mismatch in OP_Buff. expected %i got %i", sizeof(SpellBuffFade_Struct), app->size);
		DumpPacket(app);
		return;
	}
	
	SpellBuffFade_Struct* sbf = (SpellBuffFade_Struct*) app->pBuffer;
	if(sbf->spellid == 0xFFFF)
		QueuePacket(app);
	else
		BuffFadeBySpellID(sbf->spellid);

	return;
}

void Client::Handle_OP_GMHideMe(const EQZonePacket *app)
{
	int reqlevel = database.CommandRequirement("!gm");
	reqlevel = reqlevel == 255 ? minStatusToUseGMCommands : reqlevel;
	if(this->Admin() < reqlevel) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/hideme");
		return;
	}
	SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
	SetHideMe(sa->parameter == 1);
	return;

}

void Client::Handle_OP_GMNameChange(const EQZonePacket *app)
{
	const GMName_Struct* gmn = (const GMName_Struct *)app->pBuffer;
	if(this->Admin() < minStatusToUseGMCommands){
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/name");
		return;
	}
	Client* client = entity_list.GetClientByName(gmn->oldname);
	LogFile->write(EQEMuLog::Status, "GM(%s) changeing players name. Old:%s New:%s", GetName(), gmn->oldname, gmn->newname);
	bool usedname = database.CheckUsedName((const char*) gmn->newname);
	if(client==0) {
		Message(13, "%s not found for name change. Operation failed!", gmn->oldname);
		return;
	}
	if((strlen(gmn->newname) > 63) || (strlen(gmn->newname) == 0)) {
		Message(13, "Invalid number of characters in new name (%s).", gmn->newname);
		return;
	}
	if (!usedname) {
		Message(13, "%s is already in use.  Operation failed!", gmn->newname);
		return;

	}
	database.UpdateName(gmn->oldname, gmn->newname);
	strcpy(client->name, gmn->newname);
	client->Save();
	
	if(gmn->badname==1) {
		database.AddToNameFilter(gmn->oldname);
	}
	EQZonePacket* outapp = app->Copy();
	GMName_Struct* gmn2 = (GMName_Struct*) outapp->pBuffer;
	gmn2->unknown[0] = 1;
	gmn2->unknown[1] = 1;
	gmn2->unknown[2] = 1;
	entity_list.QueueClients(this, outapp, false);
	safe_delete(outapp);
	UpdateWho();
	return;
}

void Client::Handle_OP_GMKill(const EQZonePacket *app)
{
	if(this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/kill");
		return;
	}
	GMKill_Struct* gmk = (GMKill_Struct *)app->pBuffer;
	Mob* obj = entity_list.GetMob(gmk->name);
	Client* client = entity_list.GetClientByName(gmk->name);
	if(obj!=0) {
		if(client!=0) {
			entity_list.QueueClients(this,app);
		}
		else {
			obj->Kill();
		}
	}
	else {
		if (!worldserver.Connected())
			Message(0, "Error: World server disconnected");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_KillPlayer;
			pack->size = sizeof(ServerKillPlayer_Struct);
			pack->pBuffer = new uchar[pack->size];
			ServerKillPlayer_Struct* skp = (ServerKillPlayer_Struct*) pack->pBuffer;
			strcpy(skp->gmname, gmk->gmname);
			strcpy(skp->target, gmk->name);
			skp->admin = this->Admin();
			worldserver.SendPacket(pack);
			safe_delete(pack);
		}
	}
	return;
}

void Client::Handle_OP_GMLastName(const EQZonePacket *app)
{
	if (app->size != sizeof(GMLastName_Struct)) {
		cout << "Wrong size on OP_GMLastName. Got: " << app->size << ", Expected: " << sizeof(GMLastName_Struct) << endl;
		return;
	}
	GMLastName_Struct* gmln = (GMLastName_Struct*) app->pBuffer;
	if (strlen(gmln->lastname) >= 64) {
		Message(13, "/LastName: New last name too long. (max=63)");
	}
	else {
		Client* client = entity_list.GetClientByName(gmln->name);
		if (client == 0) {
			Message(13, "/LastName: %s not found", gmln->name);
		}
		else {
			if (this->Admin() < minStatusToUseGMCommands) {
				Message(13, "Your account has been reported for hacking.");
				database.SetHackerFlag(client->account_name, client->name, "/lastname");
				return;
			}
			else

				client->ChangeLastName(gmln->lastname);
		}
		gmln->unknown[0] = 1;
		gmln->unknown[1] = 1;
		gmln->unknown[2] = 1;
		gmln->unknown[3] = 1;
		entity_list.QueueClients(this, app, false);
	}
	return;
}

void Client::Handle_OP_GMToggle(const EQZonePacket *app)
{
	if (app->size != sizeof(GMToggle_Struct)) {
		cout << "Wrong size on OP_GMToggle. Got: " << app->size << ", Expected: " << sizeof(GMToggle_Struct) << endl;
		return;
	}
	if (this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/toggle");
		return;
	}
	GMToggle_Struct *ts = (GMToggle_Struct *) app->pBuffer;
	if (ts->toggle == 0) {
		this->Message_StringID(0,TOGGLE_OFF);
		//Message(0, "Turning tells OFF");
		tellsoff = true;
	}
	else if (ts->toggle == 1) {
		//Message(0, "Turning tells ON");
		this->Message_StringID(0,TOGGLE_ON);
		tellsoff = false;
	}
	else {
		Message(0, "Unkown value in /toggle packet");
	}
	UpdateWho();
	return;
}

void Client::Handle_OP_LFGCommand(const EQZonePacket *app)
{
	if (app->size != sizeof(LFG_Struct)) {
		cout << "Wrong size on OP_LFGCommand. Got: " << app->size << ", Expected: " << sizeof(LFG_Struct) << endl;
		DumpPacket(app);
		return;
	}
	
	// Process incoming packet
	LFG_Struct* lfg = (LFG_Struct*) app->pBuffer;
	if (lfg->value == 1) {
		LFG = true;
	}
	else if (lfg->value == 0) {
		LFG = false;
	}
	else
		Message(0, "Error: unknown LFG value");
	UpdateWho();
	
	// Issue outgoing packet to notify other clients
	EQZonePacket* outapp = new EQZonePacket(OP_LFGAppearance, sizeof(LFG_Appearance_Struct));
	LFG_Appearance_Struct* lfga = (LFG_Appearance_Struct*)outapp->pBuffer;
	lfga->spawn_id = this->GetID();
	lfga->lfg = (uint8)LFG;
	
	entity_list.QueueClients(this, outapp, true);
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_GMGoto(const EQZonePacket *app)
{
	if (app->size != sizeof(GMSummon_Struct)) {
		cout << "Wrong size on OP_GMGoto. Got: " << app->size << ", Expected: " << sizeof(GMSummon_Struct) << endl;
		return;
	}
	if (this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/goto");
		return;
	}
	GMSummon_Struct* gmg = (GMSummon_Struct*) app->pBuffer;
	Mob* gt = entity_list.GetMob(gmg->charname);
	if (gt != NULL) {
		this->MovePC(zone->GetZoneID(), gt->GetX(), gt->GetY(), gt->GetZ());
	}
	else if (!worldserver.Connected())
		Message(0, "Error: World server disconnected.");
	else {
		ServerPacket* pack = new ServerPacket;
		pack->opcode = ServerOP_GMGoto;
		pack->size = sizeof(ServerGMGoto_Struct);
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, pack->size);
		ServerGMGoto_Struct* wsgmg = (ServerGMGoto_Struct*) pack->pBuffer;
		strcpy(wsgmg->myname, this->GetName());
		strcpy(wsgmg->gotoname, gmg->charname);
		wsgmg->admin = admin;
		worldserver.SendPacket(pack);
		safe_delete(pack);
	}
	return;
}

void Client::Handle_OP_TraderShop(const EQZonePacket *app)
{
	TraderClick_Struct* tcs= (TraderClick_Struct*)app->pBuffer;
	if(app->size!=sizeof(TraderClick_Struct))
		return;
	
	EQZonePacket* outapp = new EQZonePacket(OP_TraderShop, sizeof(TraderClick_Struct));
	TraderClick_Struct* outtcs=(TraderClick_Struct*)outapp->pBuffer;
	Client* tmp = entity_list.GetClientByID(tcs->traderid);
	if (tmp)
		outtcs->approval=tmp->WithCustomer();
	else
		return;
	outtcs->traderid=tcs->traderid;
	QueuePacket(outapp);
	if(outtcs->approval)
		this->BulkSendTraderInventory(tmp->CharacterID());
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_ShopRequest(const EQZonePacket *app)
{
	// this works
	Merchant_Click_Struct* mc=(Merchant_Click_Struct*)app->pBuffer;
	if (app->size != sizeof(Merchant_Click_Struct))
		return;
	// Send back opcode OP_ShopRequest - tells client to open merchant window.
	//EQZonePacket* outapp = new EQZonePacket(OP_ShopRequest, sizeof(Merchant_Click_Struct));
	//Merchant_Click_Struct* mco=(Merchant_Click_Struct*)outapp->pBuffer;
	int merchantid=0;
	Mob* tmp = entity_list.GetMob(mc->npcid);
	
	if (tmp == 0 || !tmp->IsNPC() || tmp->GetClass() != MERCHANT)
		return;
	
	//you have to be somewhat close to them to be properly using them
	if(DistNoRoot(*tmp) > USE_NPC_RANGE2)
		return;
	
	merchantid=tmp->CastToNPC()->MerchantType;

	int action = 1;
	if(merchantid == 0)
	{
		EQZonePacket* outapp = new EQZonePacket(OP_ShopRequest, sizeof(Merchant_Click_Struct));
		Merchant_Click_Struct* mco=(Merchant_Click_Struct*)outapp->pBuffer;
		mco->npcid = mc->npcid;
		mco->playerid = 0;
		mco->unknown[0] = 1;
		mco->unknown[1] = 0x00;
		mco->unknown[2] = 0x00;
		mco->unknown[3] = 0x00;
		mco->unknown[4] = 0x66;
		mco->unknown[5] = 0x66;
		mco->unknown[6] = 0x86;
		mco->unknown[7] = 0x3F;
		QueuePacket(outapp);
		safe_delete(outapp);
		return;
	}
	if(tmp->IsEngaged()){
		this->Message_StringID(0,MERCHANT_BUSY);
		action = 0;
	}
	if (GetFeigned() || IsInvisible())
	{
		Message(0,"You cannot use a merchant right now.");
		action = 0;
	}
	int factionlvl = GetFactionLevel(CharacterID(), tmp->CastToNPC()->GetNPCTypeID(), GetRace(), GetClass(), GetDeity(), tmp->CastToNPC()->GetPrimaryFaction(), tmp);
	if(factionlvl >= 6 && factionlvl != 9)
	{
		Message(0,"I will not deal with one such as you!");
		action = 0;
	}
	if (tmp->Charmed())
	{
		action = 0;
	}

	EQZonePacket* outapp = new EQZonePacket(OP_ShopRequest, sizeof(Merchant_Click_Struct));
	Merchant_Click_Struct* mco=(Merchant_Click_Struct*)outapp->pBuffer;

	mco->npcid = mc->npcid;
	mco->playerid = 0;
	mco->unknown[0] = action; // Merchant command 0x01 = open
	mco->unknown[1] = 0x00;
	mco->unknown[2] = 0x00;
	mco->unknown[3] = 0x00;
	mco->unknown[4] = 0xE0;
	mco->unknown[5] = 0xCB; // 32
	mco->unknown[6] = 0x90; // 139
	mco->unknown[7] = 0x3F; // 63

	outapp->priority = 6;
	QueuePacket(outapp);
	safe_delete(outapp);

	if (action == 1)
		BulkSendMerchantInventory(merchantid,tmp->GetNPCTypeID());
	
	return;
}

void Client::Handle_OP_Bazaar(const EQZonePacket *app)
{
	if (app->size==sizeof(BazaarSearch_Struct)) {
		BazaarSearch_Struct* bss= (BazaarSearch_Struct*)app->pBuffer;
		this->SendBazaarResults(bss->traderid,bss->class_,bss->race,bss->stat,bss->slot,bss->type,bss->name,bss->minprice,bss->maxprice);
	}
	else if (app->size==sizeof(BazaarWelcome_Struct)) {
		BazaarWelcome_Struct* bws = (BazaarWelcome_Struct*)app->pBuffer;
		if (bws->beginning.action==9)
			SendBazaarWelcome();
	}
	else
		LogFile->write(EQEMuLog::Error, "Malformed BazaarSearch_Struct packet received, ignoring...\n");
	return;
}

void Client::Handle_OP_ShopPlayerBuy(const EQZonePacket *app)
{
	RDTSC_Timer t1;
	t1.start();
	Merchant_Sell_Struct* mp=(Merchant_Sell_Struct*)app->pBuffer;
#if EQDEBUG >= 5
		LogFile->write(EQEMuLog::Debug, "%s, purchase item..", GetName());
		DumpPacket(app);
#endif

	int merchantid;
	bool tmpmer_used = false;
	Mob* tmp = entity_list.GetMob(mp->npcid);
	
	if (tmp == 0 || !tmp->IsNPC() || tmp->GetClass() != MERCHANT)
		return;
	
	//you have to be somewhat close to them to be properly using them
	if(DistNoRoot(*tmp) > USE_NPC_RANGE2)
		return;
	
	merchantid=tmp->CastToNPC()->MerchantType;
	
	uint32 item_id = 0;
	std::list<MerchantList> merlist = zone->merchanttable[merchantid];
	std::list<MerchantList>::const_iterator itr;
	for(itr = merlist.begin();itr != merlist.end();itr++){
		MerchantList ml = *itr;
		if(mp->itemslot == ml.slot){
			item_id = ml.item;
			break;
		}
	}
	const Item_Struct* item = NULL;
	int32 prevcharges = 0;
	if (item_id == 0) { //check to see if its on the temporary table
		std::list<TempMerchantList> tmp_merlist = zone->tmpmerchanttable[tmp->GetNPCTypeID()];
		std::list<TempMerchantList>::const_iterator tmp_itr;
		TempMerchantList ml;
		for(tmp_itr = tmp_merlist.begin();tmp_itr != tmp_merlist.end();tmp_itr++){
			ml = *tmp_itr;
			if(mp->itemslot == ml.slot){
				item_id = ml.item;
				tmpmer_used = true;
				prevcharges = ml.charges;
				break;
			}
		}
	} 
	item = database.GetItem(item_id);
	if (!item){
		//error finding item, client didnt get the update packet for whatever reason, roleplay a tad
		Message(15,"%s tells you 'Sorry, that item is for display purposes only.' as they take the item off the shelf.",tmp->GetCleanName());						
		EQZonePacket* delitempacket = new EQZonePacket(OP_ShopDelItem, sizeof(Merchant_DelItem_Struct));
		Merchant_DelItem_Struct* delitem = (Merchant_DelItem_Struct*)delitempacket->pBuffer;
		delitem->itemslot = mp->itemslot;
		delitem->npcid = mp->npcid;
		delitem->playerid = mp->playerid;
		delitempacket->priority = 6;
		entity_list.QueueCloseClients(tmp,delitempacket); //que for anyone that could be using the merchant so they see the update
		safe_delete(delitempacket);
		return;
	}
	if (CheckLoreConflict(item))
	{
		Message(15,"You can only have one of a lore item.");
		return;
	}
	
	EQZonePacket* outapp = new EQZonePacket(OP_ShopPlayerBuy, sizeof(Merchant_Sell_Struct));
	Merchant_Sell_Struct* mpo=(Merchant_Sell_Struct*)outapp->pBuffer;
	mpo->quantity = mp->quantity;
	mpo->playerid = mp->playerid;
	mpo->npcid = mp->npcid;
	mpo->itemslot=mp->itemslot;
	
	sint16 freeslotid=0;
	ItemInst* inst = ItemInst::Create(item, mp->quantity);

	bool stacked = TryStacking(inst);
	if(!stacked)
		freeslotid = m_inv.FindFreeSlot(false, true, item->Size);
	
	//make sure we are not completely full...
	if(freeslotid == SLOT_CURSOR) {
		if(m_inv.GetItem(SLOT_CURSOR) != NULL) {
			Message(13, "You do not have room for any more items.");
			safe_delete(outapp);
			safe_delete(inst);
			return;
		}
	}
	
	mpo->price = (item->Price*127/100)*mp->quantity;
	if(freeslotid == SLOT_INVALID || !TakeMoneyFromPP(mpo->price))
	{
		safe_delete(outapp);
		safe_delete(inst);
		return;
	}

	string packet;
	if(tmpmer_used && (mp->quantity > prevcharges))
		mp->quantity = prevcharges;
	else if(mp->quantity==1 && item->Common.MaxCharges>0 && item->Common.MaxCharges<255)
		mp->quantity=item->Common.MaxCharges;
	
	if (!stacked && inst) {
		PutItemInInventory(freeslotid, *inst);
		SendItemPacket(freeslotid, inst, ItemPacketTrade);
	}
	else if(!stacked){
		LogFile->write(EQEMuLog::Error, "OP_ShopPlayerBuy: item->ItemClass Unknown! Type: %i", item->ItemClass);
	}

	QueuePacket(outapp);
	if(inst && tmpmer_used){
		sint32 new_charges = prevcharges - mp->quantity;
		zone->SaveTempItem(merchantid, tmp->GetNPCTypeID(),item_id,new_charges);
		if(new_charges<=0){
			EQZonePacket* delitempacket = new EQZonePacket(OP_ShopDelItem, sizeof(Merchant_DelItem_Struct));
			Merchant_DelItem_Struct* delitem = (Merchant_DelItem_Struct*)delitempacket->pBuffer;
			delitem->itemslot = mp->itemslot;
			delitem->npcid = mp->npcid;
			delitem->playerid = mp->playerid;
			delitempacket->priority = 6;
			entity_list.QueueClients(tmp,delitempacket); //que for anyone that could be using the merchant so they see the update
			safe_delete(delitempacket);
		}
	}
	safe_delete(inst);
	safe_delete(outapp);
	
	if (zone->merchantvar!=0){
		if (zone->merchantvar==7){
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if ((admin>=10) && (admin<20)){
			if ((zone->merchantvar<8) && (zone->merchantvar>5))
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if (admin<=20){
			if ((zone->merchantvar<8) && (zone->merchantvar>4))
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if (admin<=80){
			if ((zone->merchantvar<8) && (zone->merchantvar>3))
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if (admin<=100){
			if ((zone->merchantvar<9) && (zone->merchantvar>2))
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if (admin<=150){
			if (((zone->merchantvar<8) && (zone->merchantvar>1)) || (zone->merchantvar==9))
				LogMerchant(this,tmp,mpo,item,true);
		}
		else if (admin<=255){
			if ((zone->merchantvar<8) && (zone->merchantvar>0))
				LogMerchant(this,tmp,mpo,item,true);	
		}
	}
	t1.stop();
	cout << "At 1: " << t1.getDuration() << endl;
	return;
}

void Client::Handle_OP_ShopPlayerSell(const EQZonePacket *app)
{
	RDTSC_Timer t1(true);
	Merchant_Purchase_Struct* mp=(Merchant_Purchase_Struct*)app->pBuffer;
	
	Mob* vendor = entity_list.GetMob(mp->npcid);
	
	if (vendor == 0 || !vendor->IsNPC() || vendor->GetClass() != MERCHANT)
		return;
	
	//you have to be somewhat close to them to be properly using them
	if(DistNoRoot(*vendor) > USE_NPC_RANGE2)
		return;
	
	int32 price=0;
	int32 itemid = GetItemIDAt(mp->itemslot);
	if(itemid == 0)
		return;
	const Item_Struct* item = database.GetItem(itemid);
	ItemInst* inst = GetInv().GetItem(mp->itemslot);
	if(!inst){
		Message(13,"You seemed to have misplaced that item..");
		return;
	}
	if(mp->quantity > 1 && (sint16)mp->quantity > inst->GetCharges())
		return;

	if (item){
		price=(int)((item->Price*mp->quantity)*.884);
		AddMoneyToPP(price,false);
		if (zone->merchantvar!=0){
			if (zone->merchantvar==7) {
				LogMerchant(this,vendor,mp,item,false);
			}
			else if ((admin>=10) && (admin<20)) {
				if ((zone->merchantvar<8) && (zone->merchantvar>5))
					LogMerchant(this,vendor,mp,item,false);
			}
			else if (admin<=20) {
				if ((zone->merchantvar<8) && (zone->merchantvar>4))
					LogMerchant(this,vendor,mp,item,false);
			}
			else if (admin<=80) {
				if ((zone->merchantvar<8) && (zone->merchantvar>3))
					LogMerchant(this,vendor,mp,item,false);
			}
			else if (admin<=100) {
				if ((zone->merchantvar<9) && (zone->merchantvar>2))
					LogMerchant(this,vendor,mp,item,false);
			}
			else if (admin<=150) {
				if (((zone->merchantvar<8) && (zone->merchantvar>1)) || (zone->merchantvar==9))
					LogMerchant(this,vendor,mp,item,false);
			}
			else if (admin<=255) {
				if ((zone->merchantvar<8) && (zone->merchantvar>0))
					LogMerchant(this,vendor,mp,item,false);	
			}
		}
	}
	else
		Message(0, "Error #1, item == 0");
	
	
	if (item && inst->IsStackable())
	{
		unsigned int i_quan = inst->GetCharges();
		if (mp->quantity > i_quan)
			mp->quantity = i_quan;
	}
	else
	{
		mp->quantity = 1;
	}
	int freeslot = 0;
	int charges = 0;
	if(inst->IsStackable())
		charges = mp->quantity;
	else
		charges = inst->GetCharges();
	if((freeslot = zone->SaveTempItem(vendor->CastToNPC()->MerchantType, vendor->GetNPCTypeID(),itemid,charges,true)) > 0){
		ItemInst* inst2 = inst->Clone();
		inst2->SetPrice(item->Price*127/100);
		inst2->SetMerchantSlot(freeslot);
		if(inst2->IsStackable())
			inst2->SetCharges(mp->quantity);
		SendItemPacket(freeslot-1, inst2, ItemPacketMerchant);
		safe_delete(inst2);
	}

	// Now remove the item from the player, this happens irrguardless of outcome
	if (!inst->IsStackable())
		this->DeleteItemInInventory(mp->itemslot,0,false);
	else
		this->DeleteItemInInventory(mp->itemslot,mp->quantity,false);
	
	EQZonePacket* outapp = new EQZonePacket(OP_ShopPlayerSell, sizeof(Merchant_Purchase_Struct));
	Merchant_Purchase_Struct* mco=(Merchant_Purchase_Struct*)outapp->pBuffer;
	mco->npcid = vendor->GetID();
	mco->itemslot=mp->itemslot;
	mco->quantity=mp->quantity;
	mco->price=price;
	QueuePacket(outapp);
	safe_delete(outapp);
	t1.start();
	Save(1);	
	t1.stop();
	cout << "Save took: " << t1.getDuration() << endl;
	return;
}

void Client::Handle_OP_ShopEnd(const EQZonePacket *app)
{
	//EQZonePacket* outapp = new EQZonePacket(OP_ShopEndConfirm, 2);
	//outapp->pBuffer[0] = 0x0a;
	//outapp->pBuffer[1] = 0x66;
	//QueuePacket(outapp);
	//safe_delete(outapp);
	//Save();
	return;
}

void Client::Handle_OP_CloseContainer(const EQZonePacket *app)
{
	if (app->size != sizeof(CloseContainer_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size on CloseContainer_Struct: Expected %i, Got %i",
			sizeof(CloseContainer_Struct), app->size);
		return;
	}

	SetTradeskillObject(NULL);
	
	ClickObjectAck_Struct* oos = (ClickObjectAck_Struct*)app->pBuffer;
	Entity* entity = entity_list.GetEntityObject(oos->drop_id);
	if (entity && entity->IsObject()) {
		Object* object = entity->CastToObject();
		object->Close();
	}
	return;
}

void Client::Handle_OP_ClickObject(const EQZonePacket *app)
{
	if (app->size != sizeof(ClickObject_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size on ClickObject_Struct: Expected %i, Got %i",
			sizeof(ClickObject_Struct), app->size);
		return;
	}
	
	ClickObject_Struct* click_object = (ClickObject_Struct*)app->pBuffer;
	Entity* entity = entity_list.GetID(click_object->drop_id);
	//TODO: should enforce range checking here.
	if (entity && entity->IsObject()) {
		Object* object = entity->CastToObject();
		object->HandleClick(this, click_object);
	}
	return;
}

void Client::Handle_OP_RecipesFavorite(const EQZonePacket *app)
{
	if (app->size != sizeof(TradeskillFavorites_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for TradeskillFavorites_Struct: Expected: %i, Got: %i",
			sizeof(TradeskillFavorites_Struct), app->size);
		return;
	}
	
	TradeskillFavorites_Struct* tsf = (TradeskillFavorites_Struct*)app->pBuffer;
	
	uint32 tskill = Object::TypeToSkill(tsf->object_type);
	if(tskill == 0) {
		LogFile->write(EQEMuLog::Error, "Unknown container type for OP_RecipesFavorite: %d\n", tsf->object_type);
		return;
	}
	
char *query = 0;
	char buf[1100];	//gotta be big enough for 100 IDs
	
	bool first = true;
	uint8 r;
	char *pos = buf;
	
	//Assumes item IDs are <10 characters long
	for(r = 0; r < 100; r++) {
		if(tsf->favorite_recipes[r] == 0)
			break;	//assume the first 0 is the end...
		
		if(first) {
			pos += snprintf(pos, 10, "%u", tsf->favorite_recipes[r]);
			first = false;
		} else {
			pos += snprintf(pos, 10, ",%u", tsf->favorite_recipes[r]);
		}
	}
	
	if(first)	//no favorites....
		return;
	
	//To be a good kid, I should move this SQL somewhere else...
	//but im lazy right now, so it stays here
	uint32 qlen = 0;
	qlen = MakeAnyLenString(&query, "SELECT tr.id,tr.name,tr.trivial,SUM(tre.componentcount) "
		" FROM tradeskill_recipe AS tr "
		" LEFT JOIN tradeskill_recipe_entries AS tre ON tr.id=tre.recipe_id "
		" WHERE tr.id IN (%s) AND tradeskill=%lu "
		" GROUP BY tr.id LIMIT 100 ", buf, tskill);
	
	TradeskillSearchResults(query, qlen, tsf->object_type, tsf->some_id);
	
	safe_delete_array(query);
	return;
}

void Client::Handle_OP_RecipesSearch(const EQZonePacket *app)
{
	if (app->size != sizeof(RecipesSearch_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for RecipesSearch_Struct: Expected: %i, Got: %i",
			sizeof(RecipesSearch_Struct), app->size);
		return;
	}
	
	RecipesSearch_Struct* rss = (RecipesSearch_Struct*)app->pBuffer;
	rss->query[55] = '\0';	//just to be sure.
	
	
	uint32 tskill = Object::TypeToSkill(rss->object_type);
	if(tskill == 0) {
		LogFile->write(EQEMuLog::Error, "Unknown container type for OP_RecipesSearch: %d\n", rss->object_type);
		return;
	}
	
char *query = 0;
	char searchclause[140];	//2X rss->query + SQL crap
	
	//omit the rlike clause if query is empty
	if(rss->query[0] != 0) {
		char buf[120];	//larger than 2X rss->query
		database.DoEscapeString(buf, rss->query, strlen(rss->query));
		
		snprintf(searchclause, 139, "name rlike '%s' AND", buf);
	} else {
		searchclause[0] = '\0';
	}
	uint32 qlen = 0;
	
	//arbitrary limit of 200 recipes, makes sense to me.
	qlen = MakeAnyLenString(&query, "SELECT tr.id,tr.name,tr.trivial,SUM(tre.componentcount) "
		" FROM tradeskill_recipe AS tr "
		" LEFT JOIN tradeskill_recipe_entries AS tre ON tr.id=tre.recipe_id "
		" WHERE %s tr.trivial >= %u AND tr.trivial <= %u AND tradeskill=%lu "
		" GROUP BY tr.id LIMIT 200 ", searchclause, rss->mintrivial, rss->maxtrivial, tskill);
	
	TradeskillSearchResults(query, qlen, rss->object_type, rss->some_id);
	
	safe_delete_array(query);
	return;
}

void Client::Handle_OP_RecipeDetails(const EQZonePacket *app)
{
	if(app->size != sizeof(unsigned long)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for RecipeDetails Request: Expected: %i, Got: %i",
			sizeof(unsigned long), app->size);
		return;
	}
	unsigned long *recipe_id = (unsigned long *) app->pBuffer;
	
	SendTradeskillDetails(*recipe_id);
	
	return;
}

void Client::Handle_OP_RecipeAutoCombine(const EQZonePacket *app)
{
	if (app->size != sizeof(RecipeAutoCombine_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for RecipeAutoCombine_Struct: Expected: %i, Got: %i",
			sizeof(RecipeAutoCombine_Struct), app->size);
		return;
	}
	
	RecipeAutoCombine_Struct* rac = (RecipeAutoCombine_Struct*)app->pBuffer;
	
	Object::HandleAutoCombine(this, rac);
	return;
}

void Client::Handle_OP_TradeSkillCombine(const EQZonePacket *app)
{
	if (app->size != sizeof(NewCombine_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for NewCombine_Struct: Expected: %i, Got: %i",
			sizeof(NewCombine_Struct), app->size);
		return;
	}
	/*if (m_tradeskill_object == NULL) {
		Message(13, "Error: Server is not aware of the tradeskill container you are attempting to use");
		return;
	}*/
	
	//fixed this to work for non-world objects
	
	// Delegate to tradeskill object to perform combine
	NewCombine_Struct* in_combine = (NewCombine_Struct*)app->pBuffer;
	Object::HandleCombine(this, in_combine, m_tradeskill_object);
	return;
}

void Client::Handle_OP_ItemName(const EQZonePacket *app)
{
	if (app->size != sizeof(ItemNamePacket_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for ItemNamePacket_Struct: Expected: %i, Got: %i",
			sizeof(ItemNamePacket_Struct), app->size);
		return;
	}
	ItemNamePacket_Struct *p = (ItemNamePacket_Struct*)app->pBuffer;
	const Item_Struct *item = 0;
	if ((item = database.GetItem(p->item_id))!=NULL) {
		EQZonePacket* outapp=new EQZonePacket(OP_ItemName,sizeof(ItemNamePacket_Struct));
		p=(ItemNamePacket_Struct*)outapp->pBuffer;
		memset(p, 0, sizeof(ItemNamePacket_Struct));
		strcpy(p->name,item->Name);
		FastQueuePacket(&outapp);
	}
	return;
}

void Client::Handle_OP_AugmentItem(const EQZonePacket *app)
{
	if (app->size != sizeof(AugmentItem_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for AugmentItem_Struct: Expected: %i, Got: %i",
			sizeof(AugmentItem_Struct), app->size);
		return;
	}
	/*if (m_tradeskill_object == NULL) {
		Message(13, "Error: Server is not aware of the tradeskill container you are attempting to use");
		return;
	}*/
	
	//fixed this to work for non-world objects
	
	// Delegate to tradeskill object to perform combine
	AugmentItem_Struct* in_augment = (AugmentItem_Struct*)app->pBuffer;
	Object::HandleAugmentation(this, in_augment, m_tradeskill_object);
	return;
}

void Client::Handle_OP_ClickDoor(const EQZonePacket *app)
{
	ClickDoor_Struct* cd = (ClickDoor_Struct*)app->pBuffer;
	Doors* currentdoor = entity_list.FindDoor(cd->doorid);
	if(!currentdoor)
	{
		Message(0,"Unable to find door, please notify a GM (DoorID: %i).",cd->doorid);
	        return;
	}

	currentdoor->HandleClick(this);
	return;
}

void Client::Handle_OP_CreateObject(const EQZonePacket *app)
{
	DropItem(SLOT_CURSOR);
	return;
}

void Client::Handle_OP_FaceChange(const EQZonePacket *app)
{
	if (app->size != sizeof(FaceChange_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for OP_FaceChange: Expected: %i, Got: %i",
			sizeof(FaceChange_Struct), app->size);
		return;
	}
	
	// Notify other clients in zone
	entity_list.QueueClients(this, app, false);
	
	FaceChange_Struct* fc = (FaceChange_Struct*)app->pBuffer;
	m_pp.haircolor	= fc->haircolor;
	m_pp.beardcolor	= fc->beardcolor;
	m_pp.eyecolor1	= fc->eyecolor1;
	m_pp.eyecolor2	= fc->eyecolor2;
	m_pp.hairstyle	= fc->hairstyle;
	m_pp.face		= fc->face;
// vesuvias - appearence fix
	m_pp.beard		= fc->beard;					

	
	Save();
	Message_StringID(13,FACE_ACCEPTED);
	//Message(13, "Facial features updated.");
	return;
}

void Client::Handle_OP_GroupInvite(const EQZonePacket *app)
{
	//this seems to be the initial invite to form a group
	Handle_OP_GroupInvite2(app);
}

void Client::Handle_OP_GroupInvite2(const EQZonePacket *app)
{
	if (app->size != sizeof(GroupInvite_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for OP_GroupInvite: Expected: %i, Got: %i",
			sizeof(GroupInvite_Struct), app->size);
		return;
	}
	
	//this seems to be used for any subsequent invites into an
	//allready existing group
	
	if (app->size != sizeof(GroupInvite_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for group invite: Expected: %i, Got: %i",
			sizeof(GroupInvite_Struct), app->size);
		return;
	}
	
	if(this->GetTarget() != 0 && this->GetTarget()->IsClient()) {
		this->GetTarget()->CastToClient()->QueuePacket(app);
		return;
	}
	/*if(this->GetTarget() != 0 && this->GetTarget()->IsNPC() && this->GetTarget()->CastToNPC()->IsInteractive()) {
		if(!this->GetTarget()->CastToNPC()->IsGrouped()) {
			EQZonePacket* outapp = new EQZonePacket(OP_GroupUpdate,sizeof(GroupUpdate_Struct));
			GroupUpdate_Struct* gu = (GroupUpdate_Struct*) outapp->pBuffer;
			gu->action = 9;
			strcpy(gu->membername,GetName());
			strcpy(gu->yourname,GetTarget()->CastToNPC()->GetName());
			FastQueuePacket(&outapp);
			if (!isgrouped){
				Group* ng = new Group(this);
				entity_list.AddGroup(ng);
			}
			entity_list.GetGroupByClient(this->CastToClient())->AddMember(GetTarget());
			this->GetTarget()->CastToNPC()->TakenAction(22,this->CastToMob());
		}
		else {
			    LogFile->write(EQEMuLog::Debug, "IPC: %s already grouped.", this->GetTarget()->GetName());
		}
	}*/
	return;
}

void Client::Handle_OP_GroupAcknowledge(const EQZonePacket *app)
{
	return;
}

void Client::Handle_OP_GroupCancelInvite(const EQZonePacket *app)
{
	if (app->size != sizeof(GroupCancel_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for OP_GroupCancelInvite: Expected: %i, Got: %i",
			sizeof(GroupCancel_Struct), app->size);
		return;
	}
	
	GroupCancel_Struct* gf = (GroupCancel_Struct*) app->pBuffer;
	Mob* inviter = entity_list.GetClientByName(gf->name1);
	
	if(inviter != NULL && inviter->IsClient())
		inviter->CastToClient()->QueuePacket(app);

	database.SetGroupID(GetName(), 0);
	return;
}

void Client::Handle_OP_GroupFollow(const EQZonePacket *app)
{
	Handle_OP_GroupFollow2(app);
}

void Client::Handle_OP_GroupFollow2(const EQZonePacket *app)
{
	if (app->size != sizeof(GroupGeneric_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for OP_GroupFollow: Expected: %i, Got: %i",
			sizeof(GroupGeneric_Struct), app->size);
		return;
	}
	GroupGeneric_Struct* gf = (GroupGeneric_Struct*) app->pBuffer;
	Mob* inviter = entity_list.GetClientByName(gf->name1);
	
	if(inviter != NULL && inviter->IsClient()) {
		isgrouped = true;
		strcpy(gf->name1,inviter->GetName());
		strcpy(gf->name2,this->GetName());
		
		Group* group = entity_list.GetGroupByClient(inviter->CastToClient());
		
		if(!group){
			//Make new group
			group = new Group(inviter);
			if(!group)
				return;
			entity_list.AddGroup(group);
			
			if(group->GetID() == 0) {
				Message(13, "Unable to get new group id. Cannot create group.");
				inviter->Message(13, "Unable to get new group id. Cannot create group.");
				return;
			}
			
			//now we have a group id, can set inviter's id
			database.SetGroupID(inviter->GetName(), group->GetID());
			
			//Invite the inviter into the group first.....dont ask
			EQZonePacket* outapp=new EQZonePacket(OP_GroupUpdate,sizeof(GroupJoin_Struct));
			GroupJoin_Struct* outgj=(GroupJoin_Struct*)outapp->pBuffer;
			strcpy(outgj->membername, inviter->GetName());
			strcpy(outgj->yourname, inviter->GetName());
			outgj->action = 9;
printf("Initial group invite:\n");
DumpPacket(outapp);
			inviter->CastToClient()->QueuePacket(outapp);
			safe_delete(outapp);
		}
		if(!group)
			return;
		
		inviter->CastToClient()->QueuePacket(app);//notify inviter the client accepted
		
		if(!group->AddMember(this))
			return;
		group->SendUpdate(7,this);
		group->SendUpdate(7,inviter);
		group->SendHPPacketsTo(this);
		
	}
	return;
}

void Client::Handle_OP_GroupDisband(const EQZonePacket *app)
{
	if (app->size != sizeof(GroupGeneric_Struct)) {
		LogFile->write(EQEMuLog::Error, "Invalid size for GroupGeneric_Struct: Expected: %i, Got: %i",
			sizeof(GroupGeneric_Struct), app->size);
		return;
	}
	
LogFile->write(EQEMuLog::Debug, "Member Disband Request from %s\n", GetName());
	
	GroupGeneric_Struct* gd = (GroupGeneric_Struct*) app->pBuffer;
	Group* group = GetGroup();
	
	if(!group)
		return;
	
	if((group->IsLeader(this) && target == 0) || (group->GroupCount()<3)) {
		group->DisbandGroup();
	} else {
		group->DelMember(entity_list.GetMob(gd->name2),false);
	}
	return;
}

void Client::Handle_OP_GroupDelete(const EQZonePacket *app)
{
//should check for leader, only they should be able to do this..
	printf("Group Delete Request\n");
	Group* group = GetGroup();
	if (group)
		group->DisbandGroup();
	return;
}

void Client::Handle_OP_GMEmoteZone(const EQZonePacket *app)
{
	if(this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/emote");
		return;
	}
	GMEmoteZone_Struct* gmez = (GMEmoteZone_Struct*)app->pBuffer;
	char* newmessage=0;
	if(strstr(gmez->text,"^")==0)
		entity_list.Message(0, 15, gmez->text);
	else{
		for(newmessage = strtok((char*)gmez->text,"^");newmessage!=NULL;newmessage=strtok(NULL, "^"))
			entity_list.Message(0, 15, newmessage);
	}
	return;
}

void Client::Handle_OP_InspectRequest(const EQZonePacket *app)
{
	Inspect_Struct* ins = (Inspect_Struct*) app->pBuffer;
	Mob* tmp = entity_list.GetMob(ins->TargetID);
	if(tmp != 0 && tmp->IsClient())
		tmp->CastToClient()->QueuePacket(app); // Send request to target

	return;
}

void Client::Handle_OP_InspectAnswer(const EQZonePacket *app)
{
	//Cofruben: Fills the app sent from client.
	Inspect_Struct* ins = (Inspect_Struct*) app->pBuffer;
	EQZonePacket* outapp = app->Copy();
	InspectResponse_Struct* insr = (InspectResponse_Struct*) outapp->pBuffer;
	Mob* tmp = entity_list.GetMob(ins->TargetID);
	const Item_Struct* item = NULL;
	for (sint16 L=0; L<=21; L++) {
		const ItemInst* inst = GetInv().GetItem(L);
		item = (inst) ? inst->GetItem() : NULL;
		if(item>0){
			strcpy(insr->itemnames[L],item->Name);
			insr->itemicons[L]=item->Icon;
		}
		else
			insr->itemicons[L]=0xFFFFFFFF;	
	}
	if(tmp != 0 && tmp->IsClient())
		tmp->CastToClient()->QueuePacket(outapp); // Send answer to requester
	return;
}

#if 0	// solar: i dont think there's an op for this now, and we check this
			// when the client is sitting
void Client::Handle_OP_Medding(const EQZonePacket *app)
{
	if (app->pBuffer[0])
		medding = true;
	else
		medding = false;
	return;
}
#endif

void Client::Handle_OP_DeleteSpell(const EQZonePacket *app)
{
	if(app->size != sizeof(DeleteSpell_Struct))
		return;

	EQZonePacket* outapp = app->Copy();
	DeleteSpell_Struct* dss = (DeleteSpell_Struct*) outapp->pBuffer;
	
	if(dss->spell_slot < 0 || dss->spell_slot > MAX_PP_SPELLBOOK)
		return;
	
	if(m_pp.spell_book[dss->spell_slot] != SPELLBOOK_UNKNOWN) {
		m_pp.spell_book[dss->spell_slot] = SPELLBOOK_UNKNOWN;
		dss->success = 1;
	}
	else
		dss->success = 0;
	
	FastQueuePacket(&outapp);
	return;
}

void Client::Handle_OP_PetitionBug(const EQZonePacket *app)
{
	if(app->size!=sizeof(PetitionBug_Struct))
		printf("Wrong size of BugStruct! Expected: %i, Got: %i\n",sizeof(PetitionBug_Struct),app->size);
	else{
		PetitionBug_Struct* bug=(PetitionBug_Struct*)app->pBuffer;
		database.UpdateBug(bug);
	}
	return;
}

void Client::Handle_OP_Bug(const EQZonePacket *app)
{
	if(app->size!=sizeof(BugStruct))
		printf("Wrong size of BugStruct!\n");
	else{
		BugStruct* bug=(BugStruct*)app->pBuffer;
		database.UpdateBug(bug);
	}
	return;
}

void Client::Handle_OP_Petition(const EQZonePacket *app)
{
	if (app->size <= 1)
		return;
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	/*else if(petition_list.FindPetitionByAccountName(this->AccountName()))
		{
		Message(0,"You already have a petition in queue, you cannot petition again until this one has been responded to or you have deleted the petition.");
		return;
		}*/
	else
	{
		if(petition_list.FindPetitionByAccountName(AccountName()))
		{
		Message(0,"You already have a petition in the queue, you must wait for it to be answered or use /deletepetition to delete it.");
		return;
		}
		Petition* pet = new Petition;
		pet->SetAName(this->AccountName());
		pet->SetClass(this->GetClass());
		pet->SetLevel(this->GetLevel());
		pet->SetCName(this->GetName());
		pet->SetRace(this->GetRace());
		pet->SetLastGM("");
		pet->SetCName(this->GetName());
		pet->SetPetitionText((char*) app->pBuffer);
		pet->SetZone(zone->GetZoneID());
		pet->SetUrgency(0);
		petition_list.AddPetition(pet);						
		database.InsertPetitionToDB(pet);						petition_list.UpdateGMQueue();
		petition_list.UpdateZoneListQueue();
		worldserver.SendEmoteMessage(0, 0, 80, 15, "%s has made a petition. #%i", GetName(), pet->GetID());
	}
	return;
}

void Client::Handle_OP_PetitionCheckIn(const EQZonePacket *app)
{
	Petition_Struct* inpet = (Petition_Struct*) app->pBuffer;

	Petition* pet = petition_list.GetPetitionByID(inpet->petnumber);
	//if (inpet->urgency != pet->GetUrgency())
		pet->SetUrgency(inpet->urgency);
	pet->SetLastGM(this->GetName());
	pet->SetGMText(inpet->gmtext);

	pet->SetCheckedOut(false);
	petition_list.UpdatePetition(pet);
	petition_list.UpdateGMQueue();
	petition_list.UpdateZoneListQueue();
	return;
}

void Client::Handle_OP_PetitionResolve(const EQZonePacket *app)
{
	Handle_OP_PetitionDelete(app);
}

void Client::Handle_OP_PetitionDelete(const EQZonePacket *app)
{
	EQZonePacket* outapp = new EQZonePacket(OP_PetitionUpdate,sizeof(PetitionUpdate_Struct));
	PetitionUpdate_Struct* pet = (PetitionUpdate_Struct*) outapp->pBuffer;
	pet->petnumber = *((int*) app->pBuffer);
	pet->color = 0x00;
	pet->status = 0xFFFFFFFF;
	pet->senttime = 0;
	strcpy(pet->accountid, "");
	strcpy(pet->gmsenttoo, "");
	pet->quetotal = petition_list.GetMaxPetitionID();
	strcpy(pet->charname, "");
	FastQueuePacket(&outapp);
	
	if (petition_list.DeletePetition(pet->petnumber) == -1)
		cout << "Something is borked with: " << pet->petnumber << endl;
	petition_list.ClearPetitions();
	petition_list.UpdateGMQueue();
	petition_list.ReadDatabase();
	petition_list.UpdateZoneListQueue();
	return;
}

void Client::Handle_OP_PetCommands(const EQZonePacket *app)
{
	char val1[20]={0};		
	PetCommand_Struct* pet = (PetCommand_Struct*) app->pBuffer;
	Mob* mypet = this->GetPet();
	if(!mypet) return;
	if(mypet == 0) {
		// try to get a familiar if we dont have a real pet
		mypet = this->GetFamiliar();
		if (mypet == NULL)
		return;
	}
	
	if(GetClass() == ENCHANTER && mypet->GetPetType() != 0xFF)
		return;
	
	// just let the command "/pet get lost" work for familiars
	if(mypet == GetFamiliar() && pet->command != PET_GETLOST)
		return;
	
	switch(pet->command)
	{
	case PET_ATTACK: {
		if (!target)
			break;
		if (target->IsMezzed()) {
			Message_StringID(10, CANNOT_WAKE, mypet->GetCleanName(), target->GetCleanName());
			break;
		}
		if (mypet->GetHateTop()==0 && target != this && DistNoZ(*target) <= 100) {
			zone->AddAggroMob();
			mypet->AddToHateList(target, 1);
			Message_StringID(10, PET_ATTACKING, mypet->GetCleanName(), target->GetCleanName());
		}
		break;
	}
	case PET_BACKOFF: {
		mypet->Say_StringID(PET_CALMING);
		mypet->WhipeHateList();
		break;
	}
	case PET_HEALTHREPORT: {
		Message_StringID(10, PET_REPORT_HP, ConvertArrayF(mypet->GetHPRatio(), val1));
		//Message(10,"%s tells you, 'I have %d percent of my hit points left.'",mypet->GetName(),(int8)mypet->GetHPRatio());
		break;
	}
	case PET_GETLOST: {
		if (mypet->Charmed())
			break;
		if (mypet->GetPetType() == 0xFF || !mypet->IsNPC()) {
			// eqlive ignores this command
			// we could just remove the charm
			// and continue
			mypet->BuffFadeByEffect(SE_Charm);
			break;
		} else {
			SetPet(NULL);
		}
		if (mypet == GetFamiliar()) {
			SetFamiliarID(0);
		}
		mypet->Say_StringID(PET_GETLOST_STRING);
		mypet->CastToNPC()->Depop();
		break;
	}
	case PET_LEADER: {
		mypet->Say_StringID(PET_LEADERIS);
		break;
	}
	case PET_GUARDHERE: {
		mypet->Say_StringID(PET_GUARDINGLIFE);
		mypet->SetPetOrder(SPO_Guard);
		mypet->SaveGuardSpot();
		break;
	}
	case PET_FOLLOWME: {
		mypet->Say_StringID(PET_FOLLOWING);
		mypet->SetPetOrder(SPO_Follow);
		mypet->SendAppearancePacket(AT_Anim, ANIM_STAND);
		break;
	}
	case PET_TAUNT: {
		Message(0,"%s says, 'Now taunting foes, Master!",mypet->GetName());
		mypet->CastToNPC()->SetTaunting(true);
		break;
	}
	case PET_NOTAUNT: {
		Message(0,"%s says, 'No longer taunting foes, Master!",mypet->GetName());
		mypet->CastToNPC()->SetTaunting(false);
		break;
	}
	case PET_GUARDME: {
		mypet->Say_StringID(PET_GUARDME_STRING);
		mypet->SetPetOrder(SPO_Follow);
		mypet->SendAppearancePacket(AT_Anim, ANIM_STAND);
		break;
	}
	case PET_SITDOWN: {
		mypet->Say_StringID(PET_SIT_STRING);
		mypet->SetPetOrder(SPO_Sit);
		mypet->SetRunAnimSpeed(0);
		if(!mypet->UseBardSpellLogic())	// solar: maybe we can have a bard pet
			mypet->InterruptSpell(); //Baron-Sprite: No cast 4 u. // neotokyo: i guess the pet should start casting
		mypet->SendAppearancePacket(AT_Anim, ANIM_SIT);
		break;
	}
	case PET_STANDUP: {
		mypet->Say_StringID(PET_SIT_STRING);
		mypet->SetPetOrder(SPO_Follow);
		mypet->SendAppearancePacket(AT_Anim, ANIM_STAND);
		break;
	}
	case PET_SLUMBER: {
		mypet->Say_StringID(PET_SIT_STRING);
		mypet->SetPetOrder(SPO_Sit);
		mypet->SetRunAnimSpeed(0);
		if(!mypet->UseBardSpellLogic())	// solar: maybe we can have a bard pet
			mypet->InterruptSpell(); //Baron-Sprite: No cast 4 u. // neotokyo: i guess the pet should start casting
		mypet->SendAppearancePacket(AT_Anim, ANIM_DEATH);
		break;
	}
	default:
		printf("Client attempted to use a unknown pet command:\n");
		break;
	}
}

void Client::Handle_OP_PetitionUnCheckout(const EQZonePacket *app)
{
	if (app->size != sizeof(int32)) {
		cout << "Wrong size: OP_PetitionUnCheckout, size=" << app->size << ", expected " << sizeof(int32) << endl;
		return;
	}
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		int32 getpetnum = *((int32*) app->pBuffer);
		Petition* getpet = petition_list.GetPetitionByID(getpetnum);
		if (getpet != 0) {
			getpet->SetCheckedOut(false);
			petition_list.UpdatePetition(getpet);
			petition_list.UpdateGMQueue();
			petition_list.UpdateZoneListQueue();
		}
	}
	return;
}

void Client::Handle_OP_PetitionQue(const EQZonePacket *app)
{
#ifdef _EQDEBUG
		printf("%s looking at petitions..\n",this->GetName());
#endif
	return;
}

void Client::Handle_OP_PDeletePetition(const EQZonePacket *app)
{
	if(petition_list.DeletePetitionByCharName((char*)app->pBuffer))
		Message_StringID(0,PETITION_DELETED);	
	else
		Message_StringID(0,PETITION_NO_DELETE);	
	return;
}

void Client::Handle_OP_PetitionCheckout(const EQZonePacket *app)
{
	if (app->size != sizeof(int32)) {
		cout << "Wrong size: OP_PetitionCheckout, size=" << app->size << ", expected " << sizeof(int32) << endl;
		return;
	}
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		int32 getpetnum = *((int32*) app->pBuffer);
		Petition* getpet = petition_list.GetPetitionByID(getpetnum);
		if (getpet != 0) {
			getpet->AddCheckout();
			getpet->SetCheckedOut(true);
			getpet->SendPetitionToPlayer(this->CastToClient());
			petition_list.UpdatePetition(getpet);
			petition_list.UpdateGMQueue();
			petition_list.UpdateZoneListQueue();
		}
	}
	return;
}

void Client::Handle_OP_PetitionRefresh(const EQZonePacket *app)
{
	// This is When Client Asks for Petition Again and Again...
	// break is here because it floods the zones and causes lag if it
	// Were to actually do something:P  We update on our own schedule now.
	return;
}

void Client::Handle_OP_ReadBook(const EQZonePacket *app)
{
	BookRequest_Struct* book = (BookRequest_Struct*) app->pBuffer;
	ReadBook(book);
	return;
}

void Client::Handle_OP_Emote(const EQZonePacket *app)
{
	if(app->size != sizeof(Emote_Struct))
		return;
	
	// Calculate new packet dimensions
	Emote_Struct* in	= (Emote_Struct*)app->pBuffer;
	const char* name	= GetName();
	uint32 len_name		= strlen(name);
	uint32 len_msg		= strlen(in->message);
	uint32 len_packet	= sizeof(in->unknown01) + len_name
						+ strlen(in->message) + 1;
	
	// Construct outgoing packet
	EQZonePacket* outapp = new EQZonePacket(OP_Emote, len_packet);
	Emote_Struct* out = (Emote_Struct*)outapp->pBuffer;
	out->unknown01 = in->unknown01;
	memcpy(out->message, name, len_name);
	memcpy(&out->message[len_name], in->message, len_msg);
	
	//cout << "######### Outgoing emote packet" << endl;
	//DumpPacket(outapp);
	
	/*
	if (target && target->IsClient()) {
		entity_list.QueueCloseClients(this, outapp, false, 100, target);
		
		cptr = outapp->pBuffer + 2;
		
                        // not sure if live does this or not.  thought it was a nice feature, but would take a lot to
		// clean up grammatical and other errors.  Maybe with a regex parser...
		replacestr((char *)cptr, target->GetName(), "you");
		replacestr((char *)cptr, " he", " you");
		replacestr((char *)cptr, " she", " you");
		replacestr((char *)cptr, " him", " you");
		replacestr((char *)cptr, " her", " you");
		target->CastToClient()->QueuePacket(outapp);
		
	}
	else
	*/
	entity_list.QueueCloseClients(this, outapp, true, 100,0,true,FILTER_SOCIALS);
	
	safe_delete(outapp);
	return;
}

void Client::Handle_OP_Animation(const EQZonePacket *app)
{
	if(app->size != sizeof(Animation_Struct))
		return;
	
	Animation_Struct *s = (Animation_Struct *) app->pBuffer;
	
	//might verify spawn ID, but it wouldent affect anything
	
	// an emote (i.e., waving arm to say hello)
	DoAnim(s->value, s->action);
	
	return;
}

void Client::Handle_OP_SetServerFilter(const EQZonePacket *app)
{
	if(app->size != sizeof(SetServerFilter_Struct))
		return;
	SetServerFilter_Struct* filter=(SetServerFilter_Struct*)app->pBuffer;
	ServerFilter(filter);
	return;
}

void Client::Handle_OP_GMDelCorpse(const EQZonePacket *app)
{
	if(app->size != sizeof(GMDelCorpse_Struct))
		return;
	if(this->Admin() < commandEditPlayerCorpses) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/delcorpse");
		return;
	}
	GMDelCorpse_Struct* dc = (GMDelCorpse_Struct *)app->pBuffer;
	Mob* corpse = entity_list.GetMob(dc->corpsename);
	if(corpse==0) {
		return;
	}
	if(corpse->IsCorpse() != true) {
		return;
	}
	corpse->CastToCorpse()->Delete();
	cout << name << " deleted corpse " << dc->corpsename << endl;
	Message(13, "Corpse %s deleted.", dc->corpsename);
	return;
}

void Client::Handle_OP_GMKick(const EQZonePacket *app)
{
	if(app->size != sizeof(GMKick_Struct))
		return;
	if(this->Admin() < minStatusToKick) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/kick");
		return;
	}
	GMKick_Struct* gmk = (GMKick_Struct *)app->pBuffer;

	Client* client = entity_list.GetClientByName(gmk->name);
	if(client==0) {
		if (!worldserver.Connected())
			Message(0, "Error: World server disconnected");
		else {
			ServerPacket* pack = new ServerPacket;
			pack->opcode = ServerOP_KickPlayer;
			pack->size = sizeof(ServerKickPlayer_Struct);
			pack->pBuffer = new uchar[pack->size];
			ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
			strcpy(skp->adminname, gmk->gmname);
			strcpy(skp->name, gmk->name);
			skp->adminrank = this->Admin();
			worldserver.SendPacket(pack);
			safe_delete(pack);
		}
	}
	else {
		entity_list.QueueClients(this,app);
		//client->Kick();
	}
	return;
}

void Client::Handle_OP_GMServers(const EQZonePacket *app)
{
	if (!worldserver.Connected())
		Message(0, "Error: World server disconnected");
	else {
		ServerPacket* pack = new ServerPacket;
		pack->size = strlen(this->GetName())+2;
		pack->pBuffer = new uchar[pack->size];
		memset(pack->pBuffer, 0, pack->size);
		pack->opcode = ServerOP_ZoneStatus;
		memset(pack->pBuffer, (int8) admin, 1);
		strcpy((char *) &pack->pBuffer[1], this->GetName());
		worldserver.SendPacket(pack);
		safe_delete(pack);
	}
	return;
}

void Client::Handle_OP_Illusion(const EQZonePacket *app)
{
	Illusion_Struct* bnpc = (Illusion_Struct*)app->pBuffer;
	// @merth: these need to be implemented
	/*
	texture		= bnpc->texture;
	helmtexture	= bnpc->helmtexture;
	luclinface	= bnpc->luclinface;
	*/
	race		= bnpc->race;
	size		= 0;
	
	entity_list.QueueClients(this,app);
	return;
}

void Client::Handle_OP_GMBecomeNPC(const EQZonePacket *app)
{
	if(this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/becomenpc");
		return;
	}
	//entity_list.QueueClients(this, app, false);
	BecomeNPC_Struct* bnpc = (BecomeNPC_Struct*)app->pBuffer;
	
	Mob* cli = (Mob*) entity_list.GetMob(bnpc->id);
	if(cli==0)
		return;
	
	if(cli->IsClient())
		cli->CastToClient()->QueuePacket(app);
	cli->SendAppearancePacket(AT_NPCName, 1, true);
	cli->CastToClient()->SetBecomeNPC(true);
	cli->CastToClient()->SetBecomeNPCLevel(bnpc->maxlevel);
	cli->Message_StringID(0,TOGGLE_OFF);
	cli->CastToClient()->tellsoff = true;
	//TODO: Make this toggle a BecomeNPC flag so that it gets updated when people zone in as well; Make combat work with this.
	return;
}

void Client::Handle_OP_Fishing(const EQZonePacket *app)
{
	if(!p_timers.Expired(pTimerFishing, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	p_timers.Start(pTimerFishing, FishingReuseTime-1);
	
	fishing_timer.Start();
	return;
// Changes made based on Bobs work on foraging.  Now can set items in the forage database table to 
// forage for.
}

void Client::Handle_OP_Forage(const EQZonePacket *app)
{
	
	if(!p_timers.Expired(pTimerForaging, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	p_timers.Start(pTimerForaging, ForagingReuseTime-1);
	
	ForageItem();
	
	return;
}

void Client::Handle_OP_Mend(const EQZonePacket *app)
{
	if(GetClass() != MONK)
		return;
	
	if(!p_timers.Expired(pTimerMend, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	p_timers.Start(pTimerMend, MendReuseTime-1);
	
	int num = 25 + 5*GetAA(aaCriticalMend) + 5*GetAA(aaMendingoftheTranquil);
	int mendhp = (int) GetMaxHP() * num / 100;
	uint32 noadvance = MakeRandomInt(0, 200);
	int currenthp = GetHP();
	if (MakeRandomInt(0, 100) <= (int)GetSkill(MEND)) {
		SetHP(GetHP() + mendhp);
		SendHPUpdate();
		Message_StringID(4,MEND_SUCCESS);
		//Message(4, "You mend your wounds and heal some damage");
	}
	else if (noadvance > 175) {
		if(currenthp > mendhp) {
			SetHP(GetHP() - mendhp);
			SendHPUpdate();
			//Message(4, "You fail to mend your wounds and damage yourself!");
			Message_StringID(4,MEND_WORSEN);
		} else {
			SetHP(1);
			SendHPUpdate();
			//Message(4, "You fail to mend your wounds and damage yourself!");
			Message_StringID(4,MEND_WORSEN);
		}
	}
	else	{
		//Message(4, "You fail to mend your wounds");
		Message_StringID(4,MEND_FAIL);
	}
	
	if(GetSkill(MEND) < noadvance)
		CheckIncreaseSkill(MEND);
	//if ((GetSkill(MEND) < noadvance) && (MakeRandomFloat(0, 100) < 35) && (GetSkill(MEND) < 101))
	//	this->SetSkill(MEND,GetRawSkill(MEND)+1);
	return;
}

void Client::Handle_OP_EnvDamage(const EQZonePacket *app)
{
	EnvDamage2_Struct* ed = (EnvDamage2_Struct*)app->pBuffer;
	if(admin >= minStatusToAvoidFalling && GetGM()){
		Message(13, "Your GM status protects you from %i points of type %i environmental damage.", ed->damage, ed->dmgtype);
		SetHP(GetHP()-1);//needed or else the client wont acknowledge
		return;
	} else if(GetInvul()) {
		Message(13, "Your invuln status protects you from %i points of type %i environmental damage.", ed->damage, ed->dmgtype);
		SetHP(GetHP()-1);//needed or else the client wont acknowledge
		return;
	}
	
	int damage = ed->damage;
	
	if (ed->dmgtype == 252) {
		if(CanUseSkill(SAFE_FALL)) {
			int sv = GetSkill(SAFE_FALL);
			//this is a total bullshit forumla, somebody find a better one
			if(MakeRandomInt(0,240) < sv/5)
				damage = 0;
			else if(sv > 2)
				damage = damage * 3 / sv;
			
			CheckIncreaseSkill(SAFE_FALL);
		}
		
		switch(GetAA(aaAcrobatics)) {
		case 1:
			damage = damage * 95 / 100;
			break;
		case 2:
			damage = damage * 90 / 100;
			break;
		case 3:
			damage = damage * 80 / 100;
			break;
		}
	}
	
	if(damage < 0)
		damage = 31337;

	else if(zone->GetZoneID() == 183 || zone->GetZoneID() == 184)
		return;
	else
		SetHP(GetHP() - damage);
	
	if(GetHP() <= 0)
		Death(0,32000);
	SendHPUpdate();
	return;
}

void Client::Handle_OP_Damage(const EQZonePacket *app)
{
	// Broadcast to other clients
	CombatDamage_Struct* damage = (CombatDamage_Struct*)app->pBuffer;
	//dont send to originator of falling damage packets
	entity_list.QueueClients(this, app, (damage->type==0xFC));
	return;
}

void Client::Handle_OP_AAAction(const EQZonePacket *app)
{
	//DumpPacket(app);
	if(app->size!=sizeof(AA_Action)){
		printf("Error! OP_AAAction size didnt match!\n");
	return;
	}
	AA_Action* action=(AA_Action*)app->pBuffer;
	
	if(action->action == aaActionActivate)//AA Hotkey
		ActivateAA((aaID) action->ability);
	else if(action->action == aaActionBuy) {
		BuyAA(action);
	}
	else if(action->action == aaActionDisableEXP){ //Turn Off AA Exp
		if(m_epp.perAA > 0)
			Message_StringID(0, 119);	//119 Alternate Experience is *OFF*.
		m_epp.perAA = 0;
		SendAAStats();
	} else if(action->action == aaActionSetEXP) {
		if(m_epp.perAA == 0)
			Message_StringID(0, 121);	//121 Alternate Experience is *ON*.
		m_epp.perAA = action->exp_value;
		if (m_epp.perAA<0 || m_epp.perAA>100) m_epp.perAA=0;	// stop exploit with sanity check
		// send an update
		SendAAStats();
		SendAATable();
	} else {
		printf("Unknown AA action: %u %u 0x%x %d\n", action->action, action->ability, action->unknown08, action->exp_value);
	}
	
	return;
}

void Client::Handle_OP_TraderBuy(const EQZonePacket *app)
{
	if(app->size==sizeof(TraderBuy_Struct)){
		TraderBuy_Struct* tbs = (TraderBuy_Struct*)app->pBuffer;
		if(Client* trader=entity_list.GetClientByID(tbs->traderid)){
			BuyTraderItem(tbs,trader,app);
		}
	}
	return;
}

void Client::Handle_OP_Trader(const EQZonePacket *app)
{
	if(app->size==sizeof(Trader_ShowItems_Struct)){ //Show Items
		Trader_ShowItems_Struct* sis = (Trader_ShowItems_Struct*)app->pBuffer;
		if(sis->code==2){//end trader
			this->Trader_EndTrader();
		}
		else if(sis->code==4){ //end transaction
			Client* tmp=entity_list.GetClientByID(sis->traderid);
			if(tmp)
				tmp->withcustomer=false;
		}
		else if(sis->code==11){
			this->Trader_ShowItems();
		}
	}
	else if(app->size==sizeof(ClickTrader_Struct)){
		ClickTrader_Struct* ints = (ClickTrader_Struct*)app->pBuffer;
		if(ints->code==1){
			GetItems_Struct* gis=GetTraderItems();
			for(int i=0;i<80;i++){
				if(gis->items[i]>0 && gis->items[i]<database.GetMaxItem() && database.GetItem(gis->items[i])!=0)
					database.SaveTraderItem(this->CharacterID(),gis->items[i],ints->itemcost[i],i);
				else
					return; //sony doesnt memset so assume done on first bad item
			}
			safe_delete(gis);
			this->Trader_StartTrader();
		}
		else
			LogFile->write(EQEMuLog::Error, "Unknown TraderStruct code of: %i\n", ints->code);
	}
	else{
		LogFile->write(EQEMuLog::Error, "Unknown size for OP_Trader: %i\n", app->size);
		DumpPacket(app);
		return;
	}
	
	return;
}

void Client::Handle_OP_GMFind(const EQZonePacket *app)
{
	if (this->Admin() < minStatusToUseGMCommands) {
		Message(13, "Your account has been reported for hacking.");
		database.SetHackerFlag(this->account_name, this->name, "/find");
		return;
	}
	//Break down incoming
	GMSummon_Struct* request=(GMSummon_Struct*)app->pBuffer;
	//Create a new outgoing
	EQZonePacket *outapp = new EQZonePacket(OP_GMFind, sizeof(GMSummon_Struct));
	GMSummon_Struct* foundplayer=(GMSummon_Struct*)outapp->pBuffer;
	//Copy the constants
	strcpy(foundplayer->charname,request->charname);
	strcpy(foundplayer->gmname, request->gmname);
	//Check if the NPC exits intrazone...
	Mob* gt = entity_list.GetMob(request->charname);
	if (gt != 0) {
		foundplayer->success=1;
		foundplayer->x=(sint32)gt->GetX();
		foundplayer->y=(sint32)gt->GetY();

		foundplayer->z=(sint32)gt->GetZ();
		foundplayer->zoneID=zone->GetZoneID();
	}
	//Send the packet...
	FastQueuePacket(&outapp);
	return;
}

void Client::Handle_OP_PickPocket(const EQZonePacket *app)
{
	if (app->size != sizeof(PickPocket_Struct)){
		LogFile->write(EQEMuLog::Error, "Size mismatch for Pick Pocket packet");
		DumpPacket(app);
	}
	PickPocket_Struct* pick_in = (PickPocket_Struct*) app->pBuffer;

	//EQZonePacket* outapp = new EQZonePacket(OP_PickPocket, sizeof(sPickPocket_Struct));
	//sPickPocket_Struct* pick_out = (sPickPocket_Struct*) outapp->pBuffer;
	Mob* victim = entity_list.GetMob(pick_in->to);
	if (!victim)
		return;
	if (victim == this)
		Message(0,"You catch yourself red-handed.");
	else if (victim->GetOwnerID())
		Message(0,"You cannot steal from pets!");
	else if (victim->IsNPC())
		victim->CastToNPC()->PickPocket(this);
	else
		Message(0,"Stealing from clients not yet supported.");
	//safe_delete(outapp);
}

void Client::Handle_OP_Bind_Wound(const EQZonePacket *app)
{
	if (app->size != sizeof(BindWound_Struct)){
		LogFile->write(EQEMuLog::Error, "Size mismatch for Bind wound packet");
		DumpPacket(app);
	}
	BindWound_Struct* bind_in = (BindWound_Struct*) app->pBuffer;
	Mob* bindmob = entity_list.GetMob(bind_in->to);
	if (!bindmob){
	    LogFile->write(EQEMuLog::Error, "Bindwound on non-exsistant mob from %s", this->GetName());
	}
	LogFile->write(EQEMuLog::Debug, "BindWound in: to:\'%s\' from=\'%s\'", bindmob->GetName(), GetName());
	BindWound(bindmob, true);
	return;
}

void Client::Handle_OP_TrackTarget(const EQZonePacket *app)
{
	// Looks like an entityid should probably do something with it.
	IsTracking=(IsTracking==false);
	return;
}

void Client::Handle_OP_Track(const EQZonePacket *app)
{
	IsTracking=false;
	if(GetClass() != RANGER && GetClass() != DRUID && GetClass() != BARD)
		return;
	
	if(!p_timers.Expired(pTimerTracking, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	p_timers.Start(pTimerTracking, TrackingReuseTime-1);
	
	if( GetSkill(TRACKING)==0 )
		SetSkill(TRACKING,1);
	else
		CheckIncreaseSkill(TRACKING,15); 

	entity_list.MakeTrackPacket(this);
	return;
}

void Client::Handle_OP_TrackUnknown(const EQZonePacket *app)
{
	// size 0 send right after OP_Track
	return;
}

void Client::Handle_0x0193(const EQZonePacket *app)
{
	// Not sure what this opcode does.  It started being sent when OP_ClientUpdate was
	// changed to pump OP_ClientUpdate back out instead of OP_MobUpdate
	// 2 bytes: 00 00
}

#if 0	// solar: disabled 2/13/04
void Client::Handle_0x01e7(const EQZonePacket *app)
{
	// Dunno what this opcode does but client needs an answer
	if(app->size==8){
		app->pBuffer[4]=0;
		app->pBuffer[5]=0;
		app->pBuffer[6]=0;
		app->pBuffer[7]=0;
		QueuePacket(app);
	}
	return;
}
#endif

void Client::Handle_OP_ClientError(const EQZonePacket *app)
{
	ClientError_Struct* error = (ClientError_Struct*)app->pBuffer;
	LogFile->write(EQEMuLog::Error, "Client error: %s", error->character_name);
	LogFile->write(EQEMuLog::Error, "Error message:%s", error->message);
	//if (EQDEBUG>=5)
	//	DumpPacket(app);
	return;
}

void Client::Handle_OP_ReloadUI(const EQZonePacket *app)
{
	if(guilddbid>0 && guilddbid<0xFFFFFFFF)
		SendGuildMembers(guilddbid);
	return;
}

void Client::Handle_OP_TGB(const EQZonePacket *app)
{
	OPTGB(app);
	return;
}

void Client::Handle_OP_Split(const EQZonePacket *app)
{
	// solar: the client removes the money on its own, but we have to
	// update our state anyway, and make sure they had enough to begin
	// with.
	Split_Struct *split = (Split_Struct *)app->pBuffer;
	//Implemented by Father Nitwit
	//Per the note above, Im not exactly sure what to do on error
	//to notify the client of the error...
	if(!isgrouped) {
		Message(13, "You can not split money if your not in a group.");
		return;
	}
	Group *cgroup = GetGroup();
	if(cgroup == NULL) {
		//invalid group, not sure if we should say more...
		Message(13, "You can not split money if your not in a group.");
		return;
	}
	
	if(!TakeMoneyFromPP(split->copper + 10 * split->silver + 100 * split->gold + 1000 * split->platinum)) {
		Message(13, "You do not have enough money to do that split.");
		return;
	}
	cgroup->SplitMoney(split->copper, split->silver, split->gold, split->platinum);
	
	return;

}

void Client::Handle_OP_SenseTraps(const EQZonePacket *app)
{
	if (!CanUseSkill(SENSE_TRAPS))
		return;
	
	if(!p_timers.Expired(pTimerSenseTraps, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	int reuse = SenseTrapsReuseTime;
	switch(GetAA(aaAdvTrapNegotiation)) {
		case 1:
			reuse = reuse * 90/100;
			break;
		case 2:
			reuse = reuse * 75/100;
			break;
		case 3:
			reuse = reuse * 50/100;
			break;
	}
	p_timers.Start(pTimerSenseTraps, reuse-1);
	
	Trap* trap = entity_list.FindNearbyTrap(this,100);
	
	CheckIncreaseSkill(SENSE_TRAPS);
	
	if (trap && trap->skill > 0) {
		int uskill = GetSkill(SENSE_TRAPS);
		if ((MakeRandomInt(0,99) + uskill) >= (MakeRandomInt(0,99) + trap->skill*0.75))
		{
			float xdif = trap->x - GetX();
			float ydif = trap->y - GetY();
			if (xdif == 0 && ydif == 0)
				Message(MT_Skills,"You sense a trap right under your feet!");
			else if (xdif > 10 && ydif > 10)
				Message(MT_Skills,"You sense a trap to the NorthWest.");
			else if (xdif < -10 && ydif > 10)
				Message(MT_Skills,"You sense a trap to the NorthEast.");
			else if (ydif > 10)
				Message(MT_Skills,"You sense a trap to the North.");
			else if (xdif > 10 && ydif < -10)
				Message(MT_Skills,"You sense a trap to the SouthWest.");
			else if (xdif < -10 && ydif < -10)
				Message(MT_Skills,"You sense a trap to the SouthEast.");
			else if (ydif < -10)
				Message(MT_Skills,"You sense a trap to the South.");
			else if (xdif > 10)
				Message(MT_Skills,"You sense a trap to the West.");
			else
				Message(MT_Skills,"You sense a trap to the East.");
			trap->detected = true;
			return;
		}
	}
	Message(MT_Skills,"You did not find any traps nearby.");
	return;
}

void Client::Handle_OP_DisarmTraps(const EQZonePacket *app)
{
	if (!CanUseSkill(DISARM_TRAPS))
		return;
	
	if(!p_timers.Expired(pTimerSenseTraps, false)) {
		Message(13,"Ability recovery time not yet met.");
		return;
	}
	int reuse = SenseTrapsReuseTime;
	switch(GetAA(aaAdvTrapNegotiation)) {
		case 1:
			reuse = reuse * 90/100;
			break;
		case 2:
			reuse = reuse * 75/100;
			break;
		case 3:
			reuse = reuse * 50/100;
			break;
	}
	p_timers.Start(pTimerSenseTraps, reuse-1);
	
	Trap* trap = entity_list.FindNearbyTrap(this,40);
	if (trap && trap->detected)
	{
		int uskill = GetSkill(DISARM_TRAPS);
		if ((MakeRandomInt(0, 49) + uskill) >= (MakeRandomInt(0, 49) + trap->skill))
		{
			Message(MT_Skills,"You disarm a trap.");
			trap->disarmed = true;
			trap->respawn_timer.Start(6000000);
		}
		else
		{
			Message(MT_Skills,"You set off the trap while trying to disarm it!");
			trap->Trigger(this);
		}
		CheckIncreaseSkill(DISARM_TRAPS);
		return;
	}
	Message(MT_Skills,"You did not find any traps close enough to disarm.");
	return;
}

void Client::Handle_OP_StartTribute(const EQZonePacket *app)
{
	if(app->size != sizeof(StartTribute_Struct))
		printf("Error in OP_StartTribute.  Expected size of: %i, but got: %i\n",sizeof(StartTribute_Struct),app->size);
	else {
		//Opens the tribute master window
		StartTribute_Struct* st = (StartTribute_Struct*)app->pBuffer;
		Mob* tribmast = entity_list.GetMob(st->tribute_master_id);
		if(tribmast && tribmast->IsNPC() && tribmast->GetClass()==TRIBUTE_MASTER
			&& DistNoRoot(*tribmast) <= USE_NPC_RANGE2) {
			st->response = 1;
			QueuePacket(app);
			tribute_master_id = st->tribute_master_id;
			DoTributeUpdate();
		} else {
			st->response=0;
			QueuePacket(app);
		}
	}
	return;
}

void Client::Handle_OP_TributeItem(const EQZonePacket *app)
{
	//player donates an item...
	if(app->size != sizeof(TributeItem_Struct))
		printf("Error in OP_TributeItem.  Expected size of: %i, but got: %i\n",sizeof(StartTribute_Struct),app->size);
	else {
		TributeItem_Struct* t = (TributeItem_Struct*)app->pBuffer;
		
		tribute_master_id = t->tribute_master_id;
		//make sure they are dealing with a valid tribute master
		Mob* tribmast = entity_list.GetMob(t->tribute_master_id);
		if(!tribmast || !tribmast->IsNPC() || tribmast->GetClass() != TRIBUTE_MASTER)
			return;
		if(DistNoRoot(*tribmast) > USE_NPC_RANGE2)
			return;
		
		t->tribute_points = TributeItem(t->slot, t->quantity);
		
		QueuePacket(app);
	}
	return;
}

void Client::Handle_OP_TributeMoney(const EQZonePacket *app)
{
	//player donates money
	if(app->size != sizeof(TributeMoney_Struct))
		printf("Error in OP_TributeMoney.  Expected size of: %i, but got: %i\n",sizeof(StartTribute_Struct),app->size);
	else {
		TributeMoney_Struct* t = (TributeMoney_Struct*)app->pBuffer;
		
		tribute_master_id = t->tribute_master_id;
		//make sure they are dealing with a valid tribute master
		Mob* tribmast = entity_list.GetMob(t->tribute_master_id);
		if(!tribmast || !tribmast->IsNPC() || tribmast->GetClass() != TRIBUTE_MASTER)
			return;
		if(DistNoRoot(*tribmast) > USE_NPC_RANGE2)
			return;
		
		t->tribute_points = TributeMoney(t->platinum);
		
		QueuePacket(app);
	}
	return;
}

void Client::Handle_OP_SelectTribute(const EQZonePacket *app)
{
	//we should enforce being near a real tribute master to change this
	//but im not sure how I wanna do that right now.
	if(app->size != sizeof(SelectTributeReq_Struct))
		LogFile->write(EQEMuLog::Error, "Invalid size on OP_SelectTribute packet");
	else {
		SelectTributeReq_Struct *t = (SelectTributeReq_Struct *) app->pBuffer;
		SendTributeDetails(t->client_id, t->tribute_id);
	}
	return;
}

void Client::Handle_OP_TributeUpdate(const EQZonePacket *app)
{
	//sent when the client changes their tribute settings...
	if(app->size != sizeof(TributeInfo_Struct))
		LogFile->write(EQEMuLog::Error, "Invalid size on OP_TributeUpdate packet");
	else {
		TributeInfo_Struct *t = (TributeInfo_Struct *) app->pBuffer;
		ChangeTributeSettings(t);
	}
	return;
}

void Client::Handle_OP_TributeToggle(const EQZonePacket *app)
{
	if(app->size != sizeof(int32))
		LogFile->write(EQEMuLog::Error, "Invalid size on OP_TributeToggle packet");
	else {
		int32 *val = (int32 *) app->pBuffer;
		ToggleTribute(*val? true : false);
	}
	return;
}

void Client::Handle_OP_TributeNPC(const EQZonePacket *app)
{
	return;
}

void Client::Handle_OP_CrashDump(const EQZonePacket *app)
{
}

void Client::Handle_OP_ControlBoat(const EQZonePacket *app)
{
}

void Client::Handle_OP_DumpName(const EQZonePacket *app)
{
}

void Client::Handle_OP_SetRunMode(const EQZonePacket *app)
{
}

void Client::Handle_OP_SafeFallSuccess(const EQZonePacket *app)
{
}

void Client::Handle_OP_Heartbeat(const EQZonePacket *app)
{
}

void Client::Handle_OP_SafePoint(const EQZonePacket *app)
{
}

void Client::Handle_OP_Ignore(const EQZonePacket *app)
{
}

void Client::Handle_OP_FindPersonRequest(const EQZonePacket *app)
{
	if(app->size != sizeof(FindPersonRequest_Struct))
		printf("Error in FindPersonRequest_Struct.  Expected size of: %i, but got: %i\n",sizeof(FindPersonRequest_Struct),app->size);
	else {
		FindPersonRequest_Struct* t = (FindPersonRequest_Struct*)app->pBuffer;
		
		vector<FindPerson_Point> points;
		
		Message(13, "Searched for NPC ID: %d\n", t->npc_id);
		Mob* target = entity_list.GetMob(t->npc_id);
		
		if(target == NULL) {
			//empty length packet == not found.
			EQZonePacket outapp(OP_FindPersonReply, 0);
			QueuePacket(&outapp);
			return;
		}
		
		Message(13, "Found NPC '%s'\n", target->GetName());
		
		//fill in the path array...
		points.resize(2);
		points[0].x = GetX();
		points[0].y = GetY();
		points[0].z = GetZ();
		points[1].x = target->GetX();
		points[1].y = target->GetY();
		points[1].z = target->GetZ();
		
		SendPathPacket(points);
	}
	return;
}

void Client::DBAWComplete(int8 workpt_b1, DBAsyncWork* dbaw) {
	Entity::DBAWComplete(workpt_b1, dbaw);
	switch (workpt_b1) {
		case DBA_b1_Entity_Client_InfoForLogin: {
			if (!FinishConnState2(dbaw))
				client_state = CLIENT_ERROR;
			break;
		}
		case DBA_b1_Entity_Client_Save: {
			char errbuf[MYSQL_ERRMSG_SIZE];
			int32 affected_rows = 0;
			DBAsyncQuery* dbaq = dbaw->PopAnswer();
			if (dbaq->GetAnswer(errbuf, 0, &affected_rows) && affected_rows == 1) {
				if (dbaq->QPT()) {
					SaveBackup();
				}
			}
			else {
				cout << "Async client save failed. '" << errbuf << "'" << endl;
				Message(13, "Error: Asyncronous save of your character failed.");
				if (Admin() >= 200)
					Message(13, "errbuf: %s", errbuf);
			}
			pQueuedSaveWorkID = 0;
			break;
		}
		default: {
			cout << "Error: Client::DBAWComplete(): Unknown workpt_b1" << endl;
			break;
		}
	}
}

bool Client::FinishConnState2(DBAsyncWork* dbaw) {
	uint32 pplen = 0;
	DBAsyncQuery* dbaq = 0;
	EQZonePacket* outapp = 0;
	MYSQL_RES* result = 0;
	bool loaditems = 0;
	char errbuf[MYSQL_ERRMSG_SIZE];
	int i;
	
	for (i=1; i<=3; i++) {
		dbaq = dbaw->PopAnswer();
		if (!dbaq) {
			cout << "Error in FinishConnState2(): dbaq==0" << endl;
			return false;
		}
		if (!dbaq->GetAnswer(errbuf, &result)) {
			cout << "Error in FinishConnState2(): !dbaq[" << dbaq->QPT() << "]->GetAnswer(): " << errbuf << endl;
			return false;
		}
		if (dbaq->QPT() == 1) {
			database.GetAccountInfoForLogin_result(result, 0, account_name, &lsaccountid, &gmspeed, &revoked, &gmhideme);
		}
		else if (dbaq->QPT() == 2) {
			loaditems = database.GetCharacterInfoForLogin_result(result, 0, 0, &m_pp, &m_inv, &m_epp, &pplen, &guilddbid, &guildrank);
		}
		else if (dbaq->QPT() == 3) {
			database.LoadFactionValues_result(result, &factionvalue_list);
		}
		else {
			cout << "Error in FinishConnState2(): dbaq->PQT() unknown" << endl;
			return false;
		}
	}
	
	conn_state = PlayerProfileLoaded;
	
	char temp1[64];
	if (database.GetVariable("Max_AAXP", temp1, sizeof(temp1)-1)) {
		max_AAXP = (atoi(temp1)*16)/10;
	}
	
	//int32 aalen = database.GetPlayerAlternateAdv(account_id, name, &aa);
	//if (aalen == 0) {
	//	cout << "Client dropped: !GetPlayerAlternateAdv, name=" << name << endl;
	//	return false;
	//}
	
	
	
	////////////////////////////////////////////////////////////	// Player Profile Packet
	// Try to find the EQ ID for the guild, if doesnt exist, guild has been deleted.

	// Clear memory, but leave it in the DB (no reason not to, guild might be restored?)
	strcpy(name, m_pp.name);
	strcpy(lastname, m_pp.last_name);
	if((m_pp.x == -1 && m_pp.y == -1 && m_pp.z == -1)||(m_pp.x == -2 && m_pp.y == -2 && m_pp.z == -2)) {
		m_pp.x = zone->safe_x();
		m_pp.y = zone->safe_y();
		m_pp.z = zone->safe_z();
	}

	x_pos		= m_pp.x;
	y_pos		= m_pp.y;
	z_pos		= m_pp.z;
	heading		= m_pp.heading;
	race		= m_pp.race;
	base_race	= m_pp.race;
	class_		= m_pp.class_;
	gender		= m_pp.gender;
	base_gender	= m_pp.gender;
	level		= m_pp.level;
	deity		= m_pp.deity;//FYI: DEITY_AGNOSTIC = 396; still valid?
	haircolor	= m_pp.haircolor;
	beardcolor	= m_pp.beardcolor;
	eyecolor1	= m_pp.eyecolor1;
	eyecolor2	= m_pp.eyecolor2;
	hairstyle	= m_pp.hairstyle;
	luclinface	= m_pp.face;
// vesuvias - appearence fix
	beard		= m_pp.beard;
	
	
	//if we zone in with invalid Z, fix it.
	if (zone->map != NULL) {
		
		//for whatever reason, LineIntersectsNode is giving better results than FindBestZ
		
		NodeRef pnode;
		VERTEX me;
		me.x = GetX();
		me.y = GetY();
		me.z = GetZ() + (GetSize()==0.0?6:GetSize());
		pnode = zone->map->SeekNode( zone->map->GetRoot(), me.x, me.y );
		
		VERTEX hit;
		VERTEX below_me(me);
		below_me.z -= 500;
		if(!zone->map->LineIntersectsNode(pnode, me, below_me, &hit, NULL) || hit.z < -5000) {
#if EQDEBUG >= 5
			LogFile->write(EQEMuLog::Debug, "Player %s started below the zone trying to fix! (%.3f, %.3f, %.3f)", GetName(), me.x, me.y, me.z);
#endif
			//theres nothing below us... try to find something to stand on
			me.z += 200;	//arbitrary #
			if(zone->map->LineIntersectsNode(pnode, me, below_me, &hit, NULL)) {
				//+10 so they dont stick in the ground
				SendTo(me.x, me.y, hit.z + 10);
				m_pp.z = hit.z + 10;
			} else {
				//one more, desperate try
				me.z += 2000;
				if(zone->map->LineIntersectsNode(pnode, me, below_me, &hit, NULL)) {
				//+10 so they dont stick in the ground
					SendTo(me.x, me.y, hit.z + 10);
					m_pp.z = hit.z + 10;
				}
			}
		}
	}

	//m_pp.hunger_level = 6000;
	//m_pp.thirst_level = 6000;
	
	//aa_title	= m_pp.aa_title;
	//m_pp.timeplayed=64;
	//m_pp.birthday=1057434792;
	//m_pp.lastlogin=1057464792;

	if (m_pp.gm && admin < minStatusToBeGM)
		m_pp.gm = 0;
	
	if (m_pp.platinum < 0 || m_pp.gold < 0 || m_pp.silver < 0 || m_pp.copper < 0 || m_pp.platinum > 1000000 || m_pp.gold > 1000000 || m_pp.silver > 1000000 || m_pp.copper > 1000000)
	{
		m_pp.platinum = 0;
		m_pp.gold = 0;
		m_pp.silver = 0;
		m_pp.copper = 0;
	}
	guildeqid = database.GetGuildEQID(guilddbid);
	if (guildeqid == GUILD_NONE) {
		guilddbid = 0;
		guildrank = GUILD_MEMBER;
		m_pp.guildid = 0xFFFFFFFF;
	}
	else
		m_pp.guildid = guildeqid;
	
	switch (race)
	{
		case OGRE:
			size = 9;break;
		case TROLL:
			size = 8;break;
		case VAHSHIR:

		case FROGLOK: //Frog
		case BARBARIAN:
			size = 7;break;
		case HUMAN:
		case HIGH_ELF:
		case ERUDITE:
		case IKSAR:
			size = 6;break;
		case HALF_ELF:
			size = 5.5;break;
		case WOOD_ELF:
		case DARK_ELF:
			size = 5;break;
		case DWARF:
			size = 4;break;
		case HALFLING:
			size = 3.5;break;
		case GNOME:
			size = 3;break;
		default:
			size = 0;break;
	}
	
	//validate skills
	for (int sk = 1; sk < MAX_PP_SKILL; sk++) {
		//int cap = GetSkillCap(sk-1);
		int cap = MaxSkill(sk-1, GetClass(), GetLevel());
		if (cap >= 254)
			m_pp.skills[sk] = cap;
	}
	
	if(GetSkill(SWIMMING) < 100)
		SetSkill(SWIMMING,100);
#ifdef GUILDWARS
	m_pp.ldon_guk_points = 0;
	m_pp.ldon_mirugal_points = 0;
	m_pp.ldon_mistmoore_points = 0;
	m_pp.ldon_rujarkian_points = 0;
	m_pp.ldon_takish_points = 0;
	m_pp.ldon_available_points = 0;
	permitflag = false;
	if(m_pp.pvp)
		m_pp.pvp = false;
	if(m_pp.anon && Admin() == 0)
		m_pp.anon = 0;
	profit = 0;
	if(GuildDBID() != 0 && GuildRank() == 2)
	{
	GuildLocation* gl = 0;
	gl = location_list.FindClosestLocationByClient(this);
	if(gl != 0 && gl->GetLocationType() == CITY && gl->GetGuildOwner() == GuildDBID())
	{
	if(gl->GetProfit() > 0)
	{
	m_pp.platinum_bank += gl->GetProfit()/1000;
	profit = gl->GetProfit()/1000;
	gl->SetProfit(0);
	database.SetLocationProfit(gl->GetLocationID(),0);
	}
	}
	}
	if(GuildDBID() != 0)
	{
	this->castpercentbonus = location_list.GetCasterAttackBonus(GuildDBID());
	this->meleepercentbonus = location_list.GetMeleeAttackBonus(GuildDBID());
	}
					sint32 availpts = database.GetAvailablePoints(CharacterID(),0);
#ifdef GWDEBUG
					printf("Available points: %i for %s\n",availpts,GetName());
#endif
					if(availpts == -9999999)
					{
#ifdef GWDEBUG
					printf("Setting up points table for %s\n",GetName());
#endif
						database.SetupPointsTable(CharacterID(),0,GetName());
						availpts = 0;
					}
					if(availpts < 0)
					availpts = 0;

					m_pp.ldon_available_points = (int32)availpts;

						guildwars.SetCurrentUsers(numclients);
						if(guildwars.GetCurrentUsers() > guildwars.GetMaxUsers())
							guildwars.SetMaxUsers(numclients);
#endif

	if (spells_loaded)
	{
		for(int z=0;z<MAX_PP_MEMSPELL;z++)
		{
			if(m_pp.mem_spells[z] >= (int32)SPDAT_RECORDS)
				UnmemSpell(z, false);
		}

		for (i = 0; i < BUFF_COUNT; i++) {
			for(int z = 0; z < BUFF_COUNT; z++) {
			// check for duplicates
				if(buffs[z].spellid != SPELL_UNKNOWN && buffs[z].spellid == m_pp.buffs[i].spellid) {
					buffs[z].spellid = SPELL_UNKNOWN;
					m_pp.buffs[i].spellid = 0xFFFFFFFF;
				}
			}
			
			if (m_pp.buffs[i].spellid <= (int32)SPDAT_RECORDS && m_pp.buffs[i].spellid != 0 && m_pp.buffs[i].duration > 0) {
				if(m_pp.buffs[i].level == 0 || m_pp.buffs[i].level > 100)
					m_pp.buffs[i].level = 1;
				if(m_pp.buffs[i].duration < 3)	//make em last till they get in
					m_pp.buffs[i].duration = 3;
				m_pp.buffs[i].slotid = (i+1);
				buffs[i].spellid			= m_pp.buffs[i].spellid;
				buffs[i].ticsremaining		= m_pp.buffs[i].duration;
				buffs[i].casterlevel		= m_pp.buffs[i].level;
				buffs[i].casterid			= 0;
				buffs[i].durationformula	= spells[buffs[i].spellid].buffdurationformula;
				buffs[i].poisoncounters		= m_pp.buffs[i].poisoncounters;
				buffs[i].diseasecounters	= m_pp.buffs[i].diseasecounters;
			}
			else {
				buffs[i].spellid = SPELL_UNKNOWN;
				m_pp.buffs[i].spellid = 0xFFFFFFFF;
				m_pp.buffs[i].slotid = 0;
				m_pp.buffs[i].level = 0;
				m_pp.buffs[i].duration = 0;
				m_pp.buffs[i].effect = 0;

			}
		}
		
		//I believe these effects are stripped off because if they
		//are not, they result in permanent effects on the player
		for (int j1=0; j1 < BUFF_COUNT; j1++) {
			if (buffs[j1].spellid <= (int32)SPDAT_RECORDS) {
				for (int x1=0; x1 < EFFECT_COUNT; x1++) {
					switch (spells[buffs[j1].spellid].effectid[x1]) {
						case SE_Charm:
						case SE_Rune:
						case SE_Illusion:
							buffs[j1].spellid = SPELL_UNKNOWN;
							m_pp.buffs[j1].spellid = SPELLBOOK_UNKNOWN;
							m_pp.buffs[j1].slotid = 0;
							m_pp.buffs[j1].level = 0;
							m_pp.buffs[j1].duration = 0;
							m_pp.buffs[j1].effect = 0;
							x1 = EFFECT_COUNT;
							break;
						// We can't send appearance packets yet, put down at CompleteConnect
					}
				}
			}
		}
		
		//Validity check for memorized
		if(Admin() < minStatusToHaveInvalidSpells) {
			for (int mem = 0; mem < MAX_PP_MEMSPELL; mem++)
			{
				if (m_pp.mem_spells[mem] < 1 || m_pp.mem_spells[mem] >= (unsigned int)SPDAT_RECORDS || spells[m_pp.mem_spells[mem]].classes[GetClass()-1] < 1 || spells[m_pp.mem_spells[mem]].classes[GetClass()-1] > GetLevel())
					m_pp.mem_spells[mem] = SPELLBOOK_UNKNOWN;
			}
			for (int bk = 0; bk < MAX_PP_SPELLBOOK; bk++)
			{
				if (m_pp.spell_book[bk] < 1 
					|| m_pp.spell_book[bk] >= (unsigned int)SPDAT_RECORDS 
					|| spells[m_pp.spell_book[bk]].classes[GetClass()-1] < 1 
					|| spells[m_pp.spell_book[bk]].classes[GetClass()-1] > LEVEL_CAP)
					m_pp.spell_book[bk] = SPELLBOOK_UNKNOWN;
			}
		}
	}
	
	CalcBonuses();
	CalcMaxHP();
	CalcMaxMana();
	if (m_pp.cur_hp <= 0)
		m_pp.cur_hp = GetMaxHP();
	
	SetHP(m_pp.cur_hp);
	Mob::SetMana(m_pp.mana);
	
	m_pp.zone_change_count++;
	
	int32 groupid = database.GetGroupID(GetName());
#ifdef _EQDEBUG
		printf("Loaded group id %lu from DB.\n", groupid);
#endif
	Group* group = NULL;
	if(groupid > 0){
		group = entity_list.GetGroupByID(groupid);
		if(!group) {	//nobody from our is here... start a new group
#ifdef _EQDEBUG
			printf("Nobody in group is in this zone, making new group object.");
#endif
			group = new Group(groupid);
			if(group->GetID() != 0)
				entity_list.AddGroup(group, groupid);
			else	//error loading group members...
				group = NULL;
		}	//else, somebody from our group is allready here...
		
		if(group)
			group->UpdatePlayer(this);
		else
			database.SetGroupID(GetName(), 0);	//cannot re-establish group, kill it
		
	} else {	//no group id
		//clear out the group junk in our PP
		int xy=0;
		for(xy=0;xy < MAX_GROUP_MEMBERS;xy++)
			memset(m_pp.groupMembers[xy], 0, 64);
	}

	if(m_pp.z <= zone->newzone_data.underworld) {
		m_pp.x = zone->newzone_data.safe_x;
		m_pp.y = zone->newzone_data.safe_y;
		m_pp.z = zone->newzone_data.safe_z;
	}
	if(m_pp.class_==SHADOWKNIGHT || m_pp.class_==PALADIN){
		int32 abilitynum=0;
		if(m_pp.class_==SHADOWKNIGHT)
			abilitynum = pTimerHarmTouch;
		else
			abilitynum = pTimerLayHands;
		//int32 remaining = database.GetTimerRemaining(CharacterID(),abilitynum);
		
		//returns 0 or 0xFFFFFFFF if timer is not set.
		int32 remaining = p_timers.GetRemainingTime(abilitynum);
		
		if(remaining > 0 && remaining < 15300){
			m_pp.ability_down=1;
			m_pp.ability_up=0;
			m_pp.ability_number=abilitynum;
			int8 minutes=0;
			int8 hours=0;
			if(remaining>3600){
				hours=(remaining/3600);
				remaining=remaining-(hours*3600);
			}
			if(remaining>60){
				minutes=(remaining/60);
				remaining=remaining-(minutes*60);
			}
			m_pp.ability_time_minutes=minutes;
			m_pp.ability_time_seconds=remaining;
			m_pp.ability_time_hours=hours;
			AbilityTimer=true;
		}
		else{
			m_pp.ability_down=0;
			m_pp.ability_up=1;
			m_pp.ability_number=0;
			m_pp.ability_time_minutes=0;
			m_pp.ability_time_seconds=0;
			m_pp.ability_time_hours=0;
		}
	}
	char val[20] = {0};
	if (database.GetVariable("Expansions", val, 20))
		m_pp.expansion = atoi(val);
	else
		m_pp.expansion = 0x1FF;
	
	p_timers.SetCharID(CharacterID());
	if(!p_timers.Load()) {
		//report it...
	}
	if(!p_timers.Expired(pTimerDisciplineReuse)) {
		//reset this so they get the avaliable message.
		disc_timer.Start(p_timers.GetRemainingTime(pTimerDisciplineReuse)*1000);
	}
#ifdef _EQDEBUG	
	printf("Dumping inventory on load:\n");
	m_inv.dumpInventory();
#endif
	strcpy(m_pp.servername,"eqemulator");
	m_pp.air_remaining = 60; //Reset to max so they dont drown on zone in if its underwater
	if(zone->IsPVPZone())
		m_pp.pvp=1;
	CRC32::SetEQChecksum((unsigned char*)&m_pp, sizeof(PlayerProfile_Struct)-4);
	outapp = new EQZonePacket(OP_PlayerProfile,sizeof(PlayerProfile_Struct));
#ifdef SOLAR
	printf("PP size: %d\n", sizeof(PlayerProfile_Struct));
#endif
	memcpy(outapp->pBuffer,&m_pp,outapp->size);
	outapp->priority = 6;
	FastQueuePacket(&outapp);

	
	//this was moved before the spawn packets are sent 
	//in hopes that it adds more consistency...
	//Remake pet
	if (m_epp.pet_id > 1 && !GetPet() && m_epp.pet_id <= SPDAT_RECORDS)
	{
		MakePet(m_epp.pet_id, spells[m_epp.pet_id].teleport_zone, m_epp.pet_name);
		if (GetPet() && GetPet()->IsNPC()) {
			NPC *pet = GetPet()->CastToNPC();
			pet->SetHP(m_epp.pet_hp);
			pet->SetMana(m_epp.pet_mana);
			pet->SetPetState(m_epp.pet_buffs, m_epp.pet_items);
		}
		m_epp.pet_id = 0;
	}
	
	////////////////////////////////////////////////////////////
	// Server Zone Entry Packet
	outapp = new EQZonePacket(OP_ZoneEntry, sizeof(ServerZoneEntry_Struct));
	ServerZoneEntry_Struct* sze = (ServerZoneEntry_Struct*)outapp->pBuffer;

	FillSpawnStruct(&sze->player,CastToMob());
	sze->player.spawn.curHp=1;
	sze->player.spawn.NPC=0;
	sze->player.spawn.z += 6;	//arbitrary lift, seems to help spawning under zone.
	outapp->priority = 6;
	FastQueuePacket(&outapp);
	//safe_delete(outapp);
	
	////////////////////////////////////////////////////////////
	// Zone Spawns Packet
	entity_list.SendZoneSpawnsBulk(this);
	entity_list.SendZoneCorpsesBulk(this);
	entity_list.SendTraders(this);
	
	
	
	////////////////////////////////////////////////////////////
	// Time of Day packet
	outapp = new EQZonePacket(OP_TimeOfDay, sizeof(TimeOfDay_Struct));
	TimeOfDay_Struct* tod = (TimeOfDay_Struct*)outapp->pBuffer;
	zone->zone_time.getEQTimeOfDay(time(0), tod);
	outapp->priority = 6;
	FastQueuePacket(&outapp);
	//safe_delete(outapp);
	
	//I think this should happen earlier, not sure
	if(GetHideMe())
		SetHideMe(true);
	
	
	////////////////////////////////////////////////////////////
	// Tribute Packets
	DoTributeUpdate();
	if(m_pp.tribute_active) {
		//restart the tribute timer where we left off
		tribute_timer.Start(m_pp.tribute_time_remaining);
	}
	
	////////////////////////////////////////////////////////////
	// Character Inventory Packet
	//this is not quite where live sends inventory, they do it after tribute
	if (loaditems) {//dont load if a length error occurs
		BulkSendInventoryItems();
		
		// Send stuff on the cursor which isnt sent in bulk
		iter_queue it;
		for (it=m_inv.cursor_begin();it!=m_inv.cursor_end();it++) {
			// First item cursor is sent in bulk inventory packet
			if (it==m_inv.cursor_begin())
				continue;
			const ItemInst *inst=*it;
			SendItemPacket(SLOT_CURSOR, inst, ItemPacketSummonItem);
		}
	}
	
	
	////////////////////////////////////////////////////////////
	// Task Packets
	//TODO: send active tasks here
	//TODO: send task history here
	EQZonePacket *taskpack = new EQZonePacket(OP_CompletedTasks, 4);
	FastQueuePacket(&taskpack);
	
	
	//////////////////////////////////////
	// Weather Packet
	// This shouldent be moved, this seems to be what the client
	// uses to advance to the next state (sending ReqNewZone)
	outapp = new EQZonePacket(OP_Weather, 12);
	if (zone->zone_weather == 1)
		outapp->pBuffer[4] = 0x31; // Rain
	if (zone->zone_weather == 2)
	{
		outapp->pBuffer[8] = 0x01;
		outapp->pBuffer[4] = 0x02;
	}
	outapp->priority = 6;
	QueuePacket(outapp);
	safe_delete(outapp);
	
	
	SetAttackTimer();
	
	conn_state = ZoneInfoSent;
	
	return true;
}

// Finish client connecting state
void Client::CompleteConnect()
{

	UpdateWho();
//	database.UpdateTimersClientConnected(CharacterID());
	client_state = CLIENT_CONNECTED;
	
	hpupdate_timer.Start();
	position_timer.Start();
	SetDuelTarget(0);
	SetDueling(false);
	

#ifdef GUILDWARS
	guildwars.EnteringMessages(this);
#endif

#ifdef RAIDADDICTS
	raidaddicts.ZoneIn(this);
#endif

	// Sets GM Flag if needed & Sends Petition Queue
	UpdateAdmin(false);

	if(GuildEQID()>0 && GuildEQID()<0xFFFFFFFF){
		SendAppearancePacket(AT_GuildID, GuildEQID(), false);
		SendAppearancePacket(AT_GuildRank, GuildRank(), false);
	}
	for(int spellInt= 0; spellInt < MAX_PP_SPELLBOOK; spellInt++)
	{
		if (m_pp.spell_book[spellInt] < 3 || m_pp.spell_book[spellInt] > 20000)
			m_pp.spell_book[spellInt] = 0xFFFFFFFF;
	}

	for(int a=0; a < MAX_PP_AA_ARRAY; a++){
		aa[a] = &m_pp.aa_array[a];
		int32 id = aa[a]->AA;
		if(aa[a]->value>1)
			aa_points[(id - aa[a]->value +1)] = aa[a]->value;
		else
			aa_points[id] = aa[a]->value;
	}
	//SendAATable();
	
	//reapply some buffs
	for (uint32 j1=0; j1 < BUFF_COUNT; j1++) {
		if (buffs[j1].spellid > (int32)SPDAT_RECORDS)
			continue;
		
		const SPDat_Spell_Struct &spell = spells[buffs[j1].spellid];
		
		for (int x1=0; x1 < EFFECT_COUNT; x1++) {
			switch (spell.effectid[x1]) {
				case SE_Illusion: {
					if (spell.base[x1] == -1) {
						if (gender == 1)
							gender = 0;
						else if (gender == 0)
							gender = 1;
						SendIllusionPacket(GetRace(), gender, 0xFFFF, 0xFFFF);
					}
					else if (spell.base[x1] == -2)
					{
						if (GetRace() == 128 || GetRace() == 130 || GetRace() <= 12)
							SendIllusionPacket(GetRace(), GetGender(), spell.max[x1], spell.max[x1]);
					}
					else if (spell.max[x1] > 0)
					{
						SendIllusionPacket(spell.base[x1], 0xFF, spell.max[x1], spell.max[x1]);
					}
					else
					{
						SendIllusionPacket(spell.base[x1], 0xFF, 0xFFFF, 0xFFFF);
					}
					break;
				}
				case SE_SummonHorse: {
					SummonHorse(buffs[j1].spellid);
					//hasmount = true;	//this was false, is that the correct thing?
					break;
				}
				case SE_Rune: {
					BuffFadeBySpellID(buffs[j1].spellid);
					//SetRune(buffs[j1].durationformula);
					//Somehow we need to toss the remaining rune value over..
				}
				case SE_DivineAura:
					{
					invulnerable = true;
					break;
					}
				case SE_Invisibility: 
					{
					invisible = true;
					SendAppearancePacket(AT_Invis, 1);
					break;
					}
				case SE_Levitate:
					{
					SendAppearancePacket(AT_Levitate, 2);
					break;
					}
				case SE_InvisVsUndead: 
					{
					invisible_undead = true;
					break;
					} 
			}
		}
	}
	
	client_data_loaded = true;
	int x;
	for(x=0;x<8;x++)
		SendWearChange(x);
	Mob *pet = GetPet();
	if(pet != NULL) {
		for(x=0;x<8;x++)
			pet->SendWearChange(x);
	}
	zoneinpacket_timer.Start();
	
	conn_state = ClientConnectFinished;
}


void Client::Handle_OP_LeadershipExpToggle(const EQZonePacket *app) {
	if(app->size != 1) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_LeadershipExpToggle expected %i got %i", 1, app->size);
		DumpPacket(app);
		return;
	}
	uint8 *mode = (uint8 *) app->pBuffer;
	if(*mode) {
		//TODO: enable leadership EXP
	} else {
		//TODO: disable leadership EXP
	}
}


void Client::Handle_OP_PurchaseLeadershipAA(const EQZonePacket *app) {
	if(app->size != sizeof(uint32)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_LeadershipExpToggle expected %i got %i", 1, app->size);
		DumpPacket(app);
		return;
	}
	uint32 aaid = *((uint32 *) app->pBuffer);
	
	if(aaid >= _maxLeaderAA)
		return;
	
	uint32 current_rank = m_pp.leader_abilities.ranks[aaid];
	if(current_rank >= MAX_LEADERSHIP_TIERS) {
		Message(13, "This ability can be trained no further.");
		return;
	}
	
	int8 cost = LeadershipAACosts[aaid][current_rank];
	if(cost == 0) {
		Message(13, "This ability can be trained no further.");
		return;
	}
	
	//TODO: we need to enforce prerequisits
	
	if(aaid >= raidAAMarkNPC) {
		//it is a raid ability.
		if(cost > m_pp.raid_leadership_points) {
			Message(13, "You do not have enough points to purchase this ability.");
			return;
		}
		
		//sell them the ability.
		m_pp.raid_leadership_points -= cost;
		m_pp.leader_abilities.ranks[aaid]++;
	} else {
		//it is a group ability.
		if(cost > m_pp.group_leadership_points) {
			Message(13, "You do not have enough points to purchase this ability.");
			return;
		}
		
		//sell them the ability.
		m_pp.group_leadership_points -= cost;
		m_pp.leader_abilities.ranks[aaid]++;
	}
	
	//success, send them an update
	/*EQZonePacket *outapp = new EQZonePacket(OP_UpdateLeadershipAA, sizeof(UpdateLeadershipAA_Struct));
	UpdateLeadershipAA_Struct *u = (UpdateLeadershipAA_Struct *) outapp->pBuffer;
	u->ability_id = aaid;
	u->new_rank = m_pp.leader_abilities.ranks[aaid];
	FastQueuePacket(&outapp);*/
}

void Client::Handle_OP_SetTitle(const EQZonePacket *app) {
	m_pp.title[0] = '\0';
	//TODO: send some sort of update struct to everybody.
}

void Client::Handle_OP_RequestTitles(const EQZonePacket *app) {
	//zero length request
	//TODO: get the titles from somewhere, and ship em off
	
}

void Client::Handle_OP_BankerChange(const EQZonePacket *app)
{
	if(app->size != sizeof(BankerChange_Struct)) {
		LogFile->write(EQEMuLog::Debug, "Size mismatch in OP_BankerChange expected %i got %i", sizeof(BankerChange_Struct), app->size);
		DumpPacket(app);
		return;
	}
	
	EQZonePacket *outapp=new EQZonePacket(OP_BankerChange,NULL,sizeof(BankerChange_Struct));
	BankerChange_Struct *bc=(BankerChange_Struct *)outapp->pBuffer;
	uint32 cp=m_pp.copper+(m_pp.silver*10)+(m_pp.gold*100)+(m_pp.platinum*1000);
	m_pp.copper=cp%10;
	cp/=10;
	m_pp.silver=cp%10;
	cp/=10;
	m_pp.gold=cp%10;
	cp/=10;
	m_pp.platinum=cp;

	cp=m_pp.copper_bank+(m_pp.silver_bank*10)+(m_pp.gold_bank*100)+(m_pp.platinum_bank*1000);
	m_pp.copper_bank=cp%10;
	cp/=10;
	m_pp.silver_bank=cp%10;
	cp/=10;
	m_pp.gold_bank=cp%10;
	cp/=10;
	m_pp.platinum_bank=cp;

	bc->copper=m_pp.copper;
	bc->silver=m_pp.silver;
	bc->gold=m_pp.gold;
	bc->platinum=m_pp.platinum;

	bc->copper_bank=m_pp.copper_bank;
	bc->silver_bank=m_pp.silver_bank;
	bc->gold_bank=m_pp.gold_bank;
	bc->platinum_bank=m_pp.platinum_bank;

	FastQueuePacket(&outapp);

	return;
}
