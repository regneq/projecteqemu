//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EMUCollect.rc
//
#define ID_MOBINFO                      3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EMUCOLLECT_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_PRIVACY                     129
#define IDD_DIALOG1                     130
#define IDD_MOBINFO                     131
#define IDC_WATCH_IP                    1001
#define IDC_UPLOAD_NAME                 1002
#define IDC_BINFILE                     1003
#define IDC_ITEMSONLY                   1004
#define IDC_ALLPACKETS                  1005
#define IDC_CollectDoors                1006
#define IDC_CollectObjects              1007
#define IDC_CollectZones                1008
#define IDC_CollectSpawns               1009
#define IDC_CollectGrids                1010
#define IDC_CollectItems                1011
#define IDC_BINLOGS                     1012
#define IDC_TEXTLOGS                    1013
#define IDC_SelectBinLog                1014
#define IDC_DBUpload                    1015
#define IDC_OPINCLUDE                   1016
#define IDC_OPEXCLUDE                   1017
#define IDC_ShowOpcodes                 1018
#define IDC_FilterNone                  1019
#define IDC_FilterInclude               1020
#define IDC_FilterExclude               1021
#define IDC_OPI_ADD                     1022
#define IDC_OPI_REMOVE                  1023
#define IDC_OPI_LOAD                    1024
#define IDC_OPI_SAVE                    1025
#define IDC_OPE_ADD                     1026
#define IDC_OPE_REMOVE                  1027
#define IDC_OPE_LOAD                    1028
#define IDC_OPE_SAVE                    1029
#define IDC_TEXTFILE                    1030
#define IDC_SelectTextLog               1031
#define IDC_STAT_RUNNING                1032
#define IDC_STAT_PACKETS                1033
#define IDC_STAT_ITEMS                  1034
#define IDC_BeginCollecting             1035
#define IDC_SC_GROUP                    1036
#define IDC_UPLOAD_LABEL                1037
#define IDC_RawLogging                  1038
#define IDC_DEVICE                      1039
#define IDC_StopCollecting              1040
#define IDC_DEBUG_CONSOLE               1041
#define IDC_PrivacyName                 1042
#define IDC_PrivacyMode                 1043
#define IDC_IgnoreWorld                 1044
#define IDC_ABOUTPRIVACY                1045
#define IDC_ForceFlush                  1046
#define IDC_PrivacyLabel                1047
#define IDC_TEXT                        1048
#define IDC_SaveSettings                1048
#define IDC_STAT_RUNNING2               1049
#define IDC_ONMOBINFO                   1050
#define IDC_MOBLIST                     1051
#define IDC_STAT_OPCODES                1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
