#define KEEP_DEFINES
#include "patch_121504.h"
#include "../common/opcodemgr.h"

namespace EQE_Patch_121504 {

ExtractorConcreteFactory::ExtractorConcreteFactory(const char *filename)
: ExtractorAbstractFactory("patch_121504.conf"),
zone_info(filename)
{
}

//Build all the extractors using our current structs
#define NO_ZONE_ID_IN_NEWZONE
#include "Extractors.cpp"

//Build the build file writer using our current structs
#define OLD_DELTAS
#include "BuildWriter.cpp"


};	//end namespace



