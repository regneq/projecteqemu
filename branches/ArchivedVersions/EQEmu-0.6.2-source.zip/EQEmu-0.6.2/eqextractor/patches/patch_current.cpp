#define KEEP_DEFINES
#include "patch_current.h"
#include "../common/opcodemgr.h"
#include "../common/files.h"

namespace EQE_Patch_Current {

ExtractorConcreteFactory::ExtractorConcreteFactory(const char *filename)
: ExtractorAbstractFactory(OPCODES_FILE),
zone_info(filename)
{
}

//Build all the extractors using our current structs
#include "Extractors.cpp"

//Build the build file writer using our current structs
#include "BuildWriter.cpp"


};	//end namespace



