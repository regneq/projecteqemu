#define KEEP_DEFINES
#include "patch_example.h"
#include "../common/opcodemgr.h"

namespace EQE_Patch_Example {

ExtractorConcreteFactory::ExtractorConcreteFactory(const char *filename)
: ExtractorAbstractFactory("patch_example.conf"),
zone_info(filename)
{
}

//Build all the extractors using our current structs
#include "Extractors.cpp"

//Build the build file writer using our current structs
#include "BuildWriter.cpp"


};	//end namespace



