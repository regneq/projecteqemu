#define KEEP_DEFINES
#include "patch_051105.h"
#include "../common/opcodemgr.h"

namespace EQE_Patch_051105 {

ExtractorConcreteFactory::ExtractorConcreteFactory(const char *filename)
: ExtractorAbstractFactory("patch_051105.conf"),
zone_info(filename)
{
}

//Build all the extractors using our current structs
#define SPAWN_DEBUG_MODE
#include "Extractors.cpp"

//Build the build file writer using our current structs
#include "BuildWriter.cpp"


};	//end namespace



