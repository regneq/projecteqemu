/*

EQ Extractor, by Father Nitwit 2005

*/
#include "Explorers.h"
#include "../common/eq_packet_structs.h"
#include "../common/MiscFunctions.h"
#include "../common/packet_dump.h"

void ZoneHeaderExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_NewZone)
		return;
	if(len != sizeof(NewZone_Struct)) {
		printf("Size of newzone struct is invalid! Cannot explore zone header.\n");
		return;
	}
	NewZone_Struct *i = (NewZone_Struct *) data;
	
	printf("\nNewZone_Struct (%s):\n", i->zone_short_name);
/*	PrintBlock(i, unknown323);
	PrintBlock(i, unknown360);
	PrintBlock(i, unknown331);
	PrintBlock(i, unknown_end);
	PrintBlock(i, unknown672);
*/	
	printf("%f (%f %f %f) (%f %f) (%f %f)\n",
		i->zone_exp_multiplier,
		i->safe_x,
		i->safe_y,
		i->safe_z,
		i->max_z,
		i->underworld,
		i->minclip,
		i->maxclip);
/*	PrintFloats(i, unknown323);
	PrintFloats(i, unknown360);
	PrintFloats(i, unknown331);
	PrintFloats(i, unknown_end);
	PrintFloats(i, unknown672);*/
	PrintFloatsReal("ns", (const char *) i, sizeof(NewZone_Struct));
}

void ObjectExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_GroundSpawn)
		return;
	if(len != sizeof(Object_Struct)) {
		printf("Size of object struct is invalid! Cannot explore this object.\n");
		return;
	}
	Object_Struct *i = (Object_Struct *) data;
	
	printf("\nObject_Struct (%s):\n", i->object_name);
	PrintBlock(i, unknown008);
	PrintBlock(i, unknown020);
	PrintBlock(i, unknown060);
	PrintBlock(i, unknown084);
}

/*struct Mask1 {
	sint32 n19:19,
		   n13:13;
};

struct Mask2 {
	sint32 n13:13,
		   n19:19;
};*/

void SpawnExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_ZoneSpawns && emu_op != OP_NewSpawn && emu_op != OP_ZoneEntry)
		return;
	if(len < sizeof(Spawn_Struct)) {
		printf("Size of spawn struct is invalid! Cannot explore spawn packet.\n");
		return;
	}
	
	uint32 used = 0;
	while(used < len) {
		Spawn_Struct *i = (Spawn_Struct *) (data + used);
//printf("Packet: %d/%lu\n", sizeof(Spawn_Struct), len);
//DumpPacket((unsigned char *) i, sizeof(Spawn_Struct));
		
		printf("\nSpawn_Struct (%s <%s> #%d):\n", i->name, i->lastName, i->spawnId);
		PrintBlock(i, findable);
		PrintBlock(i, unknown);
		PrintBlock(i, unknown0114);
		PrintBlock(i, unknown0126);
		PrintBlock(i, unknown0132);
		PrintBlock(i, unknown0156);
		PrintBlock(i, unknown0159);
		PrintBlock(i, unknown0167);
		PrintBlock(i, unknown0213);
		PrintBlock(i, unknown0259);
		PrintBlock(i, unknown0264);
		PrintBlock(i, unknown0276);
		PrintBlock(i, unknown0381);
		
/*		
		
		Mask1 *m1 = (Mask1 *) &i->deltaZ;
		Mask2 *m2 = (Mask2 *) &i->deltaZ;
		//28 bytes, 6 entries
		int r;
		for(r = 0; r < 6; r++) {
			printf("Masks: %d: 1(%f %f) 2(%f %f)\n", r, 
				EQ19toFloat(m1->n19), EQ13toFloat(m1->n13), 
				EQ19toFloat(m2->n19), EQ13toFloat(m2->n13) );
			m1++;
			m2++;
		}*/
		
		
		used += sizeof(Spawn_Struct);
	}
}

void ArrowExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_SomeItemPacketMaybe)
		return;
	if(len != sizeof(Arrow_Struct)) {
		printf("Size of arrow struct is invalid! Cannot explore zone header.\n");
		return;
	}
	Arrow_Struct *i = (Arrow_Struct *) data;
	
	printf("\nArrow_Struct (%s):\n", i->model_name);
	printf("Floats: from (%f %f %f)\n", i->src_x, i->src_y, i->src_z);
	PrintBlock(i, unknown004);
	PrintBlock(i, unknown028);
	PrintBlock(i, unknown052);
	PrintBlock(i, unknown064);
	PrintBlock(i, unknown088);
	PrintBlock(i, unknown092);
	PrintBlock(i, unknown096);
	PrintBlock(i, unknown117);
}

void SpawnListExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op == OP_SpawnAppearance && len == sizeof(SpawnAppearance_Struct)) {
		SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*) data;
		if(sa->type != AT_SpawnID)
			return;
		printf("# Spawn Appearance says my spawn ID is %d (net %02x %02x)\n",
			sa->parameter, sa->parameter&0xFF, (sa->parameter&0xFF00)>>8);
		return;
	}
	
	if(emu_op != OP_ZoneSpawns && emu_op != OP_NewSpawn && emu_op != OP_ZoneEntry)
		return;
	
	if(len < sizeof(Spawn_Struct)) {
		if(len != sizeof(ServerZoneEntry_Struct))
			printf("Size of spawn struct (%d) is invalid (want %d)! Cannot explore this spawn list.\n", len, sizeof(Spawn_Struct));
		return;
	}
	
	uint32 used = 0;
	while(used < len) {
		Spawn_Struct *i = (Spawn_Struct *) (data + used);
		
		printf("%04d(%02x %02x): %s %s (class %d, race %d, level %d)\n",
			i->spawnId, i->spawnId&0xFF, (i->spawnId&0xFF00)>>8,
			i->name, i->lastName, i->class_, i->race, i->level
			);
		
		used += sizeof(Spawn_Struct);
	}
}

void MessageExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	switch(emu_op) {
	case OP_FormattedMessage: {
		FormattedMessage_Struct *s = (FormattedMessage_Struct *) data;
		printf("Format %d: ", s->string_id);
		int len;
		const char *msg = s->message;
		len = strlen(msg);
		while(len > 0) {
			printf("'%s' ", msg);
			msg += len + 1;
			len = strlen(msg);
		}
		printf("\n");
		break;
	}
	case OP_SimpleMessage: {
		SimpleMessage_Struct *s = (SimpleMessage_Struct *) data;
		printf("Simple: %d\n", s->string_id);
		break;
	}
	case OP_ChannelMessage: {
		ChannelMessage_Struct *s = (ChannelMessage_Struct *) data;
		printf("Channel: %s->%s: \"%s\"\n", s->sender, s->targetname, s->message);
		break;
	}
	default:
		break;
	}
}

void DumpUnknownExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
/*	if(to_server) {
		printf("Client->Server: [ Opcode: %s Size: %d ]\n", );
	} else {
	}
*/	DumpPacket((unsigned char *) data, len);
}

void UnknownExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_ExploreUnknown)
		return;
	
	PrintBlockReal("p", (const char *) data, len);
}

#pragma pack(1)
struct u2struct {
	float f1;
	float f2;
	float f3;
	uint8 unknown12[5];
};
#pragma pack()
void Unknown2Explorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_ExploreUnknown)
		return;
	
	printf("\nNew Packet:\n");
	u2struct *p = (u2struct *) data;
	int count = (len-1)/sizeof(u2struct);
	for(; count > 0; count--) {
		printf("unknown: (%f, %f, %f):\n", p->f1, p->f2, p->f3);
		PrintBlock(p, unknown12);
	}
}

void ClientUpdateExplorer::GivePacket(EmuOpcode emu_op, unsigned char *data, uint32 len, bool to_server) {
	if(emu_op != OP_ClientUpdate)
		return;
	
	if(len == sizeof(PlayerPositionUpdateServer_Struct)) {
		PlayerPositionUpdateServer_Struct *i = (PlayerPositionUpdateServer_Struct *) data;
		
		if(i->spawn_id == forid) {
			printf("To-Client(%d): (%f %f %f @%f) d(%f %f %f @%f) a=%x\n",
				i->spawn_id,
				EQ19toFloat(i->x_pos),
				EQ19toFloat(i->y_pos),
				EQ19toFloat(i->z_pos),
				//EQ19toFloat(i->heading),
				float(i->heading),
				NewEQ13toFloat(i->delta_x),
				NewEQ13toFloat(i->delta_y),
				NewEQ13toFloat(i->delta_z),
				//EQ13toFloat(i->delta_heading),
				float(i->delta_heading),
				i->animation);
//DumpPacket((unsigned char *) data, len);
			
//			PrintBlock(i, unknown02);
		}
		
	} else if(len == sizeof(PlayerPositionUpdateClient_Struct)) {
		PlayerPositionUpdateClient_Struct *i = (PlayerPositionUpdateClient_Struct *) data;
		
		if(forid == 0)
			forid = i->spawn_id;
/*		printf("To-Server(%d): (%f %f %f @%f) d(%f %f %f @%f) a=%d,%d\n",
			i->spawn_id, 
			i->x_pos, i->y_pos, i->z_pos, float(i->heading),
			i->delta_x, i->delta_y, i->delta_z, float(i->delta_heading),
			i->animation, i->unknown20
			);
*/		
/*		printf("Heading: %d->%f, d %d->%f\n", 
			i->heading, EQ13toFloat(i->heading), 
			i->delta_heading, EQ19toFloat(i->delta_heading));
*/	
//		PrintBlockLen(i, unknown0006+14, 4);
//		PrintBlock(i, u20);
//		PrintBlockLen(i, delta_x, 8);

//DumpPacket((unsigned char *) data, len);			
//	PrintBlockReal("p", (const char *) data, len);
		
	} else  {
		printf("Size of client update (%lu) is invalid! Cannot explore this packet.\n", len);
		
printf("Packet: %lu need (%d,%d)\n", len, sizeof(PlayerPositionUpdateClient_Struct), sizeof(PlayerPositionUpdateServer_Struct));
DumpPacket((unsigned char *) data, len);
		return;
	}
}











