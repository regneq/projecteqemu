#ifndef __EQCLIENT_TYPES_H_
#define __EQCLIENT_TYPES_H_

typedef unsigned long uint32;
typedef long int32;

typedef unsigned short uint16;
typedef short int16;

typedef unsigned char uint8;
typedef unsigned char uchar;
typedef char int8;

#define null 0

#endif
