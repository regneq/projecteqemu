#include "../common/debug.h"
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef WIN32
	#include <pthread.h>
#endif
#include "faction.h"
#include "../common/database.h"
#include "client.h"

extern Database database;

#ifdef WIN32
	#define snprintf	_snprintf
#endif

//o--------------------------------------------------------------
//| Name: CalculateFaction; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Notes: Returns the faction message value.
//|        Modify these values to taste.
//o--------------------------------------------------------------
int8 CalculateFaction(FactionMods* fm, sint32 tmpCharacter_value)
{
	sint32 character_value;

	character_value = fm->base + fm->class_mod + fm->race_mod + fm->deity_mod + tmpCharacter_value;

	if(character_value >=  1101) return FACTION_ALLY;
	if(character_value >=   701 && character_value <= 1100) return FACTION_WARMLY;
	if(character_value >=   401 && character_value <=  700) return FACTION_KINDLY;
	if(character_value >=   101 && character_value <=  400) return FACTION_AMIABLE;
	if(character_value >=     0 && character_value <=  100) return FACTION_INDIFFERENT;
	if(character_value >=  -100 && character_value <=   -1) return FACTION_APPREHENSIVE;
	if(character_value >=  -700 && character_value <= -101) return FACTION_DUBIOUS;
	if(character_value >=  -999 && character_value <= -701) return FACTION_THREATENLY;
	if(character_value <= -1000) return FACTION_SCOWLS;
	else
	{
		return FACTION_INDIFFERENT;
	}
}

//o--------------------------------------------------------------
//| Name: GetFactionLevel; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Notes: Gets the characters faction standing with the
//|        specified NPC.
//|        Will return Indifferent on failure.
//o--------------------------------------------------------------
int8 Client::GetFactionLevel(int32 char_id, int32 npc_id, int32 p_race, int32 p_class, int32 p_deity)
{
	int32 pFaction;
	sint32 pFacValue;
	sint32 tmpFactionValue;
	FactionMods fmods;
	
	//First get the NPC's Primary faction
	if(database.GetNPCPrimaryFaction(npc_id, &pFaction, &pFacValue))
	{
		//Get the faction data from the database
		if(database.GetFactionData(&fmods, p_class, p_race, p_deity, pFaction))
		{
			//Get the players current faction with pFaction
			tmpFactionValue = database.GetCharacterFactionLevel(char_id, pFaction);
			//Return the faction to the client
			return CalculateFaction(&fmods, tmpFactionValue);
		}
	}

	return FACTION_INDIFFERENT;
}

//o--------------------------------------------------------------
//| Name: SetFactionLevel; rembrant, Dec. 20, 2001
//o--------------------------------------------------------------
//| Notes: Sets the characters faction standing with the
//|        specified NPC.
//o--------------------------------------------------------------
void  Client::SetFactionLevel(int32 char_id, int32 npc_id, int8 char_class, int8 char_race, int8 char_deity)
{
	int32 faction_id[]={ 0,0,0,0,0,0,0,0,0,0 };
	sint32 npc_value[]={ 0,0,0,0,0,0,0,0,0,0 };
	sint32 tmpValue;
	sint32 current_value;
	FactionMods fm;
	//Get the npc faction list
	if(database.GetNPCFactionList(npc_id, faction_id, npc_value))
	{
		for(int i = 0;i<=9;i++)
		{
			if(faction_id[i] != 0)
			{
				//Get the faction modifiers
				if(database.GetFactionData(&fm,char_class,char_race,char_deity,faction_id[i]))
				{
					//Get the characters current value with that faction
					current_value = database.GetCharacterFactionLevel(char_id, faction_id[i]) + npc_value[i];
					//Calculate the faction
					tmpValue = current_value + fm.base + fm.class_mod + fm.race_mod + fm.deity_mod;
					//Make sure we dont go over the min/max faction limits
					if(tmpValue >= MAX_FACTION) tmpValue = MAX_FACTION;
					if(tmpValue < MAX_FACTION && tmpValue > MIN_FACTION)
					{
						if(!(database.SetCharacterFactionLevel(char_id, faction_id[i], current_value)))
						{
							return;
						}
					}
					if(tmpValue <= MIN_FACTION) tmpValue = MIN_FACTION;
					//ChannelMessageSend(0,0,7,0,BuildFactionMessage(npc_value[i], faction_id[i]));
					Message(0,BuildFactionMessage(npc_value[i],faction_id[i]));
				}
			}
		}
	}
	return;
}

//o--------------------------------------------------------------
//| Name: GetNPCPrimaryFaction; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Purpose: Retrieves the primary faction_id and value for an
//|          NPC.
//|          Returns false on failure.
//o--------------------------------------------------------------
bool Database::GetNPCPrimaryFaction(int32 npc_id, int32* faction_id, sint32* value)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT faction_id, value FROM npc_faction WHERE npc_id = %i AND primary_faction = 1;", npc_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			*faction_id = atoi(row[0]);
			*value = atoi(row[1]);
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else
	{
		cerr << "Error in GetNPCPrimaryFaction query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
	return false;
}

//o--------------------------------------------------------------
//| Name: GetFactionData; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Notes: Retrieves the faction data for the specified 
//|        faction_id. Will return Indifferent on failure.
//o--------------------------------------------------------------
bool Database::GetFactionData(FactionMods* fm, sint32 class_mod, sint32 race_mod, sint32 deity_mod, int32 faction_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT base, mod_c%i, mod_r%i, mod_d%i FROM faction_list WHERE id = %i ", class_mod, race_mod, deity_mod, faction_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			fm->base = atoi(row[0]);
			fm->class_mod = atoi(row[1]);
			fm->race_mod = atoi(row[2]);
			fm->deity_mod = atoi(row[3]);
			mysql_free_result(result);				
			return true;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetFactionData query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

//o--------------------------------------------------------------
//| Name: GetCharacterFactionLevel; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Notes: Retrieves the characters faction level with the
//|        specified faction_id.
//|        Returns 0 on failure.
//o--------------------------------------------------------------
sint32 Database::GetCharacterFactionLevel(int32 char_id, int32 faction_id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT current_value FROM faction_values where char_id = %i and faction_id = %i", char_id, faction_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			sint32 tmp = atoi(row[0]);
			mysql_free_result(result);
			return tmp;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetCharacterFactionLevel query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return 0;
}

//o--------------------------------------------------------------
//| Name: BuildFactionMessage; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Purpose: duh?
//o--------------------------------------------------------------
char* BuildFactionMessage(sint32 tmpvalue, int32 faction_id)
{
	char *faction_message = 0;
	int buf_len = 256;
    int chars = -1;

	char name[50];

	if(database.GetFactionName(faction_id, name) == false)
	{
		snprintf(name, buf_len,"Faction%i",faction_id);
	}

	if(tmpvalue == MAX_FACTION)
	{
		while (chars == -1 || chars >= buf_len)
		{
			if (faction_message != 0)
			{
				delete[] faction_message;
				faction_message = 0;
				buf_len *= 2;
			}
			faction_message = new char[buf_len];
			chars = snprintf(faction_message, buf_len, "Your faction standing with %s could not possibly get any better!", name);
		}
	}
	if(tmpvalue > 0 && tmpvalue < MAX_FACTION)
	{
		while (chars == -1 || chars >= buf_len)
		{
			if (faction_message != 0)
			{
				delete[] faction_message;
				faction_message = 0;
				buf_len *= 2;
			}
			faction_message = new char[buf_len];
			chars = snprintf(faction_message, buf_len, "Your faction standing with %s has gotten better!", name);
		}
	}
	if(tmpvalue < 0 && tmpvalue > MIN_FACTION)
	{
		while (chars == -1 || chars >= buf_len)
		{
			if (faction_message != 0)
			{
				delete[] faction_message;
				faction_message = 0;
				buf_len *= 2;
			}
			faction_message = new char[buf_len];
			chars = snprintf(faction_message, buf_len, "Your faction standing with %s has gotten worse!", name);
		}
	}
	if(tmpvalue == MIN_FACTION)
	{
		while (chars == -1 || chars >= buf_len)
		{
			if (faction_message != 0)
			{
				delete[] faction_message;
				faction_message = 0;
				buf_len *= 2;
			}
			faction_message = new char[buf_len];
			chars = snprintf(faction_message, buf_len, "Your faction standing with %s could not possibly get any worse!", name);
		}
	}
	return faction_message;
}

//o--------------------------------------------------------------
//| Name: GetFactionName; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Notes: Retrieves the name of the specified faction
//|        Returns false on failure.
//o--------------------------------------------------------------
bool Database::GetFactionName(int32 faction_id, char* name)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT name FROM faction_list WHERE id = %i", faction_id), errbuf, &result)) {
		delete[] query;
		if (mysql_num_rows(result) == 1)
		{
			row = mysql_fetch_row(result);
			strcpy(name,row[0]);
			mysql_free_result(result);
			return true;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in GetFactionName query '" << query << "' " << errbuf << endl;
		delete[] query;
	}

	return false;
}

//o--------------------------------------------------------------
//| Name: GetNPCFactionList; rembrant, Dec. 16, 2001
//o--------------------------------------------------------------
//| Purpose: Gets a list of faction_id's and values bound to
//|          the npc_id.
//|          Returns false on failure.
//o--------------------------------------------------------------
bool Database::GetNPCFactionList(int32 npc_id, int32* faction_id, sint32* value)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;

	int i = 0;

	if (RunQuery(query, MakeAnyLenString(&query, "SELECT faction_id, value FROM npc_faction WHERE npc_id = %i", npc_id), errbuf, &result)) {
		delete[] query;
		while ((row = mysql_fetch_row(result)))
		{
			faction_id[i] = atoi(row[0]);
			value[i] = atoi(row[1]);
			i++;
		}
		mysql_free_result(result);
		return true;
	}
	else
	{
		cerr << "Error in GetCharSelectInfo query '" << query << "' " << errbuf << endl;
		delete[] query;
	}
	return false;
}

//o--------------------------------------------------------------
//| Name: SetCharacterFactionLevel; rembrant, Dec. 20, 2001
//o--------------------------------------------------------------
//| Purpose: Update characters faction level with specified
//|          faction_id to specified value.
//|          Returns false on failure.
//o--------------------------------------------------------------
bool Database::SetCharacterFactionLevel(int32 char_id, int32 faction_id, sint32 value)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
	int32 affected_rows = 0;

	if (!RunQuery(query, MakeAnyLenString(&query, "DELETE FROM faction_values WHERE char_id=%i AND faction_id = %i", char_id, faction_id), errbuf)) {
		cerr << "Error in SetCharacterFactionLevel query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	if (!RunQuery(query, MakeAnyLenString(&query, "INSERT INTO faction_values (char_id,faction_id,current_value) VALUES (%i,%i,%i)", char_id, faction_id,value), errbuf, 0, &affected_rows)) {
		cerr << "Error in SetCharacterFactionLevel query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (affected_rows == 0)
	{
		return false;
	}
	return true;
}
