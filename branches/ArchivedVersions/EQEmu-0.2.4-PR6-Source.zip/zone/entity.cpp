#include "../common/debug.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#ifdef WIN32
	#include <process.h>
#else
	#include <pthread.h>
#endif

#include "entity.h"
#include "client.h"
#include "npc.h"
#include "worldserver.h"
#include "PlayerCorpse.h"
#include "../common/packet_functions.h"
#include "ClientList.h"
#include "petitions.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp	_stricmp
#endif

extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern GuildRanks_Struct guilds[512];
extern ClientList client_list;
extern int32 numclients;

Entity::Entity()
{
	id = 0;
}

Entity::~Entity()
{
}

void Entity::SetID(int16 set_id)
{
	id = set_id;
}

Client* Entity::CastToClient()
{
#ifdef DEBUG
	if(!IsClient())
	{	
		cout << "CastToClient error" << endl;
		return 0;
	}
#endif
	return static_cast<Client*>(this);
}

NPC* Entity::CastToNPC()
{
#ifdef DEBUG
	if(!IsNPC())
	{	
		cout << "CastToNPC error" << endl;
		return 0;
	}
#endif
	return static_cast<NPC*>(this);
}

Mob* Entity::CastToMob()
{
#ifdef DEBUG
	if(!IsMob())
	{	
		cout << "CastToMob error" << endl;
		return 0;
	}
#endif
	return static_cast<Mob*>(this);
}

Corpse* Entity::CastToCorpse()
{
#ifdef DEBUG
	if(!IsCorpse())
	{	
		cout << "CastToCorpse error" << endl;
		return 0;
	}
#endif
	return static_cast<Corpse*>(this);
}

void EntityList::AddClient(Client* client)
{
	client->SetID(GetFreeID());

	list.Insert(client);
}

void EntityList::AddCorpse(Corpse* corpse, int32 in_id) {
	if (corpse == 0)
		return;

	if (in_id == 0xFFFFFFFF)
		corpse->SetID(GetFreeID());
	else
		corpse->SetID(in_id);
	corpse->CalcCorpseName();

	list.Insert(corpse);
}

void EntityList::AddNPC(NPC* npc, bool SendSpawnPacket) {
	npc->SetID(GetFreeID());

	if (SendSpawnPacket) {
		APPLAYER app;
		npc->CreateSpawnPacket(&app);
		QueueClients(npc, &app);
	}

	list.Insert(npc);
};

Entity* EntityList::GetID(int16 get_id)
{
	if (get_id == 0)
		return 0;
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == get_id)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

Mob* EntityList::GetMob(int16 get_id)
{
	if (get_id == 0)
		return 0;
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob() && iterator.GetData()->GetID() == get_id)
		{
			return iterator.GetData()->CastToMob();
		}
		iterator.Advance();
	}
	return 0;
}

Mob* EntityList::GetMob(char* name)
{
	if (name == 0)
		return 0;
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob() && strcasecmp(iterator.GetData()->GetName(), name) == 0)
		{
			return iterator.GetData()->CastToMob();
		}
		iterator.Advance();
	}
	return 0;
}

int16 EntityList::GetFreeID()
{
	while(1)
	{
		last_insert_id++;
		if (last_insert_id == 0)
			last_insert_id++;
		if (GetID(last_insert_id) == 0)
		{
			return last_insert_id;
		}
	}
}

void EntityList::ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (chan_num != 8 || client->Dist(from) < 100) // Only say is limited in range
			{
					client->ChannelMessageSend(from->GetName(), 0, chan_num, language, buffer);
			}
		}
		iterator.Advance();
	}
}

void EntityList::ChannelMessageSend(Mob* to, int8 chan_num, int8 language, char* message, ...)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (client->GetID() == to->GetID()) {
				client->ChannelMessageSend(0, 0, chan_num, language, buffer);
				break;
			}
		}
		iterator.Advance();
	}
}

void EntityList::SendZoneSpawns(Client* client)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	APPLAYER* app;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob())
		{
			if (iterator.GetData()->IsClient() && (!iterator.GetData()->CastToClient()->Connected() || iterator.GetData()->CastToClient()->GMHideMe(client)))
			{
				iterator.Advance();
				continue;
			}
			app = new APPLAYER;
			iterator.GetData()->CastToMob()->CreateSpawnPacket(app); // TODO: Use zonespawns opcode instead
			client->QueuePacket(app);
			delete app;
		}
		iterator.Advance();
	}	
}

void EntityList::Save()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->Save();
		iterator.Advance();
	}	
}

void EntityList::RemoveFromTargets(Mob* mob)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsNPC())
		{
			iterator.GetData()->CastToNPC()->RemoveFromHateList(mob);
		}
		if (iterator.GetData()->IsMob() && iterator.GetData()->CastToMob()->GetTarget() == mob)
		{
			iterator.GetData()->CastToMob()->SetTarget(0);			
		}
		iterator.Advance();
	}	
}

void EntityList::QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender, float dist, Mob* SkipThisMob) {
	if (sender == 0) {
		QueueClients(sender, app, ignore_sender);
		return;
	}
	if(dist <= 0) {
		dist = 600;
	}
	float dist2 = dist * dist; //pow(dist, 2);

	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsClient() && (!ignore_sender || iterator.GetData() != sender) && (iterator.GetData() != SkipThisMob)) {
			if(iterator.GetData()->CastToClient()->DistNoRoot(sender) <= dist2 || dist == 0) {
				iterator.GetData()->CastToClient()->QueuePacket(app);
			}
		}
		iterator.Advance();
	}	
}

void EntityList::QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && (!ignore_sender || iterator.GetData() != sender))
		{
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}


void EntityList::QueueClientsStatus(Mob* sender, APPLAYER* app, bool ignore_sender, int8 minstatus, int8 maxstatus)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && (!ignore_sender || iterator.GetData() != sender) && (iterator.GetData()->CastToClient()->Admin() >= minstatus && iterator.GetData()->CastToClient()->Admin() <= maxstatus))
		{
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}

void EntityList::AESpell(Mob* caster, Mob* center, float dist, int16 spell_id) {
	LinkedListIterator<Entity*> iterator(list);

	dist = dist*dist;

//cout << "AE Spell Cast: c=" << center->GetName() << ", d=" << dist << ", x=" << center->GetX() << ", y=" << center->GetY() << endl;
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob() && iterator.GetData()->CastToMob()->DistNoRootNoZ(center) <= dist && !(iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->GMHideMe()))
		{
//cout << "AE Spell Hit: t=" << iterator.GetData()->GetName() << ", d=" << iterator.GetData()->CastToMob()->DistNoRoot(center) << ", x=" << iterator.GetData()->CastToMob()->GetX() << ", y=" << iterator.GetData()->CastToMob()->GetY() << endl;
		if(caster->IsNPC() && iterator.GetData()->IsNPC()) //temp solution till zone can handle area effects for all
		{
		}
		else
		{
			caster->SpellOnTarget(spell_id, iterator.GetData()->CastToMob());
		}
		}
		iterator.Advance();
	}	
}

Client* EntityList::GetClientByName(char *checkname) 
{ 
       LinkedListIterator<Entity*> iterator(list); 
        
       iterator.Reset(); 
       while(iterator.MoreElements()) 
       { 
           if (iterator.GetData()->IsClient()) 
           { 
			   if (strcasecmp(iterator.GetData()->CastToClient()->GetName(), checkname) == 0) {
                   return iterator.GetData()->CastToClient();
			   }
           } 
           iterator.Advance(); 
       } 
       return 0; 
} 

Client* EntityList::GetClientByAccID(int32 accid) 
{ 
       LinkedListIterator<Entity*> iterator(list); 
        
       iterator.Reset(); 
       while(iterator.MoreElements()) 
       { 
           if (iterator.GetData()->IsClient()) 
           { 
			   if (iterator.GetData()->CastToClient()->AccountID() == accid) {
                   return iterator.GetData()->CastToClient();
			   }
           } 
           iterator.Advance(); 
       } 
       return 0; 
} 

void EntityList::ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int32 guilddbid, int8 language, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message: " << (int) chan_num << " " << (int) guilddbid << ": " << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (chan_num != 0 || (client->GuildDBID() == guilddbid && client->GuildEQID() != 0xFFFFFF && guilds[client->GuildEQID()].rank[client->GuildRank()].heargu))
				client->ChannelMessageSend(from, to, chan_num, language, buffer);
		}
		iterator.Advance();
	}
}

void EntityList::Message(int32 to_guilddbid, int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (to_guilddbid == 0 || client->GuildDBID() == to_guilddbid)
				client->Message(type, buffer);
		}
		iterator.Advance();
	}
}

void EntityList::MessageClose(Mob* sender, bool skipsender, float dist, int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->DistNoRoot(sender) <= dist && (!skipsender || iterator.GetData() != sender)) {
			iterator.GetData()->CastToClient()->Message(type, buffer);
		}
		iterator.Advance();
	}
}


// Safely removes all entities before zone shutdown
void EntityList::Clear()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->Save();
		if (iterator.GetData()->IsClient())
			client_list.Remove(iterator.GetData()->CastToClient());
		if (iterator.GetData()->IsMob())
			entity_list.RemoveFromTargets(iterator.GetData()->CastToMob());
		iterator.RemoveCurrent();
	}	
}

void EntityList::UpdateWho()
{
	if ((!worldserver.Connected()) || !ZoneLoaded)
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = true;
	strcpy(scl->zone, zone->GetShortName());
	worldserver.SendPacket(pack);
	delete pack;

	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->UpdateWho(false);
		}
		iterator.Advance();
	}	
}

void EntityList::RemoveEntity(int16 id)
{
	if (id == 0)
		return;
	LinkedListIterator<Entity*> iterator(list);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == id)
		{
			cout << "spawn deleted" << endl;
			if (iterator.GetData()->IsClient())
				client_list.Remove(iterator.GetData()->CastToClient());
			if (iterator.GetData()->IsMob())
				entity_list.RemoveFromTargets(iterator.GetData()->CastToMob());
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}

	cout << "error deleting spawn" << endl;
}

void EntityList::Process()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			if (iterator.GetData()->IsClient()) {
				client_list.Remove(iterator.GetData()->CastToClient());
#ifdef WIN32
				struct in_addr	in;
				in.s_addr = iterator.GetData()->CastToClient()->GetIP();
				cout << "Dropping client: Process=false, ip=" << inet_ntoa(in) << ", port=" << ntohs(iterator.GetData()->CastToClient()->GetPort()) << endl;
#endif
				zone->StartShutdownTimer();
				numclients--;
			}
			if (iterator.GetData()->IsMob())
				entity_list.RemoveFromTargets(iterator.GetData()->CastToMob());
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

void EntityList::CountNPC(int32* NPCCount, int32* NPCLootCount, int32* gmspawntype_count) {
	LinkedListIterator<Entity*> iterator(list);
	*NPCCount = 0;
	*NPCLootCount = 0;

	iterator.Reset();
	while(iterator.MoreElements())	
	{
		if (iterator.GetData()->IsNPC()) {
			(*NPCCount)++;
			(*NPCLootCount) += iterator.GetData()->CastToNPC()->CountLoot();
			if (iterator.GetData()->CastToNPC()->GetNPCTypeID() == 0)
				(*gmspawntype_count)++;
		}
		iterator.Advance();
	}
}

void EntityList::DoZoneDump(ZSDump_Spawn2* spawn2_dump, ZSDump_NPC* npc_dump, ZSDump_NPC_Loot* npcloot_dump, NPCType* gmspawntype_dump) {
	int32 spawn2index = 0;
	int32 NPCindex = 0;
	int32 NPCLootindex = 0;
	int32 gmspawntype_index = 0;

	if (npc_dump != 0) {
		LinkedListIterator<Entity*> iterator(list);
		NPC* npc = 0;
		iterator.Reset();
		while(iterator.MoreElements())	
		{
			if (iterator.GetData()->IsNPC()) {
				npc = iterator.GetData()->CastToNPC();
				if (spawn2_dump != 0)
					npc_dump[NPCindex].spawn2_dump_index = zone->DumpSpawn2(spawn2_dump, &spawn2index, npc->respawn2);
				npc_dump[NPCindex].npctype_id = npc->GetNPCTypeID();
				npc_dump[NPCindex].cur_hp = npc->GetHP();
				npc_dump[NPCindex].corpse = npc->IsCorpse();
//				if (npc_dump[NPCindex].corpse) {
//					npc_dump[NPCindex].decay_time_left = npc->GetDecayTime();
//				}
//				else {
					npc_dump[NPCindex].decay_time_left = 0xFFFFFFFF;
//				}
				npc_dump[NPCindex].x = npc->GetX();
				npc_dump[NPCindex].y = npc->GetY();
				npc_dump[NPCindex].z = npc->GetZ();
				npc_dump[NPCindex].heading = npc->GetHeading();
				npc_dump[NPCindex].copper = npc->copper;
				npc_dump[NPCindex].silver = npc->silver;
				npc_dump[NPCindex].gold = npc->gold;
				npc_dump[NPCindex].platinum = npc->platinum;
				if (npcloot_dump != 0)
					npc->DumpLoot(NPCindex, npcloot_dump, &NPCLootindex);
				if (gmspawntype_dump != 0) {
					if (npc->GetNPCTypeID() == 0) {
						memcpy(&gmspawntype_dump[gmspawntype_index], npc->NPCTypedata, sizeof(NPCType));
						npc_dump[NPCindex].gmspawntype_index = gmspawntype_index;
						gmspawntype_index++;
					}
				}
				NPCindex++;
			}
			iterator.Advance();
		}
	}
	if (spawn2_dump != 0)
		zone->DumpAllSpawn2(spawn2_dump, &spawn2index);
}

void EntityList::Depop() {
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->Depop(false);
		iterator.Advance();
	}
}

void EntityList::DepopCorpses() {
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsNPCCorpse()) {
			iterator.GetData()->Depop();
		}
		iterator.Advance();
	}
}

#define MAX_SPAWNS_PER_PACKET	50
/*
Bulk zone spawn packet, to be requested by the client on zone in
Does 50 updates per packet, can fine tune that if neccessary

-Quagmire
*/
void EntityList::SendZoneSpawnsBulk(Client* client)
{
	return;
	// DO NOT USE
	// we dont have the encyption function right for this packet
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	uchar *data = 0, *newdata = 0;
	int16 datasize = 0, newdatasize = 0;
	NewSpawn_Struct* bns = 0;
	int i = 0;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob())
		{
			if (iterator.GetData()->IsClient() && (!iterator.GetData()->CastToClient()->Connected() || iterator.GetData()->CastToClient()->GMHideMe(client)))
			{
				iterator.Advance();
				continue;
			}
			if (datasize < (sizeof(NewSpawn_Struct) * (i+1))) {
				// Step 100 spawns every time we run out of buffer space
				newdatasize = datasize + (100 * sizeof(NewSpawn_Struct));
				newdata = new uchar[newdatasize];
				memset(newdata, 0, newdatasize);
				if (data != 0) {
					memcpy(newdata, data, datasize);
					delete data;
				}
				data = newdata;
				datasize = newdatasize;
				newdata = 0;
				bns = (NewSpawn_Struct*) data;
			}
			iterator.GetData()->CastToMob()->FillSpawnStruct(&bns[i], client);
			i++;
		}
		iterator.Advance();
	}
	bns[0].ns_unknown1 = 2;
	cout << "DEBUG: " << i << endl;
	cout << "DEBUG: sizeof(NewSpawn_Struct)=" << sizeof(NewSpawn_Struct) << endl;
	cout << "DEBUG: i*sizeof(NewSpawn_Struct)=" << i * sizeof(NewSpawn_Struct) << endl;
	if (i > 0) {
		APPLAYER* outapp = new APPLAYER;
		outapp->opcode = OP_ZoneSpawns;
		outapp->pBuffer = new uchar[datasize];
		DumpPacket(data, i * sizeof(NewSpawn_Struct));
		outapp->size = DeflatePacket(data, i * sizeof(NewSpawn_Struct), outapp->pBuffer, datasize);
		EncryptSpawnPacket(outapp);
		DumpPacket(outapp);
		client->QueuePacket(outapp);
		delete outapp;
	}
}

#define MAX_SPAWN_UPDATES_PER_PACKET	25
/*
Bulk spawn update packet, to be requested by the client on a timer.
0 range = whole zone.
Does 50 updates per packet, can fine tune that if neccessary

-Quagmire
*/
void EntityList::SendPositionUpdates(Client* client, int32 cLastUpdate, float range, Entity* alwayssend) {
	range = range * range;
	LinkedListIterator<Entity*> iterator(list);

	APPLAYER* outapp = 0;
	SpawnPositionUpdates_Struct* spus = 0;
	Mob* mob = 0;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (outapp == 0) {
			outapp = new APPLAYER;
			outapp->opcode = OP_MobUpdate;
			outapp->size = sizeof(SpawnPositionUpdates_Struct) + (sizeof(SpawnPositionUpdate_Struct) * MAX_SPAWN_UPDATES_PER_PACKET);
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			spus = (SpawnPositionUpdates_Struct*) outapp->pBuffer;
		}
		if (iterator.GetData()->IsMob()) {
			mob = iterator.GetData()->CastToMob();
			if (!mob->IsCorpse() && iterator.GetData() != client && (mob->IsClient() || mob->LastChange() >= cLastUpdate) && (!iterator.GetData()->IsClient() || !iterator.GetData()->CastToClient()->GMHideMe(client))) {
				if (range == 0 || iterator.GetData() == alwayssend || mob->DistNoRootNoZ(client) <= range) {
					mob->MakeSpawnUpdate(&spus->spawn_update[spus->num_updates]);
					spus->num_updates++;
				}
			}
		}
		if (spus->num_updates >= MAX_SPAWN_UPDATES_PER_PACKET) {
			client->QueuePacket(outapp, false);
			delete outapp;
			outapp = 0;
		}
		iterator.Advance();
	}
	if (outapp != 0) {
		if (spus->num_updates > 0) {
			outapp->size = sizeof(SpawnPositionUpdates_Struct) + (sizeof(SpawnPositionUpdate_Struct) * spus->num_updates);
			client->QueuePacket(outapp, false);
		}
		delete outapp;
		outapp = 0;
	}
}

char* EntityList::MakeNameUnique(char* name) {
	bool used[100];
	memset(used, 0, sizeof(used));
	name[26] = 0; name[27] = 0; name[28] = 0; name[29] = 0;

	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	int len = 0;
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob()) {
			len = strlen(iterator.GetData()->CastToMob()->GetName());
			if (strncasecmp(iterator.GetData()->CastToMob()->GetName(), name, len - 2) == 0) {
				if (Seperator::IsNumber(&iterator.GetData()->CastToMob()->GetName()[len-2])) {
					used[atoi(&iterator.GetData()->CastToMob()->GetName()[len-2])] = true;
				}
			}
		}
		iterator.Advance();
	}
	for (int i=0; i < 100; i++) {
		if (!used[i]) {
			#ifdef WIN32
			snprintf(name, 30, "%s%02d", name, i);
			#else
			//glibc clears destination of snprintf
			//make a copy of name before snprintf--misanthropicfiend
			char temp_name[30];
			strncpy(temp_name, name, 30);
			snprintf(name, 30, "%s%02d", temp_name, i);
			#endif
			return name;
		}
	}
	cout << "Fatal error in EntityList::MakeNameUnique: Unable to find unique name" << endl;
	return 0;
}

char* EntityList::RemoveNumbers(char* name) {
	char	tmp[30];
	memset(tmp, 0, sizeof(tmp));
	int k = 0;
	for (int i=0; i<strlen(name); i++) {
		if (name[i] < '0' || name[i] > '9')
			tmp[k++] = name[i];
	}
	memcpy(name, tmp, 30);
	return name;
}

void EntityList::ListNPCs(Client* client) {
	LinkedListIterator<Entity*> iterator(list);
	int32 x = 0;

	iterator.Reset();
	client->Message(0, "NPCs in the zone:");
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsNPC()) {
			client->Message(0, "  %5d: %s", iterator.GetData()->GetID(), iterator.GetData()->GetName());
			x++;
		}
		iterator.Advance();
	}
	client->Message(0, "%d npcs listed.", x);
}

void EntityList::ListNPCCorpses(Client* client) {
	LinkedListIterator<Entity*> iterator(list);
	int32 x = 0;

	iterator.Reset();
	client->Message(0, "NPC Corpses in the zone:");
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsNPCCorpse()) {
			client->Message(0, "  %5d: %s", iterator.GetData()->GetID(), iterator.GetData()->GetName());
			x++;
		}
		iterator.Advance();
	}
	client->Message(0, "%d npc corpses listed.", x);
}

void EntityList::ListPlayerCorpses(Client* client) {
	LinkedListIterator<Entity*> iterator(list);
	int32 x = 0;

	iterator.Reset();
	client->Message(0, "Player Corpses in the zone:");
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsPlayerCorpse()) {
			client->Message(0, "  %5d: %s", iterator.GetData()->GetID(), iterator.GetData()->GetName());
			x++;
		}
		iterator.Advance();
	}
	client->Message(0, "%d player corpses listed.", x);
}

// returns the number of corpses deleted. A negative number indicates an error code.
sint32 EntityList::DeleteNPCCorpses() {
	LinkedListIterator<Entity*> iterator(list);
	sint32 x = 0;

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsNPCCorpse()) {
			iterator.GetData()->Depop();
			x++;
		}
		iterator.Advance();
	}
	return x;
}

// returns the number of corpses deleted. A negative number indicates an error code.
sint32 EntityList::DeletePlayerCorpses() {
	LinkedListIterator<Entity*> iterator(list);
	sint32 x = 0;

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsPlayerCorpse()) {
			iterator.GetData()->CastToCorpse()->Delete();
			x++;
		}
		iterator.Advance();
	}
	return x;
}

void EntityList::SendPetitionToAdmins(Petition* pet) {
	LinkedListIterator<Entity*> iterator(list);

	APPLAYER* outapp = new APPLAYER(0x0f20,sizeof(PetitionClientUpdate_Struct));
	PetitionClientUpdate_Struct* pcus = (PetitionClientUpdate_Struct*) outapp->pBuffer;
	pcus->petnumber = pet->GetID();		// Petition Number
	if (pet->CheckedOut()) {
		pcus->color = 0x00;
		pcus->unknown2 = 0xFFFFFFFF;
		pcus->unknown[3] = 0x00;
		strcpy(pcus->accountid, "");
		strcpy(pcus->gmsenttoo, "");
	}
	else {
		pcus->color = pet->GetUrgency();	// 0x00 = green, 0x01 = yellow, 0x02 = red
		pcus->unknown2 = 0x00;
		pcus->unknown[3] = 0x1F;			// 4 has to be 0x1F
		strcpy(pcus->accountid, pet->GetAccountName());
		strcpy(pcus->charname, pet->GetCharName());
	}
	pcus->unknown[2] = 0x00;
	pcus->unknown[1] = 0x00;
	pcus->unknown[0] = 0x00;
	pcus->something = 0x00;

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->Admin() >= 100) {
			if (pet->CheckedOut())
				strcpy(pcus->gmsenttoo, "");
			else
				strcpy(pcus->gmsenttoo, iterator.GetData()->CastToClient()->GetName());
			iterator.GetData()->CastToClient()->QueuePacket(outapp);
		}
		iterator.Advance();
	}
	delete outapp;
}

void EntityList::ClearClientPetitionQueue() {
	APPLAYER* outapp = new APPLAYER(0x0f20,sizeof(PetitionClientUpdate_Struct));
	PetitionClientUpdate_Struct* pet = (PetitionClientUpdate_Struct*) outapp->pBuffer;
	pet->color = 0x00;
	pet->unknown2 = 0xFFFFFFFF;
	pet->unknown[3] = 0x00;
	pet->unknown[2] = 0x00;
	pet->unknown[1] = 0x00;
	pet->unknown[0] = 0x00;
	strcpy(pet->accountid, "");
	strcpy(pet->gmsenttoo, "");
	pet->something = 0x00;
	strcpy(pet->charname, "");
	LinkedListIterator<Entity*> iterator(list);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->Admin() >= 100) {
			int x = 0;
			for (x=0;x<16;x++) {
				pet->petnumber = x;
				iterator.GetData()->CastToClient()->QueuePacket(outapp);
			}
		}
		iterator.Advance();
	}
	delete outapp;
	return;
}