#include "../common/debug.h"
#include <stdlib.h>

#include "client.h"
#include "npc.h"
#include "../common/eq_packet_structs.h"
#include <stdio.h>
#include "skills.h"
#include "PlayerCorpse.h"
#include "spdat.h"
#include "zone.h"

#ifdef WIN32
	#define snprintf	_snprintf
#endif

extern Database database;
extern EntityList entity_list;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern Zone* zone;

void Client::Attack(Mob* other, int Hand)
{
	int skillinuse;
	int8 attack_skill;

	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;
	Item_Struct* weapon = 0;
	a->spawn_id = GetID();
	int i = 0;
	if (Hand==13)	// Kaiyodo - Pick weapon from the attacking hand
		weapon = weapon1;
	else
		weapon = weapon2;

		if (weapon!=0) 
		{
			if (weapon->flag != 0x7669) 
			{
				//cout << "skill = " << (int)weapon->common.skill << endl;
				// 1h slashing
				if (weapon->common.skill == 0x00) 
				{
					attack_skill = 0x01;
					skillinuse = 0x00;
					a->type = 5;
				}
				// 2h slashing
				if (weapon->common.skill == 0x01) 
				{
					attack_skill = 0x01;
					skillinuse = 0x01;
					a->type = 3;
				}
				// Piercing
				if (weapon->common.skill == 0x02) 
				{
					attack_skill = 0x24;
					skillinuse = 0x02;
					a->type = 2;
				}
				// 1h blunt
				if (weapon->common.skill == 0x03) 
				{
					attack_skill = 0x00;
					skillinuse = 0x03;
					a->type = 5;
				}
				// 2h blunt
				if (weapon->common.skill == 0x04) 
				{
					attack_skill = 0x00;
					skillinuse = 0x04;
					a->type = 4;
				}
				// 2h Piercing
				if (weapon->common.skill == 0x23) 
				{
					attack_skill = 0x24;
					skillinuse = 0x23;
					a->type = 4;
				}
			}
			else 
			{
	/*
				// player has a non-weapon in primary
				skillinuse = 80;
				a->type = 32; // using 32 since it doesn't seem to do anything
	*/
				// Lets still let them attack, but only hit for 1 =P
				attack_skill = 0x04;
				skillinuse = 80;
				a->type = 8;
			}
		}
		else 
		{
			// player does not have anything in primary
			// use hand to hand
			attack_skill = 0x04;
			skillinuse = 28;
			a->type = 8;
		}
			// Kaiyodo - If we're attacking with the seconary hand, play the duel wield anim
		if(Hand == 14)		// DW anim
			a->type = 6;
		// end animation determination
		a->a_unknown2[5] = 0x80;
		a->a_unknown2[6] = 0x3f;	

		entity_list.QueueCloseClients(this, &app);

		int damage = 0;
		int8 otherlevel = other->GetLevel();
		if (otherlevel == 0)
			otherlevel = 1;
		int8 mylevel = this->GetLevel();
		if (mylevel == 0)
			mylevel = 1;

		// Determine players ability to hit based on:
		// mob level difference, skillinuse, randomness
		if (skillinuse == 80) {
			damage = 1;	
		}
		else
		{
			if ((int)pp.skills[skillinuse] != 0) {
				int32 atkbonus = 0; //TODO: Find where the luclin atk bonus is held
				int32 attacker = ((mylevel/2) * ((this->GetDEX()/6)+this->GetSTR()+atkbonus+this->pp.skills[skillinuse]));
				int32 defender;
				//defender = (otherlevel/2) * (other->GetAC()+(pp.skills[DEFENSE]/2)+other->GetINT()+other->GetAGI());
				defender = (otherlevel/2) * ((otherlevel * 3000/otherlevel+90) +(pp.skills[DEFENSE]/2)+other->GetINT()+other->GetAGI());
				//float hitsuccess = (attacker / defender); // Change to hit *image*	

				float skillfactor = 1.0;
				int32 chanceskill = (255*skillfactor) - ((pp.skills[skillinuse]/10) * (1+(mylevel-otherlevel))); 
				int chanceskill2 = chanceskill;
				int chancetest = (int32)chanceskill2+rand()%(750-chanceskill2)-50;
				if(chancetest <= chanceskill2) {
					if(pp.skills[skillinuse] < 252)	{
						SetSkill(skillinuse, pp.skills[skillinuse] + 1);
					}
				}
				int rndqa = 0;
				int defender2 = 0;
				//Something got bugged, taking out chance code for now...
				// Kaiyodo - new weapon damage calc code
				//
				//	MaximumDamageMain = WeaponDamage * ((Strength + WeaponSkill) / 100) + DamageBonus
				//	MaximumDamageOff = WeaponDamage * ((Strength + WeaponSkill) / 100)

				int weapon_damage = 0;

				if(skillinuse == 28) // weapon is hand-to-hand
				{
					if(GetClass() == MONK || GetClass() == BEASTLORD)
						weapon_damage = GetMonkHandToHandDamage();	// Damage changes based on level
					else
						weapon_damage = 2;
				}
				else
				{
					weapon_damage = (int)weapon->common.damage;
					if(weapon_damage < 1)
						weapon_damage = 1;
				}

				int min_hit = 1;
				int max_hit = weapon_damage * ((GetSTR() + pp.skills[skillinuse]) / 100);	// Apply damage formula

				// Only apply the damage bonus to the main hand
				if(Hand == 13)		// Kaiyodo - If we're not using the DWDA stuff, will always be the primary hand
				{
					int damage_bonus = GetWeaponDamageBonus(weapon);	// Can be NULL, will then assume fists
					min_hit += damage_bonus;
					max_hit += damage_bonus;
				}

				if(max_hit == min_hit)
					damage = min_hit;
				else
					damage = (int32)min_hit + (rand()%(max_hit-min_hit)+1);
			
			}
		}
		other->Damage(this, damage, 0xffff, attack_skill);
		  	// Kaiyodo - Check for proc on weapon based on DEX
	if(weapon && (weapon->common.spellId < 65535ul) && (weapon->common.effecttype == 0) &&
		other && other->GetHP() > 0)
	{
		float ProcChance = (float)rand()/RAND_MAX;
		if(ProcChance < (GetDEX()/3020.0f))		// 255 dex = 0.084 chance of proc. No idea what this number should be really.
		{
			if(weapon->common.level > GetLevel())
			{
				Message(13, "You lack sufficient will to command this weapon");	// Is this the right text?
			}
			else
			{
		 		// Check who to cast the effect on. At the moment, I only know avatar is on us.
		 		if(weapon->common.spellId == 1598)	// Avatar
		 			SpellFinished(weapon->common.spellId, GetID(), 10, 0);
		 		else
		 			SpellFinished(weapon->common.spellId, other->GetID(), 10, 0);
			}
		}
	}
}

void Client::Heal()
{
	SetMaxHP();
    APPLAYER app;
    app.opcode = OP_Action;
    app.size = sizeof(Action_Struct);
    app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
    Action_Struct* a = (Action_Struct*)app.pBuffer;

    a->target = GetID();
    a->source = GetID();
    a->type = 231; // 1
    a->spell = 0x000d; //spell_id
    a->damage = -10000;

    entity_list.QueueCloseClients(this, &app);
    APPLAYER hp_app;
    CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, true);
    SendHPUpdate();

    cout << name << " healed via #heal" << endl; // Pyro: Why say damage?
}

void Client::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill) {
	if (invulnerable)
		damage=-5;

	if (attack_skill != 0xFF) {
		this->DamageShield(other);
	}
	else if (attack_skill == 0xFF) {
		if (spell_id != 0xFFFF && spell_id != 0) {
			if (spells[spell_id].targettype == ST_Tap) {
				other->SetHP(GetHP() + damage);
			}
		}
	}

	if ((GetHP() - damage) <= -11) {
		Death(other, damage, spell_id, attack_skill);
		return;
	}

	if (damage>0)
		SetHP(GetHP()-damage);

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = GetID();
	if (other == 0)
		a->source = 0;
	else if (other->IsClient() && other->CastToClient()->GMHideMe())
		a->source = 0;
	else
		a->source = other->GetID();
	a->type = attack_skill;
	a->spell = spell_id;
	a->damage = damage;

	entity_list.QueueCloseClients(this, &app);

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app);

    if (damage != 0) { // Pyro: Why log this message if no damage is inflicted
		cout << name << " hit for " << damage << ", " << GetHP() << " left." << endl; // More intuitive console output
    }
	Mob* mypet = this->GetPet();
	if (mypet && mypet->IsNPC())
	{
		if (!mypet->CastToNPC()->IsEngaged())
			zone->AddAggroMob(); //merkur
		mypet->CastToNPC()->AddToHateList(other, 0, damage);

	}
}

void Client::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	SetHP(-100);
	entity_list.RemoveFromTargets(this);
	// zonesummon = -3 = death
	zonesummon_x = -3;
	zonesummon_y = -3;
	zonesummon_z = -3;

	SetPet(0);

	pp.x = x_pos;
	pp.y = y_pos;
	pp.z = z_pos;
	pp.heading = heading;
	cout << "Player " << name << " has died." << endl;
	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->damage = damage;
	d->spell_id = spell;
	d->type = attack_skill;
	entity_list.QueueClients(this, &app);
	MakeCorpse();
}

void Client::MakeCorpse() {
	if (this->GetID() == 0)
		return;
	if (admin < 100) {
		entity_list.AddCorpse(new Corpse(this, &pp), this->GetID());
		this->SetID(0);
	}
}

void NPC::Attack(Mob* other, int Hand)	 // Kaiyodo - base function has changed prototype, need to update overloaded version
{
	if (DistNoRootNoZ(other) > 100 || this->casting_spell_id != 0) {
		return;
	}

	int skillinuse;
	int8 attack_skill;
	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;

	a->spawn_id = GetID();
	// lets determine the animation type based on whats in the primary slot.
	// TODO: since the NPC's primary slot is just a graphic, we will need to
	//		 set the weapons properties and ensure correct graphic is displayed.

	// I only implemented weapons 0-8 for now (4=bow, 6=flute)
	if ((int)GetEquipment(7) != 0) 
	{
		// 1h Slashing weapons
		if ((int)GetEquipment(7) == 1 || (int)GetEquipment(7) == 3)
		{
			attack_skill = 0x01;
			skillinuse = 0;
			a->type = 5;
		}
		// 2h Slashing weapons
		else if ((int)GetEquipment(7) == 2)
		{
			attack_skill = 0x01;
			skillinuse = 1;
			a->type = 3;
		}
		// Piercing
		else if ((int)GetEquipment(7) == 5)
		{
			attack_skill = 0x24;
			skillinuse = 2;
			a->type = 2;
		}
		// 1h Blunt
		else if ((int)GetEquipment(7) == 7)
		{
			attack_skill = 0x00;
			skillinuse = 3;
			a->type = 5;
		}
		// 2h Blunt
		else if ((int)GetEquipment(7) == 8)
		{
			attack_skill = 0x00;
			skillinuse = 4;
			a->type = 4;
		}
		else {
			attack_skill = 0x04;
			skillinuse = 80;
			a->type = 8;
		}
	}
	else 
	{
		// NPC does not have anything in primary
		// use hand to hand
		attack_skill = 0x04;
		skillinuse = 28;
		a->type = 8;
	}
	// end animation determination
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;

	entity_list.QueueCloseClients(this, &app);

	int damage = 0;
	float skillmodifier = 0.0;
	float hitmodifier = 0.0;
	int8 otherlevel = other->GetLevel();
	if (otherlevel == 0)
		otherlevel = 1;
	int8 mylevel = this->GetLevel();
	if (mylevel == 0)
		mylevel = 1;

	// Determine NPC's ability to hit based on:
	// mob level difference, skillinuse, randomness
	if (skillinuse != 80)
	{
		// TODO: Set npc's skill levels!!
		SetSkill(skillinuse, 252); // all mobs have 252 skill -socket
		if ((int)GetSkill(skillinuse) != 0) 
		{
			int32 hitsuccess = (float)otherlevel - (float)mylevel;
			// cout << "1 - " << hitsuccess << endl;
			if(mylevel > otherlevel || mylevel == otherlevel)
			{
				hitsuccess -= mylevel;
				hitsuccess -= 4;
				hitsuccess *= 8;
			}
			if(mylevel >= otherlevel)
			{
				hitsuccess += 4;
				hitsuccess *= 14;
			}
			if(otherlevel > mylevel)
			{
				hitsuccess += mylevel;
				hitsuccess *= mylevel/otherlevel;
			}
			if ((int)hitsuccess >= 91)
			{
				hitsuccess *= 4.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 40 && hitsuccess <= 90)
			{
				hitsuccess *= 3.0;
				hitmodifier = 0.1;
			}
			if ((int)hitsuccess >= 10)
			{
				hitsuccess /= 10.0;
				hitmodifier = 1.3;
			}
			else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
			{
				hitsuccess = 0.5;
				hitmodifier = 0.8;
			}
			else if ((int)hitsuccess <= -1)
			{
				hitsuccess = 0;
				hitmodifier = 0.4;
			}
			// cout << "2 - " << hitsuccess << endl;
			if ((int)GetSkill(skillinuse) >= 100)
			{
				skillmodifier = 0.1;
			}
			else if ((int)GetSkill(skillinuse) >= 200)
			{
				skillmodifier = 0.2;
			}
			hitsuccess -= ((float)GetSkill(skillinuse)/100000) + skillmodifier;
			// cout << "3 - " << hitsuccess << endl;
			hitsuccess += (float)rand()/RAND_MAX;
			// cout << "4 - " << hitsuccess << endl;
			if (hitsuccess <= hitmodifier)
			{
				// Now lets determine how much the NPC will hit for based on:
				// player's lvl, mob lvl, skill, weapon damage, str
				int weapon_damage = 0;
				if (skillinuse == 28) // weapon is hand-to-hand
				{
					weapon_damage = abs((int)GetSkill(skillinuse)/100);
					if (weapon_damage < 1) 
					{
						weapon_damage = 1;
					}
				}
				else 
				{
					// TODO: Set NPC's weapon damage
					weapon_damage = (4*(int)mylevel)/3;
					if (weapon_damage < 1) 
					{
						weapon_damage = 1;
					}
				}
				int hit_modifier = (int)((int)mylevel - (int)otherlevel)/10;
				int max_hit = 0;
				int min_hit = 0;
				min_hit = (int)abs((((int)mylevel - 20)/3) + hit_modifier * mylevel/5);
				// TODO: Add STR to mobs (right now all mobs have 255 STR) -socket
				max_hit = (int)abs((((255 + (int)GetSkill(skillinuse) + (int)mylevel)/100) + hit_modifier)*(weapon_damage*mylevel/2));
/*
cout << GetName() << "'s Attack Stats:" << endl;
cout << " skill level in use = " << (int)GetSkill(skillinuse) << endl;
cout << " STR = " << "255" << endl;
cout << " weapon_damage = " << weapon_damage << endl;
cout << " hit_modifier = " << hit_modifier << endl;
cout << " min_hit = " << min_hit << endl;
cout << " max_hit = " << max_hit << endl;
*/
				if (max_hit == min_hit)
					damage = min_hit;
				else
					damage = (int32)min_hit+rand()%(max_hit-min_hit)+1;
			}
		}
	}

	if (this->ownerid != 0) {
		if ((float)rand()/RAND_MAX < 0.2) {
		printf("Trying to cast\n");
			printf("Trying to cast0\n");
			if (this->typeofpet == 1) {
				printf("Trying to cast1\n");
				this->SpellFinished(893, this->target->GetID(), 10, 0);
			}
			if (this->typeofpet == 2) {
				printf("Trying to cast2\n");
				this->SpellFinished(1021, this->target->GetID(), 10, 0);
			}
			if (this->typeofpet == 3) {
				printf("Trying to cast3\n");
				this->SpellFinished(1021, this->target->GetID(), 10, 0);
			}
			if (this->typeofpet == 4) {
				printf("Trying to cast4\n");
				this->SpellFinished(1021, this->target->GetID(), 10, 0);
			}
		}
	}
/*	else if (rand()%100 < 10) {
		int16 SpellId = FindSpell(this->class_, this->level, SE_CurrentHP, 1);
		if (SpellId != 0) {
			this->CastSpell(SpellId,target->GetID());
		}
	}*/

	other->Damage(this, damage, 0xffff, attack_skill);
}

void NPC::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill)
{
	if (this->GetHPRatio() <= 25) {
		int16 SpellId = FindSpell(this->class_, this->level, SE_CurrentHP, 2);
		if (SpellId != 0) {
		this->CastSpell(SpellId,this->GetID());
		}
	}

	if (attack_skill != 0xFF) {
		this->DamageShield(other);
	}
	else if (attack_skill == 0xFF) {
		if (spell_id != 0xFFFF && spell_id != 0) {
			if (spells[spell_id].targettype == ST_Tap) {
				other->SetHP(GetHP() + damage);
			}
		}
	}

	if (attack_skill == 0xFF) {
		other->Message(4,"%s was hit by non-melee for %d.", this->GetName(), damage);
	}

	if (damage >= GetHP()) {
		SetHP(0);
		Death(other, damage, spell_id, attack_skill);
		return;
	}

	SetHP(GetHP() - damage);

	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;

	a->target = GetID();
	if (other == 0)
		a->source = 0;
	else if (other->IsClient() && other->CastToClient()->GMHideMe())
		a->source = 0;
	else
		a->source = other->GetID();
	a->type = attack_skill; // was 0x1c
	a->spell = spell_id;
	a->damage = damage;

	a->unknown4[0] = 0xcd;
	a->unknown4[1] = 0xcc;

	a->unknown4[2] = 0xcc;
	a->unknown4[3] = 0x3d;

	a->unknown4[4] = 0x71;
	a->unknown4[5] = 0x6b;

	a->unknown4[6] = 0x3d;
	a->unknown4[7] = 0x41;

	entity_list.QueueCloseClients(this, &app);

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app);
	if (!IsEngaged()) zone->AddAggroMob();
	this->AddToHateList(other, damage);
}

void NPC::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (other != 0 && other->IsClient())
		other->CastToClient()->CheckQuests(zone->GetShortName(), "%%DEATH%%", this->GetNPCTypeID());
	if (this->IsEngaged()) {
		zone->DelAggroMob();
		cout << "Mobs currently Aggro: " << zone->MobsAggroCount() << endl;
	}
	SetHP(0);
	SetPet(0);

	entity_list.RemoveFromTargets(this);

	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->spell_id = spell;
	d->type = attack_skill;
	d->damage = damage;
	DumpPacket(&app);
	entity_list.QueueCloseClients(this, &app, false, 600, other);
	if (other != 0) {
		if (other->IsClient())
			other->CastToClient()->QueuePacket(&app);

		hate_list.Add(other, damage);
	}

	if (hate_list.GetTop() != 0 && hate_list.GetTop()->IsClient() && other && other->IsClient())
	{
		hate_list.GetTop()->CastToClient()->AddEXP(level*level*75); // Pyro: Comment this if NPC death crashes zone
		hate_list.DoFactionHits(npctype_id);
	}

	if (respawn2 != 0) {
		respawn2->Reset();
	}

	if (class_ != 32 && this->ownerid == 0) {
		entity_list.AddCorpse(new Corpse(this, &itemlist, GetNPCTypeID(), &NPCTypedata), this->GetID());
		this->SetID(0);
	}
	p_depop = true;
}

void Mob::ChangeHP(Mob* other, sint32 amount, int16 spell_id)
{
	if (IsCorpse())
		return;
	
	if (spell_id == 982) {
		SetHP(-100);
		this->Death(other, abs(amount), spell_id, 0xFF);
		return;
	}
	else if (spell_id == 13) {
		SetHP(GetMaxHP());
	}
	else if (!invulnerable) {
		if (amount < 0) {
			this->Damage(other, abs(amount), spell_id, 0xFF);
			return;
		}
		else
			SetHP(GetHP() + amount);
	}

	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	entity_list.QueueCloseClients(this, &hp_app, false, 600, other);
	if (other != 0 && other->IsClient())
		other->CastToClient()->QueuePacket(&hp_app);
}

void Mob::MonkSpecialAttack(Mob* other, int8 type) {
	sint32 ndamage = 0;
	PlayerProfile_Struct pp;
	float hitsuccess = (float)other->GetLevel() - (float)level;
	float hitmodifier = 0.0;
	float skillmodifier = 0.0;
	if(level > other->GetLevel())
	{
		hitsuccess += 2;
		hitsuccess *= 14;
	}
	if ((int)hitsuccess >= 40)
	{
		hitsuccess *= 3.0;
		hitmodifier = 1.1;
	}
	if ((int)hitsuccess >= 10 && hitsuccess <= 39)
	{
		hitsuccess /= 4.0;
		hitmodifier = 0.25;
	}
	else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
	{
		hitsuccess = 0.5;
		hitmodifier = 1.5;
	}
	else if ((int)hitsuccess <= -1)
	{
		hitsuccess = 0.1;
		hitmodifier = 1.8;
	}
	// cout << "2 - " << hitsuccess << endl;
	if ((int)pp.skills[type] >= 100)
	{
		skillmodifier = 1;
	}
	else if ((int)pp.skills[type] >= 200)
	{
		skillmodifier = 2;
	}

	hitsuccess -= ((float)pp.skills[type]/10000) + skillmodifier;
	// cout << "3 - " << hitsuccess << endl;
	hitsuccess += (float)rand()/RAND_MAX;
	// cout << "4 - " << hitsuccess << endl;
	float ackwardtest = 2.4;
	float random = (float)rand()/RAND_MAX;
	if(random <= 0.2)
	{
		ackwardtest = 4.5;
	}
	if(random > 85 && random < 400.0)
	{
		ackwardtest = 3.2;
	}
	if(random > 400 && random < 800.0)
	{
		ackwardtest = 3.7;
	}
	if(random > 900 && random < 1400.0)
	{
		ackwardtest = 1.9;
	}
	if(random > 1400 && random < 14000.0)
	{
		ackwardtest = 2.3;
	}
	if(random > 14000 && random < 24000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 24000 && random < 34000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 990000)
	{
		ackwardtest = 1.2;
	}
	if(random < 0.2)
	{
		ackwardtest = 0.8;
	}

	ackwardtest += (float)rand()/RAND_MAX;
	ackwardtest = abs(ackwardtest);
	if (type == 0x1A) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (FLYING_KICK + GetSTR() + level) / 700);
		if ((float)rand()/RAND_MAX < 0.2) {
			ndamage = (sint32) ndamage * 4.2;
			if(ndamage <= 0) {
				entity_list.MessageClose(this, false, 200, 10, "%s misses at an attempt to thunderous kick %s!",name,other->name);
			}
			else {
			entity_list.MessageClose(this, false, 200, 10, "%s lands a thunderous kick!(%d)", name, ndamage);
			}
		}
		other->Damage(this, ndamage, 0xffff, 0x1A);
		DoAnim(45);
	}
	else if (type == 0x34) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (2 * ackwardtest) * (TIGER_CLAW + GetSTR() + level) / 900);
		other->Damage(this, ndamage, 0xffff, 0x34);
		DoAnim(46);
	}
	else if (type == 0x26) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (ROUND_KICK + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x26);
		DoAnim(11);
	}
	else if (type == 0x17) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (EAGLE_STRIKE + GetSTR() + level) / 1000);
		other->Damage(this, ndamage, 0xffff, 0x17);
		DoAnim(47);
	}
	else if (type == 0x15) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (5 * ackwardtest) * (DRAGON_PUNCH + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x15);
		DoAnim(7);
	}
	else if (type == 0x1E) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (KICK + GetSTR() + level) / 1200);
		other->Damage(this, ndamage, 0xffff, 0x1e);
		DoAnim(1);
	}
}

void NPC::AddToHateList(Mob* other, sint32 damage, sint32 hate) {
	if (other) {
		if (hate == 0xFFFFFFFF) {
			Mob* owner = other->GetOwner();
			if (owner) {
				hate_list.Add(other, 0, damage);
				hate_list.Add(owner, damage, damage / 2);
			}
			else {
				hate_list.Add(other, damage);
			}
			Mob* mypet = this->GetPet();
			if (mypet && mypet->IsNPC())
				mypet->CastToNPC()->AddToHateList(other, 0, damage);
		}
		else {
			hate_list.Add(other, damage, hate);
		}
	}
}

void Mob::DamageShield(Mob* other) {
	for (int i=0; i < 15; i++) {
		if (buffs[i].spellid != 0xFFFF) {
			for (int z=0; z < 12; z++) {
				switch(spells[buffs[i].spellid].effectid[z]) {
					case SE_DamageShield: {
						other->Damage(this, spells[buffs[i].spellid].base[1], buffs[i].spellid, 0xFF);
//						this->ChangeHP(other, spells[buffs[i].spellid].max[i], buffs[i].spellid);
//						entity_list.MessageClose(other, false, 200, 4, "%s %", other->GetName(), spells[buffs[i].spellid].pushback);
						break;
					}
				}
			}
		}
	}
}

int Client::GetWeaponDamageBonus(Item_Struct *Weapon)
{
	// Kaiyodo - Calculate the damage bonus for a weapon on the main hand
	if(GetLevel() < 28)
		return(0);

	// Check we're on of the classes that gets a damage bonus
	switch(GetClass())
	{
		case WARRIOR:
		case MONK:
		case ROGUE:
		case PALADIN:
		case SHADOWKNIGHT:
		case BEASTLORD:
		case BARD:
			break;
		default:
			return(0);
	}

	int BasicBonus = ((GetLevel() - 25) / 3) + 1;

	// If we have no weapon, or only a single handed weapon, just return the default
	// damage bonus of (Level - 25) / 3
	if(!Weapon || Weapon->common.skill == 0 || Weapon->common.skill == 2 ||
		Weapon->common.skill == 3)
		return(BasicBonus);

	// Things get more complicated with 2 handers, the bonus is based on the delay of
	// the weapon as well as a number stored inside the weapon.
	int WeaponBonus = 0;	// How do you find this out?

	// Data for this, again, from www.monkly-business.com
	if(Weapon->common.delay <= 27)
		return(WeaponBonus + BasicBonus + 1);
	if(Weapon->common.delay <= 39)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4));
	if(Weapon->common.delay <= 42)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + 1);
	// Weapon must be > 42 delay
	return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + ((Weapon->common.delay-34) / 3));
}

int Client::GetMonkHandToHandDamage(void)
{
	// Kaiyodo - Determine a monk's fist damage. Table data from www.monkly-business.com

//	for(int i=0 ; i < 30 ; i++)
//		Message(0, "pp.inventory %d = %d", i, pp.inventory[i]);

	// Have a look to see if we have epic fists on
	if(pp.inventory[12] == 10652)
		return(9);
	else
	{
		// Work out the damage from the player's level
		int Level = GetLevel();

		if(Level <= 4)
			return(4);
		if(Level <= 9)
			return(5);
		if(Level <= 14)
			return(6);
		if(Level <= 19)
			return(7);
		if(Level <= 24)
			return(8);
		if(Level <= 29)
			return(9);
		if(Level <= 34)
			return(10);
		if(Level <= 39)
			return(11);
		if(Level <= 44)
			return(12);
		if(Level <= 49)
			return(13);
		// Assume 50+, all are 14 dmg, just the delay changes
		return(14);
	}
}

int Client::GetMonkHandToHandDelay(void)
{
	// Kaiyodo - Determine a monk's fist delay. Table data from www.monkly-business.com

	// Have a look to see if we have epic fists on
	if(pp.inventory[12] == 10652)
		return(16);
	else
	{
		// Work out the delay from the player's level.
		// This should change if you're an Iksar, but I've not done that yet :)
		int Level = GetLevel();

		if(Level <= 24)
			return(36);
		if(Level <= 29)
			return(35);
		if(Level <= 34)
			return(34);
		if(Level <= 39)
			return(33);
		if(Level <= 44)
			return(32);
		if(Level <= 49)
			return(31);
		if(Level <= 52)
			return(30);
		if(Level <= 55)
			return(29);
		if(Level <= 58)
			return(28);
		if(Level <= 59)
			return(27);
		return(26);
	}
}