#ifndef SERVERINFO_H
#define SERVERINFO_H

#ifdef WIN32
  char Ver_name[36];
  DWORD Ver_build, Ver_min, Ver_maj, Ver_pid;
  int GetOS();
#else
  char* GetOS(char* os_string);
#endif

#endif
