#include "bitbool.h"
#include <iostream.h>
#include <string.h>

unsigned int BitBool::GetRealSize(unsigned int size) {
	unsigned int realsize = size / 8;
	if (size % 8 != 0)
		realsize++;
	return realsize;
}

BitBool::BitBool(unsigned int size) {
	deldata = true;
	maxindex = size;
	realsize = GetRealSize(size);
	data = (BitBool_Struct*) new unsigned char[realsize];
	memset(data, 0, realsize);
}

BitBool::BitBool(unsigned int size, unsigned char data) {
	deldata = false;
	maxindex = size;
	realsize = GetRealSize(size);
	this->data = (BitBool_Struct*) data;
}

BitBool::~BitBool() {
	if (deldata)
		delete data;
}

bool BitBool::Get(unsigned int index) {
	if (index >= realsize) {
		static bool crap;
		cout << "ERROR: BitBool: Invalid Get() index, returning crap." << endl;
		return crap;
	}
	return data[index / 8][index % 8].bit;
}

void BitBool::Set(unsigned int index, bool value) {
	if (index >= maxindex) {
		cout << "ERROR: BitBool: Invalid Set() index." << endl;
		return;
	}
	data[index / 8][index % 8].bit = value;
}
