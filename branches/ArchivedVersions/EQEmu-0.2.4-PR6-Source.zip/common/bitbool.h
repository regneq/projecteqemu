/*
  BitBool class
  Manages an array of bool values using one bit each, instead of one byte each.

  -Quagmire
*/

#ifndef BITBOOL_H
#define BITBOOL_H

#pragma pack(1)
typedef struct {
	bool bit : 1;
} BitBool_Struct[8];
#pragma pack()

class BitBool {
public:
	static unsigned int GetRealSize(unsigned int size);

	BitBool(unsigned int size);
	BitBool(unsigned int size, unsigned char data);
	~BitBool();

	bool	Get(unsigned int index);
	void	Set(unsigned int index, bool value);
private:
	bool deldata;
	unsigned int maxindex;
	unsigned int realsize;
	BitBool_Struct*	data;
};

#endif