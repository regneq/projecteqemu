#ifdef _DEBUG
	#ifndef _CRTDBG_MAP_ALLOC
		#define _CRTDBG_MAP_ALLOC
		#include <stdlib.h>
		#include <crtdbg.h>
		#define new \
        new(_NORMAL_BLOCK, __FILE__, __LINE__) 
	#endif
#endif

#define CURRENT_CHAT_VERSION	"EqEmu 0.2.4 Chat Server - Pre-Release 6"
#define CURRENT_ZONE_VERSION	"EqEmu 0.2.4 Zoneserver - Pre-release 6"
#define CURRENT_WORLD_VERSION   "EqEmu 0.2.4 Worldserver - Pre-release 6"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
#define LAST_MODIFIED	__TIME__
#else
#define LAST_MODIFIED	__TIMESTAMP__
#endif
