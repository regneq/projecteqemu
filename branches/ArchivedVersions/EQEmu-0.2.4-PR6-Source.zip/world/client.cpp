#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "LoginServer.h"
#include "zoneserver.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];
extern ZSList zoneserver_list;
extern LoginServer* loginserver;

Client::Client(int32 in_ip, int16 in_port, int in_send_socket) {
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;

	timeout_timer = new Timer(CLIENT_TIMEOUT);
	autobootup_timeout = new Timer(10000);
	autobootup_timeout->Disable();
	
	account_id = 0;

	packet_manager.SetDebugLevel(0);
	memset(zone_name, 0, sizeof(zone_name));
	char_name[0] = 0;
	pwaitingforbootup = 0;
}

Client::~Client() {
	safe_delete(timeout_timer);
	safe_delete(autobootup_timeout);
}

void Client::SendCharInfo() {
	APPLAYER *outapp;
	outapp = new APPLAYER(OP_SendCharInfo, sizeof(CharacterSelect_Struct));
	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(account_id, cs_struct);

	QueuePacket(outapp);
	delete outapp;
}

bool Client::Process() {
	bool ret = true;
	bool sendguilds = true;
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;

	if (autobootup_timeout->Check()) {
		ZoneUnavail();
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(ret && (app = PMOutQueuePop()))
	{
		switch(app->opcode)
		{
		case 0:
			break;
		case OP_SendLoginInfo:
		{

			// Quagmire - max len for name is 18, pass 15
			char name[19];
			char password[16];
			memset(name, 0, sizeof(name));
			memset(password, 0, sizeof(password));

			strncpy(name, (char*)app->pBuffer, 18);
			if (app->size < strlen(name)+2) {
				ret = false;
				break;
			}
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 15);

//cerr << "u='" << name << "', p='" << password << "'" << endl;
			if (strncasecmp(name, "LS#", 3) == 0) {
				if (loginserver == 0) {
					cout << "Error: Login server login while not connected to login server." << endl;
					ret = false;
					break;
				}
				LSAuth_Struct* lsa = 0;
				if (lsa = loginserver->CheckAuth(atoi(&name[3]), password)) {
//cout << "Client from LS: id=" << lsa->lsaccount_id << ", n=" << lsa->name << ", k=" << lsa->key << endl;
					account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
					if (account_id == 0) {
						database.CreateAccount(lsa->name, "", 0, lsa->lsaccount_id);
						account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
						if (account_id == 0) {
							// TODO: Find out how to tell the client wrong username/password
							cerr << "Error adding local account for LS login: '" << lsa->name << "', duplicate name?" << endl;
							ret = false;
							break;
						}
					}
					sendguilds = lsa->firstconnect;
					lsa->firstconnect = false;
//					loginserver->RemoveAuth(lsa->lsaccount_id);
//cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << ", k=" << password << endl;
					cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << endl;
				}
				else {
					// TODO: Find out how to tell the client wrong username/password
//cerr << "Bad/expired session key: " << name << ", k=" << password << endl;
					cerr << "Bad/expired session key: " << name << endl;
					ret = false;
					break;
				}
			}
			else if (strlen(password) <= 1) {
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Login without a password" << endl;
				ret = false;
				break;
			}
			else {
				account_id = database.CheckLogin(name,password);
				if (account_id == 0)
				{
					// TODO: Find out how to tell the client wrong username/password
					struct in_addr	in;
					in.s_addr = ip;
					cerr << inet_ntoa(in) << ": Wrong name/pass: name='" << name << "'" << endl;
					ret = false;
					break;
				}
cout << "Logged in: Local: " << name << endl;
			}

			APPLAYER *outapp;

			outapp = new APPLAYER;
			outapp->opcode = 0x0710;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			QueuePacket(outapp);
			delete outapp;

			outapp = new APPLAYER;
			outapp->opcode = 0x0180;
			outapp->pBuffer = new uchar[1];
			outapp->pBuffer[0] = 0;
			outapp->size = 1;
			QueuePacket(outapp);
			delete outapp;

			// Quagmire - Enabling expansions. Pretty sure this is bitwise
			outapp = new APPLAYER;
			outapp->opcode = OP_ExpansionInfo;
			outapp->size = 4;
			outapp->pBuffer = new uchar[outapp->size];
			memset(outapp->pBuffer, 0, outapp->size);
			char tmp[4];
			outapp->pBuffer[0] = 7;
			if (database.GetVariable("Expansions", tmp, 3)) {
				outapp->pBuffer[0] = atoi(tmp);
			}
			QueuePacket(outapp);
			delete outapp;

			if (sendguilds) {
cout << "Sending list of guilds" << endl;
				// Quagmire - tring to send list of guilds
				outapp = new APPLAYER;
				outapp->opcode = OP_GuildsList;
				outapp->size = sizeof(GuildsList_Struct);
		   		outapp->pBuffer = new uchar[outapp->size];
				memset(outapp->pBuffer, 0, outapp->size);
				GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

				for (int i=0; i < 512; i++) {
					gl->Guilds[i].guildID = 0xFFFFFFFF;
					gl->Guilds[i].unknown1[0] = 0xFF;
					gl->Guilds[i].unknown1[1] = 0xFF;
					gl->Guilds[i].unknown1[2] = 0xFF;
					gl->Guilds[i].unknown1[3] = 0xFF;
					gl->Guilds[i].exists = 0;
					gl->Guilds[i].unknown3[0] = 0xFF;
					gl->Guilds[i].unknown3[1] = 0xFF;
					gl->Guilds[i].unknown3[2] = 0xFF;
					gl->Guilds[i].unknown3[3] = 0xFF;
					if (guilds[i].databaseID != 0) {
						gl->Guilds[i].guildID = i;
						strcpy(gl->Guilds[i].name, guilds[i].name);
						gl->Guilds[i].exists = 1;
					}
				}
				
				QueuePacket(outapp);
				delete outapp;
			}

			// We are logging in and want to see character select
			SendCharInfo();
		    break;
		}
		case 0x8B20: //Name approval
		{
			if (account_id == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				ret = false;
				break;
			}
		    char name[16];
		    strncpy(name,(char*)app->pBuffer,16);
		    uchar race = app->pBuffer[32];
		    uchar clas = app->pBuffer[36];

		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0x8B20;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.CheckNameFilter(name)) {
				outapp->pBuffer[0] = 0;
			}
			else if (database.ReserveName(account_id, name)) {
				outapp->pBuffer[0] = 1;
			}
			else {
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;
		    break;			
		}
		case OP_CharacterCreate: //Char create
		{
			if (account_id == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				ret = false;
				break;
			}
			// Quag: This packet seems to be the PlayerProfile struct w/o the space for the checksum at the beginning
			if (app->size != sizeof(PlayerProfile_Struct) - 4) {
				cout << "Wrong size on OP_CharacterCreate. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) - 4 << endl;
				break;
			}
			// TODO: Sanity check in data
			PlayerProfile_Struct cc;
			memcpy((char*) &cc.name, app->pBuffer, sizeof(PlayerProfile_Struct) - 4);

			memset(cc.unknown0154, 0, sizeof(cc.unknown0154));
			memset(cc.unknown0224, 0, sizeof(cc.unknown0224));
			memset(cc.unknown0978, 0, sizeof(cc.unknown0978));
			memset(cc.unknown2582, 0, sizeof(cc.unknown2582));
			memset(cc.unknown2944, 0, sizeof(cc.unknown2944));
			memset(cc.unknown3888, 0, sizeof(cc.unknown3888));
			cc.unknown4174 = 0;
			memset(cc.unknown4176, 0, sizeof(cc.unknown4176));
			memset(cc.unknown4532, 0, sizeof(cc.unknown4532));
			memset(cc.unknown5880, 0, sizeof(cc.unknown5880));

			//Lyenu - This is the call to add starting items
			database.SetStartingItems(&cc, (int8) cc.race, (int8) cc.class_, (char*) &cc.name);

/*		    char name[16];
		    strncpy(name, cc->name, 16);

			int16 gender = cc->gender;
			int16 race = cc->race;
			int16 class_ = cc->class_;
			int8 face = cc->face;
			int8 str = cc->STR;
			int8 sta = cc->STA;
			int8 cha = cc->CHA;
			int8 dex = cc->DEX;
			int8 int_ = cc->INT;
			int8 agi = cc->AGI;
			int8 wis = cc->WIS; // TODO: Find out where deity,face and starting location is located
*/
//			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			if (!database.CreateCharacter(account_id, &cc))
			{
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp;
				outapp = new APPLAYER;
				outapp->opcode = 0x8B20;
		   		outapp->pBuffer = new uchar[1];
		   		outapp->size = 1;
				outapp->pBuffer[0] = 0;
				QueuePacket(outapp);
				delete outapp;
				ret = false;
				break;
			}

			cout << "Char create:" << cc.name << endl;
			SendCharInfo();

		    break;
		}
		case 0x0180: // Enter world
		{
			if (account_id == 0)
			{
				cerr << "Enter world with no logged in account" << endl;
				packet_manager.Close();
				QueuePacket(0);
				break;
			}
            strncpy(char_name,(char*)app->pBuffer,16);

			// Make sure this account owns this character
			if (database.GetAccountIDByChar(char_name) != account_id)
			{
				cerr << "This account does not own this character" << endl;
				packet_manager.Close();
				QueuePacket(0);
				break;
			}

			PlayerProfile_Struct pp;
			if (!database.GetPlayerProfile(account_id, char_name, &pp))
			{
				cerr << "Could not get PlayerProfile for " << char_name << endl;
				packet_manager.Close();
				QueuePacket(0);
				break;
			}
			if (!database.GetSafePoints(pp.current_zone)) {
				// This is to save people in an invalid zone, once it's removed from the DB
				strcpy(pp.current_zone, "arena");
				pp.x = 1050;
				pp.y = -50;
				pp.z = 3.2;
				database.SetPlayerProfile(account_id, char_name, &pp);
			}
			strcpy(zone_name, pp.current_zone);


			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0xdd21; // This is message of the day?
			char tmp[500];
			if (database.GetVariable("MOTD", tmp, 500)) {
				outapp->size = strlen(tmp)+1;
				outapp->pBuffer = new uchar[outapp->size];
				strcpy((char*)outapp->pBuffer, tmp);
			} else {
				char DefaultMOTD[] = "Welcome to EQ Emu(tm)!";
				outapp->size = strlen(DefaultMOTD) + 1;
				outapp->pBuffer = new uchar[outapp->size];
				strcpy((char*)outapp->pBuffer, DefaultMOTD);
			}
			QueuePacket(outapp);
			delete outapp;

			EnterWorld();
			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
				ret = false;
				break;
			}
			SendCharInfo();
			break;
		}
		case 0x3521:
		case 0x3921:
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			break;		
		default:
		{
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app->pBuffer, app->size);
			break;
		}
		}

		delete app;
	}    
	/************ Get first send packet on queue and send it! ************/
	MySendPacketStruct* p = 0;    
	while(p = PMSendQueuePop())
	{
		// Disgrace: for windows compile
		#ifndef WIN32
			sendto(send_socket, p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#else
			sendto(send_socket, (const char *) p->buffer, p->size, 0, (sockaddr*)&to, sizeof(to));
		#endif

		safe_delete(p->buffer);
		delete p;
	}
	/************ Processing finished ************/

	LockMutex lock(&MPacketManager);
	// Agz: Had to move this to the end of the function instead
	if (!packet_manager.CheckActive()) {
		cout << "Client disconnected" << endl;
		return false;
	}
    if (timeout_timer->Check()) {
		cout << "Client timeout" << endl;
		return false;
    }
	packet_manager.CheckTimers();

	return ret;
}

void Client::EnterWorld(bool TryBootup) {
	int16 zone_port;
	char zone_address[255];

	if (strlen(zone_name) == 0)
		return;

	ZoneServer* zs = zoneserver_list.FindByName(zone_name);
	if (zs) {
		// warn the world we're comming, so it knows not to shutdown
		zs->TriggerBootup();
	}
	else {
		if (TryBootup) {
			autobootup_timeout->Start();
			cout << "Attempting autobootup of '" << zone_name << "' for " << char_name << endl;
			if (!(pwaitingforbootup = zoneserver_list.TriggerBootup(zone_name))) {
				cout << "Error: No zoneserver to bootup '" << zone_name << "' for " << char_name << endl;
				ZoneUnavail();
			}
			return;
		}
		else {
			cout << "Error: Player '" << char_name << "' requested zone status for '" << zone_name << "' but it's not up." << endl;
			ZoneUnavail();
			return;
		}
	}

	pwaitingforbootup = 0;
	cout << "Enter world: " << char_name << ": " << zone_name << endl;
	database.SetAuthentication(account_id, char_name, zone_name, ip);

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ZoneServerInfo;//0x0480;
	outapp->pBuffer = new uchar[130];
	outapp->size = 130;
//	strcpy((char*) outapp->pBuffer,     zone_address);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	strcpy((char*)&outapp->pBuffer[75], zone_name);
	int16 *temp = (int16*)&outapp->pBuffer[128];
//	*temp = ntohs(zone_port);
	*temp = ntohs(zs->GetCPort());

	QueuePacket(outapp);
	delete outapp;
}

void Client::ZoneUnavail() {
	memset(zone_name, 0, sizeof(zone_name));
	pwaitingforbootup = 0;
	autobootup_timeout->Disable();
	APPLAYER* outapp = new APPLAYER(OP_ZoneUnavail, sizeof(ZoneUnavail_Struct));
	ZoneUnavail_Struct* ua = (ZoneUnavail_Struct*)outapp->pBuffer;
	strcpy(ua->zonename, zone_name);
	QueuePacket(outapp);
	delete outapp;
}

void Client::QueuePacket(APPLAYER* app, bool ack_req)
{
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size >= 31500) {
			cout << "WARNING: abnormal packet size. o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	LockMutex lock(&MPacketManager);
	packet_manager.MakeEQPacket(app, ack_req);
}

MySendPacketStruct* Client::PMSendQueuePop() {
	LockMutex lock(&MPacketManager);
	return packet_manager.SendQueue.pop();
}

APPLAYER* Client::PMOutQueuePop() {
	LockMutex lock(&MPacketManager);
	return packet_manager.OutQueue.pop();
}

void Client::ReceiveData(uchar* buf, int len) {
	LockMutex lock(&MPacketManager);
	timeout_timer->Start();
	packet_manager.ParceEQPacket(len, buf);
}

ClientList::ClientList() {
}

ClientList::~ClientList() {
}

void ClientList::Add(Client* client) {
	list.Insert(client);
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			Client* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

void ClientList::Process() {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << ntohs((int16)(iterator.GetData()->GetPort())) << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

void ClientList::ZoneBootup(ZoneServer* zs) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->WaitingForBootup()) {
			if (strcasecmp(iterator.GetData()->GetZoneName(), zs->GetZoneName()) == 0) {
				iterator.GetData()->EnterWorld(false);
			}
			else if (iterator.GetData()->WaitingForBootup() == zs->GetID()) {
				iterator.GetData()->ZoneUnavail();
			}
		}
		iterator.Advance();
	}
}

bool Database::SetStartingItems(PlayerProfile_Struct *cc, int8 si_race, int8 si_class, char* si_name)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	int i = 22;
	MYSQL_RES *result;
	MYSQL_ROW row;

	cout<< "Loading starting items for: Race: " << (int) si_race << " Class: " << (int) si_class << " onto " << si_name << endl;
	if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i ORDER BY id", (int) si_race, (int) si_class), errbuf, &result))
	{
		while(row = mysql_fetch_row(result))
		{
			cc->inventory[i] = atoi(row[0]);	
			cout<< atoi(row[0]);
			i++;
		}
	}
	mysql_free_result(result);
	delete[] query;
	return true;
}