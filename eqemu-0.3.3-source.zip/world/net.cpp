#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include "../common/queue.h"
#include "../common/timer.h"
#include "../common/EQNetwork.h"
#include "net.h"
#include "client.h"
#include "../common/database.h"
#include "../common/seperator.h"
#include "../common/version.h"
#ifdef WIN32
	#include <process.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include "../common/unix.h"
#endif
#include "zoneserver.h"
#include "console.h"
#include "LoginServer.h"

EQNetworkServer eqns(9000);
NetConnection net;
ClientList client_list;
ZSList zoneserver_list;
LoginServer loginserver;
volatile bool RunLoops = true;
uint32 numclients = 0;
uint32 numzones = 0;
bool holdzones = false;
GuildRanks_Struct guilds[512];
extern volatile bool ZoneLoopRunning;
extern volatile bool ConsoleLoopRunning;

Database database;

int main(int argc, char** argv)
{
#ifdef _DEBUG
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	if (signal(SIGINT, CatchSignal) == SIG_ERR)	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	#ifndef WIN32
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)	{
		cerr << "Could not set signal handler" << endl;
		return 0;
	}
	#endif
	if (argc >= 2) {
		char tmp[2];
		if (strcasecmp(argv[1], "help") == 0 || strcasecmp(argv[1], "?") == 0 || strcasecmp(argv[1], "/?") == 0 || strcasecmp(argv[1], "-?") == 0 || strcasecmp(argv[1], "-h") == 0 || strcasecmp(argv[1], "-help") == 0) {
			cout << "Worldserver command line commands:" << endl;
			cout << "adduser username password flag    - adds a user account" << endl;
			cout << "flag username flag    - sets GM flag on the account" << endl;
			cout << "startzone zoneshortname    - sets the starting zone" << endl;
			cout << "-holdzones    - reboots lost zones" << endl;
			return 0;
		}
		if (strcasecmp(argv[1], "-holdzones") == 0) {
			cout << "Reboot Zones mode ON" << endl;
			holdzones = true;
		}
		if (database.GetVariable("disablecommandline", tmp, 2)) {
			if (strlen(tmp) == 1) {
				if (tmp[0] == '1') {
					cout << "Command line disabled in database... exiting" << endl;
					return 0;
				}
			}
		}

		if (strcasecmp(argv[1], "adduser") == 0) {
			if (argc == 5) {
				if (Seperator::IsNumber(argv[4])) {
					if (atoi(argv[4]) >= 0 && atoi(argv[4]) <= 255) {
						if (database.CreateAccount(argv[2], argv[3], atoi(argv[4])) == 0)
							cout << "database.CreateAccount failed." << endl;
						else
							cout << "Account created: Username='" << argv[2] << "', Password='" << argv[3] << ", status=" << argv[4] << endl;
						return 0;
					}
				}
			}
			cout << "Usage: world adduser username password flag" << endl;
			cout << "flag = 0, 1 or 2" << endl;
			return 0;
		}
		if (strcasecmp(argv[1], "flag") == 0) {
			if (argc == 4) {
				if (Seperator::IsNumber(argv[3])) {
					if (atoi(argv[3]) >= 0 && atoi(argv[3]) <= 255) {
						if (database.SetGMFlag(argv[2], atoi(argv[3])))
							cout << "Account flagged: Username='" << argv[2] << "', status=" << argv[3] << endl;
						else
							cout << "database.SetGMFlag failed." << endl;
						return 0;
					}
				}
			}
			cout << "Usage: world flag username flag" << endl;
			cout << "flag = 0-200" << endl;
			return 0;
		}
		if (strcasecmp(argv[1], "startzone") == 0) {
			if (argc == 3) {
				if (strlen(argv[2]) < 3) {
					cout << "Error: zone name too short" << endl;
				}
				else if (strlen(argv[2]) > 15) {
					cout << "Error: zone name too long" << endl;
				}
				else {
					if (database.SetVariable("startzone", argv[2]))
						cout << "Starting zone changed: '" << argv[2] << "'" << endl;
					else
						cout << "database.SetVariable failed." << endl;
				}
				return 0;
			}
			cout << "Usage: world startzone zoneshortname" << endl;
			return 0;
		}
		else {
			cout << "Error, unknown command line option" << endl;
			return 0;
		}
	}
	char tmp[20];
	database.GetVariable("holdzones",tmp, 20);	
	if ((strcasecmp(tmp, "1") == 0)) {
		cout << "Reboot Zones mode ON" << endl;
		holdzones = true;
	}

	srand(time(NULL));
	cout << "Loading zone names & items...";
	database.LoadZoneNames();
	database.LoadItems();
	cout << "done." << endl;
	cout << "Loading guild ranks...";
	database.LoadGuilds(guilds);
	cout << "done." << endl;

	InitTCP();
	if (eqns.Open()) {
		if (strlen(net.GetWorldAddress()) == 0)
			cout << "World server listening on: port " << PORT << endl;
		else
			cout << "World server listening on: " << net.GetWorldAddress() << ":" << PORT << endl;
	}
	else {
		cout << "Failed to open port 9000." << endl;
		return 1;
	}

	#ifdef WIN32
		_beginthread(ConsoleLoop, 0, NULL);
		_beginthread(ZoneServerLoop, 0, NULL);
	#else
		pthread_t thread1, thread2;
		pthread_create(&thread1, NULL, &ConsoleLoop, NULL);
		pthread_create(&thread2, NULL, &ZoneServerLoop, NULL);
	#endif

	Timer InterserverTimer(INTERSERVER_TIMER); // does MySQL pings and auto-reconnect
	InterserverTimer.Trigger();
	EQNetworkConnection* eqnc;
	while(RunLoops) {
		Timer::SetCurrentTime();
		while (eqnc = eqns.NewQueuePop()) {
			struct in_addr	in;
			in.s_addr = eqnc->GetrIP();
			cout << Timer::GetCurrentTime() << " New client from ip: " << inet_ntoa(in) << " port: " << ntohs(eqnc->GetrPort()) << endl;
			Client* client = new Client(eqnc);
			client_list.Add(client);
		}
		loginserver.Process();
		if (InterserverTimer.Check()) {
			InterserverTimer.Start();
			database.ping();
			if (net.LoginServerInfo && loginserver.Connected() == false) {
#ifdef WIN32
				_beginthread(AutoInitLoginServer, 0, NULL);
#else
				pthread_t thread;
				pthread_create(&thread, NULL, &AutoInitLoginServer, NULL);
#endif
			}
		}
		if (numclients == 0) {
			Sleep(10);
			continue;
		}
		client_list.Process();
		Sleep(1);
	}
	while (ZoneLoopRunning || ConsoleLoopRunning) {
		Sleep(1);
	}
	return 0;
}

void CatchSignal(int sig_num) {
	cout << "Got signal " << sig_num << endl;
	RunLoops = false;
}

bool NetConnection::ReadLoginINI() {
	char buf[201], type[201];
	int items[2] = {0, 0};
	FILE *f;

	if (!(f = fopen ("LoginServer.ini", "r"))) {
		printf ("Couldn't open the LoginServer.ini file.\n");
		return false;
	}
	do {
		fgets (buf, 200, f);
		if (feof (f))
		{
			printf ("[LoginServer] block not found in LoginServer.ini.\n");
			fclose (f);
			return false;
		}
	}
	while (strncasecmp (buf, "[LoginServer]\n", 14) != 0 && strncasecmp (buf, "[LoginServer]\r\n", 15) != 0);

	while (!feof (f))
	{
#ifdef WIN32
		if (fscanf (f, "%[^=]=%[^\n]\r\n", type, buf) == 2)
#else
		if (fscanf (f, "%[^=]=%[^\r\n]\n", type, buf) == 2)
#endif
		{
			if (!strncasecmp (type, "worldname", 9)) {
				char tmp[200];
				strncpy (tmp, buf, 180);
				sprintf(tmp, "%s [%s]", tmp, CURRENT_VERSION);
				strncpy (worldname, tmp, 200);
				items[1] = 1;
			}
			if (!strncasecmp (type, "account", 7)) {
				strncpy(worldaccount, buf, 30);
			}
			if (!strncasecmp (type, "password", 8)) {
				strncpy (worldpassword, buf, 30);
			}
			if (!strncasecmp (type, "locked", 6)) {
				if (strcasecmp(buf, "true") == 0 || (buf[0] == '1' && buf[1] == 0))
					world_locked = true;
			}
			if (!strncasecmp (type, "worldaddress", 12)) {
				if (strlen(buf) >= 3) {
					strncpy (worldaddress, buf, 250);
				}
			}
			if ((!strcasecmp (type, "loginserver")) || (!strcasecmp (type, "loginserver1"))) {
				strncpy (loginaddress[0], buf, 100);
				items[0] = 1;
			}
			if ((!strcasecmp(type, "loginport")) || (!strcasecmp(type, "loginport1"))) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport[0] = atoi(buf);
				}
			}
			if (!strcasecmp (type, "loginserver2")) {
				strncpy (loginaddress[1], buf, 250);
			}
			if (!strcasecmp(type, "loginport2")) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport[1] = atoi(buf);
				}
			}
			if (!strcasecmp (type, "loginserver3")) {
				strncpy (loginaddress[2], buf, 250);
			}
			if (!strcasecmp(type, "loginport3")) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport[2] = atoi(buf);
				}
			}
			if (!strcasecmp (type, "loginserver4")) {
				strncpy (loginaddress[3], buf, 250);
			}
			if (!strcasecmp(type, "loginport4")) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport[3] = atoi(buf);
				}
			}
			if (!strcasecmp (type, "loginserver5")) {
				strncpy (loginaddress[4], buf, 250);
			}
			if (!strcasecmp(type, "loginport5")) {
				if (Seperator::IsNumber(buf) && atoi(buf) > 0 && atoi(buf) < 0xFFFF) {
					loginport[4] = atoi(buf);
				}
			}
		}
	}

	if (!items[0] || !items[1])
	{
		cout << "Incomplete LoginServer.INI file." << endl;
		fclose (f);
		return false;
	}

/*	if (strcasecmp(worldname, "Unnamed server") == 0) {
		cout << "LoginServer.ini: server unnamed, disabling uplink" << endl;
		fclose (f);
		return false;
	}*/
	
	fclose (f);
	cout << "LoginServer.ini read." << endl;
	return true;
}

char* NetConnection::GetLoginInfo(int16* oPort) {
	if (oPort == 0)
		return 0;
	if (loginaddress[0][0] == 0)
		return 0;

	int8 tmp[5] = { 0, 0, 0, 0, 0 };
	int8 count = 0;

	for (int i=0; i<5; i++) {
		if (loginaddress[i][0])
			tmp[count++] = i;
	}

	int x = rand() % count;

	*oPort = loginport[tmp[x]];
	return loginaddress[tmp[x]];
}