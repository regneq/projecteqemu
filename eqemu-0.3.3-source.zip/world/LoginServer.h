#ifndef LOGINSERVER_H
#define LOGINSERVER_H

#include "../common/servertalk.h"
#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/eq_packet_structs.h"
#include "../common/Mutex.h"
#include "../common/TCPConnection.h"

#ifdef WIN32
	void AutoInitLoginServer(void *tmp);
#else
	void *AutoInitLoginServer(void *tmp);
#endif
bool InitLoginServer();

struct LSAuth_Struct {
	int32	lsaccount_id;
	char	name[19];
	char	key[16];
	bool	stale;
	bool	inuse;
	bool	firstconnect;
};

class LoginServer : public TCPConnection {
public:
	LoginServer(const char* iAddress = 0, int16 iPort = 5999);
    ~LoginServer();

	bool Process();
	bool Connect(const char* iAddress = 0, int16 iPort = 0);

	void SendInfo();
	void SendStatus();
	void SendVersion();

	void AddAuth(LSAuth_Struct* newauth);
	LSAuth_Struct* CheckAuth(int32 in_lsaccount_id, const char* key);
	bool RemoveAuth(int32 in_lsaccount_id);
	void CheckStale();
private:
	int32	LoginServerIP;
	int16	LoginServerPort;
	Mutex	MAuthListLock;

	Timer* statusupdate_timer;
	Timer* staleauth_timer;

	LinkedList<LSAuth_Struct*> auth_list;
};
#endif
