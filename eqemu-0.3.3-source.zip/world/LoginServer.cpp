#include "../common/debug.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <iomanip.h>
#include <stdlib.h>
#include "../common/version.h"

#ifdef WIN32
	#include <process.h>
	#include <windows.h>
	#include <winsock.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp	_stricmp

#else // Pyro: fix for linux
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <pthread.h>
	#include <errno.h>

	#include "../common/unix.h"

	#include <unistd.h>

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1
	extern int errno;
#endif

#include "../common/servertalk.h"
#include "LoginServer.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "net.h"
#include "zoneserver.h"
#include "../common/database.h"

extern NetConnection net;
extern ZSList zoneserver_list;
extern LoginServer loginserver;
extern uint32 numzones;
extern int32 numplayers;
extern volatile bool	RunLoops;
volatile bool LoginLoopRunning = false;

bool AttemptingConnect = false;

LoginServer::LoginServer(const char* iAddress, int16 iPort)
: TCPConnection()
{
	LoginServerIP = ResolveIP(iAddress);
	LoginServerPort = iPort;
	statusupdate_timer = new Timer(LoginServer_StatusUpdateInterval);
	staleauth_timer = new Timer(LoginServer_AuthStale);
}

LoginServer::~LoginServer() {
	delete statusupdate_timer;
	delete staleauth_timer;
}

bool LoginServer::Process() {

	if (statusupdate_timer->Check()) {
		this->SendStatus();
		this->SendVersion();
	}
	if (staleauth_timer->Check()) {
		staleauth_timer->Start();
		CheckStale();
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	ServerPacket *pack = 0;
	while(pack = ServerRecvQueuePop())
	{
//cout << "Processing Packet from LoginServer: OPcode=0x" << hex << setw(4) << setfill('0') << pack->opcode << dec << " size=" << pack->size << endl;
		switch(pack->opcode) {
		case 0:
			break;
		case ServerOP_KeepAlive: {
			// ignore this
			break;
		}
		case ServerOP_LSClientAuth: {
			ServerLSClientAuth* slsca = (ServerLSClientAuth*) pack->pBuffer;
			LSAuth_Struct* lsa = new LSAuth_Struct;
			memset(lsa, 0, sizeof(LSAuth_Struct));
			lsa->lsaccount_id = slsca->lsaccount_id;
			strncpy(lsa->name, slsca->name, 18);
			strncpy(lsa->key, slsca->key, 15);
			lsa->stale = false;
			lsa->inuse = true;
			lsa->firstconnect = true;
			this->AddAuth(lsa);
//cout << "New Auth received for LS#" << slsca->lsaccount_id << endl;
//cout << "New Auth received for LS#" << slsca->lsaccount_id << ", k=" << slsca->key << endl;
			break;
		}
		case ServerOP_LSFatalError: {
			net.LoginServerInfo = false;
			cout << "Login server responded with FatalError. Disabling reconnect." << endl;
			if (pack->size > 1) {
				cout << "Error message: '" << (char*) pack->pBuffer << "'" << endl;
			}
			break;
		}
		case ServerOP_SystemwideMessage: {
			ServerSystemwideMessage* swm = (ServerSystemwideMessage*) pack->pBuffer;
			zoneserver_list.SendEmoteMessage(0, 0, swm->type, swm->message);
			break;
		}
		default:
		{
			cout << " Unknown LSOPcode:" << (int)pack->opcode;
			cout << " size:" << pack->size << endl;
DumpPacket(pack->pBuffer, pack->size);
			break;
		}
		}

		delete pack;
	}

	return true;
}

// this should always be called in a new thread
#ifdef WIN32
	void AutoInitLoginServer(void *tmp) {
#else
	void *AutoInitLoginServer(void *tmp) {
#endif
	srand(time(NULL));
	if (loginserver.GetState() == TCPS_Ready) {
		InitLoginServer();
	}
#ifndef WIN32
	return 0;
#endif
}

bool InitLoginServer() {
	if (loginserver.GetState() != TCPS_Ready) {
		cout << "Error: InitLoginServer() while already attempting connect" << endl;
		return false;
	}
	if (!net.LoginServerInfo) {
		cout << "Error: Login server info not loaded" << endl;
		return false;
	}

	AttemptingConnect = true;
	int16 port;
	char* address = net.GetLoginInfo(&port);
	loginserver.Connect(address, port);
}

bool LoginServer::Connect(const char* iAddress, int16 iPort) {
	char errbuf[TCPConnection_ErrorBufferSize];
	if (iAddress == 0) {
		cout << "Error: LoginServer::Connect: address == 0" << endl;
		return false;
	}
	else {
		if ((LoginServerIP = ResolveIP(iAddress, errbuf)) == 0) {
			cout << "Error: LoginServer::Connect: Resolving IP address: '" << errbuf << "'" << endl;
			return false;
		}
	}
	if (iPort != 0)
		LoginServerPort = iPort;

	if (LoginServerIP == 0 || LoginServerPort == 0) {
		cout << "Error: LoginServer::Connect: Connect info incomplete, cannot connect" << endl;
		return false;
	}

	if (TCPConnection::Connect(LoginServerIP, LoginServerPort, errbuf)) {
		cout << "Connected to LoginServer: " << iAddress << ":" << LoginServerPort << endl;
		SendInfo();
		SendStatus();
		SendVersion();
		return true;
	}
	else {
		cout << "Error: LoginServer::Connect: '" << errbuf << "'" << endl;
		return false;
	}
}

void LoginServer::SendInfo() {
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_LSInfo;
	pack->size = sizeof(ServerLSInfo_Struct);
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerLSInfo_Struct* lsi = (ServerLSInfo_Struct*) pack->pBuffer;
	strcpy(lsi->version, EQEMU_VERSION);
	strcpy(lsi->name, net.GetWorldName());
	strcpy(lsi->account, net.GetWorldAccount());
	strcpy(lsi->password, net.GetWorldPassword());
	strcpy(lsi->address, net.GetWorldAddress());
	SendPacket(pack);
	delete pack;
}

void LoginServer::SendStatus() {
	statusupdate_timer->Start();
	ServerPacket* pack = new ServerPacket;
	pack->opcode = ServerOP_LSStatus;
	pack->size = sizeof(ServerLSStatus_Struct);
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerLSStatus_Struct* lss = (ServerLSStatus_Struct*) pack->pBuffer;

	if (net.world_locked)
		lss->status = -2;
	if (numzones <= 0)
		lss->status = -2;

	if(lss->status != -2)
		lss->status = numplayers;

	lss->num_zones = numzones;
	lss->num_players = numplayers;
	SendPacket(pack);
	delete pack;
}

void LoginServer::SendVersion() {
ServerPacket* pack = new ServerPacket;
pack->opcode = ServerOP_WorldVersion;
pack->size = sizeof(WorldVersion_Struct);
pack->pBuffer = new uchar[pack->size];
memset(pack->pBuffer, 0, pack->size);
WorldVersion_Struct* wvs = (WorldVersion_Struct*) pack->pBuffer;
strcpy(wvs->version,CURRENT_VERSION);
SendPacket(pack);
delete pack;
}

void LoginServer::AddAuth(LSAuth_Struct* newauth) {
	LockMutex lock(&MAuthListLock);
	auth_list.Insert(newauth);
}

LSAuth_Struct* LoginServer::CheckAuth(int32 in_lsaccount_id, const char* key) {
	LinkedListIterator<LSAuth_Struct*> iterator(auth_list);

	LockMutex lock(&MAuthListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->lsaccount_id == in_lsaccount_id && strcmp(iterator.GetData()->key, key) == 0) {
			LSAuth_Struct* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

bool LoginServer::RemoveAuth(int32 in_lsaccount_id) {
	LinkedListIterator<LSAuth_Struct*> iterator(auth_list);

	LockMutex lock(&MAuthListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->lsaccount_id == in_lsaccount_id) {
			iterator.RemoveCurrent();
			return true;
		}
		iterator.Advance();
	}
	return false;
}

void LoginServer::CheckStale() {
	LinkedListIterator<LSAuth_Struct*> iterator(auth_list);

	LockMutex lock(&MAuthListLock);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->inuse) {
			if (iterator.GetData()->stale) {
				iterator.RemoveCurrent();
			}
			else {
				iterator.GetData()->stale = true;
				iterator.Advance();
			}
		}
		else
			iterator.Advance();
	}
}
