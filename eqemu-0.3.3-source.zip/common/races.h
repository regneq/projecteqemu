#ifndef RACES_H
#define RACES_H

#define HUMAN			  1
#define BARBARIAN		  2
#define ERUDITE			  3
#define WOOD_ELF		  4
#define HIGH_ELF		  5
#define DARK_ELF		  6
#define HALF_ELF		  7
#define DWARF			  8
#define TROLL			  9
#define OGRE			 10
#define HALFLING		 11
#define GNOME			 12
#define WEREWOLF		 14
#define SKELETON		 60
#define ELEMENTAL		 75
#define EYE_OF_ZOMM		108
#define WOLF_ELEMENTAL	120
#define IKSAR			128
#define VAHSHIR			130
#define IKSAR_SKELETON	161

const char* GetRaceName(int8 race);

#endif
