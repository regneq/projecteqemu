signed char sign(signed int tmp);
signed char sign(double tmp);

