/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "EQPacketManager.h"

#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h>

template <typename type>                    // LO_BYTE
type  LO_BYTE (type a) {return (a&=0xff);}  
template <typename type>                    // HI_BYTE 
type  HI_BYTE (type a) {return (a&=0xff00);} 
template <typename type>                    // LO_WORD
type  LO_WORD (type a) {return (a&=0xffff);}  
template <typename type>                    // HI_WORD 
type  HI_WORD (type a) {return (a&=0xffff0000);} 
template <typename type>                    // HI_LOSWAPshort
type  HI_LOSWAPshort (type a) {return (LO_BYTE(a)<<8) | (HI_BYTE(a)>>8);}  
template <typename type>                    // HI_LOSWAPlong
type  HI_LOSWAPlong (type x) {return (LO_WORD(a)<<16) | (HIWORD(a)>>16);}  

//#define LOG_PACKETS
//#define LOG_RAW_PACKETS_OUT
//#define LOG_RAW_PACKETS_IN

CEQPacketManager::CEQPacketManager()
{
    pm_state = PM_ACTIVE;
    dwLastCACK = 0;
    dwFragSeq  = 0;
    
    no_ack_received_timer = new Timer(500);
    no_ack_sent_timer = new Timer(500);

    /* 
       on a normal server there is always data getting sent 
       so the packetloss indicator in eq stays at 0%

       This timer will send dummy data if nothing has been sent
       in 1000ms. This is not needed. When the client doesnt
       get any data it will send a special ack request to ask
       if we are still alive. The eq client will show around 40%
       packetloss at this time. It is not real packetloss. Its
       just thinking there is packetloss since no data is sent.
       The EQ servers doesnt have a timer like this one.

       short version: This timer is not needed, it just keeps
       the green bar green.
    */
    keep_alive_timer = new Timer(1000);

    no_ack_received_timer->Disable();
    no_ack_sent_timer->Disable();

    debug_level = 0;

	datarate_timer = new Timer(100);
	datarate_timer->Start();
	dataflow = 0;
	datarate_sec = 25000; // 25.0
	datarate_tic = datarate_sec / 10;
	force_resend_packets_timer = new Timer(1250);
}

CEQPacketManager::~CEQPacketManager()
{
	delete no_ack_received_timer;
	delete no_ack_sent_timer;
	delete keep_alive_timer;
	delete datarate_timer;
	delete force_resend_packets_timer;
	MySendPacketStruct* p = 0;
	while (p = SendQueue.pop()) {
		delete p->buffer;
		delete p;
	}
//	APPLAYER* app = 0;
//	while (app = OutQueue.pop()) {
//		delete app;
//	}
}
/*****************************************************************************
*********/

void CEQPacketManager::IncomingARSP(int16 dwARSP) 
{ 
    if (debug_level >= 4)
    {
        cout << "Incoming ack response: " << dwARSP << " SACK.dwARQ:" << SACK.dwARQ << endl;
    }
	CEQPacket *pack;
    while (!ResendQueue.empty() && dwARSP - ResendQueue.top()->dwARQ >= 0)
    {
        if (debug_level >= 5)
        {
            cout << "Removing " << ResendQueue.top()->dwARQ << " from resendqueue" << endl;
        }
        pack = ResendQueue.pop();
		safe_delete(pack);
    }
    if (ResendQueue.empty())
    {
        no_ack_received_timer->Disable();
        if (debug_level >= 5)
        {
//            cout << Timer::GetCurrentTime() << " no_ack_received_timer->Disable()";
//            cout << " dwARSP:" << (unsigned short)dwARSP;
//            cout << " SACK.dwARQ:" << (unsigned short)SACK.dwARQ << endl;
        }
    }
}

void CEQPacketManager::IncomingARQ(int16 dwARQ) 
{
    CACK.dwARQ = dwARQ;
    dwLastCACK = dwARQ;
    
    if (!no_ack_sent_timer->Enabled())
    {
        no_ack_sent_timer->Start(500); // Agz: If we dont get any outgoing packet we can put an 
        // ack response in before 500ms has passed we send a pure ack response
//		if (debug_level >= 2)
//            cout << Timer::GetCurrentTime() << " no_ack_sent_timer->Start(500)" << endl;
    }
}

void CEQPacketManager::OutgoingARQ(int16 dwARQ)   //An ack request is sent
{
    if(!no_ack_received_timer->Enabled())
    {
        no_ack_received_timer->Start(500);
//        if (debug_level >= 2)
//            cout << Timer::GetCurrentTime() << " no_ack_received_timer->Start(500)" << "ARQ:" << (unsigned short) dwARQ << endl;
    }
	if (debug_level >= 4)
		cout << "Outgoing ARQ:" << (unsigned short) dwARQ << endl;
}

void CEQPacketManager::OutgoingARSP(void)
{
    no_ack_sent_timer->Disable(); // Agz: We have sent the ack response
//    if (debug_level >= 2)
//        cout << Timer::GetCurrentTime() << " no_ack_sent_timer->Disable()" << endl;
}

/************ PARCE A EQPACKET ************/
void CEQPacketManager::ParceEQPacket(int16 dwSize, uchar* pPacket)
{
    if(pm_state != PM_ACTIVE)
        return;

    /************ DECODE PACKET ************/
    CEQPacket* pack = new CEQPacket;
    pack->DecodePacket(dwSize, pPacket);
#ifdef LOG_RAW_PACKETS_IN
		cout << "Incomming RAW packet: size=" << dwSize << " " << "headers:";
		cout << (int) pack->HDR.a7_SEQEnd;
		cout << (int) pack->HDR.a6_Closing;
		cout << (int) pack->HDR.a5_SEQStart;
		cout << (int) pack->HDR.a4_ASQ;
		cout << " ";
		cout << (int) pack->HDR.a3_Fragment;
		cout << (int) pack->HDR.a2_Closing;
		cout << (int) pack->HDR.a1_ARQ;
		cout << (int) pack->HDR.a0_Unknown;
		cout << "  ";
		cout << (int) pack->HDR.b7_Unknown;
		cout << (int) pack->HDR.b6_Unknown;
		cout << (int) pack->HDR.b5_Unknown;
		cout << (int) pack->HDR.b4_Unknown;
		cout << " ";
		cout << (int) pack->HDR.b3_Unknown;
		cout << (int) pack->HDR.b2_ARSP;
		cout << (int) pack->HDR.b1_Unknown;
		cout << (int) pack->HDR.b0_SpecARQ;
		cout << endl;
		DumpPacket(pPacket, dwSize);
#endif
    if (ProcessPacket(pack, false))
    {
        delete pack;
    }
    CheckBufferedPackets();
}

/*
    Return true if its safe to delete this packet now, if we buffer it return false
    this way i can skip memcpy the packet when buffering it
*/
bool CEQPacketManager::ProcessPacket(CEQPacket* pack, bool from_buffer)
{
    /************ CHECK FOR ACK/SEQ RESET ************/ 
    if(pack->HDR.a5_SEQStart)
    {
//      cout << "resetting SACK.dwGSQ1" << endl;
//      SACK.dwGSQ      = 0;            //Main sequence number SHORT#2
        dwLastCACK      = pack->dwARQ-1;//0;
//      CACK.dwGSQ = 0xFFFF; changed next if to else instead
    }
    // Agz: Moved this, was under packet resend before..., later changed to else statement...
    else if( (pack->dwSEQ - CACK.dwGSQ) <= 0 && !from_buffer)  // Agz: if from the buffer i ignore sequence number..
    {
        if (debug_level >= 6)
        {
            cout << Timer::GetCurrentTime() << " ";
            cout << "Invalid packet ";
            cout << "pack->dwSEQ:" << pack->dwSEQ << " ";
            cout << "CACK.dwGSQ;" << CACK.dwGSQ << " ";
            cout << "pack->dwARQ:" << pack->dwARQ << endl;
        }
        return true; //Invalid packet
    }
    else if (debug_level >= 9)
    {
        cout << Timer::GetCurrentTime() << " ";
        cout << "Valid packet ";
        cout << "pack->dwSEQ:" << pack->dwSEQ << " ";
        cout << "CACK.dwGSQ;" << CACK.dwGSQ << " ";
        cout << "pack->dwARQ:" << pack->dwARQ << endl;
    }

    CACK.dwGSQ = pack->dwSEQ; //Get current sequence #.

    /************ Process ack responds ************/
	// Quagmire: Moved this to above "ack request" checking in case the packet is dropped in there
    if(pack->HDR.b2_ARSP)
        IncomingARSP(pack->dwARSP);
    /************ End process ack rsp ************/

    // Does this packet contain an ack request?
    if(pack->HDR.a1_ARQ)
    {
        // Is this packet a packet we dont want now, but will need later?
        if(pack->dwARQ - dwLastCACK > 1 && pack->dwARQ - dwLastCACK < 16) // Agz: Added 16 limit
        {
            // Debug check, if we want to buffer a packet we got from the buffer something is wrong...
            if (from_buffer)
            {
                cerr << "ERROR: Rebuffering a packet in CEQPacketManager::ProcessPacket" << endl;
            }
            LinkedListIterator<CEQPacket*> iterator(buffered_packets);
            iterator.Reset();
            while(iterator.MoreElements())
            {
                if (iterator.GetData()->dwARQ == pack->dwARQ)
                {
                    if (debug_level >= 6)
                    {
                        cout << Timer::GetCurrentTime() << " ";
                        cout << "Tried to buffer this packet, but it was already buffered ";
                        cout << "pack->dwARQ:" << pack->dwARQ << " ";
                        cout << "dwLastCACK:" << dwLastCACK << " ";
                        cout << "pack->dwSEQ:" << pack->dwSEQ << endl;
                    }
                    return true; // This packet was already buffered
                }
                iterator.Advance();
            }

			if (debug_level >= 1) {
				cout << Timer::GetCurrentTime() << " ";
				cout << "Buffering this packet ";
				cout << "pack->dwARQ:" << pack->dwARQ << " ";
				cout << "dwLastCACK:" << dwLastCACK << " ";
				cout << "pack->dwSEQ:" << pack->dwSEQ << endl;
			}

            buffered_packets.Insert(pack);
            return false;
        }
        // Is this packet a resend we have already processed?
        if(pack->dwARQ - dwLastCACK <= 0)
        {
            if (debug_level >= 6)
            {
                cout << Timer::GetCurrentTime() << " ";
                cout << "Duplicate packet received ";
                cout << "pack->dwARQ:" << pack->dwARQ << " ";
                cout << "dwLastCACK:" << dwLastCACK << " ";
                cout << "pack->dwSEQ:" << pack->dwSEQ << endl;
            }
            no_ack_sent_timer->Trigger(); // Added to make sure we send a new ack respond
            return true;
        }
    }
    
    /************ START ACK REQ CHECK ************/
    if (pack->HDR.a1_ARQ || pack->HDR.b0_SpecARQ)
        IncomingARQ(pack->dwARQ);   
    if (pack->HDR.b0_SpecARQ) // Send the ack reponse right away
        no_ack_sent_timer->Trigger();
    /************ END ACK REQ CHECK ************/

    /************ CHECK FOR THREAD TERMINATION ************/
    if(pack->HDR.a2_Closing && pack->HDR.a6_Closing)
    {
        if(!pm_state)
        {
            if (debug_level >= 1)
            {
                cout << "Closing bits received from client" << endl;
            }
            pm_state = PM_FINISHING;
            MakeEQPacket(0); // Agz: Added a close packet
        }
    }
    /************ END CHECK THREAD TERMINATION ************/

    /************ Get ack sequence number ************/
    if(pack->HDR.a4_ASQ)
        CACK.dbASQ_high = pack->dbASQ_high;
    
    if(pack->HDR.a1_ARQ)
        CACK.dbASQ_low = pack->dbASQ_low;
    /************ End get ack seq num ************/

    /************ START FRAGMENT CHECK ************/
    /************ IF - FRAGMENT ************/
    if(pack->HDR.a3_Fragment) 
    {
        if (debug_level >= 7)
        {
            cout << endl << Timer::GetCurrentTime() << " Fragment: ";
            cout << "pack->fraginfo.dwSeq:" << pack->fraginfo.dwSeq << " ";
            cout << "pack->fraginfo.dwCurr:" << pack->fraginfo.dwCurr << " ";
            cout << "pack->fraginfo.dwTotal:" << pack->fraginfo.dwTotal << endl;
        }
        FragmentGroup* fragment_group = 0;
        fragment_group = fragment_group_list.Get(pack->fraginfo.dwSeq);

        // If we dont have a fragment group with the right sequence number, create a new one
        if (fragment_group == 0)
        {
            fragment_group = new FragmentGroup(pack->fraginfo.dwSeq,pack->dwOpCode, pack->fraginfo.dwTotal);
            fragment_group_list.Add(fragment_group);
        }

        // Add this fragment to the fragment group
        fragment_group->Add(pack->fraginfo.dwCurr, pack->pExtra,pack->dwExtraSize);

        // If we have all the fragments to complete this group
        if(pack->fraginfo.dwCurr == (pack->fraginfo.dwTotal - 1) )
        {
            if (debug_level >= 8)
                cout << Timer::GetCurrentTime() << " Getting fragment opcode:" << fragment_group->GetOpcode() << endl;
            //Collect fragments and put them as one packet on the OutQueue
            APPLAYER *app = new APPLAYER;
            app->pBuffer = fragment_group->AssembleData(&app->size);
            app->opcode = fragment_group->GetOpcode();
            fragment_group_list.Remove(pack->fraginfo.dwSeq);
            if (debug_level >= 8)
                cout << "FRAGMENT_GROUP finished" << endl;

#ifdef LOG_PACKETS
	if (app && app->opcode != 0 && app->opcode != 0xFFFF) {
		cout << "Logging incoming packet. OPCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
		DumpPacketHex(app);
	}
#endif

            OutQueue.push(app);
            return true;
        }
        else
        {
            if (debug_level >= 8)
                cout << "FRAGMENT_GROUP not finished wait for more... " << endl;
            return true;
        }
    }
    /************ ELSE - NO FRAGMENT ************/
    else 
    {
        APPLAYER *app	= new APPLAYER;   
        app->pBuffer    = new uchar[pack->dwExtraSize]; memcpy(app->pBuffer,pack->pExtra, pack->dwExtraSize); // Agz: Added alloc
        app->size       = pack->dwExtraSize;
        app->opcode     = pack->dwOpCode;
        if (debug_level >= 9)
            cout << "Packet processed opcode:" << pack->dwOpCode << " length:" << app->size << endl;

#ifdef LOG_PACKETS
	if (app && app->opcode != 0 && app->opcode != 0xFFFF) {
		cout << "Logging incoming packet. OPCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
		DumpPacketHex(app);
	}
#endif

        OutQueue.push(app);
        return true;
    }
    /************ END FRAGMENT CHECK ************/

    cout << endl << "reached end of ParceEQPacket?!" << endl << endl;
    return true;
}

void CEQPacketManager::CheckBufferedPackets()
{
// Should use a hash table or sorted list instead....
    int num=0; // Counting buffered packets for debug output
    LinkedListIterator<CEQPacket*> iterator(buffered_packets);
    iterator.Reset();
    while(iterator.MoreElements())
    {
        num++;
        // Check if we have a packet we want already buffered
        if (iterator.GetData()->dwARQ - dwLastCACK == 1)
        {
            if (debug_level >= 8)
            {
                cout << Timer::GetCurrentTime() << " ";
                cout << "Found a packet we want in the incoming packet buffer";
                cout << "pack->dwARQ:" << iterator.GetData()->dwARQ << " ";
                cout << "dwLastCACK:" << dwLastCACK << " ";
                cout << "pack->dwSEQ:" << iterator.GetData()->dwSEQ << endl;
            }
            ProcessPacket(iterator.GetData(), true);
            iterator.RemoveCurrent(); // This will call delete on the packet
            iterator.Reset();         // Start from the beginning of the list again
            num=0;                    // Reset the counter
            continue;
        }
        iterator.Advance();
    }

    if (debug_level >= 9)
        cout << "Number of packets in buffer:" << num << endl;
}

/************************************************************************/
/************ Make an EQ packet and put it to the send queue ************/
/* 
    APP->size == 0 && app->pBuffer == NULL if no data.

    Agz: set ack_req = false if you dont want this packet to require an ack
    response from the client, this menas this packet may get lost and not
    resent. This is used by the EQ servers for HP and position updates among 
    other things. WARNING: I havent tested this yet.
*/
void CEQPacketManager::MakeEQPacket(APPLAYER* app, bool ack_req)
{
#ifdef LOG_PACKETS
	if (app && app->opcode != 0 && app->opcode != 0xFFFF) {
		cout << "Logging outgoing packet. OPCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
		DumpPacketHex(app);
	}
#endif

    int16 restore_op;

    /************ PM STATE = NOT ACTIVE ************/
    if(pm_state == PM_FINISHING)
    {
        CEQPacket *pack = new CEQPacket;
        MySendPacketStruct *p = new MySendPacketStruct;

        pack->dwSEQ = SACK.dwGSQ++; // Agz: Added this commented rest        
  
        pack->HDR.a6_Closing    = 1;// Agz: Lets try to uncomment this line again
        pack->HDR.a2_Closing    = 1;// and this
        pack->HDR.a1_ARQ        = 1;// and this
//      pack->dwARQ             = 1;// and this, no that was not too good
        pack->dwARQ             = SACK.dwARQ;// try this instead

        AddAck(pack);
        pm_state = PM_FINISHED;
        
        p->buffer = pack->ReturnPacket(&p->size);
#ifdef LOG_RAW_PACKETS_OUT
		cout << "Outgoing RAW packet: size=" << p->size << " " << "headers:";
		cout << (int) pack->HDR.a7_SEQEnd;
		cout << (int) pack->HDR.a6_Closing;
		cout << (int) pack->HDR.a5_SEQStart;
		cout << (int) pack->HDR.a4_ASQ;
		cout << " ";
		cout << (int) pack->HDR.a3_Fragment;
		cout << (int) pack->HDR.a2_Closing;
		cout << (int) pack->HDR.a1_ARQ;
		cout << (int) pack->HDR.a0_Unknown;
		cout << "  ";
		cout << (int) pack->HDR.b7_Unknown;
		cout << (int) pack->HDR.b6_Unknown;
		cout << (int) pack->HDR.b5_Unknown;
		cout << (int) pack->HDR.b4_Unknown;
		cout << " ";
		cout << (int) pack->HDR.b3_Unknown;
		cout << (int) pack->HDR.b2_ARSP;
		cout << (int) pack->HDR.b1_Unknown;
		cout << (int) pack->HDR.b0_SpecARQ;
		cout << endl;
		DumpPacket(p->buffer, p->size);
#endif
        SendQueue.push(p);
        SACK.dwGSQ++; 
		delete pack;

        return;
    }

    // Agz:Moved this to after finish check
    if(app == NULL)
    {
        cout << "CEQPacketManager::MakeEQPacket app == NULL" << endl;
        return;
    }
    bool bFragment= false; //This is set later on if fragseq should be increased at the end.

    /************ IF opcode is == 0xFFFF it is a request for pure ack creation ************/
    if(app->opcode == 0xFFFF)
    {
        CEQPacket *pack = new CEQPacket;

        if(!SACK.dwGSQ)
        {
//          pack->HDR.a5_SEQStart   = 1; // Agz: hmmm, yes commenting this makes the client connect to zone
                                         //      server work and the world server doent seem to care either way
            SACK.dwARQ              = rand()%0x3FFF;//Current request ack
            SACK.dbASQ_high         = 1;            //Current sequence number
            SACK.dbASQ_low          = 0;            //Current sequence number
  
            if (debug_level >= 1)
                cout << "New random SACK.dwARQ" << endl;
        }
        if (debug_level >= 3)
            cout << "SACK.dwGSQ:" << SACK.dwGSQ << endl;
        MySendPacketStruct *p = new MySendPacketStruct;
        pack->HDR.b2_ARSP    = 1;
        pack->dwARSP         = dwLastCACK;//CACK.dwARQ;
        pack->dwSEQ = SACK.dwGSQ++;
        p->buffer = pack->ReturnPacket(&p->size);

        if (debug_level >= 6)
        {
            cout << Timer::GetCurrentTime() << " Pure ack sent ";
            cout << "pack->dwARSP=dwLastCACK:" << dwLastCACK << " ";
            cout << "pack->dwSEQ=SACK.dwGSQ:" << SACK.dwGSQ << endl;
        }
#ifdef LOG_RAW_PACKETS_OUT
		cout << "Outgoing RAW packet: size=" << p->size << " " << "headers:";
		cout << (int) pack->HDR.a7_SEQEnd;
		cout << (int) pack->HDR.a6_Closing;
		cout << (int) pack->HDR.a5_SEQStart;
		cout << (int) pack->HDR.a4_ASQ;
		cout << " ";
		cout << (int) pack->HDR.a3_Fragment;
		cout << (int) pack->HDR.a2_Closing;
		cout << (int) pack->HDR.a1_ARQ;
		cout << (int) pack->HDR.a0_Unknown;
		cout << "  ";
		cout << (int) pack->HDR.b7_Unknown;
		cout << (int) pack->HDR.b6_Unknown;
		cout << (int) pack->HDR.b5_Unknown;
		cout << (int) pack->HDR.b4_Unknown;
		cout << " ";
		cout << (int) pack->HDR.b3_Unknown;
		cout << (int) pack->HDR.b2_ARSP;
		cout << (int) pack->HDR.b1_Unknown;
		cout << (int) pack->HDR.b0_SpecARQ;
		cout << endl;
		DumpPacket(p->buffer, p->size);
#endif
        SendQueue.push(p);  

        no_ack_sent_timer->Disable();
		delete pack;

        return;
    }

    /************ CHECK PACKET MANAGER STATE ************/
    int fragsleft = (app->size >> 9) + 1;

    if (debug_level >= 8)
        cout << Timer::GetCurrentTime() << " fragsleft: " << fragsleft << endl;

    if(pm_state == PM_ACTIVE)
    /************ PM STATE = ACTIVE ************/
    {
        while(fragsleft--)
        {
            CEQPacket *pack = new CEQPacket;
            MySendPacketStruct *p = new MySendPacketStruct;
    
            if(!SACK.dwGSQ)
            {
                pack->HDR.a5_SEQStart   = 1;
                SACK.dwARQ              = rand()%0x3FFF;//Current request ack
                SACK.dbASQ_high         = 1;            //Current sequence number
                SACK.dbASQ_low          = 0;            //Current sequence number   
                if (debug_level >= 1)
                    cout << "New random SACK.dwARQ: 0x" << hex << setw(4) << setfill('0') << SACK.dwARQ << dec << endl;
            }
            if (debug_level >= 5)
                cout << "SACK.dwGSQ:" << SACK.dwGSQ << endl;

            AddAck(pack);

            //IF NON PURE ACK THEN ALWAYS INCLUDE A ACKSEQ              // Agz: Not anymore... Always include ackseq if not a fragmented packet
            if ((app->size >> 9) == 0 || fragsleft == (app->size >> 9)) // If this will be a fragmented packet, only include ackseq in first fragment
                pack->HDR.a4_ASQ = 1;                                   // This is what the eq servers does

            /************ Caculate the next ACKSEQ/acknumber ************/
            /************ Check if its a static ackseq ************/
            if( HI_BYTE(app->opcode) == 0x2000)
            {
                if(app->size == 15)
                    pack->dbASQ_low = 0xb2;
                else
                    pack->dbASQ_low = 0xa1;

            }
            /************ Normal ackseq ************/
            else
            {
                //If not pure ack and opcode != 0x20XX then
                if (ack_req) // If the caller of this function wants us to put an ack request on this packet
                {
                    pack->HDR.a1_ARQ = 1;
                    pack->dwARQ      = SACK.dwARQ;
                }

                if(pack->HDR.a1_ARQ && pack->HDR.a4_ASQ)
                {
                    pack->dbASQ_low  = SACK.dbASQ_low;
                    pack->dbASQ_high = SACK.dbASQ_high;
                }
                else
                {
                    if(pack->HDR.a4_ASQ)
                    {
                        pack->dbASQ_high = SACK.dbASQ_high;
                    }
                }
            }

            /************ Check if this packet should contain op ************/
            if(app->opcode)
            {
                pack->dwOpCode = app->opcode;
                restore_op =  app->opcode; // Agz: I'm reusing messagees when sending to multiple clients.
                app->opcode = 0; //Only first fragment contains op
            }
            /************ End opcode check ************/

            /************ SHOULD THIS PACKET BE SENT AS A FRAGMENT ************/
            if((app->size >> 9))
            {
                bFragment = true;
                pack->HDR.a3_Fragment = 1;
            }
            /************ END FRAGMENT CHECK ************/

            if(app->size && app->pBuffer)
            {
                if(pack->HDR.a3_Fragment)
                {
                    // If this is the last packet in the fragment group
                    if(!fragsleft)
                    {
                        // Calculate remaining bytes for this fragment
                        pack->dwExtraSize = app->size-510-512*((app->size/512)-1);
                    }
                    else
                    {
                        if(fragsleft == (app->size >> 9))
                        {
                            pack->dwExtraSize = 510; // The first packet in a fragment group has 510 bytes for data

                        }
                        else
                        {
                            pack->dwExtraSize = 512; // Other packets in a fragment group has 512 bytes for data
                        }
                    }
                    pack->fraginfo.dwCurr = (app->size >> 9) - fragsleft;
                    pack->fraginfo.dwSeq  = dwFragSeq;
                    pack->fraginfo.dwTotal= (app->size >> 9) + 1;
                }
                else
                {
                    pack->dwExtraSize = (int16)app->size;
                }
                pack->pExtra = new uchar[pack->dwExtraSize];
                memcpy((void*)pack->pExtra, (void*)app->pBuffer, pack->dwExtraSize);
                app->pBuffer += pack->dwExtraSize; //Increase counter
            }       

            /******************************************/
            /*********** !PACKET GENERATED! ***********/
            /******************************************/
            
            /************ Update timers ************/
            if(pack->HDR.a1_ARQ)
            {
                if (debug_level >= 5)
                    cout << "OutgoingARQ pack->dwARQ:" << (unsigned short)pack->dwARQ << " SACK.dwARQ:" << (unsigned short)SACK.dwARQ << endl;
                OutgoingARQ(pack->dwARQ);
                ResendQueue.push(pack);
                SACK.dwARQ++;
            }
    
            if(pack->HDR.b2_ARSP)
                OutgoingARSP();

            keep_alive_timer->Start();
            /************ End update timers ************/
                    
            pack->dwSEQ = SACK.dwGSQ++;
            p->buffer = pack->ReturnPacket(&p->size);
            
#ifdef LOG_RAW_PACKETS_OUT
			cout << "Outgoing RAW packet: size=" << p->size << " " << "headers:";
			cout << (int) pack->HDR.a7_SEQEnd;
			cout << (int) pack->HDR.a6_Closing;
			cout << (int) pack->HDR.a5_SEQStart;
			cout << (int) pack->HDR.a4_ASQ;
			cout << " ";
			cout << (int) pack->HDR.a3_Fragment;
			cout << (int) pack->HDR.a2_Closing;
			cout << (int) pack->HDR.a1_ARQ;
			cout << (int) pack->HDR.a0_Unknown;
			cout << "  ";
			cout << (int) pack->HDR.b7_Unknown;
			cout << (int) pack->HDR.b6_Unknown;
			cout << (int) pack->HDR.b5_Unknown;
			cout << (int) pack->HDR.b4_Unknown;
			cout << " ";
			cout << (int) pack->HDR.b3_Unknown;
			cout << (int) pack->HDR.b2_ARSP;
			cout << (int) pack->HDR.b1_Unknown;
			cout << (int) pack->HDR.b0_SpecARQ;
			cout << endl;
			DumpPacket(p->buffer, p->size);
#endif
            SendQueue.push(p);
    
            if(pack->HDR.a4_ASQ)
                SACK.dbASQ_low++;
			
			if (!pack->HDR.a1_ARQ) { // Quag: need to delete it since didnt get on the resend queue
				delete pack;
			}
            
        }//end while

        if(bFragment)
            dwFragSeq++;
        app->pBuffer -= app->size; //Restore ptr.
        app->opcode = restore_op; // Agz: Restore opcode
        
    } //end if
}

void CEQPacketManager::CheckTimers(void)
{
	if ((!DataQueueFull()) || force_resend_packets_timer->Check()) {
		/************ Should packets be resent? ************/
		force_resend_packets_timer->Start();
		if (no_ack_received_timer->Check()) {
			if (debug_level >= 1)
				cout << "Resending packets" << endl;
			CEQPacket *pack;
			MyQueue<CEQPacket> q;
			while(pack = ResendQueue.pop())
			{
				q.push(pack);
				MySendPacketStruct *p = new MySendPacketStruct;
				pack->dwSEQ = SACK.dwGSQ++;
				if (debug_level >= 4)
					cout << "Resending packet ARQ:" << pack->dwARQ << " with SEQ:" << pack->dwSEQ << ", count=" << (int16) pack->resend_count << endl;
				p->buffer = pack->ReturnPacket(&p->size);
#ifdef LOG_RAW_PACKETS_OUT
		cout << "Outgoing RAW packet: size=" << p->size << " " << "headers:";
		cout << (int) pack->HDR.a7_SEQEnd;
		cout << (int) pack->HDR.a6_Closing;
		cout << (int) pack->HDR.a5_SEQStart;
		cout << (int) pack->HDR.a4_ASQ;
		cout << " ";
		cout << (int) pack->HDR.a3_Fragment;
		cout << (int) pack->HDR.a2_Closing;
		cout << (int) pack->HDR.a1_ARQ;
		cout << (int) pack->HDR.a0_Unknown;
		cout << "  ";
		cout << (int) pack->HDR.b7_Unknown;
		cout << (int) pack->HDR.b6_Unknown;
		cout << (int) pack->HDR.b5_Unknown;
		cout << (int) pack->HDR.b4_Unknown;
		cout << " ";
		cout << (int) pack->HDR.b3_Unknown;
		cout << (int) pack->HDR.b2_ARSP;
		cout << (int) pack->HDR.b1_Unknown;
		cout << (int) pack->HDR.b0_SpecARQ;
		cout << endl;
		DumpPacket(p->buffer, p->size);
#endif
				SendQueue.push(p);
			}
			while(pack = q.pop())
			{
				ResendQueue.push(pack);
				if(++pack->resend_count > 15) {
					if (debug_level >= 1) {
						cout << "Dropping client, resend_count > 15 on ARQ:" << pack->dwARQ << ", SEQ:" << pack->dwSEQ << endl;
					}
					pm_state = PM_FINISHING;
					MakeEQPacket(0);
				}
			}

			no_ack_received_timer->Start(1000);
		}
	}
	/************ Should a pure ack be sent? ************/
	if (no_ack_sent_timer->Check() || keep_alive_timer->Check())
	{
		APPLAYER app;
		app.opcode = 0xFFFF;
		MakeEQPacket(&app);
	}

	if (datarate_timer->Check()) {
		dataflow -= datarate_tic;
		if (dataflow < 0)
			dataflow = 0;
	}
}

