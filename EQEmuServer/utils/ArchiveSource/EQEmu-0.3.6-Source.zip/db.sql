-- EQEmu 0.3.6 Database

-- To install, copy this file to your mySQL/bin folder and run mysql.exe
-- Type "create database eq;" (if one doesnt exist) then type "use eq". then type "source db.sq;"

--
-- Table structure for table 'account'
--

CREATE TABLE account (
  id int(11) NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  charname varchar(64) NOT NULL default '',
  packencrypt blob NOT NULL default '',
  password varchar(30) NOT NULL default '',
  status tinyint(2) unsigned NOT NULL default '0',
  lsaccount_id int(11) unsigned default NULL,
  gmspeed tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY lsaccount_id (lsaccount_id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'account'
--


INSERT INTO account VALUES (1,'eqemu','eqemu',0,NULL,0);

--
-- Table structure for table 'altadv_vars'
--

CREATE TABLE altadv_vars (
  skill_id int(11) default NULL,
  name varchar(128) default NULL,
  cost int(11) default NULL,
  max_level int(11) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'altadv_vars'
--


INSERT INTO altadv_vars VALUES (0,'Unknown0',0,0);
INSERT INTO altadv_vars VALUES (1,'Innate Strength',1,5);
INSERT INTO altadv_vars VALUES (2,'Innate Stamina',1,5);
INSERT INTO altadv_vars VALUES (3,'Innate Agility',1,5);
INSERT INTO altadv_vars VALUES (4,'Innate Dexterity',1,5);
INSERT INTO altadv_vars VALUES (5,'Innate Intelligence',1,5);
INSERT INTO altadv_vars VALUES (6,'Innate Wisdom',1,5);
INSERT INTO altadv_vars VALUES (7,'Innate Charisma',1,5);
INSERT INTO altadv_vars VALUES (8,'Innate Fire Protection',1,5);
INSERT INTO altadv_vars VALUES (9,'Innate Cold Protection',1,5);
INSERT INTO altadv_vars VALUES (10,'Innate Magic Protection',1,5);
INSERT INTO altadv_vars VALUES (11,'Innate Poison Protection',1,5);
INSERT INTO altadv_vars VALUES (12,'Innate Disease Protection',1,5);
INSERT INTO altadv_vars VALUES (13,'Innate Run Speed',1,3);
INSERT INTO altadv_vars VALUES (14,'Innate Regeneration',1,3);
INSERT INTO altadv_vars VALUES (15,'Innate Metabolism',1,3);
INSERT INTO altadv_vars VALUES (16,'Innate Lung Capacity',1,3);
INSERT INTO altadv_vars VALUES (17,'First Aid',1,3);
INSERT INTO altadv_vars VALUES (18,'Healing Adept',2,3);
INSERT INTO altadv_vars VALUES (19,'Healing Gift',2,3);
INSERT INTO altadv_vars VALUES (20,'Spell Casting Mastery',2,3);
INSERT INTO altadv_vars VALUES (21,'Spell Casting Reinforcement',2,3);
INSERT INTO altadv_vars VALUES (22,'Mental Clarity',2,3);
INSERT INTO altadv_vars VALUES (23,'Spell Casting Fury',2,3);
INSERT INTO altadv_vars VALUES (24,'Chanelling Focus',2,3);
INSERT INTO altadv_vars VALUES (25,'Spell Casting Subtlety',2,3);
INSERT INTO altadv_vars VALUES (26,'Spell Casting Expertise',2,3);
INSERT INTO altadv_vars VALUES (27,'Spell Casting Deftness',2,3);
INSERT INTO altadv_vars VALUES (28,'Natural Durability',2,3);
INSERT INTO altadv_vars VALUES (29,'Natural Healing',2,3);
INSERT INTO altadv_vars VALUES (30,'Combat Fury',2,3);
INSERT INTO altadv_vars VALUES (31,'Fear Resistance',2,3);
INSERT INTO altadv_vars VALUES (32,'Finishing Blow',2,3);
INSERT INTO altadv_vars VALUES (33,'Combat Stability',2,3);
INSERT INTO altadv_vars VALUES (34,'Combat Agility',2,3);
INSERT INTO altadv_vars VALUES (35,'Mass Group Buff',9,1);
INSERT INTO altadv_vars VALUES (36,'Divine Resurrection',1,1);
INSERT INTO altadv_vars VALUES (37,'Innate Invis To Undead',1,1);
INSERT INTO altadv_vars VALUES (38,'Celestial Regeneration',1,1);
INSERT INTO altadv_vars VALUES (39,'Bestow Divine Aura',1,1);
INSERT INTO altadv_vars VALUES (40,'Turn Undead',1,1);
INSERT INTO altadv_vars VALUES (41,'Purify Soul',1,1);
INSERT INTO altadv_vars VALUES (42,'Quick Evacuation',1,1);
INSERT INTO altadv_vars VALUES (43,'Exodus',1,1);
INSERT INTO altadv_vars VALUES (44,'Quick Damage',1,1);
INSERT INTO altadv_vars VALUES (45,'Enhanced Root',1,1);
INSERT INTO altadv_vars VALUES (46,'Dire Charm',1,1);
INSERT INTO altadv_vars VALUES (47,'Cannibalization',1,1);
INSERT INTO altadv_vars VALUES (48,'Quick Buff',1,3);
INSERT INTO altadv_vars VALUES (49,'Alchemy Mastery',1,3);
INSERT INTO altadv_vars VALUES (50,'Rabid Bear',1,1);
INSERT INTO altadv_vars VALUES (51,'Mana Burn',1,1);
INSERT INTO altadv_vars VALUES (52,'Improved Familiar',1,1);
INSERT INTO altadv_vars VALUES (53,'Nexus Gate',1,1);
INSERT INTO altadv_vars VALUES (54,'Unknown54',0,0);
INSERT INTO altadv_vars VALUES (55,'Permanent Illusion',1,1);
INSERT INTO altadv_vars VALUES (56,'Jewel Craft Mastery',1,1);
INSERT INTO altadv_vars VALUES (57,'Gather Mana',1,1);
INSERT INTO altadv_vars VALUES (58,'Mend Companion',1,1);
INSERT INTO altadv_vars VALUES (59,'Quick Summoning',1,1);
INSERT INTO altadv_vars VALUES (60,'Frenzied Burnout',1,1);
INSERT INTO altadv_vars VALUES (61,'Elemental Form Fire',1,1);
INSERT INTO altadv_vars VALUES (62,'Elemental Form Water',1,1);
INSERT INTO altadv_vars VALUES (63,'Elemental Form Earth',1,1);
INSERT INTO altadv_vars VALUES (64,'Elemental Form Air',1,1);
INSERT INTO altadv_vars VALUES (65,'Improved Reclaim Energy',1,1);
INSERT INTO altadv_vars VALUES (66,'Turn Summoned',1,1);
INSERT INTO altadv_vars VALUES (67,'Elemental Pact',1,1);
INSERT INTO altadv_vars VALUES (68,'Life Burn',1,1);
INSERT INTO altadv_vars VALUES (69,'Dead Mesmerization',1,1);
INSERT INTO altadv_vars VALUES (70,'Fearstorm',1,1);
INSERT INTO altadv_vars VALUES (71,'Flesh To Bone',1,1);
INSERT INTO altadv_vars VALUES (72,'Call To Corpse',1,1);
INSERT INTO altadv_vars VALUES (73,'Divine Stun',9,1);
INSERT INTO altadv_vars VALUES (74,'Improved Lay Of Hands',5,1);
INSERT INTO altadv_vars VALUES (75,'Slay Undead',3,3);
INSERT INTO altadv_vars VALUES (76,'Act Of Valor',3,1);
INSERT INTO altadv_vars VALUES (77,'Holy Steed',5,1);
INSERT INTO altadv_vars VALUES (78,'Fearless',6,1);
INSERT INTO altadv_vars VALUES (79,'2 Hand Bash',6,1);
INSERT INTO altadv_vars VALUES (80,'Innate Camouflage',1,1);
INSERT INTO altadv_vars VALUES (81,'Ambidexterity',1,1);
INSERT INTO altadv_vars VALUES (82,'Archery Mastery',1,1);
INSERT INTO altadv_vars VALUES (83,'Unknown83',0,0);
INSERT INTO altadv_vars VALUES (84,'Endless Quiver',1,1);
INSERT INTO altadv_vars VALUES (85,'Unholy Steed',1,1);
INSERT INTO altadv_vars VALUES (86,'Improved Harm Touch',1,1);
INSERT INTO altadv_vars VALUES (87,'Leech Touch',1,1);
INSERT INTO altadv_vars VALUES (88,'Unknown88',0,0);
INSERT INTO altadv_vars VALUES (89,'Soul Abrasion',1,1);
INSERT INTO altadv_vars VALUES (90,'Instrument Mastery',1,1);
INSERT INTO altadv_vars VALUES (91,'Unknown91',0,0);
INSERT INTO altadv_vars VALUES (92,'Unknown92',0,0);
INSERT INTO altadv_vars VALUES (93,'Unknown93',0,0);
INSERT INTO altadv_vars VALUES (94,'Jam Fest',1,1);
INSERT INTO altadv_vars VALUES (95,'Unknown95',0,0);
INSERT INTO altadv_vars VALUES (96,'Unknown96',0,0);
INSERT INTO altadv_vars VALUES (97,'Critical Mend',1,1);
INSERT INTO altadv_vars VALUES (98,'Purify Body',1,1);
INSERT INTO altadv_vars VALUES (99,'Unknown99',0,0);
INSERT INTO altadv_vars VALUES (100,'Rapid Feign',1,1);
INSERT INTO altadv_vars VALUES (101,'Return Kick',1,1);
INSERT INTO altadv_vars VALUES (102,'Escape',1,1);
INSERT INTO altadv_vars VALUES (103,'Poison Mastery',1,1);
INSERT INTO altadv_vars VALUES (104,'Double Riposte',3,3);
INSERT INTO altadv_vars VALUES (105,'Unknown105',0,0);
INSERT INTO altadv_vars VALUES (106,'Unknown106',0,0);
INSERT INTO altadv_vars VALUES (107,'Purge Poison',1,1);
INSERT INTO altadv_vars VALUES (108,'Flurry',1,1);
INSERT INTO altadv_vars VALUES (109,'Rampage',1,1);
INSERT INTO altadv_vars VALUES (110,'Area Taunt',1,1);
INSERT INTO altadv_vars VALUES (111,'Warcry',1,1);
INSERT INTO altadv_vars VALUES (112,'Bandage Wound',1,1);
INSERT INTO altadv_vars VALUES (113,'Spell Casting Reinforcement Mastery',1,1);
INSERT INTO altadv_vars VALUES (114,'Unknown114',0,0);
INSERT INTO altadv_vars VALUES (115,'Extended Notes',1,1);
INSERT INTO altadv_vars VALUES (116,'Dragon Punch',1,1);
INSERT INTO altadv_vars VALUES (117,'Strong Root',1,1);
INSERT INTO altadv_vars VALUES (118,'Singing Mastery',1,1);
INSERT INTO altadv_vars VALUES (119,'Body And Mind Rejuvenation',5,1);
INSERT INTO altadv_vars VALUES (120,'Physical Enhancement',5,1);
INSERT INTO altadv_vars VALUES (121,'Adv Trap Negotiation',1,1);
INSERT INTO altadv_vars VALUES (122,'Acrobatics',1,1);
INSERT INTO altadv_vars VALUES (123,'Scribble Notes',1,1);
INSERT INTO altadv_vars VALUES (124,'Chaotic Stab',1,1);
INSERT INTO altadv_vars VALUES (125,'Pet Discipline',1,1);
INSERT INTO altadv_vars VALUES (126,'Unknown126',0,0);
INSERT INTO altadv_vars VALUES (127,'Unknown127',0,0);

--
-- Table structure for table 'authentication'
--

CREATE TABLE authentication (
  account_id int(11) NOT NULL default '0',
  char_name varchar(16) NOT NULL default '',
  zone_name varchar(16) NOT NULL default '',
  time timestamp(14) NOT NULL,
  ip int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (account_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'authentication'
--



--
-- Table structure for table 'books'
--

CREATE TABLE books (
  name varchar(15) NOT NULL default '',
  txtfile text NOT NULL,
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'books'
--



--
-- Table structure for table 'character_'
--

CREATE TABLE character_ (
  id int(11) NOT NULL auto_increment,
  account_id int(11) NOT NULL default '0',
  name varchar(16) NOT NULL default '',
  profile blob,
  guild int(11) default '0',
  guildrank tinyint(2) unsigned default '5',
  x float NOT NULL default '0',
  y float NOT NULL default '0',
  z float NOT NULL default '0',
  zonename varchar(30) NOT NULL default '',
  alt_adv blob,
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'character_'
--



--
-- Table structure for table 'doors'
--

CREATE TABLE doors (
  id int(11) NOT NULL auto_increment,
  doorid smallint(4) NOT NULL default '0',
  zone varchar(16) NOT NULL default '',
  name varchar(10) NOT NULL default '',
  pos_y float NOT NULL default '0',
  pos_x float NOT NULL default '0',
  pos_z float NOT NULL default '0',
  heading int(11) NOT NULL default '0',
  opentype smallint(4) NOT NULL default '0',
  guild smallint(4) NOT NULL default '0',
  lockpick smallint(4) NOT NULL default '0',
  keyitem int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'doors'
--


INSERT INTO doors VALUES (1,1,'freportn','DOOR1',-182.171,-66.0379,27.9898,0,5,0,0,0);
INSERT INTO doors VALUES (2,2,'freportn','DOOR1',-182.387,-46.0148,27.9898,0,5,0,0,0);
INSERT INTO doors VALUES (3,3,'freportn','DOOR1',-166.319,-32.0328,27.9898,0,0,0,0,0);
INSERT INTO doors VALUES (4,4,'freportn','DOOR1',-166.72,-59.9862,27.9898,0,0,0,0,0);
INSERT INTO doors VALUES (5,5,'freportn','DOOR1',-183.285,-65.9548,13.9954,17280,0,0,0,0);
INSERT INTO doors VALUES (6,6,'freportn','DOOR1',-166.8,-32.045,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (7,7,'freportn','DOOR2',98.1448,305.781,0.000977,0,0,0,0,0);
INSERT INTO doors VALUES (8,8,'freportn','DOOR2',98.4963,403.777,0.00097,0,0,0,0,0);
INSERT INTO doors VALUES (9,9,'freportn','DOOR4',42.4104,355.85,-12.9938,0,0,0,0,0);
INSERT INTO doors VALUES (10,10,'freportn','DOOR2',106.033,377.587,55.9786,17152,0,0,0,0);
INSERT INTO doors VALUES (11,11,'freportn','DOOR2',115.898,320.851,55.9786,17344,0,0,0,0);
INSERT INTO doors VALUES (12,12,'freportn','DOOR5',169.993,-83.5547,0.000986,17152,0,0,0,0);
INSERT INTO doors VALUES (13,13,'freportn','DOOR5',247.918,-83.6109,0.000986,17152,0,0,0,0);
INSERT INTO doors VALUES (14,14,'freportn','DOOR5',168.09,-133.865,-13.9933,17280,0,0,0,0);
INSERT INTO doors VALUES (15,15,'freportn','DOOR5',199.919,-113.374,-13.9934,17344,0,0,0,0);
INSERT INTO doors VALUES (16,16,'freportn','DOOR5',211.919,-139.799,-13.9935,17152,0,0,0,0);
INSERT INTO doors VALUES (17,17,'freportn','DOOR5',157.967,-83.3265,-13.9935,17152,0,0,0,0);
INSERT INTO doors VALUES (18,18,'freportn','DOOR5',251.908,-83.2847,-13.9935,17152,0,0,0,0);
INSERT INTO doors VALUES (19,19,'freportn','DOOR5',250.588,-133.939,-13.9935,17280,0,0,0,0);
INSERT INTO doors VALUES (20,20,'freportn','DOOR1',-41.644,529.715,0.001012,0,0,0,0,0);
INSERT INTO doors VALUES (21,21,'freportn','DOOR1',-93.9442,474.975,0.001017,17152,0,0,0,0);
INSERT INTO doors VALUES (22,22,'freportn','DOOR1',-15.9132,489.22,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (23,23,'freportn','DOOR1',-210.044,533.854,0.000943,17280,0,0,0,0);
INSERT INTO doors VALUES (24,24,'freportn','DOOR1',-195.758,217.845,0.000987,0,0,0,0,0);
INSERT INTO doors VALUES (25,25,'freportn','DOOR1',-205.86,349.2,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (26,26,'freportn','DOOR1',-42.3337,184.018,0.001013,17280,0,0,0,0);
INSERT INTO doors VALUES (27,27,'freportn','DOOR1',-125.146,221.981,0.001022,17280,0,0,0,0);
INSERT INTO doors VALUES (28,28,'freportn','DOOR1',-68.5868,181.846,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (29,29,'freportn','DOOR1',-154.307,12.0183,0.001089,17280,0,0,0,0);
INSERT INTO doors VALUES (30,30,'freportn','DOOR1',-181.237,-81.9252,0.001007,17280,0,0,0,0);
INSERT INTO doors VALUES (31,31,'freportn','DOOR1',-70.1391,-63.9205,0.000979,17280,0,0,0,0);
INSERT INTO doors VALUES (32,32,'freportn','DOOR1',4.08196,28.2121,0.000986,17152,0,0,0,0);
INSERT INTO doors VALUES (33,33,'freportn','DOOR1',17.9798,111.528,0.000987,17344,0,0,0,0);
INSERT INTO doors VALUES (34,34,'freportn','DOOR1',81.202,77.955,0.001055,0,0,0,0,0);
INSERT INTO doors VALUES (35,35,'freportn','DOOR1',105.894,62.6775,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (36,36,'freportn','DOOR1',73.9541,62.6905,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (37,37,'freportn','DOOR1',45.9635,83.3543,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (38,38,'freportn','DOOR1',29.9542,62.7312,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (39,39,'freportn','DOOR1',36.0828,49.4229,27.9898,17152,0,0,0,0);
INSERT INTO doors VALUES (40,40,'freportn','DOOR1',71.9987,49.5216,27.9898,17152,0,0,0,0);
INSERT INTO doors VALUES (41,41,'freportn','DOOR1',110.037,49.3684,27.9898,17152,0,0,0,0);
INSERT INTO doors VALUES (42,42,'freportn','DOOR1',42.3406,-2.07434,0.000982,0,0,0,0,0);
INSERT INTO doors VALUES (43,43,'freportn','DOOR1',57.3265,-56.0041,0.000992,0,0,0,0,0);
INSERT INTO doors VALUES (44,44,'freportn','DOOR1',77.9588,-112.22,0.001003,17344,0,0,0,0);
INSERT INTO doors VALUES (45,45,'freportn','DOOR1',-56.7593,-147.884,0.000999,17280,0,0,0,0);
INSERT INTO doors VALUES (46,46,'freportn','DOOR1',-87.4528,-149.913,0.000956,17280,0,0,0,0);
INSERT INTO doors VALUES (47,47,'freportn','DOOR1',-70.7205,-181.904,0.001023,17280,0,0,0,0);
INSERT INTO doors VALUES (48,48,'freportn','DOOR1',-85.8844,-223.416,0.001017,17152,0,0,0,0);
INSERT INTO doors VALUES (49,49,'freportn','DOOR1',-13.426,-229.972,0.001026,0,0,0,0,0);
INSERT INTO doors VALUES (50,50,'freportn','DOOR1',-18.0347,-196.202,0.000995,17344,0,0,0,0);
INSERT INTO doors VALUES (51,51,'freportn','DOOR1',-38.6744,-237.936,0.001031,0,0,0,0,0);
INSERT INTO doors VALUES (52,52,'freportn','DOOR1',-101.957,0.45072,0.000984,17152,0,0,0,0);
INSERT INTO doors VALUES (53,53,'freportn','DOOR1',-151.879,355.307,0.001018,17152,0,0,0,0);
INSERT INTO doors VALUES (54,54,'freportn','DOOR1',-209.557,361.779,0.001107,0,0,0,0,0);
INSERT INTO doors VALUES (55,55,'freportn','DOOR1',-175.864,259.432,0.00095,17152,0,0,0,0);
INSERT INTO doors VALUES (56,56,'freportn','DOOR1',-195.609,287.823,0.000968,0,0,0,0,0);
INSERT INTO doors VALUES (57,57,'freportn','DOOR1',-177.14,465.841,13.9955,17280,0,0,0,0);
INSERT INTO doors VALUES (58,58,'freportn','DOOR1',-210.542,497.788,0.000979,0,0,0,0,0);
INSERT INTO doors VALUES (59,59,'freportn','DOOR1',-151.849,547.281,0.001019,17152,0,0,0,0);
INSERT INTO doors VALUES (60,60,'freportn','DOOR1',-112.018,569.865,0.001019,17280,0,0,0,0);
INSERT INTO doors VALUES (61,61,'freportn','DOOR1',-95.8797,531.954,0.001017,17152,0,0,0,0);
INSERT INTO doors VALUES (62,62,'freportn','DOOR5',329.852,349.196,-13.9935,17344,0,0,0,0);
INSERT INTO doors VALUES (63,63,'freportn','DOOR1',265.744,-139.204,13.8823,17215,54,0,0,0);
INSERT INTO doors VALUES (64,64,'freportn','DOOR1',272.951,-132.372,14.001,17213,54,0,0,0);
INSERT INTO doors VALUES (65,65,'freportn','DOOR1',265.725,-84.3768,13.8961,17344,54,0,0,0);
INSERT INTO doors VALUES (66,66,'freportn','DOOR1',255.652,-84.3683,13.8274,17343,54,0,0,0);
INSERT INTO doors VALUES (67,67,'freportn','DOOR1',247.821,-84.478,13.8507,17343,54,0,0,0);
INSERT INTO doors VALUES (68,68,'freportn','DOOR1',237.906,-51.7604,14.001,17280,54,0,0,0);
INSERT INTO doors VALUES (69,69,'freportn','DOOR1',237.829,-61.1613,14.001,17280,54,0,0,0);
INSERT INTO doors VALUES (70,70,'freportn','DOOR1',181.967,-41.9651,14.001,0,54,0,0,0);
INSERT INTO doors VALUES (71,71,'freportn','DOOR1',181.978,-51.9214,14.001,16025,54,0,0,0);
INSERT INTO doors VALUES (72,72,'freportn','DOOR1',163.825,-84.0495,13.9975,17344,54,0,0,0);
INSERT INTO doors VALUES (73,73,'freportn','DOOR1',173.74,-84.0723,13.9953,17343,54,0,0,0);
INSERT INTO doors VALUES (74,74,'freportn','DOOR1',167.664,-84.7083,11.6396,17152,54,0,0,0);
INSERT INTO doors VALUES (75,75,'freportn','DOOR1',167.865,-139.921,13.9439,17280,54,0,0,0);
INSERT INTO doors VALUES (76,76,'freportn','DOOR1',167.943,-130,14.001,17280,54,0,0,0);
INSERT INTO doors VALUES (77,77,'freportn','DOOR1',216.805,-202.5,14.001,17215,54,0,0,0);
INSERT INTO doors VALUES (78,78,'freportn','DOOR1',126.775,117.875,28.002,0,54,0,0,0);
INSERT INTO doors VALUES (79,79,'freportn','DOOR1',127.469,107.779,28.2262,16163,54,0,0,0);
INSERT INTO doors VALUES (80,80,'freportn','DOOR1',126.353,97.5679,28.0473,16405,54,0,0,0);
INSERT INTO doors VALUES (81,81,'freportn','DOOR1',126.115,77.5354,28.002,17281,54,0,0,0);
INSERT INTO doors VALUES (82,1,'freportw','DOOR1',151.952,-699.936,-13.9934,17344,0,0,0,0);
INSERT INTO doors VALUES (83,2,'freportw','DOOR1',-0.354012,-1047.55,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (84,3,'freportw','DOOR1',-56.3557,-1057.56,-27.9878,17274,0,0,0,0);
INSERT INTO doors VALUES (85,4,'freportw','DOOR1',-221.843,-363.531,-27.9878,17152,0,0,0,0);
INSERT INTO doors VALUES (86,5,'freportw','DOOR1',-41.513,-114.004,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (87,6,'freportw','DOOR1',-126.008,-98.4896,-27.9877,17344,0,0,0,0);
INSERT INTO doors VALUES (88,7,'freportw','DOOR1',-138.589,-411.869,-13.9934,0,0,0,0,0);
INSERT INTO doors VALUES (89,8,'freportw','DOOR1',-138.493,-443.915,-13.9934,0,0,0,0,0);
INSERT INTO doors VALUES (90,9,'freportw','DOOR1',-138.442,-477.847,-13.9934,0,0,0,0,0);
INSERT INTO doors VALUES (91,10,'freportw','DOOR1',-193.998,-505.145,-13.9935,17344,0,0,0,0);
INSERT INTO doors VALUES (92,11,'freportw','DOOR1',-166.015,-505.195,-13.9935,17344,0,0,0,0);
INSERT INTO doors VALUES (93,12,'freportw','DOOR1',-148.663,-533.79,-27.9879,0,0,0,0,0);
INSERT INTO doors VALUES (94,13,'freportw','DOOR1',-183.937,-490.066,-27.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (95,14,'freportw','DOOR1',-2.55759,-161.941,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (96,15,'freportw','DOOR1',-42.6163,-193.935,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (97,16,'freportw','DOOR1',-83.9851,-157.384,-27.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (98,17,'freportw','DOOR1',-77.9314,-142.42,-27.9878,17152,0,0,0,0);
INSERT INTO doors VALUES (99,18,'freportw','DOOR1',-109.932,-142.435,-27.9878,17152,0,0,0,0);
INSERT INTO doors VALUES (100,19,'freportw','DOOR1',-59.9528,-142.455,-13.9934,17152,0,0,0,0);
INSERT INTO doors VALUES (101,20,'freportw','DOOR1',-115.859,-142.465,-13.9934,17152,0,0,0,0);
INSERT INTO doors VALUES (102,21,'freportw','DOOR1',-125.974,-98.4083,-13.9935,17344,0,0,0,0);
INSERT INTO doors VALUES (103,22,'freportw','HHCELL',-264.492,-218.988,-41.9823,0,0,0,0,0);
INSERT INTO doors VALUES (104,23,'freportw','HHCELL',-187.856,-207.883,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (105,24,'freportw','HHCELL',-221.966,-253.856,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (106,25,'freportw','HHCELL',-197.998,-254.017,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (107,26,'freportw','HHCELL',-173.962,-253.837,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (108,27,'freportw','HHCELL',-241.832,-139.118,-27.9879,17152,0,0,0,0);
INSERT INTO doors VALUES (109,28,'freportw','DOOR1',-336.214,-46.8918,-27.9879,17280,0,0,0,0);
INSERT INTO doors VALUES (110,29,'freportw','HHCELL',-265.868,-49.9442,-27.9877,17152,0,0,0,0);
INSERT INTO doors VALUES (111,30,'freportw','DOOR1',-268.288,-24.0881,-27.9879,0,0,0,0,0);
INSERT INTO doors VALUES (112,31,'freportw','DOOR1',-303.849,-68.3902,-27.9879,17280,0,0,0,0);
INSERT INTO doors VALUES (113,32,'freportw','DOOR1',-231.935,-0.650448,-27.9879,0,0,0,0,0);
INSERT INTO doors VALUES (114,33,'freportw','DOOR1',-201.971,-812.168,-27.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (115,34,'freportw','DOOR1',126.492,-887.686,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (116,35,'freportw','DOOR1',119.914,-937.931,-27.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (117,36,'freportw','DOOR1',-206.01,-209.631,-41.9822,17344,5,0,0,0);
INSERT INTO doors VALUES (118,37,'freportw','DOOR1',-50.0047,-143.265,0.001,17343,5,0,0,0);
INSERT INTO doors VALUES (119,38,'freportw','DOOR1',-115.938,-142.511,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (120,39,'freportw','DOOR1',-303.647,13.9997,0.001,17152,54,0,0,0);
INSERT INTO doors VALUES (121,40,'freportw','DOOR1',-303.641,13.1009,0.001,17344,54,0,0,0);
INSERT INTO doors VALUES (122,41,'freportw','DOOR1',-313.613,12.9613,0.001,17343,54,0,0,0);
INSERT INTO doors VALUES (123,42,'freportw','DOOR1',-323.444,13.1588,0.001,17344,54,0,0,0);
INSERT INTO doors VALUES (124,43,'freportw','DOOR1',-227.769,-320.654,-13.9342,17280,54,0,0,0);
INSERT INTO doors VALUES (125,44,'freportw','DOOR1',-227.97,-310.632,-13.9342,0,54,0,0,0);
INSERT INTO doors VALUES (126,45,'freportw','DOOR1',-225.839,-361.683,-13.9057,17280,54,0,0,0);
INSERT INTO doors VALUES (127,46,'freportw','DOOR1',-196.433,-310.125,-14.4893,0,54,0,0,0);
INSERT INTO doors VALUES (128,47,'freportw','DOOR1',-196.146,-319.682,-14.4893,0,54,0,0,0);
INSERT INTO doors VALUES (129,48,'freportw','DOOR1',-196.183,-319.959,-13.4979,17344,54,0,0,0);
INSERT INTO doors VALUES (130,49,'freportw','DOOR1',-205.948,-329.875,-14.4893,17152,54,0,0,0);
INSERT INTO doors VALUES (131,50,'freportw','DOOR1',-176.272,-319.875,-14.4057,17280,54,0,0,0);
INSERT INTO doors VALUES (132,51,'freportw','DOOR1',-166.348,-319.742,-14.3245,17280,54,0,0,0);
INSERT INTO doors VALUES (133,52,'freportw','DOOR1',-176.119,-329.567,-14.4408,17280,54,0,0,0);
INSERT INTO doors VALUES (134,53,'freportw','DOOR1',-158.438,-327.55,-14.3034,17280,54,0,0,0);
INSERT INTO doors VALUES (135,54,'freportw','DOOR1',-186.192,-339.473,-14.4354,17152,54,0,0,0);
INSERT INTO doors VALUES (136,55,'freportw','DOOR1',-186.178,-339.548,-14.4411,17280,54,0,0,0);
INSERT INTO doors VALUES (137,56,'freportw','DOOR1',-195.99,-339.628,-14.5148,17280,54,0,0,0);
INSERT INTO doors VALUES (138,57,'freportw','DOOR1',-196.009,-339.347,-14.7467,17344,54,0,0,0);
INSERT INTO doors VALUES (139,58,'freportw','DOOR1',-185.952,-339.415,-14.7582,17344,54,0,0,0);
INSERT INTO doors VALUES (140,59,'freportw','DOOR1',-176.174,-339.253,-14.4411,17344,54,0,0,0);
INSERT INTO doors VALUES (141,60,'freportw','DOOR1',-206.152,-358.835,-14.4564,17152,54,0,0,0);
INSERT INTO doors VALUES (142,61,'freportw','DOOR1',-186.165,-349.078,-14.5108,17344,54,0,0,0);
INSERT INTO doors VALUES (143,62,'freportw','DOOR1',-176.598,-349.16,-13.4467,17280,54,0,0,0);
INSERT INTO doors VALUES (144,63,'freportw','DOOR1',-176.513,-348.666,-14.6967,17345,54,0,0,0);
INSERT INTO doors VALUES (145,64,'freportw','DOOR1',-176.753,-348.937,-14.3321,0,54,0,0,0);
INSERT INTO doors VALUES (146,65,'freportw','DOOR1',-176.373,-339.564,-14.6911,17150,54,0,0,0);
INSERT INTO doors VALUES (147,66,'freportw','DOOR1',-166.686,-329.451,-14.6967,16345,54,0,0,0);
INSERT INTO doors VALUES (148,67,'freportw','DOOR1',-157.679,-348.762,-13.4699,16542,54,0,0,0);
INSERT INTO doors VALUES (149,68,'freportw','DOOR1',-167.217,-339.142,-13.4391,17152,54,0,0,0);
INSERT INTO doors VALUES (150,69,'freportw','DOOR1',-12.4912,-433.614,-18.7444,17349,54,0,0,0);
INSERT INTO doors VALUES (151,70,'freportw','DOOR1',127.188,-894.142,-15.7829,17280,54,0,0,0);
INSERT INTO doors VALUES (152,1,'freporte','DOOR1',-4.30211,-1044.93,-55.9678,17345,54,0,0,0);
INSERT INTO doors VALUES (153,2,'freporte','DOOR1',-14.1626,-1044.98,-55.9678,17343,54,0,0,0);
INSERT INTO doors VALUES (154,3,'freporte','DOOR1',72.0395,-349.446,-55.9766,17152,0,0,0,0);
INSERT INTO doors VALUES (155,4,'freporte','DOOR5',85.9564,-700.058,-55.9766,17344,0,0,0,0);
INSERT INTO doors VALUES (156,5,'freporte','DOOR5',25.9773,-700.076,-55.9766,17344,0,0,0,0);
INSERT INTO doors VALUES (157,6,'freporte','DOOR1',-16.0232,-658.145,-54.977,17344,0,0,0,0);
INSERT INTO doors VALUES (158,7,'freporte','DOOR1',-91.8752,-681.989,-55.9766,17152,0,0,0,0);
INSERT INTO doors VALUES (159,8,'freporte','DOOR1',-71.6016,-737.645,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (160,9,'freporte','DOOR1',98.3756,-537.809,-55.9766,0,5,0,0,0);
INSERT INTO doors VALUES (161,10,'freporte','DOOR1',62.5631,-583.685,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (162,11,'freporte','DOOR1',161.85,-420.332,-55.9767,17344,5,0,0,0);
INSERT INTO doors VALUES (163,12,'freporte','DOOR1',89.5158,-367.872,-55.9766,0,5,0,0,0);
INSERT INTO doors VALUES (164,13,'freporte','DOOR1',95.4681,-461.848,-27.9878,0,5,0,0,0);
INSERT INTO doors VALUES (165,14,'freporte','DOOR1',94.7432,-451.732,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (166,15,'freporte','DOOR1',94.7548,-421.754,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (167,16,'freporte','DOOR1',-153.426,-437.87,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (168,17,'freporte','DOOR1',-14.5079,-497.715,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (169,18,'freporte','DOOR1',-84.0134,-476.259,-83.9654,17344,0,0,0,0);
INSERT INTO doors VALUES (170,19,'freporte','DOOR1',-56.5503,-441.852,-41.9822,0,0,0,0,0);
INSERT INTO doors VALUES (171,20,'freporte','DOOR1',-56.7165,-475.884,-41.9822,0,0,0,0,0);
INSERT INTO doors VALUES (172,21,'freporte','DOOR1',167.438,-273.843,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (173,22,'freporte','DOOR1',167.446,-319.84,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (174,23,'freporte','DOOR1',84.198,-257.917,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (175,24,'freporte','DOOR1',119.998,-312.443,-55.9767,17152,0,0,0,0);
INSERT INTO doors VALUES (176,25,'freporte','DOOR1',132.604,-273.841,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (177,26,'freporte','DOOR1',34.0556,-153.282,-55.9766,17152,5,0,0,0);
INSERT INTO doors VALUES (178,27,'freporte','DOOR1',32.028,-230.69,-55.9766,17152,0,0,0,0);
INSERT INTO doors VALUES (179,28,'freporte','DOOR1',-55.7788,-365.901,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (180,29,'freporte','DOOR1',-55.5146,-249.909,-41.9822,0,0,0,0,0);
INSERT INTO doors VALUES (181,30,'freporte','DOOR1',-45.9702,-264.559,-83.9654,17152,0,0,0,0);
INSERT INTO doors VALUES (182,31,'freporte','DOOR1',-40.0309,-224.374,-55.9766,17344,0,0,0,0);
INSERT INTO doors VALUES (183,32,'freporte','DOOR5',-72.0613,-224.16,-55.9766,17344,0,0,0,0);
INSERT INTO doors VALUES (184,33,'freporte','DOOR1',-62.0166,-265.562,-83.9654,17344,0,0,0,0);
INSERT INTO doors VALUES (185,34,'freporte','DOOR1',-169.858,-146.599,-69.971,17152,0,0,0,0);
INSERT INTO doors VALUES (186,35,'freporte','DOOR1',-179.374,-125.941,-83.9655,17280,0,0,0,0);
INSERT INTO doors VALUES (187,36,'freporte','DOOR1',-169.911,-181.612,-83.9654,17152,0,0,0,0);
INSERT INTO doors VALUES (188,37,'freporte','DOOR1',-221.919,-126.227,-83.9654,17344,0,0,0,0);
INSERT INTO doors VALUES (189,38,'freporte','DOOR1',-303.791,-210.457,-83.9653,17152,0,0,0,0);
INSERT INTO doors VALUES (190,39,'freporte','DOOR5',-252.283,-245.873,-83.9654,17280,0,0,0,0);
INSERT INTO doors VALUES (191,40,'freporte','DOOR1',111.491,-487.751,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (192,41,'freporte','DOOR1',-42.6159,-665.789,-41.9822,0,0,0,0,0);
INSERT INTO doors VALUES (193,42,'freporte','DOOR1',-57.4081,-663.725,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (194,43,'freporte','DOOR1',-57.381,-719.664,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (195,44,'freporte','DOOR1',-229.999,-285.169,-111.954,17344,0,0,0,0);
INSERT INTO doors VALUES (196,45,'freporte','DOOR1',-212.325,-251.995,-111.954,0,0,0,0,0);
INSERT INTO doors VALUES (197,46,'freporte','DOOR1',-91.8749,-202.634,-97.9598,17152,0,0,0,0);
INSERT INTO doors VALUES (198,47,'freporte','DOOR1',-53.9603,-212.476,-97.9598,17152,0,0,0,0);
INSERT INTO doors VALUES (199,48,'freporte','DOOR1',-56.4378,-221.912,-97.9598,0,0,0,0,0);
INSERT INTO doors VALUES (200,49,'freporte','DOOR1',-91.9197,-246.446,-97.9598,17152,0,0,0,0);
INSERT INTO doors VALUES (201,50,'freporte','DOOR1',72.5429,-851.601,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (202,51,'freporte','DOOR1',105.955,-910.281,-54.977,17344,0,0,0,0);
INSERT INTO doors VALUES (203,52,'freporte','DOOR1',41.4739,-817.653,-54.977,17280,0,0,0,0);
INSERT INTO doors VALUES (204,53,'freporte','DOOR1',-187.953,-855.025,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (205,54,'freporte','DOOR1',-197.824,-840.376,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (206,55,'freporte','DOOR1',-225.838,-840.337,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (207,56,'freporte','DOOR1',-253.867,-840.047,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (208,57,'freporte','DOOR1',-263.858,-850.398,-55.9766,17152,0,0,0,0);
INSERT INTO doors VALUES (209,58,'freporte','DOOR1',-181.327,-803.703,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (210,59,'freporte','DOOR1',-187.985,-910.348,-67.9718,17344,0,0,0,0);
INSERT INTO doors VALUES (211,60,'freporte','DOOR1',-261.812,-893.966,-95.9606,17152,0,0,0,0);
INSERT INTO doors VALUES (212,61,'freporte','DOOR1',-189.957,-876.867,-97.9598,17344,0,0,0,0);
INSERT INTO doors VALUES (213,62,'freporte','DOOR1',-212.708,-851.725,-97.9598,0,0,0,0,0);
INSERT INTO doors VALUES (214,63,'freporte','DOOR1',-311.909,-851.33,-110.955,17344,0,0,0,0);
INSERT INTO doors VALUES (215,64,'freporte','DOOR1',-278.875,-616,-30.0329,17278,54,0,0,0);
INSERT INTO doors VALUES (216,65,'freporte','DOOR1',-140.105,-709.739,-27.9941,17280,54,0,0,0);
INSERT INTO doors VALUES (217,66,'freporte','DOOR1',-140.172,-719.592,-28.1045,17279,54,0,0,0);
INSERT INTO doors VALUES (218,67,'freporte','DOOR1',-140.201,-729.437,-28.1524,17279,54,0,0,0);
INSERT INTO doors VALUES (219,68,'freporte','DOOR1',-140.168,-739.25,-28.1313,17279,54,0,0,0);
INSERT INTO doors VALUES (220,69,'freporte','DOOR1',-278.875,-764.876,-30.5329,17279,54,0,0,0);
INSERT INTO doors VALUES (221,70,'freporte','DOOR1',-139.945,-671.56,-28.035,17279,54,0,0,0);
INSERT INTO doors VALUES (222,71,'freporte','DOOR1',-140.068,-661.761,-28.0081,17280,54,0,0,0);
INSERT INTO doors VALUES (223,72,'freporte','DOOR1',-140.043,-651.935,-28.069,17280,54,0,0,0);
INSERT INTO doors VALUES (224,73,'freporte','DOOR1',-139.98,-642.086,-28.1853,17280,54,0,0,0);
INSERT INTO doors VALUES (225,74,'freporte','DOOR1',42.0339,-38.0007,-27.999,17280,54,0,0,0);
INSERT INTO doors VALUES (226,75,'freporte','DOOR1',41.8625,-48.0194,-27.999,17280,54,0,0,0);
INSERT INTO doors VALUES (227,76,'freporte','DOOR1',-328.643,-342.841,-27.9678,17024,54,0,0,0);
INSERT INTO doors VALUES (228,77,'freporte','DOOR1',-335.609,-335.772,-27.9678,17024,54,0,0,0);
INSERT INTO doors VALUES (229,78,'freporte','DOOR1',-334.946,-325.902,-27.9678,17407,54,0,0,0);
INSERT INTO doors VALUES (230,79,'freporte','DOOR1',-321.765,-349.444,-27.9678,17151,54,0,0,0);
INSERT INTO doors VALUES (231,1,'neriakb','DOOR1',-74.9655,-1075.65,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (232,2,'neriakb','DOOR1',55.3845,-935.575,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (233,3,'neriakb','DOOR1',81.8922,-812.262,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (234,4,'neriakb','DOOR1',70.4616,-960.565,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (235,5,'neriakb','DOOR1',71.5138,-900.717,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (236,6,'neriakb','DOOR2',156.56,-881.675,-41.9822,0,2,0,0,0);
INSERT INTO doors VALUES (237,7,'neriakb','DOOR2',141.496,-923.581,-41.9822,17280,2,0,0,0);
INSERT INTO doors VALUES (238,8,'neriakb','DOOR2',156.512,-913.725,-41.9822,0,2,0,0,0);
INSERT INTO doors VALUES (239,9,'neriakb','HHCELL',141.991,-985.701,-27.9878,17152,65,0,0,0);
INSERT INTO doors VALUES (240,10,'neriakb','DOOR1',-126.315,-1012.57,-27.9878,17280,0,0,0,0);
INSERT INTO doors VALUES (241,11,'neriakb','HHCELL',-44.0865,-637.729,-27.9878,17344,65,0,0,0);
INSERT INTO doors VALUES (242,12,'neriakb','DOOR2',2.97065,-1121.6,-55.9766,0,15,0,0,0);
INSERT INTO doors VALUES (243,13,'neriakb','HHCELL',11.9397,-897.74,-41.9822,0,65,0,0,0);
INSERT INTO doors VALUES (244,14,'neriakb','HHCELL',-107.995,-897.646,-41.9822,0,65,0,0,0);
INSERT INTO doors VALUES (245,15,'neriakb','DOOR1',-169.835,-1017.54,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (246,16,'neriakb','DOOR1',-57.8875,-993.285,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (247,17,'neriakb','DOOR1',-39.9409,-996.328,-27.9878,17152,0,0,0,0);
INSERT INTO doors VALUES (248,18,'neriakb','DOOR1',-57.8769,-996.401,-27.9878,17152,0,0,0,0);
INSERT INTO doors VALUES (249,19,'neriakb','DOOR1',-39.9012,-993.185,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (250,20,'neriakb','DOOR1',-55.1735,-989.509,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (251,21,'neriakb','DOOR1',-40.8361,-993.623,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (252,22,'neriakb','DOOR1',-40.7798,-1013.63,-55.9766,0,0,0,0,0);
INSERT INTO doors VALUES (253,23,'neriakb','DOOR1',-55.1464,-1007.54,-55.9766,17280,0,0,0,0);
INSERT INTO doors VALUES (254,24,'neriakb','DOOR1',-22.9973,-1037.06,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (255,25,'neriakb','DOOR1',42.8284,-956.539,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (256,26,'neriakb','DOOR1',40.0037,-872.562,-41.9822,17280,0,0,0,0);
INSERT INTO doors VALUES (257,27,'neriakb','DOOR1',30.0121,-893.625,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (258,28,'neriakb','DOOR1',9.01642,-1075.65,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (259,29,'neriakb','DOOR1',15.8665,-995.652,-41.9822,0,0,0,0,0);
INSERT INTO doors VALUES (260,30,'neriakb','DOOR1',-113.978,-1065.55,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (261,31,'neriakb','DOOR1',-142.024,-1100.15,-40.9826,17344,0,0,0,0);
INSERT INTO doors VALUES (262,32,'neriakb','DOOR1',158.849,-798.458,-41.9822,17344,0,0,0,0);
INSERT INTO doors VALUES (263,33,'neriakb','DOOR1',148.959,-825.213,-41.9822,17152,0,0,0,0);
INSERT INTO doors VALUES (264,34,'neriakb','DOOR2',40.0126,-856.65,-55.9766,17280,15,0,0,0);
INSERT INTO doors VALUES (265,35,'neriakb','DOOR2',40.1726,-884.66,-55.9766,17280,17,0,0,0);
INSERT INTO doors VALUES (266,36,'neriakb','DOOR2',56.9745,-884.63,-55.9766,17280,17,0,0,0);
INSERT INTO doors VALUES (267,37,'neriakb','DOOR2',23.0498,-907.724,-55.9766,17152,17,0,0,0);
INSERT INTO doors VALUES (268,38,'neriakb','DOOR2',16.0338,-920.701,-55.9766,0,17,0,0,0);
INSERT INTO doors VALUES (269,39,'neriakb','DOOR2',94.9796,-939.574,-27.9878,17344,15,0,0,0);
INSERT INTO doors VALUES (270,40,'neriakb','DOOR2',94.8972,-922.748,-27.9878,17344,15,0,0,0);
INSERT INTO doors VALUES (271,41,'neriakb','DOOR2',153.848,-938.852,-41.9822,17344,17,0,0,0);
INSERT INTO doors VALUES (272,42,'neriakb','HHCELL',-195.005,-995.68,-41.9822,0,65,0,0,0);
INSERT INTO doors VALUES (273,43,'neriakb','HHCELL',-35.177,-861.564,-40.9826,17344,65,0,0,0);
INSERT INTO doors VALUES (274,44,'neriakb','HHCELL',-43.577,-861.564,-40.9826,17344,65,0,0,0);
INSERT INTO doors VALUES (275,45,'neriakb','HHCELL',-51.927,-861.564,-40.9826,17344,65,0,0,0);
INSERT INTO doors VALUES (276,46,'neriakb','DOOR2',40.4236,-933.615,-55.9766,17280,2,0,0,0);
INSERT INTO doors VALUES (277,1,'nektulos','CAMPFIRE',-468.191,758.839,-8.748,16690,58,0,0,0);
INSERT INTO doors VALUES (278,2,'nektulos','DEDPINE1',-1122,425.835,-8.63128,17360,58,0,0,0);
INSERT INTO doors VALUES (279,3,'nektulos','MONU6',-1061.95,484.404,-8.66522,17270,58,0,0,0);
INSERT INTO doors VALUES (280,4,'nektulos','DEDPINE1',-1057.67,519.105,-8.43662,17246,58,0,0,0);
INSERT INTO doors VALUES (281,5,'nektulos','DEDPINE',-1067.39,446.659,-8.748,17264,58,0,0,0);
INSERT INTO doors VALUES (282,6,'nektulos','MONU1',1660.68,1282.34,-1.10991,17272,58,0,0,0);
INSERT INTO doors VALUES (283,7,'nektulos','MONU1',2121.57,808.209,-9.10295,17351,58,0,0,0);
INSERT INTO doors VALUES (284,8,'nektulos','MONU1',2540.7,689.301,-40.578,17341,58,0,0,0);
INSERT INTO doors VALUES (285,9,'nektulos','MONU1',1965.25,1049.33,-37.1424,17297,58,0,0,0);
INSERT INTO doors VALUES (286,10,'nektulos','MONU6',2240.04,1228.6,14.7319,17128,58,0,0,0);
INSERT INTO doors VALUES (287,11,'nektulos','CAMPFIRE',2232.73,1189.35,-31.4805,17350,58,0,0,0);
INSERT INTO doors VALUES (288,12,'nektulos','ORCTENT',-517.991,800.776,-10.636,17377,58,0,0,0);
INSERT INTO doors VALUES (289,13,'nektulos','ORCTENT',-494.24,705.553,-8.748,17060,58,0,0,0);
INSERT INTO doors VALUES (290,14,'nektulos','ORCFLAG2',-461.274,810.244,-9.13873,16074,58,0,0,0);
INSERT INTO doors VALUES (291,15,'nektulos','ORCTENT',-186.524,-580.849,-8.998,17124,58,0,0,0);
INSERT INTO doors VALUES (292,16,'nektulos','ORCTENT',-115.06,-521.394,-8.43915,17221,58,0,0,0);
INSERT INTO doors VALUES (293,17,'nektulos','ORCTENT',-66.582,-449.364,-8.26342,17269,58,0,0,0);
INSERT INTO doors VALUES (294,18,'nektulos','ORCFLAG2',-143.138,-535.094,-8.71255,17214,58,0,0,0);
INSERT INTO doors VALUES (295,19,'nektulos','ORCFLAG2',-78.8839,-410.07,-8.748,17271,58,0,0,0);
INSERT INTO doors VALUES (296,20,'nektulos','ORCFLAG2',-221.182,-557.259,-8.748,17103,58,0,0,0);
INSERT INTO doors VALUES (297,21,'nektulos','CAMPFIRE',-174.635,-465.227,-8.748,17209,58,0,0,0);
INSERT INTO doors VALUES (319,1,'neriaka','NERDOOR',-455.821,-435.251,1.0006,17344,0,0,0,0);
INSERT INTO doors VALUES (320,2,'neriaka','NERDOOR',-433.601,-276.887,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (321,3,'neriaka','DOOR5',137.929,-224.534,0.072886,17344,0,0,0,0);
INSERT INTO doors VALUES (322,4,'neriaka','DOOR5',163.91,-124.149,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (323,5,'neriaka','DOOR5',10.9018,-101.975,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (324,6,'neriaka','DOOR5',-13.4438,-111.915,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (325,7,'neriaka','DOOR2',137.894,-153.269,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (326,8,'neriaka','DOOR2',126.107,-249.852,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (327,9,'neriaka','DOOR5',82.9538,-97.2922,13.9954,17346,0,0,0,0);
INSERT INTO doors VALUES (328,10,'neriaka','DOOR5',72.9749,-84.3736,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (329,11,'neriaka','DOOR5',98.976,-84.6201,13.9954,17150,0,0,0,0);
INSERT INTO doors VALUES (330,12,'neriaka','DOOR5',112.025,-121.876,13.9954,17283,0,0,0,0);
INSERT INTO doors VALUES (331,13,'neriaka','DOOR5',98.8945,-111.989,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (332,14,'neriaka','DOOR5',125.688,-121.947,13.9954,17280,0,0,0,0);
INSERT INTO doors VALUES (333,15,'neriaka','DOOR5',111.437,-121.917,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (334,16,'neriaka','DOOR5',98.9164,-112.036,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (335,17,'neriaka','DOOR5',82.9207,-97.1098,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (336,18,'neriaka','DOOR5',73.0329,-84.7096,0.001,17156,0,0,0,0);
INSERT INTO doors VALUES (337,19,'neriaka','DOOR5',98.998,-84.4111,0.001,17153,0,0,0,0);
INSERT INTO doors VALUES (338,20,'neriaka','DOOR5',-0.047684,-83.5597,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (339,21,'neriaka','DOOR5',-30.0444,-55.1377,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (340,22,'neriaka','DOOR5',39.9545,-55.6696,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (341,23,'neriaka','DOOR5',127.967,-265.806,0.001,17160,0,0,0,0);
INSERT INTO doors VALUES (342,24,'neriaka','NERDOOR',-245.971,-359.611,2.9998,17344,0,0,0,0);
INSERT INTO doors VALUES (343,25,'neriaka','NERDOOR',-230.944,-265.223,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (344,26,'neriaka','NERDOOR',-269.329,-369.878,2.9998,16240,0,0,0,0);
INSERT INTO doors VALUES (345,27,'neriaka','NERDOOR',-216.614,-395.867,2.9998,16552,0,0,0,0);
INSERT INTO doors VALUES (346,28,'neriaka','NERDOOR',-369.849,-360.155,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (347,29,'neriaka','NERDOOR',-412.425,-306.932,0.001,16500,0,0,0,0);
INSERT INTO doors VALUES (348,30,'neriaka','NERDOOR',-433.471,-320.84,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (349,31,'neriaka','NERDOOR',-374.352,-199.953,17.9938,16467,0,0,0,0);
INSERT INTO doors VALUES (350,32,'neriaka','NERDOOR',-369.805,-178.38,0.001,17150,0,0,0,0);
INSERT INTO doors VALUES (351,33,'neriaka','NERDOOR',-357.786,-144.939,0.001,17153,0,0,0,0);
INSERT INTO doors VALUES (352,34,'neriaka','NERDOOR',-306.322,-181.988,0.001,16286,0,0,0,0);
INSERT INTO doors VALUES (353,35,'neriaka','NERDOOR',-303.867,-430.445,14.995,17146,0,0,0,0);
INSERT INTO doors VALUES (354,36,'neriaka','NERDOOR',-340.932,-424.89,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (355,37,'neriaka','NERDOOR',-432.647,-222.926,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (356,38,'neriaka','NERDOOR',-411.992,-222.982,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (357,39,'neriaka','NERDOOR',-412.353,-276.829,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (358,40,'neriaka','NERDOOR',-375.1,-325.913,17.9938,0,0,0,0,0);
INSERT INTO doors VALUES (359,41,'neriaka','DOOR5',123.946,-251.226,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (360,42,'neriaka','DOOR5',123.875,-239.33,13.9954,17344,5,0,0,0);
INSERT INTO doors VALUES (361,43,'neriaka','DOOR2',253.985,-80.6577,13.9954,17152,17,0,0,0);
INSERT INTO doors VALUES (362,44,'neriaka','DOOR2',278.877,-101.422,13.9954,17344,17,0,0,0);
INSERT INTO doors VALUES (363,45,'neriaka','NERDOOR',-345.865,-449.589,13.9954,17344,1,0,0,0);
INSERT INTO doors VALUES (364,46,'neriaka','NERDOOR',-376.397,-417.912,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (411,1,'paineel','PAROCK103',630.308,462.063,-101.875,17284,2,0,0,0);
INSERT INTO doors VALUES (412,2,'paineel','PAROCK103',629.972,454.962,-27.9791,17190,2,0,0,0);
INSERT INTO doors VALUES (413,3,'paineel','PALIFT101',628.482,499.635,76.7288,17152,54,0,0,0);
INSERT INTO doors VALUES (414,4,'paineel','PALIFT101',599.871,493.881,84.9448,17216,54,0,0,0);
INSERT INTO doors VALUES (415,5,'paineel','PALIFT101',649.176,504.197,84.7288,17024,54,0,0,0);
INSERT INTO doors VALUES (416,6,'paineel','PADOOR103',880.689,587.929,-125.936,17344,66,0,0,0);
INSERT INTO doors VALUES (417,7,'paineel','PADOOR102',718.282,903.556,-71.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (418,8,'paineel','PADOOR101',718.282,893.706,-71.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (419,9,'paineel','PADOOR102',718.265,785.685,-71.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (420,10,'paineel','PADOOR101',718.265,775.735,-71.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (421,11,'paineel','PADOOR102',785.726,810.188,-83.9173,17344,7,0,0,0);
INSERT INTO doors VALUES (422,12,'paineel','PADOOR101',795.676,810.194,-83.9175,17344,2,0,0,0);
INSERT INTO doors VALUES (423,13,'paineel','PADOOR102',795.618,869.09,-83.9072,17152,7,0,0,0);
INSERT INTO doors VALUES (424,14,'paineel','PADOOR101',785.719,869.09,-83.9072,17152,2,0,0,0);
INSERT INTO doors VALUES (425,15,'paineel','PADOOR102',977.256,857.749,-69.9668,0,7,0,0,0);
INSERT INTO doors VALUES (426,16,'paineel','PADOOR101',977.256,867.599,-69.9668,0,2,0,0,0);
INSERT INTO doors VALUES (427,17,'paineel','PADOOR102',977.07,871.697,-69.9668,0,7,0,0,0);
INSERT INTO doors VALUES (428,18,'paineel','PADOOR101',977.07,881.647,-69.9668,0,2,0,0,0);
INSERT INTO doors VALUES (429,19,'paineel','PADOOR102',962.328,889.614,-69.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (430,20,'paineel','PADOOR101',962.328,879.715,-69.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (431,21,'paineel','PADOOR102',949.591,908.963,-69.9668,17152,7,0,0,0);
INSERT INTO doors VALUES (432,22,'paineel','PADOOR101',939.641,908.963,-69.9668,17152,2,0,0,0);
INSERT INTO doors VALUES (433,23,'paineel','PADOOR102',950.64,851.235,-83.9025,17344,7,0,0,0);
INSERT INTO doors VALUES (434,24,'paineel','PADOOR101',960.539,851.242,-83.9025,17344,2,0,0,0);
INSERT INTO doors VALUES (435,25,'paineel','PADOOR102',925.075,827.769,-83.9525,0,7,0,0,0);
INSERT INTO doors VALUES (436,26,'paineel','PADOOR101',925.075,837.619,-83.9525,0,2,0,0,0);
INSERT INTO doors VALUES (437,27,'paineel','PADOOR102',950.651,812.232,-83.9525,17344,7,0,0,0);
INSERT INTO doors VALUES (438,28,'paineel','PADOOR101',960.601,812.232,-83.9525,17344,2,0,0,0);
INSERT INTO doors VALUES (439,29,'paineel','PALIFT101',629.576,475.842,-98.2159,17152,59,0,0,0);
INSERT INTO doors VALUES (440,30,'paineel','PALIFT101',671.764,447.927,67.0645,17280,54,0,0,0);
INSERT INTO doors VALUES (441,31,'paineel','PALIFT101',601.08,433.43,47.8145,17280,54,0,0,0);
INSERT INTO doors VALUES (442,32,'paineel','PALIFT101',587.708,462.572,80.2775,17280,54,0,0,0);
INSERT INTO doors VALUES (443,33,'paineel','PADOOR102',868.709,-99.5191,15.002,17344,7,0,0,0);
INSERT INTO doors VALUES (444,34,'paineel','PADOOR101',878.559,-99.5191,15.002,17344,2,0,0,0);
INSERT INTO doors VALUES (445,35,'paineel','PADOOR102',881.081,-54.0389,0.002,0,7,0,0,0);
INSERT INTO doors VALUES (446,36,'paineel','PADOOR101',881.081,-44.0389,0.002,0,2,0,0,0);
INSERT INTO doors VALUES (447,37,'paineel','PAROCK105',567.701,-895.539,-96.0385,17186,0,0,0,0);
INSERT INTO doors VALUES (448,38,'paineel','PADOOR101',624.845,503.617,-97.9585,17152,2,0,0,0);
INSERT INTO doors VALUES (449,39,'paineel','PADOOR102',662.245,547.867,-97.9588,0,7,0,0,0);
INSERT INTO doors VALUES (450,40,'paineel','PADOOR101',662.245,557.717,-97.9588,0,2,0,0,0);
INSERT INTO doors VALUES (451,41,'paineel','PADOOR102',634.695,503.617,-97.9088,17152,7,0,0,0);
INSERT INTO doors VALUES (452,42,'paineel','PADOOR101',778.298,557.754,-121.936,0,2,0,0,0);
INSERT INTO doors VALUES (453,43,'paineel','PADOOR102',778.298,547.805,-121.936,0,7,0,0,0);
INSERT INTO doors VALUES (454,44,'paineel','PADOOR101',813.735,601.27,-121.936,17152,2,0,0,0);
INSERT INTO doors VALUES (455,45,'paineel','PADOOR102',823.584,601.27,-121.936,17152,7,0,0,0);
INSERT INTO doors VALUES (456,46,'paineel','PADOOR101',869.67,489.211,-123.936,17152,2,0,0,0);
INSERT INTO doors VALUES (457,47,'paineel','PADOOR102',879.57,489.211,-123.936,17152,7,0,0,0);
INSERT INTO doors VALUES (458,48,'paineel','PADOOR101',919.905,472.722,-123.936,0,2,0,0,0);
INSERT INTO doors VALUES (459,49,'paineel','PADOOR102',919.905,462.872,-123.936,0,7,0,0,0);
INSERT INTO doors VALUES (460,50,'paineel','PADOOR101',919.922,448.732,-123.936,0,2,0,0,0);
INSERT INTO doors VALUES (461,51,'paineel','PADOOR102',919.922,438.832,-123.936,0,7,0,0,0);
INSERT INTO doors VALUES (462,52,'paineel','PADOOR101',905.231,450.909,-123.936,17280,2,0,0,0);
INSERT INTO doors VALUES (463,53,'paineel','PADOOR102',905.231,460.759,-123.936,17280,7,0,0,0);
INSERT INTO doors VALUES (464,54,'paineel','PADOOR101',829.158,426.916,-123.936,17280,2,0,0,0);
INSERT INTO doors VALUES (465,55,'paineel','PADOOR102',829.158,436.766,-123.936,17280,7,0,0,0);
INSERT INTO doors VALUES (466,56,'paineel','PADOOR101',975.075,674.751,-69.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (467,57,'paineel','PADOOR102',975.075,684.701,-69.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (468,58,'paineel','PADOOR101',966.643,659.283,-83.9167,17152,2,0,0,0);
INSERT INTO doors VALUES (469,59,'paineel','PADOOR102',976.593,659.283,-83.8667,17152,7,0,0,0);
INSERT INTO doors VALUES (470,60,'paineel','PADOOR101',955.633,644.225,-69.9668,17152,2,0,0,0);
INSERT INTO doors VALUES (471,61,'paineel','PADOOR102',965.533,644.225,-69.9668,17152,7,0,0,0);
INSERT INTO doors VALUES (472,62,'paineel','PADOOR101',965.112,604.841,-69.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (473,63,'paineel','PADOOR102',965.111,614.691,-69.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (474,64,'paineel','PADOOR101',950.528,656.165,-83.9167,17344,2,0,0,0);
INSERT INTO doors VALUES (475,65,'paineel','PADOOR102',940.678,656.164,-83.9167,17344,7,0,0,0);
INSERT INTO doors VALUES (476,66,'paineel','PADOOR101',1002.29,739.624,-82.9668,0,2,0,0,0);
INSERT INTO doors VALUES (477,67,'paineel','PADOOR102',1002.29,729.724,-82.9668,0,7,0,0,0);
INSERT INTO doors VALUES (478,68,'paineel','PADOOR101',1030.8,757.65,-82.9668,0,2,0,0,0);
INSERT INTO doors VALUES (479,69,'paineel','PADOOR102',1030.8,747.8,-82.9668,0,7,0,0,0);
INSERT INTO doors VALUES (480,70,'paineel','PADOOR101',977.624,800.063,-82.9167,17152,2,0,0,0);
INSERT INTO doors VALUES (481,71,'paineel','PADOOR102',987.574,800.063,-82.9167,17152,7,0,0,0);
INSERT INTO doors VALUES (482,72,'paineel','PADOOR101',988.624,785.032,-82.7168,17152,2,0,0,0);
INSERT INTO doors VALUES (483,73,'paineel','PADOOR102',998.574,785.032,-82.7168,17152,7,0,0,0);
INSERT INTO doors VALUES (484,74,'paineel','PADOOR101',719.083,844.594,-57.9668,0,2,0,0,0);
INSERT INTO doors VALUES (485,75,'paineel','PADOOR102',719.083,834.744,-57.9668,0,7,0,0,0);
INSERT INTO doors VALUES (486,76,'paineel','PADOOR101',658.773,877.072,-57.9668,17152,2,0,0,0);
INSERT INTO doors VALUES (487,77,'paineel','PADOOR102',668.723,877.072,-57.9668,17152,7,0,0,0);
INSERT INTO doors VALUES (488,78,'paineel','PADOOR101',658.809,849.919,-57.9668,17155,2,0,0,0);
INSERT INTO doors VALUES (489,79,'paineel','PADOOR102',668.709,850.319,-57.9668,17155,7,0,0,0);
INSERT INTO doors VALUES (490,80,'paineel','PADOOR101',683.566,817.766,-57.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (491,81,'paineel','PADOOR102',683.566,827.615,-57.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (492,82,'paineel','PADOOR101',668.688,829.386,-57.9668,17344,2,0,0,0);
INSERT INTO doors VALUES (493,83,'paineel','PADOOR102',658.738,829.386,-57.9668,17344,7,0,0,0);
INSERT INTO doors VALUES (494,84,'paineel','PADOOR101',657.248,844.623,-57.9668,0,2,0,0,0);
INSERT INTO doors VALUES (495,85,'paineel','PADOOR102',657.248,834.723,-57.9668,0,7,0,0,0);
INSERT INTO doors VALUES (496,86,'paineel','MISTGATE',840.271,855.675,-83.8667,17280,1,0,0,0);
INSERT INTO doors VALUES (497,87,'paineel','MISTGATE',840.321,813.697,-83.9167,17280,1,0,0,0);
INSERT INTO doors VALUES (498,88,'paineel','PADOOR101',1142.56,799.022,-41.9668,17152,2,0,0,0);
INSERT INTO doors VALUES (499,89,'paineel','PADOOR102',1152.51,799.022,-41.9668,17152,7,0,0,0);
INSERT INTO doors VALUES (500,90,'paineel','PADOOR101',1200.17,812.722,-41.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (501,91,'paineel','PADOOR102',1200.17,822.571,-41.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (502,92,'paineel','PADOOR101',1186.23,862.732,-41.9668,17280,2,0,0,0);
INSERT INTO doors VALUES (503,93,'paineel','PADOOR102',1186.23,872.582,-41.9668,17280,7,0,0,0);
INSERT INTO doors VALUES (504,94,'paineel','PADOOR101',1152.52,906.126,-41.9668,17344,2,0,0,0);
INSERT INTO doors VALUES (505,95,'paineel','PADOOR102',1142.57,906.126,-41.9668,17344,7,0,0,0);
INSERT INTO doors VALUES (506,96,'paineel','PADOOR101',1078.82,872.618,-41.9668,0,2,0,0,0);
INSERT INTO doors VALUES (507,97,'paineel','PADOOR102',1078.82,862.668,-41.9668,0,7,0,0,0);
INSERT INTO doors VALUES (508,98,'paineel','PADOOR101',1102.47,920.455,-41.9668,17344,2,0,0,0);
INSERT INTO doors VALUES (509,99,'paineel','PADOOR102',1092.57,920.455,-41.9668,17344,7,0,0,0);
INSERT INTO doors VALUES (510,100,'paineel','PADOOR101',1142.59,906.946,-27.9668,17152,2,0,0,0);
INSERT INTO doors VALUES (511,101,'paineel','PADOOR102',1152.49,906.946,-27.9668,17152,7,0,0,0);
INSERT INTO doors VALUES (512,102,'paineel','PADOOR101',1186.85,872.619,-27.9661,16395,2,0,0,0);
INSERT INTO doors VALUES (513,103,'paineel','PADOOR102',1187.1,862.669,-27.9661,16395,7,0,0,0);
INSERT INTO doors VALUES (514,104,'paineel','PADOOR101',1101,741.672,-40.9668,0,2,0,0,0);
INSERT INTO doors VALUES (515,105,'paineel','PADOOR102',1101,731.722,-40.9668,0,7,0,0,0);
INSERT INTO doors VALUES (516,106,'paineel','PADOOR101',1085.82,741.668,-40.9668,16366,2,0,0,0);
INSERT INTO doors VALUES (517,107,'paineel','PADOOR102',1085.97,731.718,-40.9668,16366,7,0,0,0);
INSERT INTO doors VALUES (518,108,'paineel','PADOOR101',1070.99,729.706,-40.9668,0,2,0,0,0);
INSERT INTO doors VALUES (519,109,'paineel','PADOOR102',1070.99,719.806,-40.9668,0,7,0,0,0);
INSERT INTO doors VALUES (520,110,'paineel','PADOOR101',1278.39,754.435,-41.9668,17344,2,0,0,0);
INSERT INTO doors VALUES (521,111,'paineel','PADOOR102',1268.54,754.435,-41.9668,17344,7,0,0,0);
INSERT INTO doors VALUES (522,112,'paineel','PADOOR101',1278.45,727.447,-41.9668,17344,2,0,0,0);
INSERT INTO doors VALUES (523,113,'paineel','PADOOR102',1268.5,727.447,-41.9668,17344,7,0,0,0);
INSERT INTO doors VALUES (524,114,'paineel','PADOOR101',1315.7,690.661,-25.9836,24064,0,0,0,0);
INSERT INTO doors VALUES (568,1,'halas','HALDOOR',218.466,122.898,4.13627,0,5,0,0,0);
INSERT INTO doors VALUES (569,2,'halas','HALDOOR',207.9,-265.127,2.00019,17344,0,0,0,0);
INSERT INTO doors VALUES (570,3,'halas','HALDOOR',305.953,-262.888,1.0006,17280,0,0,0,0);
INSERT INTO doors VALUES (571,4,'halas','HALDOOR',263.262,242.865,0.000985,0,0,0,0,0);
INSERT INTO doors VALUES (572,5,'halas','HALDOOR',160.018,420.452,0.000985,17152,0,0,0,0);
INSERT INTO doors VALUES (573,6,'halas','HALDOOR',158.014,364.326,0.000985,17152,0,0,0,0);
INSERT INTO doors VALUES (574,7,'halas','HALDOOR',221.96,-179.133,0.000985,17152,0,0,0,0);
INSERT INTO doors VALUES (575,8,'halas','HALDOOR',131.934,-307.676,0.000985,17344,0,0,0,0);
INSERT INTO doors VALUES (576,9,'halas','HALDOOR',129.65,-236.875,0.000985,17280,0,0,0,0);
INSERT INTO doors VALUES (577,10,'halas','HALDOOR',286.874,-214.669,0.000985,17344,0,0,0,0);
INSERT INTO doors VALUES (578,11,'halas','HALDOOR',170.359,142.021,0.354631,17280,0,0,0,0);
INSERT INTO doors VALUES (579,12,'halas','HALDOOR',242.891,289.325,0.000985,17344,0,0,0,0);
INSERT INTO doors VALUES (580,13,'halas','HALDOOR',-8.00098,48.9419,0.000985,17344,0,0,0,0);
INSERT INTO doors VALUES (581,1,'kaladima','VUDOOR',-71.3375,489.902,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (582,2,'kaladima','VUDOOR',-71.0631,461.822,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (583,3,'kaladima','VUDOOR',-71.2054,427.886,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (584,4,'kaladima','VUDOOR',-52.7709,407.822,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (585,5,'kaladima','VUDOOR',223.879,-213.139,0.001,17345,0,0,0,0);
INSERT INTO doors VALUES (586,6,'kaladima','VUDOOR',237.047,-191.926,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (587,7,'kaladima','VUDOOR',168.027,-165.825,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (588,8,'kaladima','VUDOOR',-119.415,-307.527,7.9978,17343,0,0,0,0);
INSERT INTO doors VALUES (589,9,'kaladima','VUDOOR',-42.0263,-339.715,7.9978,17344,0,0,0,0);
INSERT INTO doors VALUES (590,10,'kaladima','VUDOOR',-175.664,-363.755,7.9978,17280,0,0,0,0);
INSERT INTO doors VALUES (591,11,'kaladima','VUDOOR',-119.58,-419.813,7.9978,17280,0,0,0,0);
INSERT INTO doors VALUES (592,12,'kaladima','VUDOOR',1.97953,-380.957,7.9978,17344,5,0,0,0);
INSERT INTO doors VALUES (593,13,'kaladima','VUDOOR',1.99755,-339.557,7.9978,17344,0,0,0,0);
INSERT INTO doors VALUES (594,14,'kaladima','VUDOOR',-42.0339,-381.014,7.9978,17344,0,0,0,0);
INSERT INTO doors VALUES (595,15,'kaladima','VUDOOR',131.14,213.835,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (596,16,'kaladima','VUDOOR',96.7705,206.004,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (597,17,'kaladima','VUDOOR',169.958,359.245,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (598,18,'kaladima','VUDOOR',119.419,369.795,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (599,19,'kaladima','VUDOOR',189.603,336.332,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (600,1,'kaladimb','VUDOOR',597.552,246.648,-35.9846,17344,0,0,0,0);
INSERT INTO doors VALUES (601,2,'kaladimb','VUDOOR',466.885,-158.007,0.001002,0,0,0,0,0);
INSERT INTO doors VALUES (602,3,'kaladimb','VUDOOR',397.884,-180.066,0.001002,17152,0,0,0,0);
INSERT INTO doors VALUES (603,4,'kaladimb','VUDOOR',385.867,-180.523,11.9962,17152,0,0,0,0);
INSERT INTO doors VALUES (604,5,'kaladimb','VUDOOR',421.871,-96.507,0.001002,17152,0,0,0,0);
INSERT INTO doors VALUES (605,6,'kaladimb','VUDOOR',490.569,-146.003,0.001002,16529,0,0,0,0);
INSERT INTO doors VALUES (606,7,'kaladimb','VUDOOR',729.286,135.85,0.001002,16531,0,0,0,0);
INSERT INTO doors VALUES (607,8,'kaladimb','VUDOOR',1447.26,104.33,35.9866,17344,0,0,0,0);
INSERT INTO doors VALUES (608,9,'kaladimb','VUDOOR',1451.05,119.931,35.9866,0,0,0,0,0);
INSERT INTO doors VALUES (609,10,'kaladimb','VUDOOR',1450.68,151.896,35.9866,16355,0,0,0,0);
INSERT INTO doors VALUES (610,11,'kaladimb','VUDOOR',1439.43,159.379,35.9866,17148,0,0,0,0);
INSERT INTO doors VALUES (611,12,'kaladimb','VUDOOR',1334.8,107.912,35.9866,0,5,0,0,0);
INSERT INTO doors VALUES (612,13,'kaladimb','VUDOOR',1334.74,163.851,35.9866,0,5,0,0,0);
INSERT INTO doors VALUES (613,14,'kaladimb','VUDOOR',655.393,-181.943,0.001002,0,5,0,0,0);
INSERT INTO doors VALUES (614,1,'butcher','KALHSEDR',-534.514,1844.66,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (615,2,'butcher','KALHSEDR',2068.74,399.415,-3.40255,17280,0,0,0,0);
INSERT INTO doors VALUES (616,3,'butcher','DOOR1',1049.3,3013.88,7.89165,17280,0,0,0,0);
INSERT INTO doors VALUES (617,4,'butcher','KALHSEDR',1091.67,2739.96,-3.02686,17280,0,0,0,0);
INSERT INTO doors VALUES (618,5,'butcher','KALHSEDR',1122.57,2712.37,-3.10235,17313,0,0,0,0);
INSERT INTO doors VALUES (619,6,'butcher','GNHSEDOOR',1181.45,2645.68,-0.920385,17344,0,0,0,0);
INSERT INTO doors VALUES (620,7,'butcher','GNHSEDOOR',1209.01,2655.2,-1.42673,17344,0,0,0,0);
INSERT INTO doors VALUES (621,8,'butcher','FAYDOOR',1380.45,2778.27,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (622,9,'butcher','FAYDOOR',1409.19,2778.2,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (623,10,'butcher','FAYDOOR',1412.01,2740.78,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (624,11,'butcher','KALHSEDR',1268.13,2572.89,-3.40255,17334,0,0,0,0);
INSERT INTO doors VALUES (625,12,'butcher','KALHSEDR',1113.1,1473.17,-3.40263,17344,0,0,0,0);
INSERT INTO doors VALUES (626,13,'butcher','KALHSEDR',2843.88,-689.75,-3.65255,17280,0,0,0,0);
INSERT INTO doors VALUES (627,14,'butcher','KALHSEDR',-1435.27,2893.7,-4.49264,0,0,0,0,0);
INSERT INTO doors VALUES (628,15,'butcher','KALHSEDR',-1474.74,2878.92,-5.0606,17280,0,0,0,0);
INSERT INTO doors VALUES (629,16,'butcher','KALHSEDR',-1205.24,-1947.51,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (630,17,'butcher','KALHSEDR',-1290.98,-2004.07,-3.40255,17280,0,0,0,0);
INSERT INTO doors VALUES (631,18,'butcher','KALHSEDR',-132.769,133.491,-3.40255,0,0,0,0,0);
INSERT INTO doors VALUES (632,19,'butcher','KALHSEDR',-962.097,9.22144,-3.51318,0,0,0,0,0);
INSERT INTO doors VALUES (633,20,'butcher','KALHSEDR',2068.59,-792.025,-3.40255,17280,0,0,0,0);
INSERT INTO doors VALUES (634,21,'butcher','KALHSEDR',2725.86,-935.748,-3.40255,17344,0,0,0,0);
INSERT INTO doors VALUES (635,22,'butcher','KALHSEDR',2797.74,-909.358,-3.40255,17152,0,0,0,0);
INSERT INTO doors VALUES (636,1,'akanon','AKADOOR',815.763,-182.894,-31.9862,17152,0,0,0,0);
INSERT INTO doors VALUES (637,2,'akanon','AKADOOR',871.514,-448.774,-31.9862,17344,0,0,0,0);
INSERT INTO doors VALUES (638,3,'akanon','AKALIGHT4G',1306.03,-901.01,13.9954,17366,100,0,0,0);
INSERT INTO doors VALUES (639,4,'akanon','AKALIGHT4G',1294.86,-914.125,13.9954,17366,100,0,0,0);
INSERT INTO doors VALUES (640,5,'akanon','AKALIGHT4G',1283.01,-900.835,13.9954,17366,100,0,0,0);
INSERT INTO doors VALUES (641,6,'akanon','AKALIGHT2G',819.947,-105.715,-31.4862,17366,100,0,0,0);
INSERT INTO doors VALUES (642,7,'akanon','AKADOOR',1288.45,-823.767,-39.983,0,6,0,0,0);
INSERT INTO doors VALUES (643,8,'akanon','AKALIGHT4G',1288.96,-793.08,-39.983,17366,100,0,0,0);
INSERT INTO doors VALUES (644,9,'akanon','AKALIGHT4G',1309.48,-793.201,-39.983,17366,100,0,0,0);
INSERT INTO doors VALUES (645,10,'akanon','AKALIGHT4G',1299.72,-809.933,-39.983,17366,100,0,0,0);
INSERT INTO doors VALUES (646,11,'akanon','AKADOOR',1214.48,-943.596,-39.983,17280,1,0,0,0);
INSERT INTO doors VALUES (647,12,'akanon','AKADOOR',1214.5,-919.534,-39.983,17280,1,0,0,0);
INSERT INTO doors VALUES (648,13,'akanon','AKADOOR',1214.48,-887.56,-39.983,17280,1,0,0,0);
INSERT INTO doors VALUES (649,14,'akanon','AKADOOR',1214.48,-863.617,-39.983,17280,1,0,0,0);
INSERT INTO doors VALUES (650,15,'akanon','AKADOOR',1239.59,-894.588,-31.9862,17152,1,0,0,0);
INSERT INTO doors VALUES (651,16,'akanon','AKADOOR',1263.45,-904.686,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (652,17,'akanon','AKADOOR',719.755,-190.916,-55.9766,17152,1,0,0,0);
INSERT INTO doors VALUES (653,18,'akanon','AKADOOR',791.621,-193.065,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (654,19,'akanon','AKADOOR',774.794,-183.768,-31.9862,17280,1,0,0,0);
INSERT INTO doors VALUES (655,20,'akanon','AKADOOR',735.678,-145.027,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (656,21,'akanon','AKADOOR',727.771,-134.879,-31.9862,17152,1,0,0,0);
INSERT INTO doors VALUES (657,22,'akanon','AKALIGHT4G',793.083,-134.557,-31.9862,17366,100,0,0,0);
INSERT INTO doors VALUES (658,23,'akanon','AKALIGHT4G',782.382,-134.572,-31.9862,17366,100,0,0,0);
INSERT INTO doors VALUES (659,24,'akanon','AKALIGHT4G',782.181,-145.297,-31.9862,17366,100,0,0,0);
INSERT INTO doors VALUES (660,25,'akanon','AKALIGHT4G',793.095,-145.306,-31.9862,17366,100,0,0,0);
INSERT INTO doors VALUES (661,26,'akanon','AKADOOR',783.735,-158.828,-31.9862,17152,1,0,0,0);
INSERT INTO doors VALUES (662,27,'akanon','AKADOOR',768.724,-135.951,-31.9862,0,1,0,0,0);
INSERT INTO doors VALUES (663,28,'akanon','AKADOOR',806.639,-143.703,-31.9862,17280,1,0,0,0);
INSERT INTO doors VALUES (664,29,'akanon','AKADOOR',1958.34,-359.757,-125.949,17280,6,0,0,0);
INSERT INTO doors VALUES (665,30,'akanon','AKADOOR',1958.3,-219.806,-125.949,17280,6,0,0,0);
INSERT INTO doors VALUES (666,31,'akanon','AKADOOR',1175.69,-583.318,-55.9766,17152,1,0,0,0);
INSERT INTO doors VALUES (667,32,'akanon','AKADOOR',1224.63,-591.989,-55.9766,0,1,0,0,0);
INSERT INTO doors VALUES (668,33,'akanon','AKADOOR',1207.49,-584.841,-55.9766,17344,1,0,0,0);
INSERT INTO doors VALUES (669,34,'akanon','AKADOOR',862.636,-447.738,-31.9862,17280,1,0,0,0);
INSERT INTO doors VALUES (670,35,'akanon','AKADOOR',903.585,-448.995,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (671,36,'akanon','AKADOOR',927.679,-454.737,-31.9862,17152,1,0,0,0);
INSERT INTO doors VALUES (672,37,'akanon','AKADOOR',935.491,-480.873,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (673,38,'akanon','AKADOOR',991.573,-481.152,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (674,39,'akanon','AKADOOR',241.875,13.0099,-27.9878,17344,1,0,0,0);
INSERT INTO doors VALUES (675,40,'akanon','AKADOOR',247.862,42.0859,-27.9878,17344,6,0,0,0);
INSERT INTO doors VALUES (676,41,'akanon','AKALIGHT4G',1204.05,-592.994,-40.9826,17089,102,0,0,0);
INSERT INTO doors VALUES (677,42,'akanon','AKALIGHT4G',1284.91,-518.635,-41.9822,17366,100,0,0,0);
INSERT INTO doors VALUES (678,43,'akanon','AKALIGHT4G',1311.92,-771.149,-13.9934,17366,100,0,0,0);
INSERT INTO doors VALUES (679,44,'akanon','AKALIGHT4G',1277.09,-771.265,-13.9934,17366,100,0,0,0);
INSERT INTO doors VALUES (680,45,'akanon','AKALIGHT4G',1312.27,-731.671,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (681,46,'akanon','AKALIGHT4G',878.147,-477.923,-31.9862,17366,100,0,0,0);
INSERT INTO doors VALUES (682,47,'akanon','AKALIGHT2G',975.419,-303.852,-9.14544,17089,102,0,0,0);
INSERT INTO doors VALUES (683,48,'akanon','AKALIGHT4G',381.544,21.4447,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (684,49,'akanon','AKALIGHT4G',249.265,30.6494,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (685,50,'akanon','AKALIGHT4G',226.961,70.3559,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (686,51,'akanon','AKALIGHT4G',1796.65,-362.374,-125.949,17366,100,0,0,0);
INSERT INTO doors VALUES (687,52,'akanon','AKALIGHT4G',1894.36,-371.096,-125.949,17366,100,0,0,0);
INSERT INTO doors VALUES (688,53,'akanon','AKALIGHT4G',1996.28,-261.66,-125.199,17366,100,0,0,0);
INSERT INTO doors VALUES (689,54,'akanon','AKAWHEEL',1938.66,-293.616,-123.437,0,105,0,0,0);
INSERT INTO doors VALUES (690,55,'akanon','AKALIGHT4G',1690.1,-331.477,-124.949,17366,100,0,0,0);
INSERT INTO doors VALUES (691,56,'akanon','AKALIGHT4G',1388.88,-521.592,-82.9658,17366,100,0,0,0);
INSERT INTO doors VALUES (692,57,'akanon','AKALIGHT4G',1340.96,-520.629,-81.9662,17366,100,0,0,0);
INSERT INTO doors VALUES (693,58,'akanon','AKALIGHT4G',226.803,11.1748,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (694,59,'akanon','AKALIGHT4G',248.985,-2.77428,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (695,60,'akanon','AKALIGHT4G',248.176,-41.4365,-15.9926,17366,100,0,0,0);
INSERT INTO doors VALUES (696,61,'akanon','AKALIGHT4G',226.603,11.8277,-15.9926,17366,100,0,0,0);
INSERT INTO doors VALUES (697,62,'akanon','AKALIGHT4G',226.721,29.904,-15.9926,17366,100,0,0,0);
INSERT INTO doors VALUES (698,63,'akanon','AKALIGHT4G',485.092,-49.6744,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (699,64,'akanon','AKALIGHT4G',492.543,36.0651,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (700,65,'akanon','AKALIGHT4G',658.651,141.718,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (701,66,'akanon','AKALIGHT4G',725.434,145.894,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (702,67,'akanon','AKALIGHT4G',554.02,-228.077,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (703,68,'akanon','AKALIGHT4G',604.755,-380.413,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (704,69,'akanon','AKALIGHT4G',792.715,-383.25,-27.9878,0,0,0,0,0);
INSERT INTO doors VALUES (705,70,'akanon','AKALIGHT4G',1326.22,-619.809,-27.9878,17366,100,0,0,0);
INSERT INTO doors VALUES (706,71,'akanon','AKALIGHT4G',1078.01,-1007.88,27.9898,17366,100,0,0,0);
INSERT INTO doors VALUES (707,72,'akanon','AKALIGHT4G',1041.32,-1013.53,27.9898,17366,100,0,0,0);
INSERT INTO doors VALUES (708,73,'akanon','AKALIGHT4G',1085.98,-1046.31,27.9898,17366,100,0,0,0);
INSERT INTO doors VALUES (709,74,'akanon','AKALIGHT4G',1216.85,-593.407,-40.9826,17089,102,0,0,0);
INSERT INTO doors VALUES (710,75,'akanon','AKALIGHT2G',1210.59,-530.1,-40.8853,17089,102,0,0,0);
INSERT INTO doors VALUES (711,76,'akanon','AKALIGHT2G',1179.37,-534.077,-40.8841,17089,102,0,0,0);
INSERT INTO doors VALUES (712,77,'akanon','AKALIGHT2G',1241.49,-554.068,-41.1315,17089,102,0,0,0);
INSERT INTO doors VALUES (713,78,'akanon','AKADOOR',975.608,-64.8815,-39.983,17344,1,0,0,0);
INSERT INTO doors VALUES (714,79,'akanon','AKADOOR',967.662,-55.0738,-39.983,17152,1,0,0,0);
INSERT INTO doors VALUES (715,80,'akanon','AKADOOR',959.188,-63.936,-39.983,17280,1,0,0,0);
INSERT INTO doors VALUES (716,81,'akanon','AKADOOR',1244.36,-701.719,-27.9878,17344,1,0,0,0);
INSERT INTO doors VALUES (717,82,'akanon','AKADOOR',1317.2,-717.771,-27.9878,0,1,0,0,0);
INSERT INTO doors VALUES (718,83,'akanon','VUDOOR',1092.46,-1003.83,27.9898,0,0,0,0,0);
INSERT INTO doors VALUES (719,84,'akanon','VUDOOR',1073.69,-993.435,27.9898,17152,0,0,0,0);
INSERT INTO doors VALUES (720,85,'akanon','VUDOOR',1081.52,-1020.93,27.9898,17344,0,0,0,0);
INSERT INTO doors VALUES (721,86,'akanon','VUDOOR',1063.78,-1011.52,27.9898,17280,0,0,0,0);
INSERT INTO doors VALUES (722,87,'akanon','AKADOOR',2038.94,-384.678,-183.925,17344,1,0,0,0);
INSERT INTO doors VALUES (723,88,'akanon','AKADOOR',751.142,-111.919,-15.9926,17280,1,0,0,0);
INSERT INTO doors VALUES (724,89,'akanon','AKALIGHT4G',742.128,-115.735,-15.9926,17366,100,0,0,0);
INSERT INTO doors VALUES (725,90,'akanon','AKADOOR',745.28,-143.971,-15.9926,0,1,0,0,0);
INSERT INTO doors VALUES (726,91,'akanon','AKADOOR',735.665,-128.993,-15.9926,17344,1,0,0,0);
INSERT INTO doors VALUES (727,92,'akanon','AKADOOR',823.658,-129.092,-14.993,17344,1,0,0,0);
INSERT INTO doors VALUES (728,93,'akanon','AKADOOR',744.937,-119.97,-15.9926,0,1,0,0,0);
INSERT INTO doors VALUES (729,94,'akanon','AKADOOR',727.774,-159.004,-55.9766,17152,1,0,0,0);
INSERT INTO doors VALUES (730,95,'akanon','AKADOOR',759.497,-112.995,-55.9766,17344,1,0,0,0);
INSERT INTO doors VALUES (731,96,'akanon','AKADOOR',760.881,-104.019,-55.9766,0,1,0,0,0);
INSERT INTO doors VALUES (732,97,'akanon','AKADOOR',744.774,-104.003,-55.9766,0,1,0,0,0);
INSERT INTO doors VALUES (733,98,'akanon','AKADOOR',727.744,-134.963,-55.9766,17152,1,0,0,0);
INSERT INTO doors VALUES (734,99,'akanon','AKADOOR',815.704,-158.894,-71.9702,17152,1,0,0,0);
INSERT INTO doors VALUES (735,100,'akanon','AKADOOR',815.7,-134.929,-71.9702,17152,1,0,0,0);
INSERT INTO doors VALUES (736,101,'akanon','AKALIGHT4G',820.589,-213.721,-71.9702,17366,100,0,0,0);
INSERT INTO doors VALUES (737,102,'akanon','AKALIGHT4G',828.025,-180.219,-63.9734,17366,100,0,0,0);
INSERT INTO doors VALUES (738,103,'akanon','AKALIGHT4G',812.067,-180.526,-63.9734,17366,100,0,0,0);
INSERT INTO doors VALUES (739,104,'akanon','AKADOOR',1343.46,-904.674,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (740,105,'akanon','AKADOOR',1351.55,-894.567,-31.9862,17152,1,0,0,0);
INSERT INTO doors VALUES (741,106,'akanon','AKADOOR',1335.52,-855.059,-23.9894,17152,1,0,0,0);
INSERT INTO doors VALUES (742,107,'akanon','AKADOOR',1375.48,-886.616,-39.983,17152,1,0,0,0);
INSERT INTO doors VALUES (743,108,'akanon','AKADOOR',1383.35,-912.688,-39.983,17344,1,0,0,0);
INSERT INTO doors VALUES (744,109,'akanon','AKADOOR',233.94,29.0132,-27.9878,17152,1,0,0,0);
INSERT INTO doors VALUES (745,110,'akanon','AKADOOR',791.643,-120.919,-31.9862,17344,1,0,0,0);
INSERT INTO doors VALUES (746,111,'akanon','AKADOOR',227.919,0.082279,-27.7516,17152,1,0,0,0);
INSERT INTO doors VALUES (747,1,'steamfont','GNHSEDOOR',-1635.14,426.6,-110.944,0,0,0,0,0);
INSERT INTO doors VALUES (748,2,'steamfont','GNHSEDOOR',-1785.15,682.318,-111.158,17344,0,0,0,0);
INSERT INTO doors VALUES (749,3,'steamfont','GNHSEDOOR',-1783.53,348.273,-110.944,17344,0,0,0,0);
INSERT INTO doors VALUES (750,4,'steamfont','GNHSEDOOR',-1709.77,833.653,-110.944,0,0,0,0,0);
INSERT INTO doors VALUES (751,5,'steamfont','GNHSEDOOR',-1591.57,-1843.89,-110.944,17280,0,0,0,0);
INSERT INTO doors VALUES (752,6,'steamfont','GNHSEDOOR',-1561.8,-1826.78,-110.908,17280,0,0,0,0);
INSERT INTO doors VALUES (753,7,'steamfont','GNHSEDOOR',-1516.02,-1833.94,-110.995,17344,0,0,0,0);
INSERT INTO doors VALUES (754,8,'steamfont','GNHSEDOOR',1880.33,-196.217,-111.876,17280,0,0,0,0);
INSERT INTO doors VALUES (755,9,'steamfont','GNHSEDOOR',1887.03,-282.293,-111.677,17280,0,0,0,0);
INSERT INTO doors VALUES (756,10,'steamfont','WMDOOR',134.507,-823.971,-111.158,17344,0,0,0,0);
INSERT INTO doors VALUES (757,11,'steamfont','WMDOOR',101.986,-566.361,-108.108,17344,0,0,0,0);
INSERT INTO doors VALUES (758,12,'steamfont','WMDOOR',-59.9893,-411.754,-110.158,17344,0,0,0,0);
INSERT INTO doors VALUES (759,13,'steamfont','WMBLADE',94.1166,-563.978,81.842,17280,105,0,0,0);
INSERT INTO doors VALUES (760,14,'steamfont','SHAFT',94.5324,-624.115,-109.747,17396,100,0,0,0);
INSERT INTO doors VALUES (761,15,'steamfont','SHAFT',-67.518,-459.924,-110.923,17396,100,0,0,0);
INSERT INTO doors VALUES (762,16,'steamfont','WMBLADE',-67.518,-404.678,94.342,17280,105,0,0,0);
INSERT INTO doors VALUES (763,17,'steamfont','SHAFT',123.018,-867.567,-111.657,17396,100,0,0,0);
INSERT INTO doors VALUES (764,18,'steamfont','WMBLADE',127.976,-816.8,89.592,17280,105,0,0,0);
INSERT INTO doors VALUES (765,1,'qeynos','DOOR1',509.453,-322.797,12.002,17151,54,0,0,0);
INSERT INTO doors VALUES (766,2,'qeynos','DOOR1',-268.116,-224.415,0.002,17342,0,0,0,0);
INSERT INTO doors VALUES (767,3,'qeynos','DOOR1',475.702,-289.472,15.501,16384,54,0,0,0);
INSERT INTO doors VALUES (768,4,'qeynos','BBBOARD',-326.309,-216.156,4.751,17152,55,0,0,0);
INSERT INTO doors VALUES (769,5,'qeynos','DOOR1',30.0511,-560.18,27.9898,17152,0,0,0,0);
INSERT INTO doors VALUES (770,6,'qeynos','DOOR1',82.0039,-560.214,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (771,7,'qeynos','DOOR1',53.2673,-575.732,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (772,8,'qeynos','DOOR1',419.186,-95.9453,0.000982,17280,0,0,0,0);
INSERT INTO doors VALUES (773,9,'qeynos','DOOR1',431.776,-70.4861,0.001016,17344,0,0,0,0);
INSERT INTO doors VALUES (774,10,'qeynos','DOOR1',305.913,-160.788,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (775,11,'qeynos','DOOR1',297.136,-183.946,13.9954,15779,0,0,0,0);
INSERT INTO doors VALUES (776,12,'qeynos','DOOR1',253.138,-175.93,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (777,13,'qeynos','DOOR1',255.257,-118.028,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (778,14,'qeynos','DOOR1',254.504,-83.8874,13.9954,17280,0,0,0,0);
INSERT INTO doors VALUES (779,15,'qeynos','DOOR1',319.345,-90.0124,13.9954,0,0,0,0,0);
INSERT INTO doors VALUES (780,16,'qeynos','DOOR1',295.92,-88.3207,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (781,17,'qeynos','DOOR1',303.968,-126.44,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (782,18,'qeynos','DOOR1',359.848,-103.752,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (783,19,'qeynos','DOOR1',348.971,-74.019,0.000986,17152,0,0,0,0);
INSERT INTO doors VALUES (784,20,'qeynos','DOOR1',331.734,-69.3671,0.001027,17344,0,0,0,0);
INSERT INTO doors VALUES (785,21,'qeynos','DOOR1',291.786,-99.307,0.001018,17344,0,0,0,0);
INSERT INTO doors VALUES (786,22,'qeynos','DOOR1',281.89,-86.5917,0.000996,17152,0,0,0,0);
INSERT INTO doors VALUES (787,23,'qeynos','DOOR1',349.062,-115.975,0.00092,0,0,0,0,0);
INSERT INTO doors VALUES (788,24,'qeynos','DOOR1',224.328,-86.0096,0.00099,0,0,0,0,0);
INSERT INTO doors VALUES (789,25,'qeynos','DOOR1',322.303,-170.004,0.000924,0,0,0,0,0);
INSERT INTO doors VALUES (790,26,'qeynos','DOOR1',335.343,-613.667,0.000859,17280,0,0,0,0);
INSERT INTO doors VALUES (791,27,'qeynos','DOOR1',335.653,-571.73,0.001091,17280,0,0,0,0);
INSERT INTO doors VALUES (792,28,'qeynos','DOOR1',389.755,-574.117,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (793,29,'qeynos','DOOR1',335.249,-487.75,0.000997,17280,0,0,0,0);
INSERT INTO doors VALUES (794,30,'qeynos','DOOR1',364.273,-491.81,0.000848,0,0,0,0,0);
INSERT INTO doors VALUES (795,31,'qeynos','DOOR1',305.851,-476.198,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (796,32,'qeynos','DOOR1',307.623,-459.796,0.001103,17280,0,0,0,0);
INSERT INTO doors VALUES (797,33,'qeynos','DOOR1',193.836,-280.266,0.001007,17344,0,0,0,0);
INSERT INTO doors VALUES (798,34,'qeynos','DOOR1',-193.904,-377.317,0.000989,17152,0,0,0,0);
INSERT INTO doors VALUES (799,35,'qeynos','DOOR1',-167.588,-211.993,0.00096,0,0,0,0,0);
INSERT INTO doors VALUES (800,36,'qeynos','DOOR1',277.816,-336.409,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (801,37,'qeynos','DOOR1',263.874,-336.311,0.001018,17343,0,0,0,0);
INSERT INTO doors VALUES (802,38,'qeynos','DOOR1',265.519,-305.784,0.00101,17280,0,0,0,0);
INSERT INTO doors VALUES (803,39,'qeynos','DOOR1',505.868,-321.513,0.000998,17152,0,0,0,0);
INSERT INTO doors VALUES (804,40,'qeynos','DOOR1',431.796,-210.09,0.000992,17344,0,0,0,0);
INSERT INTO doors VALUES (805,41,'qeynos','DOOR1',490.314,-43.9946,0.000794,0,0,0,0,0);
INSERT INTO doors VALUES (806,42,'qeynos','BBBOARD',226.221,-107.042,3.751,17280,55,0,0,0);
INSERT INTO doors VALUES (807,43,'qeynos','CHEST1',-205.078,-373.545,0.001,16387,56,0,0,0);
INSERT INTO doors VALUES (808,44,'qeynos','PORT1414',122.696,-539.731,-13.765,17344,66,0,0,0);
INSERT INTO doors VALUES (809,45,'qeynos','BBDOOR1',-2.16171,-389.332,-25.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (810,46,'qeynos','BBDOOR1',-44.023,-389.468,-25.9878,17344,0,0,0,0);
INSERT INTO doors VALUES (811,47,'qeynos','BBDOOR1',-72.3358,-407.924,-25.9878,0,0,0,0,0);
INSERT INTO doors VALUES (812,48,'qeynos','BBDOOR1',-72.4357,-435.873,-25.9886,0,0,0,0,0);
INSERT INTO doors VALUES (813,49,'qeynos','BBDOOR1',-72.4162,-463.904,-25.8978,0,0,0,0,0);
INSERT INTO doors VALUES (814,50,'qeynos','BBDOOR1',-53.932,-492.31,-25.9886,17152,0,0,0,0);
INSERT INTO doors VALUES (815,51,'qeynos','BBDOOR1',-11.959,-492.016,-25.9886,17152,0,0,0,0);
INSERT INTO doors VALUES (816,52,'qeynos','QEYLAMP',-160.94,-28.0047,43.9943,17344,100,0,0,0);
INSERT INTO doors VALUES (817,53,'qeynos','DOOR1',-141.101,-53.9396,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (818,54,'qeynos','DOOR1',-180.364,-30.0596,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (819,55,'qeynos','DOOR1',26.7716,-95.9163,0.001,17279,0,0,0,0);
INSERT INTO doors VALUES (820,56,'qeynos','BBBOARD',301.661,-159.899,4.001,0,55,0,0,0);
INSERT INTO doors VALUES (821,57,'qeynos','DOOR1',475.804,-279.57,15.5585,17406,54,0,0,0);
INSERT INTO doors VALUES (822,58,'qeynos','DOOR1',165.323,-40.1764,8.251,17127,54,0,0,0);
INSERT INTO doors VALUES (823,59,'qeynos','DOOR1',121.645,-216.175,8.751,17354,54,0,0,0);
INSERT INTO doors VALUES (824,60,'qeynos','DOOR1',174.007,-42.9831,8.251,17256,54,0,0,0);
INSERT INTO doors VALUES (825,61,'qeynos','DOOR1',167.23,-31.5745,8.251,17403,54,0,0,0);
INSERT INTO doors VALUES (826,62,'qeynos','DOOR1',118.7,-225.207,8.751,17253,54,0,0,0);
INSERT INTO doors VALUES (827,63,'qeynos','DOOR1',112.164,-217.943,8.501,17012,54,0,0,0);
INSERT INTO doors VALUES (828,64,'qeynos','DOOR1',-237.746,-513.673,11.9944,17279,54,0,0,0);
INSERT INTO doors VALUES (829,65,'qeynos','DOOR1',-236.94,-523.266,12.001,17280,54,0,0,0);
INSERT INTO doors VALUES (830,66,'qeynos','DOOR1',-237.129,-531.694,12.001,17279,54,0,0,0);
INSERT INTO doors VALUES (831,67,'qeynos','DOOR1',-168.415,-479.947,12.001,17407,54,0,0,0);
INSERT INTO doors VALUES (832,68,'qeynos','PORT1414',-188.682,119.137,-99.2168,17342,58,0,0,0);
INSERT INTO doors VALUES (833,1,'qeynos2','CRATEB',177.785,-358.056,0.002,17251,0,0,0,0);
INSERT INTO doors VALUES (834,2,'qeynos2','CRATEA',171.492,-357.653,3.002,17289,0,0,0,0);
INSERT INTO doors VALUES (835,3,'qeynos2','CRATEA',172.868,-355.323,0.002,17279,0,0,0,0);
INSERT INTO doors VALUES (836,4,'qeynos2','CRATEB',169.557,-360.156,0.002,16957,0,0,0,0);
INSERT INTO doors VALUES (837,5,'qeynos2','CRATEG',172.824,-365.722,0.752,17289,0,0,0,0);
INSERT INTO doors VALUES (838,6,'qeynos2','CRATEG',171.022,-365.252,0.002,17166,0,0,0,0);
INSERT INTO doors VALUES (839,7,'qeynos2','BARREL3',182.497,-349.656,0.002,17265,0,0,0,0);
INSERT INTO doors VALUES (840,8,'qeynos2','BARREL3',182.499,-372.634,0.002,17221,0,0,0,0);
INSERT INTO doors VALUES (841,9,'qeynos2','BARREL3',161.659,-373.738,0.002,17173,0,0,0,0);
INSERT INTO doors VALUES (842,10,'qeynos2','BARREL3',162.178,-351.627,0.002,17254,0,0,0,0);
INSERT INTO doors VALUES (843,11,'qeynos2','PAWHOOK',162.254,-353.482,3.002,17343,0,0,0,0);
INSERT INTO doors VALUES (844,12,'qeynos2','PAWHOOK',181.154,-372.601,3.002,17283,0,0,0,0);
INSERT INTO doors VALUES (845,13,'qeynos2','PAWHOOK',181,-350,3.002,17283,0,0,0,0);
INSERT INTO doors VALUES (846,14,'qeynos2','CRATED',195.958,575.372,0.002,17173,0,0,0,0);
INSERT INTO doors VALUES (847,15,'qeynos2','CRATEC',193.403,566.321,0.002,17300,0,0,0,0);
INSERT INTO doors VALUES (848,16,'qeynos2','CRATEB',187.796,568.589,0.002,17024,0,0,0,0);
INSERT INTO doors VALUES (849,17,'qeynos2','CRATEA',191.263,575.8,0.002,17257,0,0,0,0);
INSERT INTO doors VALUES (850,18,'qeynos2','BARREL3',203.149,559.603,0.002,17211,0,0,0,0);
INSERT INTO doors VALUES (851,19,'qeynos2','BARREL3',203.238,580.478,0.002,17273,0,0,0,0);
INSERT INTO doors VALUES (852,20,'qeynos2','BARREL3',180.376,582.167,0.002,17302,0,0,0,0);
INSERT INTO doors VALUES (853,21,'qeynos2','BARREL3',178.872,562.101,0.002,17288,0,0,0,0);
INSERT INTO doors VALUES (854,22,'qeynos2','PAWHOOK',180.432,581.197,3.002,17341,0,0,0,0);
INSERT INTO doors VALUES (855,23,'qeynos2','PAWHOOK',182.049,582.064,3.002,17405,0,0,0,0);
INSERT INTO doors VALUES (856,24,'qeynos2','PAWHOOK',181,561.75,3.002,17404,0,0,0,0);
INSERT INTO doors VALUES (857,25,'qeynos2','DOOR1',84.3751,39.8946,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (858,26,'qeynos2','DOOR1',129.637,190.908,-32.9858,0,0,0,0,0);
INSERT INTO doors VALUES (859,27,'qeynos2','DOOR1',124.102,180.969,-32.9858,17280,0,0,0,0);
INSERT INTO doors VALUES (860,28,'qeynos2','DOOR1',281.979,334.677,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (861,29,'qeynos2','DOOR1',249.872,153.287,0.000894,17344,0,0,0,0);
INSERT INTO doors VALUES (862,30,'qeynos2','DOOR1',239.913,84.4073,0.000886,17152,0,0,0,0);
INSERT INTO doors VALUES (863,31,'qeynos2','DOOR1',267.939,281.915,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (864,32,'qeynos2','DOOR1',126.375,347.816,0.000997,0,0,0,0,0);
INSERT INTO doors VALUES (865,33,'qeynos2','DOOR1',98.3291,263.808,0.000994,16117,0,0,0,0);
INSERT INTO doors VALUES (866,34,'qeynos2','DOOR1',84.2358,207.847,0.001008,16133,0,0,0,0);
INSERT INTO doors VALUES (867,35,'qeynos2','DOOR1',14.6053,81.9501,0.001015,15887,0,0,0,0);
INSERT INTO doors VALUES (868,36,'qeynos2','DOOR1',41.7273,30.0313,0.001004,17280,0,0,0,0);
INSERT INTO doors VALUES (869,37,'qeynos2','DOOR1',28.4595,-58.0296,0.001013,15862,0,0,0,0);
INSERT INTO doors VALUES (870,38,'qeynos2','DOOR1',13.9766,-70.6204,0.001001,17344,0,0,0,0);
INSERT INTO doors VALUES (871,39,'qeynos2','DOOR1',-27.6452,-80.0158,0.000998,15949,0,0,0,0);
INSERT INTO doors VALUES (872,40,'qeynos2','DOOR1',-58.0333,-70.3602,0.001046,17344,0,0,0,0);
INSERT INTO doors VALUES (873,41,'qeynos2','DOOR1',-99.9773,-56.4738,0.001062,17344,0,0,0,0);
INSERT INTO doors VALUES (874,42,'qeynos2','DOOR1',-153.64,-44.0023,0.000968,15526,0,0,0,0);
INSERT INTO doors VALUES (875,43,'qeynos2','DOOR1',-95.8834,0.307603,0.000998,17153,0,0,0,0);
INSERT INTO doors VALUES (876,44,'qeynos2','DOOR1',151.882,28.7521,16.0446,17344,0,0,0,0);
INSERT INTO doors VALUES (877,45,'qeynos2','DOOR1',128.003,-28.8981,15.995,17152,0,0,0,0);
INSERT INTO doors VALUES (878,46,'qeynos2','DOOR1',137.933,-41.1786,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (879,47,'qeynos2','DOOR1',324.921,279.858,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (880,48,'qeynos2','HHCELL',68.1118,89.9202,-32.9858,0,0,0,0,0);
INSERT INTO doors VALUES (881,49,'qeynos2','HHCELL',72.9733,62.7922,-32.9858,17152,0,0,0,0);
INSERT INTO doors VALUES (882,50,'qeynos2','HHCELL',96.981,63.0283,-32.9858,17152,0,0,0,0);
INSERT INTO doors VALUES (883,51,'qeynos2','HHCELL',112.062,80.058,-32.9858,17280,0,0,0,0);
INSERT INTO doors VALUES (884,52,'qeynos2','SPEARDOWN',34.5967,146.889,-69.971,0,66,0,0,0);
INSERT INTO doors VALUES (885,53,'qeynos2','DOOR2',-139.149,-156.001,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (886,54,'qeynos2','DOOR2',-113.999,-141.097,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (887,55,'qeynos2','DOOR1',40.0381,309.373,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (888,56,'qeynos2','DOOR1',39.3468,28.5068,12.001,17149,54,0,0,0);
INSERT INTO doors VALUES (889,57,'qeynos2','DOOR1',69.8322,0.82502,29.9597,17150,54,0,0,0);
INSERT INTO doors VALUES (890,58,'qeynos2','DOOR1',89.7017,-0.279808,30.0805,17344,54,0,0,0);
INSERT INTO doors VALUES (891,59,'qeynos2','DOOR1',312.024,279.822,29.501,17152,54,0,0,0);
INSERT INTO doors VALUES (892,60,'qeynos2','DOOR1',302.027,279.875,29.251,17151,54,0,0,0);
INSERT INTO doors VALUES (893,61,'qeynos2','DOOR1',261.463,335.875,29.751,17344,54,0,0,0);
INSERT INTO doors VALUES (894,62,'qeynos2','DOOR1',270.22,335.875,29.751,17344,54,0,0,0);
INSERT INTO doors VALUES (895,63,'qeynos2','DOOR1',321.625,278.87,29.4964,17280,54,0,0,0);
INSERT INTO doors VALUES (896,64,'qeynos2','DOOR1',137.845,-29.2732,25.7982,17156,54,0,0,0);
INSERT INTO doors VALUES (897,65,'qeynos2','DOOR1',128.184,-29.5555,25.751,17154,54,0,0,0);
INSERT INTO doors VALUES (898,66,'qeynos2','CRATEF',178.514,-365.123,0.002,17317,0,0,0,0);
INSERT INTO doors VALUES (899,67,'qeynos2','CRATEG',190.181,570.061,1.252,17310,0,0,0,0);
INSERT INTO doors VALUES (900,68,'qeynos2','CRATEF',191.294,566.455,3.002,17264,0,0,0,0);
INSERT INTO doors VALUES (901,69,'qeynos2','CRATEB',199.114,566.89,0.002,17163,0,0,0,0);
INSERT INTO doors VALUES (902,1,'rivervale','VUDOOR',-225.784,-95.7902,-21.9163,17152,0,0,0,0);
INSERT INTO doors VALUES (903,2,'rivervale','VUDOOR',-239.993,-117.925,-19.9911,17280,0,0,0,0);
INSERT INTO doors VALUES (904,3,'rivervale','VUDOOR',-206.017,-156.166,-19.8753,17344,0,0,0,0);
INSERT INTO doors VALUES (905,4,'rivervale','VUDOOR',-179.767,-122.024,-21.9895,0,0,0,0,0);
INSERT INTO doors VALUES (906,5,'rivervale','VUDOOR',70.9767,-152.022,2.05021,0,0,0,0,0);
INSERT INTO doors VALUES (907,6,'rivervale','VUDOOR',-106.145,-133.989,0.000963,0,0,0,0,0);
INSERT INTO doors VALUES (908,7,'rivervale','VUDOOR',-23.913,-187.933,0.00097,0,0,0,0,0);
INSERT INTO doors VALUES (909,8,'rivervale','VUDOOR',-63.8961,-155.826,0.000963,17152,0,0,0,0);
INSERT INTO doors VALUES (910,9,'rivervale','VUDOOR',-231.793,-335.346,-15.9927,17152,0,0,0,0);
INSERT INTO doors VALUES (911,10,'rivervale','VUDOOR',-85.1069,-393.679,-13.992,17280,0,0,0,0);
INSERT INTO doors VALUES (912,11,'rivervale','VUDOOR',37.0835,-337.87,-5.99656,0,0,0,0,0);
INSERT INTO doors VALUES (913,12,'rivervale','VUDOOR',21.8645,-385.774,-3.99742,17344,0,0,0,0);
INSERT INTO doors VALUES (914,13,'rivervale','VUDOOR',197.882,-237.834,0.001001,17280,0,0,0,0);
INSERT INTO doors VALUES (915,14,'rivervale','VUDOOR',253.02,-217.949,0.001007,0,0,0,0,0);
INSERT INTO doors VALUES (916,15,'rivervale','VUDOOR',213.829,-109.027,-11.9943,17344,0,0,0,0);
INSERT INTO doors VALUES (917,16,'rivervale','VUDOOR',166.919,-70.0388,0.000967,17280,0,0,0,0);
INSERT INTO doors VALUES (918,17,'rivervale','VUDOOR',142.834,-46.0238,0.001018,17280,0,0,0,0);
INSERT INTO doors VALUES (919,18,'rivervale','VUDOOR',-165.866,-202.875,0.00097,17152,0,0,0,0);
INSERT INTO doors VALUES (920,19,'rivervale','VUDOOR',-206.871,-191.971,0.00097,0,0,0,0,0);
INSERT INTO doors VALUES (921,20,'rivervale','VUDOOR',383.846,-417.745,-5.9966,17280,0,0,0,0);
INSERT INTO doors VALUES (922,21,'rivervale','VUDOOR',443.643,-421.987,-3.99734,16363,0,0,0,0);
INSERT INTO doors VALUES (923,22,'rivervale','VUDOOR',421.912,-396.027,-7.94576,17152,0,0,0,0);
INSERT INTO doors VALUES (924,23,'rivervale','VUDOOR',82.7034,-143.313,49.933,17155,54,0,0,0);
INSERT INTO doors VALUES (925,1,'misty','HOBDOOR',-343.184,-1154.75,-0.248789,17280,0,0,0,0);
INSERT INTO doors VALUES (926,2,'misty','HOBDOOR',-879.592,-2267.34,0.063963,0,0,0,0,0);
INSERT INTO doors VALUES (927,3,'misty','HOBDOOR',792.769,-1955.78,-7.24673,17344,0,0,0,0);
INSERT INTO doors VALUES (928,4,'misty','HOBDOOR',836.777,-1932.87,-7.2893,17152,0,0,0,0);
INSERT INTO doors VALUES (929,5,'misty','HOBDOOR',879.278,-2341.89,-7.41807,0,0,0,0,0);
INSERT INTO doors VALUES (930,6,'misty','HOBDOOR',589.563,-2334.56,-7.35088,17344,0,0,0,0);
INSERT INTO doors VALUES (931,7,'misty','HOBDOOR',650.877,-2212.76,-7.2893,0,0,0,0,0);
INSERT INTO doors VALUES (932,8,'misty','HOBDOOR',577.665,-2224.1,-7.2893,17152,0,0,0,0);
INSERT INTO doors VALUES (933,9,'misty','HOBDOOR',349.727,-2279.08,-7.2893,17280,0,0,0,0);
INSERT INTO doors VALUES (934,1,'felwithea','FELDOOR',39.9151,-253.424,-15.9926,17344,0,0,0,0);
INSERT INTO doors VALUES (935,2,'felwithea','DOOR1',-63.4873,-359.853,0.00097,17280,0,0,0,0);
INSERT INTO doors VALUES (936,3,'felwithea','DOOR1',217.903,-377.277,0.00097,17344,0,0,0,0);
INSERT INTO doors VALUES (937,4,'felwithea','DOOR1',217.888,-363.372,0.00097,17344,0,0,0,0);
INSERT INTO doors VALUES (938,5,'felwithea','FELDOOR2',8.0847,-496.733,-3.99741,17152,15,0,0,0);
INSERT INTO doors VALUES (939,6,'felwithea','FELDOOR',-4.96559,-220.903,-15.9926,17152,15,0,0,0);
INSERT INTO doors VALUES (940,7,'felwithea','FELDOOR',30.0331,-253.977,0.000969,17152,15,0,0,0);
INSERT INTO doors VALUES (941,8,'felwithea','FELDOOR',-30.0514,-254.877,0.000969,17344,15,0,0,0);
INSERT INTO doors VALUES (942,9,'felwithea','DOOR1',-14.0405,-365.871,0.000969,0,0,0,0,0);
INSERT INTO doors VALUES (943,10,'felwithea','DOOR1',-71.0872,-459.802,0.000969,17280,0,0,0,0);
INSERT INTO doors VALUES (944,11,'felwithea','DOOR1',-69.9116,-404.686,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (945,12,'felwithea','DOOR1',-110.001,-404.418,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (946,13,'felwithea','DOOR1',165.911,-612.873,-13.9934,17344,0,0,0,0);
INSERT INTO doors VALUES (947,14,'felwithea','DOOR1',251.535,-645.84,-13.9934,0,5,0,0,0);
INSERT INTO doors VALUES (948,15,'felwithea','DOOR1',99.9976,-404.675,0.000969,17152,5,0,0,0);
INSERT INTO doors VALUES (949,16,'felwithea','DOOR1',138.821,-389.82,0.000969,17280,0,0,0,0);
INSERT INTO doors VALUES (950,17,'felwithea','DOOR1',163.933,-363.51,0.000969,17344,5,0,0,0);
INSERT INTO doors VALUES (951,18,'felwithea','DOOR1',169.962,-362.479,0.000969,17152,0,0,0,0);
INSERT INTO doors VALUES (952,19,'felwithea','DOOR1',183.946,-362.249,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (953,20,'felwithea','DOOR1',151.896,-378.336,13.9954,17344,0,0,0,0);
INSERT INTO doors VALUES (954,21,'felwithea','DOOR1',141.971,-362.647,13.9954,17152,0,0,0,0);
INSERT INTO doors VALUES (955,22,'felwithea','DOOR1',126.539,-333.777,0.000969,17280,0,0,0,0);
INSERT INTO doors VALUES (956,23,'felwithea','DOOR1',69.0496,-337.869,-13.9934,16568,0,0,0,0);
INSERT INTO doors VALUES (957,24,'felwithea','DOOR1',56.0524,-362.145,-13.9934,17152,0,0,0,0);
INSERT INTO doors VALUES (958,25,'felwithea','FELDOOR',-30.0349,-253.491,-15.9926,17344,2,0,0,0);
INSERT INTO doors VALUES (959,26,'felwithea','DOOR1',-123.909,-320.231,0.00097,17152,0,0,0,0);
INSERT INTO doors VALUES (960,27,'felwithea','DOOR1',-109.867,-448.562,0.00097,17152,0,0,0,0);
INSERT INTO doors VALUES (961,28,'felwithea','DOOR1',-114.855,-475.729,9.501,17271,54,0,0,0);
INSERT INTO doors VALUES (962,29,'felwithea','DOOR1',0.255522,-512.031,10.001,17152,54,0,0,0);
INSERT INTO doors VALUES (963,30,'felwithea','DOOR1',18.3821,-512.031,9.92579,17152,54,0,0,0);
INSERT INTO doors VALUES (964,31,'felwithea','DOOR1',9.05001,-511.81,10.001,17152,54,0,0,0);
INSERT INTO doors VALUES (965,1,'felwitheb','FELDOOR',409.75,-886.84,-7.9958,17344,15,0,0,0);
INSERT INTO doors VALUES (966,2,'felwitheb','FELDOOR',395.544,-841.683,-7.9958,0,15,0,0,0);
INSERT INTO doors VALUES (967,3,'felwitheb','FELDOOR',415.048,-841.738,-7.9958,0,15,0,0,0);
INSERT INTO doors VALUES (968,4,'felwitheb','FELDOOR',408.29,-788.774,-7.9958,17280,15,0,0,0);
INSERT INTO doors VALUES (969,5,'felwitheb','FELDOOR2',510.185,-841.586,0.001,17280,15,0,0,0);
INSERT INTO doors VALUES (970,6,'felwitheb','FELDOOR',419.081,-596.778,14.995,0,2,0,0,0);
INSERT INTO doors VALUES (971,7,'felwitheb','FELDOOR',445.743,-426.687,0.001,17348,2,0,0,0);
INSERT INTO doors VALUES (972,8,'felwitheb','FELDOOR',435.913,-358.295,0.001,17152,2,0,0,0);
INSERT INTO doors VALUES (973,9,'felwitheb','FELDOOR',547.787,-768.585,0.001,17152,2,0,0,0);
INSERT INTO doors VALUES (974,10,'felwitheb','FELDOOR',617.689,-903.12,0.001,17344,2,0,0,0);
INSERT INTO doors VALUES (975,11,'felwitheb','FELDOOR',497.79,-902.998,0.001,17344,2,0,0,0);
INSERT INTO doors VALUES (976,12,'felwitheb','FELDOOR',629.639,-575.839,0.001,0,2,0,0,0);
INSERT INTO doors VALUES (977,13,'felwitheb','FELDOOR',738.117,-609.747,0.002,17280,2,0,0,0);
INSERT INTO doors VALUES (978,14,'felwitheb','FELDOOR',753.441,-609.825,0.002,0,2,0,0,0);
INSERT INTO doors VALUES (979,15,'felwitheb','FELDOOR',498.898,-469.84,0.001,17152,2,0,0,0);
INSERT INTO doors VALUES (980,1,'gfaydark','FAYDOOR',-199.033,-604.634,157.971,0,0,0,0,0);
INSERT INTO doors VALUES (981,2,'gfaydark','FAYDOOR',-119.525,-560.576,157.971,0,0,0,0,0);
INSERT INTO doors VALUES (982,3,'gfaydark','FAYDOOR',-377.26,-605.551,157.968,17377,0,0,0,0);
INSERT INTO doors VALUES (983,4,'gfaydark','FAYDOOR',-378.764,-325.503,157.97,17376,0,0,0,0);
INSERT INTO doors VALUES (984,5,'gfaydark','FAYDOOR2A',-488.62,-230.471,157.979,17212,0,0,0,0);
INSERT INTO doors VALUES (985,6,'gfaydark','FAYDOOR2',-481.21,-222.911,157.979,17221,5,0,0,0);
INSERT INTO doors VALUES (986,7,'gfaydark','FAYDOOR2A',-520.268,-198.796,157.979,17218,0,0,0,0);
INSERT INTO doors VALUES (987,8,'gfaydark','FAYDOOR2',-512.795,-191.396,157.979,17212,5,0,0,0);
INSERT INTO doors VALUES (988,9,'gfaydark','FAYDOOR',-501.359,-560.915,157.919,17280,0,0,0,0);
INSERT INTO doors VALUES (989,10,'gfaydark','FAYDOOR',-263.603,-420.027,114.4,0,0,0,0,0);
INSERT INTO doors VALUES (990,11,'gfaydark','FAYDOOR',-291.006,-341.331,114.393,17024,0,0,0,0);
INSERT INTO doors VALUES (991,12,'gfaydark','FAYDOOR',-359.577,-187.18,73.9681,17312,0,0,0,0);
INSERT INTO doors VALUES (992,13,'gfaydark','FAYDOOR',-389.148,-158.042,73.9681,17312,0,0,0,0);
INSERT INTO doors VALUES (993,14,'gfaydark','FAYDOOR',-481.767,-136.544,73.8657,17280,0,0,0,0);
INSERT INTO doors VALUES (994,15,'gfaydark','FAYDOOR',-342.192,-46.3165,73.9703,17152,0,0,0,0);
INSERT INTO doors VALUES (995,16,'gfaydark','FAYDOOR',-225.203,-252.983,74.0132,17375,0,0,0,0);
INSERT INTO doors VALUES (996,17,'gfaydark','FAYDOOR',-106.946,-223.895,72.5828,17344,0,0,0,0);
INSERT INTO doors VALUES (997,18,'gfaydark','FAYDOOR',-61.1517,-223.726,72.5828,17344,0,0,0,0);
INSERT INTO doors VALUES (998,19,'gfaydark','FAYDOOR',-53.2915,-102.293,73.9681,17024,0,0,0,0);
INSERT INTO doors VALUES (999,20,'gfaydark','FAYDOOR',-208.924,126.264,114.47,17025,0,0,0,0);
INSERT INTO doors VALUES (1000,21,'gfaydark','FAYDOOR',-349.122,138.796,114.391,17220,0,0,0,0);
INSERT INTO doors VALUES (1001,22,'gfaydark','FAYDOOR',-329.063,118.705,114.394,17216,0,0,0,0);
INSERT INTO doors VALUES (1002,23,'gfaydark','FAYDOOR',-557.78,59.1166,157.973,17280,0,0,0,0);
INSERT INTO doors VALUES (1003,24,'gfaydark','FAYDOOR',-88.1368,208.585,73.9679,17152,0,0,0,0);
INSERT INTO doors VALUES (1004,25,'gfaydark','FAYDOOR2A',-254.457,259.732,73.9584,17216,0,0,0,0);
INSERT INTO doors VALUES (1005,26,'gfaydark','FAYDOOR2',-246.907,267.168,73.9584,17213,5,0,0,0);
INSERT INTO doors VALUES (1006,27,'gfaydark','FAYDOOR2',-215.166,235.796,73.9584,17216,5,0,0,0);
INSERT INTO doors VALUES (1007,28,'gfaydark','FAYDOOR2A',-222.582,228.299,73.9584,17217,0,0,0,0);
INSERT INTO doors VALUES (1008,29,'gfaydark','FAYDOOR',356.577,284.6,73.9568,17313,0,0,0,0);
INSERT INTO doors VALUES (1009,30,'gfaydark','FAYDOOR',410.278,438.574,73.9677,17152,0,0,0,0);
INSERT INTO doors VALUES (1010,31,'gfaydark','FAYDOOR2',261.248,468.973,73.9418,17025,5,0,0,0);
INSERT INTO doors VALUES (1011,32,'gfaydark','FAYDOOR2A',253.833,476.428,73.9418,17024,0,0,0,0);
INSERT INTO doors VALUES (1012,33,'gfaydark','FAYDOOR',225.455,613.309,73.9659,0,0,0,0,0);
INSERT INTO doors VALUES (1013,34,'gfaydark','FAYDOOR',128.575,763.192,73.9598,17152,0,0,0,0);
INSERT INTO doors VALUES (1014,35,'gfaydark','FAYDOOR',-153.742,673.938,114.398,17219,0,0,0,0);
INSERT INTO doors VALUES (1015,36,'gfaydark','FAYDOOR',-175.51,617.472,114.398,17280,0,0,0,0);
INSERT INTO doors VALUES (1016,37,'gfaydark','FAYDOOR',-20.149,407.213,157.981,0,0,0,0,0);
INSERT INTO doors VALUES (1017,38,'gfaydark','FAYDOOR',10.168,122.759,157.963,0,0,0,0,0);
INSERT INTO doors VALUES (1018,39,'gfaydark','FAYDOOR',-18.4667,122.709,157.963,0,0,0,0,0);
INSERT INTO doors VALUES (1019,40,'gfaydark','FAYDOOR',-286.079,461.75,114.47,17029,0,0,0,0);
INSERT INTO doors VALUES (1020,41,'gfaydark','FAYDOOR2',-396.541,466.684,114.4,17217,5,0,0,0);
INSERT INTO doors VALUES (1021,42,'gfaydark','FAYDOOR2A',-404.024,459.312,114.4,17214,0,0,0,0);
INSERT INTO doors VALUES (1022,43,'gfaydark','FAYDOOR',442.036,676.65,114.398,17280,0,0,0,0);
INSERT INTO doors VALUES (1023,44,'gfaydark','FAYDOOR',468.04,685.386,114.394,17020,0,0,0,0);
INSERT INTO doors VALUES (1024,45,'gfaydark','FAYDOOR',341.793,345.803,157.976,17280,0,0,0,0);
INSERT INTO doors VALUES (1025,46,'gfaydark','FAYDOOR',413.648,278.444,157.963,17344,0,0,0,0);
INSERT INTO doors VALUES (1026,47,'gfaydark','FAYDOOR',600.029,626.57,157.97,17152,0,0,0,0);
INSERT INTO doors VALUES (1027,48,'gfaydark','FAYDOOR',619.696,432.089,157.963,17021,0,0,0,0);
INSERT INTO doors VALUES (1028,49,'gfaydark','FAYDOOR',585.802,297.976,157.973,17344,0,0,0,0);
INSERT INTO doors VALUES (1029,50,'gfaydark','FAYDOOR',641.919,85.7735,73.967,17280,0,0,0,0);
INSERT INTO doors VALUES (1030,51,'gfaydark','FAYDOOR',817.905,95.4094,73.9672,0,0,0,0,0);
INSERT INTO doors VALUES (1031,52,'gfaydark','FAYDOOR',943.848,168.247,73.8918,17376,0,0,0,0);
INSERT INTO doors VALUES (1032,53,'gfaydark','FAYDOOR',932.334,289.632,74.0435,17023,0,0,0,0);
INSERT INTO doors VALUES (1033,54,'gfaydark','FAYDOOR',731.452,467.225,72.9369,17152,0,0,0,0);
INSERT INTO doors VALUES (1034,55,'gfaydark','FAYDOOR',731.482,438.555,72.9369,17152,0,0,0,0);
INSERT INTO doors VALUES (1035,56,'gfaydark','FAYDOOR2',726.865,-139.166,73.9418,17344,5,0,0,0);
INSERT INTO doors VALUES (1036,57,'gfaydark','FAYDOOR2A',737.368,-139.146,73.9418,17344,0,0,0,0);
INSERT INTO doors VALUES (1037,58,'gfaydark','FAYDOOR2A',737.336,-184.045,73.9418,17344,0,0,0,0);
INSERT INTO doors VALUES (1038,59,'gfaydark','FAYDOOR2',726.833,-184.019,73.9418,17344,5,0,0,0);
INSERT INTO doors VALUES (1039,60,'gfaydark','FAYDOOR2',1026.91,571.206,114.399,0,5,0,0,0);
INSERT INTO doors VALUES (1040,61,'gfaydark','FAYDOOR2A',1026.91,581.735,114.399,0,0,0,0,0);
INSERT INTO doors VALUES (1041,62,'gfaydark','FAYDOOR',938.546,645.444,114.398,17152,0,0,0,0);
INSERT INTO doors VALUES (1042,63,'gfaydark','FAYDOOR2',-651.877,229.565,73.9383,17280,5,0,0,0);
INSERT INTO doors VALUES (1043,64,'gfaydark','FAYDOOR2A',-651.86,218.999,73.9383,17280,0,0,0,0);
INSERT INTO doors VALUES (1044,65,'gfaydark','FAYDOOR2',-607.347,229.438,73.9383,17280,5,0,0,0);
INSERT INTO doors VALUES (1045,66,'gfaydark','FAYDOOR2A',-607.32,218.969,73.9383,17280,0,0,0,0);
INSERT INTO doors VALUES (1046,67,'gfaydark','FAYDOOR',-636.254,342.003,74.0064,17221,0,0,0,0);
INSERT INTO doors VALUES (1047,68,'gfaydark','FAYLEVATOR',137.463,350.014,2.1582,17344,59,0,0,0);
INSERT INTO doors VALUES (1048,69,'gfaydark','FELE2',128.17,238.669,8.9092,17280,59,0,0,0);
INSERT INTO doors VALUES (1049,70,'gfaydark','FELE2',152.396,271.107,77.4681,17342,59,0,0,0);
INSERT INTO doors VALUES (1050,71,'gfaydark','FAYDOOR',-489.02,135.337,157.981,17152,0,0,0,0);
INSERT INTO doors VALUES (1051,72,'gfaydark','FAYLEVATOR',872.302,221.448,-27.6523,0,59,0,0,0);
INSERT INTO doors VALUES (1052,73,'gfaydark','FELE2',950.314,236.218,77.9202,17146,59,0,0,0);
INSERT INTO doors VALUES (1053,74,'gfaydark','FELE2',983.996,212.27,-20.4945,17340,59,0,0,0);
INSERT INTO doors VALUES (1054,75,'gfaydark','FAYLEVATOR',-88.6519,-136.173,2.4082,0,59,0,0,0);
INSERT INTO doors VALUES (1055,76,'gfaydark','FELE2',24.2785,-146.716,9.58386,17139,59,0,0,0);
INSERT INTO doors VALUES (1056,77,'gfaydark','FELE2',-10.2559,-121.795,78.1702,17151,59,0,0,0);
INSERT INTO doors VALUES (1057,78,'gfaydark','FAYLEVATOR',-1895.94,-426.813,34.6542,17391,54,0,0,0);
INSERT INTO doors VALUES (1058,79,'gfaydark','FAYLEVATOR',-1912.85,-364.028,36.3052,17329,54,0,0,0);
INSERT INTO doors VALUES (1059,80,'gfaydark','FAYLEVATOR',-1886.11,-374.167,37.5796,17329,54,0,0,0);
INSERT INTO doors VALUES (1060,81,'gfaydark','FAYLEVATOR',-1877.19,-400.018,35.4447,17248,54,0,0,0);
INSERT INTO doors VALUES (1061,82,'gfaydark','FAYLEVATOR',-1948.66,-559.54,36.9793,17245,54,0,0,0);
INSERT INTO doors VALUES (1062,83,'gfaydark','FAYLEVATOR',-1961.11,-588.273,45.3572,17249,54,0,0,0);
INSERT INTO doors VALUES (1063,84,'gfaydark','FAYLEVATOR',-1983.66,-601.287,41.042,17092,54,0,0,0);
INSERT INTO doors VALUES (1064,85,'gfaydark','FAYLEVATOR',-2009.59,-588.683,39.9885,17085,54,0,0,0);
INSERT INTO doors VALUES (1065,86,'gfaydark','FAYDOOR',-1968.88,-603.093,20.2197,17212,54,0,0,0);
INSERT INTO doors VALUES (1066,87,'gfaydark','FAYDOOR',-2025.98,-577.229,15.9977,17091,54,0,0,0);
INSERT INTO doors VALUES (1067,88,'gfaydark','FAYLEVATOR',-2130.44,-537.21,27.7227,17086,54,0,0,0);
INSERT INTO doors VALUES (1068,89,'gfaydark','FAYLEVATOR',-2162.33,-523.784,27.1563,17085,54,0,0,0);
INSERT INTO doors VALUES (1069,90,'gfaydark','FAYLEVATOR',-2173.02,-500.114,39.0774,17393,54,0,0,0);
INSERT INTO doors VALUES (1070,91,'gfaydark','FAYDOOR',-2177.42,-510.482,10.062,17390,54,0,0,0);
INSERT INTO doors VALUES (1071,92,'gfaydark','FAYLEVATOR',-2157.82,-465.028,37.412,17391,54,0,0,0);
INSERT INTO doors VALUES (1072,93,'gfaydark','FAYDOOR',-2162.74,-479.84,18.1978,17386,54,0,0,0);
INSERT INTO doors VALUES (1073,94,'gfaydark','FAYLEVATOR',-2106.12,-334.651,24.5783,17391,54,0,0,0);
INSERT INTO doors VALUES (1074,95,'gfaydark','FAYLEVATOR',-2091.59,-300.849,25.8372,17391,54,0,0,0);
INSERT INTO doors VALUES (1075,96,'gfaydark','FAYDOOR',-2096.38,-314.908,3.23129,17392,54,0,0,0);
INSERT INTO doors VALUES (1076,97,'gfaydark','FAYLEVATOR',-2066.78,-291.797,28.5482,17328,54,0,0,0);
INSERT INTO doors VALUES (1077,98,'gfaydark','FAYDOOR',-2079.05,-288.097,6.11266,17328,54,0,0,0);
INSERT INTO doors VALUES (1078,99,'gfaydark','FAYLEVATOR',-2033.83,-306.659,29.6945,17325,54,0,0,0);
INSERT INTO doors VALUES (1079,100,'gfaydark','FAYDOOR',-2047.37,-302.381,5.89266,17326,54,0,0,0);
INSERT INTO doors VALUES (1080,1,'oggok','DOOR620X20',279.28,-154.928,0.001,17280,5,0,0,0);
INSERT INTO doors VALUES (1081,2,'oggok','DOOR620X20',278.553,-196.868,0.001,17280,5,0,0,0);
INSERT INTO doors VALUES (1082,3,'oggok','DOOR620X20',334.65,-172.877,0.001,0,5,0,0,0);
INSERT INTO doors VALUES (1083,4,'oggok','DOOR620X20',334.406,-134.923,0.001,0,0,0,0,0);
INSERT INTO doors VALUES (1084,5,'oggok','DOOR620X20',164.932,-226.156,0.001,17344,0,0,0,0);
INSERT INTO doors VALUES (1085,6,'oggok','DOOR620X20',9.81649,-211.802,-10.9946,17344,0,0,0,0);
INSERT INTO doors VALUES (1086,7,'oggok','DOOR620X20',342.773,46.3589,1.0006,17344,0,0,0,0);
INSERT INTO doors VALUES (1087,8,'oggok','DOOR620X20',519.742,-211.159,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (1088,1,'grobb','DOOR620X20',421.71,-171.179,-9.78953,17265,54,0,0,0);
INSERT INTO doors VALUES (1089,2,'grobb','DOOR620X20',438.566,-183.191,-7.92203,17318,54,0,0,0);
INSERT INTO doors VALUES (1090,3,'grobb','GROBDOOR',469.282,-227.888,-9.995,17280,0,0,0,0);
INSERT INTO doors VALUES (1091,4,'grobb','GROBDOOR',423.749,-571.517,9.997,17344,5,0,0,0);
INSERT INTO doors VALUES (1092,5,'grobb','GROBDOOR',-24.2035,-452.04,69.973,0,5,0,0,0);
INSERT INTO doors VALUES (1093,6,'grobb','GROBDOOR',-85.7801,-447.907,75.9706,0,0,0,0,0);
INSERT INTO doors VALUES (1094,7,'grobb','GROBCAGEDR',-110.081,-469.434,75.9706,17152,0,0,0,0);
INSERT INTO doors VALUES (1095,8,'grobb','GROBCAGEDR',-88.1309,-469.954,75.9706,17344,6,0,0,0);
INSERT INTO doors VALUES (1096,9,'grobb','GROBCAGEDR',558.684,-386.293,-9.995,17399,6,0,0,0);
INSERT INTO doors VALUES (1097,10,'grobb','GROBCAGEDR',604.036,-459.657,-9.995,17226,6,0,0,0);
INSERT INTO doors VALUES (1098,11,'grobb','GROBCAGEDR',332.517,-40.0727,3.99941,16956,6,0,0,0);
INSERT INTO doors VALUES (1099,12,'grobb','GROBCAGEDR',466.936,-427.719,-9.995,17338,6,0,0,0);
INSERT INTO doors VALUES (1100,13,'grobb','GROBDOOR',513.717,-598.979,9.997,17344,0,0,0,0);
INSERT INTO doors VALUES (1101,14,'grobb','GROBDOOR',583.703,-667.073,9.997,17344,0,0,0,0);
INSERT INTO doors VALUES (1102,15,'grobb','DOOR620X20',126.387,-467.753,39.985,17280,0,0,0,0);
INSERT INTO doors VALUES (1103,16,'grobb','GROBDOOR',-93.9723,-433.021,75.9706,17344,0,0,0,0);
INSERT INTO doors VALUES (1104,17,'grobb','GROBDOOR',256.781,-465.812,13.9954,17280,0,0,0,0);
INSERT INTO doors VALUES (1105,18,'grobb','DOOR620X20',440.375,-181.627,-7.998,17317,54,0,0,0);
INSERT INTO doors VALUES (1106,1,'cabwest','KNDOOR102',-63.4673,687.855,0.001,17280,0,0,0,0);
INSERT INTO doors VALUES (1107,2,'cabwest','KNDOOR102',155.881,685.26,0.001,17152,0,0,0,0);
INSERT INTO doors VALUES (1108,3,'cabwest','KNDOOR102',-78.0266,631.573,0.002,17280,0,0,0,0);
INSERT INTO doors VALUES (1109,4,'cabwest','CRATEG',208.859,522.99,-9.88349,16683,53,0,0,0);
INSERT INTO doors VALUES (1110,5,'cabwest','CRATEG',265,529,-10.6243,0,53,0,0,0);
INSERT INTO doors VALUES (1111,6,'cabwest','CRATEG',395,588,2.25399,0,53,0,0,0);
INSERT INTO doors VALUES (1112,7,'cabwest','CRATEG',408,522,2.3478,0,53,0,0,0);
INSERT INTO doors VALUES (1113,8,'cabwest','CRATEG',349,530.5,2.65844,0,53,0,0,0);
INSERT INTO doors VALUES (1114,9,'cabwest','CRATEG',76.1621,509.25,99.167,16827,53,0,0,0);
INSERT INTO doors VALUES (1115,10,'cabwest','CRATEG',-32.4263,537.035,0.656775,17321,53,0,0,0);
INSERT INTO doors VALUES (1116,1,'timorous','FIRPOLE100',5857.5,3638.42,-53.4229,17313,0,0,0,0);
INSERT INTO doors VALUES (1117,2,'timorous','FIRPOLE100',5847.05,3628.37,-53.6906,17027,0,0,0,0);
INSERT INTO doors VALUES (1118,3,'timorous','FIRPOLE200',5891.25,3603,-2.47329,17377,30,0,0,0);
INSERT INTO doors VALUES (1119,4,'timorous','FIRPOLE200',5888.22,3599.86,-2.42011,17377,30,0,0,0);
INSERT INTO doors VALUES (1120,5,'timorous','FIRPOLE200',5885.23,3596.8,-2.46506,17377,30,0,0,0);
INSERT INTO doors VALUES (1121,6,'timorous','FAYBRAZIER',6029.66,3480.87,-2.72586,17315,145,0,0,0);
INSERT INTO doors VALUES (1122,7,'timorous','FAYBRAZIER',6017.5,3468.91,-2.814,17182,130,0,0,0);
INSERT INTO doors VALUES (1123,8,'timorous','BOAT',5890.92,3523,-4.87774,17225,30,0,0,0);
INSERT INTO doors VALUES (1124,9,'timorous','BOAT',5901.61,3534.08,-4.84637,17217,30,0,0,0);
INSERT INTO doors VALUES (1125,10,'timorous','BOAT',5913.48,3542.51,-4.92498,17373,30,0,0,0);
INSERT INTO doors VALUES (1126,11,'timorous','FIRPOLE100',5892.39,3546.16,-46.4453,17028,0,0,0,0);
INSERT INTO doors VALUES (1127,12,'timorous','FIRPOLE100',5872.62,3525.06,-45.9345,17031,0,0,0,0);
INSERT INTO doors VALUES (1128,13,'timorous','FIRPOLE200',5910.33,3565.93,-2.64036,17030,30,0,0,0);
INSERT INTO doors VALUES (1129,14,'timorous','FIRPOLE100',5888.48,3609.63,-52.7278,17314,0,0,0,0);
INSERT INTO doors VALUES (1130,15,'timorous','FIRPOLE100',5879.16,3598.5,-53.0009,17031,0,0,0,0);
INSERT INTO doors VALUES (1131,16,'timorous','FIRPOLE200',5916.42,3567.78,-2.3999,17377,30,0,0,0);
INSERT INTO doors VALUES (1132,17,'timorous','FIRPOLE200',5919.65,3571.42,-2.37479,17378,30,0,0,0);
INSERT INTO doors VALUES (1133,18,'timorous','FIRPOLE200',5922.66,3574.64,-2.36894,17378,30,0,0,0);
INSERT INTO doors VALUES (1134,19,'timorous','FIRPOLE100',5912.2,3567.85,-52.3516,17034,0,0,0,0);
INSERT INTO doors VALUES (1135,20,'timorous','FIRPOLE100',5922.87,3578.21,-52.3689,17313,0,0,0,0);
INSERT INTO doors VALUES (1136,21,'timorous','FIRPOLE200',5906.5,3576.99,-4.45053,17378,30,0,0,0);
INSERT INTO doors VALUES (1137,22,'timorous','FIRPOLE200',5908.8,3581.13,-2.53794,17220,30,0,0,0);
INSERT INTO doors VALUES (1138,23,'timorous','FIRPOLE200',5912.45,3583.8,-4.47538,17378,30,0,0,0);
INSERT INTO doors VALUES (1139,24,'timorous','FIRPOLE100',5938.08,3543.91,-52.6457,17026,0,0,0,0);
INSERT INTO doors VALUES (1140,25,'timorous','FIRPOLE100',5948.67,3555.1,-52.6133,17314,0,0,0,0);
INSERT INTO doors VALUES (1141,26,'timorous','FIRPOLE200',5940.44,3546.15,-5.10861,17377,30,0,0,0);
INSERT INTO doors VALUES (1142,27,'timorous','FIRPOLE200',5943.79,3549.45,-4.80243,17377,30,0,0,0);
INSERT INTO doors VALUES (1143,28,'timorous','FIRPOLE200',5946.67,3552.74,-4.31974,17377,30,0,0,0);
INSERT INTO doors VALUES (1144,29,'timorous','FIRPOLE100',5983.38,3523.22,-51.7813,17314,0,0,0,0);
INSERT INTO doors VALUES (1145,30,'timorous','FIRPOLE100',5973.18,3510.48,-51.705,17378,0,0,0,0);
INSERT INTO doors VALUES (1146,31,'timorous','FIRPOLE100',6009.17,3478.8,-51.6811,17028,0,0,0,0);
INSERT INTO doors VALUES (1147,32,'timorous','FIRPOLE100',6019.24,3489.11,-51.5562,17315,0,0,0,0);
INSERT INTO doors VALUES (1148,33,'timorous','FIRPOLE200',6021.1,3483.65,-4.86108,17219,30,0,0,0);
INSERT INTO doors VALUES (1149,34,'timorous','FIRPOLE200',6014.86,3477.25,-2.66883,17377,30,0,0,0);
INSERT INTO doors VALUES (1150,35,'timorous','FIRPOLE200',6018.03,3480.37,-4.7936,17219,35,0,0,0);
INSERT INTO doors VALUES (1151,36,'timorous','KURBRAZIER',-12321.8,4424.75,-282.935,0,57,0,0,0);
INSERT INTO doors VALUES (1152,37,'timorous','FREPORTBRA',-12317.3,4368.75,-282.935,17321,57,0,0,0);
INSERT INTO doors VALUES (1153,38,'timorous','SACBOWLFIR',-12320.5,4324.5,-277.935,17344,57,0,0,0);
INSERT INTO doors VALUES (1154,39,'timorous','FAYBRAZIER',-12296,4301.75,-282.685,17385,57,0,0,0);
INSERT INTO doors VALUES (1155,40,'timorous','KELBRAZ',-12249.8,4302,-282.935,17343,57,0,0,0);
INSERT INTO doors VALUES (1156,41,'timorous','NERBRAZIER',-12204,4301,-282.685,17388,57,0,0,0);
INSERT INTO doors VALUES (1157,42,'timorous','ERBRAZIER',-12189,4330,-282.685,17062,57,0,0,0);
INSERT INTO doors VALUES (1158,43,'timorous','OGBRAZIER',-12190,4373,-282.685,0,57,0,0,0);
INSERT INTO doors VALUES (1159,44,'timorous','CAMPFIRE',-12193,4415,-282.935,17404,57,0,0,0);
INSERT INTO doors VALUES (1160,45,'timorous','TIKI',-12220,4436,-282.935,17150,57,0,0,0);
INSERT INTO doors VALUES (1161,46,'timorous','AKALIGHT1',-12257,4437,-282.685,17146,57,0,0,0);
INSERT INTO doors VALUES (1162,47,'timorous','KALBRAZ',-12299,4439,-282.685,17280,57,0,0,0);
INSERT INTO doors VALUES (1163,1,'kithicor','DOOR1',1461.33,2291.42,295.388,17344,0,0,0,0);
INSERT INTO doors VALUES (1164,2,'kithicor','DOOR1',1438.04,2359.25,296.054,17106,0,0,0,0);
INSERT INTO doors VALUES (1165,3,'kithicor','DOOR1',-267.87,3968.36,494.966,17152,0,0,0,0);
INSERT INTO doors VALUES (1166,4,'kithicor','DOOR1',-294.407,3877.65,493.427,17280,0,0,0,0);
INSERT INTO doors VALUES (1167,5,'kithicor','DOOR1',-210.524,3846.66,492.617,17344,0,0,0,0);
INSERT INTO doors VALUES (1168,6,'kithicor','DOOR1',-290.225,3833.1,492.28,17344,0,0,0,0);
INSERT INTO doors VALUES (1169,7,'kithicor','DOOR1',-290.377,3788.13,492.359,17344,0,0,0,0);
INSERT INTO doors VALUES (1170,8,'kithicor','DOOR1',-744.843,3076.17,471.095,17280,0,0,0,0);
INSERT INTO doors VALUES (1171,9,'kithicor','BBDOOR1',-503.258,1981.08,235.357,0,0,0,0,0);
INSERT INTO doors VALUES (1172,10,'kithicor','DOOR1',1246.92,1071.74,117.322,0,0,0,0,0);
INSERT INTO doors VALUES (1173,11,'kithicor','DOOR1',1411.7,-829.058,-47.7649,0,0,0,0,0);
INSERT INTO doors VALUES (1174,12,'kithicor','DOOR1',1174.63,-689.547,-44.3046,17280,0,0,0,0);
INSERT INTO doors VALUES (1175,13,'kithicor','DOOR1',1129.79,-689.583,-44.0629,17280,0,0,0,0);
INSERT INTO doors VALUES (1176,14,'kithicor','DOOR1',220.612,90.2636,-17.0933,17176,0,0,0,0);
INSERT INTO doors VALUES (1177,15,'kithicor','DOOR1',1491.05,2320.96,296.19,0,0,0,0,0);
INSERT INTO doors VALUES (1178,1,'commons','CRATEA',-873.931,3558.75,-49.8687,17336,58,0,0,0);
INSERT INTO doors VALUES (1179,2,'commons','CRATEB',-868.555,3562.01,-50.1353,17251,58,0,0,0);
INSERT INTO doors VALUES (1180,3,'commons','CRATEF',-875.465,3557.06,-52.587,17336,58,0,0,0);
INSERT INTO doors VALUES (1181,4,'commons','CRATEF',-870.06,3561.54,-53.0237,17296,58,0,0,0);
INSERT INTO doors VALUES (1182,5,'commons','CRATEA',-871.462,3568.84,-52.9544,17151,58,0,0,0);
INSERT INTO doors VALUES (1183,6,'commons','CRATEA',-906.371,3646.16,-50.3852,17256,58,0,0,0);
INSERT INTO doors VALUES (1184,7,'commons','CRATEA',-914.001,3643.85,-47.6025,17264,58,0,0,0);
INSERT INTO doors VALUES (1185,8,'commons','CRATEF',-910.202,3638.72,-49.789,17377,58,0,0,0);
INSERT INTO doors VALUES (1186,9,'commons','CRATEB',-914.454,3643.88,-50.5231,16968,58,0,0,0);
INSERT INTO doors VALUES (1187,10,'commons','CAMPFIRE2',-882.426,3611.68,-52.5337,17406,58,0,0,0);
INSERT INTO doors VALUES (1188,11,'commons','CRATEA',1007.57,-826.169,-52.2167,17398,58,0,0,0);
INSERT INTO doors VALUES (1189,12,'commons','CRATEB',1007.32,-826.669,-55.2167,17382,58,0,0,0);
INSERT INTO doors VALUES (1190,13,'commons','CHAIR2',1035.81,-832.639,-55.2167,17311,58,0,0,0);
INSERT INTO doors VALUES (1191,14,'commons','CRATEA',1051.04,-837.622,-52.2167,17387,58,0,0,0);
INSERT INTO doors VALUES (1192,15,'commons','CRATEB',1050.97,-837.665,-55.2167,17347,58,0,0,0);
INSERT INTO doors VALUES (1193,16,'commons','CRATEB',1055.04,-859.463,-52.2167,17183,58,0,0,0);
INSERT INTO doors VALUES (1194,17,'commons','CRATEF',1054.92,-859.943,-55.2167,16854,58,0,0,0);
INSERT INTO doors VALUES (1195,18,'commons','CRATEA',1054.15,-853.373,-52.2167,17271,58,0,0,0);
INSERT INTO doors VALUES (1196,19,'commons','CRATEB',1054.85,-854.438,-55.2167,17208,58,0,0,0);
INSERT INTO doors VALUES (1197,20,'commons','NERBRAZIER',1010.6,-881.643,-55.2167,17075,58,0,0,0);
INSERT INTO doors VALUES (1198,21,'commons','NERBRAZIER',1017.72,-821.928,-55.2167,17347,58,0,0,0);
INSERT INTO doors VALUES (1199,22,'commons','NERBRAZIER',1038.8,-853.963,-55.2167,17261,58,0,0,0);
INSERT INTO doors VALUES (1200,23,'commons','CHAIR3',1030.97,-873.525,-55.2167,17206,58,0,0,0);
INSERT INTO doors VALUES (1201,24,'commons','BTENT',1041.38,-827.275,-55.2167,17310,58,0,0,0);
INSERT INTO doors VALUES (1202,25,'commons','BTENT1',1040.89,-884.856,-55.2167,17211,58,0,0,0);
INSERT INTO doors VALUES (1203,26,'commons','CAMPFIRE2',998.198,3168.18,-55.0605,17144,58,0,0,0);
INSERT INTO doors VALUES (1204,27,'commons','NTHRONE1',1031.67,3166.91,-55.0605,17271,58,0,0,0);
INSERT INTO doors VALUES (1205,28,'commons','NERBRAZIER',1028.81,3152.01,-55.0605,17266,58,0,0,0);
INSERT INTO doors VALUES (1206,29,'commons','NERBRAZIER',1029.9,3182.2,-55.0605,17286,58,0,0,0);
INSERT INTO doors VALUES (1207,30,'commons','BTENT1',1047.28,3165.9,-55.0605,17275,58,0,0,0);
INSERT INTO doors VALUES (1208,31,'commons','BTENT',1004.35,3137.07,-55.0605,17168,58,0,0,0);
INSERT INTO doors VALUES (1209,32,'commons','BTENT',1006.72,3196.09,-55.0605,17333,58,0,0,0);
INSERT INTO doors VALUES (1210,33,'commons','DOOR1',383.127,2420.82,-51.2352,0,0,0,0,0);
INSERT INTO doors VALUES (1211,34,'commons','DOOR1',-467.194,2805.89,-51.5346,17152,0,0,0,0);
INSERT INTO doors VALUES (1212,35,'commons','DOOR1',-454.994,2653.24,-51.9535,17344,0,0,0,0);
INSERT INTO doors VALUES (1213,36,'commons','DOOR1',-507.321,2599.44,-52.2715,17344,0,0,0,0);
INSERT INTO doors VALUES (1214,37,'commons','DOOR1',-143.332,485.926,-51.6884,17344,0,0,0,0);
INSERT INTO doors VALUES (1215,38,'commons','BBDOOR1',364.823,-17.1633,-52.0021,0,0,0,0,0);
INSERT INTO doors VALUES (1216,39,'commons','BBDOOR1',-714.642,244.415,-54.0004,17152,0,0,0,0);
INSERT INTO doors VALUES (1217,40,'commons','DOOR1',-192.112,574.196,-52.0777,17237,0,0,0,0);
INSERT INTO doors VALUES (1218,41,'commons','DOOR1',-254.193,527.991,-51.5865,17280,0,0,0,0);
INSERT INTO doors VALUES (1219,42,'commons','DOOR1',-151.242,1292.23,-52.2222,17152,0,0,0,0);
INSERT INTO doors VALUES (1220,43,'commons','DOOR1',-418.484,2719.55,-54.6791,0,0,0,0,0);
INSERT INTO doors VALUES (1221,44,'commons','DOOR1',1206.2,-1657.36,114.664,17332,54,0,0,0);
INSERT INTO doors VALUES (1222,45,'commons','BTENT',-903.649,3570.89,-51.2264,16927,58,0,0,0);
INSERT INTO doors VALUES (1223,46,'commons','BTENT',-898.758,3659.6,-51.2995,17371,58,0,0,0);
INSERT INTO doors VALUES (1224,47,'commons','BTENT1',-830.917,3608.23,-55.0605,17277,58,0,0,0);
INSERT INTO doors VALUES (1225,48,'commons','NTHRONE1',-845.697,3608.82,-54.5506,17280,58,0,0,0);
INSERT INTO doors VALUES (1226,49,'commons','NERBRAZIER',-885.727,3680.63,-52.505,17358,0,0,0,0);
INSERT INTO doors VALUES (1227,50,'commons','NERBRAZIER',-842.031,3628.23,-54.4751,17279,58,0,0,0);
INSERT INTO doors VALUES (1228,51,'commons','NERBRAZIER',-842.17,3588.6,-55.0605,17272,58,0,0,0);
INSERT INTO doors VALUES (1229,1,'ecommons','BBDOOR1',263.308,4889.43,-52.1715,17152,0,0,0,0);
INSERT INTO doors VALUES (1230,2,'ecommons','BBDOOR1',297.215,4847.43,-51.9283,16256,0,0,0,0);
INSERT INTO doors VALUES (1231,3,'ecommons','BBDOOR1',240.019,4755.9,-52.3623,17344,0,0,0,0);
INSERT INTO doors VALUES (1232,4,'ecommons','BBDOOR1',-100.439,4725.36,-53.9566,17280,0,0,0,0);
INSERT INTO doors VALUES (1233,5,'ecommons','BBDOOR1',320.371,4068.91,-52.6582,0,0,0,0,0);
INSERT INTO doors VALUES (1234,6,'ecommons','BBDOOR1',972.678,3741.07,-52.8213,17152,0,0,0,0);
INSERT INTO doors VALUES (1235,7,'ecommons','BBDOOR1',1002.17,3687.37,-53.2539,0,0,0,0,0);
INSERT INTO doors VALUES (1236,8,'ecommons','BBDOOR1',-300.137,3018.89,-54.792,17280,0,0,0,0);
INSERT INTO doors VALUES (1237,9,'ecommons','BBDOOR1',-272.171,3113.37,-58.0855,17152,0,0,0,0);
INSERT INTO doors VALUES (1238,10,'ecommons','DOOR1',-79.9643,1665.22,-52.4622,17280,0,0,0,0);
INSERT INTO doors VALUES (1239,11,'ecommons','BBDOOR1',-178.266,96.2232,-53.0117,17344,0,0,0,0);
INSERT INTO doors VALUES (1240,12,'ecommons','BBDOOR1',-165.287,111.514,-53.1063,17280,0,0,0,0);
INSERT INTO doors VALUES (1241,13,'ecommons','BBDOOR1',-124.208,213.158,-52.0733,17150,0,0,0,0);
INSERT INTO doors VALUES (1242,14,'ecommons','BBDOOR1',-130.177,48.5817,-54.0531,17343,0,0,0,0);
INSERT INTO doors VALUES (1243,15,'ecommons','BBDOOR1',168.111,-850.416,-52.6653,0,0,0,0,0);
INSERT INTO doors VALUES (1244,16,'ecommons','BBDOOR1',-160.463,-851.483,-52.4357,17280,0,0,0,0);
INSERT INTO doors VALUES (1245,17,'ecommons','BBDOOR1',-127.179,-804.898,-52.246,17152,0,0,0,0);
INSERT INTO doors VALUES (1246,18,'ecommons','DOOR1',1202.33,5052.74,122.096,16209,54,0,0,0);

--
-- Table structure for table 'faction_list'
--

CREATE TABLE faction_list (
  id int(11) NOT NULL auto_increment,
  name varchar(50) NOT NULL default '',
  base smallint(6) NOT NULL default '0',
  mod_c1 smallint(6) NOT NULL default '0',
  mod_c2 smallint(6) NOT NULL default '0',
  mod_c3 smallint(6) NOT NULL default '0',
  mod_c4 smallint(6) NOT NULL default '0',
  mod_c5 smallint(6) NOT NULL default '0',
  mod_c6 smallint(6) NOT NULL default '0',
  mod_c7 smallint(6) NOT NULL default '0',
  mod_c8 smallint(6) NOT NULL default '0',
  mod_c9 smallint(6) NOT NULL default '0',
  mod_c10 smallint(6) NOT NULL default '0',
  mod_c11 smallint(6) NOT NULL default '0',
  mod_c12 smallint(6) NOT NULL default '0',
  mod_c13 smallint(6) NOT NULL default '0',
  mod_c14 smallint(6) NOT NULL default '0',
  mod_c15 smallint(6) NOT NULL default '0',
  mod_r1 smallint(6) NOT NULL default '0',
  mod_r2 smallint(6) NOT NULL default '0',
  mod_r3 smallint(6) NOT NULL default '0',
  mod_r4 smallint(6) NOT NULL default '0',
  mod_r5 smallint(6) NOT NULL default '0',
  mod_r6 smallint(6) NOT NULL default '0',
  mod_r7 smallint(6) NOT NULL default '0',
  mod_r8 smallint(6) NOT NULL default '0',
  mod_r9 smallint(6) NOT NULL default '0',
  mod_r10 smallint(6) NOT NULL default '0',
  mod_r11 smallint(6) NOT NULL default '0',
  mod_r12 smallint(6) NOT NULL default '0',
  mod_r14 smallint(6) NOT NULL default '0',
  mod_r60 smallint(6) NOT NULL default '0',
  mod_r75 smallint(6) NOT NULL default '0',
  mod_r108 smallint(6) NOT NULL default '0',
  mod_r120 smallint(6) NOT NULL default '0',
  mod_r128 smallint(6) NOT NULL default '0',
  mod_r130 smallint(6) NOT NULL default '0',
  mod_r161 smallint(6) NOT NULL default '0',
  mod_d140 smallint(6) NOT NULL default '0',
  mod_d201 smallint(6) NOT NULL default '0',
  mod_d202 smallint(6) NOT NULL default '0',
  mod_d203 smallint(6) NOT NULL default '0',
  mod_d204 smallint(6) NOT NULL default '0',
  mod_d205 smallint(6) NOT NULL default '0',
  mod_d206 smallint(6) NOT NULL default '0',
  mod_d207 smallint(6) NOT NULL default '0',
  mod_d208 smallint(6) NOT NULL default '0',
  mod_d209 smallint(6) NOT NULL default '0',
  mod_d210 smallint(6) NOT NULL default '0',
  mod_d211 smallint(6) NOT NULL default '0',
  mod_d212 smallint(6) NOT NULL default '0',
  mod_d213 smallint(6) NOT NULL default '0',
  mod_d214 smallint(6) NOT NULL default '0',
  mod_d215 smallint(6) NOT NULL default '0',
  mod_d216 smallint(6) NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'faction_list'
--


INSERT INTO faction_list VALUES (1,'Beta Neutral',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

--
-- Table structure for table 'faction_values'
--

CREATE TABLE faction_values (
  char_id int(4) NOT NULL default '0',
  faction_id int(4) NOT NULL default '0',
  current_value smallint(6) NOT NULL default '0',
  PRIMARY KEY  (char_id,faction_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'faction_values'
--



--
-- Table structure for table 'guilds'
--

CREATE TABLE guilds (
  id int(11) NOT NULL auto_increment,
  eqid smallint(4) NOT NULL default '0',
  name varchar(32) NOT NULL default '',
  leader int(11) NOT NULL default '0',
  motd text NOT NULL,
  rank0title varchar(100) NOT NULL default '',
  rank1title varchar(100) NOT NULL default '',
  rank1 varchar(8) NOT NULL default '',
  rank2title varchar(100) NOT NULL default '',
  rank2 varchar(8) NOT NULL default '',
  rank3title varchar(100) NOT NULL default '',
  rank3 varchar(8) NOT NULL default '',
  rank4title varchar(100) NOT NULL default '',
  rank4 varchar(8) NOT NULL default '',
  rank5title varchar(100) NOT NULL default '',
  rank5 varchar(8) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY eqid (eqid),
  UNIQUE KEY name (name),
  UNIQUE KEY leader (leader)
) TYPE=MyISAM;

--
-- Dumping data for table 'guilds'
--



--
-- Table structure for table 'hackers'
--

CREATE TABLE hackers (
  id int(4) NOT NULL auto_increment,
  account text NOT NULL,
  name text NOT NULL,
  hacked text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'hackers'
--



--
-- Table structure for table 'items'
--

CREATE TABLE items (
  id int(11) NOT NULL default '0',
  raw_data blob,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'items'
--

--
-- Table structure for table 'lootdrop'
--

CREATE TABLE lootdrop (
  id int(11) unsigned NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'lootdrop'
--



--
-- Table structure for table 'lootdrop_entries'
--

CREATE TABLE lootdrop_entries (
  lootdrop_id int(11) unsigned NOT NULL default '0',
  item_id int(11) NOT NULL default '0',
  item_charges tinyint(2) NOT NULL default '1',
  equip_item tinyint(2) unsigned NOT NULL default '0',
  chance tinyint(2) unsigned NOT NULL default '1',
  PRIMARY KEY  (lootdrop_id,item_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'lootdrop_entries'
--



--
-- Table structure for table 'loottable'
--

CREATE TABLE loottable (
  id int(11) unsigned NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  mincash int(11) unsigned NOT NULL default '0',
  maxcash int(11) unsigned NOT NULL default '0',
  avgcoin smallint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'loottable'
--



--
-- Table structure for table 'loottable_entries'
--

CREATE TABLE loottable_entries (
  loottable_id int(11) unsigned NOT NULL default '0',
  lootdrop_id int(11) unsigned NOT NULL default '0',
  multiplier tinyint(2) unsigned NOT NULL default '1',
  probability tinyint(2) unsigned NOT NULL default '100',
  PRIMARY KEY  (loottable_id,lootdrop_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'loottable_entries'
--



--
-- Table structure for table 'merchantlist'
--

CREATE TABLE merchantlist (
  merchantid int(11) NOT NULL default '0',
  slot int(11) NOT NULL default '0',
  item int(11) NOT NULL default '0',
  PRIMARY KEY  (merchantid,slot)
) TYPE=MyISAM;

--
-- Dumping data for table 'merchantlist'
--



--
-- Table structure for table 'name_filter'
--

CREATE TABLE name_filter (
  name varchar(30) NOT NULL default '',
  PRIMARY KEY  (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'name_filter'
--



--
-- Table structure for table 'npc_faction'
--

CREATE TABLE npc_faction (
  npc_id int(11) NOT NULL default '0',
  faction_id int(11) NOT NULL default '0',
  value smallint(6) NOT NULL default '0',
  primary_faction tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (npc_id,faction_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'npc_faction'
--



--
-- Table structure for table 'npc_types'
--

CREATE TABLE npc_types (
  id int(11) NOT NULL auto_increment,
  name text NOT NULL,
  level tinyint(2) unsigned NOT NULL default '0',
  race tinyint(2) unsigned NOT NULL default '0',
  class tinyint(2) unsigned NOT NULL default '0',
  hp int(11) NOT NULL default '0',
  gender tinyint(2) unsigned NOT NULL default '0',
  texture tinyint(2) unsigned NOT NULL default '0',
  helmtexture tinyint(2) unsigned NOT NULL default '0',
  size float NOT NULL default '0',
  hp_regen_rate int(11) unsigned NOT NULL default '0',
  mana_regen_rate int(11) unsigned NOT NULL default '0',
  loottable_id int(11) unsigned NOT NULL default '0',
  merchant_id int(11) unsigned NOT NULL default '0',
  mindmg int(10) unsigned NOT NULL default '0',
  maxdmg int(10) unsigned NOT NULL default '0',
  usedspells varchar(70) NOT NULL default '',
  npcspecialattks char(1) NOT NULL default '',
  banish int(10) unsigned NOT NULL default '0',
  aggroradius int(10) unsigned NOT NULL default '0',
  social int(10) unsigned NOT NULL default '0',
  face int(10) unsigned NOT NULL default '1',
  luclin_hairstyle int(10) unsigned NOT NULL default '1',
  luclin_haircolor int(10) unsigned NOT NULL default '1',
  luclin_eyecolor int(10) unsigned NOT NULL default '1',
  luclin_beardcolor int(10) unsigned NOT NULL default '1',
  fixedz tinyint(2) unsigned NOT NULL default '0',
  d_meele_texture1 int(10) unsigned NOT NULL default '0',
  d_meele_texture2 int(10) unsigned NOT NULL default '0',
  walkspeed float NOT NULL default '0',
  runspeed float NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'npc_types'
--



--
-- Table structure for table 'petitions'
--

CREATE TABLE petitions (
  dib int(10) unsigned NOT NULL auto_increment,
  petid int(10) unsigned NOT NULL default '0',
  charname varchar(32) NOT NULL default '',
  accountname varchar(32) NOT NULL default '',
  lastgm varchar(32) NOT NULL default '',
  petitiontext text NOT NULL,
  gmtext text,
  zone varchar(32) NOT NULL default '',
  urgency int(11) NOT NULL default '0',
  charclass int(11) NOT NULL default '0',
  charrace int(11) NOT NULL default '0',
  charlevel int(11) NOT NULL default '0',
  checkouts int(11) NOT NULL default '0',
  unavailables int(11) NOT NULL default '0',
  ischeckedout tinyint(4) NOT NULL default '0',
  senttime bigint(11) NOT NULL default '0',
  PRIMARY KEY  (dib),
  KEY petid (petid)
) TYPE=MyISAM COMMENT='Table for Petitions';

--
-- Dumping data for table 'petitions'
--



--
-- Table structure for table 'player_corpses'
--

CREATE TABLE player_corpses (
  id int(11) unsigned NOT NULL auto_increment,
  charid int(11) unsigned NOT NULL default '0',
  charname varchar(30) NOT NULL default '',
  zonename varchar(16) NOT NULL default '',
  x float NOT NULL default '0',
  y float NOT NULL default '0',
  z float NOT NULL default '0',
  heading float NOT NULL default '0',
  data blob NOT NULL,
  time timestamp(14) NOT NULL,
  PRIMARY KEY  (id),
  KEY zonename (zonename)
) TYPE=MyISAM;

--
-- Dumping data for table 'player_corpses'
--



--
-- Table structure for table 'quest'
--

CREATE TABLE quest (
  id int(11) NOT NULL auto_increment,
  zone varchar(16) NOT NULL default '',
  name varchar(32) NOT NULL default '',
  activator varchar(64) NOT NULL default '',
  text varchar(255) NOT NULL default '',
  end varchar(64) NOT NULL default '',
  npcID int(11) NOT NULL default '0',
  questobject int(11) unsigned NOT NULL default '0',
  priceobject int(11) unsigned NOT NULL default '0',
  cash int(11) unsigned NOT NULL default '0',
  exp int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'quest'
--



--
-- Table structure for table 'spawn2'
--

CREATE TABLE spawn2 (
  id int(11) NOT NULL auto_increment,
  spawngroupID int(11) NOT NULL default '0',
  zone varchar(16) NOT NULL default '',
  x float NOT NULL default '0',
  y float NOT NULL default '0',
  z float NOT NULL default '0',
  heading float NOT NULL default '0',
  respawntime int(11) NOT NULL default '0',
  variance smallint(4) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'spawn2'
--



--
-- Table structure for table 'spawnentry'
--

CREATE TABLE spawnentry (
  spawngroupID int(11) NOT NULL default '0',
  npcID int(11) NOT NULL default '0',
  chance smallint(4) NOT NULL default '0',
  PRIMARY KEY  (spawngroupID,npcID)
) TYPE=MyISAM;

--
-- Dumping data for table 'spawnentry'
--



--
-- Table structure for table 'spawngroup'
--

CREATE TABLE spawngroup (
  id int(11) NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'spawngroup'
--



--
-- Table structure for table 'starting_items'
--

CREATE TABLE starting_items (
  id int(11) unsigned NOT NULL auto_increment,
  race int(11) NOT NULL default '0',
  class int(11) NOT NULL default '0',
  itemid int(11) NOT NULL default '0',
  gm tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id,race)
) TYPE=MyISAM;

--
-- Dumping data for table 'starting_items'
--


INSERT INTO starting_items VALUES (1,2,15,9991,0);
INSERT INTO starting_items VALUES (2,2,15,9990,0);
INSERT INTO starting_items VALUES (3,2,15,9979,0);
INSERT INTO starting_items VALUES (4,2,15,18700,0);
INSERT INTO starting_items VALUES (5,2,9,9991,0);
INSERT INTO starting_items VALUES (6,2,9,9990,0);
INSERT INTO starting_items VALUES (7,2,9,9997,0);
INSERT INTO starting_items VALUES (8,2,9,9979,0);
INSERT INTO starting_items VALUES (9,2,9,18700,0);
INSERT INTO starting_items VALUES (10,2,10,9991,0);
INSERT INTO starting_items VALUES (11,2,10,9990,0);
INSERT INTO starting_items VALUES (12,2,10,9999,0);
INSERT INTO starting_items VALUES (13,2,10,9979,0);
INSERT INTO starting_items VALUES (14,2,10,9993,0);
INSERT INTO starting_items VALUES (15,2,10,9983,0);
INSERT INTO starting_items VALUES (16,2,10,18700,0);
INSERT INTO starting_items VALUES (17,2,1,9991,0);
INSERT INTO starting_items VALUES (18,2,1,9990,0);
INSERT INTO starting_items VALUES (19,2,1,9998,0);
INSERT INTO starting_items VALUES (20,2,1,9979,0);
INSERT INTO starting_items VALUES (21,2,1,18700,0);
INSERT INTO starting_items VALUES (22,6,2,9991,0);
INSERT INTO starting_items VALUES (23,6,2,9990,0);
INSERT INTO starting_items VALUES (24,6,2,9999,0);
INSERT INTO starting_items VALUES (25,6,2,9993,0);
INSERT INTO starting_items VALUES (26,6,2,9985,0);
INSERT INTO starting_items VALUES (27,6,2,18700,0);
INSERT INTO starting_items VALUES (28,6,14,9991,0);
INSERT INTO starting_items VALUES (29,6,14,9990,0);
INSERT INTO starting_items VALUES (30,6,14,9997,0);
INSERT INTO starting_items VALUES (31,6,14,9987,0);
INSERT INTO starting_items VALUES (32,6,14,9986,0);
INSERT INTO starting_items VALUES (33,6,14,18700,0);
INSERT INTO starting_items VALUES (34,6,13,9991,0);
INSERT INTO starting_items VALUES (35,6,13,9990,0);
INSERT INTO starting_items VALUES (36,6,13,9997,0);
INSERT INTO starting_items VALUES (37,6,13,9994,0);
INSERT INTO starting_items VALUES (38,6,13,9986,0);
INSERT INTO starting_items VALUES (39,6,13,18700,0);
INSERT INTO starting_items VALUES (40,6,11,9991,0);
INSERT INTO starting_items VALUES (41,6,11,9990,0);
INSERT INTO starting_items VALUES (42,6,11,9997,0);
INSERT INTO starting_items VALUES (43,6,11,9989,0);
INSERT INTO starting_items VALUES (44,6,11,9986,0);
INSERT INTO starting_items VALUES (45,6,11,18700,0);
INSERT INTO starting_items VALUES (46,6,9,9991,0);
INSERT INTO starting_items VALUES (47,6,9,9990,0);
INSERT INTO starting_items VALUES (48,6,9,9997,0);
INSERT INTO starting_items VALUES (49,6,9,18700,0);
INSERT INTO starting_items VALUES (50,6,5,9991,0);
INSERT INTO starting_items VALUES (51,6,5,9990,0);
INSERT INTO starting_items VALUES (52,6,5,9998,0);
INSERT INTO starting_items VALUES (53,6,5,18700,0);
INSERT INTO starting_items VALUES (54,6,1,9991,0);
INSERT INTO starting_items VALUES (55,6,1,9990,0);
INSERT INTO starting_items VALUES (56,6,1,9998,0);
INSERT INTO starting_items VALUES (57,6,1,18700,0);
INSERT INTO starting_items VALUES (58,6,12,9991,0);
INSERT INTO starting_items VALUES (59,6,12,9990,0);
INSERT INTO starting_items VALUES (60,6,12,9997,0);
INSERT INTO starting_items VALUES (61,6,12,9988,0);
INSERT INTO starting_items VALUES (62,6,12,9986,0);
INSERT INTO starting_items VALUES (63,6,12,18700,0);
INSERT INTO starting_items VALUES (64,8,2,9991,0);
INSERT INTO starting_items VALUES (65,8,2,9990,0);
INSERT INTO starting_items VALUES (66,8,2,9999,0);
INSERT INTO starting_items VALUES (67,8,2,9993,0);
INSERT INTO starting_items VALUES (68,8,2,9985,0);
INSERT INTO starting_items VALUES (69,8,2,18700,0);
INSERT INTO starting_items VALUES (70,8,3,9991,0);
INSERT INTO starting_items VALUES (71,8,3,9990,0);
INSERT INTO starting_items VALUES (72,8,3,9998,0);
INSERT INTO starting_items VALUES (73,8,3,18700,0);
INSERT INTO starting_items VALUES (74,8,9,9991,0);
INSERT INTO starting_items VALUES (75,8,9,9990,0);
INSERT INTO starting_items VALUES (76,8,9,9997,0);
INSERT INTO starting_items VALUES (77,8,9,18700,0);
INSERT INTO starting_items VALUES (78,8,1,9991,0);
INSERT INTO starting_items VALUES (79,8,1,9991,0);
INSERT INTO starting_items VALUES (80,8,1,9990,0);
INSERT INTO starting_items VALUES (81,8,1,9998,0);
INSERT INTO starting_items VALUES (82,8,1,18700,0);
INSERT INTO starting_items VALUES (83,3,2,9991,0);
INSERT INTO starting_items VALUES (84,3,2,9990,0);
INSERT INTO starting_items VALUES (85,3,2,9999,0);
INSERT INTO starting_items VALUES (86,3,2,6378,0);
INSERT INTO starting_items VALUES (87,3,2,9993,0);
INSERT INTO starting_items VALUES (88,3,2,9985,0);
INSERT INTO starting_items VALUES (89,3,2,18700,0);
INSERT INTO starting_items VALUES (90,3,14,9991,0);
INSERT INTO starting_items VALUES (91,3,14,9990,0);
INSERT INTO starting_items VALUES (92,3,14,9997,0);
INSERT INTO starting_items VALUES (93,3,14,9979,0);
INSERT INTO starting_items VALUES (94,3,14,9987,0);
INSERT INTO starting_items VALUES (95,3,14,9986,0);
INSERT INTO starting_items VALUES (96,3,14,18700,0);
INSERT INTO starting_items VALUES (97,3,13,9991,0);
INSERT INTO starting_items VALUES (98,3,13,9990,0);
INSERT INTO starting_items VALUES (99,3,13,9997,0);
INSERT INTO starting_items VALUES (100,3,13,9979,0);
INSERT INTO starting_items VALUES (101,3,13,9994,0);
INSERT INTO starting_items VALUES (102,3,13,9986,0);
INSERT INTO starting_items VALUES (103,3,13,18700,0);
INSERT INTO starting_items VALUES (104,3,11,9991,0);
INSERT INTO starting_items VALUES (105,3,11,9990,0);
INSERT INTO starting_items VALUES (106,3,11,9997,0);
INSERT INTO starting_items VALUES (107,3,11,6378,0);
INSERT INTO starting_items VALUES (108,3,11,9989,0);
INSERT INTO starting_items VALUES (109,3,11,9986,0);
INSERT INTO starting_items VALUES (110,3,11,18700,0);
INSERT INTO starting_items VALUES (111,3,3,9991,0);
INSERT INTO starting_items VALUES (112,3,3,9990,0);
INSERT INTO starting_items VALUES (113,3,3,9998,0);
INSERT INTO starting_items VALUES (114,3,3,9979,0);
INSERT INTO starting_items VALUES (115,3,3,18700,0);
INSERT INTO starting_items VALUES (116,3,5,9991,0);
INSERT INTO starting_items VALUES (117,3,5,9990,0);
INSERT INTO starting_items VALUES (118,3,5,9998,0);
INSERT INTO starting_items VALUES (119,3,5,6378,0);
INSERT INTO starting_items VALUES (120,3,5,18700,0);
INSERT INTO starting_items VALUES (121,3,12,9991,0);
INSERT INTO starting_items VALUES (122,3,12,9990,0);
INSERT INTO starting_items VALUES (123,3,12,9997,0);
INSERT INTO starting_items VALUES (124,3,12,9979,0);
INSERT INTO starting_items VALUES (125,3,12,9988,0);
INSERT INTO starting_items VALUES (126,3,12,9986,0);
INSERT INTO starting_items VALUES (127,3,12,18700,0);
INSERT INTO starting_items VALUES (128,12,2,9991,0);
INSERT INTO starting_items VALUES (129,12,2,9990,0);
INSERT INTO starting_items VALUES (130,12,2,9999,0);
INSERT INTO starting_items VALUES (131,12,2,9993,0);
INSERT INTO starting_items VALUES (132,12,2,9985,0);
INSERT INTO starting_items VALUES (133,12,2,18700,0);
INSERT INTO starting_items VALUES (134,12,14,9991,0);
INSERT INTO starting_items VALUES (135,12,14,9990,0);
INSERT INTO starting_items VALUES (136,12,14,9997,0);
INSERT INTO starting_items VALUES (137,12,14,9987,0);
INSERT INTO starting_items VALUES (138,12,14,9986,0);
INSERT INTO starting_items VALUES (139,12,14,18700,0);
INSERT INTO starting_items VALUES (140,12,13,9991,0);
INSERT INTO starting_items VALUES (141,12,13,9990,0);
INSERT INTO starting_items VALUES (142,12,13,9997,0);
INSERT INTO starting_items VALUES (143,12,13,9994,0);
INSERT INTO starting_items VALUES (144,12,13,9986,0);
INSERT INTO starting_items VALUES (145,12,13,18700,0);
INSERT INTO starting_items VALUES (146,12,11,9991,0);
INSERT INTO starting_items VALUES (147,12,11,9990,0);
INSERT INTO starting_items VALUES (148,12,11,9997,0);
INSERT INTO starting_items VALUES (149,12,11,9989,0);
INSERT INTO starting_items VALUES (150,12,11,9986,0);
INSERT INTO starting_items VALUES (151,12,11,18700,0);
INSERT INTO starting_items VALUES (152,12,9,9991,0);
INSERT INTO starting_items VALUES (153,12,9,9990,0);
INSERT INTO starting_items VALUES (154,12,9,9997,0);
INSERT INTO starting_items VALUES (155,12,9,18700,0);
INSERT INTO starting_items VALUES (156,12,1,9991,0);
INSERT INTO starting_items VALUES (157,12,1,9990,0);
INSERT INTO starting_items VALUES (158,12,1,9998,0);
INSERT INTO starting_items VALUES (159,12,1,18700,0);
INSERT INTO starting_items VALUES (160,12,12,9991,0);
INSERT INTO starting_items VALUES (161,12,12,9990,0);
INSERT INTO starting_items VALUES (162,12,12,9997,0);
INSERT INTO starting_items VALUES (163,12,12,9988,0);
INSERT INTO starting_items VALUES (164,12,12,9986,0);
INSERT INTO starting_items VALUES (165,12,12,18700,0);
INSERT INTO starting_items VALUES (166,7,8,9991,0);
INSERT INTO starting_items VALUES (167,7,8,9990,0);
INSERT INTO starting_items VALUES (168,7,8,9998,0);
INSERT INTO starting_items VALUES (169,7,8,18700,0);
INSERT INTO starting_items VALUES (170,7,6,9991,0);
INSERT INTO starting_items VALUES (171,7,6,9990,0);
INSERT INTO starting_items VALUES (172,7,6,9999,0);
INSERT INTO starting_items VALUES (173,7,6,9993,0);
INSERT INTO starting_items VALUES (174,7,6,9984,0);
INSERT INTO starting_items VALUES (175,7,6,18700,0);
INSERT INTO starting_items VALUES (176,7,3,9991,0);
INSERT INTO starting_items VALUES (177,7,3,9990,0);
INSERT INTO starting_items VALUES (178,7,3,9998,0);
INSERT INTO starting_items VALUES (179,7,3,18700,0);
INSERT INTO starting_items VALUES (180,7,4,9991,0);
INSERT INTO starting_items VALUES (181,7,4,9990,0);
INSERT INTO starting_items VALUES (182,7,4,9998,0);
INSERT INTO starting_items VALUES (183,7,4,18700,0);
INSERT INTO starting_items VALUES (184,7,9,9991,0);
INSERT INTO starting_items VALUES (185,7,9,9990,0);
INSERT INTO starting_items VALUES (186,7,9,9997,0);
INSERT INTO starting_items VALUES (187,7,9,18700,0);
INSERT INTO starting_items VALUES (188,7,1,9991,0);
INSERT INTO starting_items VALUES (189,7,1,9990,0);
INSERT INTO starting_items VALUES (190,7,1,9998,0);
INSERT INTO starting_items VALUES (191,7,1,18700,0);
INSERT INTO starting_items VALUES (192,11,2,9991,0);
INSERT INTO starting_items VALUES (193,11,2,9990,0);
INSERT INTO starting_items VALUES (194,11,2,9999,0);
INSERT INTO starting_items VALUES (195,11,2,9986,0);
INSERT INTO starting_items VALUES (196,11,2,9985,0);
INSERT INTO starting_items VALUES (197,11,2,18700,0);
INSERT INTO starting_items VALUES (198,11,6,9991,0);
INSERT INTO starting_items VALUES (199,11,6,9990,0);
INSERT INTO starting_items VALUES (200,11,6,9999,0);
INSERT INTO starting_items VALUES (201,11,6,9993,0);
INSERT INTO starting_items VALUES (202,11,6,9984,0);
INSERT INTO starting_items VALUES (203,11,6,18700,0);
INSERT INTO starting_items VALUES (204,11,9,9991,0);
INSERT INTO starting_items VALUES (205,11,9,9990,0);
INSERT INTO starting_items VALUES (206,11,9,9997,0);
INSERT INTO starting_items VALUES (207,11,9,18700,0);
INSERT INTO starting_items VALUES (208,5,2,9991,0);
INSERT INTO starting_items VALUES (209,5,2,9990,0);
INSERT INTO starting_items VALUES (210,5,2,9999,0);
INSERT INTO starting_items VALUES (211,5,2,9986,0);
INSERT INTO starting_items VALUES (212,5,2,9985,0);
INSERT INTO starting_items VALUES (213,5,2,18700,0);
INSERT INTO starting_items VALUES (214,5,14,9991,0);
INSERT INTO starting_items VALUES (215,5,14,9990,0);
INSERT INTO starting_items VALUES (216,5,14,9985,0);
INSERT INTO starting_items VALUES (217,5,14,9987,0);
INSERT INTO starting_items VALUES (218,5,14,9986,0);
INSERT INTO starting_items VALUES (219,5,14,18700,0);
INSERT INTO starting_items VALUES (220,5,13,9991,0);
INSERT INTO starting_items VALUES (221,5,13,9990,0);
INSERT INTO starting_items VALUES (222,5,13,9997,0);
INSERT INTO starting_items VALUES (223,5,13,9994,0);
INSERT INTO starting_items VALUES (224,5,13,9986,0);
INSERT INTO starting_items VALUES (225,5,13,18700,0);
INSERT INTO starting_items VALUES (226,5,3,9991,0);
INSERT INTO starting_items VALUES (227,5,3,9990,0);
INSERT INTO starting_items VALUES (228,5,3,9998,0);
INSERT INTO starting_items VALUES (229,5,3,18700,0);
INSERT INTO starting_items VALUES (230,5,12,9991,0);
INSERT INTO starting_items VALUES (231,5,12,9990,0);
INSERT INTO starting_items VALUES (232,5,12,9997,0);
INSERT INTO starting_items VALUES (233,5,12,9988,0);
INSERT INTO starting_items VALUES (234,5,12,9986,0);
INSERT INTO starting_items VALUES (235,1,8,9991,0);
INSERT INTO starting_items VALUES (236,1,8,9990,0);
INSERT INTO starting_items VALUES (237,1,8,9998,0);
INSERT INTO starting_items VALUES (238,1,8,9979,0);
INSERT INTO starting_items VALUES (239,1,8,18700,0);
INSERT INTO starting_items VALUES (240,1,2,9991,0);
INSERT INTO starting_items VALUES (241,1,2,9990,0);
INSERT INTO starting_items VALUES (242,1,2,9999,0);
INSERT INTO starting_items VALUES (243,1,2,9982,0);
INSERT INTO starting_items VALUES (244,1,2,9993,0);
INSERT INTO starting_items VALUES (245,1,2,9985,0);
INSERT INTO starting_items VALUES (246,1,2,18700,0);
INSERT INTO starting_items VALUES (247,1,6,9991,0);
INSERT INTO starting_items VALUES (248,1,6,9990,0);
INSERT INTO starting_items VALUES (249,1,6,9999,0);
INSERT INTO starting_items VALUES (250,1,6,9979,0);
INSERT INTO starting_items VALUES (251,1,6,9993,0);
INSERT INTO starting_items VALUES (252,1,6,9984,0);
INSERT INTO starting_items VALUES (253,1,6,18700,0);
INSERT INTO starting_items VALUES (254,1,14,9991,0);
INSERT INTO starting_items VALUES (255,1,14,9990,0);
INSERT INTO starting_items VALUES (256,1,14,9997,0);
INSERT INTO starting_items VALUES (257,1,14,9979,0);
INSERT INTO starting_items VALUES (258,1,14,9987,0);
INSERT INTO starting_items VALUES (259,1,14,9986,0);
INSERT INTO starting_items VALUES (260,1,14,18700,0);
INSERT INTO starting_items VALUES (261,1,13,9991,0);
INSERT INTO starting_items VALUES (262,1,13,9990,0);
INSERT INTO starting_items VALUES (263,1,13,9997,0);
INSERT INTO starting_items VALUES (264,1,13,9979,0);
INSERT INTO starting_items VALUES (265,1,13,9994,0);
INSERT INTO starting_items VALUES (266,1,13,9986,0);
INSERT INTO starting_items VALUES (267,1,13,18700,0);
INSERT INTO starting_items VALUES (268,1,7,9991,0);
INSERT INTO starting_items VALUES (269,1,7,9990,0);
INSERT INTO starting_items VALUES (270,1,7,9979,0);
INSERT INTO starting_items VALUES (271,1,7,18700,0);
INSERT INTO starting_items VALUES (272,1,11,9991,0);
INSERT INTO starting_items VALUES (273,1,11,9990,0);
INSERT INTO starting_items VALUES (274,1,11,9997,0);
INSERT INTO starting_items VALUES (275,1,11,9982,0);
INSERT INTO starting_items VALUES (276,1,11,9989,0);
INSERT INTO starting_items VALUES (277,1,11,9986,0);
INSERT INTO starting_items VALUES (278,1,11,18700,0);
INSERT INTO starting_items VALUES (279,1,3,9991,0);
INSERT INTO starting_items VALUES (280,1,3,9990,0);
INSERT INTO starting_items VALUES (281,1,3,9998,0);
INSERT INTO starting_items VALUES (282,1,3,9979,0);
INSERT INTO starting_items VALUES (283,1,3,18700,0);
INSERT INTO starting_items VALUES (284,1,4,9991,0);
INSERT INTO starting_items VALUES (286,1,4,9990,0);
INSERT INTO starting_items VALUES (287,1,4,9979,0);
INSERT INTO starting_items VALUES (288,1,4,18700,0);
INSERT INTO starting_items VALUES (289,1,9,9991,0);
INSERT INTO starting_items VALUES (290,1,9,9990,0);
INSERT INTO starting_items VALUES (291,1,9,9997,0);
INSERT INTO starting_items VALUES (292,1,9,9979,0);
INSERT INTO starting_items VALUES (293,1,9,18700,0);
INSERT INTO starting_items VALUES (294,1,5,9991,0);
INSERT INTO starting_items VALUES (295,1,5,9990,0);
INSERT INTO starting_items VALUES (296,1,5,9998,0);
INSERT INTO starting_items VALUES (297,1,5,9982,0);
INSERT INTO starting_items VALUES (298,1,5,18700,0);
INSERT INTO starting_items VALUES (299,1,1,9991,0);
INSERT INTO starting_items VALUES (300,1,1,9990,0);
INSERT INTO starting_items VALUES (301,1,1,9998,0);
INSERT INTO starting_items VALUES (302,1,1,9979,0);
INSERT INTO starting_items VALUES (303,1,1,18700,0);
INSERT INTO starting_items VALUES (304,1,12,9991,0);
INSERT INTO starting_items VALUES (305,1,12,9990,0);
INSERT INTO starting_items VALUES (306,1,12,9997,0);
INSERT INTO starting_items VALUES (307,1,12,9979,0);
INSERT INTO starting_items VALUES (308,1,12,9988,0);
INSERT INTO starting_items VALUES (309,1,12,9986,0);
INSERT INTO starting_items VALUES (310,1,12,18700,0);
INSERT INTO starting_items VALUES (311,128,15,9991,0);
INSERT INTO starting_items VALUES (312,128,15,9990,0);
INSERT INTO starting_items VALUES (313,128,15,9997,0);
INSERT INTO starting_items VALUES (314,128,15,18700,0);
INSERT INTO starting_items VALUES (315,128,7,9991,0);
INSERT INTO starting_items VALUES (316,128,7,9990,0);
INSERT INTO starting_items VALUES (317,128,7,18700,0);
INSERT INTO starting_items VALUES (318,128,11,9991,0);
INSERT INTO starting_items VALUES (319,128,11,9990,0);
INSERT INTO starting_items VALUES (320,128,11,9997,0);
INSERT INTO starting_items VALUES (321,128,11,9989,0);
INSERT INTO starting_items VALUES (322,128,11,9986,0);
INSERT INTO starting_items VALUES (323,128,11,18700,0);
INSERT INTO starting_items VALUES (324,128,5,9991,0);
INSERT INTO starting_items VALUES (325,128,5,9990,0);
INSERT INTO starting_items VALUES (326,128,5,9998,0);
INSERT INTO starting_items VALUES (327,128,5,18700,0);
INSERT INTO starting_items VALUES (328,128,10,9991,0);
INSERT INTO starting_items VALUES (329,128,10,9990,0);
INSERT INTO starting_items VALUES (330,128,10,9999,0);
INSERT INTO starting_items VALUES (331,128,10,9993,0);
INSERT INTO starting_items VALUES (332,128,10,9983,0);
INSERT INTO starting_items VALUES (333,128,10,18700,0);
INSERT INTO starting_items VALUES (334,128,1,9991,0);
INSERT INTO starting_items VALUES (335,128,1,9990,0);
INSERT INTO starting_items VALUES (336,128,1,9998,0);
INSERT INTO starting_items VALUES (337,128,1,18700,0);
INSERT INTO starting_items VALUES (338,10,15,9991,0);
INSERT INTO starting_items VALUES (339,10,15,9990,0);
INSERT INTO starting_items VALUES (340,10,15,9997,0);
INSERT INTO starting_items VALUES (341,10,15,18700,0);
INSERT INTO starting_items VALUES (342,10,5,9991,0);
INSERT INTO starting_items VALUES (343,10,5,9990,0);
INSERT INTO starting_items VALUES (344,10,5,9998,0);
INSERT INTO starting_items VALUES (345,10,5,18700,0);
INSERT INTO starting_items VALUES (346,10,10,9991,0);
INSERT INTO starting_items VALUES (347,10,10,9990,0);
INSERT INTO starting_items VALUES (348,10,10,9999,0);
INSERT INTO starting_items VALUES (349,10,10,9993,0);
INSERT INTO starting_items VALUES (350,10,10,9983,0);
INSERT INTO starting_items VALUES (351,10,10,18700,0);
INSERT INTO starting_items VALUES (352,10,1,9991,0);
INSERT INTO starting_items VALUES (353,10,1,9990,0);
INSERT INTO starting_items VALUES (354,10,1,9998,0);
INSERT INTO starting_items VALUES (355,10,1,18700,0);
INSERT INTO starting_items VALUES (356,9,15,9991,0);
INSERT INTO starting_items VALUES (357,9,15,9990,0);
INSERT INTO starting_items VALUES (358,9,15,9997,0);
INSERT INTO starting_items VALUES (359,9,15,18700,0);
INSERT INTO starting_items VALUES (360,9,5,9991,0);
INSERT INTO starting_items VALUES (361,9,5,9990,0);
INSERT INTO starting_items VALUES (362,9,5,9998,0);
INSERT INTO starting_items VALUES (363,9,5,18700,0);
INSERT INTO starting_items VALUES (364,9,10,9991,0);
INSERT INTO starting_items VALUES (365,9,10,9990,0);
INSERT INTO starting_items VALUES (366,9,10,9999,0);
INSERT INTO starting_items VALUES (367,9,10,9993,0);
INSERT INTO starting_items VALUES (368,9,10,9983,0);
INSERT INTO starting_items VALUES (369,9,1,9991,0);
INSERT INTO starting_items VALUES (370,9,1,9990,0);
INSERT INTO starting_items VALUES (371,9,1,9998,0);
INSERT INTO starting_items VALUES (372,9,1,18700,0);
INSERT INTO starting_items VALUES (373,130,8,9991,0);
INSERT INTO starting_items VALUES (374,130,8,9990,0);
INSERT INTO starting_items VALUES (375,130,8,9998,0);
INSERT INTO starting_items VALUES (376,130,8,18700,0);
INSERT INTO starting_items VALUES (377,130,15,9991,0);
INSERT INTO starting_items VALUES (378,130,15,9990,0);
INSERT INTO starting_items VALUES (379,130,15,9997,0);
INSERT INTO starting_items VALUES (380,130,15,18700,0);
INSERT INTO starting_items VALUES (381,130,9,9991,0);
INSERT INTO starting_items VALUES (382,130,9,9990,0);
INSERT INTO starting_items VALUES (383,130,9,9997,0);
INSERT INTO starting_items VALUES (384,130,9,18700,0);
INSERT INTO starting_items VALUES (385,130,10,9991,0);
INSERT INTO starting_items VALUES (386,130,10,9990,0);
INSERT INTO starting_items VALUES (387,130,10,9999,0);
INSERT INTO starting_items VALUES (388,130,10,9993,0);
INSERT INTO starting_items VALUES (389,130,10,9983,0);
INSERT INTO starting_items VALUES (390,130,10,18700,0);
INSERT INTO starting_items VALUES (391,130,1,9991,0);
INSERT INTO starting_items VALUES (392,130,1,9990,0);
INSERT INTO starting_items VALUES (393,130,1,9998,0);
INSERT INTO starting_items VALUES (394,4,8,9991,0);
INSERT INTO starting_items VALUES (395,4,8,9990,0);
INSERT INTO starting_items VALUES (396,4,8,9998,0);
INSERT INTO starting_items VALUES (397,4,8,18700,0);
INSERT INTO starting_items VALUES (398,4,6,9991,0);
INSERT INTO starting_items VALUES (399,4,6,9990,0);
INSERT INTO starting_items VALUES (400,4,6,9999,0);
INSERT INTO starting_items VALUES (401,4,6,9993,0);
INSERT INTO starting_items VALUES (402,4,6,9984,0);
INSERT INTO starting_items VALUES (403,4,6,18700,0);
INSERT INTO starting_items VALUES (404,4,4,9991,0);
INSERT INTO starting_items VALUES (405,4,4,9990,0);
INSERT INTO starting_items VALUES (406,4,4,9998,0);
INSERT INTO starting_items VALUES (407,4,4,18700,0);
INSERT INTO starting_items VALUES (408,4,9,9991,0);
INSERT INTO starting_items VALUES (409,4,9,9990,0);
INSERT INTO starting_items VALUES (410,4,9,9998,0);
INSERT INTO starting_items VALUES (411,4,9,18700,0);
INSERT INTO starting_items VALUES (412,4,1,9991,0);
INSERT INTO starting_items VALUES (413,4,1,9990,0);
INSERT INTO starting_items VALUES (414,4,1,9998,0);
INSERT INTO starting_items VALUES (415,4,1,18700,0);

--
-- Table structure for table 'tradeskillrecipe'
--

CREATE TABLE tradeskillrecipe (
  id int(11) NOT NULL auto_increment,
  tradeskill smallint(6) NOT NULL default '0',
  skillneeded smallint(6) NOT NULL default '0',
  product smallint(6) NOT NULL default '0',
  i1 smallint(6) NOT NULL default '0',
  i2 smallint(6) NOT NULL default '0',
  i3 smallint(6) NOT NULL default '0',
  i4 smallint(6) NOT NULL default '0',
  i5 smallint(6) NOT NULL default '0',
  i6 smallint(6) NOT NULL default '0',
  i7 smallint(6) NOT NULL default '0',
  i8 smallint(6) NOT NULL default '0',
  i9 smallint(6) NOT NULL default '0',
  i10 smallint(6) NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY id (id),
  UNIQUE KEY name (product)
) TYPE=MyISAM;

--
-- Dumping data for table 'tradeskillrecipe'
--


INSERT INTO tradeskillrecipe VALUES (1,68,14,16600,16500,10015,0,0,0,0,0,0,0,0);
INSERT INTO tradeskillrecipe VALUES (2,68,14,14600,16504,10015,0,0,0,0,0,0,0,0);
INSERT INTO tradeskillrecipe VALUES (3,68,30,14628,16504,10020,0,0,0,0,0,0,0,0);
INSERT INTO tradeskillrecipe VALUES (4,68,30,16656,16500,10020,0,0,0,0,0,0,0,0);

--
-- Table structure for table 'variables'
--

CREATE TABLE variables (
  varname varchar(25) NOT NULL default '',
  value text NOT NULL,
  PRIMARY KEY  (varname)
) TYPE=MyISAM;

--
-- Dumping data for table 'variables'
--


INSERT INTO variables VALUES ('MOTD','Welcome EQEmu!');
INSERT INTO variables VALUES ('disablecommandline','0');
INSERT INTO variables VALUES ('PersistentZoneState','0');
INSERT INTO variables VALUES ('decaytime 1 54','300');
INSERT INTO variables VALUES ('decaytime 55 100','1800');
INSERT INTO variables VALUES ('Max_AAXP','21626880');

--
-- Table structure for table 'zone'
--

CREATE TABLE zone (
  short_name varchar(16) NOT NULL default '',
  file_name varchar(16) default NULL,
  long_name text,
  safe_x float NOT NULL default '0',
  safe_y float NOT NULL default '0',
  safe_z float NOT NULL default '0',
  minium_level tinyint(3) unsigned NOT NULL default '0',
  minium_status tinyint(3) unsigned NOT NULL default '0',
  zoneidnumber int(4) NOT NULL default '0',
  PRIMARY KEY  (short_name),
  UNIQUE KEY zoneidnumber (zoneidnumber)
) TYPE=MyISAM;

--
-- Dumping data for table 'zone'
--


INSERT INTO zone VALUES ('qeynos',NULL,'South Qeynos',0,10,3,0,0,1);
INSERT INTO zone VALUES ('qeynos2',NULL,'North Qeynos',-74,428,0,0,0,2);
INSERT INTO zone VALUES ('qrg',NULL,'Surefall Glade',0,0,5,0,0,3);
INSERT INTO zone VALUES ('qeytoqrg',NULL,'Qeynos Hills',83,508,0,0,0,4);
INSERT INTO zone VALUES ('highpass',NULL,'Highpass Hold',74,164,5,0,0,5);
INSERT INTO zone VALUES ('highkeep',NULL,'High Keep',88,-16,5,0,0,6);
INSERT INTO zone VALUES ('freportn',NULL,'North Freeport',211,-296,0,0,0,8);
INSERT INTO zone VALUES ('freportw',NULL,'West Freeport',181,335,0,0,0,9);
INSERT INTO zone VALUES ('freporte',NULL,'East Freeport',-950,-14,0,0,0,10);
INSERT INTO zone VALUES ('runnyeye',NULL,'Runnyeye Citadel',0,0,5,0,0,11);
INSERT INTO zone VALUES ('qey2hh1',NULL,'Western Plains of Karana',-15919,-4199,5,0,0,12);
INSERT INTO zone VALUES ('northkarana',NULL,'Northern Plains of Karana',-382,-284,5,0,0,13);
INSERT INTO zone VALUES ('southkarana',NULL,'Southern Plains of Karana',1294,2348,5,0,0,14);
INSERT INTO zone VALUES ('eastkarana',NULL,'Eastern Plains of Karana',865,15,5,0,0,15);
INSERT INTO zone VALUES ('beholder',NULL,'Gorge of King Xorbb',-31,-512,5,0,0,16);
INSERT INTO zone VALUES ('blackburrow',NULL,'Blackburrow',-159,39,5,0,0,17);
INSERT INTO zone VALUES ('paw',NULL,'Lair of the Splitpaw',63,-122,5,0,0,18);
INSERT INTO zone VALUES ('rivervale',NULL,'Rivervale',0,0,-37,0,0,19);
INSERT INTO zone VALUES ('kithicor',NULL,'Kithicor Woods',3828,1889,5,0,0,20);
INSERT INTO zone VALUES ('commons',NULL,'West Commonlands',-1334,214,0,0,0,21);
INSERT INTO zone VALUES ('ecommons',NULL,'East Commonlands',4947,8,0,0,0,22);
INSERT INTO zone VALUES ('erudnint',NULL,'Erudin Palace',728,833,5,0,0,23);
INSERT INTO zone VALUES ('erudnext',NULL,'Erudin',-1104,-212,5,0,0,24);
INSERT INTO zone VALUES ('nektulos',NULL,'Nektulos Forest',-259,-1200,0,0,0,25);
INSERT INTO zone VALUES ('cshome',NULL,'Sunset Home',100,0,5,0,0,26);
INSERT INTO zone VALUES ('lavastorm',NULL,'Lavastorm Mountains',154,-1833,0,0,0,27);
INSERT INTO zone VALUES ('halas',NULL,'Halas',0,0,4,0,0,29);
INSERT INTO zone VALUES ('everfrost',NULL,'Everfrost',3139,629,5,0,0,30);
INSERT INTO zone VALUES ('soldunga',NULL,'Solusek\'s Eye',-486,-476,5,0,0,31);
INSERT INTO zone VALUES ('soldungb',NULL,'Nagafen\'s Lair',-263,-424,5,0,0,32);
INSERT INTO zone VALUES ('misty',NULL,'Misty Thicket',0,0,5,0,0,33);
INSERT INTO zone VALUES ('nro',NULL,'Northern Desert of Ro',299,3538,0,0,0,34);
INSERT INTO zone VALUES ('sro',NULL,'Southern Desert of Ro',286,1265,0,0,0,35);
INSERT INTO zone VALUES ('befallen',NULL,'Befallen',-813,-205,5,0,0,36);
INSERT INTO zone VALUES ('oasis',NULL,'Oasis of Marr',904,450,1,0,0,37);
INSERT INTO zone VALUES ('tox',NULL,'Toxxulia Forest',203,2295,5,0,0,38);
INSERT INTO zone VALUES ('hole',NULL,'The Hole',-1050,640,0,0,0,39);
INSERT INTO zone VALUES ('neriaka',NULL,'Neriak Foreign Quarter',157,-3,0,0,0,40);
INSERT INTO zone VALUES ('neriakb',NULL,'Neriak Commons',-500,3,-380,0,0,41);
INSERT INTO zone VALUES ('neriakc',NULL,'Neriak Third Gate',-969,892,-54,0,0,42);
INSERT INTO zone VALUES ('najena',NULL,'Najena',858,-76,5,0,0,44);
INSERT INTO zone VALUES ('qcat',NULL,'Qeynos Aqueduct System',80,860,5,0,0,45);
INSERT INTO zone VALUES ('innothule',NULL,'Innothule Swamp',-588,-2192,-25,0,0,46);
INSERT INTO zone VALUES ('feerrott',NULL,'The Feerrott',905,1051,5,0,0,47);
INSERT INTO zone VALUES ('cazicthule',NULL,'Lost Temple of CazicThule',185,0,5,0,0,48);
INSERT INTO zone VALUES ('oggok',NULL,'Oggok',-99,-345,5,0,0,49);
INSERT INTO zone VALUES ('rathemtn',NULL,'Rathe Mountains',1831,3825,5,0,0,50);
INSERT INTO zone VALUES ('lakerathe',NULL,'Lake Rathetear',1213,4183,5,0,0,51);
INSERT INTO zone VALUES ('grobb',NULL,'Grobb',0,-100,5,0,0,52);
INSERT INTO zone VALUES ('gfaydark',NULL,'Greater Faydark',10,-20,0,0,0,54);
INSERT INTO zone VALUES ('akanon',NULL,'Ak\'Anon',-35,47,5,0,0,55);
INSERT INTO zone VALUES ('steamfont',NULL,'Steamfont Mountains',-273,160,5,0,0,56);
INSERT INTO zone VALUES ('lfaydark',NULL,'Lesser Faydark',-1770,-108,0,0,0,57);
INSERT INTO zone VALUES ('crushbone',NULL,'Crushbone',158,-644,5,0,0,58);
INSERT INTO zone VALUES ('mistmoore',NULL,'Castle Mistmoore',120,-330,177,0,0,59);
INSERT INTO zone VALUES ('kaladima',NULL,'North Kaladim',-2,-18,5,0,0,60);
INSERT INTO zone VALUES ('felwithea',NULL,'Northern Felwithe',94,-25,5,0,0,61);
INSERT INTO zone VALUES ('felwitheb',NULL,'Southern Felwithe',-790,320,10.5,0,0,62);
INSERT INTO zone VALUES ('unrest',NULL,'Estate of Unrest',52,-38,5,0,0,63);
INSERT INTO zone VALUES ('kedge',NULL,'Kedge Keep',-242,-231,5,0,0,64);
INSERT INTO zone VALUES ('guktop',NULL,'Guk',7,-36,5,0,0,65);
INSERT INTO zone VALUES ('gukbottom',NULL,'Ruins of Old Guk',-217,1197,5,0,0,66);
INSERT INTO zone VALUES ('kaladimb',NULL,'South Kaladim',300,494,-31,0,0,67);
INSERT INTO zone VALUES ('butcher',NULL,'Butcherblock Mountains',-700,2550,294,0,0,68);
INSERT INTO zone VALUES ('oot',NULL,'Ocean of Tears',-9200,390,5,0,0,69);
INSERT INTO zone VALUES ('cauldron',NULL,'Dagnor\'s Cauldron',320,2815,473,0,0,70);
INSERT INTO zone VALUES ('airplane',NULL,'Plane of Air',0,0,5,46,0,71);
INSERT INTO zone VALUES ('fearplane',NULL,'Plane of Fear',-558,588,5,46,0,72);
INSERT INTO zone VALUES ('permafrost',NULL,'Permafrost Caverns',0,0,5,0,0,73);
INSERT INTO zone VALUES ('kerraridge',NULL,'Kerra Isle',-860,475,5,0,0,74);
INSERT INTO zone VALUES ('paineel',NULL,'Paineel',200,800,5,0,0,75);
INSERT INTO zone VALUES ('hateplane',NULL,'Plane of Hate',0,0,0,46,0,76);
INSERT INTO zone VALUES ('arena',NULL,'The Arena',-817,-11,3,0,0,77);
INSERT INTO zone VALUES ('fieldofbone',NULL,'Field of Bone',1617,-1684,-54,0,0,78);
INSERT INTO zone VALUES ('warslikswood',NULL,'Warslilks Woods',-2205,-582,5,0,0,79);
INSERT INTO zone VALUES ('soltemple',NULL,'Temple of Solusek Ro',36,262,5,0,0,80);
INSERT INTO zone VALUES ('droga',NULL,'Mines of Droga',-580,2111,5,0,0,81);
INSERT INTO zone VALUES ('cabwest',NULL,'Cabilis West',-140,593,5,0,0,82);
INSERT INTO zone VALUES ('swampofnohope',NULL,'Swamp Of No Hope',2945,2761,4,0,0,83);
INSERT INTO zone VALUES ('firiona',NULL,'Firiona Vie',1440,-2392,5,0,0,84);
INSERT INTO zone VALUES ('lakeofillomen',NULL,'Lake of Ill Omen',-5383,5747,68,0,0,85);
INSERT INTO zone VALUES ('dreadlands',NULL,'Dreadlands',9565,2806,1045,0,0,86);
INSERT INTO zone VALUES ('burningwood',NULL,'The Burning Wood',-821,-4942,5,0,0,87);
INSERT INTO zone VALUES ('kaesora',NULL,'Kaesora',40,370,100,0,0,88);
INSERT INTO zone VALUES ('sebilis',NULL,'Old Sebilis',0,0,0,0,0,89);
INSERT INTO zone VALUES ('citymist',NULL,'The City of Mist',-734,28,5,0,0,90);
INSERT INTO zone VALUES ('skyfire',NULL,'Skyfire Mountains',5131,3618,-54,0,0,91);
INSERT INTO zone VALUES ('frontiermtns',NULL,'Frontier Mountains',-4262,-633,113,0,0,92);
INSERT INTO zone VALUES ('overthere',NULL,'The Overthere',-4263,-241,5,0,0,93);
INSERT INTO zone VALUES ('emeraldjungle',NULL,'The Emerald Jungle',4648,-1223,0,0,0,94);
INSERT INTO zone VALUES ('trakanon',NULL,'Trakanon\'s Teeth',1486,3868,340,0,0,95);
INSERT INTO zone VALUES ('timorous',NULL,'Timorous Deep',2194,-5392,4,0,0,96);
INSERT INTO zone VALUES ('kurn',NULL,'Kurn\'s Tower',0,0,4,0,0,97);
INSERT INTO zone VALUES ('erudsxing',NULL,'Erud\'s Crossing',795,-1767,5,0,0,98);
INSERT INTO zone VALUES ('stonebrunt',NULL,'Stonebrunt Mountains',-1643,-3428,5,0,0,100);
INSERT INTO zone VALUES ('warrens',NULL,'Warrens',0,0,5,0,0,101);
INSERT INTO zone VALUES ('karnor',NULL,'Karnor\'s Castle',305,18,3,0,0,102);
INSERT INTO zone VALUES ('chardok',NULL,'Chardok',154,-352,5,0,0,103);
INSERT INTO zone VALUES ('dalnir',NULL,'Dalnir',250,-929,5,0,0,104);
INSERT INTO zone VALUES ('charasis',NULL,'Howling stones',0,0,5,0,0,105);
INSERT INTO zone VALUES ('cabeast',NULL,'Cabilis East',-417,1362,5,0,0,106);
INSERT INTO zone VALUES ('nurga',NULL,'Mines of Nurga',-1318,-83,5,0,0,107);
INSERT INTO zone VALUES ('veeshan',NULL,'Veeshan\'s Peak',1680,40,30,0,0,108);
INSERT INTO zone VALUES ('iceclad',NULL,'Iceclad Ocean',340,5530,5,0,0,110);
INSERT INTO zone VALUES ('frozenshadow',NULL,'Tower of Frozen Shadow',200,120,5,0,0,111);
INSERT INTO zone VALUES ('velketor',NULL,'Velketor\'s Labrynth',-65,581,5,0,0,112);
INSERT INTO zone VALUES ('kael',NULL,'Kael Drakael',-633,-47,0,0,0,113);
INSERT INTO zone VALUES ('skyshrine',NULL,'Skyshrine',-730,-210,0,0,0,114);
INSERT INTO zone VALUES ('thurgadinb',NULL,'Icewell Keep',250,0,0,0,0,115);
INSERT INTO zone VALUES ('eastwastes',NULL,'Eastern Wastelands',4296,-5049,0,0,0,116);
INSERT INTO zone VALUES ('cobaltscar',NULL,'Cobalt Scar',-1185,-399,0,0,0,117);
INSERT INTO zone VALUES ('greatdivide',NULL,'Great Divide',-965,-7720,5,0,0,118);
INSERT INTO zone VALUES ('wakening',NULL,'The Wakening Lands',5000,-673,0,0,0,119);
INSERT INTO zone VALUES ('westwastes',NULL,'Western Wastelands',3500,-4100,5,0,0,120);
INSERT INTO zone VALUES ('crystal',NULL,'Crystal Caverns',303,487,0,0,0,121);
INSERT INTO zone VALUES ('necropolis',NULL,'Dragon Necropolis',0,0,5,0,0,123);
INSERT INTO zone VALUES ('templeveeshan',NULL,'Temple of Veeshan',-500,-2086,-40,46,0,124);
INSERT INTO zone VALUES ('sirens',NULL,'Sirens Grotto',0,0,5,0,0,125);
INSERT INTO zone VALUES ('mischiefplane',NULL,'Plane of Mischief',-395,-1410,115,46,0,126);
INSERT INTO zone VALUES ('growthplane',NULL,'Plane of Growth',0,0,5,46,0,127);
INSERT INTO zone VALUES ('sleeper',NULL,'Sleepers Tomb',0,0,0,0,0,128);
INSERT INTO zone VALUES ('shadowhaven',NULL,'Shadow Haven',190,-982,-58,0,0,150);
INSERT INTO zone VALUES ('bazaar',NULL,'The Bazaar',-172,-821,0,0,0,151);
INSERT INTO zone VALUES ('nexus',NULL,'The Nexus',12,3,-30,0,0,152);
INSERT INTO zone VALUES ('echo',NULL,'Echo Caverns',-800,840,0,0,0,153);
INSERT INTO zone VALUES ('acrylia',NULL,'Acrylia Caverns',-665,20,0,0,0,154);
INSERT INTO zone VALUES ('sharvahl',NULL,'Shar Vahl',85,-1135,0,0,0,155);
INSERT INTO zone VALUES ('paludal',NULL,'Paludal Caverns',241,-3721,0,0,0,156);
INSERT INTO zone VALUES ('fungusgrove',NULL,'Fungus Grove',1005,-2140,0,0,0,157);
INSERT INTO zone VALUES ('vexthal',NULL,'Vex Thal',1,-1122,-40,0,0,158);
INSERT INTO zone VALUES ('sseru',NULL,'Sanctus Seru',-233,1194,0,0,0,159);
INSERT INTO zone VALUES ('katta',NULL,'Katta Castellum',-545,645,0,0,0,160);
INSERT INTO zone VALUES ('netherbian',NULL,'Netherbian Lair',14,1787,0,0,0,161);
INSERT INTO zone VALUES ('ssratemple',NULL,'Ssraeshza Temple',0,0,0,0,0,162);
INSERT INTO zone VALUES ('griegsend',NULL,'Grieg\'s End',3461,-19,0,0,0,163);
INSERT INTO zone VALUES ('thedeep',NULL,'The Deepshade',-700,-398,0,0,0,164);
INSERT INTO zone VALUES ('shadeweaver',NULL,'Shadeweavers Thicket',-3570,-2122,0,0,0,165);
INSERT INTO zone VALUES ('hollowshade',NULL,'Hollowshade Moor',2420,1241,0,0,0,166);
INSERT INTO zone VALUES ('grimling',NULL,'Grimling Forest',-1140,-950,0,0,0,167);
INSERT INTO zone VALUES ('mseru',NULL,'Marus Seru',-15,-74,0,0,0,168);
INSERT INTO zone VALUES ('letalis',NULL,'Mons Letalis',-623,-1249,0,0,0,169);
INSERT INTO zone VALUES ('twilight',NULL,'The Twilight Sea',-1858,-420,0,0,0,170);
INSERT INTO zone VALUES ('thegrey',NULL,'The Grey',0,0,0,0,0,171);
INSERT INTO zone VALUES ('tenebrous',NULL,'The Tenebrous Mountains',1820,51,0,0,0,172);
INSERT INTO zone VALUES ('maiden',NULL,'The Maiden\'s Eye',1485,-960,0,0,0,173);
INSERT INTO zone VALUES ('dawnshroud',NULL,'Dawnshroud Peaks',2085,0,0,0,0,174);
INSERT INTO zone VALUES ('scarlet',NULL,'The Scarlet Desert',-1678,-1054,0,0,0,175);
INSERT INTO zone VALUES ('umbral',NULL,'The Umbral Plains',1900,-474,0,0,0,176);
INSERT INTO zone VALUES ('akheva',NULL,'Akheva Ruins',0,0,0,0,0,179);
INSERT INTO zone VALUES ('tutorial',NULL,'The Tutorial Zone',0,0,0,0,100,183);
INSERT INTO zone VALUES ('load',NULL,'Loading Zone',-316,5,8.2,0,100,184);
INSERT INTO zone VALUES ('thurgadina',NULL,'City of Thurgadin',0,-1222,5,0,0,192);

--
-- Table structure for table 'zone_points'
--

CREATE TABLE zone_points (
  id int(11) NOT NULL auto_increment,
  zone char(16) NOT NULL default '',
  y float NOT NULL default '0',
  x float NOT NULL default '0',
  z float NOT NULL default '0',
  target_zone char(16) NOT NULL default '',
  target_y float NOT NULL default '0',
  target_x float NOT NULL default '0',
  target_z float NOT NULL default '0',
  keep_x tinyint(1) NOT NULL default '0',
  keep_y tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'zone_points'
--


INSERT INTO zone_points VALUES (1,'qeynos',464,-440,351,'qeynos2',-155,-7,351,0,0);
INSERT INTO zone_points VALUES (2,'qeynos2',-155,-7,351,'qeynos',464,-440,351,0,0);
INSERT INTO zone_points VALUES (3,'qeynos',590,-76,351,'qeynos2',-30,357,351,0,0);
INSERT INTO zone_points VALUES (4,'qeynos2',-30,357,351,'qeynos',590,-76,351,0,0);
INSERT INTO zone_points VALUES (5,'qeynos',0,0,3,'qcat',0,0,3,0,0);
INSERT INTO zone_points VALUES (6,'qcat',0,0,3,'qeynos',0,0,3,0,0);
INSERT INTO zone_points VALUES (7,'qeynos2',0,0,3,'qcat',0,0,3,0,0);
INSERT INTO zone_points VALUES (8,'qcat',0,0,3,'qeynos2',0,0,3,0,0);
INSERT INTO zone_points VALUES (9,'qeynos2',102,1374,3.1,'qeytoqrg',94,-388,4,0,0);
INSERT INTO zone_points VALUES (10,'qeytoqrg',94,-388,4,'qeynos2',102,1200,3.1,0,0);
INSERT INTO zone_points VALUES (11,'qeytoqrg',5211,143,351,'qrg',114,-610,3,0,0);
INSERT INTO zone_points VALUES (12,'qrg',114,-610,3,'qeytoqrg',5221,153,3,0,0);
INSERT INTO zone_points VALUES (13,'qeytoqrg',1313,-2378,351,'qey2hh1',66,58,3,0,0);
INSERT INTO zone_points VALUES (14,'qey2hh1',46,38,3,'qeytoqrg',1333,-2398,3,0,0);
INSERT INTO zone_points VALUES (15,'qeytoqrg',-1156,3433,3,'blackburrow',0,-171,3,0,0);
INSERT INTO zone_points VALUES (16,'blackburrow',0,-171,3,'qeytoqrg',-1156,3433,3,0,0);
INSERT INTO zone_points VALUES (17,'qey2hh1',-15910,646,0,'northkarana',3242,627,0,0,0);
INSERT INTO zone_points VALUES (18,'northkarana',3242,627,0,'qey2hh1',-15910,646,0,0,0);
INSERT INTO zone_points VALUES (19,'northkarana',-3096,6,-33.5,'eastkarana',1066,12,-33.5,0,0);
INSERT INTO zone_points VALUES (20,'eastkarana',1066,12,-33.5,'northkarana',-3096,6,-33.5,0,0);
INSERT INTO zone_points VALUES (21,'northkarana',1212,-4487,-30,'southkarana',899,2880,-30,0,0);
INSERT INTO zone_points VALUES (22,'southkarana',899,2880,-30,'northkarana',1212,-4487,-30,0,0);
INSERT INTO zone_points VALUES (23,'eastkarana',-2014,3618,8,'beholder',-412,-1172,30.3,0,0);
INSERT INTO zone_points VALUES (24,'beholder',-412,-1172,30.3,'eastkarana',-2014,3618,8,0,0);
INSERT INTO zone_points VALUES (25,'eastkarana',-8336,-3080,693,'highpass',124,875,4,0,0);
INSERT INTO zone_points VALUES (26,'highpass',124,875,4,'eastkarana',-8336,-3080,693,0,0);
INSERT INTO zone_points VALUES (27,'southkarana',926,-3153,-8.8,'paw',27,-152,3,0,0);
INSERT INTO zone_points VALUES (28,'paw',27,-152,3,'southkarana',926,-3153,-8.8,0,0);
INSERT INTO zone_points VALUES (29,'southkarana',1180,-8520,3.3,'lakerathe',0,0,3,0,0);
INSERT INTO zone_points VALUES (30,'lakerathe',0,0,3,'southkarana',1180,-8520,3.3,0,0);
INSERT INTO zone_points VALUES (31,'beholder',-1855,902,4,'runnyeye',0,0,3,0,0);
INSERT INTO zone_points VALUES (32,'runnyeye',0,0,3,'beholder',-1855,902,4,0,0);
INSERT INTO zone_points VALUES (33,'runnyeye',0,0,3,'misty',1432,-837,-8,0,0);
INSERT INTO zone_points VALUES (34,'misty',1432,-837,-8,'runnyeye',0,0,3,0,0);
INSERT INTO zone_points VALUES (35,'highpass',-109,63,3.7,'kithicor',4888,567,693.7,0,0);
INSERT INTO zone_points VALUES (36,'kithicor',4888,567,693.7,'highpass',-109,63,3.7,0,0);
INSERT INTO zone_points VALUES (37,'highpass',109,63,3.7,'highkeep',86,-89,3.7,0,0);
INSERT INTO zone_points VALUES (38,'highkeep',86,-89,3.7,'highpass',109,63,3.7,0,0);
INSERT INTO zone_points VALUES (39,'kithicor',1092,1310,-40,'commons',4203,918,48.3,0,0);
INSERT INTO zone_points VALUES (40,'commons',4203,918,48.3,'kithicor',-1092,1310,-40,0,0);
INSERT INTO zone_points VALUES (41,'kithicor',3809,2009,466.7,'rivervale',156,-49,3.7,0,0);
INSERT INTO zone_points VALUES (42,'rivervale',156,-49,3.7,'kithicor',3809,2009,466.7,0,0);
INSERT INTO zone_points VALUES (43,'rivervale',152,-63,2,'misty',-2575,405,-8,0,0);
INSERT INTO zone_points VALUES (44,'misty',-2575,405,-8,'rivervale',152,-63,2,0,0);
INSERT INTO zone_points VALUES (45,'commons',0,0,3,'ecommons',0,0,3,0,0);
INSERT INTO zone_points VALUES (46,'ecommons',0,0,3,'commons',0,0,3,0,0);
INSERT INTO zone_points VALUES (47,'commons',576,-1146,-38.5,'befallen',0,0,3,0,0);
INSERT INTO zone_points VALUES (48,'befallen',0,0,3,'commons',576,-1146,-38.5,0,0);
INSERT INTO zone_points VALUES (49,'ecommons',1581,-6,-51,'freportw',1216,100,-24,0,0);
INSERT INTO zone_points VALUES (50,'freportw',1180,100,-24,'ecommons',1521,-6,-51,0,0);
INSERT INTO zone_points VALUES (51,'ecommons',612,1524,-18,'nektulos',-613,-2686,-18,0,0);
INSERT INTO zone_points VALUES (52,'nektulos',-613,-2686,-18,'ecommons',612,1524,-18,0,0);
INSERT INTO zone_points VALUES (53,'ecommons',-1266,-3089,3,'nro',1874,2025,3,0,0);
INSERT INTO zone_points VALUES (54,'nro',1874,2025,3,'ecommons',-1266,-3089,3,0,0);
INSERT INTO zone_points VALUES (55,'freportw',-618,-398,-24,'freporte',-400,456,-24,0,0);
INSERT INTO zone_points VALUES (56,'freporte',-380,426,-24,'freportw',-638,-378,-24,0,0);
INSERT INTO zone_points VALUES (57,'freportw',-669,321,-24,'freportn',-26,430,-24,0,0);
INSERT INTO zone_points VALUES (58,'freportn',-26,410,-24,'freportw',-649,301,-24,0,0);
INSERT INTO zone_points VALUES (59,'freporte',-620,-1587,-52,'nro',318,4036,-25,0,0);
INSERT INTO zone_points VALUES (60,'nro',318,4036,-25,'freporte',-620,-1587,-52,0,0);
INSERT INTO zone_points VALUES (61,'blackburrow',-322,163,3,'everfrost',-529,-3055,-110,0,0);
INSERT INTO zone_points VALUES (62,'everfrost',-529,-3055,-110,'blackburrow',-322,163,3,0,0);
INSERT INTO zone_points VALUES (63,'everfrost',-7068,2019,-60,'permafrost',0,0,3,0,0);
INSERT INTO zone_points VALUES (64,'permafrost',0,0,3,'everfrost',-7068,2019,-60,0,0);
INSERT INTO zone_points VALUES (65,'everfrost',377,3754,4,'halas',17,-72,5.3,0,0);
INSERT INTO zone_points VALUES (66,'halas',17,-72,5.3,'everfrost',377,3754,4,0,0);
INSERT INTO zone_points VALUES (67,'nektulos',-1106,2277,3.7,'neriakc',-834,189,-39,0,0);
INSERT INTO zone_points VALUES (68,'neriakc',-834,189,-39,'nektulos',-1106,2277,3.7,0,0);
INSERT INTO zone_points VALUES (69,'nektulos',316,3044,-14,'lavastorm',-172,-2107,-18,0,0);
INSERT INTO zone_points VALUES (70,'lavastorm',-172,-2107,-18,'nektulos',316,3044,-14,0,0);
INSERT INTO zone_points VALUES (71,'neriakc',-1809,904,-81,'neriakb',-305,40,-11,0,0);
INSERT INTO zone_points VALUES (72,'neriakb',-305,40,-11,'neriakc',-1809,904,-81,0,0);
INSERT INTO zone_points VALUES (73,'neriakb',-848,219,-39,'neriaka',-418,-46,-11,0,0);
INSERT INTO zone_points VALUES (74,'neriaka',-418,-46,-11,'neriakb',-848,219,-39,0,0);
INSERT INTO zone_points VALUES (75,'lavastorm',330,1351,148,'soltemple',0,0,3,0,0);
INSERT INTO zone_points VALUES (76,'soltemple',0,0,3,'lavastorm',330,1351,148,0,0);
INSERT INTO zone_points VALUES (77,'lavastorm',485,909,54,'soldunga',0,0,3,0,0);
INSERT INTO zone_points VALUES (78,'soldunga',0,0,3,'lavastorm',485,909,54,0,0);
INSERT INTO zone_points VALUES (79,'lavastorm',232,797,129,'soldungb',-572,-164,20,0,0);
INSERT INTO zone_points VALUES (80,'soldungb',-572,-164,20,'lavastorm',232,797,129,0,0);
INSERT INTO zone_points VALUES (81,'lavastorm',-1089,942,15,'najena',898,-12,3,0,0);
INSERT INTO zone_points VALUES (82,'najena',898,-12,3,'lavastorm',-1089,942,15,0,0);
INSERT INTO zone_points VALUES (83,'nro',-73,-1883,50,'oasis',-34,2119,3,0,0);
INSERT INTO zone_points VALUES (84,'oasis',-34,2119,3,'nro',-73,-1883,50,0,0);
INSERT INTO zone_points VALUES (85,'sro',-73,-1883,50,'oasis',-34,2119,3,0,0);
INSERT INTO zone_points VALUES (86,'oasis',-34,2119,3,'sro',-73,-1883,50,0,0);
INSERT INTO zone_points VALUES (87,'sro',-73,-1883,50,'innothule',-34,2119,3,0,0);
INSERT INTO zone_points VALUES (88,'innothule',-34,2119,3,'sro',-73,-1883,50,0,0);
INSERT INTO zone_points VALUES (89,'innothule',-841,157,-10,'guktop',0,0,3,0,0);
INSERT INTO zone_points VALUES (90,'guktop',0,0,3,'innothule',-841,157,-10,0,0);
INSERT INTO zone_points VALUES (91,'innothule',-634,293,-30,'grobb',18,-177,4,0,0);
INSERT INTO zone_points VALUES (92,'grobb',18,-177,4,'innothule',-634,293,-30,0,0);
INSERT INTO zone_points VALUES (93,'innothule',1886,-1132,-10,'feerrott',-3108,-1122,-10,0,0);
INSERT INTO zone_points VALUES (94,'feerrott',-3108,-1122,-10,'innothule',1886,-1132,-10,0,0);
INSERT INTO zone_points VALUES (95,'guktop',0,0,3,'gukbottom',0,0,3,0,0);
INSERT INTO zone_points VALUES (96,'gukbottom',0,0,3,'guktop',0,0,3,0,0);
INSERT INTO zone_points VALUES (97,'feerrott',3143,375,2,'rathemtn',0,0,3,0,0);
INSERT INTO zone_points VALUES (98,'rathemtn',0,0,3,'feerrott',3143,375,2,0,0);
INSERT INTO zone_points VALUES (99,'feerrott',0,0,3,'oggok',-48,-445,3,0,0);
INSERT INTO zone_points VALUES (100,'oggok',-48,-445,3,'feerrott',0,0,3,0,0);
INSERT INTO zone_points VALUES (101,'feerrott',-7,-1489,50,'cazicthule',-24,15,4,0,0);
INSERT INTO zone_points VALUES (102,'cazicthule',-24,15,4,'feerrott',-7,-1489,50,0,0);
INSERT INTO zone_points VALUES (103,'rathemtn',0,0,3,'lakerathe',0,0,3,0,0);
INSERT INTO zone_points VALUES (104,'lakerathe',0,0,3,'rathemtn',0,0,3,0,0);
INSERT INTO zone_points VALUES (105,'lakerathe',0,0,3,'arena',0,0,3,0,0);
INSERT INTO zone_points VALUES (106,'arena',0,0,3,'lakerathe',0,0,3,0,0);
INSERT INTO zone_points VALUES (107,'lakerathe',0,0,3,'southkarana',0,0,3,0,0);
INSERT INTO zone_points VALUES (108,'southkarana',0,0,3,'lakerathe',0,0,3,0,0);
INSERT INTO zone_points VALUES (181,'erudnext',-170,-644,77,'erudnint',-190,-1570,5,0,0);
INSERT INTO zone_points VALUES (182,'erudnint',-190,-1570,5,'erudnext',-170,-644,77,0,0);
INSERT INTO zone_points VALUES (109,'erudnext',-190,-1570,-44,'tox',297,2548,-45,0,0);
INSERT INTO zone_points VALUES (110,'tox',297,2548,-45,'erudnext',-190,-1570,-44,0,0);
INSERT INTO zone_points VALUES (111,'tox',-424,-2653,-41,'paineel',-958,644,-94,0,0);
INSERT INTO zone_points VALUES (112,'paineel',-958,644,-94,'tox',-424,-2653,-41,0,0);
INSERT INTO zone_points VALUES (113,'tox',0,0,3,'kerraridge',-994,421,22,0,0);
INSERT INTO zone_points VALUES (114,'kerraridge',-994,421,22,'tox',0,0,3,0,0);
INSERT INTO zone_points VALUES (115,'paineel',0,0,3,'hole',0,0,3,0,0);
INSERT INTO zone_points VALUES (116,'hole',0,0,3,'paineel',0,0,3,0,0);
INSERT INTO zone_points VALUES (117,'paineel',0,0,3,'warrens',0,0,3,0,0);
INSERT INTO zone_points VALUES (118,'warrens',0,0,3,'paineel',0,0,3,0,0);
INSERT INTO zone_points VALUES (119,'warrens',0,0,3,'stonebrunt',0,0,3,0,0);
INSERT INTO zone_points VALUES (120,'stonebrunt',0,0,3,'warrens',0,0,3,0,0);
INSERT INTO zone_points VALUES (121,'erudsxing',0,0,3,'erudnext',0,0,3,0,0);
INSERT INTO zone_points VALUES (122,'erudnext',0,0,3,'erudsxing',0,0,3,0,0);
INSERT INTO zone_points VALUES (123,'gfaydark',-1099,-2644,3,'lfaydark',1023,-2715,2,0,0);
INSERT INTO zone_points VALUES (124,'lfaydark',0,0,3,'gfaydark',-1099,-2644,3,0,0);
INSERT INTO zone_points VALUES (125,'gfaydark',-2595,-1943,23,'felwithe',255,6,3,0,0);
INSERT INTO zone_points VALUES (126,'felwithe',255,6,3,'gfaydark',-2595,-1943,23,0,0);
INSERT INTO zone_points VALUES (127,'felwithea',-711,-371,-10,'felwitheb',-818,217,-10,0,0);
INSERT INTO zone_points VALUES (128,'felwitheb',-818,217,-10,'felwithea',-711,-371,-10,0,0);
INSERT INTO zone_points VALUES (129,'gfaydark',-45,2642,19,'crushbone',206,-754,3,0,0);
INSERT INTO zone_points VALUES (130,'crushbone',206,-754,3,'gfaydark',-45,2642,19,0,0);
INSERT INTO zone_points VALUES (131,'gfaydark',2674,-1649,2,'butcherblock',0,0,3,0,0);
INSERT INTO zone_points VALUES (132,'butcherblock',0,0,3,'gfaydark',2674,-1649,2,0,0);
INSERT INTO zone_points VALUES (133,'butcherblock',-180,3142,3,'kaladima',22,-85,3,0,0);
INSERT INTO zone_points VALUES (134,'kaladima',22,-85,3,'butcherblock',-180,3142,3,0,0);
INSERT INTO zone_points VALUES (135,'kaladima',-266,394,4,'kaladimb',0,0,3,0,0);
INSERT INTO zone_points VALUES (136,'kaladimb',0,0,3,'kaladima',-266,394,4,0,0);
INSERT INTO zone_points VALUES (137,'butcherblock',0,0,3,'cauldron',268,2849,471,0,0);
INSERT INTO zone_points VALUES (138,'cauldron',268,2849,471,'butcherblock',0,0,3,0,0);
INSERT INTO zone_points VALUES (139,'cauldron',-651,2064,92,'unrest',290,119,3,0,0);
INSERT INTO zone_points VALUES (140,'unrest',290,119,3,'cauldron',-651,2064,92,0,0);
INSERT INTO zone_points VALUES (141,'cauldron',0,0,3,'kedge',0,0,3,0,0);
INSERT INTO zone_points VALUES (142,'kedge',0,0,3,'cauldron',0,0,3,0,0);
INSERT INTO zone_points VALUES (143,'lfaydark',-2185,924,-3,'steamfont',2201,586,-111,0,0);
INSERT INTO zone_points VALUES (144,'steamfont',2201,586,-111,'lfaydark',-2185,924,-3,0,0);
INSERT INTO zone_points VALUES (145,'lfaydark',-3362,-1090,2,'mistmoore',126,-361,3,0,0);
INSERT INTO zone_points VALUES (146,'mistmoore',126,-361,3,'lfaydark',-3362,-1090,2,0,0);
INSERT INTO zone_points VALUES (147,'steamfont',533,-2047,-107,'akanon',-62,73,3.1,0,0);
INSERT INTO zone_points VALUES (148,'akanon',-62,73,3.1,'steamfont',533,-2047,-107,0,0);
INSERT INTO zone_points VALUES (149,'cabeast',312,-35,4,'cabwest',318,-12,4,0,0);
INSERT INTO zone_points VALUES (150,'cabwest',318,-12,4,'cabeast',312,-35,4,0,0);
INSERT INTO zone_points VALUES (151,'cabeast',-574,-245,4,'swampofnohope',0,0,3,0,0);
INSERT INTO zone_points VALUES (152,'swampofnohope',0,0,3,'cabeast',-574,-245,4,0,0);
INSERT INTO zone_points VALUES (153,'cabeast',-494,1358,4,'fieldofbone',0,0,3,0,0);
INSERT INTO zone_points VALUES (154,'fieldofbone',0,0,3,'cabeast',-494,1358,4,0,0);
INSERT INTO zone_points VALUES (155,'cabwest',0,0,3,'warslikswoods',0,0,3,0,0);
INSERT INTO zone_points VALUES (156,'warslikswoods',0,0,3,'cabwest',0,0,3,0,0);
INSERT INTO zone_points VALUES (157,'cabwest',0,0,3,'lakeofillomen',0,0,3,0,0);
INSERT INTO zone_points VALUES (158,'lakeofillomen',0,0,3,'cabwest',0,0,3,0,0);
INSERT INTO zone_points VALUES (159,'swampofnohope',0,0,3,'trakanon',0,0,3,0,0);
INSERT INTO zone_points VALUES (160,'trakanon',0,0,3,'swampofnohope',0,0,3,0,0);
INSERT INTO zone_points VALUES (161,'swampofnohope',0,0,3,'firionavie',0,0,3,0,0);
INSERT INTO zone_points VALUES (162,'firionavie',0,0,3,'swampofnohope',0,0,3,0,0);
INSERT INTO zone_points VALUES (163,'trakanon',0,0,3,'sebilis',-1,83,3,0,0);
INSERT INTO zone_points VALUES (164,'sebilis',-1,83,3,'trakanon',0,0,3,0,0);
INSERT INTO zone_points VALUES (165,'trakanon',0,0,3,'emeraldjungle',0,0,3,0,0);
INSERT INTO zone_points VALUES (166,'emeraldjungle',0,0,3,'trakanon',0,0,3,0,0);
INSERT INTO zone_points VALUES (167,'emeraldjungle',0,0,3,'citymist',0,0,3,0,0);
INSERT INTO zone_points VALUES (168,'citymist',0,0,3,'emeraldjungle',0,0,3,0,0);
INSERT INTO zone_points VALUES (169,'emeraldjungle',0,0,3,'fieldofbone',0,0,3,0,0);
INSERT INTO zone_points VALUES (170,'fieldofbone',0,0,3,'emeraldjungle',0,0,3,0,0);
INSERT INTO zone_points VALUES (171,'fieldofbone',0,0,3,'kaesora',0,0,3,0,0);
INSERT INTO zone_points VALUES (172,'kaesora',0,0,3,'fieldofbone',0,0,3,0,0);
INSERT INTO zone_points VALUES (173,'fieldofbone',979,543,69,'kurn',0,0,3,0,0);
INSERT INTO zone_points VALUES (174,'kurn',0,0,3,'fieldofbone',979,543,69,0,0);
INSERT INTO zone_points VALUES (175,'lakeofillomen',0,0,3,'frontiermtns',0,0,3,0,0);
INSERT INTO zone_points VALUES (176,'frontiermtns',0,0,3,'lakeofillomen',0,0,3,0,0);
INSERT INTO zone_points VALUES (177,'lakeofillomen',0,0,3,'veksar',0,0,3,0,0);
INSERT INTO zone_points VALUES (178,'veksar',0,0,3,'lakeofillomen',0,0,3,0,0);
INSERT INTO zone_points VALUES (179,'frontiermtns',0,0,3,'chardok',867,-51,102,0,0);
INSERT INTO zone_points VALUES (180,'chardok',867,-51,102,'frontiermtns',0,0,3,0,0);
INSERT INTO zone_points VALUES (183,'qeynos',0,0,3,'erudnext',0,0,3,0,0);
INSERT INTO zone_points VALUES (184,'erudnext',0,0,3,'qeynos',0,0,3,0,0);
INSERT INTO zone_points VALUES (185,'freportn',0,0,3,'butcherblock',0,0,3,0,0);
INSERT INTO zone_points VALUES (186,'butcherblock',0,0,3,'freportn',0,0,3,0,0);
INSERT INTO zone_points VALUES (187,'oasis',0,0,3,'overthere',0,0,3,0,0);
INSERT INTO zone_points VALUES (188,'overthere',0,0,3,'oasis',0,0,3,0,0);

--
-- Table structure for table 'zone_server'
--

CREATE TABLE zone_server (
  name varchar(16) NOT NULL default '',
  address text NOT NULL,
  port int(11) NOT NULL default '0',
  player_count int(11) NOT NULL default '0',
  last_alive timestamp(14) NOT NULL,
  rain char(1) NOT NULL default '0',
  PRIMARY KEY  (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'zone_server'
--



--
-- Table structure for table 'zone_state_dump'
--

CREATE TABLE zone_state_dump (
  zonename varchar(16) NOT NULL default '',
  spawn2_count int(10) unsigned NOT NULL default '0',
  npc_count int(10) unsigned NOT NULL default '0',
  npcloot_count int(10) unsigned NOT NULL default '0',
  gmspawntype_count int(10) unsigned NOT NULL default '0',
  spawn2 mediumblob,
  npcs mediumblob,
  npc_loot mediumblob,
  gmspawntype mediumblob,
  time timestamp(14) NOT NULL,
  PRIMARY KEY  (zonename)
) TYPE=MyISAM;

--
-- Dumping data for table 'zone_state_dump'
--



--
-- Table structure for table 'zonepoints_raw'
--

CREATE TABLE zonepoints_raw (
  id int(11) NOT NULL auto_increment,
  zone varchar(16) NOT NULL default '',
  zoneline blob,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'zonepoints_raw'
--


INSERT INTO zonepoints_raw VALUES (1,'nexus','\0\0\0\0GH\0��D\0���\0\0|�\0\0�B�');
INSERT INTO zonepoints_raw VALUES (2,'nexus','\0\0\0\0AC\0\0*C\0@�D\0\0d�\0�yD�');
INSERT INTO zonepoints_raw VALUES (3,'nexus','\0\0\0\0ED\0�Z�\0\0@C\0\0�@\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (4,'nexus','\0\0\0\0IS\0@�\0``�\0\0��\0\0\0C�');
INSERT INTO zonepoints_raw VALUES (5,'nexus','\0\0\0 \0IS\0��D\0pKE\0\0�B\0\0�C�');
INSERT INTO zonepoints_raw VALUES (6,'nexus','\0\0\0\0N^\0��D\0\0h�\0\0lB\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (7,'nexus','\0\0\0	\0TY\0\0*C\0�D\0\0\\�\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (8,'nexus','\0\0\0\n\02^\0\0D\0�	�\0\0@@\0\0�C�');
INSERT INTO zonepoints_raw VALUES (9,'nexus','\0\0\0
\0NT\0Pf�\0 �D\0\0��\0\0�C\r');
INSERT INTO zonepoints_raw VALUES (10,'nexus','\0\0\0\03^\0p>E\0�F\0��D\0\0yCV');
INSERT INTO zonepoints_raw VALUES (11,'nexus','\0\0\0\r\0TY\0\0*C\0`�D\0\0H�\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (12,'nexus','\0\0\0\05^\0\0��\0@��\0\0p�\0\0\0C�');
INSERT INTO zonepoints_raw VALUES (13,'nexus','\0\0\0\0NT\0 ��\0��\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (14,'bazaar','\0\0\0\0GH\0��C\0�(D\0\0��\0\0�C�');
INSERT INTO zonepoints_raw VALUES (15,'bazaar','\0\0\0\0AC\0��C\0�FD\0\0��\0\0�C�');
INSERT INTO zonepoints_raw VALUES (16,'bazaar','\0\0\0\0ED\0\0��\0\0��\0\0p�\0\0�C�');
INSERT INTO zonepoints_raw VALUES (17,'shadowhaven','\0\0\0\0GH\0\0\0\0\0\0\0\0\0\0��\0�yD�');
INSERT INTO zonepoints_raw VALUES (18,'shadowhaven','\0\0\0\0AC\0�PD\0\0a�\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (19,'shadowhaven','\0\0\0\0ED\0\0z�\0\0��\0\0\0\0\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (20,'shadowhaven','\0\0\0\0IS\0 \n�\0�ZD\0���\0\0�C�');
INSERT INTO zonepoints_raw VALUES (21,'shadowhaven','\0\0\0\0IS\0\0>C\0��D\0\0\\�\0�yD�');
INSERT INTO zonepoints_raw VALUES (22,'shadowhaven','\0\0\0 \0N^\0\0>C\0��D\0\0��\0�yD�');
INSERT INTO zonepoints_raw VALUES (23,'shadowhaven','\0\0\0\0TY\0�Z�\0\0 �\0\0pA\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (24,'shadowhaven','\0\0\0	\02^\0�Z�\0\0W�\0\0pA\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (25,'shadowhaven','\0\0\0\n\0NT\0`��\0\0�A\0\0pB\0�yD�');
INSERT INTO zonepoints_raw VALUES (26,'shadowhaven','\0\0\0
\03^\0��\0`�D\0���\0\0�C�');
INSERT INTO zonepoints_raw VALUES (27,'shadowhaven','\0\0\0\0TY\0�(�\0��C\0\0��\0�yD�');
INSERT INTO zonepoints_raw VALUES (28,'echo','\0\0\0\0GH\0\0�C\0��D\0\0X�\0\0�C�');
INSERT INTO zonepoints_raw VALUES (29,'echo','\0\0\0\0AC\0��\0 ��\0\0��\0\0\0C�');
INSERT INTO zonepoints_raw VALUES (30,'echo','\0\0\0\0ED\0���\0�7�\0\0p�\0\0\0C�');
INSERT INTO zonepoints_raw VALUES (31,'echo','\0\0\0\0IS\0���\0��D\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (32,'echo','\0\0\0\0IS\0��\0 ��\0\0��\0\0\0C�');
INSERT INTO zonepoints_raw VALUES (33,'trakanon','\0\0\0\0GH\0��D\0���\0\0�B\0\0�CS');
INSERT INTO zonepoints_raw VALUES (34,'trakanon','\0\0\0\0AC\0V��#tI�#tI\0\0\0\0^');
INSERT INTO zonepoints_raw VALUES (35,'trakanon','\0\0\0\0ED\0\0xC\0\0��\0\0$B\0��CY');
INSERT INTO zonepoints_raw VALUES (36,'sebilis','\0\0\0\0GH\0���\0���\0���\0\0�C_');
INSERT INTO zonepoints_raw VALUES (37,'sebilis','\0\0\0\0AC\0���\0���\0���\0\0�C_');
INSERT INTO zonepoints_raw VALUES (38,'emeraldjungle','\0\0\0\0GH�#tI\0@���#tI\0�yDN');
INSERT INTO zonepoints_raw VALUES (39,'emeraldjungle','\0\0\0\0AC\0\0��\0�]�\0\0�@\0\0\0CZ');
INSERT INTO zonepoints_raw VALUES (40,'emeraldjungle','\0\0\0\0ED\0\0�A\0�]�\0\0�@\0\0\0CZ');
INSERT INTO zonepoints_raw VALUES (41,'emeraldjungle','\0\0\0\0IS\0pxE�#tI�#tI\0\0�C_');
INSERT INTO zonepoints_raw VALUES (42,'fieldofbone','\0\0\0\0GH\0\0�D\0�\Z�\0\0\0A\0�yDj');
INSERT INTO zonepoints_raw VALUES (43,'fieldofbone','\0\0\0\0AC\0@�D\0���\0\0\0A\0�yDj');
INSERT INTO zonepoints_raw VALUES (44,'fieldofbone','\0\0\0\0ED\0\0�C\0\0 B\0\0�B\0\0�CX');
INSERT INTO zonepoints_raw VALUES (45,'fieldofbone','\0\0\0\0IS\0\0��\0\0|B\0\0\0\0\0�yDa');
INSERT INTO zonepoints_raw VALUES (46,'fieldofbone','\0\0\0\0IS\0\0��\0\0|�\0\0\0\0\0�yDa');
INSERT INTO zonepoints_raw VALUES (47,'fieldofbone','\0\0\0\0N^�#tI\0�u��#tI\0�yDO');
INSERT INTO zonepoints_raw VALUES (48,'fieldofbone','\0\0\0 \0TY\0�E�#tI�#tI\0�yDS');
INSERT INTO zonepoints_raw VALUES (49,'fieldofbone','\0\0\0\02^�#tI\0��E�#tI\0�yD^');
INSERT INTO zonepoints_raw VALUES (50,'warslikswood','\0\0\0\0GH�#tI\0`�E�#tI\0�yDN');
INSERT INTO zonepoints_raw VALUES (51,'warslikswood','\0\0\0\0AC\0\0q�\00��\0\0xC\0\0\0C]');
INSERT INTO zonepoints_raw VALUES (52,'warslikswood','\0\0\0\0ED\0@YD\0��D\0\0\0A\0�yDR');
INSERT INTO zonepoints_raw VALUES (53,'warslikswood','\0\0\0\0IS\0\0\'D\0�D\0\0\0A\0\0�CR');
INSERT INTO zonepoints_raw VALUES (54,'warslikswood','\0\0\0\0IS\0\0��\0\0�B\0\0�@\0�yDh');
INSERT INTO zonepoints_raw VALUES (55,'warslikswood','\0\0\0\0N^\0p�E\0\0�D�#tI\0�yDU');
INSERT INTO zonepoints_raw VALUES (56,'thurgadina','\0\0\0\0GH\0\0DB\0\0��\0\0�B\0\0�Cv');
INSERT INTO zonepoints_raw VALUES (57,'thurgadina','\0\0\0\0AC\0\0>�\0\0��\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (58,'thurgadina','\0\0\0\0ED\0\0�B\0\04B\0\0@@\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (59,'thurgadinb','\0\0\0\0GH\0\0pC\0\0B\0\0@@\0\0�Cs');
INSERT INTO zonepoints_raw VALUES (60,'thurgadinb','\0\0\0\0AC\0`��\0\0E\0\0C\0�yDv');
INSERT INTO zonepoints_raw VALUES (61,'thurgadinb','\0\0\0\0ED\0@&�\0\0��\0\0��\0\0�Cs');
INSERT INTO zonepoints_raw VALUES (62,'greatdivide','\0\0\0\0GH\0 ��\0��E\0\0EC\0�yDt');
INSERT INTO zonepoints_raw VALUES (63,'greatdivide','\0\0\0\0AC\0���\0\0��\0\0\0\0\0\0\0\0s');
INSERT INTO zonepoints_raw VALUES (64,'greatdivide','\0\0\0\0ED\0@D\0\0��\0\0�\0\0~Cp');
INSERT INTO zonepoints_raw VALUES (65,'rivervale','\0\0\0b\0GH\0��D\0oE\0��C\0�yD');
INSERT INTO zonepoints_raw VALUES (66,'rivervale','\0\0\0c\0AC\0\0�C\0��\0\0��\0�yD!');
INSERT INTO zonepoints_raw VALUES (67,'misty','\0\0\0\0GH\0\0dC\0\0C\0\0�@\0�yD
');
INSERT INTO zonepoints_raw VALUES (68,'misty','\0\0\0\0AC\0\0��\0\0�B\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (69,'kithicor','\0\0\0\0GH\0�t�\0\0�B\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (70,'kithicor','\0\0\0\0AC\0���\0\0��\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (71,'lfaydark','\0\0\0\0GH\0�D\0�	E\0\0��\0�yD8');
INSERT INTO zonepoints_raw VALUES (72,'lfaydark','\0\0\0\0AC\0\0$�\0 ��\0\0�?\0�yD6');
INSERT INTO zonepoints_raw VALUES (73,'lfaydark','\0\0\0\0ED\0���\0\0�B\0\06�\0�yD;');
INSERT INTO zonepoints_raw VALUES (74,'lfaydark','\0\0\0	\0IS\0�cD\0���\0\0��\0\0bC*');
INSERT INTO zonepoints_raw VALUES (75,'gfaydark','\0\0\0\0GH\0\0 B\0\0HC\0\0�@\0�yD=');
INSERT INTO zonepoints_raw VALUES (76,'gfaydark','\0\0\0\0AC\0� E\0@��\0\0�?\0�yD9');
INSERT INTO zonepoints_raw VALUES (77,'gfaydark','\0\0\0\0ED\0\0��\0�@�\0\0�?\0�yDD');
INSERT INTO zonepoints_raw VALUES (78,'gfaydark','\0\0\0\0IS\0\0%�\0\0\"C\0\0�@\0�yD:');
INSERT INTO zonepoints_raw VALUES (79,'felwithea','\0\0\0\0GH\0\0tC\0�P�\0\0 �\0�yD>');
INSERT INTO zonepoints_raw VALUES (80,'felwithea','\0\0\0\0AC\0`��\0�$�\0\0�A\0�yD6');
INSERT INTO zonepoints_raw VALUES (81,'felwitheb','\0\0\0\0GH\0\0�C\0\04�\0\0 �\0�yD=');
INSERT INTO zonepoints_raw VALUES (82,'felwitheb','\0\0\0\0AC\0\0D\0���\0\0\0�\0\00C>');
INSERT INTO zonepoints_raw VALUES (83,'felwitheb','\0\0\0\0ED\0�D\0��\0\0��\0\0,B>');
INSERT INTO zonepoints_raw VALUES (84,'felwitheb','\0\0\0\0IS\0\0�C\0@3�\0\0��\0��C>');
INSERT INTO zonepoints_raw VALUES (85,'felwitheb','\0\0\0\0IS\0��C\0��\0\0 �\0\0�C>');
INSERT INTO zonepoints_raw VALUES (86,'felwitheb','\0\0\0\0N^\0��C\0��\0\0 �\0\0�C>');
INSERT INTO zonepoints_raw VALUES (87,'felwitheb','\0\0\0 \0TY\0��C\0��\0\0 �\0\0�C>');
INSERT INTO zonepoints_raw VALUES (88,'butcher','\0\0\0\0GH\0@��\0\'E\0\0�?\0�yD6');
INSERT INTO zonepoints_raw VALUES (89,'butcher','\0\0\0\0AC\0\0��\0\0(B\0\0�@\0�yD<');
INSERT INTO zonepoints_raw VALUES (90,'butcher','\0\0\0\0ED\0�2E\0\0�C\0��C\0�yDF');
INSERT INTO zonepoints_raw VALUES (91,'dalnir','\0\0\0\0GH\0� E\0 �E\0\0n�\0\0pBO');
INSERT INTO zonepoints_raw VALUES (92,'dalnir','\0\0\0\0AC\0� E\0 �E\0\0n�\0\0pBO');
INSERT INTO zonepoints_raw VALUES (93,'dalnir','\0\0\0c\0ED\0� E\0 �E\0\0n�\0\0pBO');
INSERT INTO zonepoints_raw VALUES (94,'overthere','\0\0\0\0GH\0\0q�\0`~E\0\0vC\0\0�CO');
INSERT INTO zonepoints_raw VALUES (95,'overthere','\0\0\0\0AC\0��E\0�D\0\0�C\0\0�C\\');
INSERT INTO zonepoints_raw VALUES (96,'overthere','\0\0\0\0ED\0 ��\08��\0\00B\0�yD[');
INSERT INTO zonepoints_raw VALUES (97,'overthere','\0\0\0\0IS\0���\08��\0\00B\0�yD[');
INSERT INTO zonepoints_raw VALUES (98,'overthere','\0\0\0\0IS\0\0\0\0\0\0\0\0\0\0\0�\0�yDi');
INSERT INTO zonepoints_raw VALUES (99,'frontiermtns','\0\0\0\0GH\0\0��\0QE\0\0�B\0\0�CU');
INSERT INTO zonepoints_raw VALUES (100,'frontiermtns','\0\0\0\0AC\0PE\0 Y�\0\0C\0�yDV');
INSERT INTO zonepoints_raw VALUES (101,'frontiermtns','\0\0\0\0ED\0@/�\0���\0\0��\0�yDW');
INSERT INTO zonepoints_raw VALUES (102,'frontiermtns','\0\0\0\0IS\00
�\0���\0\0�@\0�yDk');
INSERT INTO zonepoints_raw VALUES (103,'frontiermtns','\0\0\0\0IS\0��D\0\0�C\0\0�@\0�yDQ');
INSERT INTO zonepoints_raw VALUES (104,'frontiermtns','\0\0\0 \0N^\0���#tI�#tI\0�yD]');
INSERT INTO zonepoints_raw VALUES (105,'skyfire','\0\0\0\0GH\0ؤE�#tI�#tI\0�yDW');
INSERT INTO zonepoints_raw VALUES (106,'skyfire','\0\0\0\0AC\0���\0��E\0\0�B\0�yD]');
INSERT INTO zonepoints_raw VALUES (107,'skyfire','\0\0\0\0ED\0\0w�\0��E\0\0�B\0�yD]');
INSERT INTO zonepoints_raw VALUES (108,'skyfire','\0\0\0\0IS\0\0 B\0\0�D\0\0\0B\0�yDl');
INSERT INTO zonepoints_raw VALUES (109,'burningwood','\0\0\0\0GH\0@SE�#tI�#tI\0�yDV');
INSERT INTO zonepoints_raw VALUES (110,'burningwood','\0\0\0\0AC\0`���#tI�#tI\0�yD[');
INSERT INTO zonepoints_raw VALUES (111,'burningwood','\0\0\0\0ED\0�\0`�E\0\0��\0�yD\\');
INSERT INTO zonepoints_raw VALUES (112,'burningwood','\0\0\0\0IS\0\0��\0�hD\0\0�B\0\0�Cg');
INSERT INTO zonepoints_raw VALUES (113,'chardok','\0\0\0\0GH\0��E\0���\0\0f�\0\0zCW');
INSERT INTO zonepoints_raw VALUES (121,'dreadlands','\0\0\0\0IS\0\0��\0��C\0\0\0\0\0�yDf');
INSERT INTO zonepoints_raw VALUES (120,'dreadlands','\0\0\0\0ED\0�m�\0 J�\0\0��\0�yD\\');
INSERT INTO zonepoints_raw VALUES (119,'dreadlands','\0\0\0\0AC\0���\0\0F�\0\0IC\0�yDW');
INSERT INTO zonepoints_raw VALUES (118,'dreadlands','\0\0\0\0GH\0��C\0лE\0\0��\0�yDT');
INSERT INTO zonepoints_raw VALUES (122,'dreadlands','\0\0\0\0IS\0\0�B\0��C\0\0\0\0\0�yDf');
INSERT INTO zonepoints_raw VALUES (123,'dreadlands','\0\0\0\0N^\0\0\0\0\0\0\0\0\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (124,'karnor','\0\0\0\0GH\0�/D\0���\0\0�A\0�yDV');
INSERT INTO zonepoints_raw VALUES (125,'karnor','\0\0\0\0AC\0\0�C\0���\0\0�A\0�yDV');
INSERT INTO zonepoints_raw VALUES (126,'firiona','\0\0\0\0GH\0��C\0���\0\0C\0�yDV');
INSERT INTO zonepoints_raw VALUES (127,'firiona','\0\0\0\0AC\08���#tI�#tI\0�yDS');
INSERT INTO zonepoints_raw VALUES (128,'firiona','\0\0\0\0ED\0P���#tI�#tI\0�yDS');
INSERT INTO zonepoints_raw VALUES (129,'firiona','\0\0\0\0IS\0��D\0Љ�\0\0XC\0�yDU');
INSERT INTO zonepoints_raw VALUES (130,'lakeofillomen','\0\0\0\0GH\0\0��\0`��\0\0�B\0\00C\\');
INSERT INTO zonepoints_raw VALUES (131,'lakeofillomen','\0\0\0\0AC\0`�D\0�[E\0\0RC\0�yDT');
INSERT INTO zonepoints_raw VALUES (132,'lakeofillomen','\0\0\0\0ED\0d�\0��D�#tI\0�yDO');
INSERT INTO zonepoints_raw VALUES (133,'lakeofillomen','\0\0\0\0IS\0�C�\0�?D\0\0\0A\0\0�CR');
INSERT INTO zonepoints_raw VALUES (134,'lakeofillomen','\0\0\0 \0IS\0�v�\0�\rD\0\0\0A\0\0�@R');
INSERT INTO zonepoints_raw VALUES (135,'swampofnohope','\0\0\0\0GH\0�E�#tI�#tI\0�yDT');
INSERT INTO zonepoints_raw VALUES (136,'swampofnohope','\0\0\0\0AC\08�E�#tI�#tI\0�yDT');
INSERT INTO zonepoints_raw VALUES (137,'swampofnohope','\0\0\0\0ED\0`�D\08�E\0���\0\0\0\0_');
INSERT INTO zonepoints_raw VALUES (138,'swampofnohope','\0\0\0\0IS\0���\0\0��\0\0\0A\0�yDj');
INSERT INTO zonepoints_raw VALUES (139,'swampofnohope','\0\0\0\0IS\0\0��\0\0$�\0\0\0A\0�yDj');
INSERT INTO zonepoints_raw VALUES (140,'swampofnohope','\0\0\0 \0N^\0PR��#tI�#tI\0�yDN');
INSERT INTO zonepoints_raw VALUES (141,'netherbian','\0\0\0\0GH\0\0�C\0\0�A\0\0��\0��C�');
INSERT INTO zonepoints_raw VALUES (142,'netherbian','\0\0\0\0AC\0@�\0���\0\0��\0\0\"C�');
INSERT INTO zonepoints_raw VALUES (143,'netherbian','\0\0\0\0ED\0\0D\0`��\0\0��\0\0�B�');
INSERT INTO zonepoints_raw VALUES (144,'netherbian','\0\0\0\0IS\0��C\0���\0\0��\0\0�B�');
INSERT INTO zonepoints_raw VALUES (145,'netherbian','\0\0\0\0IS\0�E\0\0��\0\0�B\0\0�C�');
INSERT INTO zonepoints_raw VALUES (146,'netherbian','\0\0\0\0N^\0\0E\0\0u�\0\0�B\0\0�B�');
INSERT INTO zonepoints_raw VALUES (147,'mseru','\0\0\0\0GH\0��D\0��C\0\0lB\0��C�');
INSERT INTO zonepoints_raw VALUES (148,'mseru','\0\0\0\0AC\0@D\0\0D\0\0�B\0��C�');
INSERT INTO zonepoints_raw VALUES (149,'mseru','\0\0\0\0ED\0\0��\0@.�\0\0�A\0\0�A�');
INSERT INTO zonepoints_raw VALUES (150,'mseru','\0\0\0\0IS\0\0�C\0��D\0\0�B\0\0�C�');
INSERT INTO zonepoints_raw VALUES (151,'northkarana','\0\0\0\0GH\0\0\0\0\0\0\0\0\0\0��\0\0\0\0�');
INSERT INTO zonepoints_raw VALUES (152,'southkarana','\0\0\0\0GH\0��E\0��D\0\0�?\0�yD3');
INSERT INTO zonepoints_raw VALUES (153,'paw','\0\0\0\0GH\0pD�\0�hD\0\00�\0�yD');
INSERT INTO zonepoints_raw VALUES (154,'lakerathe','\0\0\0\0GH\00UE\0�=E\0\0\0�\0�yD2');
INSERT INTO zonepoints_raw VALUES (155,'lakerathe','\0\0\0\0AC\0\0l�\0@R�\0\0A\0�yDM');
INSERT INTO zonepoints_raw VALUES (156,'lakerathe','\0\0\0\0ED\0��\0��D\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (157,'arena','\0\0\0\0GH\0�E\0�(E\0\0�B\0�yD3');
INSERT INTO zonepoints_raw VALUES (158,'rathemtn','\0\0\0\0GH\0`E\0��\0\0�@\0�yD3');
INSERT INTO zonepoints_raw VALUES (159,'rathemtn','\0\0\0\0AC\0��C\0\0VE\0\0\0@\0�yD/');
INSERT INTO zonepoints_raw VALUES (160,'feerrott','\0\0\0\0GH\0 ��\0��D\0\00�\0�yD.');
INSERT INTO zonepoints_raw VALUES (161,'feerrott','\0\0\0\0AC\0��C\0�@�\0\0\0@\0�yD2');
INSERT INTO zonepoints_raw VALUES (162,'feerrott','\0\0\0\0ED\0\0lB\0\0��\0\0�@33�@0');
INSERT INTO zonepoints_raw VALUES (163,'feerrott','\0\0\0\0IS\0���\0\0��\0\0�?\0�yD1');
INSERT INTO zonepoints_raw VALUES (164,'feerrott','\0\0\0\0IS\0@A�\0��D\0\0�B\0\0�?H');
INSERT INTO zonepoints_raw VALUES (165,'cazicthule','\0\0\0\0GH\0\0��\0\0��\0\0PB\0\0�@/');
INSERT INTO zonepoints_raw VALUES (166,'innothule','\0\0\0\0GH\0�G�\0`�D�#tI\0�yD#');
INSERT INTO zonepoints_raw VALUES (167,'innothule','\0\0\0\0AC\0���\0�C�\0\0 �\0�yD/');
INSERT INTO zonepoints_raw VALUES (168,'innothule','\0\0\0\0ED\0\0�\0\0HB\0\0�@\0�yD4');
INSERT INTO zonepoints_raw VALUES (169,'innothule','\0\0\0\0IS\0\0P�\0\0B\0\0�@\0�yDA');
INSERT INTO zonepoints_raw VALUES (170,'grobb','\0\0\0\0GH\0 ,�\0��\0\0\0�\0�yD.');
INSERT INTO zonepoints_raw VALUES (171,'guktop','\0\0\0\0GH\0`�D\0\0�\0\0��\0\0�CB');
INSERT INTO zonepoints_raw VALUES (172,'guktop','\0\0\0\0AC\0@�D\0\0P�\0\0��\0��CB');
INSERT INTO zonepoints_raw VALUES (173,'guktop','\0\0\0\0ED\0��D\0�\"D\0\0��\0\0\0\0B');
INSERT INTO zonepoints_raw VALUES (174,'guktop','\0\0\0\0IS\0��D\0\0T�\0\0��\0�yDB');
INSERT INTO zonepoints_raw VALUES (175,'guktop','\0\0\0\0IS\0\0C\0�M�\0\00�\0�yD.');
INSERT INTO zonepoints_raw VALUES (176,'guktop','\0\0\0 \0N^\0`�D\0\0�\0\0��\0\0�CB');
INSERT INTO zonepoints_raw VALUES (177,'gukbottom','\0\0\0\0GH\0��D\0��C\0\0��\0�yDA');
INSERT INTO zonepoints_raw VALUES (178,'gukbottom','\0\0\0\0AC\0�D\0\0l�\0\0��\0\0%CA');
INSERT INTO zonepoints_raw VALUES (179,'gukbottom','\0\0\0\0ED\0\0\0\0\0\0\0\0\0\0�@\0\0\0\0A');
INSERT INTO zonepoints_raw VALUES (180,'gukbottom','\0\0\0\0IS\0��D\0\0D\0\0��\0\0\0\0A');
INSERT INTO zonepoints_raw VALUES (181,'gukbottom','\0\0\0\0IS\0��D\0\0@�\0\0��\0�yDA');
INSERT INTO zonepoints_raw VALUES (182,'gukbottom','\0\0\0 \0N^\0��D\0��C\0\0��\0�yDA');
INSERT INTO zonepoints_raw VALUES (183,'sro','\0\0\0\0GH\0`���#tI\0\0�@\0�yD%');
INSERT INTO zonepoints_raw VALUES (184,'sro','\0\0\0\0AC\0� E\0��D�#tI\0�yD.');
INSERT INTO zonepoints_raw VALUES (185,'oasis','\0\0\0\0GH\0����#tI�#tI\0�yD\"');
INSERT INTO zonepoints_raw VALUES (186,'oasis','\0\0\0\0AC\0@�D�#tI\0\0@@\0�yD#');
INSERT INTO zonepoints_raw VALUES (187,'nro','\0\0\0\0GH\0\0���#tI\0\0`�\0�yD\n');
INSERT INTO zonepoints_raw VALUES (188,'nro','\0\0\0\0AC\0�E�#tI�#tI\0�yD%');
INSERT INTO zonepoints_raw VALUES (189,'nro','\0\0\0\0ED\0��\0\0�\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (190,'nro','\0\0\0\0IS\0��E\0\0�C\0\0p�\0\0�Cn');
INSERT INTO zonepoints_raw VALUES (191,'freporte','\0\0\0	\0GH\0\0��\0�g�\0\0��\0�yD	');
INSERT INTO zonepoints_raw VALUES (192,'freporte','\0\0\0\n\0AC\0\0��\0��\0\0��\0�yD	');
INSERT INTO zonepoints_raw VALUES (193,'freporte','\0\0\0
\0ED\0ЁE�#tI\0\0��\0�yD\"');
INSERT INTO zonepoints_raw VALUES (194,'freporte','\0\0\05\0IS\0\09�\0\0��\0\0��\0�yD	');
INSERT INTO zonepoints_raw VALUES (195,'freportw','\0\0\0\0GH\0\0@A\0\0$�\0\0\\�\0�yD	');
INSERT INTO zonepoints_raw VALUES (196,'freportw','\0\0\0\0AC\0\0C\0�*�\0\0P�\0�yD	');
INSERT INTO zonepoints_raw VALUES (197,'freportw','\0\0\0 \0ED\0\0��\0\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (198,'freportw','\0\0\0\0IS\0\0��\0@D�#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (199,'freportw','\0\0\0	\0IS\0\0�B\0\0��\0\0��\0�yD\n');
INSERT INTO zonepoints_raw VALUES (200,'freportw','\0\0\0\n\0N^\0\0�C\0\0��\0\0��\0�yD\n');
INSERT INTO zonepoints_raw VALUES (201,'freportw','\0\0\0\0TY�#tI\0\0��\0\0X�\0�yD');
INSERT INTO zonepoints_raw VALUES (202,'freportw','\0\0\03\02^\0\0�C\0�4D\0\0\0�\0�yD');
INSERT INTO zonepoints_raw VALUES (203,'freportw','\0\0\04\0NT\0\0\0�\0���\0\0��\0�yD');
INSERT INTO zonepoints_raw VALUES (204,'freportw','\0\0\05\03^\0\0�\0\0�C\0\0��\0�yD\n');
INSERT INTO zonepoints_raw VALUES (205,'freportn','\0\0\0 \0GH\0��C\0\0/��#tI\0�yD	');
INSERT INTO zonepoints_raw VALUES (206,'freportn','\0\0\0\0AC\0\0cC\0\0���#tI\0�yD	');
INSERT INTO zonepoints_raw VALUES (207,'freportn','\0\0\03\0ED\0��D\0���\0\0�@\0�yD	');
INSERT INTO zonepoints_raw VALUES (208,'freportn','\0\0\04\0IS\0�6D\0@�\0\0��\0�yD	');
INSERT INTO zonepoints_raw VALUES (209,'ecommons','\0\0\0\0GH\0�\"E\0p5E\0\0�?\0�yD\"');
INSERT INTO zonepoints_raw VALUES (210,'neriaka','\0\0\0\0GH\0\0r��#tI�#tI\0�yD)');
INSERT INTO zonepoints_raw VALUES (211,'neriaka','\0\0\0\0AC�#tI\0����#tI\0�yD)');
INSERT INTO zonepoints_raw VALUES (212,'neriaka','\0\0\0\0ED\0�E\0 ��\0\0�?\0�yD');
INSERT INTO zonepoints_raw VALUES (213,'neriakb','\0\0\0\0GH\0\0w��#tI�#tI\0�yD(');
INSERT INTO zonepoints_raw VALUES (214,'neriakb','\0\0\0\0AC�#tI\0����#tI\0�yD(');
INSERT INTO zonepoints_raw VALUES (215,'neriakb','\0\0\0\0ED\0\0NC�#tI�#tI\0�yD*');
INSERT INTO zonepoints_raw VALUES (216,'neriakc','\0\0\0\0GH\0\0HC�#tI�#tI\0�yD)');
INSERT INTO zonepoints_raw VALUES (217,'neriakc','\0\0\0\0AC\0\0[�\0@�D\0\0��\0\0|C9');
INSERT INTO zonepoints_raw VALUES (218,'lavastorm','\0\0\0\0GH\0\0p�\0\0VD\0\0�@\0�yD,');
INSERT INTO zonepoints_raw VALUES (219,'lavastorm','\0\0\0\0AC\0@bD\0��C\0\0dB\0�yD');
INSERT INTO zonepoints_raw VALUES (220,'lavastorm','\0\0\0X\0ED\0\0zC\0\0`B\0\0@@\0�yDP');
INSERT INTO zonepoints_raw VALUES (221,'najena','\0\0\0\0GH\0\0j�\0@��\0\0PA\0�yD');
INSERT INTO zonepoints_raw VALUES (222,'soldunga','\0\0\0\0GH��CD=�cCR��B\0�yD');
INSERT INTO zonepoints_raw VALUES (223,'soldunga','\0\0\0\0AC�#tI\0����#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (224,'soldunga','\0\0\0\0ED�#tI\0\0��#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (225,'soldunga','\0\0\0\0IS�#tI\0\0���#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (226,'soldunga','\0\0\0\0IS\0����#tI�#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (227,'soldunga','\0\0\0\0N^�#tI\0\0���#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (228,'soldunga','\0\0\0 \0TY\0\0���#tI�#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (229,'soldunga','\0\0\0\02^�#tI\0\0��#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (230,'soldunga','\0\0\0	\0NT�#tI\0����#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (231,'soldunga','\0\0\0\n\03^�#tI\0\0���#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (232,'soldunga','\0\0\0
\0TY\0����#tI�#tI\0�yD ');
INSERT INTO zonepoints_raw VALUES (233,'soldunga','\0\0\0\05^\0�b�\0���\0\0 A\0\0\0C');
INSERT INTO zonepoints_raw VALUES (234,'soldungb','\0\0\0\0GH��cD\\/�C��eB\0�yD');
INSERT INTO zonepoints_raw VALUES (235,'soldungb','\0\0\0\0AC�#tI\0����#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (236,'soldungb','\0\0\0\0ED�#tI\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (237,'soldungb','\0\0\0\0IS�#tI\0\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (238,'soldungb','\0\0\0\0IS\0��C\0\0/�\0\0P�\0�yD-');
INSERT INTO zonepoints_raw VALUES (239,'soldungb','\0\0\0\0N^\0����#tI�#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (240,'soldungb','\0\0\0\0TY�#tI\0\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (241,'soldungb','\0\0\0\02^�#tI\0\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (242,'soldungb','\0\0\0 \0NT\0\0���#tI�#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (243,'soldungb','\0\0\0\03^�#tI\0��\0\0�A\0�yD');
INSERT INTO zonepoints_raw VALUES (244,'soldungb','\0\0\0	\0TY�#tI\0����#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (245,'soldungb','\0\0\0\n\05^�#tI\0\0���#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (246,'soldungb','\0\0\0
\0NT\0����#tI�#tI\0�yD');
INSERT INTO zonepoints_raw VALUES (247,'highpass','\0\0\0\0GH\0�A�\0H�\0�,D\0�yD');
INSERT INTO zonepoints_raw VALUES (248,'highpass','\0\0\0\0AC\0@
D\0��E\0�,D\0�yD');
INSERT INTO zonepoints_raw VALUES (249,'runnyeye','\0\0\0\0GH\0�aD\0���\0\0�@\0�yD');
INSERT INTO zonepoints_raw VALUES (250,'runnyeye','\0\0\0\0AC\0�O�\0�D\0\0�\0�yD!');
INSERT INTO zonepoints_raw VALUES (251,'airplane','\0\0\0\0GH\0���\0��C\0\0C\0\0\0\0%');
INSERT INTO zonepoints_raw VALUES (252,'airplane','\0\0\0\0AC\0\0D\0��D\0\0\0�\0�yDG');
INSERT INTO zonepoints_raw VALUES (253,'airplane','\0\0\0\0ED\0\0��\0\0��\0���\0�yDG');
INSERT INTO zonepoints_raw VALUES (254,'airplane','\0\0\0\0IS\0\0\rD\0\0�C\0\0\\�\0\0\0\0G');
INSERT INTO zonepoints_raw VALUES (255,'airplane','\0\0\0\0IS\0 �D\0@C�\0\0C\0�yDG');
INSERT INTO zonepoints_raw VALUES (256,'airplane','\0\0\0 \0N^\0\0]�\0 �D\0\0�C\0�yDG');
INSERT INTO zonepoints_raw VALUES (257,'airplane','\0\0\0\0TY\0�;�\0\0�C\0\0AD\0�yDG');
INSERT INTO zonepoints_raw VALUES (258,'airplane','\0\0\0	\02^\0\0v�\0���\0@}D\0�yDG');
INSERT INTO zonepoints_raw VALUES (259,'airplane','\0\0\0\n\0NT\0\0��\0���\0��D\0�yDG');
INSERT INTO zonepoints_raw VALUES (260,'airplane','\0\0\0
\03^\0\0��\0@��\0\0�A\0�yD\n');
INSERT INTO zonepoints_raw VALUES (261,'airplane','\0\0\0\0TY\0�D\0�D\0@?�\0\0zCG');

--
-- Table structure for table 'zoneserver_auth'
--

CREATE TABLE zoneserver_auth (
  host varchar(30) NOT NULL default '',
  note text,
  PRIMARY KEY  (host)
) TYPE=MyISAM;

--
-- Dumping data for table 'zoneserver_auth'
--


INSERT INTO zoneserver_auth VALUES ('%','Grant ALL');

