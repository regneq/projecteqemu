/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef CLIENT_H
#define CLIENT_H
class Client;

#include "../common/timer.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/EQNetwork.h"
#include "../common/linked_list.h"
#include "../common/database.h"
#include "errno.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "../common/deity.h"
#include "mob.h"
#include "npc.h"
#include "zone.h"
#include "../common/seperator.h"

#define CLIENT_TIMEOUT 90000

#define CLIENT_CONNECTING1	0
#define CLIENT_CONNECTING2	1
#define CLIENT_CONNECTING3	2
#define CLIENT_CONNECTING4	3
#define CLIENT_CONNECTING5	4
#define CLIENT_CONNECTED	5
#define CLIENT_KICKED		6
#define DISCONNECTED		7

class Client : public Mob
{
public:
	Client(EQNetworkConnection* ieqnc);
    ~Client();

	virtual bool IsClient() { return true; }

	void	FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho);
	virtual bool Process();
	void	ReceiveData(uchar* buf, int len);
	void	RemoveData();
	
	void	SendPacketQueue(bool Block = true);
	void	QueuePacket(APPLAYER* app, bool ack_req = true);
	void	ChannelMessageReceived(int8 chan_num, int8 language, const char* message, const char* targetname);
//	void	ChannelMessageReceived(int8 chan_num, int8 language, char* message);
	void	ChannelMessageSend(const char* from, const char* to, int8 chan_num, int8 language, const char* message, ...);
	void	Message(int32 type, const char* message, ...);
	void	operator<<(const char* message)		{ Message(0, "%s", message); }

	int32	GetIP()			{ return ip; }
	int16	GetPort()		{ return port; }
	bool	berserk;

	bool	Save();
	
	bool	Connected()		{ return (client_state == CLIENT_CONNECTED); }
	bool	IsState5()		{ return (client_state == CLIENT_CONNECTING5); }
	void	Kick() { Save(); client_state = CLIENT_KICKED; }
	void	WorldKick();
	int8	GetAnon()		{ return pp.anon; }
	PlayerProfile_Struct GetPP()	{ return pp; }
	bool	CheckAccess(int8 iDBLevel, int8 iDefaultLevel);

	bool IsEnd(char* string);
	bool IsCommented(char* string);
	char * rmnl(char* nstring);
	void CheckQuests(const char* zonename, const char* message, int32 npc_id, int32 item_id = 0);
	char * strreplace(char* searchstring, char* searchquery, const char* replacement);
	
	void	Attack(Mob* other, int Hand = 13);	// 13 = Primary (default), 14 = secondary
	void	Heal();
	void	Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill = 0x04);
	void	Death(Mob* other, sint32 damage, int16 spell_id = 0xFFFF, int8 attack_skill = 0x04);
	void	MakeCorpse(int32 exploss);

	void	Duck();
	void	Stand();

	void	SendHPUpdate();
	void	SetMaxHP();
	void	SetGM(bool toggle);
	void	SetPVP(bool toggle);
	bool	GetPVP()	{ return pp.pvp; }
	int8	GetGM()		{ return pp.gm; }

	int8	GetBaseRace()	{ return pp.race; }
	int8	GetBaseGender()	{ return pp.gender; }
	sint32	CalcMaxMana();
	sint32	SetMana(sint32 amount);

	int8	GetBaseSTR()	{ return pp.STR; }
	int8	GetBaseSTA()	{ return pp.STA; }
	int8	GetBaseCHA()	{ return pp.CHA; }
	int8	GetBaseDEX()	{ return pp.DEX; }
	int8	GetBaseINT()	{ return pp.INT; }
	int8	GetBaseAGI()	{ return pp.AGI; }
	int8	GetBaseWIS()	{ return pp.WIS; }
	int8	GetLanguageSkill(int8 n)	{ return pp.languages[n]; }


	int16	GetAC()			{ return GetRawItemAC() + itembonuses->AC + spellbonuses->AC; } // Quagmire - this is NOT the right math on this
	sint16	GetSTR()		{ return GetBaseSTR() + itembonuses->STR + spellbonuses->STR + aa.general_skills.named.innate_strength * 2; }
	sint16	GetSTA()		{ return GetBaseSTA() + itembonuses->STA + spellbonuses->STA + aa.general_skills.named.innate_stamina * 2; }
	sint16	GetDEX()		{ return GetBaseDEX() + itembonuses->DEX + spellbonuses->DEX + aa.general_skills.named.innate_dexterity * 2; }
	sint16	GetAGI()		{ return GetBaseAGI() + itembonuses->AGI + spellbonuses->AGI + aa.general_skills.named.innate_agility * 2; }
	sint16	GetINT()		{ return GetBaseINT() + itembonuses->INT + spellbonuses->INT + aa.general_skills.named.innate_intelligence * 2; }
	sint16	GetWIS()		{ return GetBaseWIS() + itembonuses->WIS + spellbonuses->WIS + aa.general_skills.named.innate_wisdom * 2; }
	sint16	GetCHA()		{ return GetBaseCHA() + itembonuses->CHA + spellbonuses->CHA + aa.general_skills.named.innate_charisma * 2; }

	uint32	GetEXP()		{ return pp.exp; }

	sint32	GetHP()			{ return cur_hp; }
	sint32	GetMaxHP()		{ return max_hp; }
	sint32	GetBaseHP()		{ return base_hp; }
	sint32	CalcMaxHP();
	sint32	CalcBaseHP();

	void	AddEXP(uint32 add_exp);
	void	SetEXP(int32 set_exp, int32 set_aaxp, bool resexp=false);
	//void	SetEXP(uint32 set_exp, bool isrezzexp = false);
	virtual void SetLevel(uint8 set_level, bool command = false);

	void	GoToBind();
	void	SetBindPoint();
	void	MovePC(const char* zonename, float x, float y, float z, bool ignorerestrictions = false, bool summoned = false);
	void	MovePC(int32 zoneID, float x, float y, float z, bool ignorerestrictions = false, bool summoned = false);
	void	WhoAll();
	void	SummonItem(int16 item_id, sint8 charges = 0);
	void	ChangeLastName(const char* in_lastname);

	void	AddToCursorBag(int16 item,int16 slot,int8 charges) {pp.cursorbaginventory[slot] = item;pp.cursorbagitemproperties[slot].charges = charges;}

	int8	GetFactionLevel(int32 char_id, int32 npc_id, int32 p_race, int32 p_class, int32 p_deity, int32 pFaction);
	
	void	SetFactionLevel(int32 char_id, int32 npc_id, int8 char_class, int8 char_race, int8 char_deity);
	void    SetFactionLevel2(int32 char_id, int32 faction_id, int8 char_class, int8 char_race, int8 char_deity, sint32 value);
	int8	GetSkill(int skill_num);
	virtual void SetSkill(int skill_num, int8 skill_id); // socket 12-29-01
	void	AddSkill(int skillid, int8 value);
	int16	GetRawItemAC();
	int16	GetCombinedAC_TEST();

	int32	CharacterID()	{ return character_id; }
	int32	AccountID()		{ return account_id; }
	char*	AccountName()	{ return account_name; }
	int8	Admin()			{ return admin; }
	void	UpdateAdmin();
	void	UpdateWho(bool remove = false);
	bool	GMHideMe(Client* client = 0);

	int32	GuildEQID()		{ return guildeqid; }
	int32	GuildDBID()		{ return guilddbid; }
	int8	GuildRank()		{ return guildrank; }
	bool	SetGuild(int32 in_guilddbid, int8 in_rank);

//	virtual void	CastSpell(int16 spell_id, int16 target_id, int16 slot = 10, int32 casttime = 0xFFFFFFFF);
	void	SendManaUpdatePacket();

    // Disgrace: currently set from database.CreateCharacter. 
	// Need to store in proper position in PlayerProfile...
	int8	GetFace()		{ return pp.face; } 
	int32	PendingGuildInvite; // Used for /guildinvite
	void	WhoAll(Who_All_Struct* whom);

	int16	GetItemAt(int16 in_slot);
	int16	FindFreeInventorySlot(int16** pointer = 0, bool ForBag = false, bool TryCursor = true);
	bool	PutItemInInventory(int16 slotid, int16 itemid, sint8 charges);
	bool	PutItemInInventory(int16 slotid, const Item_Struct* item);
	bool	PutItemInInventory(int16 slotid, const Item_Struct* item, sint8 charges);
	int16	TradeList[90];
	int8	TradeCharges[90];
	void	DeleteItemInInventory(uint32 slotid,bool clientupdate = false);
	int16	TradeWithEnt;
	sint8	InTrade;
	void	Stun(int16 duration);
	void	ReadBook(char txtfile[14]);

	void	TakeMoneyFromPP(uint32 copper);
	void	AddMoneyToPP(uint32 copper);
	void	AddMoneyToPP(uint32 copper, uint32 silver, uint32 gold,uint32 platinum);

	bool	CheckIncreaseSkill(int16 skillid,sint16 chancemodi = 0);
	void	FinishTrade(Client* whith);
	bool	isgrouped;
	void	ChangeTitle(int8 in_title) { this->pp.title = in_title; }
	void	SetZoneSummonCoords(float x, float y, float z) {zonesummon_x = x; zonesummon_y = y; zonesummon_z = z;}
	int32	pendingrezzexp;
	void	GMKill();
	void	RepairInventory();
	bool	IsMedding()	{return medding;}
	uint32  GetAAXP()   { return 0; } // FIXME! pp.expAA; }
	void  SendAAStats();
	void  SendAATable();
	bool	IsSitting() {return (playeraction == 1);}
	bool	IsBecomeNPC() { return npcflag; }
	int8	GetBecomeNPCLevel() { return npclevel; }
	void	SetBecomeNPC(bool flag) { npcflag = flag; }
	void	SetBecomeNPCLevel(int8 level) { npclevel = level; }
protected:
	friend class Mob;
	void CalcItemBonuses(StatBonuses* newbon);
	void MakeBuffFadePacket(int16 spell_id, int8 slot_id);
private:	
	int32 pLastUpdate;
	int8  playeraction;
    void FindItem(const char* search_criteria);

	EQNetworkConnection* eqnc;

	int32				ip;
	int16				port;
	int8				client_state;
	int32				character_id;
	int32				account_id;
	char				account_name[30];
	int8				admin;
	int32				guilddbid; // guild's ID in the database
	int8				guildrank; // player's rank in the guild, 0-GUILD_MAX_RANK
	bool				tellsoff;	// GM /toggle
	bool				gmhideme;
	bool				LFG;
	bool				auto_attack;
	bool				medding;
	PlayerProfile_Struct pp;
	Item_Struct cis;
	const Item_Struct* weapon1; // Primary Weapon ItemID.
	const Item_Struct* weapon2; // Secondary Weapon Item

	void GuildCommand(Seperator* sep);
	bool GuildEditCommand(int32 dbid, int32 eqid, int8 rank, const char* what, const char* value);
	uint32 GetEXPForLevel(uint16 level);

	//Disgrace: make due for now...
	char GetCasterClass();

	char	zonesummon_name[32];
	float	zonesummon_x;
	float	zonesummon_y;
	float	zonesummon_z;
	bool	zonesummon_ignorerestrictions;

	Timer*	position_timer;
	int8	position_timer_counter;

	void	SendInventoryItems();
	void	BulkSendInventoryItems();

	LinkedList<FactionValue*> factionvalue_list;
	sint32	GetCharacterFactionLevel(int32 faction_id);

	bool IsSettingGuildDoor;
	int16 SetGuildDoorID;

	int32       max_AAXP;
	PlayerAA_Struct aa; // Alternate Advancement!
	void DecreaseCharges(int16 slotid);
	bool npcflag;
	int8 npclevel;
};

#endif

