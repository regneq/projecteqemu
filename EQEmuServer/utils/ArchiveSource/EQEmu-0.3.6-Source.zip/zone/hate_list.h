/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef HATELIST_H
#define HATELIST_H

#include "../common/types.h"
#include <stdlib.h>

class Mob;
class HateListElement
{
private:

	Mob*				ent;
	sint32				damage;
	sint32				hate;
	HateListElement*	next;

public:

	HateListElement(Mob* in_ent, sint32 in_dam, sint32 in_hate)
	{
		ent = in_ent;
		damage = in_dam;
		hate = in_hate;
		next = 0;
	}

	~HateListElement()
	{
		if (next != 0)
		{
			delete next;
		}
	}

	void AddHate(sint32 in_dam, sint32 in_hate) { damage += in_dam; hate += in_hate; }
	sint32 GetHate() { return hate; }
	Mob* GetEnt() { return ent; }

	HateListElement* GetNext()         { return  next; }
	void SetNext(HateListElement* n)	{ next = n; } 
	void DoFactionHits(int32 npc_id);
};

class HateList
{
public:
	HateList();
	~HateList();

	// Heko - added to return hate of given ent
	sint32 GetEntHate(Mob* ent);
	void Add(Mob* ent, sint32 in_dam = 0, sint32 in_hate = 0xFFFFFFFF);
	void RemoveEnt(Mob* ent);
	Mob* GetTop();
	Mob* GetRandom();
	void Whipe();
	void DoFactionHits(int32 npc_id);
private:
	HateListElement* Pop(Mob* in_ent);

	HateListElement* first;
	int32	ElementCount;
};

#endif
