/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <math.h>

#include "mob.h"
#include "client.h"
#include "PlayerCorpse.h"
#include "zone.h"
#include "spdat.h"
#include "skills.h"

#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/database.h"
#include "../common/packet_dump.h"
#include "../common/packet_functions.h"

#include <stdio.h>
extern EntityList entity_list;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern Database database;

#define INTERACTIVE

Mob::Mob(const char*   in_name, 
         const char*   in_lastname, 
         sint32  in_cur_hp, 
         sint32  in_max_hp,
         int8    in_gender,
         int16    in_race,
         int8    in_class,
         int8    in_deity,
         int8    in_level,
         int32	 in_npctype_id, // rembrant, Dec. 20, 2001
         const int8*	 in_skills, // socket 12-29-01
		 float	in_size,
		 float	in_walkspeed,
		 float	in_runspeed,
         float	in_heading,
         float	in_x_pos,
         float	in_y_pos,
         float	in_z_pos,
		 
         int8    in_light,
         const int8*   in_equipment,
		 int8	 in_texture,
		 int8	 in_helmtexture,
		 int16	 in_ac,
		 int16	 in_atk,
		 int8	 in_str,
		 int8	 in_sta,
		 int8	 in_dex,
		 int8	 in_agi,
		 int8	 in_int,
		 int8	 in_wis,
		 int8	 in_cha,
		 int8	in_haircolor,
		 int8	in_beardcolor,
		 int8	in_eyecolor1, // the eyecolors always seem to be the same, maybe left and right eye?
		 int8	in_eyecolor2,
		 int8	in_hairstyle,
		 int8	in_title, //Face Overlay? (barbarian only)
		 int8	in_luclinface, // and beard
		 int16	in_fixed_z,
		 int16	in_d_meele_texture1,
		 int16	in_d_meele_texture2
		 )
{
	adverrorinfo = 0;
	strncpy(name,in_name,64);
	strncpy(lastname,in_lastname,64);
	cur_hp		= in_cur_hp;
	max_hp		= in_max_hp;
	base_hp		= in_max_hp;
	gender		= in_gender;
	race		= in_race;
	base_gender	= in_gender;
	base_race	= in_race;
	class_		= in_class;
	deity		= in_deity;
	level		= in_level;
	npctype_id	= in_npctype_id; // rembrant, Dec. 20, 2001
	size		= in_size;
	walkspeed	= (in_walkspeed > 0)?in_walkspeed:0.7f;
	runspeed	= (in_runspeed > 0)?in_runspeed:1.25f;
	heading		= in_heading;
	x_pos		= in_x_pos;
	y_pos		= in_y_pos;
	z_pos		= (in_fixed_z)?in_z_pos:in_z_pos*10;
	//fixedZ		= in_fixed_z;
	light		= in_light;
	texture		= in_texture;
	helmtexture	= in_helmtexture;
    d_meele_texture1 = in_d_meele_texture1;
	d_meele_texture2= in_d_meele_texture2;
	haircolor	= in_haircolor;
	beardcolor	= in_beardcolor;
	eyecolor1	= in_eyecolor1;
	eyecolor2	= in_eyecolor2;
	hairstyle	= in_hairstyle;
	title		= in_title;
	
	
	AC		= in_ac;
	ATK		= in_atk;
	STR		= in_str;
	STA		= in_sta;
	DEX		= in_dex;
	AGI		= in_agi;
	INT		= in_int;
	WIS		= in_wis;
	CHA		= in_cha;
	
	NPCTypedata = 0;
	HastePercentage = 0;
	
	cur_mana = 0;
	max_mana = 0;
	invisible = false;
	int i = 0;
	for (i=0; i<9; i++)
	{
		if (in_equipment == 0)
		{
			equipment[i] = 0;
		}
		else
		{
			equipment[i] = in_equipment[i];
		}
	}
	
	/*	for (i=0; i<74; i++) { // socket 12-29-01
	if (in_skills == 0) {
	skills[i] =0;
	}
	else {
	skills[i] = in_skills[i];
	}
		 }*/ // Quag: dont understand why a memcpy wont do the job here =P
	if (in_skills) {
		memcpy(skills, in_skills, 74);
	}
	else {
		memset(skills, 0, 74);
	}
	for (int j = 0; j < 15; j++) {
		buffs[j].spellid = 0xFFFF;
	}
	
	delta_heading = 0;
	delta_x = 0;
	delta_y = 0;
	delta_z = 0;
	
	invulnerable = false;
	appearance = 0;
	guildeqid = 0xFFFFFFFF;
	
	attack_timer = new Timer(2000);
	attack_timer_dw = new Timer(2000);
	tic_timer = new Timer(6000);
	mana_timer = new Timer(5000);
	spellend_timer = new Timer(0);
	casting_spell_id = 0;
	target = 0;
	
	itembonuses = new StatBonuses;
	spellbonuses = new StatBonuses;
	memset(itembonuses, 0, sizeof(StatBonuses));
	memset(spellbonuses, 0, sizeof(StatBonuses));
	spellbonuses->aggroradius = -1;
	pLastChange = 0;
	this->SetPetID(0);
	this->SetOwnerID(0);
	typeofpet = 0xFF;
	
	isattacked = false;
	isinterrupted = false;
	mezzed = false;
	stunned = false;
	stunned_timer = new Timer(0);
}     

Mob::~Mob()
{
	delete stunned_timer;
	SetPet(0);
	safe_delete(itembonuses);
	safe_delete(spellbonuses);
	safe_delete(spellend_timer);
	safe_delete(tic_timer);
	if (attack_timer != 0) {
		delete attack_timer;
		attack_timer = 0;
	}
	if (mana_timer != 0) {
		delete mana_timer;
		mana_timer = 0;
	}
	// Kaiyodo - destruction of dual wield attack timer
	if(attack_timer_dw != 0)
	{
		delete attack_timer_dw;
		attack_timer_dw = 0;
	}
	APPLAYER app;
	CreateDespawnPacket(&app);
	entity_list.QueueClients(this, &app, true);
	entity_list.RemoveFromTargets(this);
}

void Mob::CreateSpawnPacket(APPLAYER* app, Mob* ForWho) {
	app->opcode = OP_NewSpawn;
	app->pBuffer = new uchar[sizeof(NewSpawn_Struct)];
	app->size = sizeof(NewSpawn_Struct);
	
	memset(app->pBuffer, 0, sizeof(NewSpawn_Struct));
	NewSpawn_Struct* ns = (NewSpawn_Struct*)app->pBuffer;
	FillSpawnStruct(ns, ForWho);
	int8* tmp = app->pBuffer;
	app->pBuffer = new int8[app->size+50];
	app->size = DeflatePacket(tmp, app->size, app->pBuffer, app->size + 50);
	EncryptSpawnPacket(app);
}

void Mob::CreateSpawnPacket(APPLAYER* app, NewSpawn_Struct* ns) {
	app->opcode = OP_NewSpawn;
	app->pBuffer = new uchar[sizeof(NewSpawn_Struct)+50];
	app->size = DeflatePacket((int8*) ns, sizeof(NewSpawn_Struct), app->pBuffer, sizeof(NewSpawn_Struct) + 50);
	EncryptSpawnPacket(app);
}

void Mob::FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho) {
	ns->spawn.size = size;
	ns->spawn.walkspeed = walkspeed;
	ns->spawn.runspeed = runspeed;
	ns->spawn.heading = (int8) heading;
	ns->spawn.x_pos = (sint16) x_pos;
	ns->spawn.y_pos = (sint16) y_pos;
	ns->spawn.z_pos = (sint16) z_pos;
	ns->spawn.spawn_id = GetID();
	ns->spawn.cur_hp = GetHPRatio();
	ns->spawn.race = race;
	ns->spawn.GuildID = 0xffff;
	ns->spawn.guildrank = -1;
	if (this->invisible == false)
		ns->spawn.invis = 0;
	else
		ns->spawn.invis = 1;
	
	ns->spawn.NPC = 1;
#ifdef INTERACTIVE
	if(IsNPC() && CastToNPC()->IsInteractive())
		ns->spawn.NPC = 0;
	else
		ns->spawn.NPC = 1;
#endif
	ns->spawn.class_ = class_;
	ns->spawn.gender = gender;
	ns->spawn.level = level;
	ns->spawn.anim_type = 0x64;
	ns->spawn.light = light;
	
	ns->spawn.LD = 0;
	ns->spawn.npc_armor_graphic = texture;
	ns->spawn.npc_helm_graphic = helmtexture;
	strcpy(ns->spawn.name, name);
	strcpy(ns->spawn.lastname, lastname);
	ns->spawn.deity = deity;
	
	ns->spawn.pet_owner_id = ownerid;
	ns->spawn.haircolor = haircolor;
	ns->spawn.beardcolor = beardcolor;
	ns->spawn.eyecolor1 = eyecolor1;
	ns->spawn.eyecolor2 = eyecolor2;
	ns->spawn.hairstyle = hairstyle;
	ns->spawn.title = title;
	ns->spawn.equipment[7] = d_meele_texture1;
	ns->spawn.equipment[8] = d_meele_texture2;
	//	ns->spawn.luclinface = luclinface; See eq_packets_structs.h 
	ns->spawn.runspeed = runspeed;
	ns->spawn.walkspeed = walkspeed;
	
	if(IsNPC() && CastToNPC()->IsInteractive())
	{
		for(int i=-1;i<9;i++)
		{
			const Item_Struct* item = 0;
			item = database.GetItem(equipment[i]);
			if(item != 0)
			{
				if(i <= 7)
					ns->spawn.equipcolors[i] = item->common.color;
				ns->spawn.equipment[i] = item->common.material;
			}
			if(item == 0)
			{
				if(i<=7)
					ns->spawn.equipcolors[i] = 0;
				ns->spawn.equipment[i] = 0;
			}
		}
	}
	
}

void Mob::CreateDespawnPacket(APPLAYER* app)
{
	app->opcode = OP_DeleteSpawn;
	
	app->size = sizeof(DeleteSpawn_Struct);
	app->pBuffer = new uchar[app->size];
	memset(app->pBuffer, 0, app->size);
	DeleteSpawn_Struct* ds = (DeleteSpawn_Struct*)app->pBuffer;
	ds->spawn_id = GetID();
}

void Mob::CreateHPPacket(APPLAYER* app)
{
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	memset(app->pBuffer, 0, sizeof(SpawnHPUpdate_Struct));
	SpawnHPUpdate_Struct* ds = (SpawnHPUpdate_Struct*)app->pBuffer;
	ds->spawn_id = GetID();
	if (IsNPC()) {
		ds->cur_hp = GetHPRatio();
		ds->max_hp = 100;
	}
	else if (IsClient()) {
		if (GetHP() > 30000)
			ds->cur_hp = 30000;
		else
			ds->cur_hp = GetHP() - itembonuses->HP;
		
		if (max_hp > 30000)
			ds->max_hp = 30000;
		else
			ds->max_hp = max_hp - itembonuses->HP;
	}
	else {
		ds->cur_hp = cur_hp;
		ds->max_hp = max_hp;
	}
}

void Mob::SendPosUpdate(bool SendToSelf)
{
	APPLAYER* app = new APPLAYER;
	
	app->opcode = OP_MobUpdate;
	app->size = sizeof(SpawnPositionUpdates_Struct) + sizeof(SpawnPositionUpdate_Struct);
	
	app->pBuffer = new uchar[app->size];
	memset(app->pBuffer, 0, app->size);
	SpawnPositionUpdates_Struct* spu = (SpawnPositionUpdates_Struct*)app->pBuffer;	
	
	spu->num_updates = 1;
	MakeSpawnUpdate(&spu->spawn_update[0]);
	app->priority = 2;
	entity_list.QueueClients(this, app, !SendToSelf);
	delete app;
}

void Mob::MakeSpawnUpdate(SpawnPositionUpdate_Struct* spu) {
	spu->spawn_id = GetID();
	spu->anim_type = appearance;
	spu->heading = (int8) heading;
	spu->delta_heading = delta_heading;
	spu->x_pos = (sint16) x_pos;
	spu->y_pos = (sint16) y_pos;
	spu->z_pos = (sint16) z_pos;
	spu->delta_y = delta_y/125;
	spu->delta_x = delta_x/125;
	spu->delta_z = delta_z;
}

float Mob::Dist(Mob* other)
{
	return sqrt((double)(pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2) + pow(other->z_pos-z_pos, 2)));
	//	return pow((other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos), 1/3);
}

float Mob::DistNoZ(Mob* other)
{
	return sqrt((double)pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2));
	//	return pow((other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos), 1/3);
}

float Mob::DistNoRoot(Mob* other)
{
	return pow(other->x_pos-x_pos, 2) + pow(other->y_pos-y_pos, 2) + (pow(other->z_pos-z_pos, 2)*2);
	//	return (other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos)+(other->z_pos-z_pos)*(other->z_pos-z_pos);
}

float Mob::DistNoRootNoZ(Mob* other)
{
	return (other->x_pos-x_pos)*(other->x_pos-x_pos)+(other->y_pos-y_pos)*(other->y_pos-y_pos);
} 

void Mob::SetHP(sint32 hp) {
	if (hp >= max_hp)
		cur_hp = max_hp;
	else
		cur_hp = hp;
}

void Mob::ShowStats(Client* client) {
	client->Message(0, "Name: %s %s", GetName(), lastname);
	client->Message(0, "  Level: %i  MaxHP: %i  CurHP: %i  AC: %i", GetLevel(), GetMaxHP(), GetHP(), GetAC());
	client->Message(0, "  MaxMana: %i  CurMana: %i  ATK: %i  Size: %1.1f", GetMaxMana(), GetMana(), GetATK(), GetSize());
	client->Message(0, "  STR: %i  STA: %i  DEX: %i  AGI: %i  INT: %i  WIS: %i  CHA: %i", GetSTR(), GetSTA(), GetDEX(), GetAGI(), GetINT(), GetWIS(), GetCHA());
	client->Message(0, "  Race: %i  BaseRace: %i  Texture: %i  HelmTexture: %i  Gender: %i  BaseGender: %i", GetRace(), GetBaseRace(), GetTexture(), GetHelmTexture(), GetGender(), GetBaseGender());
	if (client->Admin() >= 100) {
		if (this->IsClient()) {
			client->Message(0, "  EntityID: %i  CharID: %i  PetID: %i", this->GetID(), this->CastToClient()->CharacterID(), this->GetPetID());
		}
		else if (this->IsCorpse()) {
			if (this->IsPlayerCorpse()) {
				client->Message(0, "  EntityID: %i  CharID: %i  PlayerCorpse: %i", this->GetID(), this->CastToCorpse()->GetCharID(), this->CastToCorpse()->GetDBID());
			}
			else {
				client->Message(0, "  EntityID: %i  NPCCorpse", this->GetID());
			}
		}
		else if (this->IsNPC()) {
			client->Message(0, "  EntityID: %i  NPCID: %i  LootTable: %i  PetID: %i  OwnerID: %i", this->GetID(), this->CastToNPC()->GetNPCTypeID(), this->CastToNPC()->GetLoottableID(), this->GetPetID(), this->GetOwnerID());
		}
	}
}

void Mob::DoAnim(const int animnum) {
	APPLAYER outapp;
	outapp.opcode = OP_Attack;
	outapp.size = sizeof(Attack_Struct);
	outapp.pBuffer = new uchar[outapp.size];
	memset(outapp.pBuffer, 0, outapp.size);
	Attack_Struct* a = (Attack_Struct*)outapp.pBuffer;
	a->spawn_id = GetID();
	a->type = animnum;
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;
	entity_list.QueueCloseClients(this, &outapp);
}

void Mob::ShowBuffs(Client* client) {
	if (!spells_loaded)
		return;
	client->Message(0, "Buffs on: %s", this->GetName());
	for (int i=0; i < 15; i++) {
		if (buffs[i].spellid != 0xFFFF) {
			if (buffs[i].durationformula == 50)
				client->Message(0, "  %i: %s: Permanent", i, spells[buffs[i].spellid].name);
			else
				client->Message(0, "  %i: %s: %i tics left", i, spells[buffs[i].spellid].name, buffs[i].ticsremaining);
		}
	}
}

sint32 Mob::SetMana(sint32 amount) {
	if (amount < 0)
		cur_mana = 0;
	else if (amount > GetMaxMana())
		cur_mana = GetMaxMana();
	else
		cur_mana = amount;
	return cur_mana;
}

void Mob::GMMove(float x, float y, float z, float heading) {
	this->x_pos = x;
	this->y_pos = y;
	this->z_pos = z;
	if (heading != 0.01)
		this->heading = heading;
	SendPosUpdate(true);
}

void Mob::SendIllusionPacket(int16 in_race, int8 in_gender, int16 in_texture, int16 in_helmtexture, int8 in_haircolor, int8 in_beardcolor, int8 in_eyecolor1, int8 in_eyecolor2, int8 in_hairstyle, int8 in_title, int8 in_luclinface) {
	if (in_race == 0) {
		this->race = GetBaseRace();
		if (in_gender == 0xFFFF)
			this->gender = GetBaseGender();
		else
			this->gender = in_gender;
	}
	else {
		this->race = in_race;
		if (in_gender == 0xFF) {
			int8 tmp = Mob::GetDefaultGender(this->race, gender);
			if (tmp == 2)
				gender = 2;
			else if (gender == 2 && GetBaseGender() == 2)
				gender = tmp;
			else if (gender == 2)
				gender = GetBaseGender();
		}
		else
			gender = in_gender;
	}
	if (in_texture == 0xFFFF) {
		if ((race == 0 || race > 12) && race != 128 && race != 130) {
			if (GetTexture() == 0xFF)
				this->texture = 0;
		}
		else if (in_race == 0)
			this->texture = 0xFF;
	}
	else if (in_texture != 0xFF || this->IsClient() || this->IsPlayerCorpse()) {
		this->texture = in_texture;
	}
	else
		this->texture = 0;
	if (in_helmtexture == 0xFFFF) {
		if (in_texture != 0xFFFF)
			this->helmtexture = this->texture;
		else if ((race == 0 || race > 12) && race != 128 && race != 130) {
			if (GetHelmTexture() == 0xFF)
				this->helmtexture = 0;
		}
		else if (in_race == 0)
			this->helmtexture = 0xFF;
		else
			this->helmtexture = 0;
	}
	else if (in_helmtexture != 0xFF || this->IsClient() || this->IsPlayerCorpse()) {
		this->helmtexture = in_helmtexture;
	}
	else
		this->texture = 0;
	if ((race == 0 || race > 12) && race != 128 && race != 130) {
		this->haircolor = in_haircolor;
		this->beardcolor = in_beardcolor;
		this->eyecolor1 = in_eyecolor1;
		this->eyecolor2 = in_eyecolor2;
		this->hairstyle = in_hairstyle;
		this->title = in_title;
		this->luclinface = in_luclinface;
	}
	else {
		this->hairstyle = 0xFF;
		this->beardcolor = 0xFF;
		this->eyecolor1 = 0xFF;
		this->eyecolor2 = 0xFF;
		this->hairstyle = 0xFF;
		this->title = 0xFF;
		this->luclinface = 0xFF;
	}
	APPLAYER* outapp = new APPLAYER(OP_Illusion, sizeof(Illusion_Struct));
	memset(outapp->pBuffer, 0, sizeof(outapp->pBuffer));
	Illusion_Struct* is = (Illusion_Struct*) outapp->pBuffer;
	is->spawnid = GetID();
	is->race = this->race;
	is->gender = this->gender;
	is->texture = this->texture;
	is->helmtexture = this->helmtexture;
	is->haircolor = this->haircolor;
	is->beardcolor = this->beardcolor;
	is->eyecolor1 = this->eyecolor1;
	is->eyecolor2 = this->eyecolor2;
	is->hairstyle = this->hairstyle;
	is->title = this->title;
	is->luclinface = this->luclinface;
	is->unknown_26 = 26;
	is->unknown016 = 0xffffffff;
	//DumpPacket(outapp);
	entity_list.QueueClients(this, outapp);
	delete outapp;
}

int8 Mob::GetDefaultGender(int8 in_race, int8 in_gender) {
	if ((in_race > 0 && in_race <= 12 ) || in_race == 128 || in_race == 130 ||
		in_race == 15 || in_race == 50 || in_race == 57 || in_race == 70 || in_race == 98 || in_race == 118) {
		if (in_gender >= 2) {
			// Female default for PC Races
			return 1;
		}
		else
			return in_gender;
	}
	else if (in_race == 44 || in_race == 52 || in_race == 55 || in_race == 65 || in_race == 67 || in_race == 88 || in_race == 117 || in_race == 127 ||
		in_race == 77 || in_race == 78 || in_race == 81 || in_race == 90 || in_race == 92 || in_race == 93 || in_race == 94 || in_race == 106 || in_race == 112) {
		// Male only races
		return 0;
	}
	else if (in_race == 25 || in_race == 56) {
		// Female only races
		return 1;
	}
	else {
		// Neutral default for NPC Races
		return 2;
	}
}

void Mob::TicProcess() {
	for (int buffs_i=0; buffs_i < 15; buffs_i++) {
		if (buffs[buffs_i].spellid != 0xFFFF) {
			DoBuffTic(buffs[buffs_i].spellid, buffs[buffs_i].ticsremaining, buffs[buffs_i].casterlevel, entity_list.GetMob(buffs[buffs_i].casterid));
			if (buffs[buffs_i].durationformula != 50) {
				buffs[buffs_i].ticsremaining--;
				if (buffs[buffs_i].ticsremaining <= 0) {
					BuffFade(buffs[buffs_i].spellid);
					buffs[buffs_i].spellid = 0xFFFF;
				}
			}
		}
	}
}

void Mob::SendAppearancePacket(int32 type, int32 value, bool WholeZone) {
	APPLAYER* outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
	SpawnAppearance_Struct* appearance = (SpawnAppearance_Struct*)outapp->pBuffer;
	appearance->spawn_id = this->GetID();
	appearance->type = type;
	appearance->parameter = value;
	if (WholeZone)
		entity_list.QueueClients(this, outapp, false);
	else if (this->IsClient())
		this->CastToClient()->QueuePacket(outapp);
	delete outapp;
}

void Mob::ChangeSize(float in_size = 0, bool bNoRestriction) {
	//Neotokyo's Size Code
	if (!bNoRestriction)
	{
		if (this->IsClient() || this->petid != 0)
			if (in_size < 3.0)
				in_size = 3.0;
			
			
			if (this->IsClient() || this->petid != 0)
				if (in_size > 15.0)
					in_size = 15.0;
	}
	
	
	if (in_size < 1.0)
		in_size = 1.0;
	
	if (in_size > 255.0)
		in_size = 255.0;
	//End of Neotokyo's Size Code
	this->size = in_size;
	SendAppearancePacket(29, (int32) in_size);
}


Mob* Mob::GetPet() {
	Mob* tmp = entity_list.GetMob(this->GetPetID());
	
	if (tmp) {
		if (tmp->GetOwnerID() == this->GetID()) {
			return tmp;
		}
		else {
			this->SetPetID(0);
			return 0;
		}
	}
	return 0;
}

void Mob::SetPet(Mob* newpet) {
	Mob* oldpet = GetPet();
	if (oldpet) {
		oldpet->SetOwnerID(0);
	}
	if (newpet == 0) {
		SetPetID(0);
	}
	else {
		SetPetID(newpet->GetID());
		Mob* oldowner = entity_list.GetMob(newpet->GetOwnerID());
		if (oldowner)
			oldowner->SetPetID(0);
		newpet->SetOwnerID(this->GetID());
	}
}

Mob* Mob::GetOwner() {
	Mob* owner = entity_list.GetMob(this->GetOwnerID());
	if (owner && owner->GetPetID() == this->GetID()) {
		return owner;
	}
	this->SetOwnerID(0);
	return 0;
}

void Mob::SetOwnerID(int16 NewOwnerID) {
	ownerid = NewOwnerID;
	if (ownerid == 0 && this->IsNPC() && this->GetPetType() != 0xFF)
		this->Depop();
}

//heko: for backstab
bool Mob::BehindMob(Mob* other, float playerx, float playery) {
	//see if player is behind mob
	float angle, lengthb, vectorx, vectory;
	float mobx = -(other->GetX());	// mob xlocation (inverse because eq is confused)
	float moby = other->GetY();		// mobylocation
	float heading = (int8)other->GetHeading();	// mob heading
	heading = (heading * 360.0)/256.0;	// convert to degrees
	if (heading < 270)
		heading += 90;
	else
		heading -= 270;
	heading = heading*3.1415/180.0;	// convert to radians
	vectorx = mobx + (10.0 * cosf(heading));	// create a vector based on heading
	vectory = moby + (10.0 * sinf(heading));	// of mob length 10
	
	//length of mob to player vector
	lengthb = (float)sqrt(pow((-playerx-mobx),2) + pow((playery-moby),2));
	
	// calculate dot product to get angle
	angle = acosf(((vectorx-mobx)*(-playerx-mobx)+(vectory-moby)*(playery-moby)) / (10 * lengthb));
	angle = angle * 180 / 3.1415;
	if (angle > 90.0) //not sure what value to use (90*2=180 degrees is front)
		return true;
	else
		return false;
}

void Mob::SetZone(int32 zone_id)
{
if(IsClient())
CastToClient()->pp.current_zone = zone_id;
Save();
}

void Mob::Kill() {
	Death(this, 0, 0xffff, 0x04);
}

void Mob::SetAttackTimer() {
	// Quagmire - image's attack timer code
	float PermaHaste = 100.0f / (100.0f + GetHaste()+GetItemHaste()); //PercentageHaste);  	// use #haste to set haste level
	if(PermaHaste > .9)
		PermaHaste = .9;
	
	Timer	*TimerToUse;
	const Item_Struct *ItemToUse;
	
	for(int i=13 ; i <= 14 ; i++)
	{
		ItemToUse = 0;
		if(i==13)
			TimerToUse = attack_timer;
		else
			TimerToUse = attack_timer_dw;
		
		if (IsClient())
			ItemToUse = database.GetItem(CastToClient()->pp.inventory[i]);
		
		if(!ItemToUse)
		{
			// Work out if we're a monk
			if(GetClass() == MONK || GetClass() == BEASTLORD)
			{
				int speed = (int)(GetMonkHandToHandDelay()*100.0f*PermaHaste);
				if(speed < 1200)
					speed = 1200;
				TimerToUse->Start(speed);		// Hand to hand, delay based on level or epic
				//printf("Fist Timer started = %d\n", (int)(GetMonkHandToHandDelay()*100.0f*PermaHaste));
			}
			else
			{
				int speed = (int)(3600*PermaHaste);
				if(speed < 1800)
					speed = 1800;
				TimerToUse->Start(speed); 	// Hand to hand, non-monk 2/36
			}
		}
		else
			if(ItemToUse->common.skill > 4 && ItemToUse->common.skill != 45 && ItemToUse->common.skill != 23)			// Check skill is valid
				TimerToUse->Disable();		// Disable timer if primary item uses a non-weapon skill
			else
			{
				int speed = (int)(ItemToUse->common.delay*(100.0f*PermaHaste));
				if(speed < 1200)
					speed = 1200;
				TimerToUse->Start(speed);	// Convert weapon delay to timer resolution (milliseconds)
				//Message(0, "Weapon Timer started = %d", (int)(ItemToUse->common.delay*(100.0f*PermaHaste)));
			}
	}
}

bool Mob::CanThisClassDuelWield(void)
{
	// Kaiyodo - Check the classes that can DW, and make sure we're not using a 2 hander
	switch(GetClass())
	{
	case WARRIOR:
	case MONK:
	case RANGER:
	case ROGUE:
	case BARD:
	case BEASTLORD:
		{
			// Check the weapon in the main hand, see if it's a 2 hander
			if (IsClient()) {
				uint16 item_id = CastToClient()->pp.inventory[13];
				const Item_Struct* item = database.GetItem(item_id);
				
				// 2HS, 2HB or 2HP
				if(item && (item->common.skill == 0x01 || item->common.skill == 0x23 ||
					item->common.skill == 0x04))
					return(false);
			}
		}
		if (this->IsClient())
			return(this->CastToClient()->GetSkill(DOUBLE_ATTACK) != 0);	// No skill = no chance
		else
			return true;
	}
	
	return(false);
}

bool Mob::CanThisClassDoubleAttack(void)
{
	// Kaiyodo - Check the classes that can DA
	switch(GetClass())
	{
	case WARRIOR:
	case MONK:
	case RANGER:
	case PALADIN:
	case SHADOWKNIGHT:
	case ROGUE:
		if (this->IsClient())
			return(this->CastToClient()->GetSkill(DUEL_WIELD) != 0);	// No skill = no chance
		else
			return true;
	}
	
	return(false);
}
int8 Mob::GetClassLevelFactor(){
	int8 multiplier = 0;
	switch(GetClass())
	{
	case WARRIOR:
		if (GetLevel() < 20)
			multiplier = 22;
		else if (GetLevel() < 30)
			multiplier = 23;
		else if (GetLevel() < 40)
			multiplier = 25;
		else if (GetLevel() < 53)
			multiplier = 27;
		else if (GetLevel() < 57)
			multiplier = 28;
		else
			multiplier = 30;
		break;
		
	case DRUID:
	case CLERIC:
	case SHAMAN:
		multiplier = 15;
		break;
		
	case PALADIN:
	case SHADOWKNIGHT:
		if (GetLevel() < 35)
			multiplier = 21;
		else if (GetLevel() < 45)
			multiplier = 22;
		else if (GetLevel() < 51)
			multiplier = 23;
		else if (GetLevel() < 56)
			multiplier = 24;
		else if (GetLevel() < 60)
			multiplier = 25;
		else
			multiplier = 26;
		break;
		
	case MONK:
	case BARD:
	case ROGUE:
	case BEASTLORD:
		if (GetLevel() < 51)
			multiplier = 18;
		else if (GetLevel() < 58)
			multiplier = 19;
		else
			multiplier = 20;				
		break;
		
	case RANGER:
		if (GetLevel() < 58)
			multiplier = 20;
		else
			multiplier = 21;			
		break;
		
	case MAGICIAN:
	case WIZARD:
	case NECROMANCER:
	case ENCHANTER:
		multiplier = 12; 
		break;
		
	default:
		//cerr << "Unknown/invalid class in Client::CalcBaseHP" << endl;
		if (GetLevel() < 35)
			multiplier = 21;
		else if (GetLevel() < 45)
			multiplier = 22;
		else if (GetLevel() < 51)
			multiplier = 23;
		else if (GetLevel() < 56)
			multiplier = 24;
		else if (GetLevel() < 60)
			multiplier = 25;
		else
			multiplier = 26;
		break;
	}
	return multiplier;
}

/* 
solar: returns false if attack should not be allowed
I try to list every type of conflict that's possible here, so it's easy
to see how the decision is made.  Yea, it could be condensed and made
faster, but I'm doing it this way to make it readable and easy to modify
*/
bool Mob::IsAttackAllowed(Mob *target)
{
	if(!target) return 0;
	
	/* self */
	if(this->GetID() == target->GetID())
	{
		return 0;
	}
	
	if(_CLIENT(this))
	{
		if(_CLIENT(target))
		{
			if(this->CastToClient()->GetPVP() != target->CastToClient()->GetPVP())
				return 0;
			else if(this->CastToClient()->GetPVP() && target->CastToClient()->GetPVP())
				return 1;
			else if(this->CastToClient()->GetDuelTarget() == target->GetID() && target->CastToClient()->GetDuelTarget() == GetID() && target->CastToClient()->IsDueling() && this->CastToClient()->IsDueling())
				return 1;
		}
		else if(_NPC(target))
		{
			if(target->CastToNPC()->IsInteractive() && (!target->CastToNPC()->IsPVP() || !this->CastToClient()->GetPVP()))
				return 0;
			else
				return 1;
		}
		else if(_BECOMENPC(target))
		{
			if(this->CastToClient()->GetLevel() > target->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_CLIENTPET(target))
		{
			if(this->CastToClient()->GetDuelTarget() == target->CastToMob()->GetOwner()->GetID() && target->CastToMob()->GetOwner()->CastToClient()->GetDuelTarget() == GetID() && target->CastToMob()->GetOwner()->CastToClient()->IsDueling() && this->CastToClient()->IsDueling())
				return 1;
			else if(this->CastToClient()->GetPVP() != target->CastToMob()->GetOwner()->CastToClient()->GetPVP())
				return 0;
			else if(this->CastToClient()->GetPVP() && target->CastToMob()->GetOwner()->CastToClient()->GetPVP())
				return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			if(this->CastToClient()->GetLevel() > target->CastToMob()->GetOwner()->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else
		{
			goto nocase;
		}
	}
	else if(_NPC(this))
	{
		if(_CLIENT(target))
		{
			if(CastToNPC()->IsInteractive() && (!CastToNPC()->IsPVP() || !target->CastToClient()->GetPVP()))
				return 0;
			
			return 1;
		}
		else if(_NPC(target))
		{
			return 1;
		}
		else if(_BECOMENPC(target))
		{
			return 1;
		}
		else if(_CLIENTPET(target))
		{
			return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			return 1;
		}
		else
		{
			goto nocase;
		}
	}
	else if(_BECOMENPC(this))
	{
		if(_CLIENT(target))
		{
			if(target->CastToClient()->GetLevel() > this->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_NPC(target))
		{
			return 1;
		}
		else if(_BECOMENPC(target))
		{
			return 1;
		}
		else if(_CLIENTPET(target))
		{
			if(target->CastToMob()->GetOwner()->CastToClient()->GetLevel() > this->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			return 1;
		}
		else
		{
			goto nocase;
		}
	}
	else if(_CLIENTPET(this))
	{
		if(_CLIENT(target))
		{
			if(this->CastToMob()->GetOwner()->CastToClient()->IsDueling() && this->CastToMob()->GetOwner()->CastToClient()->GetDuelTarget() == target->GetID() && target->CastToClient()->IsDueling() && target->CastToClient()->GetDuelTarget() == this->CastToMob()->GetOwner()->GetID())
				return 1;
			else if(this->CastToMob()->GetOwner()->CastToClient()->GetPVP() != target->CastToClient()->GetPVP())
				return 0;
			else if(this->CastToMob()->GetOwner()->CastToClient()->GetPVP() && target->CastToClient()->GetPVP())
				return 1;
		}
		else if(_NPC(target))
		{
			return 1;
		}
		else if(_BECOMENPC(target))
		{
			if(this->CastToMob()->GetOwner()->CastToClient()->GetLevel() > target->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_CLIENTPET(target))
		{
			if(this->CastToMob()->GetOwner()->CastToClient()->IsDueling() && this->CastToMob()->GetOwner()->CastToClient()->GetDuelTarget() == target->CastToMob()->GetOwner()->GetID() && target->CastToMob()->GetOwner()->CastToClient()->IsDueling() && target->CastToMob()->GetOwner()->CastToClient()->GetDuelTarget() == this->CastToMob()->GetOwner()->GetID())
				return 1;
			else if(this->CastToMob()->GetOwner()->CastToClient()->GetPVP() != target->CastToMob()->GetOwner()->CastToClient()->GetPVP())
				return 0;
			else if(this->CastToMob()->GetOwner()->CastToClient()->GetPVP() && target->CastToMob()->GetOwner()->CastToClient()->GetPVP())
				return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			if(this->CastToMob()->GetOwner()->CastToClient()->GetLevel() > target->CastToMob()->GetOwner()->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else
		{
			goto nocase;
		}
	}
	else if(_NPCPET(this))
	{
		if(_CLIENT(target))
		{
			return 1;
		}
		else if(_NPC(target))
		{
			return 1;
		}
		else if(_BECOMENPC(target))
		{
			return 1;
		}
		else if(_CLIENTPET(target))
		{
			return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			return 1;
		}
		else
		{
			goto nocase;
		}
	}
	else if(_BECOMENPCPET(this))
	{
		if(_CLIENT(target))
		{
			if(target->CastToClient()->GetLevel() > this->CastToMob()->GetOwner()->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_NPC(target))
		{
			return 1;
		}
		else if(_BECOMENPC(target))
		{
			return 1;
		}
		else if(_CLIENTPET(target))
		{
			if(target->CastToMob()->GetOwner()->CastToClient()->GetLevel() > this->CastToMob()->GetOwner()->CastToClient()->GetBecomeNPCLevel())
				return 0;
			else
				return 1;
		}
		else if(_NPCPET(target))
		{
			return 1;
		}
		else if(_BECOMENPCPET(target))
		{
			return 1;
		}
		else
		{
			goto nocase;
		}
	}
	
nocase:
	printf("Mob::IsAttackAllowed: don't have a rule for this - %s vs %s\n", this->GetName(), target->GetName());
	return 0;
}
