#include "../common/debug.h"
#include "Scripts.h"
#include <string.h>

#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef WIN32
	#include <windows.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

#include "../common/races.h"
#include "../common/classes.h"
#include "worldserver.h"
#include "client.h"
#include "../common/database.h"

Scripts scripts;
extern EntityList entity_list;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern Database database;

char*	strreplace(char* line, char* search, const char* replacement, int linesize, char** destination = 0, bool deleteinput = false);

Scripts::Scripts() {
	triggerarray = 0;
	max_triggerarray = 0;
	actionarray = 0;
	max_actionarray = 0;
	NextTimer = 0xFFFFFFFF;
}

Scripts::~Scripts() {
	Clear();
}

void Scripts::Clear() {
	int32 i;
	if (triggerarray) {
		for (i=0; i<max_triggerarray; i++) {
			safe_delete(triggerarray[i].MatchText);
		}
		safe_delete(triggerarray);
	}
	if (actionarray) {
		for (i=0; i<max_actionarray; i++) {
			safe_delete(actionarray[i]);
		}
		safe_delete(actionarray);
	}
	triggerarray = 0;
	max_triggerarray = 0;
	actionarray = 0;
	max_actionarray = 0;
	NextTimer = 0xFFFFFFFF;
}

bool Scripts::Load(char* ifilename) {
	char filename[255];
#ifdef WIN32
	snprintf(filename, 255, "Quests\\%s.qst", ifilename);
#else
	snprintf(filename, 255, "Quests/%s.qst", ifilename);
#endif
	FILE *f;
	if (!(f = fopen (filename, "rb"))) {
		return false;
	}
	int32 fs = filesize(f);
	char* buffer = new char[fs];
	fread(buffer, fs, 1, f);

	bool ret = Phraser(buffer);
	delete[] buffer;
	return ret;
}

int32 Scripts::DoTrigger(int32 iTriggerOP, int32 iNPCTypeID, Mob* causer, NPC* responder, int32 iMatchID, char* iMatchText) {
	int32 ret = 0;
	if (triggerarray) {
		for (int32 i=0; i<max_triggerarray; i++) {
			if (triggerarray[i].TriggerOP == iTriggerOP && triggerarray[i].NPCTypeID == iNPCTypeID
			&& (iMatchID == 0 || triggerarray[i].MatchID == 0 || triggerarray[i].MatchID == iMatchID)
			&& (iMatchText == 0 || triggerarray[i].MatchText == 0 || strcasecmp(triggerarray[i].MatchText, iMatchText) == 0)) {
				DoAction(actionarray[triggerarray[i].ActionID], causer, responder);
				ret++;
			}
		}
	}
	return ret;
}

int32 Scripts::AddAction(char* iActionText, int32 version) {
	sActionArray** new_actionarray = new sActionArray*[max_actionarray + 1];
	if (actionarray) {
		for (int32 i=0; i<max_actionarray; i++) {
			new_actionarray[i] = actionarray[i];
		}
		delete actionarray;
	}
	actionarray = new_actionarray;
	new_actionarray[max_actionarray] = (sActionArray*) new uchar[sizeof(sActionArray) + strlen(iActionText) + 1];
	strcpy(new_actionarray[max_actionarray]->ActionText, iActionText);
	new_actionarray[max_actionarray]->version = version;
	new_actionarray[max_actionarray]->dbID = 0;
	max_actionarray++;
	return max_actionarray - 1;
}

int32 Scripts::AddTrigger(int32 iTriggerOP, int32 iNPCTypeID, int32 iActionID, int32 iMatchID, char* iMatchText) {
	sTriggerArray* new_triggerarray = new sTriggerArray[max_triggerarray + 1];
	memset(new_triggerarray, 0, sizeof(sTriggerArray) * (max_triggerarray + 1));
	if (triggerarray) {
		memcpy(new_triggerarray, triggerarray, sizeof(sTriggerArray) * max_triggerarray);
		delete triggerarray;
	}
	triggerarray = new_triggerarray;
	new_triggerarray[max_triggerarray].TriggerOP = iTriggerOP;
	new_triggerarray[max_triggerarray].NPCTypeID = iNPCTypeID;
	new_triggerarray[max_triggerarray].ActionID = iActionID;
	new_triggerarray[max_triggerarray].MatchID = iMatchID;
	if (iMatchText && strlen(iMatchText) > 0) {
		new_triggerarray[max_triggerarray].MatchText = new char[strlen(iMatchText)+1];
		strcpy(new_triggerarray[max_triggerarray].MatchText, iMatchText);
	}
	max_triggerarray++;
	return max_triggerarray - 1;
}

void Scripts::AddTimer(int32 iDelay, int32 iActionID, int16 entityid) {
	sTriggerTimer* t = new sTriggerTimer;
	t->TriggerTime = Timer::GetCurrentTime() + iDelay;
	t->ActionID = iActionID;
	t->EntityID = entityid;
	if (NextTimer >= t->TriggerTime)
		NextTimer = t->TriggerTime;
	timer_list.Insert(t);
}

void Scripts::CheckTimers() {
	if (NextTimer > Timer::GetCurrentTime())
		return;

	LinkedListIterator<sTriggerTimer*> iterator(timer_list);
	int32 NewNextTimer = 0xFFFFFFFF;

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->TriggerTime <= Timer::GetCurrentTime()) {
			Mob* mob = entity_list.GetMob(iterator.GetData()->EntityID);
			NPC* npc = 0;
			if (mob->IsNPC())
				npc = mob->CastToNPC();
			DoAction(actionarray[iterator.GetData()->ActionID], 0, npc);
			iterator.RemoveCurrent();
		}
		else {
			if (NewNextTimer >= iterator.GetData()->TriggerTime)
				NewNextTimer = iterator.GetData()->TriggerTime;
			iterator.Advance();
		}
	}
	NextTimer = NewNextTimer;
}

void Scripts::RemoveTimerByEntityID(int16 entityid) {
	LinkedListIterator<sTriggerTimer*> iterator(timer_list);
	int32 NewNextTimer = 0xFFFFFFFF;

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->EntityID == entityid) {
			iterator.RemoveCurrent();
		}
		else {
			if (NewNextTimer >= iterator.GetData()->TriggerTime)
				NewNextTimer = iterator.GetData()->TriggerTime;
			iterator.Advance();
		}
	}
	NextTimer = NewNextTimer;
}


// Script version number checker
bool Scripts::Phraser(char* iPhraseText) {
	Seperator linesep(iPhraseText, 10, 5000, 500, false, 13);
	for (int i=0; i<linesep.argnum; i++) {
		for (int k=0; k<strlen(linesep.arg[i]); k++) {
			if (strncasecmp(&linesep.arg[i][k], "version ", 8) == 0) {
				if (linesep.IsNumber(&linesep.arg[i][k+8])) {
					if (atoi(&linesep.arg[i][k+8]) == 1) {
						return Phraser_v1(&linesep);
					}
					else if (atoi(&linesep.arg[i][k+8]) == 2) {
						return Phraser_v2(&linesep);
					}
				}
				else {
					return false;
				}
			}
		}
	}
	return false;
}

// Script phraser version 1
bool Scripts::Phraser_v1(Seperator* linesep) {
	bool	in_npc = false;
	bool	in_trigger = false;
	int32	in_npcID = 0;
	int32	startindex = 0;

	int32	triggerOP = 0;
	char	triggertext[250];
	int32	triggerint = 0;

	for (int i=0; i<linesep->argnum; i++) {
		Seperator sep(linesep->arg[i], ' ', 15, 250, true, '	', ':');
		if (sep.argnum == 0) {
		}
		else if (strcasecmp(sep.arg[0], "}") == 0) {
			if (sep.argnum != 1) {
				return false;
			}

			if (in_trigger) {
				char* command = 0;
				int32 tmpbufsize = 0, tmpstrlen = 0;
				for (int k=startindex; k<i; k++) {
					AppendAnyLenString(&command, &tmpbufsize, &tmpstrlen, "%s\n", linesep->arg[k]);
				}
				if (triggertext[0] == 0) {
					Scripts::AddTrigger(triggerOP, in_npc, Scripts::AddAction(command, 1), triggerint, 0);
				}
				else {
					Scripts::AddTrigger(triggerOP, in_npc, Scripts::AddAction(command, 1), triggerint, triggertext);
				}
				delete[] command;
				in_trigger = false;
			}
			else if (in_npc) {
				in_npcID = 0;
				startindex = 0;
				triggerOP = 0;
				triggertext[0] = 0;
				triggerint = 0;
				in_npc = false;
			}
			else {
				return false;
			}
		}
		else if ((!in_npc) && (!in_trigger)) {
			if (strcasecmp(sep.arg[0], "INCLUDE") == 0) {
				char tmp[250];
#ifdef WIN32
				snprintf(tmp, 250, "Quests\\%s.qst", sep.argplus[1]);
#else
				snprintf(tmp, 250, "Quests/%s.qst", sep.argplus[1]);
#endif
				Load(tmp);
			}
			else if (strcasecmp(sep.arg[0], "NPC_SCRIPT") == 0) {
				if (sep.IsNumber(1) && sep.argnum == 3 && strcasecmp(sep.arg[2], "{") == 0) {
					in_npcID = atoi(sep.arg[1]);
					in_npc = true;
				}
				else {
					return false;
				}
			}
			else if (strcasecmp(sep.arg[0], "TIMER_RESPONSE") == 0) {
				if (strcasecmp(sep.arg[sep.argnum - 1], "{") != 0) {
					return false;
				}
				if (strlen(sep.argplus[1]) >= 250)
					return false;
				memset(triggertext, 0, sizeof(triggertext));
				strncpy(triggertext, sep.argplus[1], strlen(sep.argplus[1]) - 2);
				triggerOP = TriggerOP_Timer;
				in_trigger = true;
				startindex = i + 1;
			}
		}

		// below are the triggers
		else if (in_npc && !in_trigger) {
			if (strcasecmp(sep.arg[0], "TRIGGER_TEXT") == 0) {
				if (strcasecmp(sep.arg[sep.argnum - 1], "{") != 0) {
					return false;
				}
				if (strlen(sep.arg[1]) >= 250)
					return false;
				memset(triggertext, 0, sizeof(triggertext));
				strncpy(triggertext, sep.arg[1], strlen(sep.arg[1]));
				triggerOP = TriggerOP_Text;
				in_trigger = true;
				startindex = i + 1;
			}
			else if (strcasecmp(sep.arg[0], "TRIGGER_ITEM") == 0) {
				if (strcasecmp(sep.arg[sep.argnum - 1], "{") != 0) {
					return false;
				}
				if (!sep.IsNumber(1))
					return false;
				triggerint = atoi(sep.arg[1]);
				triggerOP = TriggerOP_Item;
				in_trigger = true;
				startindex = i + 1;
			}
			else if (strcasecmp(sep.arg[0], "TRIGGER_DEATH") == 0) {
				if (strcasecmp(sep.arg[sep.argnum - 1], "{") != 0) {
					return false;
				}
				triggerOP = TriggerOP_Death;
				in_trigger = true;
				startindex = i + 1;
			}
			else if (strcasecmp(sep.arg[0], "TRIGGER_ARRGO") == 0) {
				if (strcasecmp(sep.arg[sep.argnum - 1], "{") != 0) {
					return false;
				}
				triggerOP = TriggerOP_Arrgo;
				in_trigger = true;
				startindex = i + 1;
			}
		}
		else if (!in_trigger) {
			return false;
		}
	}
	return true;
}

// Script phraser version 2
bool Scripts::Phraser_v2(Seperator* linesep) {
	return false;
}

void Scripts::DoAction(sActionArray* iAction, Mob* causer, NPC* responder) {
	if (iAction->version == 1)
		DoAction_v1(iAction, causer, responder);
	else if (iAction->version == 2)
		DoAction_v2(iAction, causer, responder);
	else
		cout << "Error in script: Unknown version" << endl;
}

void Scripts::DoAction_v1(sActionArray* iAction, Mob* causer, NPC* responder) {
	char* tmpAction = 0;
	strreplace(iAction->ActionText, "%CHARNAME%", causer->GetName(), 0, &tmpAction);
	strreplace(tmpAction, "%CHARRACE%", GetRaceName(causer->GetRace()), 0, &tmpAction, true);
	char tmp[5];
	snprintf(tmp, sizeof(tmp), "%d", causer->GetLevel());
	strreplace(tmpAction, "%CHARLEVEL%", tmp, 0, &tmpAction, true);
	strreplace(tmpAction, "%CHARCLASS%", GetEQClassName(causer->GetClass()), 0, &tmpAction, true);
	Seperator sep(tmpAction, 10, 100, 500, false, 13);
	KillFrontWhitespace(&sep);
	for (int i=0; i<sep.argnum; i++) {
		if (!IsCommented(sep.arg[i])) {
			Seperator sep2(sep.arg[i], ' ', 15, 500, false, '	', ':');
			if (strcasecmp(sep2.arg[0], "say") == 0) {
				if (sep2.argnum >= 2) {
					entity_list.MessageClose(0, MT_Say, true, 200, "%s says, '%s'", causer->GetName(), sep2.argplus[1]);
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "emote") == 0) {
				if (sep2.argnum >= 2) {
					entity_list.MessageClose(0, MT_Emote, true, 200, "%s %s", causer->GetName(), sep2.argplus[1]);
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "shout") == 0) {
				if (sep2.argnum >= 2) {
					entity_list.Message(0, MT_Shout, "%s shouts, '%s'", causer->GetName(), sep2.argplus[1]);
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "worldshout") == 0) {
				if (sep2.argnum >= 2) {
					worldserver.SendEmoteMessage(0, 0, MT_Shout, "%s shouts, '%s'", causer->GetName(), sep2.argplus[1]);
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "SPAWN_ITEM") == 0) {
				if (sep2.IsNumber(1)) {
					if (causer->IsClient())
						causer->CastToClient()->SummonItem(atoi(sep2.arg[1]));
					else {
						const Item_Struct* item = database.GetItem(atoi(sep2.arg[1]));
						if (item)
							causer->CastToNPC()->AddItem(item, item->common.charges);
					}
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}		
			else if (strcasecmp(sep2.arg[0], "ADD_HATELIST") == 0) {
				if (sep2.IsNumber(1)) {
					responder->AddToHateList(causer, 0, atoi(sep2.arg[1]));
				}
				else {
					responder->AddToHateList(causer);
				}
			}
			else if (strcasecmp(sep2.arg[0], "FLAG_ACCOUNT") == 0) {
				if (sep2.IsNumber(1) && causer->IsClient()) {
					if (!database.SetGMFlag(causer->CastToClient()->AccountName(), atoi(sep2.arg[1])))
						causer->Message(0, "Unable to set GM Flag.");
					else {
						causer->Message(0, "Set GM Flag on account to %d.", atoi(sep2.arg[1]));
						ServerPacket* pack = new ServerPacket(ServerOP_FlagUpdate, strlen(causer->CastToClient()->AccountName()) + 1);
						strcpy((char*) pack->pBuffer, causer->CastToClient()->AccountName());
						worldserver.SendPacket(pack);
						delete pack;
					}
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "SET_PVP") == 0) {
				if (sep2.argnum >= 2 && causer->IsClient()) {
					if (strcasecmp(sep2.arg[1], "OFF") == 0) {
						causer->CastToClient()->SetPVP(false);
					}
					if (strcasecmp(sep2.arg[1], "ON") == 0) {
						causer->CastToClient()->SetPVP(true);
					}
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "SPAWN_NPC") == 0) {
				if (sep2.argnum >= 4) {
					NPC* npc = NPC::SpawnNPC(sep2.arg[1], atof(sep.arg[2]), atof(sep.arg[3]), atof(sep.arg[4]), atof(sep.arg[5]));
					if (npc == 0) {
						if (causer)
							causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
						else
							cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
					}
				}
				else if (sep.argnum == 2 && causer != 0) {
					NPC* npc = NPC::SpawnNPC(sep2.arg[1], causer->GetX(), causer->GetY(), causer->GetZ(), causer->GetHeading());
					if (npc == 0) {
						if (causer)
							causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
						else
							cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
					}
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "SPAWN_NPC_ARRGO") == 0) {
				if (sep2.argnum >= 4) {
					NPC* npc = NPC::SpawnNPC(sep2.arg[1], atof(sep.arg[2]), atof(sep.arg[3]), atof(sep.arg[4]), atof(sep.arg[5]));
					if (npc) {
						if (causer)
							npc->AddToHateList(causer);
					}
					else {
						if (causer)
							causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
						else
							cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
					}
				}
				else if (sep.argnum == 2 && causer != 0) {
					NPC* npc = NPC::SpawnNPC(sep2.arg[1], causer->GetX(), causer->GetY(), causer->GetZ(), causer->GetHeading());
					if (npc) {
						if (causer)
							npc->AddToHateList(causer);
					}
					else {
						if (causer)
							causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
						else
							cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
					}
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "EXP") == 0) {
				if (sep2.IsNumber(1)) {
					if (causer->IsClient())
						causer->CastToClient()->AddEXP(atoi(sep2.arg[1]));
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "LEVEL") == 0) {
				if (sep2.IsNumber(1)) {
					if (causer->IsClient())
						causer->CastToClient()->SetLevel(atoi(sep2.arg[1]));
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "Weather") == 0) {
				if (sep2.argnum >= 2) {
					if (strcasecmp(sep2.arg[1], "Rain") == 0)
						zone->zone_weather = 1;
					else if (strcasecmp(sep2.arg[1], "Snow") == 0)
						zone->zone_weather = 2;
					else
						zone->zone_weather = 0;
					APPLAYER* outapp = new APPLAYER(OP_Weather, 8);
					outapp->pBuffer[0] = zone->zone_weather;
					if (sep2.IsNumber(2))
						outapp->pBuffer[4] = atoi(sep2.arg[2]);
					else
						outapp->pBuffer[4] = 1;
					entity_list.QueueClients(0, outapp);
					delete outapp;
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "CAST_SPELL") == 0) {
				if (sep2.IsNumber(1)) {
					responder->CastSpell(atoi(sep2.arg[1]), causer->GetID());
				}
				else {
					if (causer)
						causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
					else
						cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
				}
			}
			else if (strcasecmp(sep2.arg[0], "FACE_TARGET") == 0) {
				responder->FaceTarget(causer);
			}
			else if (strcasecmp(sep2.arg[0], "SPAWN_GROUP") == 0) {
				//Temporarily disabled			entity_list.Message(0, MT_Say, "%s says, '%s'", this->GetName(), sep4.arghza[1]);
			}
			else {
				if (causer)
					causer->Message(0, "Error in script: \"%s\"", sep.arg[i]);
				else
					cout << "Error in script: \"" << sep.arg[i] << "\"" << endl;
			}		
		}
	}
}

void Scripts::DoAction_v2(sActionArray* iAction, Mob* causer, NPC* responder) {
}

bool Scripts::IsCommented(char* line) {
	if (line[0] == '#')
		return true;
	int len = strlen(line);
	for (int i=0; i<len; i++) {
		if (line[i] == '#')
			return true;
		else if (!(line[i] == '	' || line[i] == ' '))
			return false;
	}
	return false;
}

void Scripts::KillFrontWhitespace(Seperator* sep) {
	for (int i=0; i<sep->argnum; i++) {
		KillFrontWhitespace(sep->arg[i]);
	}
}

char* Scripts::KillFrontWhitespace(char* line) {
	int len = strlen(line);
	int newfront = 0;
	for (int i=0; i<len; i++) {
		if (line[i] == '	' || line[i] == ' ' || line[i] == 13) {
			newfront = i + 1;
		}
		else {
			break;
		}
	}
	if (newfront)
		strcpy(line, &line[newfront]);
	return line;
}

char* strreplace(char* line, char* search, const char* replacement, int linesize, char** destination, bool deleteinput) {
	int rlen = strlen(replacement);
	int slen = strlen(search);
	int len = strlen(line) - slen;
	int lr = 0;
	char* newline = 0;
	int32 bufsize = 0, strlen = 0;

	for (int i=0; i<len; i++) {
		if (strncasecmp(&line[i], search, slen)) {
			if ((i - lr) > 0) {
				line[i] = 0;
				AppendAnyLenString(&newline, &bufsize, &strlen, "%s", &line[lr]);
				lr = i + rlen;
			}
			i += slen - 1;
			AppendAnyLenString(&newline, &bufsize, &strlen, "%s", replacement);
		}
	}
	if ((i - lr) > 0) {
		line[i] = 0;
		AppendAnyLenString(&newline, &bufsize, &strlen, "%s", &line[lr]);
		lr = i + rlen;
	}
	if (destination) {
		if (deleteinput)
			delete line;
		*destination = newline;
		return *destination;
	}
	else {
		snprintf(line, linesize, "%s", newline);
		safe_delete(newline);
		return line;
	}
}
