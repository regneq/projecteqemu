/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
solar: fixed some values, small bugs, cleaned up the code a little.

  you can miss now, won't hit every time.
  riposte, dodge, etc don't go off every time if you have < 5 skill
  
*/

#include "../common/debug.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <iostream.h>

#include "client.h"
#include "npc.h"
#include "../common/packet_dump.h"
#include "../common/eq_packet_structs.h"
#include "skills.h"
#include "PlayerCorpse.h"
#include "spdat.h"
#include "zone.h"
#include "groups.h"

#ifdef WIN32
#define snprintf	_snprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#endif

extern Database database;
extern EntityList entity_list;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern Zone* zone;

void Client::Attack(Mob* other, int Hand)
{
	if(!other) return;
	
	if((IsClient() && CastToClient()->dead) || (other->IsClient() && other->CastToClient()->dead))
		return;
	
	if(GetHP() < 0)
		return;
	
	
	if(!IsAttackAllowed(other)) return;
	
	/* Determine animation */
	
	int skillinuse = HIGHEST_SKILL+1;
	int8 attack_skill=4;
	
	APPLAYER app;
	app.opcode = OP_Attack;
	app.size = sizeof(Attack_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Attack_Struct* a = (Attack_Struct*)app.pBuffer;
	const Item_Struct* weapon = 0;
	//int i = 0;
	
	a->spawn_id = GetID();
	
	if (Hand==13)	// Kaiyodo - Pick weapon from the attacking hand
		weapon = weapon1;
	else
		weapon = weapon2;
	if(weapon)
	{
		switch(weapon->common.skill)
		{
		case 0: // 1H Slashing
			{
				attack_skill = 1;
				skillinuse = 1;
				a->type = 5;
				break;
			}
		case 1: // 2H Slashing
			{
				attack_skill = 1;
				skillinuse = 3;
				a->type = 3;
				break;
			}
		case 2: // Piercing
			{
				attack_skill = 36;
				skillinuse = 36;
				a->type = 2;
				break;
			}
		case 3: // 1H Blunt
			{
				attack_skill = 0;
				skillinuse = 0;
				a->type = 5;
				break;
			}
		case 4: // 2H Blunt
			{
				attack_skill = 0;
				skillinuse = 2;
				a->type = 4;
				break;
			}
		case 35: // 2H Piercing
			{
				attack_skill = 36;
				skillinuse = 36;
				a->type = 4;
				break;
			}
		case 45:
			{
				attack_skill = 4;
				skillinuse = 29;
				a->type = 8;
				break;
			}
		default:
			{
				attack_skill = 4;
				skillinuse = HIGHEST_SKILL+1;
				a->type = 8;
				break;
			}
		}
	}
	else
	{
		attack_skill = 4;
		skillinuse = 28;
		a->type = 8;
	}
	// Kaiyodo - If we're attacking with the seconary hand, play the duel wield anim
	if(Hand == 14)	// DW anim
		a->type = 6;
	
	a->a_unknown2[5] = 0x80;
	a->a_unknown2[6] = 0x3f;
	app.priority = 1;
	entity_list.QueueCloseClients(this, &app);
	
	/* Animation stuff done */
	
	
	/* Now figure out damage */
	int damage = 0;
	
	int8 otherlevel = other->GetLevel();
	int8 mylevel = this->GetLevel();
	
	otherlevel = otherlevel ? otherlevel : 1;
	mylevel = mylevel ? mylevel : 1;
	
	// Determine players ability to hit based on:
	// mob level difference, skillinuse, randomness
	if (skillinuse == HIGHEST_SKILL+1) /* the fallthru, only do 1 damage */
	{
		damage = 1;
	}
	else
	{
		if ( 1 )
		{
			//int32 atkbonus = 0; //TODO: Find where the luclin atk bonus is held
			//int32 attacker = ((mylevel/2) * ((this->GetDEX()/6)+this->GetSTR()+atkbonus+this->pp.skills[skillinuse]));
			//int32 defender = (otherlevel/2) * ((otherlevel * 3000/otherlevel+90) +(pp.skills[DEFENSE]/2)+other->GetINT()+other->GetAGI());
			//float hitsuccess = (attacker / defender); // Change to hit *image*
			
			float skillfactor = 1.0;
			int32 chanceskill = (int32)(255*skillfactor) - ((pp.skills[skillinuse]/10) * (1+(mylevel-otherlevel)));
			int chanceskill2 = chanceskill;
			int chancetest = (int32)chanceskill2+rand()%(750-chanceskill2)-50;
			if(chancetest <= chanceskill2)
			{
				if(pp.skills[skillinuse] < 252)
				{
					SetSkill(skillinuse, pp.skills[skillinuse] + 1);
				}
			}
			//int rndqa = 0;
			//int defender2 = 0;
			//Something got bugged, taking out chance code for now...
			// Kaiyodo - new weapon damage calc code
			//
			//  MaximumDamageMain = WeaponDamage * ((Strength + WeaponSkill) / 100) + DamageBonus
			//  MaximumDamageOff = WeaponDamage * ((Strength + WeaponSkill) / 100)
			
			int weapon_damage = 0;
			
			if(skillinuse == 28) // weapon is hand-to-hand
			{
				if(GetClass() == MONK || GetClass() == BEASTLORD)
					weapon_damage = GetMonkHandToHandDamage();	// Damage changes based on level
				else
					weapon_damage = 2;
			}
			else
			{
				weapon_damage = (int)weapon->common.damage;
				if(weapon_damage < 1)
					weapon_damage = 1;
			}
			
			int min_hit = 1;
			int max_hit = weapon_damage * ((GetSTR() + pp.skills[skillinuse]) / 100);	// Apply damage formula
			
			// Only apply the damage bonus to the main hand
			if(Hand == 13)		// Kaiyodo - If we're not using the DWDA stuff, will always be the primary hand
			{
				int damage_bonus = GetWeaponDamageBonus(weapon);	// Can be NULL, will then assume fists
				min_hit += damage_bonus;
				max_hit += damage_bonus;
			}
			
			if(max_hit == min_hit)
				damage = min_hit;
			else
				damage = (int32)min_hit + (rand()%(max_hit-min_hit)+1);
			
		}
	}
	
	uint8 *aa_item = &(((uint8 *)&aa)[30]);
	int amount1 = *aa_item;
	if (GetClass() == WARRIOR)
	{
		int amount = *aa_item;
		amount = (amount*5)+5;
		int Critchance = GetDEX()-amount;
		int Critical = rand()%Critchance;
		int FinalChance = Critchance-amount;
		if (Critical > FinalChance)
		{
			int RAND_CRIT = rand()%5;
			if (this->berserk)
				RAND_CRIT = rand()%10;
			damage += (((GetLevel() / 4) + (weapon ? weapon->common.damage : 0)) * RAND_CRIT);
			if (this->berserk)
				entity_list.MessageClose(this, false, 200, 10, "%s lands a crippling blow!(%d)", name,damage);
			else
				entity_list.MessageClose(this, false, 200, 10, "%s scores a critical hit!(%d)", name,damage);
		}
	}
	else
	{
		if (amount1 != 0)
		{
			int amount = amount1*5;
			int Critchance = GetDEX()-amount;
			int Critical = rand()%Critchance;
			int FinalChance = Critchance-amount;
			if (Critical > FinalChance)
			{
				int RAND_CRIT = rand()%5;
				damage += (((GetLevel() / 4) + (weapon ? weapon->common.damage : 0)) * RAND_CRIT);
				entity_list.MessageClose(this, false, 200, 10, "%s scores a critical hit!(%d)", name,damage);
			}
		}
	}
	
	
	// chance to hit
	float chancetohit = GetSkill(skillinuse) / 3.75;
	if (mylevel-other->GetLevel() < 0)
	{
		// based on leveldiff
		chancetohit -= (float)((other->GetLevel()-mylevel)*(other->GetLevel()-mylevel))/4;
	}
	
	int16 targetagi = other->GetAGI();
	targetagi = (targetagi <= 200) ? targetagi:targetagi + ((targetagi-200)/5);
	
	chancetohit -= (float)targetagi*0.05;
	chancetohit += (float)(this->itembonuses->DEX + this->spellbonuses->DEX)/5;
	chancetohit = (chancetohit > 0) ? chancetohit+30:30;
	chancetohit = chancetohit > 95 ? 95 : chancetohit; /* cap to 95% */
	
	//  char temp[100];
	//  snprintf(temp, 100, "Chance to hit %s: %f", other->GetName(), chancetohit);
	//  ChannelMessageSend(0,0,7,0,temp);
	
	if (((float)rand()/RAND_MAX)*100 > chancetohit)
		damage = 0;
	damage = damage >= 0 ? damage : 0;
	aa_item = &(((uint8 *)&aa)[32]);
	if(damage > 0 && *aa_item>0 && ((((float)other->GetHP())/((float)other->GetMaxHP())) <=.10))
	{
		int tempchancerand =rand()%100;
		if(*aa_item==1 && (tempchancerand<=3))
		{	  other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");}
		else if(*aa_item==2 && (tempchancerand<=6))
		{	  other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");}
		else if(*aa_item==3 && (tempchancerand<=10))
		{	  other->Damage(this,32000,0xffff,attack_skill); Message(0,"You inflict a finishing blow!");}
		else
		{//Message(0,"Wtf? You can\'t have more than 3 points in finishing blow");}
		}
	}
	other->Damage(this, damage, 0xffff, attack_skill);
	
	
	
	// Kaiyodo - Check for proc on weapon based on DEX
	if(weapon && (weapon->common.spellId < 65535ul) && (weapon->common.effecttype == 0) && other && other->GetHP() > 0)
	{
		float ProcChance = (float)rand()/RAND_MAX;
		if(ProcChance < (GetDEX()/3020.0f))	// 255 dex = 0.084 chance of proc. No idea what this number should be really.
		{
			if(weapon->common.level > GetLevel())
			{
				Message(13, "Your will is not sufficient to command this weapon.");
			}
			else
			{
				switch(weapon->common.spellId)
				{
				case 2434:
					SpellFinished(weapon->common.spellId, GetID(), 10, 0);
					break;
				case 1775:
					SpellFinished(weapon->common.spellId, GetID(), 10, 0);
					break;
					
				default:
					SpellFinished(weapon->common.spellId, other->GetID(), 10, 0);
					
				}
				// Check who to cast the effect on. At the moment, I only know avatar is on us.
				if(weapon->common.spellId == 2434)	// Avatar
					SpellFinished(weapon->common.spellId, GetID(), 10, 0);
				else
					SpellFinished(weapon->common.spellId, other->GetID(), 10, 0);
			}
		}
	}
	
	if(other->IsNPC() && other->CastToNPC()->GetHPRatio() <= 7 && other->CastToNPC()->SpecialNPCAttacks[2] == 1)
	{
		//other->CastToNPC()->FaceTarget(); //Causes too much lag?? Disabled. -image
		other->Attack(this);
	}
}

void Client::Heal()
{
	if(dead)
		return;
	
	SetMaxHP();
	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;
	
	a->target = GetID();
	a->source = GetID();
	a->type = 231; // 1
	a->spell = 0x000d; //spell_id
	a->damage = -10000;
	
	entity_list.QueueCloseClients(this, &app);
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 1;
	entity_list.QueueCloseClients(this, &hp_app, true);
	SendHPUpdate();
	
	cout << name << " healed via #heal" << endl; // Pyro: Why say damage?
}

void Client::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill)
{
	adverrorinfo = 411;
	
	//  damage avoidance - as soon as one of them kicks in, the others aren't
	//  checked, that's why riposte is checked first since it's better.
	
	bool avoidable=1;
	if(spell_id) avoidable=0;
	
	if(avoidable)
	{
		/* riposte */
		if (damage > 0 && GetSkill(RIPOSTE) && (
			class_==WARRIOR ||
			class_==ROGUE ||
			class_==MONK ||
			class_==BARD ||		/* at 59 or 60? not sure though */
			class_==BEASTLORD ||
			class_==RANGER ||
			class_==PALADIN ||
			class_==SHADOWKNIGHT))
		{
			if(((float)rand()/RAND_MAX) < GetSkill(RIPOSTE)/1500.0)
			{
				damage = -3;
			}
		}
		
		/* block */
		if (damage > 0 && GetSkill(BLOCK) && (
			class_==MONK ||
			class_==BEASTLORD))
		{
			if(((float)rand()/RAND_MAX) < GetSkill(BLOCK)/1500.0)
			{
				damage = -1;
			}
		}
		
		/* parry */
		if (damage > 0 && GetSkill(PARRY) && (
			class_==WARRIOR ||
			class_==ROGUE ||
			class_==MONK ||		/* can monks parry? i *think* they can... */
			class_==BEASTLORD ||	/* not sure */
			class_==BARD ||		/* i think they can at 58 or something... */
			class_==PALADIN ||
			class_==RANGER ||
			class_==SHADOWKNIGHT))
		{
			if(((float)rand()/RAND_MAX) < GetSkill(PARRY)/1500.0)
			{
				damage = -2;
			}
		}
		
		/* dodge */
		if (damage > 0 && GetSkill(DODGE))
		{
			if(((float)rand()/RAND_MAX) < GetSkill(DODGE)/1500.0)
			{
				damage = -4;
			}
		}
	}
	
	if (invulnerable) damage=-5;
	
	if (other && damage > 0 && (attack_skill != 245 && attack_skill != 231 && attack_skill != 247 && attack_skill != 248 && attack_skill != 249))
	{
		this->DamageShield(other);
	}
	else 
	{
		if (attack_skill == 0xFF)
		{
			if (spell_id != 0xFFFF && spell_id != 0)
			{
				if (spells[spell_id].targettype == ST_Tap && other)
				{
					other->SetHP(GetHP() + damage);
				}
			}
		}
	}
	
	if ((GetHP() - damage) <= 0)
	{
		Death(other, damage, spell_id, attack_skill);
		return;
	}
	
	if (damage > 0)
		SetHP(GetHP()-damage);
	
	APPLAYER app;
	app.opcode = OP_Action;
	app.size = sizeof(Action_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Action_Struct* a = (Action_Struct*)app.pBuffer;
	adverrorinfo = 412;
	a->target = GetID();
	
	if (other == 0)
		a->source = 0;
	else
		if (other->IsClient() && other->CastToClient()->GMHideMe())
			a->source = 0;
		else
			a->source = other->GetID();
		
		a->type = attack_skill;
		a->spell = spell_id;
		a->damage = damage;
		app.priority = 4;
		entity_list.QueueCloseClients(this, &app);
		adverrorinfo = 413;
		APPLAYER hp_app;
		CreateHPPacket(&hp_app);
		hp_app.priority = 1;
		entity_list.QueueCloseClients(this, &hp_app);
		
		if (damage != 0)
		{ // Pyro: Why log this message if no damage is inflicted
			if (IsMezzed())
				this->BuffFadeByEffect(SE_Mez);
			if (damage == -3) /* riposting */
			{
				Attack(target, 13);	// Kaiyodo - added attacking hand to arguments
				// Kaiyodo - support for double attack. Chance based on formula from Monkly business
				if(CanThisClassDoubleAttack())
				{
					float DoubleAttackProbability = (GetSkill(DOUBLE_ATTACK) + GetLevel()) / 500.0f; // 62.4 max
					// Check for double attack with main hand assuming maxed DA Skill (MS)
					float random = (float)rand()/RAND_MAX;
					if(random < DoubleAttackProbability)		// Max 62.4 % chance of DA
						if(target && target->GetHP() > 0)
							Attack(target, 13);
				}
			}
			if(this->casting_spell_id != 0)
			{
				// client: 30 = basechance
				int16 channelchance = (int16)(30+((float)this->GetSkill(CHANNELING)/400)*100);
				if (((float)rand()/RAND_MAX)*100 > channelchance)
				{
					this->isattacked = true;
					this->isinterrupted = true;
				}
				else
				{
					this->isattacked = true;
				}
			}
			
			//    cout << name << " hit for " << damage << ", " << GetHP() << " left." << endl; // More intuitive console output
			adverrorinfo = 41;
		}
		
		Mob* mypet = this->GetPet();
		if (mypet && mypet->IsNPC() && other)
		{
			if (!mypet->CastToNPC()->IsEngaged())
				zone->AddAggroMob(); //merkur
			mypet->CastToNPC()->AddToHateList(other, 0, damage);
		}
}

void Client::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	SetHP(-100);
	entity_list.RemoveFromTargets(this);
	zonesummon_x = -3;
	zonesummon_y = -3;
	zonesummon_z = -3;
	
	SetPet(0);
	
	pp.x = x_pos;
	pp.y = y_pos;
	pp.z = z_pos;
	pp.heading = heading;
	
	for(int i=0;i<15;i++)
	{
		memset(&pp.buffs[i],0,sizeof(SpellBuff_Struct));
	}
	Save();
	
	if(other->IsClient() && other->CastToClient()->IsDueling() && other->CastToClient()->GetDuelTarget() == GetID())
	{
		other->CastToClient()->SetDueling(false);
		other->CastToClient()->SetDuelTarget(0);
	}
	
	
	cout << "Player " << name << " has died." << endl;
	APPLAYER app;
	app.opcode = OP_Death;
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	//  d->unknown011 = 0x05;
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->damage = damage;
	d->spell_id = spell;
	d->type = attack_skill;
	d->unknownds016 = pp.bind_point_zone;
	int32 exploss = (int32)(GetLevel()*((float)GetLevel()/18)*8000);
	if (GetLevel() > 9 &&  pp.gm != 1 && GetEXP() >= 0)
		SetEXP(((sint32)GetEXP() - GetLevel()*((float)GetLevel()/18)*8000 > 0)? (uint32)GetEXP() - GetLevel()*((float)GetLevel()/18)*8000 : 1,GetAAXP());
	entity_list.QueueClients(this, &app);
	
	if(IsBecomeNPC() == true)
	{
		if (other && other->IsClient())
		{
			if (other->CastToClient()->isgrouped && entity_list.GetGroupByMob(other) != 0)
				entity_list.GetGroupByMob(other->CastToClient())->SplitExp(level*level*75*3.5f);
			else
				other->CastToClient()->AddEXP(level*level*75*3.5f); // Pyro: Comment this if NPC death crashes zone
			//hate_list.DoFactionHits(npctype_id);
		}
	}
	
	MakeCorpse(exploss);
}

void Client::MakeCorpse(int32 exploss)
{
	if (this->GetID() == 0)
		return;
	
	if (pp.gm != 1 && pp.level > 9)
	{
		// Check to see if we are suppose to make a corpse
		// Via the database setting (anything in leavecorpses)
		char tmp[20];
		memset(tmp,0,sizeof(tmp));
		database.GetVariable("leavecorpses",tmp, 20);
		if (!strcmp(tmp,"1"))
		{
			entity_list.AddCorpse(new Corpse(this, &pp,exploss), this->GetID());
			this->SetID(0);
		}
	}
}

void NPC::Attack(Mob* other, int Hand)	 // Kaiyodo - base function has changed prototype, need to update overloaded version
{
	if((other->GetHP() <= -11) || (other->IsClient() && other->CastToClient()->dead))
	{
		RemoveFromHateList(other);
		return;
	}
	
	if (!IsAttackAllowed(other))
	{
		char temp[200];
		snprintf(temp, 200, "%s says, 'That is not a legal target master.'", this->GetName());
		entity_list.MessageClose(this, 1, 200, 10, temp);
		this->WhipeHateList();
		return;
	}
	else
	{
		int disttest = (int)(this->GetSize() * 2);
		if(disttest <= 9)
		{
			disttest = 10;
		}
		if(this->GetRace() == 49)
		{
			disttest = 85;
		}
		if (DistNoRootNoZ(other) > disttest * 40 || this->casting_spell_id != 0)
		{
			return;
		}
		
		int skillinuse;
		int8 attack_skill;
		APPLAYER app;
		app.opcode = OP_Attack;
		app.size = sizeof(Attack_Struct);
		app.pBuffer = new uchar[app.size];
		memset(app.pBuffer, 0, app.size);
		Attack_Struct* a = (Attack_Struct*)app.pBuffer;
		
		a->spawn_id = GetID();
		// lets determine the animation type based on whats in the primary slot.
		// TODO: since the NPC's primary slot is just a graphic, we will need to
		// set the weapons properties and ensure correct graphic is displayed.
		
		// I only implemented weapons 0-8 for now (4=bow, 6=flute)
		if ((int)GetEquipment(7) != 0)
		{
			// 1h Slashing weapons
			if ((int)GetEquipment(7) == 1 || (int)GetEquipment(7) == 3)
			{
				attack_skill = 0x01;
				skillinuse = 0;
				a->type = 5;
			}
			// 2h Slashing weapons
			else if ((int)GetEquipment(7) == 2)
			{
				attack_skill = 0x01;
				skillinuse = 1;
				a->type = 3;
			}
			// Piercing
			else if ((int)GetEquipment(7) == 5)
			{
				attack_skill = 0x24;
				skillinuse = 2;
				a->type = 2;
			}
			// 1h Blunt
			else if ((int)GetEquipment(7) == 7)
			{
				attack_skill = 0x00;
				skillinuse = 3;
				a->type = 5;
			}
			// 2h Blunt
			else if ((int)GetEquipment(7) == 8)
			{
				attack_skill = 0x00;
				skillinuse = 4;
				a->type = 4;
			}
			else
			{
				attack_skill = 0x04;
				skillinuse = HIGHEST_SKILL+1;
				a->type = 8;
			}
		}
		else
		{
			// NPC does not have anything in primary
			// use hand to hand
			attack_skill = 0x04;
			skillinuse = 28;
			a->type = 8;
		}
		// end animation determination
		
		a->a_unknown2[5] = 0x80;
		a->a_unknown2[6] = 0x3f;
		app.priority = 1;
		entity_list.QueueCloseClients(this, &app);
		
		int damage = 0;
		
		int8 otherlevel = other->GetLevel();
		if (otherlevel == 0)
			otherlevel = 1;
		
		int8 mylevel = this->GetLevel();
		if (mylevel == 0)
			mylevel = 1;
		
		float dmgbonusmod = 0;
		int8  atks = 1;
		float clmod = (float)GetClassLevelFactor()/22;
		float basedamage = mylevel*3.1f*clmod;
		dmgbonusmod += (float)(this->itembonuses->STR + this->spellbonuses->STR)/3;
		dmgbonusmod += (float)(this->spellbonuses->ATK + this->itembonuses->ATK)/5;
		basedamage += (float)basedamage/100*dmgbonusmod;
		float basedefend = (float) 1.118f * sqrt(other->GetAC());
		if (mylevel > 54 && CanThisClassDoubleAttack())
		{
			float DoubleAttackProbability = (250 + mylevel) / 500.0f; // 62.4 max
			float random = (float)rand()/RAND_MAX;
			if(random < DoubleAttackProbability)
				atks *= 2;
		}
		if (GetEquipment(7) && GetEquipment(8) && GetEquipment(7) && CanThisClassDuelWield ())
			atks *= 2;
		
		if (this->ownerid != 0)
		{
			if ((float)rand()/RAND_MAX < 0.2)
			{
				if (this->typeofpet == 1)
				{
					printf("Trying to cast1\n");
					this->SpellFinished(893, this->target->GetID(), 10, 0);
				}
				if (this->typeofpet == 2)
				{
					printf("Trying to cast2\n");
					this->SpellFinished(1021, this->target->GetID(), 10, 0);
				}
				if (this->typeofpet == 3)
				{
					printf("Trying to cast3\n");
					this->SpellFinished(1021, this->target->GetID(), 10, 0);
				}
				if (this->typeofpet == 4)
				{
					printf("Trying to cast4\n");
					this->SpellFinished(1021, this->target->GetID(), 10, 0);
				}
			}
		}
		/*
		else if (rand()%100 < 10)
		{
		int16 SpellId = FindSpell(this->class_, this->level, SE_CurrentHP, 1);
		if (SpellId != 0)
		{
        this->CastSpell(SpellId,target->GetID());
		}
		}
		*/
		float currenthit;
		/*cout << "Basedamage: " << basedamage<< endl;
		cout << "BaseDefend: " << basedefend << endl;
		cout << "Bonus:		 " << (int16)dmgbonusmod << endl;
		cout << "mod:		 " << clmod << endl;*/
		for (int ix = 0;ix != atks;ix++)
		{
			if(min_dmg != 0 && max_dmg != 0 && min_dmg <= max_dmg)
			{
				if (max_dmg == min_dmg)
					currenthit = damage = min_dmg;
				else
					currenthit = min_dmg + (float)rand()/RAND_MAX*(max_dmg-min_dmg);
			}
			else
				currenthit = (float)basedamage-basedamage/100*25 + (float)rand()/RAND_MAX * basedamage/100*50;
			damage = (int)(currenthit - (float)basedamage/100*basedefend);
			// chance to hit
			float chancetohit = 0;
			if (mylevel-other->GetLevel() >= 0)
			{
				// 83% (+30) baschance, if target if lower then me
				chancetohit = 68;
			}
			else
			{
				// based on leveldiff
				chancetohit = 68-(float)((other->GetLevel()-mylevel)*(other->GetLevel()-mylevel))/4;
			}
			int16 targetagi = other->GetAGI();
			targetagi = (targetagi <= 200) ? targetagi:targetagi + ((targetagi-200)/5);
			chancetohit -= (float)targetagi*0.05;
			chancetohit += (float)(this->itembonuses->DEX + this->spellbonuses->DEX)/5;
			chancetohit = (chancetohit > 0) ? chancetohit+30:30;
			//cout << "Chance: " << chancetohit << endl;
			if (((float)rand()/RAND_MAX)*100 > chancetohit)
				damage = 0;
			if (damage < 0)
				damage = 0;
			other->Damage(this, damage, 0xffff, attack_skill);
		}
  }
}

void NPC::Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill)
{
	if (this->GetHPRatio() <= 25)
	{
		int16 SpellId = FindSpell(this->class_, this->level, SE_CurrentHP, 2);
		if (SpellId != 0)
		{
			this->CastSpell(SpellId,this->GetID());
		}
	}
	
	if (other && damage > 0 && (attack_skill != 245 && attack_skill != 231 && attack_skill != 247 && attack_skill != 248 && attack_skill != 249))
	{
		this->DamageShield(other);
	}
	
	if (attack_skill>200 && attack_skill<250)
		if (other->IsClient())
			other->CastToClient()->Message(4,"%s was hit by non-melee for %d points of damage.", this->GetName(), damage);
		
		// if spell is lifetap add hp to the caster
		if (other && IsLifetapSpell( spell_id ))
		{
			int32 healedhp;
			
			// check if healing would be greater than max hp
			// use temp var to store actual healing value
			if ( other->GetHP() + damage > other->GetMaxHP())
			{
				healedhp = other->GetMaxHP() - other->GetHP();
				other->SetHP(other->GetMaxHP());
			}
			else
			{
				healedhp = damage;
				other->SetHP(other->GetHP() + damage);
			}
			
			// not sure if i need to send this or not. didnt hurt yet though ;-)
			APPLAYER hp_app;
			other->CreateHPPacket(&hp_app);
			
			// if client was casting the spell there need to be some messages
			if (other->IsClient())
			{
				other->CastToClient()->Message(4,"You have been healed for %d points of damage.", healedhp);
				other->CastToClient()->QueuePacket(&hp_app);
			}
			
			// emote goes with every one ... even npcs
			entity_list.MessageClose(this, true, 300, MT_Emote, "%s beams a smile at %s", other->GetName(), this->GetName() );
			entity_list.QueueCloseClients(this, &hp_app, false, 600, other);
		}
		
		if (damage >= GetHP())
		{
			SetHP(-100);
			Death(other, damage, spell_id, attack_skill);
			return;
		}
		
		SetHP(GetHP() - damage);
		
		APPLAYER app;
		app.opcode = OP_Action;
		app.size = sizeof(Action_Struct);
		app.pBuffer = new uchar[app.size];
		memset(app.pBuffer, 0, app.size);
		Action_Struct* a = (Action_Struct*)app.pBuffer;
		
		a->target = GetID();
		if (other == 0)
			a->source = 0;
		else 
			if (other->IsClient() && other->CastToClient()->GMHideMe())
				a->source = 0;
			else
				a->source = other->GetID();
			a->type = attack_skill; // was 0x1c
			a->spell = spell_id;
			a->damage = damage;
			
			a->unknown4[0] = 0xcd;
			a->unknown4[1] = 0xcc;
			a->unknown4[2] = 0xcc;
			a->unknown4[3] = 0x3d;
			a->unknown4[4] = 0x71;
			a->unknown4[5] = 0x6b;
			a->unknown4[6] = 0x3d;
			a->unknown4[7] = 0x41;
			
			app.priority = 5;
			
			entity_list.QueueCloseClients(this, &app);
			
			APPLAYER hp_app;
			CreateHPPacket(&hp_app);
			hp_app.priority = 1;
			entity_list.QueueCloseClients(this, &hp_app);
			if (!IsEngaged()) zone->AddAggroMob();
			this->AddToHateList(other, damage);
			
			if (damage > 0)
			{
				if (IsMezzed())
				{
					this->BuffFadeByEffect(SE_Mez);
				}
				if (rooted)
				{
					if ((float)rand()/RAND_MAX > 0.8f)
						this->BuffFadeByEffect(SE_Root);
				}
				if(this->casting_spell_id != 0)
				{
					// 40 = basechance
					int16 channelchance = (int16)(40+((float)this->GetSkill(CHANNELING)/300)*100);
					if (((float)rand()/RAND_MAX)*100 > channelchance)
					{
						this->isattacked = true;
						this->isinterrupted = true;
					}
					else
						this->isattacked = true;
				}
			}
}

void NPC::Death(Mob* other, sint32 damage, int16 spell, int8 attack_skill)
{
	if (other && other->IsClient())
		other->CastToClient()->CheckQuests(zone->GetShortName(), "%%DEATH%%", this->GetNPCTypeID());
	if (this->IsEngaged())
	{
		zone->DelAggroMob();
		//    cout << "Mobs currently Aggro: " << zone->MobsAggroCount() << endl;
	}
	SetHP(0);
	SetPet(0);
	
	entity_list.RemoveFromTargets(this);
	
	APPLAYER app;
	app.opcode = OP_Death;
	
	app.size = sizeof(Death_Struct);
	app.pBuffer = new uchar[app.size];
	memset(app.pBuffer, 0, app.size);
	Death_Struct* d = (Death_Struct*)app.pBuffer;
	d->corpseid = GetID();
	d->spawn_id = GetID();
	if (other == 0)
		d->killer_id = 0;
	else
		d->killer_id = other->GetID();
	d->spell_id = spell;
	d->type = attack_skill;
	d->damage = damage;
	entity_list.QueueCloseClients(this, &app, false, 600, other);
	if (other)
	{
		if (other->IsClient())
			other->CastToClient()->QueuePacket(&app);
		hate_list.Add(other, damage);
	}
	
	if (hate_list.GetTop() && hate_list.GetTop()->IsClient() && other && other->IsClient())
	{
		if (hate_list.GetTop()->CastToClient()->isgrouped && entity_list.GetGroupByClient(hate_list.GetTop()->CastToClient()) != 0)
			entity_list.GetGroupByClient(hate_list.GetTop()->CastToClient())->SplitExp(level*level*75*3.5f);
		else
			hate_list.GetTop()->CastToClient()->AddEXP(level*level*75*3.5f); // Pyro: Comment this if NPC death crashes zone
		hate_list.DoFactionHits(npctype_id);
	}
	
	if (respawn2 != 0)
	{
		respawn2->Reset();
	}
	
	if (class_ != 32 && this->ownerid == 0)
	{
		entity_list.AddCorpse(new Corpse(this, &itemlist, GetNPCTypeID(), &NPCTypedata), this->GetID());
		this->SetID(0);
	}
	this->WhipeHateList();
	p_depop = true;
}

void Mob::ChangeHP(Mob* other, sint32 amount, int16 spell_id)
{
	if (IsCorpse())
		return;
	
	if (spell_id == 982)		/* Cazic Touch */
	{
		SetHP(-100);
		this->Death(other, abs(amount), spell_id, 231);
		return;
	}
	else if (spell_id == 13)	/* Complete Healing */
	{
		SetHP(GetMaxHP());
	}
	else if (!invulnerable)
	{
		if (amount < 0)
		{
			this->Damage(other, abs(amount), spell_id, 231);
			return;
		}
		else
			SetHP(GetHP() + amount);
	}
	
	APPLAYER hp_app;
	CreateHPPacket(&hp_app);
	hp_app.priority = 2;
	entity_list.QueueCloseClients(this, &hp_app, false, 600, other);
	if (other != 0 && other->IsClient())
		other->CastToClient()->QueuePacket(&hp_app);
}

void Mob::MonkSpecialAttack(Mob* other, int8 type)
{
	sint32 ndamage = 0;
	PlayerProfile_Struct pp;
	float hitsuccess = (float)other->GetLevel() - (float)level;
	float hitmodifier = 0.0;
	float skillmodifier = 0.0;
	if(level > other->GetLevel())
	{
		hitsuccess += 2;
		hitsuccess *= 14;
	}
	if ((int)hitsuccess >= 40)
	{
		hitsuccess *= 3.0;
		hitmodifier = 1.1;
	}
	if ((int)hitsuccess >= 10 && hitsuccess <= 39)
	{
		hitsuccess /= 4.0;
		hitmodifier = 0.25;
	}
	else if ((int)hitsuccess < 10 && (int)hitsuccess > -1)
	{
		hitsuccess = 0.5;
		hitmodifier = 1.5;
	}
	else if ((int)hitsuccess <= -1)
	{
		hitsuccess = 0.1;
		hitmodifier = 1.8;
	}
	// cout << "2 - " << hitsuccess << endl;
	if ((int)pp.skills[type] >= 100)
	{
		skillmodifier = 1;
	}
	else if ((int)pp.skills[type] >= 200)
	{
		skillmodifier = 2;
	}
	
	hitsuccess -= ((float)pp.skills[type]/10000) + skillmodifier;
	// cout << "3 - " << hitsuccess << endl;
	hitsuccess += (float)rand()/RAND_MAX;
	// cout << "4 - " << hitsuccess << endl;
	float ackwardtest = 2.4;
	float random = (float)rand()/RAND_MAX;
	if(random <= 0.2)
	{
		ackwardtest = 4.5;
	}
	if(random > 85 && random < 400.0)
	{
		ackwardtest = 3.2;
	}
	if(random > 400 && random < 800.0)
	{
		ackwardtest = 3.7;
	}
	if(random > 900 && random < 1400.0)
	{
		ackwardtest = 1.9;
	}
	if(random > 1400 && random < 14000.0)
	{
		ackwardtest = 2.3;
	}
	if(random > 14000 && random < 24000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 24000 && random < 34000.0)
	{
		ackwardtest = 1.3;
	}
	if(random > 990000)
	{
		ackwardtest = 1.2;
	}
	if(random < 0.2)
	{
		ackwardtest = 0.8;
	}
	
	ackwardtest += (float)rand()/RAND_MAX;
	ackwardtest = abs((long)ackwardtest);
	if (type == 0x1A) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (FLYING_KICK + GetSTR() + level) / 700);
		if ((float)rand()/RAND_MAX < 0.2) {
			ndamage = (sint32) (ndamage * 4.2);
			if(ndamage <= 0) {
				entity_list.MessageClose(this, false, 200, 10, "%s misses at an attempt to thunderous kick %s!",name,other->name);
			}
			else {
				entity_list.MessageClose(this, false, 200, 10, "%s lands a thunderous kick!(%d)", name, ndamage);
			}
		}
		other->Damage(this, ndamage, 0xffff, 0x1A);
		DoAnim(45);
	}
	else if (type == 0x34) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (2 * ackwardtest) * (TIGER_CLAW + GetSTR() + level) / 900);
		other->Damage(this, ndamage, 0xffff, 0x34);
		DoAnim(46);
	}
	else if (type == 0x26) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (ROUND_KICK + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x26);
		DoAnim(11);
	}
	else if (type == 0x17) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (4 * ackwardtest) * (EAGLE_STRIKE + GetSTR() + level) / 1000);
		other->Damage(this, ndamage, 0xffff, 0x17);
		DoAnim(47);
	}
	else if (type == 0x15) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (5 * ackwardtest) * (DRAGON_PUNCH + GetSTR() + level) / 800);
		other->Damage(this, ndamage, 0xffff, 0x15);
		DoAnim(7);
	}
	else if (type == 0x1E) {
		ndamage = (sint32) (((level/10) + hitmodifier) * (3 * ackwardtest) * (KICK + GetSTR() + level) / 1200);
		other->Damage(this, ndamage, 0xffff, 0x1e);
		DoAnim(1);
	}
}

void NPC::AddToHateList(Mob* other, sint32 damage, sint32 hate) {
	if (other) {
		if ((unsigned int)hate == 0xFFFFFFFF) {
			Mob* owner = other->GetOwner();
			if (owner) {
				hate_list.Add(other, 0, damage);
				hate_list.Add(owner, damage, damage / 2);
			}
			else {
				hate_list.Add(other, damage);
			}
			Mob* mypet = this->GetPet();
			if (mypet && mypet->IsNPC())
				mypet->CastToNPC()->AddToHateList(other, 0, damage);
		}
		else {
			hate_list.Add(other, damage, hate);
		}
	}
}

void Mob::DamageShield(Mob* other)
{
	for (int i=0; i < 15; i++)
	{
		if (buffs[i].spellid != 0xFFFF)
		{
			for (int z=0; z < 12; z++)
			{
				switch(spells[buffs[i].spellid].effectid[z])
				{
				case SE_DamageShield:
					//entity_list.MessageClose(other, 0, 200, 10, "%s takes %d damage from %s's damage shield (%s)", other->GetName(), -spells[buffs[i].spellid].base[1], this->GetName(), spells[buffs[i].spellid].name);
					//this->ChangeHP(other, spells[buffs[i].spellid].base[i], buffs[i].spellid);
					break;
				}
			}
		}
	}
}

int Mob::GetWeaponDamageBonus(const Item_Struct *Weapon)
{
	// Kaiyodo - Calculate the damage bonus for a weapon on the main hand
	if(GetLevel() < 28)
		return(0);
	
	// Check we're on of the classes that gets a damage bonus
	switch(GetClass())
	{
    case WARRIOR:
    case MONK:
    case ROGUE:
    case PALADIN:
    case SHADOWKNIGHT:
    case BEASTLORD:
    case BARD:
		break;
    default:
		return(0);
	}
	
	int BasicBonus = ((GetLevel() - 25) / 3) + 1;
	
	// If we have no weapon, or only a single handed weapon, just return the default
	// damage bonus of (Level - 25) / 3
	if(!Weapon || Weapon->common.skill == 0 || Weapon->common.skill == 2 ||
		Weapon->common.skill == 3)
		return(BasicBonus);
	
	// Things get more complicated with 2 handers, the bonus is based on the delay of
	// the weapon as well as a number stored inside the weapon.
	int WeaponBonus = 0;	// How do you find this out?
	
	// Data for this, again, from www.monkly-business.com
	if(Weapon->common.delay <= 27)
		return(WeaponBonus + BasicBonus + 1);
	if(Weapon->common.delay <= 39)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4));
	if(Weapon->common.delay <= 42)
		return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + 1);
	// Weapon must be > 42 delay
	return(WeaponBonus + BasicBonus + ((GetLevel()-27) / 4) + ((Weapon->common.delay-34) / 3));
}

int Mob::GetMonkHandToHandDamage(void)
{
	// Kaiyodo - Determine a monk's fist damage. Table data from www.monkly-business.com
	
	//	for(int i=0 ; i < 30 ; i++)
	//		Message(0, "pp.inventory %d = %d", i, pp.inventory[i]);
	
	// Have a look to see if we have epic fists on
	if (IsClient() && CastToClient()->pp.inventory[12] == 10652)
		return(9);
	else
	{
		// Work out the damage from the player's level
		int Level = GetLevel();
		
		if(Level <= 4)
			return(4);
		if(Level <= 9)
			return(5);
		if(Level <= 14)
			return(6);
		if(Level <= 19)
			return(7);
		if(Level <= 24)
			return(8);
		if(Level <= 29)
			return(9);
		if(Level <= 34)
			return(10);
		if(Level <= 39)
			return(11);
		if(Level <= 44)
			return(12);
		if(Level <= 49)
			return(13);
		if(Level <= 75)
			return(14);
		if(Level <= 80)
			return(15);
		if(Level <= 85)
			return(15);
		if(Level <= 90)
			return(16);
		if(Level <= 95)
			return(16);
		if(Level <= 100)
			return(17);
		return(17);
	}
}

int Mob::GetMonkHandToHandDelay(void)
{
	// Kaiyodo - Determine a monk's fist delay. Table data from www.monkly-business.com
	
	// Have a look to see if we have epic fists on
	if (IsClient() && CastToClient()->pp.inventory[12] == 10652)
		return(16);
	else
	{
		// Work out the delay from the player's level.
		// This should change if you're an Iksar, but I've not done that yet :)
		int Level = GetLevel();
		
		if (GetRace() == HUMAN)
		{
			if(Level <= 24)
				return(36);
			if(Level <= 29)
				return(35);
			if(Level <= 34)
				return(34);
			if(Level <= 39)
				return(33);
			if(Level <= 44)
				return(32);
			if(Level <= 49)
				return(31);
			if(Level <= 52)
				return(30);
			if(Level <= 55)
				return(29);
			if(Level <= 58)
				return(28);
			if(Level <= 59)
				return(27);
			if(Level <= 65)
				return(25);
			if(Level <= 70)
				return(24);
			if(Level <= 75)
				return(23);
			if(Level <= 80)
				return(24);
			if(Level <= 85)
				return(23);
			if(Level <= 90)
				return(24);
			if(Level <= 100)
				return(23);
			return(23);
		}
		else	//heko: iksar table
		{
			if(Level <= 29)
				return(36);
			if(Level <= 34)
				return(35);
			if(Level <= 39)
				return(34);
			if(Level <= 44)
				return(33);
			if(Level <= 49)
				return(32);
			if(Level <= 52)
				return(31);
			if(Level <= 55)
				return(30);
			if(Level <= 58)
				return(29);
			if(Level <= 59)
				return(28);
			if(Level <= 65)
				return(26);
			if(Level <= 70)
				return(25);
			if(Level <= 75)
				return(24);
			if(Level <= 80)
				return(25);
			if(Level <= 85)
				return(24);
			if(Level <= 90)
				return(25);
			if(Level <= 100)
				return(24);
			return(24);
		}
	}
}

//heko: backstab
void Mob::RogueBackstab(Mob* other, const Item_Struct *weapon1, int8 bs_skill)
{
	sint32 ndamage = 0;
	sint32 max_hit, min_hit;
	float skillmodifier = 0.0;
	const Item_Struct* primaryweapon = 0;
	
	primaryweapon = weapon1;	//backstab uses primary weapon
	skillmodifier = (float)bs_skill/25.0;	//formula's from www.thesafehouse.org
	
	// formula is (weapon damage * 2) + 1 + (level - 25)/3 + (strength+skill)/100
	max_hit = (sint32)(((float)primaryweapon->common.damage * 2.0) + 1.0 + ((level - 25)/3.0) + ((GetSTR()+GetSkill(BACKSTAB))/100));
	max_hit *= (sint32)skillmodifier;
	
	// determine minimum hits
	if (level < 51)
	{
		min_hit = 0;
	}
	else
	{
		switch (level)
		{
		case 51:
			min_hit = (sint32) ((float)level * 1.5);
			break;
		case 52:
			min_hit = (sint32) ((float)level * 1.55);
			break;
		case 53:
			min_hit = (sint32) ((float)level * 1.6);
			break;
		case 54:
			min_hit = (sint32) ((float)level * 1.65);
			break;
		case 55:
			min_hit = (sint32) ((float)level * 1.7);
			break;
		case 56:
			min_hit = (sint32) ((float)level * 1.75);
			break;
		case 57:
			min_hit = (sint32) ((float)level * 1.80);
			break;
		case 58:
			min_hit = (sint32) ((float)level * 1.85);
			break;
		case 59:
			min_hit = (sint32) ((float)level * 1.9);
			break;
		case 60:
		default:
			min_hit = (sint32) ((float)level * 2.0);
			break;
		}
	}
	ndamage = (sint32)min_hit + (rand()%(max_hit-min_hit)+1);	// TODO: better formula, consider mob level vs player level, strength/atk
	other->Damage(this, ndamage, 0xffff, 0x08);	//0x08 is backstab
	DoAnim(2);	//piercing animation
}


// solar - assassinate
void Mob::RogueAssassinate(Mob* other)
{
	other->Damage(this, 32000, 0xffff, 0x08);	//0x08 is backstab
	DoAnim(2);	//piercing animation
}

// neotokyo 14-Nov-02
// Helperfunction to check for Lifetaps
bool Mob::IsLifetapSpell(int16 spell_id)
{
	// filter out invalid spell_ids
	if (spell_id <= 0 || spell_id >= 0xffff)
		return false;
	
	// if database says its a tap, i am sure its right
	if (spells[spell_id].targettype == ST_Tap)
		return true;
	
	// now check some additional lifetaps just to make sure
	// i.e. lifebane isnt recognized since type == target not tap
	switch(spell_id)
	{
	case 1613:
	case 341:
	case 445:
	case 502:
	case 447:
	case 525:
	case 2115: // Ancient: Lifebane
	case 446:
	case 524:
	case 1618: 
	case 1393: // Gangrenous touch of zu'muul
	case 1735: // trucidation
		return true;
	}
	return false;
}