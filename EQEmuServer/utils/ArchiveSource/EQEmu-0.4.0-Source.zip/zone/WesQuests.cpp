/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include "../common/files.h"
#include "client.h"

#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

// Disgrace: for windows compile
#ifdef WIN32
#include <windows.h>
#include <winsock.h>
#include <process.h>

#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#else
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "../common/unix.h"
#endif

#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "../common/classes.h"
#include "../common/races.h"
#include "../common/database.h"
#include "spdat.h"
#include "../common/packet_functions.h"
#include "PlayerCorpse.h"
#include "spawn2.h"
#include "zone.h"
#include "../common/seperator-2.h"

extern Database database;
extern Zone* zone;
extern WorldServer worldserver;

bool Client::IsCommented(char* string) {
	if (string[0] == '#') {
		return true;
	}
	for (unsigned int u=0; u < strlen(string); u++)
	{
		if (string[u] == '#' && string[0] == '	') {
			return true;
		}
	}
	return false;
}

bool Client::IsEnd(char* string)
{
	if (string[0] == 125) {
		return true;
	}
	for (unsigned int u=0; u < strlen(string); u++)
	{
		if (string[u] == '}' && (string[0] == '	' || string[0] == ' ')) {
			return true;
		}
	}
	return false;
}

char * Client::strreplace(char* searchstring, char* searchquery, const char* replacement)
{
	static char newstringza[4096] = "";
	memset(newstringza, 0, sizeof(newstringza));
	unsigned int i, j = 0, k;
	for (i=0; i < strlen(searchstring); ++i)
	{
		if (!strncmp(&searchstring[i], searchquery, strlen(searchquery)))
		{
			for (k = 0; k < strlen(replacement); ++k)
				newstringza[j++] = replacement[k];
			i += strlen(searchquery) - 1;
		}
		else
		{   
			newstringza[j] = searchstring[i];
			++j;
		}
	}  
	return newstringza;
}

char * Client::rmnl(char* nstring)
{
	for (unsigned int e=0; e < strlen(nstring); e++)
	{
		if (nstring[e] == 13 || nstring[e] == 10) {
			printf("Edited!!! %d and %d\n", e, strlen(nstring));
			nstring[e] = 32;
		}
	}
	return nstring;
}

void Client::CheckQuests(const char* zonename, const char * message, int32 npc_id, int32 item_id)
{
	bool ps = false;
	bool tt = false;
	bool ti = false;
	bool ps2 = false;
	bool tt2 = false;
	bool ti2 = false;
	bool stt = false;
	bool pss = false;
	bool std = false;
	bool td = false;
	bool sti = false;
	int jh = 0;
	FILE * pFile;
	long lSize;
	char * buffer;
	char filename[255];
#ifdef WIN32
	snprintf(filename, 254, "Quests\\%i.qst", npc_id);
#else
	snprintf(filename, 254, "%s/%i.qst", QUEST_DIR, npc_id);
#endif
	
	if ((pFile = fopen ( filename , "rb" ))) {
		printf("Reading quests from %s\n", filename);
	}
	else {
		printf("Error: No quests file found '%s'\n", filename);
		return;
	}
	if (pFile==NULL) exit (1);
	
	// obtain file size.
	fseek (pFile , 0 , SEEK_END);
	lSize = ftell (pFile);
	rewind (pFile);
	
	// allocate memory to contain the whole file.
	buffer = new char[lSize];
	if (buffer == NULL) exit (2);
	
	// copy the file into the buffer.
	fread (buffer,1,lSize,pFile);
	fclose(pFile);
	Seperator3 sep3(buffer);
	for(int i=0; i < 2048; ++i)
	{
		//  printf("Temp: %s\n", sep3.arghz[i]);
		char * command;
		char * temp;
		temp = sep3.arghz[i];
		if (temp == NULL) return;
		Seperator sep(temp);
		Seperator4 sep4(temp);
		command = sep4.arghza[0];
		if (!IsCommented(temp)) {
			if (ps) {
				char lvl[5];
				sprintf(lvl, "%i", this->GetLevel());
				strcpy(sep4.arghza[1], strreplace(sep4.arghza[1],"%CHARRACE%", GetRaceName(this->GetRace())));
				strcpy(sep4.arghza[1], strreplace(sep4.arghza[1],"%CHARLEVEL%", lvl));
				strcpy(sep4.arghza[1], strreplace(sep4.arghza[1],"%CHARCLASS%", GetEQClassName(this->GetClass(), 50)));	
				strcpy(sep4.arghza[1], strreplace(sep4.arghza[1],"%CHARNAME%", this->GetName()));
				char *nmessage=sep4.arghza[1];
				if (strstr(strupr(command),"SAY") != NULL) {
					if (tt2 || ti2 || td) {
						entity_list.Message(0, MT_Say, "%s says, '%s'", this->target->GetName(), nmessage);
					}
				}
				else if (strstr(strupr(command),"EMOTE") != NULL) {
					if (tt2 || ti2 || td) {
						entity_list.Message(0, MT_Emote, "%s %s", this->target->GetName(), nmessage);
					}
				}
				else if (strstr(strupr(command),"SHOUT") != NULL) {
					if (tt2 || ti2 || td) {
						entity_list.Message(0, MT_Shout, "%s shouts, '%s'", this->target->GetName(), nmessage);
					}
				}
				else if (strstr(strupr(command),"SPAWN_ITEM") != NULL) {
					if (tt2 || ti2 || td) {
						this->SummonItem(atoi(sep.arg[1]));
					}
				}
				else if (strstr(strupr(command),"ADD_HATELIST") != NULL) {
					if (tt2 || ti2 || td) {
						Entity* tmp = entity_list.GetID(atoi(sep.arg[1]));
						//Mob* tma = entity_list.GetMob(tmp->GetName());
						tmp->CastToNPC()->AddToHateList(this, 100, 100);
					}
				}
				else if (strstr(strupr(command), "FLAG_ACCOUNT") != NULL) {
					if (tt2 || ti2 || td) {
						if(!database.SetGMFlag(this->account_name, atoi(sep.arg[1])))
							Message(0, "Unable to set GM Flag.");
						else {
							cout<<this->account_name;
							Message(0, "Set GM Flag on account.");
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_FlagUpdate;
							pack->size = strlen(this->account_name) + 1;
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							strcpy((char*) pack->pBuffer, this->account_name);
							worldserver.SendPacket(pack);
							delete pack;
						}
					}
				}
				else if (strstr(strupr(command),"SPAWN_NPC") != NULL) {
					if (tt2 || ti2 || td) {
						sep.arg[1][29] = 0;
						if (!sep.IsNumber(2))
							sprintf(sep.arg[2],"1"); 
						if (!sep.IsNumber(3))
							sprintf(sep.arg[3],"1"); 
						if (!sep.IsNumber(4))
							sprintf(sep.arg[4],"0");
						if (atoi(sep.arg[5]) > 2100000000 || atoi(sep.arg[5]) <= 0)
							sprintf(sep.arg[5],"");
						if (!strcmp(sep.arg[6],"-"))
							sprintf(sep.arg[6],""); 
						if (!sep.IsNumber(6))
							sprintf(sep.arg[6],""); 
						if (!sep.IsNumber(7))
							sprintf(sep.arg[7],"1");
						
						
						if (!sep.IsNumber(8))
							sprintf(sep.arg[8],"0");
						if (!strcmp(sep.arg[5],"-"))
							sprintf(sep.arg[5],""); 
						//Calc MaxHP if client neglected to enter it...
						if (!sep.IsNumber(5)) {
							//Stolen from Client::GetMaxHP...
							int8 multiplier = 0;
							switch(atoi(sep.arg[6]))
							{
							case WARRIOR:
								if (atoi(sep.arg[3]) < 20)
									multiplier = 22;
								else if (GetLevel() < 30)
									multiplier = 23;
								else if (GetLevel() < 40)
									multiplier = 25;
								else if (GetLevel() < 53)
									multiplier = 27;
								else if (GetLevel() < 57)
									multiplier = 28;
								else
									multiplier = 30;
								break;
								
							case DRUID:
							case CLERIC:
							case SHAMAN:
								multiplier = 15;
								break;
								
							case PALADIN:
							case SHADOWKNIGHT:
								if (atoi(sep.arg[3]) < 35)
									multiplier = 21;
								else if (GetLevel() < 45)
									multiplier = 22;
								else if (GetLevel() < 51)
									multiplier = 23;
								else if (GetLevel() < 56)
									multiplier = 24;
								else if (GetLevel() < 60)
									multiplier = 25;
								else
									multiplier = 26;
								break;
								
							case MONK:
							case BARD:
							case ROGUE:
								//		case BEASTLORD:
								if (atoi(sep.arg[3]) < 51)
									multiplier = 18;
								else if (GetLevel() < 58)
									multiplier = 19;
								else
									multiplier = 20;				
								break;
								
							case RANGER:
								if (atoi(sep.arg[3]) < 58)
									multiplier = 20;
								else
									multiplier = 21;			
								break;
								
							case MAGICIAN:
							case WIZARD:
							case NECROMANCER:
							case ENCHANTER:
								multiplier = 12;
								break;
								
							default:
								if (atoi(sep.arg[3]) < 35)
									multiplier = 21;
								else if (atoi(sep.arg[3]) < 45)
									multiplier = 22;
								else if (atoi(sep.arg[3]) < 51)
									multiplier = 23;
								else if (atoi(sep.arg[3]) < 56)
									multiplier = 24;
								else if (atoi(sep.arg[3]) < 60)
									multiplier = 25;
								else
									multiplier = 26;
								break;
							}
							sprintf(sep.arg[5],"%i",5+multiplier*atoi(sep.arg[3])+multiplier*atoi(sep.arg[3])*75/300);
						}
						
						// Autoselect NPC Gender... (Scruffy)
						if (sep.arg[6][0] == 0) {
							sprintf(sep.arg[6], "%i", (int) Mob::GetDefaultGender(atoi(sep.arg[2])));
						}
						
						// Well we want everyone to know what they spawned, right? 
						
						//Time to create the NPC!! 
						NPCType* npc_type = new NPCType;
						memset(npc_type, 0, sizeof(NPCType));
						strcpy(npc_type->name,sep.arg[1]);
						npc_type->cur_hp = atoi(sep.arg[5]); 
						npc_type->max_hp = atoi(sep.arg[5]); 
						npc_type->race = atoi(sep.arg[2]); 
						npc_type->gender = atoi(sep.arg[6]); 
						npc_type->class_ = atoi(sep.arg[7]); 
						npc_type->deity= 1; 
						npc_type->level = atoi(sep.arg[3]); 
						npc_type->npc_id = 0;
						npc_type->loottable_id = 0;
						npc_type->texture = atoi(sep.arg[4]);
						npc_type->light = 0; 
						for (int i=0; i<9; i++) 
							npc_type->equipment[i] = atoi(sep.arg[8]); 
						
						npc_type->STR = 75;
						npc_type->STA = 75;
						npc_type->DEX = 75;
						npc_type->AGI = 75;
						npc_type->INT = 75;
						npc_type->WIS = 75;
						npc_type->CHA = 75;
						
						
						NPC* npc = new NPC(npc_type, 0, atoi(sep.arg[9]), atoi(sep.arg[10]), atoi(sep.arg[11]), heading);
						delete npc_type;
						
						// Disgrace: add some loot to it!
						npc->AddCash();
						int itemcount = (rand()%5) + 1;
						for (int counter=0; counter<itemcount; counter++)
						{
							
							const Item_Struct* item = 0;
							while (item == 0)
								item = database.GetItem(rand() % 33000);						
							
							npc->AddItem(item, 0, 0);
						}
						
						entity_list.AddNPC(npc); 
				}
				}
				else if (strstr(strupr(command),"EXP") != NULL) {
					if (tt2 || ti2 || td) {
						this->AddEXP (atoi(sep.arg[1]));
					}
				}
				else if (strstr(strupr(command),"LEVEL") != NULL) {
					if (tt2 || ti2 || td) {
						this->SetLevel(atoi(sep.arg[1]), true);
					}
				}
				else if (strstr(strupr(command),"RAIN") != NULL) {
					if (tt2 || ti2 || td) {
						zone->zone_weather = atoi(sep.arg[1]);
						APPLAYER* outapp = new APPLAYER;
						outapp = new APPLAYER;
						outapp->opcode = OP_Weather;
						outapp->pBuffer = new uchar[8];
						memset(outapp->pBuffer, 0, 8);
						outapp->size = 8;
						outapp->pBuffer[4] = atoi(sep.arg[1]); // Why not just use 0x01/2/3?
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
				}
				else if (strstr(strupr(command),"SNOW") != NULL) {
					if (tt2 || ti2 || td) {
						zone->zone_weather = atoi(sep.arg[1]) + 1;
						APPLAYER* outapp = new APPLAYER;
						outapp = new APPLAYER;
						outapp->opcode = OP_Weather;
						outapp->pBuffer = new uchar[8];
						memset(outapp->pBuffer, 0, 8);
						outapp->size = 8;
						outapp->pBuffer[0] = 0x01;
						outapp->pBuffer[4] = atoi(sep.arg[1]); 
						entity_list.QueueClients(this, outapp);
						delete outapp;
					}
				}
				else if (strstr(strupr(command),"CAST_SPELL") != NULL) {
					if (tt2 || ti2 || td) {
						this->target->CastSpell(atoi(sep.arg[1]),this->GetID());
					}
				}
				else if (strstr(strupr(command),"FACE_TARGET") != NULL) {
					if (tt2 || ti2 || td) {
						this->GetTarget()->CastToNPC()->SetTarget(entity_list.GetMob(this->GetName()));
						this->GetTarget()->CastToNPC()->FaceTarget();
					}
				}
				else if (strstr(strupr(command),"SPAWN_GROUP") != NULL) {
					if (tt2 || ti2 || td) {
						//Temporarily disabled			entity_list.Message(0, MT_Say, "%s says, '%s'", this->GetName(), sep4.arghza[1]);
					}
				}
				else if (strstr(strupr(command),"PVP") != NULL) {
					if (tt2 || ti2 || td) {
						if (strstr(strupr(sep.arg[1]),"ON") != NULL)
							this->CastToClient()->SetPVP(true);
						else
							this->CastToClient()->SetPVP(false);
					}
				}
				/*else if (strstr(strupr(command),"CHANGEFACTION") != NULL) { // Wiz: This does not work - remaking it for new faction code
					if (tt2 || ti2 || td) {
						if ((sep.IsNumber(1)) && (sep.IsNumber(2))) {
							this->CastToClient()->SetFactionLevel2(this->CastToClient()->CharacterID(),atoi(sep.arg[1]), this->CastToClient()->GetClass(), this->CastToClient()->GetRace(), this->CastToClient()->GetDeity(), atoi(sep.arg[2]));
							this->CastToClient()->Message(0,BuildFactionMessage(GetCharacterFactionLevel(atoi(sep.arg[1])),atoi(sep.arg[1])));
						}
						else
						{
							cout << "Error in script!!!!!  Bad CHANGEFACTION Line! " << endl;
						}
					}
				}*/
				else if (strstr(strupr(command),"DO_ANIMATION") != NULL) {
					if (tt2 || ti2 || td) {
						if (target!=0){
							target->DoAnim(atoi(sep.arg[1]));
						}							
					}
				}
				else if (strstr(strupr(command),"SETALLSKILL") != NULL) {
					if (tt2 || ti2 || td) {
						if (sep.IsNumber(1) && (atoi(sep.arg[1]) >= 0 || atoi(sep.arg[1]) <= 252)) {
							for(int skill_num=0;skill_num<74;skill_num++)
								this->SetSkill(skill_num, atoi(sep.arg[1]));
						}
						else
							cout << "Error in script!!!! Bad SETALLSKILL line!" << endl;
					}
				}
				else if (strstr(strupr(command),"SETSKILL") != NULL) {
					if (tt2 || ti2 || td) {
						if (sep.IsNumber(1) && sep.IsNumber(2) && (atoi(sep.arg[2]) >= 0 || atoi(sep.arg[2]) <= 252) && (atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) < 74)) {
							this->SetSkill(atoi(sep.arg[1]), atoi(sep.arg[2]));
						}
						else
							cout << "Error in script!!!! Bad SETSKILL line!" << endl;
					}
				}
				else if (strstr(strupr(command),"ADDSKILL") != NULL) {
					if (tt2 || ti2 || td) {
						if (sep.IsNumber(1) && sep.IsNumber(2) && (atoi(sep.arg[2]) >= 0 || atoi(sep.arg[2]) <= 252) && (atoi(sep.arg[1]) >= 0 && atoi(sep.arg[1]) < 74)) {
							this->AddSkill(atoi(sep.arg[1]), atoi(sep.arg[2]));
						}
						else
							cout << "Error in script!!!! Bad ADDSKILL line!" << endl;
					}
				}
				
				
	}
	if (IsEnd(temp)) {
		if (tt || stt) { jh = 1; tt = false; tt2 = false; stt = false; }
		else if (ti || sti) { jh = 1; ti = false; ti2 = false; sti = false; }
		else if (td || std) { jh = 1; td = false; std = false; }
		else if (ps || pss) { jh = 1; ps = false; pss = false; }
		jh = 0;
	}
	if (strstr(strupr(command),"NPC_SCRIPT") != NULL && strstr(sep3.arghz[i],"{") != NULL) {
		if (!ps && !tt && !ti) {
			if (atoi(sep.arg[1]) == npc_id) { ps = true; ps2 = true; }
			else { pss = true; }
		}
		else {
			printf("NPC_SCRIPT Error at line %d: missing left curly bracket\n", i);
			return;
		}
	}
	else if (strstr(strupr(command),"TRIGGER_DEATH") != NULL && strstr(sep3.arghz[i],"{") != NULL && ps) {
		if (!tt && !ti && ps && strstr(message,"%%DEATH%%") != NULL) {
			
			td = true;
		}
		else { std = true; }
	}
	else if (strstr(strupr(command),"TRIGGER_ITEM") != NULL && strstr(sep3.arghz[i],"{") != NULL) {
		if (!tt && !ti) {
			
			if (item_id == atoi(sep4.arghza[1])) { ti = true; ti2 = true; }
			else { sti = true; }
		}
		else if (!ps) { printf("TRIGGER_ITEM Error at line %d: Not in NPC_Script\n", i); return; }
		else {
			printf("TRIGGER_ITEM Error at line %d: missing left curly bracket\n", i);
			return;
		}
	}
	else if (strstr(strupr(command),"TRIGGER_TEXT") != NULL && strstr(sep3.arghz[i],"{") != NULL && ps) {
		if (!tt && !ti && strstr(message,"%%DEATH%%") == NULL && strstr(message,"%%item%%") == NULL) {
			char* tmp = new char[strlen(message)+1];
			strcpy(tmp, message);
			strupr(tmp);
			if (strstr(tmp,strupr(sep4.arghza[1])) != NULL) {
				tt2 = true; tt = true;
			}
			else {
				stt = true;
			}
			delete tmp;
		}
		else if (strstr(message,"%%DEATH%%") != NULL || strstr(message,"%%item%%") != NULL) { stt = true; }
		else if (!ps) { printf("TRIGGER_TEXT Error at line %d: Not in NPC_Script\n", i); return; }
		else {
			printf("TRIGGER_TEXT Error at line %d: missing left curly bracket\n", i);
			return;
		}
	}
#ifdef WIN32
	delete command;
	delete temp;
#endif
}
}
delete buffer;
}

