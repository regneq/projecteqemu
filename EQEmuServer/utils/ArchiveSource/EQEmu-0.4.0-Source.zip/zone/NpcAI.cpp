/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#ifdef WIN32
#define snprintf	_snprintf
#endif

#include "NpcAI.h"
#include "entity.h"
#include "npc.h"
#include "client.h"
#include "faction.h"

////////////////////////////////////////////// MOB AI /////////////////////////////////////
// 03/09   - Merkur
// Adds Hate to close Mobs depending on faction,level, appearence and target
//////////////////////////////////////////////////////////////////////////////////////////
bool EntityList::AddHateToCloseMobs(NPC* sender, float dist, int social)
{
    // thoughts on aggro:
    // - each mob has aggro radius, which can be lowered by spells
    // - mobs that cant see each other dont aggro (exception outdoors)
    // - in dungeons green mobs dont add
    // - mobs will aggro even if max ally, if you attack one of their mates
    // - if attacker is already on hate list dont increase aggro
	
    // if no sender, or sender doesnt even have aggro return
	if (sender == 0 || sender->GetHateTop() == 0)
		return false;
	
    if(dist <= 0)
		dist = 90;
	
    int count = 0;
	
	LinkedListIterator<Entity*> iterator(list);	
	iterator.Reset();					
	
	while(iterator.MoreElements()) 
	{
		if (iterator.GetData() != sender && iterator.GetData() != 0)
		{
            if (iterator.GetData()->IsNPC())
            {
                NPC * currentnpc = iterator.GetData()->CastToNPC();
				
                sint32 current_aggroradius = currentnpc->GetAggroRadius();
                // the mobs in database arent set so get some defaultvalue
                // defaultvalue is set in NPCType, but just to make sure
                if (current_aggroradius <= 0 || current_aggroradius >= 999)
                    current_aggroradius = 90;
                // check distance -> aggroradius
                float distance = currentnpc->DistNoZ( sender );
				
                // if its out of aggrorange dont do anything at all
                if (distance > current_aggroradius)
                {
                    iterator.Advance();
                    continue;
                }
				
                // now check level difference - can we get indoor/outdoor status??
                int32 currentmoblevel = currentnpc->GetLevel();
                int32 attackerlevel = 200;
                // now assume the offender is the one with the most hate on the sender.
                // would be cool to check all the hatelist - but how?
                // TODO: make hatelist iterator
                Mob* attacker = sender->GetHateTop();
                if (attacker && attacker->IsClient())
                {
                    // seems to be ok. attacker exists and is a client
                    attackerlevel = attacker->GetLevel();
                }
                else if (attacker)
                {
                    // ok, attacker is a charmed npc or pet
                    attackerlevel = attacker->GetLevel();
                }
				
                // Check if attacker is already on hatelist
                if (currentnpc->hate_list.IsOnHateList(attacker))
                {
                    iterator.Advance();
                    continue;
                }
                
                // use some obscure function to determine con
                int32 con = GetLevelCon(attackerlevel, currentmoblevel);
                // if the mob cons green it wont help its friend
                if (con == CON_GREEN || con == CON_BLUE2)
                {
                    iterator.Advance();
                    continue;
                }
				
                // TODO: how can we check if the mobs can see each other
                //  face-2-face - aggroradius is lower if back turned to sender
				
                // ok now we need to check factions
                // aggro is only spread between mobs on the same faction
                // if the mob would aggro on the Client is another story
                // this is only for spreading the hate
                // (aggro by distance is hopefully checked elsewhere)
                LinkedList<struct NPCFaction*> *currentmob_faclist = &currentnpc->faction_list;
                LinkedListIterator<struct NPCFaction*> fac_iteratorcur(*currentmob_faclist);
				
                LinkedList<struct NPCFaction*> *sender_faclist = &sender->faction_list;
                LinkedListIterator<struct NPCFaction*> fac_iteratorsend(*sender_faclist);
				
                fac_iteratorcur.Reset();
				
                bool bSameFaction = false;
				while(fac_iteratorcur.MoreElements())
                {
                    struct NPCFaction *pfac_send = NULL;
                    struct NPCFaction *pfac_cur = NULL;
					
                    pfac_cur = fac_iteratorcur.GetData();
					
                    fac_iteratorsend.Reset();
					while(fac_iteratorsend.MoreElements())
                    {
                        pfac_send = fac_iteratorsend.GetData();
                        
                        // now we can check the factions - we should get the faction-modifier
                        // and only if both ids are equal and modifier is negative we have a winner
                        if ((pfac_send->factionID == pfac_cur->factionID) && pfac_send->value_mod <= 0)
                            bSameFaction = true;
                        fac_iteratorsend.Advance();
                    } // while sender fac_list
                    fac_iteratorcur.Advance();
                } // while currentmob fac_list
				
                if (bSameFaction)
                {
#ifdef _DEBUG
					cout << "Distance between << " << currentnpc->GetName() << " and " << sender->GetName() << " is: " << distance << " --> Aggroradius=" << current_aggroradius << endl;
					cout << currentnpc->GetName() << " will do battle now --> adding to hate list" << endl;
#endif
					currentnpc->AddToHateList(attacker, 1);
                    count++;
                }
            } // if ->IsNPC
            else
            {
                // if its not a npc we cant do anything
                iterator.Advance();
                continue;
            }
        } // if != sender && != NULL
        iterator.Advance();
    } // while
    if (count > 0)
        return true;
    return false;
}


// neotokyo: I HATE THE GUY WHO WROTE THIS!!!!
int32 GetLevelCon(int8 PlayerLevel, int8 NPCLevel)
{
	sint8 tmp = NPCLevel - PlayerLevel;
	int32 conlevel=0;
	if (PlayerLevel <= 12)
	{
		conlevel =  (tmp <= -4) ? 0x02:
	(tmp >=-3 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:			
	(tmp >= 1 && tmp <= 2) ?0x0F:    
	0x0D;							
	}
	else if (PlayerLevel >= 13 && PlayerLevel <= 24)
	{
		conlevel =  (tmp <= -6) ? 0x02:			
	(tmp >=-5 && tmp <= -4) ? 0x12:
	(tmp >=-3 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 25 && PlayerLevel <= 40)
	{
								conlevel =  (tmp <= -11) ? 0x02:
	(tmp >=-10 && tmp <= -8) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 41 && PlayerLevel <= 48)
	{
								conlevel =  (tmp <= -12) ? 0x02:
	(tmp >=-11 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 50)
	{
								conlevel =  (tmp <= -14) ? 0x02:
	(tmp >=-13 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	};
	return conlevel;
	
};
