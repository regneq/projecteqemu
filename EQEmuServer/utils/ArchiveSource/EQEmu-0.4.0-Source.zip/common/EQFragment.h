/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef EQFRAGMENT_H
#define EQFRAGMENT_H

#include "types.h"
#include "linked_list.h"

/*	Replacement code for FRAGMENT and FRAGMENT_GROUP 
	not for speed, for functionality and readability */

class Fragment
{
public:
	Fragment();
	~Fragment();

	void   SetData(uchar* d, int32 s);

	uchar* GetData() { return data; }
	int32  GetSize() { return size; }

private:
	uchar*	data;
	int32	size;
};

class FragmentGroup
{
public:
	FragmentGroup(int16 seq, int16 opcode, int16 num_fragments);
	~FragmentGroup();

	void Add(int16 frag_id, uchar* data, int32 size);
	uchar* AssembleData(int32* size);

	int16 GetSeq()               { return seq; }
	int16 GetOpcode()            { return opcode; }

private:
	int16 seq;        //Sequence number
	int16 opcode;     //Fragment group's opcode
	int16 num_fragments;
	Fragment* fragment;
};

class FragmentGroupList
{
public:
	void Add(FragmentGroup* add_group);
	FragmentGroup* Get(int16 find_seq);
	void Remove(int16 remove_seq);

private:
	LinkedList<FragmentGroup*> fragment_group_list;
};

#endif
