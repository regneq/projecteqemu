#ifndef EQTIME_H
#define EQTIME_H

#include "../common/eq_packet_structs.h"
#include "../common/database.h"

//Struct
struct eqTimeOfDay
{
	TimeOfDay_Struct start_eqtime;
	time_t	start_realtime;
};

//Class Def
class EQTime
{
public:
	//Constructor/destructor
	EQTime(TimeOfDay_Struct start_eq, time_t start_real);
	EQTime();
	~EQTime();

	//Get functions
	int getEQTimeOfDay( time_t timeConvert, TimeOfDay_Struct *eqTimeOfDay );
	TimeOfDay_Struct getStartEQTime() { return eqTime.start_eqtime; }
	time_t getStartRealTime() { return eqTime.start_realtime; }
	int8 getTimeZone() { return timezone; }

	//Set functions
	int setEQTimeOfDay(TimeOfDay_Struct start_eq, time_t start_real);
	void setEQTimeZone(sint8 in_timezone) { timezone=in_timezone; }

	//Database functions
	//bool loadDB(Database q);
	//bool setDB(Database q);
	bool loadFile(char filename[255]);
	bool saveFile(char filename[255]);

private:
	//This is our reference clock.
	eqTimeOfDay eqTime;
	//This is our tz offset
	sint8 timezone;
};

#endif
