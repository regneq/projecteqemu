/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef ZONESERVER_H
#define ZONESERVER_H

#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/servertalk.h"
#include "../common/eq_packet_structs.h"
#include "WorldTCPConnection.h"
#include "console.h"
#include "../common/Mutex.h"
#include "../common/eqtime.h"

class ClientListEntry;

#ifdef WIN32
	void ZoneServerLoop(void *tmp);
#else
	void *ZoneServerLoop(void *tmp);
#endif

class ZoneServer : public WorldTCPConnection
{
public:
	ZoneServer(int32 ip, int16 port, int send_socket);
    ~ZoneServer();
	
	bool		Process();
	bool		ReceiveData();
	void		SendPacket(ServerPacket* pack);
	void		SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...);
	bool		SetZone(const char* zonename,bool sz=false);
	bool		SetConnectInfo(const char* in_address, int16 in_port);
	void		TriggerBootup(const char* zonename = 0, const char* adminname = 0);

	const char*	GetZoneName()	{ return zone_name; }
	int32		GetIP()			{ return ip; }
	int16		GetPort()		{ return port; }
	const char*	GetCAddress()	{ return clientaddress; }
	int16		GetCPort()		{ return clientport; }
	int32		GetID()			{ return ID; }
	bool		IsBootingUp()	{ return BootingUp; }
	bool		IsStaticZone()	{ return staticzone; }

private:
	Mutex	MPacketLock;
	SPackSendQueue* SendQueuePop();
	void RecvPacket(ServerPacket* pack);
	ServerPacket* RecvQueuePop();

	int32	ID;
	int		send_socket;
	int32	ip;
	int16	port;
	char	clientaddress[250];
	int16	clientport;
	bool	BootingUp;
	bool	staticzone;

	Timer* timeout_timer;

	MyQueue<ServerPacket> ServerRecvQueue;
	MyQueue<SPackSendQueue> ServerSendQueue;
	
	char zone_name[16];
};

class ZSList
{
public:
	ZSList();
	~ZSList();
	ZoneServer* FindByName(const char* zonename);
	ZoneServer* FindByID(int32 ZoneID);
	ZoneServer* FindByZoneID(int32 ZoneID);
	ZoneServer*	FindByPort(int16 port);
	
	void	SendChannelMessage(const char* from, const char* to, int8 chan_num, int8 language, const char* message, ...);
	void	SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...);

	void	ClientUpdate(ZoneServer* zoneserver, const char* name, int32 accountid, const char* accountname, int32 lsaccountid, sint16 admin, const char* zone, int8 level, int8 class_, int8 race, int8 anon, bool tellsoff, int32 in_guilddbid, int32 in_guildeqid, bool LFG);
	void	ClientRemove(const char* name, const char* zone);

	void	SendWhoAll(const char* to, sint16 admin, Who_All_Struct* whom, WorldTCPConnection* connection);
	void	SendZoneStatus(const char* to, sint16 admin, WorldTCPConnection* connection);
	void	SendTimeSync();
	ClientListEntry* FindCharacter(const char* name);
	void	CLCheckStale();
	
	void	Add(ZoneServer* zoneserver);
	void	Process();
	void	ReceiveData();
	void	SendPacket(ServerPacket* pack);
	void	SendPacket(const char* to, ServerPacket* pack);
	int32	GetNextID()		{ return NextID++; }
	void	RebootZone(const char* ip1,int16 port, const char* ip2, int32 skipid, int32 zoneid = 0);
	int32	TriggerBootup(const char* zonename);
	static void SOPZoneBootup(const char* adminname, int32 ZoneServerID, const char* zonename);
	Mutex	MListLock;
	EQTime worldclock;
private:
	int32 NextID;
	LinkedList<ZoneServer*> list;
	LinkedList<ClientListEntry*> clientlist;
};

class ClientListEntry
{
public:
	ClientListEntry(ZoneServer* zoneserver, const char* in_name, int32 in_accountid, const char* in_accountname, int32 in_lsaccountid, sint16 in_admin, const char* in_zone, int8 level, int8 class_, int8 race, int8 anon, bool tellsoff, int32 in_guilddbid, int32 in_guildeqid, bool in_LFG) {
		pzoneserver = zoneserver;
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		plsaccountid = in_lsaccountid;
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
		panon = anon;
		ptellsoff = tellsoff;
		pguilddbid = in_guilddbid;
		pguildeqid = in_guildeqid;
		pLFG = in_LFG;
		stale = 0;
		timeout_timer = new Timer(INTERSERVER_TIMER);
	}
	~ClientListEntry() {
		delete timeout_timer;
	}
	bool CheckStale() {
		if (timeout_timer->Check()) {
			if (stale >= 2) {
				return true;
			}
			else {
				stale++;
				return false;
			}
		}
	}
	void Update(ZoneServer* zoneserver, const char* in_name, int32 in_accountid, const char* in_accountname, int32 in_lsaccountid, sint16 in_admin, const char* in_zone, int8 level, int8 class_, int8 race, int8 anon, bool tellsoff, int32 in_guilddbid, int32 in_guildeqid, bool in_LFG) {
		pzoneserver = zoneserver;
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		plsaccountid = in_lsaccountid;
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
		panon = anon;
		ptellsoff = tellsoff;
		pguilddbid = in_guilddbid;
		pguildeqid = in_guildeqid;
		pLFG = in_LFG;
		stale = 0;
	}
	ZoneServer* Server() { return pzoneserver; }
	char* name() { return pname; }
	char* zone() { return pzone; }
	char* AccountName() { return paccountname; }
	int32 AccountID() { return paccountid; }
	int32 LSAccountID() { return plsaccountid; }
	sint16 Admin() { return padmin; }
	int8 level() { return plevel; }
	int8 class_() { return pclass_; }
	int8 race() { return prace; }
	int8 Anon() { return panon; }
	int8 TellsOff() { return ptellsoff; }
	int32 GuildDBID() { return pguilddbid; }
	int32 GuildEQID() { return pguildeqid; }
	bool	LFG()		{ return pLFG; }
private:
	ZoneServer* pzoneserver;
	char pzone[25];
	sint16 padmin;
	char pname[64];
	int32 paccountid;
	char paccountname[32];
	int32 plsaccountid;
	int8 plevel;
	int8 pclass_;
	int8 prace;
	int8 panon;
	int8 ptellsoff;
	int32 pguilddbid;
	int32 pguildeqid;
	bool pLFG;

	int8 stale;

	Timer* timeout_timer;
};
#endif
