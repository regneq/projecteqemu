#include <iostream.h>
#include <string.h>
#include <stdio.h>

#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
#endif

#include "../common/servertalk.h"
#include "zoneserver.h"
#include "net.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "../common/classes.cpp"
#include "../common/races.h"

#ifdef BUILD_FOR_WINDOWS
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

extern Database database;
extern uint32	numclients;
extern uint32	numzones;
extern ZSList	zoneserver_list;
extern volatile bool ShutdownLoops;

int listening_socketZS;

void ZoneServerLoop(void *tmp);
void ListenNewZoneServer();
bool InitZoneServer();
ServerPacket* CopyPacket(ServerPacket* pack);

ZoneServer::ZoneServer(int32 in_ip, int16 in_port, int in_send_socket)
{
	ip = in_ip;
	port = in_port;
	ID = zoneserver_list.GetNextID();
	send_socket = in_send_socket;
	timeout_timer = new Timer(SERVER_TIMEOUT);
	zone_name[0]=0;
}

bool ZoneServer::SetZone(char* zonename) {
	strcpy(zone_name, zonename);
	struct in_addr  in;
	in.s_addr = GetIP();
	cout << "Zoneserver SetZone: " << inet_ntoa(in) << ":" << (int16)GetPort() << " " << zonename << endl;
	// TODO: Register zone in DB
	return true;
}

bool ZoneServer::SetPort(int16 in_port) {
	if (in_port != 0)
		port = in_port;
	struct in_addr  in;
	in.s_addr = GetIP();
	cout << "Zoneserver SetPort: " << inet_ntoa(in) << " says it's clinet listening port is " << (int16)GetPort() << endl;
	return true;
}

ZoneServer::~ZoneServer()
{
	zoneserver_list.ClientRemove(0, this->GetZoneName());
	shutdown(send_socket, 0x01);
	shutdown(send_socket, 0x00);
#ifdef BUILD_FOR_WINDOWS
	closesocket(send_socket);
#else
	close(send_socket);
#endif
	// TODO: Unregister zone
}

bool ZoneServer::Process()
{
    SOCKADDR_IN to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;
    
	/************ Get all packets from packet manager out queue and process them ************/
	ServerPacket *pack = 0;
	while(pack = ServerOutQueue.pop())
	{
		switch(pack->opcode) {
		case 0:
		break;
		case ServerOP_KeepAlive: {
			// ignore this
			break;
		}
		case ServerOP_ChannelMessage: {
			zoneserver_list.SendPacket(CopyPacket(pack));
			break;
		}
		case ServerOP_EmoteMessage: {
			ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
			zoneserver_list.SendEmoteMessage(sem->to, sem->type, sem->message);
			break;
		}
		case ServerOP_SetZone: {
			if (pack->size > 1)
				SetZone((char*) &pack->pBuffer[0]);
			else
				SetZone("");
			break;
		}
		case ServerOP_SetPort: {
			int32 port = 0;
			if (pack->size == 4)
				memcpy(&port, pack->pBuffer, 4);
				SetPort(port);
			break;
		}
		case ServerOP_ShutdownAll: {
			zoneserver_list.SendPacket(CopyPacket(pack));
			zoneserver_list.Process();
			ShutdownLoops = true;
			break;
		}
		case ServerOP_ZoneShutdown: {
			ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
			ZoneServer* zs = 0;
			if (s->ZoneServerID != 0)
				zs = zoneserver_list.FindByID(s->ZoneServerID);
			else if (s->zonename[0] != 0)
				zs = zoneserver_list.FindByName(s->zonename);
			else
				zoneserver_list.SendChannelMessage(0, s->adminname, 7, 0, "Error: SOP_ZoneShutdown: neither ID nor name specified");

			if (zs == 0)
				zoneserver_list.SendChannelMessage(0, s->adminname, 7, 0, "Error: SOP_ZoneShutdown: zoneserver not found");
			else
				zs->SendPacket(CopyPacket(pack));
			break;
		}
		case ServerOP_ZoneBootup: {
			ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
			cout << "ServerOP_ZoneBootup: " << s->adminname << ", " << s->zonename << ", " << s->ZoneServerID << endl;
			ZoneServer* zs = 0;
			ZoneServer* zs2 = 0;
			if (s->ZoneServerID != 0)
				zs = zoneserver_list.FindByID(s->ZoneServerID);
			else
				zoneserver_list.SendChannelMessage(0, s->adminname, 7, 0, "Error: SOP_ZoneBootup: ServerID must be specified");

			if (zs == 0)
				zoneserver_list.SendChannelMessage(0, s->adminname, 7, 0, "Error: SOP_ZoneBootup: zoneserver not found");
			else {
				zs2 = zoneserver_list.FindByName(s->zonename);
				if (zs2 != 0)
					zoneserver_list.SendChannelMessage(0, s->adminname, 7, 0, "Error: SOP_ZoneBootup: zone '%s' already being hosted by ZoneServer #%i", s->zonename, zs2->GetID());
				else
					zs->SendPacket(CopyPacket(pack));
			}
			break;
		}
		case ServerOP_ZoneStatus: {
			if (pack->size >= 1)
				zoneserver_list.SendZoneStatus((char *) &pack->pBuffer[1], (int8) pack->pBuffer[0]);
			break;
		}
		case ServerOP_ClientList: {
			ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
			if (scl->remove)
				zoneserver_list.ClientRemove(scl->name, scl->zone);
			else
				zoneserver_list.ClientUpdate(scl->name, scl->AccountID, scl->AccountName, scl->Admin, scl->zone, scl->level, scl->class_, scl->race);
			break;
		}
		case ServerOP_Who: {
			zoneserver_list.SendWhoAll((char*) &pack->pBuffer[1], (int8) pack->pBuffer[0]);
			break;
		}
		case ServerOP_ZonePlayer: {
			ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
			ZoneServer* zs = zoneserver_list.FindByName(szp->zone);
			if (zs == 0)
				zoneserver_list.SendEmoteMessage(szp->adminname, 0, "Error: zone '%s' not up", szp->zone);
			else
				zoneserver_list.SendPacket(CopyPacket(pack));
			break;
		}
		case ServerOP_KickPlayer: {
			zoneserver_list.SendPacket(CopyPacket(pack));
			break;
		}
		default:
		{
			cout << Timer::GetCurrentTime() << " Unknown ServerOPcode:" << (int)pack->opcode;
			cout << " size:" << pack->size << endl;
DumpPacketAscii(pack->pBuffer, pack->size, 16, 0);
			break;
		}
		}

		delete pack;
	}    
	/************ Get first send packet on queue and send it! ************/
	ServerPacket* p = 0;
	int status = 0;
	uchar* buf = 0;
	int16 size = 0;
	while(p = ServerSendQueue.pop())
	{
//		cout << "p->size=" << p->size << endl;
		buf = new uchar[p->size + 4];
		if (p->pBuffer != 0 && p->size != 0)
			memcpy((char *) &buf[4], (char *) p->pBuffer, p->size);
		memcpy((char *) &buf[0], (char *) &p->opcode, 2);
		size = p->size + 4;
		memcpy((char *) &buf[2], (char *) &size, 2);
		status = send(send_socket, (const char *) buf, size, 0);
		delete[] buf;
		delete &p;
		if (status == SOCKET_ERROR) {
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Zoneserver send() failed, assumed disconnect: #" << GetID() << " " << zone_name << " " << inet_ntoa(in) << ":" << GetPort() << endl;
			cout << "send_socket=" << send_socket << ", Status: " << status << ", Errorcode: " << WSAGetLastError() << endl;
			return false;
		}
	}
	/************ Processing finished ************/
    if (timeout_timer->Check())
    {
		// this'll hit the "send error, assumed disconnect" if the zoneserver has gone byebye
		pack = new ServerPacket;
		pack->opcode = ServerOP_KeepAlive;
		pack->size = 0;
		SendPacket(pack);
    }

	return true;
}

void ZoneServer::SendPacket(ServerPacket* pack) {
	ServerSendQueue.push(pack);
}

bool ZoneServer::ReceiveData() {
    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct in_addr	in;

    status = recv(send_socket, (char *) &buffer, sizeof(buffer), 0);

    if (status > 1)
    {
		in.s_addr = GetIP();

//		cout << Timer::GetCurrentTime() << " Data from ip: " << inet_ntoa(in) << " port:" << GetPort() << " length: " << status << endl;

		timeout_timer->Start();
		int16 base = 0;
		int16 size = 0;
// Fucking TCP stack will throw all the packets queued at you at once in one buffer
// Have to find the packet splitpoints
// Hoping it'll never throw only half a packet, but who knows :/
		while (base < status) {
			size = 4;
			if ((status - base) < 4)
				cout << "ZoneServer: packet too short for processing" << endl;
			else {
				ServerPacket* pack = new ServerPacket;
				memcpy((char*) &size, (char*) &buffer[base + 2], 2);

				memcpy((char*) &pack->opcode, (char*) &buffer[base + 0], 2);
				pack->size = size - 4;
				if (size > 4) {
					pack->pBuffer = new uchar[pack->size];
					memcpy((char*) pack->pBuffer, (char*) &buffer[base + 4], pack->size);
				} else
					pack->pBuffer = 0;
//cout << "Packet from zoneserver: OPcode=" << pack->opcode << " size=" << pack->size << endl;
				ServerOutQueue.push(pack);
			}
			base += size;
		}
	} else if (status == SOCKET_ERROR) {
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "Zoneserver connection lost: " << zone_name << " " << inet_ntoa(in) << ":" << GetPort() << endl;
			return false;
		}
	}
	return true;
}

void ZSList::Add(ZoneServer* zoneserver)
{
	list.Insert(zoneserver);
}

void ZSList::Process()
{
	LinkedListIterator<ZoneServer*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing zoneserver from ip:" << inet_ntoa(in) << " port:" << (int16)(iterator.GetData()->GetPort()) << endl;
			iterator.RemoveCurrent();
			numzones--;
		}
		else
		{
			iterator.Advance();
		}
	}
}

void ZSList::ReceiveData() {
	LinkedListIterator<ZoneServer*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->ReceiveData()) {
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing zoneserver: " << iterator.GetData()->GetZoneName() << " " << inet_ntoa(in) << ":" << (int16)(iterator.GetData()->GetPort()) << endl;
			iterator.RemoveCurrent();
			numzones--;
		} else {
			iterator.Advance();
		}

	}
}

void ZSList::SendPacket(ServerPacket* pack) {
	LinkedListIterator<ZoneServer*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		iterator.GetData()->SendPacket(pack);
		iterator.Advance();
	}
}

ZoneServer* ZSList::FindByName(char* zonename) {
	LinkedListIterator<ZoneServer*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->GetZoneName(), zonename) == 0)
			return iterator.GetData();
		iterator.Advance();
	}
}

ZoneServer* ZSList::FindByID(int32 ZoneID) {
	LinkedListIterator<ZoneServer*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == ZoneID)
			return iterator.GetData();
		iterator.Advance();
	}
}

void ZSList::SendZoneStatus(char* to, int8 admin) {
	LinkedListIterator<ZoneServer*> iterator(list);
	struct in_addr  in;
	
	iterator.Reset();
	SendEmoteMessage(to, 0, "Zoneservers online:");
	int x=0;
	while(iterator.MoreElements())
	{
		in.s_addr = iterator.GetData()->GetIP();

		if (admin >= 1) {
			SendEmoteMessage(to, 0, "  #%i  %s:%i  %s", iterator.GetData()->GetID(), inet_ntoa(in), iterator.GetData()->GetPort(), iterator.GetData()->GetZoneName());
			x++;
		}
		else if (strlen(iterator.GetData()->GetZoneName()) != 0) {
			SendEmoteMessage(to, 0, "  #%i  %s", iterator.GetData()->GetID(), iterator.GetData()->GetZoneName());
			x++;
		}
		iterator.Advance();
	}
	SendEmoteMessage(to, 0, "%i servers listed", x);
}

void ZSList::SendChannelMessage(char* from, char* to, int8 chan_num, int8 language, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->opcode = ServerOP_ChannelMessage;
	pack->size = sizeof(ServerChannelMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerChannelMessage_Struct* scm = (ServerChannelMessage_Struct*) pack->pBuffer;
	if (from == 0) {
		strcpy(scm->from, "WServer");
		scm->noreply = true;
	}
	else if (from[0] == 0) {
		strcpy(scm->from, "WServer");
		scm->noreply = true;
	}
	else
		strcpy(scm->from, from);
	if (to != 0) {
		strcpy((char *) scm->to, to);
		strcpy((char *) scm->deliverto, to);
	}
	else {
		scm->to[0] = 0;
		scm->deliverto[0] = 0;
	}

	scm->language = language;
	scm->chan_num = chan_num;
	strcpy(&scm->message[0], buffer);
	zoneserver_list.SendPacket(pack);
}

void ZSList::SendEmoteMessage(char* to, int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	ServerPacket* pack = new ServerPacket;

	pack->opcode = ServerOP_EmoteMessage;
	pack->size = sizeof(ServerEmoteMessage_Struct)+strlen(buffer)+1;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerEmoteMessage_Struct* sem = (ServerEmoteMessage_Struct*) pack->pBuffer;
	
	if (to != 0) {
		strcpy((char *) sem->to, to);
	}
	else {
		sem->to[0] = 0;
	}

	sem->type = type;
	strcpy(&sem->message[0], buffer);
	sem->messagesize = strlen(buffer);

	if (sem->to[0] != 0) {
		ZoneServer* zs = zoneserver_list.FindByName(sem->to);
		if (zs == 0)
			zoneserver_list.SendPacket(pack);
		else
			zs->SendPacket(pack);
	}
	else
		zoneserver_list.SendPacket(pack);
}

void ZSList::ClientRemove(char* name, char* zone) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->zone(), zone) == 0) {
			if (name == 0)
				iterator.RemoveCurrent();
			else if (name[0] == 0)
				iterator.RemoveCurrent();
			else if (strcasecmp(iterator.GetData()->name(), name) == 0) {
				iterator.RemoveCurrent();
				return;
			}
		}
		iterator.Advance();
	}
}

void ZSList::ClientUpdate(char* name, int32 accountid, char* accountname, int8 admin, char* zone, int8 level, int8 class_, int8 race) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (strcasecmp(iterator.GetData()->name(), name) == 0) {
			iterator.GetData()->Update(name, accountid, accountname, admin, zone, level, class_, race);
			return;
		}
		iterator.Advance();
	}
	ClientListEntry* tmp = new ClientListEntry(name, accountid, accountname, admin, zone, level, class_, race);
	clientlist.Insert(tmp);
}

void ZSList::SendWhoAll(char* to, int8 admin) {
	LinkedListIterator<ClientListEntry*> iterator(clientlist);

	iterator.Reset();
	char tmp[15];
	int32 x = 0;
	zoneserver_list.SendEmoteMessage(to, 10, "Players on server:");
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->Admin() == 1)
			strcpy(tmp, "*GM* ");
		else if (iterator.GetData()->Admin() == 2)
			strcpy(tmp, "*ServerOP* ");
		else
			strcpy(tmp, "");
		if (admin >= 1)
			zoneserver_list.SendEmoteMessage(to, 10, "%s[%i %s] %s (%s) zone: %s AccID: %i AccName: %s", tmp, iterator.GetData()->level(), GetClassName(iterator.GetData()->class_()), iterator.GetData()->name(), GetRaceName(iterator.GetData()->race()), iterator.GetData()->zone(), iterator.GetData()->AccountID(), iterator.GetData()->AccountName());
		else
			zoneserver_list.SendEmoteMessage(to, 10, "%s[%i %s] %s (%s) zone: %s", tmp, iterator.GetData()->level(), GetClassName(iterator.GetData()->class_()), iterator.GetData()->name(), GetRaceName(iterator.GetData()->race()), iterator.GetData()->zone());
		x++;
		iterator.Advance();
	}
	zoneserver_list.SendEmoteMessage(to, 10, "%i players online", x);
}

ServerPacket* CopyPacket(ServerPacket* pack) {
	ServerPacket *pack2 = new ServerPacket;
	pack2->opcode = pack->opcode;
	pack2->pBuffer = new uchar[pack->size];
	memcpy(pack2->pBuffer, pack->pBuffer, pack->size);
	pack2->size = pack->size;
	return pack2;
}

void ZoneServerLoop(void *tmp) {
	while(!ShutdownLoops) {
		ListenNewZoneServer();
		#ifdef BUILD_FOR_WINDOWS
			if (numzones==0) {
				Sleep(50);
				continue;
			}
		#endif
		zoneserver_list.Process();
		#ifdef BUILD_FOR_WINDOWS
			Sleep(1);
		#endif
	}
}

bool InitZoneServer()
{
	SOCKADDR_IN address;
	int reuse_addr = 1;
	unsigned long nonblocking = 1;
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;

	WSAStartup (version, &wsadata);
		

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up TCP port for new zoneservers */
	listening_socketZS = socket(AF_INET, SOCK_STREAM, 0);
	if (listening_socketZS == INVALID_SOCKET) 
 	{
	
		return false;
	}

	setsockopt(listening_socketZS, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse_addr, sizeof(reuse_addr));

	if (bind(listening_socketZS, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
		closesocket (listening_socketZS);
		return false;
	}

	#ifdef BUILD_FOR_WINDOWS
		ioctlsocket (listening_socketZS, FIONBIO, &nonblocking);
	#else
		fcntl(listening_socket, F_SETFL, O_NONBLOCK);
	#endif

	if (listen (listening_socketZS, SOMAXCONN) == SOCKET_ERROR) 
	{
		cout << "Listening TCP socket failed. Error: " << WSAGetLastError() << endl;
		closesocket (listening_socketZS);
		return false;
	}



	return true;
}

void ListenNewZoneServer()
{
    int		tmpsock;
    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;
    unsigned short	port;
	ZoneServer* zs;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	// Check for pending connects
	tmpsock = accept(listening_socketZS, (struct sockaddr*) &from, (int *) &fromlen);
	if (!(tmpsock == INVALID_SOCKET))
	{
//		if (bind(tmpsock, (struct sockaddr*) &from, fromlen) != 0)
//			cout << "DEBUG bind!=0" << endl;
		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		// New zoneserver connecting
		zs = new ZoneServer(in.s_addr, ntohs(from.sin_port), tmpsock);
		cout << "New zoneserver: #" << zs->GetID() << " " << inet_ntoa(in) << ":" << ntohs(port) << endl;
		zoneserver_list.Add(zs);
		numzones++;
	}
	zoneserver_list.ReceiveData();
	zoneserver_list.Process();
}
