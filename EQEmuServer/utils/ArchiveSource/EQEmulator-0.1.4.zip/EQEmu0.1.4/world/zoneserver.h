#ifndef ZONESERVER_H
#define ZONESERVER_H

#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/servertalk.h"

class ClientListEntry;

#ifdef BUILD_FOR_WINDOWS
	void ZoneServerLoop(void *tmp);
#else
	void *ZoneServerLoop(void *tmp);
#endif
bool InitZoneServer();

class ZoneServer
{
public:
	ZoneServer(int32 ip, int16 port, int send_socket);
    ~ZoneServer();
	bool SetZone(char* zonename);
	bool SetPort(int16 in_port);
	
	bool Process();
	bool ReceiveData();
	void SendPacket(ServerPacket* pack);

	char* GetZoneName() { return zone_name; }
	int32 GetIP()    { return ip; }
	int16 GetPort()  { return port; }
	int32 GetID()	 { return ID; }

private:
	int32 ip;
	int32 ID;
	int16 port;

	int send_socket;

	MyQueue<ServerPacket> ServerOutQueue;
	MyQueue<ServerPacket> ServerSendQueue;

	Timer* timeout_timer;
	
//	char char_name[16];
	char zone_name[16];
};

class ZSList
{
public:
	ZSList() { NextID = 1; }
	~ZSList() {}
	ZoneServer* FindByName(char* zonename);
	ZoneServer* FindByID(int32 ZoneID);
	
	void SendChannelMessage(char* from, char* to, int8 chan_num, int8 language, char* message, ...);
	void SendEmoteMessage(char* to, int32 type, char* message, ...);

	void ClientUpdate(char* name, int32 accountid, char* accountname, int8 admin, char* zone, int8 level, int8 class_, int8 race);
	void ClientRemove(char* name, char* zone);
	void SendWhoAll(char* to, int8 admin);
	
	void Add(ZoneServer* zoneserver);
	void Process();
	void ReceiveData();
	void SendPacket(ServerPacket* pack);
	void SendZoneStatus(char* to, int8 admin);
	int32 GetNextID() { return NextID++; }
private:
	int32 NextID;
	LinkedList<ZoneServer*> list;
	LinkedList<ClientListEntry*> clientlist;
};

class ClientListEntry
{
public:
	ClientListEntry(char* in_name, int32 in_accountid, char* in_accountname, int8 in_admin, char* in_zone, int8 level, int8 class_, int8 race) {
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
	}
	~ClientListEntry() {}
	void Update(char* in_name, int32 in_accountid, char* in_accountname, int8 in_admin, char* in_zone, int8 level, int8 class_, int8 race) {
		strcpy(pname, in_name);
		paccountid = in_accountid;
		strcpy(paccountname, in_accountname);
		padmin = in_admin;
		strcpy(pzone, in_zone);
		plevel = level;
		pclass_ = class_;
		prace = race;
	}
	char* name() { return pname; }
	char* zone() { return pzone; }
	char* AccountName() { return paccountname; }
	int32 AccountID() { return paccountid; }
	int8 Admin() { return padmin; }
	int8 level() { return plevel; }
	int8 class_() { return pclass_; }
	int8 race() { return prace; }
private:
	char pzone[30];
	int8 padmin;
	char pname[30];
	int32 paccountid;
	char paccountname[30];
	int8 plevel;
	int8 pclass_;
	int8 prace;
};
#endif
