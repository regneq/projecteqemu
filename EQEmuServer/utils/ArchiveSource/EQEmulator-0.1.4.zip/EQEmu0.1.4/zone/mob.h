#ifndef MOB_H
#define MOB_H

#include "../common/EQPacketManager.h"
#include "entity.h"

class Mob : public Entity
{
public:
	Mob(char*   in_name,
	    char*   in_lastname,
	    sint16  in_cur_hp,
	    sint16  in_max_hp,
	    int8    in_gender,
	    int8    in_race,
	    int8    in_class,
	    int8    in_deity,
	    int8    in_level,

	    int8   in_heading,
	    sint16   in_x_pos,
	    sint16   in_y_pos,
	    sint16   in_z_pos,

	    int8    in_light,
	    int8*   in_equipment);
	int16 GetHP() { return cur_hp; }
	float DistNoRootNoZ(Mob*); 
	
	virtual ~Mob();

	virtual bool IsMob() { return true; }

	virtual void SetLevel(uint16 in_level) { level = in_level; }

	virtual void Attack(Mob* other) {}
	virtual void Damage(Mob* from, int32 damage, int16 spell_id)  {}
	virtual void Heal(Mob* from, int32 damage, int16 spell_id)  {}
	virtual void Death(Mob* killer, int32 damage, int16 spell_id) {}

	void SendPosUpdate();
	void CreateDespawnPacket(APPLAYER* app);
    void CreateSpawnPacket(APPLAYER* app);
	void CreateHPPacket(APPLAYER* app);

	int8 GetLevel()   { return level; }
	char* GetName()   { return name; }
	int8 GetHPRatio() { return (int8)((float)cur_hp/max_hp*100); }
	Mob* GetTarget()  { return target; }
	void SetTarget(Mob* mob) { target = mob; }


	float Dist(Mob*);
	float DistNoRoot(Mob*);

	sint16 GetX() { return x_pos; }
	sint16 GetY() { return y_pos; }
	sint16 GetZ() { return z_pos; }

protected:
	char    name[30];
	char    lastname[20];

	sint16  cur_hp;
	sint16  max_hp;

	int8    gender;
	int8    race;
	int8    class_;
	int8    deity;
	int8    level;

	sint8   heading;
	sint8   delta_heading;
	sint16  x_pos;
	sint16  y_pos;
	sint16  z_pos;
//	sint8   delta_x;
//	sint8   delta_y;
//	sint8   delta_z;
    sint32 delta_y:10,
           spacer1:1,
           delta_z:10,
           spacer2:1,
           delta_x:10;


	int8    light;
	int8    equipment[9];

	int8    appearance; // 0 standing, 1 sitting, 2 ducking

	bool	corpse;

	Mob*    target;
	Timer*  attack_timer;
	Timer*  regen_timer;
};

#endif

