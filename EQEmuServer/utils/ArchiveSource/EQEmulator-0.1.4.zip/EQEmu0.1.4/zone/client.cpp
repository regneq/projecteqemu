#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
// Disgrace: for windows compile
#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#include <winsock.h>
	#include <process.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
#endif

#include "worldserver.h"
#include "net.h"
#include "skills.h"
#include "client.h"
#include "../common/database.h"

extern WorldServer* worldserver;
extern Database database; 

void seperation(char string[], char sep[], int ammount, int line); 

struct login 
{ 
char line[266]; 
}; 

struct login process[666]; 
char *token; 

void seperation(char string[], char sep[], int ammount, int line) 
{ 
	int total = 0; 

	token = strtok(string,sep); 
	sprintf(process[line].line,"%s",token); 
	while(token != NULL && total <= ammount) 
	{ 
		total += 1; 
		/* While there are tokens in "string" */ 
		/* Get next token: */ 
		token = strtok(NULL,sep); 
		sprintf(process[line].line,"%s",token); 
	} 
} 

Client::Client(int32 in_ip, int16 in_port, int in_send_socket)
 : Mob("No name","",0,0,0,0,0,0,0,0,0,0,0,0,0)
{
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	client_state = CLIENT_CONNECTING1;
	timeout_timer = new Timer(CLIENT_TIMEOUT);
	timeout_timer->Start();
	account_id = 0;
	admin = 0;
	strcpy(account_name, "");
	packet_manager.SetDebugLevel(0);

	target = 0;
	auto_attack = false;
}

Client::~Client()
{
	UpdateWho(true);
	Save(); // This fails when database destructor is called first on shutdown
}

bool Client::Save()
{
	if (Connected())
	{
		pp.x = x_pos;
		pp.y = y_pos;
		pp.z = z_pos/10; // Pyro: Fixed Z save bug
		pp.heading = heading;
		if (!database.SetPlayerProfile(account_id, name, &pp))
		{	
			cerr << "Failed to update player profile" << endl;
			#ifdef BUILD_FOR_WINDOWS
				return false;
			#else
				//	return false;
			#endif
		}
	}
	#ifdef BUILD_FOR_WINDOWS
	  return true;
	#endif
}

void Client::ReceiveData(uchar* buf, int len)
{
	timeout_timer->Start();
	packet_manager.ParceEQPacket(len, buf);
}

void Client::ChannelMessageReceived(int8 chan_num, int8 language, char* message, char* targetname) 
{
	cout << "Channel:" << (int)chan_num << " " << message << endl;

	if (message[0] == '#')
	{
		char* arg1 = strchr(message, ' ');

		if (strncasecmp(message, "#level", 5) == 0 && (admin == 2 || admin == 1))
		{
			if (target == 0)
			{
				Message(0, "Error: #Level: No target");
			}
			else if (arg1 == 0)
			{
				Message(0, "Usage: #level x");
			}
			else
			{
				int16 level = atoi(arg1);
				if (level > 0 && level <= 75)
				{
					target->SetLevel(level);
				}
				else
				{
					Message(0, "Error: #Level: Invalid Level");
				}
			}
		}
		else if (strncasecmp(message, "#damage",6) == 0 && (admin == 2 || admin == 1)) {
			if (target==0) {
				Message(0, "Error: #Damage: No Target.");
			}
			else if (arg1==0) {
				Message(0, "Usage: #damage x.");		
			}else{
			int16 nkdmg =atoi(arg1);
			target->Damage(this,nkdmg,0xffff);
			}
		}
		else if (strncasecmp(message, "#heal",4) == 0 && (admin == 2 || admin == 1)) {
			if (target==0) {
				Message(0, "Error: #Heal: No Target.");
			} else {
				target->Heal(this,0,0xffff);
			}
		}
		else if (strcasecmp(message, "#kill") == 0 && (admin == 2 || admin == 1)) {
			if (target==0) {
				Message(0, "Error: #Kill: No target.");
			} else {
				target->Death(this,32000,0xffff);
			}
		}
		else if(strncasecmp(message,"#rain",4) == 0 && (admin == 2 || admin == 1)) {
				char messagebackup[500]; sprintf(messagebackup,"%s",message); 
				seperation(message, " ", 0, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 1, 2); char arg3[500]; sprintf(arg3,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
			if(arg1 == 0 || arg2 == 0)
			{
				Message(0, "Usage: #rain <0/1>. (0 = Off, 1 = On)");
			}
			else
			{
			if(atoi(arg2) == 1)
			{
			Message(0, "Rain is being turned on.");
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Unknown
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x31; // rain
					entity_list.QueueClients(this, outapp);
					delete outapp;
			int weather = 0;
			weather = database.SetZoneWeather(zone->GetShortName(),arg2);
			if(weather == 0)
			{
			Message(0, "Unable to update weather on database.");
			}
			}
			if(atoi(arg2) == 0)
			{
			Message(0, "Rain is being turned off.");
						APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Rain opcode
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x00; // rain
					entity_list.QueueClients(this, outapp);
			int weather = 0;
			weather = database.SetZoneWeather(zone->GetShortName(),arg2);
			if(weather == 0)
			{
			Message(0, "Unable to update weather on database.");
			}
			}
			}
			}		
			/*else if(strncasecmp(message,"#rain",4) == 0 && (admin == 2 || admin == 1)) {
				char messagebackup[500]; sprintf(messagebackup,"%s",message); 
				seperation(message, " ", 0, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 1, 2); char arg3[500]; sprintf(arg3,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
			if(arg1 == 0 || arg2 == 0 || arg3 == 0)
			{
				Message(0, "Usage: #rain <zonename> <0/1>. (0 = Off, 1 = On)");
			}
			else
			{
			if(atoi(arg3) == 1)
			{
			Message(0, "Rain is being turned on.");
					APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Unknown
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x31; // rain
					entity_list.QueueClients(this, outapp);
					delete outapp;
			int weather = 0;
			weather = database.SetZoneWeather(arg2,arg3);
			if(weather == 0)
			{
			Message(0, "Unable to update weather on database.");
			}
			}
			if(atoi(arg3) == 0)
			{
			Message(0, "Rain is being turned off.");
						APPLAYER* outapp = new APPLAYER;
					outapp = new APPLAYER;
					outapp->opcode = 0x3621; // Rain opcode
					outapp->pBuffer = new uchar[8];
					memset(outapp->pBuffer, 0, 8);
		   			outapp->size = 8;
					outapp->pBuffer[6] = 0x00; // rain
					entity_list.QueueClients(this, outapp);
			int weather = 0;
			weather = database.SetZoneWeather(arg2,arg3);
			if(weather == 0)
			{
			Message(0, "Unable to update weather on database.");
			}
			}
			}
			}*/
		else if (strcasecmp(message, "#shutdown")==0 && admin == 2)
		{
			CatchSignal(2);
		}
		else if (strcasecmp(message, "#help") ==0)
		{
			Message(0, "FreeQuest(tm) Commands:");
			Message(0, "  #itemsearch [id]    searches item database");
			Message(0, "  #summonitem [id]    summon item");
			Message(0, "  #goto  [x,y,z]    warps you to coords");
			Message(0, "  #zone [zonename] - zones to 0, 0, 10 in zonename");
			Message(0, "  #zonestatus - shows what zones are up");
			if(admin == 1 || admin == 2)
			{
				Message(0, "FreeQuest(tm) GM Commands:");
				Message(0, "  #level [id]   sets target level.");
				Message(0, "  #damage [id]   inflicts damage upon target.");
				Message(0, "  #heal   (PC ONLY) completely heals target");
				Message(0, "  #kill   (NPC ONLY) kills your selected target");
				Message(0, "  #spawn   lets you spawn a creature");
				Message(0, "  #setxp   sets target exp");
				Message(0, "  #emote   sends emotish message, type for syntax");
				Message(0, "  #summon [charname] - summons a player to you");
				Message(0, "  #kick [charname] - kicks the charname off the server");
			}
			if(admin == 2)
			{
				Message(0, "FreeQuest(tm) GM Admin Commands:");
				Message(0, "  #shutdown   shuts down the server.");
				Message(0, "  #worldshutdown   shuts down the worldserver and all zones");
				Message(0, "  #createacct [name] [password] [status]   creates a Everquest account.");
				Message(0, "  #delacct [name]   deletes a FreeQuest account.");
				Message(0, "  #zoneshutdown [ZoneID | ZoneName] - shuts down the zoneserver");
				Message(0, "  #zonebootup [ZoneID] [ZoneName] - boots ZoneName on the zoneserver specified");
			}
		}
		else if (strncasecmp(message, "#setxp",5) == 0 && (admin == 2 || admin == 1))
		{
			if (arg1 != 0) {
				AddEXP (atoi(arg1));
				//ChannelMessageSend(0, 0, 7, 0, "Added XP.");
			}
		}
		else if (strncasecmp(message, "#summonitem", 11) == 0)
		{
			if (arg1 == 0)
			{
				Message(0, "Usage: #summonitem x , x is an item number");
			} else	{
				uint16 item_id = atoi(arg1);
				Item_Struct* item = zone->GetItem(item_id);
				if (item == 0)
				{
					Message(0, "No such item:%i",item_id);
				} else {
					item->equipSlot = 0;
					APPLAYER* app = new APPLAYER;
					app->opcode = OP_SummonedItem;
					app->size = sizeof(SummonedItem_Struct);
					app->pBuffer = new uchar[app->size];
					memcpy(app->pBuffer, item, sizeof(Item_Struct));
					packet_manager.MakeEQPacket(app);
					delete app;
				}
			}
		}
		else if (strncasecmp(message, "#itemsearch", 11) == 0)
		{
			if (arg1 == 0)
			{
				Message(0, "Format: #itemsearch item");
			} else {
				MYSQL_RES *res_set;
				MYSQL_ROW row;
				unsigned int i, numresults = 0;
				char query[1024];

				++arg1;
				sprintf(query, "SELECT * FROM items WHERE raw_data LIKE \"%c%s%c\"", 37, arg1, 37);
				mysql_query(&database.mysql, query);
				res_set = mysql_store_result(&database.mysql);
				Message(0, "Searching for %s:", arg1);
				while ((row = mysql_fetch_row(res_set)) != NULL && numresults <= 19)
				{
					ChannelMessageSend(0,0,7,0, "%s: %s", row[0], row[1]);
					//Message(0, "%s: %s", row[0], row[1]);
					++numresults;
				}
				Message(0, "Search complete, found %d result(s)", numresults);
				if(numresults == 20)
				{
					Message(0, "Search complete, found too many items, be more specific: limited to %d results", numresults);
				}
			}
		}
		else if (strncasecmp(message, "#spawn",5) == 0 && (admin == 2 || admin == 1)) // Image's Spawn Code
		{
			cout << "Spawning:" << endl; 
			//Well it needs a name!!! 
			if(arg1 == 0) 
			{ 
				Message(0, "Format: #spawn firstname lastname(put (null) for no last name) race gender class level hp weaponnumber: spawns a npc those parameters."); 
			} 
			else 
			{ 
				char messagebackup[500]; sprintf(messagebackup,"%s",message); 

				//Gotta do seperation, ouch!! messy :)
				seperation(message, " ", 0, 2); char fname[500]; sprintf(fname,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 1, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 2, 3); char arg3[500]; sprintf(arg3,"%s",process[3].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 3, 3); char arg4[500]; sprintf(arg4,"%s",process[3].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 4, 4); char arg5[500]; sprintf(arg5,"%s",process[4].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 5, 4); char arg6[500]; sprintf(arg6,"%s",process[4].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 6, 4); char arg7[500]; sprintf(arg7,"%s",process[4].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 7, 4); char arg8[500]; sprintf(arg8,"%s",process[4].line); sprintf(message,"%s",messagebackup); 

				//Lets see if someone didn't fill out the whole #spawn function properly 
				if(!strcmp(arg2,"(null)")) 
				{ 
					sprintf(arg2,""); 
				} 
				if(!strcmp(arg3,"(null)")) 
				{ 
					sprintf(arg3,"1"); 
				} 
				if(!strcmp(arg4,"(null)")) 
				{ 
					sprintf(arg4,"1"); 
				} 
				if(!strcmp(arg5,"(null)")) 
				{ 
					sprintf(arg5,"1"); 
				} 
				if(!strcmp(arg6,"(null)")) 
				{ 
					sprintf(arg6,"1"); 
				} 
				if(!strcmp(arg7,"(null)")) 
				{ 
					sprintf(arg7,"100"); 
				} 
				if(!strcmp(arg8,"(null)")) 
				{ 
					sprintf(arg8,"0"); 
				} 
				char fullname[500]; 
				sprintf(fullname,"%s %s",fname,arg2); 

				// Well we want everyone to know what they spawned, right? 
				Message(0, "New spawn:"); 
				Message(0, "  First Name: %s",fname); 
				Message(0, "  Last Name: %s",arg2); 
				Message(0, "  Race: %s",arg3); 
				Message(0, "  Gender: %s",arg4); 
				Message(0, "  Class: %s",arg5); 
				Message(0, "  Level: %s",arg6); 
				Message(0, "  Current/Max HP: %s",arg7); 
				Message(0, "  Weapon Item Number: %s",arg8); 
		
				//Time to create the NPC!! 
				NPCType npc_type; 
				strcpy(npc_type.name,fullname); 
				strcpy(npc_type.lastname,arg2); 
				npc_type.cur_hp = atoi(arg7); 
				npc_type.max_hp = atoi(arg7); 
				npc_type.race = atoi(arg3); 
				npc_type.gender = atoi(arg4); 
				npc_type.class_ = atoi(arg5); 
				npc_type.deity= 1; 
				npc_type.level = atoi(arg6); 
				npc_type.light = 0; 
				for (int i=0; i<9; i++) 
				npc_type.equipment[i] = atoi(arg8); 
				entity_list.AddNPC(new NPC(&npc_type, 0, x_pos, y_pos, z_pos, heading)); 
				//What the hell lets send a position update!
				SendPosUpdate();
			}
		}
		else if (strncasecmp(message, "#createacct", 10) == 0 && admin == 2)
		{
			if(arg1 == 0)
			{
				Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
			} else {
				char messagebackup[500]; sprintf(messagebackup,"%s",message); 

				seperation(message, " ", 0, 2); char name[500]; sprintf(name,"%s",process[2].line); sprintf(message,"%s",messagebackup);
				seperation(message, " ", 1, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup);
				seperation(message, " ", 2, 3); char arg3[500]; sprintf(arg3,"%s",process[3].line); sprintf(message,"%s",messagebackup);
				seperation(message, " ", 3, 4); char arg4[500]; sprintf(arg4,"%s",process[4].line); sprintf(message,"%s",messagebackup);
				if(!strcmp(arg2,"(null)"))
				{
					Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
					return;
				}
				if(!strcmp(arg3,"(null)")) 
				{
					Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
					return;
				}
				if(!strcmp(arg4,"(null)"))
				{
					int create = 0;
					create = database.CreateAccount(name,arg2,arg3);
					if(create == 0)
					{
						Message(0, "Unable to create account.");
					} else {
						Message(0, "The account was created.");
					}
				} else {
					Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
					return;
				}
			}
		}
		else if (strncasecmp(message, "#delacct",7) == 0 && admin == 2)
		{
			if(arg1 == 0)
			{
				Message(0, "Format: #delacct accountname");
			} else {
				char messagebackup[500]; sprintf(messagebackup,"%s",message);
				seperation(message, " ", 0, 2); char name[500]; sprintf(name,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				seperation(message, " ", 1, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup); 
				if(!strcmp(name,"(null)"))
				{
					Message(0, "Format: #createacct accountname accountpassword accountstatus(no spaces) (Account Status: 0 = Normal, 1 = GM, 2 = Lead GM)");
					return;
				}
				if(!strcmp(arg2,"(null)"))
				{
					int del = 0;
					del = database.DeleteAccount(name);
					if(del == 0)
					{
						Message(0, "Unable to delete account.");
					} else {
						Message(0, "The account was deleted."); 
					}
				} else {
					Message(0, "Format: #delacct accountname");
					return;
				}
			}
		}
		else if (strcasecmp(message, "#loc") == 0)
		{
			Message(0, "Current Location: %d, %d, %d",x_pos,y_pos,z_pos/10);
		}
		else if (strncasecmp(message, "#size", 5) == 0 && (admin >= 1))	{
			if (arg1 == 0)
				Message(0, "Usage: #size [1 - 50]");
			else {
				APPLAYER* outapp = new APPLAYER;
				outapp->opcode = OP_SpawnAppearance;
				outapp->size = sizeof(SpawnAppearance2_Struct);
				outapp->pBuffer = new uchar[outapp->size];

				SpawnAppearance2_Struct* appearance = (SpawnAppearance2_Struct*)outapp->pBuffer;
				if (target)
					appearance->spawn_id = target->GetID();
				else
					appearance->spawn_id = id;
				appearance->parameter = atoi(arg1);
				appearance->type = 29;
				entity_list.QueueClients(this, outapp, false);
//				packet_manager.MakeEQPacket(outapp);  
				delete outapp;

				cout << "Changed size to: " << atoi(arg1) << endl;
			}
		}

		else if (strncasecmp(message, "#goto", 5) == 0) // Pyro's goto function
		{
				if (arg1 == 0)
				{
					Message(0, "Usage: #goto [x y z].");
				} else {
					char messagebackup[20];
					sprintf(messagebackup,"%s",message);
					seperation(message, " ", 0, 2); char x[20]; sprintf(x,"%s",process[2].line); sprintf(message,"%s",messagebackup);
					seperation(message, " ", 1, 2); char y[20]; sprintf(y,"%s",process[2].line); sprintf(message,"%s",messagebackup);
					seperation(message, " ", 2, 3); char z[20]; sprintf(z,"%s",process[3].line); sprintf(message,"%s",messagebackup);

					MovePC(atoi(x),atoi(y),atoi(z));
				}
		}
		else if (strcasecmp(message, "#worldshutdown") == 0 && admin == 2) {
		// GM command to shutdown world server and all zone servers
			if (worldserver != 0) {
				Message(0, "Sending shutdown packet");
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ShutdownAll;
				pack->size=0;
				worldserver->SendPacket(pack);
			}
			else
				Message(0, "Error: World server disconnected");
		}
		else if (strcasecmp(message, "#connectworldserver") == 0 && admin == 2) {
		// GM command to reconnect to worldserver if connection is lost
#ifdef BUILD_FOR_WINDOWS
			_beginthread(ClientInitWorldServer, 0, this);
#else
			pthread_t thread;
			pthread_create(&thread, NULL, ClientInitWorldServer, this).
#endif
		}
		else if (strncasecmp(message, "#chat", 5) == 0 && admin == 2) {
			// sends any channel message to all zoneservers
			// could use for worldwide shout or whatever =p
			char* arg2 = 0;
			if (!(arg1 == 0))
				arg2 = strchr((arg1+1), ' ');
			if (arg1 == 0 || arg2 == 0) {
				Message(0, "Format: #chat channum message");
			}
			else {
				uint16 channelnum = atoi(arg1);
				arg2++;
				if (worldserver != 0)
					worldserver->SendChannelMessage(0, 0, (uint8) channelnum, 0, arg2);
				else
					Message(0, "Error: World server disconnected");
			}

		}
		else if (strncasecmp(message, "#zoneshutdown", 13) == 0 && admin == 2) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else if (arg1 == 0) {
				Message(0, "Usage: #zoneshutdown zoneshortname");
			} else {
				arg1++;
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneShutdown;
				strcpy(s->adminname, this->GetName());
				if (arg1[0] >= '0' && arg1[0] <= '9')
					s->ZoneServerID = atoi(arg1);
				else
					strcpy(s->zonename, arg1);
				worldserver->SendPacket(pack);
			}
		}
		else if (strncasecmp(message, "#zonebootup", 11) == 0 && admin == 2) {
			char* arg2 = strchr(arg1+1, ' ') + 1;
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else if (arg1 == 0 || arg2 == 0) {
				Message(0, "Usage: #zonebootup ZoneServerID# zoneshortname");
			} else {
				arg1++;
				ServerPacket* pack = new ServerPacket;
				pack->size = sizeof(ServerZoneStateChange_struct);
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
				ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
				pack->opcode = ServerOP_ZoneBootup;
				s->ZoneServerID = atoi(arg1);
				strcpy(s->adminname, this->GetName());
				strcpy(s->zonename, arg2);
				worldserver->SendPacket(pack);
			}
		}
		else if (strcasecmp(message, "#zonestatus") == 0) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				pack->opcode = ServerOP_ZoneStatus;
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char *) &pack->pBuffer[1], this->GetName());
				worldserver->SendPacket(pack);
			}
		}
		else if (strncasecmp(message, "#emote", 6) == 0 && (admin == 2 || admin == 1)) {
			if (arg1 == 0)
				Message(0, "Usage: #emote [name | world | zone] type# message");
			else {
				char messagebackup[500]; sprintf(messagebackup,"%s",message); 
				seperation(message, " ", 0, 2); char to[500]; sprintf(to,"%s",process[2].line); sprintf(message,"%s",messagebackup);
				seperation(message, " ", 1, 2); char arg2[500]; sprintf(arg2,"%s",process[2].line); sprintf(message,"%s",messagebackup);
				char *emote = strchr(arg1+1+strlen(to)+1+strlen(arg2), ' ');
				if (emote != 0) {
					while (emote[0] == ' ')
						emote++;
					if (emote[0] == 0)
						emote = 0;
				}
				if (!strcmp(to, "(null)") || !(arg2[0] >= '0' && arg2[0] <= '9') || emote == 0)
					Message(0, "Usage: #emote [name | world | zone] type# message");
				else {
					if (strcasecmp(to, "zone") == 0)
						entity_list.Message(atoi(arg2), emote);
					else if (worldserver == 0)
						Message(0, "Error: World server disconnected");
					else if (strcasecmp(to, "world") == 0)
						worldserver->SendEmoteMessage(0, atoi(arg2), emote);
					else
						worldserver->SendEmoteMessage(to, atoi(arg2), emote);
				}
			}
		}
// Pyro - Implemented /who all
		/*		else if (strcasecmp(message, "#who") == 0) {
			if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_Who;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char*) &pack->pBuffer[1], this->GetName());
				worldserver->SendPacket(pack);
			}
		}*/
		else if (strncasecmp(message, "#zone", 5) == 0) {
			if (arg1 == 0)
				Message(0, "Usage: #zone [zonename]");
			else if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				arg1++;
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_ZonePlayer;
				pack->size = sizeof(ServerZonePlayer_Struct);
				pack->pBuffer = new uchar[pack->size];
				ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
				strcpy(szp->adminname, this->GetName());
				strcpy(szp->name, this->GetName());
				strcpy(szp->zone, arg1);
				szp->x_pos = 0;
				szp->y_pos = 0;
				szp->z_pos = 10;
				worldserver->SendPacket(pack);
			}
		}
		else if (strncasecmp(message, "#summon", 7) == 0 && (admin >= 1)) {
			if (arg1 == 0)
				Message(0, "Usage: #summon [charname]");
			else {
				arg1++;
				Client* client = entity_list.GetClientByName(arg1);
				if (client != 0) {
					client->Message(15, "You have been summoned by the gods!");
					this->Message(0, "Summoning %s to *samezone* %i, %i, %i", arg1, this->x_pos, this->y_pos, this->z_pos+5);
					client->MovePC(this->x_pos, this->y_pos, this->z_pos+5);
				}
				else if (worldserver == 0)
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_ZonePlayer;
					pack->size = sizeof(ServerZonePlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
					strcpy(szp->adminname, this->GetName());
					strcpy(szp->name, arg1);
					strcpy(szp->zone, zone->GetShortName());
					szp->x_pos = this->x_pos;
					szp->y_pos = this->y_pos;
					szp->z_pos = this->z_pos+5;
					worldserver->SendPacket(pack);
				}
			}
		}
		else if (strncasecmp(message, "#kick", 5) == 0 && (admin >= 1)) {
			if (arg1 == 0)
				Message(0, "Usage: #kick [charname]");
			else {
				arg1++;
				Client* client = entity_list.GetClientByName(arg1);
				if (client != 0) {
					client->Kick();
					this->Message(0, "Kick: local: kicing %s", arg1);
				}
				else if (worldserver == 0)
					Message(0, "Error: World server disconnected");
				else {
					ServerPacket* pack = new ServerPacket;
					pack->opcode = ServerOP_KickPlayer;
					pack->size = sizeof(ServerKickPlayer_Struct);
					pack->pBuffer = new uchar[pack->size];
					ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
					strcpy(skp->adminname, this->GetName());
					strcpy(skp->name, arg1);
					worldserver->SendPacket(pack);
				}
			}
		}
		else {
			Message(0, "Command does not exist");
		}
	} else {
		if (chan_num == 3 || chan_num == 4 || chan_num == 5 || chan_num == 8) // Shout, auction, ooc, say
		{
			entity_list.ChannelMessage(this, chan_num, language, message);
		} else if (chan_num == 7 && strcasecmp(targetname, "Broadcast") == 0) {
			// Cant get GM flag clientside for /broadcast
			// This is a workaround so you can use "/tell broadcast"
			if (worldserver == 0)
				Message(0, "Error: World server dirconnected");
			else if (!(admin == 2 || admin == 1))
				Message(0, "Error: Only GMs can use broadcast");
			else {
				char tmpName[23];
				tmpName[0] = ' '; // add a space before your name so you can see your own /broad
				strcpy(&tmpName[1], this->GetName());
				worldserver->SendChannelMessage(tmpName, 0, 6, language, message);
			}
		}
		else if (chan_num == 0 || chan_num == 6 || chan_num == 7) {
			if (worldserver != 0)
				worldserver->SendChannelMessage(this->GetName(), targetname, chan_num, language, message);
			else
				Message(0, "Error: World server dirconnected");
		}
		else {
			Message(0, "Channel not implemented");
        } 

	}
}

void Client::ChannelMessageSend(char* from, char* to, int8 chan_num, int8 language, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER app;

	app.opcode = OP_ChannelMessage;
	app.size = sizeof(ChannelMessage_Struct)+strlen(buffer)+1;
	app.pBuffer = new uchar[app.size];
memset(app.pBuffer, 0, app.size);
	ChannelMessage_Struct* cm = (ChannelMessage_Struct*) app.pBuffer;
	if (from == 0)
		strcpy(cm->sender, "ZServer");
	else if (from[0] == 0)
		strcpy(cm->sender, "ZServer");
	else
		strcpy(cm->sender, from);
	if (to != 0)
		strcpy((char *) cm->targetname, to);
	else
		cm->targetname[0] = 0;
	cm->language = language;
	cm->chan_num = chan_num;
//cm->cm_unknown4[0] = 0xff;
cm->cm_unknown4[1] = 0xff; // One of these tells the client how well we know the language
cm->cm_unknown4[2] = 0xff;
cm->cm_unknown4[3] = 0xff;
cm->cm_unknown4[4] = 0xff;
	strcpy(&cm->message[0], buffer);

	if (chan_num == 7 && from != 0) 
	{ 
		strcpy(cm->targetname, pp.name); 
	} 
	packet_manager.MakeEQPacket(&app);
}

void Client::Message(int32 type, char* message, ...)
{
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	APPLAYER* app = new APPLAYER;
	app->opcode = OP_SpecialMesg;
	app->size = 4+strlen(buffer)+1;
	app->pBuffer = new uchar[app->size];
	SpecialMesg_Struct* sm=(SpecialMesg_Struct*)app->pBuffer;
	sm->msg_type = type;
	strcpy(sm->message, buffer);
	packet_manager.MakeEQPacket(app);
	delete app;	
}

void Client::SendHPUpdate()
{
	APPLAYER* app = new APPLAYER;
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnHPUpdate_Struct* shu = (SpawnHPUpdate_Struct*)app->pBuffer;
	shu->spawn_id = id;
	shu->shu_unknown1 = 0;
	shu->cur_hp = GetHP();
	shu->shu_unknown2 = 0;
	shu->max_hp = GetMaxHP();
	shu->shu_unknown3 = 0;

/*
	app->opcode = OP_SpawnAppearance;
	app->size = sizeof(SpawnAppearance_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
	sa->spawn_id = id;
sa->sa_unknown1 = 0;
	sa->type = 0x11;
sa->sa_unknown2 = 0xc34a;
	sa->parameter = GetHP();
*/
	packet_manager.MakeEQPacket(app);
	delete app;
}

void Client::SetMaxHP()
{
	APPLAYER* app = new APPLAYER;
	app->opcode = OP_HPUpdate;
	app->size = sizeof(SpawnHPUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	SpawnHPUpdate_Struct* shu = (SpawnHPUpdate_Struct*)app->pBuffer;
	shu->shu_unknown1 = 0;
	cur_hp = GetMaxHP();
	SetHP(GetMaxHP());
	shu->shu_unknown2 = 0;
	max_hp = GetMaxHP();
	shu->shu_unknown3 = 0;
	cur_hp = GetMaxHP();
	SendHPUpdate();
	Save();
	packet_manager.MakeEQPacket(app);
	delete app;
}

void Client::QueuePacket(APPLAYER* app)
{
	packet_manager.MakeEQPacket(app);
}

void Client::AddEXP(int32 add_exp)
{
	SetEXP(GetEXP() + add_exp);
}

void Client::SetEXP(int32 set_exp)
{
	int16 check_level = GetLevel()+1;

	while (set_exp > GetEXPForLevel(check_level))
		check_level++;

	if (GetLevel() != check_level-1)
	{
		if (GetLevel() == check_level-2)
		{
			Message(15, "You have gained a level! Welcome to level %i!", check_level-1);
		}
		else
		{
			Message(15, "Welcome to level %i!", check_level-1);
		}
		SetLevel(check_level-1);
		UpdateWho(false);
	}
	else
	{
		Message(15, "You gain experience!!");
		APPLAYER app;
		app.opcode = OP_ExpUpdate;
		app.size = sizeof(ExpUpdate_Struct);
		app.pBuffer = new uchar[app.size];
		ExpUpdate_Struct* eu = (ExpUpdate_Struct*)app.pBuffer;
		eu->exp = set_exp;
		packet_manager.MakeEQPacket(&app);		
	}

	pp.exp = set_exp;
}

void Client::MovePC(int32 move_x, int32 move_y, int32 move_z)
{
        ChannelMessageSend(0, 0, 7, 0, "Moving to location: %d, %d, %d", move_x, move_y, move_z);
        
		APPLAYER* app = new APPLAYER;
        app->opcode = OP_MobUpdate;
        app->size = sizeof(SpawnPositionUpdates_Struct) + sizeof(SpawnPositionUpdate_Struct);
        
		#ifdef BUILD_FOR_WINDOWS
			app->pBuffer = new uchar[app->size];
			SpawnPositionUpdates_Struct* spu = (SpawnPositionUpdates_Struct*)app->pBuffer;
		#else
			SpawnPositionUpdates_Struct* spu = (SpawnPositionUpdates_Struct*)app->pBuffer = new uchar[app->size];
		#endif
		

        spu->num_updates = 1;
        spu->spawn_update[0].spawn_id = id;

        spu->spawn_update[0].anim_type = 0;

        spu->spawn_update[0].heading = heading;
        spu->spawn_update[0].delta_heading = delta_heading;
        spu->spawn_update[0].x_pos = move_x;
        spu->spawn_update[0].y_pos = move_y;
        spu->spawn_update[0].z_pos = move_z;
        spu->spawn_update[0].delta_x = delta_x;
        spu->spawn_update[0].delta_y = delta_y;
        spu->spawn_update[0].delta_z = delta_z;

		packet_manager.MakeEQPacket(app);
		delete app;

        cout << name << ", warping to: " << move_x << ", " << move_y << ", " << move_z << endl;
}


void Client::SetLevel(int16 set_level)
{

	APPLAYER* app = new APPLAYER;
	app->opcode = OP_LevelUpdate;
	app->size = sizeof(LevelUpdate_Struct);
	app->pBuffer = new uchar[app->size];
	LevelUpdate_Struct* lu = (LevelUpdate_Struct*)app->pBuffer;
	lu->level = set_level;
	lu->level_old = level;
	lu->exp = GetEXPForLevel(set_level);
	packet_manager.MakeEQPacket(app);

	pp.exp = lu->exp;
	pp.level = set_level;
	level = set_level;

	cout << "Setting Level: " << GetName() << " = " << set_level << endl;

	delete app;	
	Message(15, "Welcome to level %i!", set_level);
	UpdateWho(false);

//	ChannelMessageSend(0, 0, 7, 0, "Your level changed, please check if your max hp is %i. If not do a bug report with class, level, stamina and max hp", GetMaxHP());
}
//                           hum  bar  eru  elf  hie  def  hef  dwa  tro  ogr  hal  gno
float  race_modifiers[12] =  {100, 105, 100, 100, 100, 100, 100, 100, 120, 115,  95, 100};
//                           war  cle  pal  ran  shd  dru  mnk  brd  rog  shm  nec  wiz  mag  enc
float class_modifiers[14] = {  9,  10,  14,  14,  14,  10,  12,  14, 9.05, 10,  11,  11,  11,  11};

/*
	Note: The client calculates exp separatly, we cant change this function
*/
uint32 Client::GetEXPForLevel(int16 check_level)
{
	if (GetRace() < 1 || GetRace() > 12 || GetClass() < 1 || GetClass() > 14)
		return 0;
	if (check_level < 31)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]);
	else if (check_level < 36)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.1);
	else if (check_level < 41)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.2);
	else if (check_level < 46)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.3);
	else if (check_level < 52)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.4);
	else if (check_level < 53)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.5);
	else if (check_level < 54)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.6);
	else if (check_level < 55)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.7);
	else if (check_level < 56)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*1.9);
	else if (check_level < 57)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*2.1);
	else if (check_level < 58)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*2.3);
	else if (check_level < 59)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*2.5);
	else if (check_level < 60)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*2.7);
	else if (check_level < 61)
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*3.0);
	else
		return (uint32)((check_level-1)*(check_level-1)*(check_level-1)*class_modifiers[GetClass()-1]*race_modifiers[GetRace()-1]*3.1);
}

/*
	Note: The client calculates max hp separatly, we cant change this function
*/
uint16 Client::GetMaxHP()
{
	int8 multiplier = 0;

	switch(GetClass())
	{
		case WARRIOR:
			if (GetLevel() < 20)
				multiplier = 22;
			else if (GetLevel() < 30)
				multiplier = 23;
			else if (GetLevel() < 40)
				multiplier = 25;
			else if (GetLevel() < 53)
				multiplier = 27;
			else if (GetLevel() < 57)
				multiplier = 28;
			else
				multiplier = 30;
			break;

		case CLERIC:
		case SHAMAN:
			multiplier = 15;
			break;

		case PALADIN:
		case SHADOWKNIGHT:
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				 multiplier = 22;
			else if (GetLevel() < 51)
				 multiplier = 23;
			else if (GetLevel() < 56)
				 multiplier = 24;
			else if (GetLevel() < 60)
				 multiplier = 25;
			else
				 multiplier = 26;
			break;

		case MONK:
		case BARD:
		case ROGUE:
//		case BEASTLORD:
			if (GetLevel() < 51)
				multiplier = 18;
			else if (GetLevel() < 58)
				multiplier = 19;
			else
				multiplier = 20;				
			break;

		case RANGER:
			if (GetLevel() < 58)
				multiplier = 20;
			else
				multiplier = 21;			
			break;

		case MAGICIAN:
		case WIZARD:
		case NECROMANCER:
		case ENCHANTER:
			multiplier = 12;
			break;

		default:
			cerr << "Invalid class in Client::GetMaxHP" << endl;
			if (GetLevel() < 35)
				multiplier = 21;
			else if (GetLevel() < 45)
				multiplier = 22;
			else if (GetLevel() < 51)
				multiplier = 23;
			else if (GetLevel() < 56)
				multiplier = 24;
			else if (GetLevel() < 60)
				multiplier = 25;
			break;
	}

	if (multiplier == 0)
	{
		cerr << "Multiplier == 0 in Client::GetMaxHP" << endl;
	}

//	cout << "m:" << (int)multiplier << " l:" << (int)GetLevel() << " s:" << (int)GetSTA() << endl;

	return 5+multiplier*GetLevel()+multiplier*GetLevel()*GetSTA()/300;
}

int8 Client::GetSkill(int skill_num)
{
	return pp.skills[skill_num];
}

/*
	This should return the combined AC of all the items the player is wearing.
*/
int16 Client::GetRawItemAC()
{
	return 0;
}

/*
	This is a testing formula for AC, the value this returns should be the same value as the one the client shows...
	ac1 and ac2 are probably the damage migitation and damage avoidance numbers, not sure which is which.
	I forgot to include the iksar defense bonus and i cant find my notes now...
	AC from spells are not included (cant even cast spells yet..)
*/
int16 Client::GetCombinedAC_TEST()
{
	int ac1;

	ac1 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac1 = ac1*4/3;
	}
	ac1 += GetSkill(DEFENSE)/3;
	if (GetAGI() > 70)
	{
		ac1 += GetAGI()/20;
	}

	int ac2;

	ac2 = GetRawItemAC();
	if (pp.class_ != WIZARD && pp.class_ != MAGICIAN && pp.class_ != NECROMANCER && pp.class_ != ENCHANTER)
	{
		ac2 = ac2*4/3;
	}
	ac2 += GetSkill(DEFENSE)*400/255;

	int combined_ac = (ac1+ac2)*1000/847;

	return combined_ac;
}

void Client::UpdateWho(bool remove) {
	if (worldserver == 0)
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = remove;
	strcpy(scl->name, this->GetName());
	scl->Admin = this->Admin();
	scl->AccountID = this->GetAccountID();
	strcpy(scl->AccountName, this->GetAccountName());
	strcpy(scl->zone, zone->GetShortName());
	scl->race = this->GetRace();
	scl->class_ = GetClass();
	scl->level = GetLevel();

	worldserver->SendPacket(pack);
}

void Client::ZonePC(char* zonename, sint16 x, sint16 y, sint16 z) {
	APPLAYER* outapp;
	outapp = new APPLAYER;
	outapp->opcode = 0xdb20;
	outapp->size = 0;
	packet_manager.MakeEQPacket(outapp);
	delete outapp;

	outapp = new APPLAYER;
	outapp->opcode = 0x1020;
	outapp->size = 0;
	packet_manager.MakeEQPacket(outapp);					
	delete outapp;

	outapp = new APPLAYER;
	outapp->opcode = OP_ZoneChange;
	outapp->pBuffer = new uchar[sizeof(ZoneChange_Struct)];
	outapp->size = sizeof(ZoneChange_Struct);
	memset(outapp->pBuffer, 0, sizeof(ZoneChange_Struct));
	ZoneChange_Struct *zc = (ZoneChange_Struct*)outapp->pBuffer;
	strcpy(zc->char_name, this->GetName());
	strcpy(zc->zone_name, zonename);
	pp.x = x;
	pp.y = y;
	pp.z = z;
	strcpy(pp.current_zone, zonename);
	Save();
	database.SetAuthentication(account_id, zc->char_name, zc->zone_name, ip);
	packet_manager.MakeEQPacket(outapp);
	delete outapp;

}

void Client::WhoAll() {
if (worldserver == 0)
				Message(0, "Error: World server disconnected");
			else {
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_Who;
				pack->size = strlen(this->GetName())+2;
				pack->pBuffer = new uchar[pack->size];
				memset(pack->pBuffer, 0, pack->size);
				memset(pack->pBuffer, (int8) admin, 1);
				strcpy((char*) &pack->pBuffer[1], this->GetName());
				worldserver->SendPacket(pack);
			}
}