#include "EQPacketManager.h"

#include <iostream.h>
#include <stdlib.h>

template <typename type>					// LO_BYTE
type  LO_BYTE (type a) {return (a&=0xff);}  
template <typename type>					// HI_BYTE 
type  HI_BYTE (type a) {return (a&=0xff00);} 
template <typename type>					// LO_WORD
type  LO_WORD (type a) {return (a&=0xffff);}  
template <typename type>					// HI_WORD 
type  HI_WORD (type a) {return (a&=0xffff0000);} 
template <typename type>					// HI_LOSWAPshort
type  HI_LOSWAPshort (type a) {return (LO_BYTE(a)<<8) | (HI_BYTE(a)>>8);}  
template <typename type>					// HI_LOSWAPlong
type  HI_LOSWAPlong (type x) {return (LO_WORD(a)<<16) | (HIWORD(a)>>16);}  


CEQPacketManager::CEQPacketManager()//CTimer *tim_set, int32 ddTimerID_set)
{
//	tim = tim_set;

	pm_state = PM_ACTIVE;
	resend_count = 0;
	dwTimerARQ = 0;
	dwLastCACK = 0;
	dwFragSeq  = 0;

	//Only create timers, no startup!
//	ddTimerID = ddTimerID_set;
//	tim->AddTimer(ddTimerID, TIMER_NO_ACK_RESPOND_RECEIVED, 0, 0);
//	tim->AddTimer(ddTimerID, TIMER_NO_ACK_RESPOND_SENT_SEND_PURE, 0, 0);
////	tim->AddTimer(ddTimerID, TIMER_SENDBUFF, 1, 0);
	
	no_ack_received_timer = new Timer(3500);//0);
	no_ack_sent_timer = new Timer(3500);//0);

	no_ack_received_timer->Disable();
	no_ack_sent_timer->Disable();

	debug_level = 0;
}

CEQPacketManager::~CEQPacketManager()
{
}
/**************************************************************************************/

/************ PARCE A EQPACKET ************/
void CEQPacketManager::ParceEQPacket(int16 dwSize, uchar* pPacket)
{
	if(pm_state != PM_ACTIVE)
		return;
	
//	APPLAYER *app = new APPLAYER;	
	
	/************ DECODE PACKET ************/
	CEQPacket* pack = new CEQPacket;
	pack->DecodePacket(dwSize, pPacket);
	if (ProcessPacket(pack, false))
	{
		delete pack;
	}
	CheckBufferedPackets();
}

/*
	Return true if its safe to delete this packet now, if we buffer it return false
	this way i can skip memcpy the packet when buffering it
*/
bool CEQPacketManager::ProcessPacket(CEQPacket* pack, bool from_buffer=false)
{
	/************ CHECK FOR ACK/SEQ RESET ************/ 
	if(pack->HDR.a5_SEQStart)
	{
		//cout << "resetting SACK.dwGSQ1" << endl;
		//		SACK.dwGSQ		= 0;			//Main sequence number SHORT#2
		dwLastCACK		= pack->dwARQ-1;//0;
		//		CACK.dwGSQ = 0xFFFF; changed next if to else instead
	}
	// Agz: Moved this, was under packet resend before..., later changed to else statement...
	else if( (pack->dwSEQ - CACK.dwGSQ) <= 0 && !from_buffer)  // Agz: if from the buffer i ignore sequence number..
	{
		if (debug_level >= 2)
		{
			cout << Timer::GetCurrentTime() << " ";
			cout << "Invalid packet ";
			cout << "pack->dwSEQ:" << pack->dwSEQ << " ";
			cout << "CACK.dwGSQ;" << CACK.dwGSQ << endl;
		}
		return true; //Invalid packet
	}
	else if (debug_level >= 3)
	{
        cout << Timer::GetCurrentTime() << " ";
        cout << "Valid packet ";
        cout << "pack->dwSEQ:" << pack->dwSEQ << " ";
        cout << "CACK.dwGSQ;" << CACK.dwGSQ << endl;
	}

	CACK.dwGSQ = pack->dwSEQ; //Get current sequence #.

	// Does this packet contain an ack request?
	if(pack->HDR.a1_ARQ)
	{
		// Is this packet a packet we dont want now, but will need later?
		if(pack->dwARQ - dwLastCACK > 1 && pack->dwARQ - dwLastCACK < 16) // Agz: Added 16 limit
        {
			// Debug check, if we want to buffer a packet we got from the buffer something is wrong...
			if (from_buffer)
			{
				cerr << "ERROR: Rebuffering a packet in CEQPacketManager::ProcessPacket" << endl;
			}
			LinkedListIterator<CEQPacket*> iterator(buffered_packets);
			iterator.Reset();
			while(iterator.MoreElements())
			{
				if (iterator.GetData()->dwARQ == pack->dwARQ)
				{
					if (debug_level >= 2)
					{
						cout << Timer::GetCurrentTime() << " ";
						cout << "Tried to buffer this packet, but it was already buffered ";
						cout << "pack->dwARQ:" << pack->dwARQ << " ";
						cout << "dwLastCACK:" << dwLastCACK << " ";
						cout << "pack->dwSEQ:" << pack->dwSEQ << endl;
					}
					return true; // This packet was already buffered
				}
				iterator.Advance();
			}

			cout << Timer::GetCurrentTime() << " ";
			cout << "Buffering this packet ";
			cout << "pack->dwARQ:" << pack->dwARQ << " ";
			cout << "dwLastCACK:" << dwLastCACK << " ";
			cout << "pack->dwSEQ:" << pack->dwSEQ << endl;

			buffered_packets.Insert(pack);
			return false;
		}
		// Is this packet a resend we have already processed?
		if(pack->dwARQ - dwLastCACK <= 0)
		{
 			if (debug_level >= 2)
			{
				cout << Timer::GetCurrentTime() << " ";
				cout << "Duplicate packet received ";
				cout << "pack->dwARQ:" << pack->dwARQ << " ";
				cout << "dwLastCACK:" << dwLastCACK << " ";
				cout << "pack->dwSEQ:" << pack->dwSEQ << endl;
			}
			no_ack_sent_timer->Trigger(); // Added to make sure we send a new ack respond
			return true;
		}
	}

	
	if(pack->dwOpCode == LS_REQUEST_SERVERLIST)
		int x = 1;
	/************ Process ack responds ************/
	if(pack->HDR.b2_ARSP)
		IncomingARSP(pack->dwARSP);
	/************ End process ack rsp ************/


	/************ END RESET CHECK ************/

	/************ START ACK REQ CHECK ************/
	if(pack->HDR.a1_ARQ || pack->HDR.b0_SpecARQ)
		IncomingARQ(pack->dwARQ);
	
	/************ END ACK REQ CHECK ************/

	/************ CHECK FOR THREAD TERMINATION ************/
	if(pack->HDR.a2_Closing && pack->HDR.a6_Closing)
		if(!pm_state)
		{
			pm_state = PM_FINISHING;
			MakeEQPacket(0); // Agz: Added
		}
	/************ END CHECK THREAD TERMINATION ************/

	/************ Get ack sequence number ************/
	if(pack->HDR.a4_ASQ)
		CACK.dbASQ_high = pack->dbASQ_high;
	
	if(pack->HDR.a1_ARQ)
		CACK.dbASQ_low = pack->dbASQ_low;
	/************ End get ack seq num ************/

	/************ START FRAGMENT CHECK ************/
	/************ IF - FRAGMENT ************/
	if(pack->HDR.a3_Fragment) 
	{
		if (debug_level >= 3)
		{
			cout << endl << Timer::GetCurrentTime() << " Fragment: ";
			cout << "pack->fraginfo.dwSeq:" << pack->fraginfo.dwSeq << " ";
			cout << "pack->fraginfo.dwCurr:" << pack->fraginfo.dwCurr << " ";
			cout << "pack->fraginfo.dwTotal:" << pack->fraginfo.dwTotal << endl;
		}
		FragmentGroup* fragment_group = 0;
		fragment_group = fragment_group_list.Get(pack->fraginfo.dwSeq);
if (fragment_group == 0)
//		if (pack->fraginfo.dwCurr == 0)
		{
			fragment_group = new FragmentGroup(pack->fraginfo.dwSeq, pack->dwOpCode, pack->fraginfo.dwTotal);
			fragment_group_list.Add(fragment_group);
		}
//		else
//		{
//			fragment_group = fragment_group_list.Get(pack->fraginfo.dwSeq);
//		}

		if (fragment_group == 0)
		{
			cerr << endl << "ERROR: fragment_group == 0!!" << endl << endl;
			return true;
		}

		fragment_group->Add(pack->fraginfo.dwCurr, pack->pExtra, pack->dwExtraSize);

		if(pack->fraginfo.dwCurr == (pack->fraginfo.dwTotal - 1) )
		{
			if (debug_level >= 3)
				cout << Timer::GetCurrentTime() << " Getting fragment opcode:" << fragment_group->GetOpcode() << endl;
			//Collect fragments and put them as one packet on the OutQueue
			APPLAYER *app = new APPLAYER;	
			app->pBuffer = fragment_group->AssembleData(&app->size);
			app->opcode = fragment_group->GetOpcode();
			fragment_group_list.Remove(pack->fraginfo.dwSeq);
			if (debug_level >= 3)
				cout << "FRAGMENT_GROUP finished" << endl;
			OutQueue.push(app);
			return true;
		}
		else
		{
			if (debug_level >= 3)
				cout << "FRAGMENT_GROUP not finished wait for more... " << endl;
			return true;
		}
	}
	/************ ELSE - NO FRAGMENT ************/
	else 
	{
//		cout << "NO FRAGMENT packet" << endl;
		APPLAYER *app = new APPLAYER;	
		app->pBuffer	= new uchar[pack->dwExtraSize]; memcpy(app->pBuffer, pack->pExtra, pack->dwExtraSize); // Agz: Added alloc
		app->size		= pack->dwExtraSize;
		app->opcode		= pack->dwOpCode;
		if (debug_level >= 3)
			cout << "Packet processed opcode:" << pack->dwOpCode << " length:" << app->size << endl;
		OutQueue.push(app);
		return true;
	}
	/************ END FRAGMENT CHECK ************/
cout << endl << "reached end of ParceEQPacket?!" << endl << endl;
return true;
}

void CEQPacketManager::CheckBufferedPackets()
{
// Should use a hash table or sorted list instead....
	int num=0; // Counting buffered packets for debug output
	LinkedListIterator<CEQPacket*> iterator(buffered_packets);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		num++;
		// Check if we have a packet we want already buffered
		if (iterator.GetData()->dwARQ - dwLastCACK == 1)
		{
			if (debug_level >= 2)
			{
				cout << Timer::GetCurrentTime() << " ";
				cout << "Found a packet we want in the incoming packet buffer ";
				cout << "pack->dwARQ:" << iterator.GetData()->dwARQ << " ";
				cout << "dwLastCACK:" << dwLastCACK << " ";
				cout << "pack->dwSEQ:" << iterator.GetData()->dwSEQ << endl;
			}
			ProcessPacket(iterator.GetData(), true);
			iterator.RemoveCurrent(); // This will call delete on the packet
			iterator.Reset(); // Start from the beginning of the list again
			num=0;
			continue;
		}
		iterator.Advance();
	}

	if (debug_level >= 2)
		cout << "Number of packets in buffer:" << num << endl;
}

/**************************************************************************************/
/************ Make an EQ packet and put it to the send queue ************/
//APP->size == 0 && app->pBuffer == NULL if no data.
void CEQPacketManager::MakeEQPacket(APPLAYER* app)
{
	int16 restore_op;

	/************ PM STATE = NOT ACTIVE ************/
	if(pm_state == PM_FINISHING)
	{
		CEQPacket *pack = new CEQPacket;
		MySendPacketStruct *p = new MySendPacketStruct;

		pack->dwSEQ = SACK.dwGSQ++; // Agz: Added this commented rest			
		pack->HDR.a6_Closing	= 1;// Agz: Lets try to uncomment this line again
		pack->HDR.a2_Closing	= 1;// and this
		pack->HDR.a1_ARQ		= 1;// and this
//		pack->dwARQ				= 1;// and this, no that was not too good
		pack->dwARQ				= SACK.dwARQ;// try this instead

		AddAck(pack);
		pm_state = PM_FINISHED;
		
		p->buffer = pack->ReturnPacket(&p->size);
		SendQueue.push(p);
		SACK.dwGSQ++; 

		return;
	}

	// Agz:Moved this to after finish check
	if(app == NULL)
	{
		cout << "CEQPacketManager::MakeEQPacket app == NULL" << endl;
		return;
	}
	bool bFragment= false; //This is set later on if fragseq should be increased at the end.

	/************ IF opcode is == 0xFFFF it is a request for pure ack creation ************/
	if(app->opcode == 0xFFFF)
	{
		CEQPacket *pack = new CEQPacket;

		// Added
		if(!SACK.dwGSQ)
		{
//			pack->HDR.a5_SEQStart	= 1; // Agz: hmmm, yes commenting this makes the client connect to zone
                                         //      server work and the world server doent seem to care either way
			SACK.dwARQ				= rand()%0x3FFF;//Current request ack
			SACK.dbASQ_high			= 1;			//Current sequence number
			SACK.dbASQ_low			= 0;			//Current sequence number	
			if (debug_level > 0)
				cout << "New random SACK.dwARQ 1" << endl;
		}
		if (debug_level > 0)
			cout << "SACK.dwGSQ:" << SACK.dwGSQ << endl;
		MySendPacketStruct *p = new MySendPacketStruct;
		pack->HDR.b2_ARSP    = 1;
		pack->dwARSP		 = CACK.dwARQ;
		pack->dwSEQ = SACK.dwGSQ++;
		p->buffer = pack->ReturnPacket(&p->size);

		if (debug_level >= 3)
		{
			cout << Timer::GetCurrentTime() << " Pure ack sent ";
			cout << "pack->dwARSP=CACK.dwARQ:" << CACK.dwARQ << " ";
			cout << "pack->dwSEQ=SACK.dwGSQ:" << SACK.dwGSQ << endl;
		}
		SendQueue.push(p);	

		return;
	}

	/************ CHECK PACKET MANAGER STATE ************/
	int fragsleft = (app->size >> 9) + 1;

	if (debug_level >= 3)
		cout << Timer::GetCurrentTime() << " fragsleft: " << fragsleft << endl;

	if(pm_state == PM_ACTIVE)
	/************ PM STATE = ACTIVE ************/
	{
		while(fragsleft--)
		{
			CEQPacket *pack = new CEQPacket;
			MySendPacketStruct *p = new MySendPacketStruct;
	
			if(!SACK.dwGSQ)
			{
				pack->HDR.a5_SEQStart	= 1;
				SACK.dwARQ				= rand()%0x3FFF;//Current request ack
				SACK.dbASQ_high			= 1;			//Current sequence number
				SACK.dbASQ_low			= 0;			//Current sequence number	
				if (debug_level > 0)
	                cout << "NEW random SACK.dwARQ 2" << endl;
			}
			if (debug_level > 0)
				cout << "SACK.dwGSQ:" << SACK.dwGSQ << endl;

			AddAck(pack);

			//IF NON PURE ACK THEN ALWAYS INCLUDE A ACKSEQ // Agz: Not anymore...
			if ((app->size >> 9) == 0 || fragsleft == (app->size >> 9)) // Agz: Added this
			pack->HDR.a4_ASQ = 1;

			/************ Caculate the next ACKSEQ/acknumber ************/
			/************ Check if its a static ackseq ************/
			if( HI_BYTE(app->opcode) == 0x2000)
			{
				if(app->size == 15)
					pack->dbASQ_low = 0xb2;
				else
					pack->dbASQ_low = 0xa1;

			}
			/************ Normal ackseq ************/
			else
			{
				//If not pure ack and opcode != 0x20XX then
				pack->HDR.a1_ARQ = 1;
				pack->dwARQ		 = SACK.dwARQ;

				if(pack->HDR.a1_ARQ && pack->HDR.a4_ASQ)
				{
					pack->dbASQ_low  = SACK.dbASQ_low;
					pack->dbASQ_high = SACK.dbASQ_high;
				}
				else
					if(pack->HDR.a4_ASQ)
					{
						pack->dbASQ_high = SACK.dbASQ_high;
					}
			}

			/************ Check if this packet should contain op ************/
			if(app->opcode)
			{
				pack->dwOpCode = app->opcode;
				restore_op =  app->opcode; // Agz: I'm reusing messagees when sending to multiple clients.
				app->opcode = 0; //Only first fragment contains op
			}
			/************ End opcode check ************/

			/************ SHOULD THIS PACKET BE SENT AS A FRAGMENT ************/
			if((app->size >> 9))
			{
				bFragment = true;
				pack->HDR.a3_Fragment = 1;
			}
			/************ END FRAGMENT CHECK ************/

			if(app->size && app->pBuffer)
			{
				if(pack->HDR.a3_Fragment)
				{
					if(!fragsleft)
						pack->dwExtraSize = app->size-510-512*((app->size/512)-1);//(int16)app->size&0x1FF;//app->size-510*(app->size/510)-2;
					else
						if(fragsleft == (app->size >> 9))
							pack->dwExtraSize = 510;
						else
							pack->dwExtraSize = 512;

					pack->fraginfo.dwCurr = (app->size >> 9) - fragsleft;
					pack->fraginfo.dwSeq  = dwFragSeq;
					pack->fraginfo.dwTotal= (app->size >> 9) + 1;
				}
				else
					pack->dwExtraSize = (int16)app->size;
	
				pack->pExtra = new uchar[pack->dwExtraSize];
				memcpy((void*)pack->pExtra, (void*)app->pBuffer, pack->dwExtraSize);
				app->pBuffer += pack->dwExtraSize; //Increase counter
			}
							
		

			/******************************************/
			/*********** !PACKET GENERATED! ***********/
			/******************************************/
			
			/************ Update timers ************/
			if(pack->HDR.a1_ARQ)
			{
				if (debug_level >=2 )
					cout << "OutgoingARQ pack->dwARQ:" << (unsigned short)pack->dwARQ << " SACK.dwARQ:" << (unsigned short)SACK.dwARQ << endl;
				OutgoingARQ(pack->dwARQ);
				ResendQueue.push(pack);

				SACK.dwARQ++;
			}
	
			if(pack->HDR.b2_ARSP)
				OutgoingARSP();
			/************ End update timers ************/
					
			pack->dwSEQ = SACK.dwGSQ++;
			p->buffer = pack->ReturnPacket(&p->size);
			
			SendQueue.push(p);
	
			if(pack->HDR.a4_ASQ)
				SACK.dbASQ_low++;
			
		}//end while

		if(bFragment)
			dwFragSeq++;
		app->pBuffer -= app->size; //Restore ptr.
		app->opcode = restore_op; // Agz: Restore opcode
		
	} //end if
}

void CEQPacketManager::CheckTimers(void)
{
	/************ Should packets be resent? ************/
//	if(tim->CheckTimer(ddTimerID, TIMER_NO_ACK_RESPOND_RECEIVED))
	if (no_ack_received_timer->Check())
	{
		if (debug_level > 0)
			cout << "Resending packets" << endl;
		CEQPacket *pack;
		MyQueue<CEQPacket> q;
		while(pack = ResendQueue.pop())
		{
			q.push(pack);
			MySendPacketStruct *p = new MySendPacketStruct;
			pack->dwSEQ = SACK.dwGSQ++;
			if (debug_level > 0)
				cout << "Resending packet ARQ:" << pack->dwARQ << " with SEQ:" << pack->dwSEQ << endl;
			p->buffer = pack->ReturnPacket(&p->size);
			SendQueue.push(p);
		}
		while(pack = q.pop())
		{
			ResendQueue.push(pack);
		}

		if(++resend_count > 9)
			pm_state = PM_FINISHED;

//		tim->Activate(ddTimerID, TIMER_NO_ACK_RESPOND_RECEIVED, 1000);
		no_ack_received_timer->Start(1000);
	}
	/************ Should a pure ack be sent ************/
//	if(tim->CheckTimer(ddTimerID, TIMER_NO_ACK_RESPOND_SENT_SEND_PURE))
	if (no_ack_sent_timer->Check())
	{
		APPLAYER app;
		app.opcode = 0xFFFF;
		MakeEQPacket(&app);
	}
}
