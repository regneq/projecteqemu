#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>

#include "entity.h"
#include "npc.h"
#include "client.h"
#include "worldserver.h"

#ifdef BUILD_FOR_WINDOWS
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
#endif

#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp

extern WorldServer* worldserver;

Entity::Entity()
{
}

Entity::~Entity()
{
}

void Entity::SetID(int16 set_id)
{
	id = set_id;
}

int16 Entity::GetID()
{
	return id;
}

Client* Entity::CastToClient()
{
#ifdef DEBUG
	if(!IsClient())
	{	
		cout << "CastToClient error" << endl;
		return 0;
	}
#endif
	return static_cast<Client*>(this);
}

NPC* Entity::CastToNPC()
{
#ifdef DEBUG
	if(!IsNPC())
	{	
		cout << "CastToNPC error" << endl;
		return 0;
	}
#endif
	return static_cast<NPC*>(this);
}

Mob* Entity::CastToMob()
{
#ifdef DEBUG
	if(!IsMob())
	{	
		cout << "CastToMob error" << endl;
		return 0;
	}
#endif
	return static_cast<Mob*>(this);
}

void EntityList::AddClient(Client* client)
{
	client->SetID(GetFreeID());

	list.Insert(client);
}

void EntityList::AddNPC(NPC* npc)
{
	LinkedListIterator<Entity*> iterator(list);
	APPLAYER app;

	npc->SetID(GetFreeID());
	npc->CreateSpawnPacket(&app);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->QueuePacket(&app);
		}
		iterator.Advance();
	}

	list.Insert(npc);
};

Entity* EntityList::GetID(int16 get_id)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetID() == get_id)
		{
			return iterator.GetData();
		}
		iterator.Advance();
	}
	return 0;
}

Client* EntityList::GetClient(int32 ip, int16 port)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (client->GetIP() == ip && client->GetPort() == port)
			{
				return client;
			}
		}
		iterator.Advance();
	}
	return 0;
}

void EntityList::Process()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr	in;
			in.s_addr = iterator.GetData()->CastToClient()->GetIP();
			cout << "Dropping client: Process=false, ip=" << inet_ntoa(in) << ", port=" << ntohs(iterator.GetData()->CastToClient()->GetPort()) << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

int16 EntityList::GetFreeID()
{
	while(1)
	{
		last_insert_id++;
		if (GetID(last_insert_id) == 0)
		{
			return last_insert_id;
		}
	}
}

void EntityList::ChannelMessage(Mob* from, int8 chan_num, int8 language, char* message, ...)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			if (chan_num != 8 || client->Dist(from) < 100) // Only say is limited in range
			{
					client->ChannelMessageSend(from->GetName(), 0, chan_num, language, buffer);
			}
		}
		iterator.Advance();
	}
}

void EntityList::SendZoneSpawns(Client* client)
{
	LinkedListIterator<Entity*> iterator(list);
	va_list argptr;
	char buffer[256];

	APPLAYER* app;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsMob())
		{
			if (iterator.GetData()->IsClient() && !iterator.GetData()->CastToClient()->Connected())
			{
				iterator.Advance();
				continue;
			}
			app = new APPLAYER;
			iterator.GetData()->CastToMob()->CreateSpawnPacket(app); // TODO: Use zonespawns opcode instead
			client->QueuePacket(app);
			delete app;
		}
		iterator.Advance();
	}	
}

void EntityList::Save()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->Save();
		}
		iterator.Advance();
	}	
}

void EntityList::RemoveFromTargets(Mob* mob)
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsNPC())
		{
			iterator.GetData()->CastToNPC()->RemoveFromHateList(mob);
		}
		if (iterator.GetData()->IsMob() && iterator.GetData()->CastToMob()->GetTarget() == mob)
		{
			iterator.GetData()->CastToMob()->SetTarget(0);			
		}
		iterator.Advance();
	}	
}

#ifdef BUILD_FOR_WINDOWS
void EntityList::QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender, float dist)
#else
void EntityList::QueueCloseClients(Mob* sender, APPLAYER* app, bool ignore_sender=false, float dist=200)
#endif
{
	LinkedListIterator<Entity*> iterator(list);

	dist=dist*dist*dist;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && iterator.GetData()->CastToClient()->DistNoRoot(sender) <= dist && (!ignore_sender || iterator.GetData() != sender))
		{
//ChannelMessage(0, 8, 0, "Sending a message [%04x:%i] to %s", app->opcode, app->size, iterator.GetData()->CastToClient()->GetName());
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}

#ifdef BUILD_FOR_WINDOWS
void EntityList::QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender)
#else
void EntityList::QueueClients(Mob* sender, APPLAYER* app, bool ignore_sender=false)
#endif

{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient() && (!ignore_sender || iterator.GetData() != sender))
		{
			iterator.GetData()->CastToClient()->QueuePacket(app);
		}
		iterator.Advance();
	}	
}

Client* EntityList::GetClientByName(char *checkname) 
{ 
       LinkedListIterator<Entity*> iterator(list); 
        
       iterator.Reset(); 
       while(iterator.MoreElements()) 
       { 
           if (iterator.GetData()->IsClient() && iterator.GetData()->IsMob()) 
           { 
			   if (strcasecmp(iterator.GetData()->CastToClient()->GetName(), checkname) == 0) {
                   return iterator.GetData()->CastToClient();
			   }
           } 
           iterator.Advance(); 
       } 
       return 0; 
} 

void EntityList::ChannelMessageFromWorld(char* from, char* to, int8 chan_num, int8 language, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			client->ChannelMessageSend(from, to, chan_num, language, buffer);
		}
		iterator.Advance();
	}
}

void EntityList::Message(int32 type, char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	LinkedListIterator<Entity*> iterator(list);

	cout << "Message:" << buffer << endl;

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			Client* client = iterator.GetData()->CastToClient();
			client->Message(type, buffer);
		}
		iterator.Advance();
	}
}

// Safely removes all entities before zone shutdown
void EntityList::Clear()
{
	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->Save();
		}
		iterator.RemoveCurrent();
	}	
}

void EntityList::UpdateWho()
{
	if (worldserver == 0 || zone == 0)
		return;
	ServerPacket* pack = new ServerPacket;
	pack->size = sizeof(ServerClientList_Struct);
	pack->opcode = ServerOP_ClientList;
	pack->pBuffer = new uchar[pack->size];
	memset(pack->pBuffer, 0, pack->size);
	ServerClientList_Struct* scl = (ServerClientList_Struct*) pack->pBuffer;
	scl->remove = true;
	strcpy(scl->zone, zone->GetShortName());
	worldserver->SendPacket(pack);

	LinkedListIterator<Entity*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->IsClient())
		{
			iterator.GetData()->CastToClient()->UpdateWho(false);
		}
		iterator.Advance();
	}	
}
