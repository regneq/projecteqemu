#include <iostream.h>

#include "hate_list.h"
#include "mob.h"

HateList::HateList()
{
  first = 0;
}

HateList::~HateList()
{
	if (first != 0)
	{
		delete first;
	}
}


void HateList::Add(Mob* ent, uint32 amount)
{
	HateListElement* current = first;
	HateListElement* temp;

	amount+=RemoveEnt(ent);

	temp = new HateListElement(ent,amount);

	if (first == 0)
	{
		first = temp;
	}
	else
	{
		current = first; // FIXED BUG HERE I THINK
		while (current->GetNext() != 0) // AND HERE: ADDED ->GetNext()
		{	
			if (current->GetAmount() < amount)
			{
				break;
			}
			current = current->GetNext();
		}
		if (current == first)
		{
			temp->SetNext(first);
			first = temp;
		}
		else
		{
			temp->SetNext(current->GetNext());
			current->SetNext(temp);
		}
	}
/*
	current = first;
	cout << "-- Hate List debug --" << endl;
	while (current != 0)
	{
		cout << current->GetEnt()->GetName() << ":" << current->GetAmount() << endl;
		current = current->GetNext();
	}
	cout << "-- End hate list debug --" << endl;
*/
}

Mob* HateList::GetTop()
{
	if (first == 0)
	{
		return 0;
	}

	return first->GetEnt();
}

uint32 HateList::RemoveEnt(Mob *ent)
{
	HateListElement *current = first;
	HateListElement *prev = 0;

	uint32 amount = 0;

	while (current != 0)
	{
		if (current->GetEnt() == ent)
		{
			break;
		}
		prev = current;
		current = current->GetNext();
	}

	if (current != 0)
	{
		if (prev == 0)
		{
			first = current->GetNext();
		}
		else
		{
			prev->SetNext(current->GetNext());
		}
		current->SetNext(0);
		amount = current->GetAmount();
		delete current;
	}

	return amount;
}