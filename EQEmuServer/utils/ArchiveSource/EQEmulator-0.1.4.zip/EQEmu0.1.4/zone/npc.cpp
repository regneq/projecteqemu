#include <math.h>

#include "npc.h"

NPC::NPC(NPCType* d, Spawn* in_respawn, float x, float y, float z, float heading) 
 : Mob(d->name,
       d->lastname,
       d->max_hp,
       d->max_hp,
       d->gender,
       d->race,
       d->class_,
       d->deity,
       d->level,
       heading,
       x,
       y,
       z,
       d->light,
       d->equipment)
{
	respawn = in_respawn;
	if (respawn == 0)
	{
		cout << name << " respawn == 0" << endl;
	}
}

NPC::~NPC()
{
}

bool NPC::Process()
{
	if (corpse)
		return true;

	SetTarget(hate_list.GetTop());

	if (target != 0)
	{
		if (attack_timer->Check())
		{
			FaceTarget();
			Attack(target);
			SendPosUpdate();
		}
	}

    return true;
}

void NPC::FaceTarget()
{
	// TODO: Simplify?

	float angle;

	if (target->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else if (target->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(target->GetY()-y_pos) / (double)(target->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (target->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
//cout << "dX:" << target->GetX()-x_pos;
//cout << "dY:" << target->GetY()-y_pos;
//cout << "Angle:" << angle;

	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;

	heading = 256*(360-angle)/360.0f;

//cout << "Heading:" << (int)heading << endl;
}

void NPC::RemoveFromHateList(Mob* mob)
{
	hate_list.RemoveEnt(mob);
}