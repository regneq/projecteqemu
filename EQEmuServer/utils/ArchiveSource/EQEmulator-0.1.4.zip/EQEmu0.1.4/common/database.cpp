#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Disgrace: for windows compile
#ifdef BUILD_FOR_WINDOWS
	#include <windows.h>
	#define snprintf	_snprintf
#endif

#include "database.h"

// change starting zone
const char* ZONE_NAME = "dreadlands";


/*
	This is the amount of time in seconds the client has to enter the zone
	server after the world server, or inbetween zones when that is finished
*/
#define AUTHENTICATION_TIMEOUT 120

#ifdef BUILD_FOR_WINDOWS
/*
	Establish a connection to a mysql database with the supplied parameters

	Added a very simple .ini file parser - Bounce
*/
Database::Database ()
{
	char host[200], user[200], passwd[200], database[200], buf[200], type[200];
	int items[4] = {0, 0, 0, 0};
	FILE *f;

	if (!(f = fopen ("db.ini", "r")))
	{
		printf ("Couldn't open the DB.INI file.\n");
		printf ("Read README.TXT!\n");
		exit (1);
	}

	do
	{
		fgets (buf, 199, f);
		if (feof (f))
		{
			printf ("[Database] block not found in DB.INI.\n");
			printf ("Read README.TXT!\n");
			exit (1);
		}
	}
	while (stricmp (buf, "[Database]\n"));

	while (!feof (f))
	{
		if (fscanf (f, "%[^=]=%[^\n]\n", type, buf) == 2)
		{
			if (!strnicmp (type, "host", 4))
			{
				strcpy (host, buf);
				items[0] = 1;
			}
			if (!strnicmp (type, "user", 4))
			{
				strcpy (user, buf);
				items[1] = 1;
			}
			if (!strnicmp (type, "pass", 4))
			{
				strcpy (passwd, buf);
				items[2] = 1;
			}
			if (!strnicmp (type, "data", 4))
			{
				strcpy (database, buf);
				items[3] = 1;
			}
		}
	}

	if (!items[0] || !items[1] || !items[2] || !items[3])
	{
		printf ("Incomplete DB.INI file.\n");
		printf ("Read README.TXT!\n");
		exit (1);
	}
	
	fclose (f);

	mysql_init(&mysql);
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, 0))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}
#else
/*
	Establish a connection to a mysql database with the supplied parameters
*/
Database::Database(const char* host, const char* user, const char* passwd, const char* database)
{
	mysql_init(&mysql);
	if (!mysql_real_connect(&mysql, host, user, passwd, database, 0, 0, 0))
	{
		cerr << "Failed to connect to database: Error: " << mysql_error(&mysql) << endl;
	}
	else
	{
		cout << "Using database '" << database << "' at " << host << endl;
	}
}
#endif

/*
	Close the connection to the database
*/
Database::~Database()
{
	mysql_close(&mysql);
}

/*
	Get the address and port to the zone server with the given name.
	If a record with that zone name is found return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetZoneServer(char* name, char* address, int16* port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address,port FROM zone_server WHERE name='%s'", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strncpy(address,row[0],256); // TODO: Find out max address len
				*port = atoi(row[1]);
				mysql_free_result(result);
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		cerr << "Error in GetZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}

/*
	If a record with that zone name is found return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetZoneServer(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address,port FROM zone_server WHERE name='%s'", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				mysql_free_result(result);
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		cerr << "Error in GetZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}


/*
	Register a zone server with the given address and port. If a zone
	with the given name is not registered or is already registered with 
	the same address and port we will return true, otherwise return false.
	False will also be returned if there is a database error.
*/
bool Database::RegisterZoneServer(char* name, char* address, int16 port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT address, port FROM zone_server WHERE name='%s' AND address='%s' AND port=%i", name, address, port);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				return true;
				mysql_free_result(result);
			}
		}
	}

	query = 0;
	buf_len = 256;
	chars = -1;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO zone_server SET name='%s', address='%s', port=%i", name, address, port);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in RegisterZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;	
}

/*
	Unregister the zone server with the given name, address and port. If the zone was
	was registered return trure, otherwise return false.
	False will also be returned if there is a database error.
*/
bool Database::UnregisterZoneServer(char* name, char* address, int16 port)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM zone_server WHERE name='%s' AND address='%s' AND port=%i", name, address, port);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in UnRegisterZoneServer query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;	
}

/*
	Check if the character with the name char_name from ip address ip has
	permission to enter zone zone_name. Return the account_id if the client
	has the right permissions, otherwise return zero.
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAuthentication(char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT account_id FROM authentication WHERE char_name='%s' AND zone_name='%s' AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", char_name, zone_name, ip, AUTHENTICATION_TIMEOUT);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 account_id = atoi(row[0]);
				mysql_free_result(result);
				return account_id;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;;
		}
	}
	else
	{
		cerr << "Error in GetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return 0;
	}

	return 0;
}

/*
	Give the account with id "account_id" permission to enter zone "zone_name" from ip address "ip"
	with character "char_name". Return true if successful.
	False will be returned if there is a database error.
*/
bool Database::SetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM authentication WHERE account_id=%i", account_id);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	buf_len = 128;
	chars = -1;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT INTO authentication SET account_id=%i, char_name='%s', zone_name='%s', ip=%u", account_id, char_name, zone_name, ip);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in SetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	delete[] query;

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	This function will return the zone name in the "zone_name" parameter.
	This is used when a character changes zone, the old zone server sets
	the authentication record, the world server reads this new zone	name.
	If there was a record return true, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT char_name, zone_name FROM authentication WHERE account_id=%i AND ip=%u AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(time) < %i", account_id, ip, AUTHENTICATION_TIMEOUT);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strcpy(char_name, row[0]);
				strcpy(zone_name, row[1]);
				mysql_free_result(result);
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		cerr << "Error in GetAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return false;
}


/*
	This function will remove the record in the authentication table for
	the account with id "accout_id"
	False will also be returned if there is a database error.
*/
bool Database::ClearAuthentication(int32 account_id)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE FROM authentication WHERE account_id=%i", account_id);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in ClearAuthentication query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

/*
	Check if there is an account with name "name" and password "password"
	Return the account id or zero if no account matches.
	Zero will also be returned if there is a database error.
*/
int32 Database::CheckLogin(char* name, char* password)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	int i;
	for (i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}
	for (i=0; i<strlen(password); i++)
	{
		if ((password[i] < 'a' || password[i] > 'z') && 
		    (password[i] < 'A' || password[i] > 'Z') && 
		    (password[i] < '0' || password[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT id FROM account WHERE name='%s' AND password='%s'", name, password);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 id = atoi(row[0]);
				mysql_free_result(result);
				return id;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
	{
		cerr << "Error in CheckLogin query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::CheckStatus(int32 account_id)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
chars = snprintf(query, buf_len, "SELECT status FROM account WHERE id='%i'", account_id);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
	{
		cerr << "Error in CheckStatus query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::CheckZoneWeather(char* zonename)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;
	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
chars = snprintf(query, buf_len, "SELECT rain FROM zone_server WHERE name='%s'", zonename);
cerr << "Zone Weather: " << zonename << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
	{
		cerr << "Error in CheckZoneWeather query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return 0;
}

int32 Database::SetZoneWeather(char* zonename, char* weather)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
chars = snprintf(query, buf_len, "UPDATE zone_server SET rain='%s' WHERE name='%s'",weather,zonename);
		cerr << "Updating Weather for: " << zonename << "Setting to: " << weather << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		cerr << "Error in SetWorldWeather query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

int32 Database::CreateAccount(char* name, char* password, char* status)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
chars = snprintf(query, buf_len, "INSERT INTO account SET name='%s', password='%s', status='%s';",name,password,status);
		cerr << "Account Attempting to be created:" << name << " " << password << " " << status << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		cerr << "Error in CreateAccount query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

int32 Database::DeleteAccount(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
chars = snprintf(query, buf_len, "DELETE FROM account WHERE name='%s';",name);
		cerr << "Account Attempting to be deleted:" << name << endl;
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				int32 status = atoi(row[0]);
				mysql_free_result(result);
				return status;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		cerr << "Error in CheckLogin query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}
void Database::GetCharSelectInfo(int32 account_id, CharacterSelect_Struct* cs)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

    memset((char*)cs, 0, 1120);
    for(int i=0;i<10;i++)
    {
        strcpy(cs->name[i], "<none>");
        strcpy(cs->zone[i], ZONE_NAME);
        cs->level[i] = 0;
    }

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT name,profile FROM character_ WHERE account_id=%i", account_id);
	}

	PlayerProfile_Struct* pp;
	int char_num = 0;
	unsigned long* lengths;

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			while ((row = mysql_fetch_row(result)))
			{
				lengths = mysql_fetch_lengths(result);
				if (lengths[1] == sizeof(PlayerProfile_Struct))
				{
					strcpy(cs->name[char_num], row[0]);
					pp = (PlayerProfile_Struct*) row[1];
					cs->level[char_num] = pp->level;
					cs->class_[char_num] = pp->class_;
					cs->race[char_num] = pp->race;
					cs->gender[char_num] = pp->gender;
					strcpy(cs->zone[char_num], pp->current_zone);
//cs->gender[char_num] = has not been found yet;
					char_num++;
				}
			}
			mysql_free_result(result);
		}
	}
	else
	{
		cerr << "Error in GetCharSelectInfo query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return;
	}

	return;
}

/*
	Reserve the character name "name" for account "account_id"
	This name can then be used to create a character.
	Return true if successful, false if the name was already reserved.
	False will also be returned if there is a database error.
*/
bool Database::ReserveName(int32 account_id, char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "INSERT into character_ SET account_id=%i, name='%s', profile=NULL", account_id, name);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in ReserveName query '" << query << "' " << mysql_error(&mysql) << endl;
		if (query != 0)
			delete[] query;
		return false;
	}

	return true;
}

/*
	Delete the character with the name "name"
	False will also be returned if there is a database error.
*/
bool Database::DeleteCharacter(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
		if (i > 0 && name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i]+'a'-'A';
		}
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "DELETE from character_ WHERE name='%s'", name);
	}

	if (mysql_query(&mysql, query))
	{
		cerr << "Error in DeleteCharacter query '" << query << "' " << mysql_error(&mysql) << endl;
		if (query != 0)
			delete[] query;
		return false;
	}

	return true;
}

/*
	Create and store a character profile with the give parameters.
	This function will not check if the paramaters are legal for this class/race combination.
	Return true if successful. Return false if the name was not reserved for character creation
	for this "account_id".
	False will also be returned if there is a database error.
*/
bool Database::CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis)
{
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z'))
			return 0;
	}

	PlayerProfile_Struct pp;
	memset((char*)&pp, 0, sizeof(PlayerProfile_Struct));

// TODO: Get the right data into this without using this file
/*
FILE* fp;
fp = fopen("../zone/start_profile_packet", "r");
fread((char*)&pp, sizeof(PlayerProfile_Struct), 1, fp);
fclose(fp);
*/
	strcpy(pp.name, name);
	pp.last_name[0] = 0;
	pp.race = race;
	pp.class_ = class_;
	pp.gender = gender;
	pp.level = 1;
	pp.exp = 0;
//	pp.pp_unknown5[0] = 0x05;
	pp.mana = 0;
	pp.pp_unknown6[0] = 0x02;
//	pp.pp_unknown6[48] = 0x14;
//	pp.pp_unknown6[50] = 0x05;
pp.cur_hp = 20; // TODO: This should be max hp
	pp.STR = str;
	pp.STA = sta;
	pp.CHA = cha;
	pp.DEX = dex;	
	pp.INT = int_;
	pp.AGI = agi;
	pp.WIS = wis;
	
	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		for (int i=0;i<24;i++) 
			pp.languages[i] = 100;
		for (int i=0;i<sizeof(pp.inventory); i++) 
		{ 
			pp.inventory[i] = 0xffff; 
		} 
	#else
		for (i=0;i<24;i++) 
			pp.languages[i] = 100;
		for (i=0;i<sizeof(pp.inventory); i++) 
		{ 
			pp.inventory[i] = 0xffff; 
		} 
	#endif
/*
	pp.pp_unknown8[58] = 0x07;
	pp.pp_unknown8[59] = 0x27;
	pp.pp_unknown8[60] = 0x06;
	pp.pp_unknown8[61] = 0x27;
	pp.pp_unknown8[62] = 0x0d;
	pp.pp_unknown8[63] = 0x27;
	pp.pp_unknown8[64] = 0xfb;
	pp.pp_unknown8[65] = 0x26;
	pp.pp_unknown8[66] = 0x04;
	pp.pp_unknown8[67] = 0x27;
	pp.pp_unknown8[68] = 0x02;
	pp.pp_unknown8[69] = 0x27;
	pp.pp_unknown8[70] = 0x1e;
	pp.pp_unknown8[71] = 0x49;
	pp.pp_unknown8[72] = 0x0c;
	pp.pp_unknown8[73] = 0x49;
*/
	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		for (int i=0;i<15; i++)
			pp.buffs[i].spell = 0xffff;

		for (int i=0;i<180; i++)
		{
			pp.pp_unknown9[i] = 0xff;
		}

		for (int i=0;i<256; i++)
			pp.spell_book[i] = 0xffff;
		for (int i=0;i<8; i++)
			pp.spell_memory[i] = 0xffff;
	#else
		for (i=0;i<15; i++)
			pp.buffs[i].spell = 0xffff;

		for (i=0;i<180; i++)
		{
			pp.pp_unknown9[i] = 0xff;
		}

		for (i=0;i<256; i++)
			pp.spell_book[i] = 0xffff;
		for (i=0;i<8; i++)
			pp.spell_memory[i] = 0xffff;
	#endif



	pp.x = 0;
	pp.y = 0;
	pp.z = 10;
	char tmp[260];
	if (!GetVariable("startzone", tmp))
		strcpy(pp.current_zone, ZONE_NAME); // TODO: The players choice of starting zone should be here
	else
		strcpy(pp.current_zone, tmp);

	pp.platinum = 10;
	pp.gold = 20;
	pp.silver = 30;
	pp.copper = 40;
	pp.platinum_bank = 15;
	pp.gold_bank = 25;
	pp.silver_bank = 35;
	pp.copper_bank = 45;

	// Disgrace: for windows compile
	#ifndef BUILD_FOR_WINDOWS
		for (int i=0;i<74; i++)
			pp.skills[i] = i;	
		strcpy(pp.bind_point_zone, ZONE_NAME);
		for (int i=0;i<4; i++)
			strcpy(pp.start_point_zone[i], ZONE_NAME);
	#else
		for (i=0;i<74; i++)
			pp.skills[i] = i;	
		strcpy(pp.bind_point_zone, ZONE_NAME);
		for (i=0;i<4; i++)
			strcpy(pp.start_point_zone[i], ZONE_NAME);
	#endif

    end += sprintf(end, "UPDATE character_ SET profile=");
    *end++ = '\'';
    end += mysql_real_escape_string(&mysql, end, (char*)&pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s' AND profile IS NULL", account_id, name);

    if (mysql_real_query(&mysql, query, (unsigned int) (end - query)))
    {
        cerr << "Error in CreateCharacter query '" << query << "' " << mysql_error(&mysql) << endl;
		return false;
    }

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	Get the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT profile FROM character_ WHERE account_id=%i AND name='%s'", account_id, name);
	}

	unsigned long* lengths;

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{	
				row = mysql_fetch_row(result);
				lengths = mysql_fetch_lengths(result);
				if (lengths[0] == sizeof(PlayerProfile_Struct))
				{
					memcpy(pp, row[0], sizeof(PlayerProfile_Struct));
				}
				else
				{
					cerr << "Pleyer profile length mismatch in GetPlayerProfile" << endl;
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		cerr << "Error in GetPlayerProfile query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
		return false;
	}

	return true;
}

/*
	Update the player profile for the given account "account_id" and character name "name"
	Return true if the character was found, otherwise false.
	False will also be returned if there is a database error.
*/
bool Database::SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp)
{
    char query[256+sizeof(PlayerProfile_Struct)*2+1];
	char* end = query;
    MYSQL_RES *result;
    MYSQL_ROW row;

	if (strlen(name) > 15)
		return false;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}

    end += sprintf(end, "UPDATE character_ SET profile=");
    *end++ = '\'';
    end += mysql_real_escape_string(&mysql, end, (char*)pp, sizeof(PlayerProfile_Struct));
    *end++ = '\'';
    end += sprintf(end," WHERE account_id=%d AND name='%s'", account_id, name);

    if (mysql_real_query(&mysql, query, (unsigned int) (end - query)))
    {
        cerr << "Error in SetPlayerProfile query " << mysql_error(&mysql) << endl;
		return false;
    }

	if (mysql_affected_rows(&mysql) == 0)
	{
		return false;
	}

	return true;
}

/*
	This function returns the account_id that owns the character with
	the name "name" or zero if no character with that name was found
	Zero will also be returned if there is a database error.
*/
int32 Database::GetAccountID(char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	for (int i=0; i<strlen(name); i++)
	{
		if ((name[i] < 'a' || name[i] > 'z') && 
		    (name[i] < 'A' || name[i] > 'Z') && 
		    (name[i] < '0' || name[i] > '9'))
			return 0;
	}

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT account_id FROM character_ WHERE name='%s'", name);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				return atoi(row[0]);
			}
		}
	}
	else
	{
		cerr << "Error in GetAccountID query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}

	return 0;
}

void Database::GetAccountName(int32 accountid, char* name)
{
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT name FROM account WHERE id='%i'", accountid);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strcpy(name, row[0]);
			}
		}
	}
	else
	{
		cerr << "Error in GetAccountName query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
}

// Gets variable from 'variables' table
bool Database::GetVariable(char* varname, char* varvalue) {
    char *query = 0;
	int buf_len = 256;
    int chars = -1;
    MYSQL_RES *result;
    MYSQL_ROW row;

	while (chars == -1 || chars >= buf_len)
	{
		if (query != 0)
		{
			delete[] query;
			query = 0;
			buf_len *= 2;
		}
		query = new char[buf_len];
		chars = snprintf(query, buf_len, "SELECT value FROM variables WHERE varname like '%s'", varname);
	}

	if (!mysql_query(&mysql, query))
	{
		delete[] query;
		result = mysql_store_result(&mysql);
		if (result)
		{
			if (mysql_num_rows(result) == 1)
			{
				row = mysql_fetch_row(result);
				strcpy(varvalue, row[0]);
				return true;
			}
		}
	}
	else
	{
		cerr << "Error in GetVariable query '" << query << "' " << mysql_error(&mysql) << endl;
		delete[] query;
	}
	return false;
}