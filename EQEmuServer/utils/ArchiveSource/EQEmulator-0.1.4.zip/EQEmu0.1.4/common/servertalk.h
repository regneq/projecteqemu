#ifndef EQ_SOPCODES_C
#define EQ_SOPCODES_C

#define ServerOP_KeepAlive  0x0001		// packet to test if port is still open
#define ServerOP_ChannelMessage  0x0002	// broadcast/guildsay
#define ServerOP_SetZone  0x0003		// client -> server zoneinfo
#define ServerOP_ShutdownAll  0x0004	// exit(0);
#define ServerOP_ZoneShutdown  0x0005	// unload all data, goto sleep mode
#define ServerOP_ZoneBootup  0x0006		// come out of sleep mode and load zone specified
#define ServerOP_ZoneStatus	0x0007		// Shows status of all zones
#define ServerOP_SetPort    0x0008		// Tells server port #
#define ServerOP_EmoteMessage 0x0009	// Worldfarts
#define ServerOP_ClientList		0x000A	// Update worldserver's client list, for #whos
#define ServerOP_Who			0x000B	// #who
#define ServerOP_ZonePlayer		0x000C  // #zone, or #summon
#define ServerOP_KickPlayer		0x000D  // #kick

#define SERVER_TIMEOUT 60000	// how often keepalive gets sent

#include "../common/timer.h"

/************ PACKET RELATED STRUCT ************/
class ServerPacket
{
public:
	~ServerPacket() { if (pBuffer !=0) delete[] pBuffer; }
	ServerPacket() { size = 0; opcode = 0; pBuffer = 0; }
	int16  size;
	int16  opcode;
	uchar* pBuffer;
};

struct ServerZoneStateChange_struct {
	int32 ZoneServerID;
	char adminname[30];
	char zonename[15];
};

struct ServerChannelMessage_Struct {
	char  deliverto[23];
	char  to[23];
	char  from[23];
	bool  noreply;
	int16 chan_num;
	int16  language;
	int16 messagesize;
	char  message[0];
};

struct ServerEmoteMessage_Struct {
	char to[23];
	int32 type;
	int16 messagesize;
	char message[0];
};

struct ServerClientList_Struct {
	bool remove;
	char zone[30];
	int8 Admin;
	char name[30];
	int32 AccountID;
	char AccountName[30];
	int8 race;
	int8 class_;
	int8 level;
};

struct ServerZonePlayer_Struct {
	char adminname[30];
	char name[30];
	char zone[15];
    sint16 x_pos;
    sint16 y_pos;
    sint16 z_pos;
};

struct ServerKickPlayer_Struct {
	char adminname[30];
	char name[30];
	int32 AccountID;
};
#endif