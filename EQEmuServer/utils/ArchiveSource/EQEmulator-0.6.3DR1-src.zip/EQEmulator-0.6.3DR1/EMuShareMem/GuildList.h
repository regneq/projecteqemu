#include "../common/types.h"
#include "../common/EMuShareMem.h"
#include "../common/eq_packet_structs.h"

struct MMFGuildList_Struct {
	uint32		MaxGuildID;
	GuildsListEntry_Struct		GuildList[MAX_NUMBER_GUILDS];
};

bool	pDLLLoadGuildList(CALLBACK_DBLoadGuildList cbDBLoadGuildList, int32 iGuildListtructSize);
bool	pAddGuild(uint32 id, const char* door);
uint32	pGetMaxGuildID();
const char* pGetGuild(uint32 id);
