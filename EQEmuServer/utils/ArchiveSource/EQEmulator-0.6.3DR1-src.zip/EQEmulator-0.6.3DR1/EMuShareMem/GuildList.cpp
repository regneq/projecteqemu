#include "../common/debug.h"

#ifdef WIN32
#include <windows.h>
#else
#include "../common/unix.h"
#endif

#include <memory.h>
#include <iostream>
using namespace std;
#include "GuildList.h"
#include "../common/timer.h"
#include "MMF.h"
#include "../common/eq_packet_structs.h"

MMF GuildListMMF;
const MMFGuildList_Struct* MMFGuildListData = 0;
MMFGuildList_Struct* MMFGuildListData_Writable = 0;


DLLFUNC bool AddGuild(uint32 id, const char* name) {
	if (!MMFGuildListData_Writable)
		return false;
	if (id > MAX_NUMBER_GUILDS)
		return false;
	if (id > MMFGuildListData_Writable->MaxGuildID)
		MMFGuildListData_Writable->MaxGuildID=id;
	memcpy(&MMFGuildListData_Writable->GuildList[id].name, name, strlen(name)+1);

	return true;
}

DLLFUNC bool DLLLoadGuildList(CALLBACK_DBLoadGuildList cbDBLoadGuildList, int32 iGuildListtructSize) {
	if (iGuildListtructSize != sizeof(GuildsListEntry_Struct)) {
		cout << "Error: EMuShareMem: DLLLoadGuildList: iGuildListtructSize != sizeof(GuildsListEntry_Struct)" << endl;
		cout << "GuildsListEntry_Struct struct has changed, EMuShareMem.dll needs to be recompiled." << endl;
		return false;
	}
	int32 tmpMemSize = sizeof(MMFGuildList_Struct);
	if (GuildListMMF.Open("EQEMuGuildList", tmpMemSize)) {
		if (GuildListMMF.CanWrite()) {
			MMFGuildListData_Writable = (MMFGuildList_Struct*) GuildListMMF.GetWriteableHandle();
			if (!MMFGuildListData_Writable) {
				cout << "Error: EMuShareMem: DLLLoadGuildList: !MMFGuildListData_Writable" << endl;
				return false;
			}

			memset(MMFGuildListData_Writable, 0, tmpMemSize);
			// use a callback so the DB functions are done in the main exe
			// this way the DLL doesnt have to open a connection to mysql
			if (!cbDBLoadGuildList()) {
				cout << "Error: EMuShareMem: DLLLoadGuildList: !cbDBLoadGuildList" << endl;
				return false;
			}

			MMFGuildListData_Writable = 0;
			GuildListMMF.SetLoaded();
			MMFGuildListData = (const MMFGuildList_Struct*) GuildListMMF.GetHandle();
			if (!MMFGuildListData) {
				cout << "Error: EMuShareMem: DLLLoadGuildList: !MMFGuildListData (CanWrite=true)" << endl;
				return false;
			}
			return true;
		}
		else {
			if (!GuildListMMF.IsLoaded()) {
				Timer::SetCurrentTime();
				int32 starttime = Timer::GetCurrentTime();
				while ((!GuildListMMF.IsLoaded()) && ((Timer::GetCurrentTime() - starttime) < 300000)) {
					Sleep(10);
					Timer::SetCurrentTime();
				}
				if (!GuildListMMF.IsLoaded()) {
					cout << "Error: EMuShareMem: DLLLoadGuildList: !GuildListMMF.IsLoaded() (timeout)" << endl;
					return false;
				}
			}
			MMFGuildListData = (const MMFGuildList_Struct*) GuildListMMF.GetHandle();
			if (!MMFGuildListData) {
				cout << "Error: EMuShareMem: DLLLoadGuildList: !MMFGuildListData (CanWrite=false)" << endl;
				return false;
			}
			return true;
		}
	}
	else {
		cout << "Error Loading GuildList: GuildList.cpp: pDLLLoadGuildList: ret == 0" << endl;
		return false;
	}
	return false;
};

DLLFUNC const char* GetGuild(uint32 id) {
	if (MMFGuildListData == 0 || (!GuildListMMF.IsLoaded()) || id > MAX_NUMBER_GUILDS)
		return 0;
	return MMFGuildListData->GuildList[id].name;
}

DLLFUNC uint32 GetMaxGuildID() {
	if (MMFGuildListData == 0 || (!GuildListMMF.IsLoaded()))
		return 0;
	return MMFGuildListData->MaxGuildID;
}
