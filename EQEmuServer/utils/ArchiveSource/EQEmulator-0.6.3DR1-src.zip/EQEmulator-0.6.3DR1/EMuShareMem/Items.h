#include "../common/types.h"
#include "../common/eq_packet_structs.h"
#include "../common/EMuShareMem.h"

// MMF_EQMAX_ITEMS:  Make sure this is bigger than the highest item ID#
#define MMF_EQMAX_ITEMS		100000
// MMF_MEMMAX_ITEMS: Maxium number of items to load into memory. Make sure this is bigger
//                   than the total number of items in the server's database!
//#define MMF_MEMMAX_ITEMS	32700

struct MMFItems_Struct {
	uint32		MaxItemID;
	uint32		NextFreeIndex;
	uint32		ItemCount;
	uint32		ItemIndex[MMF_EQMAX_ITEMS+1];
	Item_Struct	Items[0];
};

struct MMFItemsSerialization_Struct {
	uint32		SerializationOffset[MMF_EQMAX_ITEMS+1];
	uint32		NextSerializationOffset;
	unsigned char 	Serializations[0];
};
//#define MMF_MAX_ITEMS_MEMSIZE	sizeof(MMFItems_Struct) + 256



