struct Msg {
	int		id;
	char*	Sender;
	char*	Subject;
	char*	Body;
	char*	Date;
};
