/*  EQEMu:  Everquest Server Emulator
	Copyright (C) 2001-2003  EQEMu Development Team (http://eqemulator.net)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../common/debug.h"
#include <iostream>
#include <stdlib.h>

#include "masterentity.h"
#include "../common/database.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
#include "StringIDs.h"
using namespace std;

const char DEFAULT_OBJECT_NAME[] = "IT63_ACTORDEF";
const char DEFAULT_OBJECT_NAME_SUFFIX[] = "_ACTORDEF";

extern Database database;
extern Zone* zone;
extern EntityList entity_list;

// Loading object from database
Object::Object(uint32 id, uint32 type, uint32 icon, const Object_Struct& object, const ItemInst* inst)
 : respawn_timer(0), decay_timer(1800000)
{
	
	user = NULL;
	
	// Initialize members
	m_id = id;
	m_type = type;
	m_icon = icon;
	m_inuse = false;
	m_inst = NULL;
	m_ground_spawn=false;
	// Copy object data
	memcpy(&m_data, &object, sizeof(Object_Struct));
	if (inst) {
		m_inst = inst->Clone();
		decay_timer.Start();
	} else {
		decay_timer.Disable();
	}
	respawn_timer.Disable();
	
	// Set drop_id to zero - it will be set when added to zone with SetID()
	m_data.drop_id = 0;
}

//creating a re-ocurring ground spawn.
Object::Object(const ItemInst* inst, char* name,float max_x,float min_x,float max_y,float min_y,float z,float heading,int32 respawntimer)
 : respawn_timer(respawntimer), decay_timer(1800000)
{
	
	user = NULL;
	m_max_x=max_x;
	m_max_y=max_y;
	m_min_x=min_x;
	m_min_y=min_y;
	m_id	= 0;
	m_inst	= (inst) ? inst->Clone() : NULL;
	m_type	= OT_DROPPEDITEM;
	m_icon	= 0;
	m_inuse	= false;
	m_ground_spawn = true;
	decay_timer.Disable();
	// Set as much struct data as we can
	memset(&m_data, 0, sizeof(Object_Struct));
	m_data.heading = heading;
	//printf("Spawning object %s at %f,%f,%f\n",name,m_data.x,m_data.y,m_data.z);
	m_data.z = z;
	m_data.zone_id = zone->GetZoneID();
	respawn_timer.Disable();
	strcpy(m_data.object_name, name);
	RandomSpawn(false);
	
	// Hardcoded portion for unknown members
	m_data.unknown024	= 0x7f001194;
	m_data.unknown064	= 0;	//0x0000000D;
	m_data.unknown068	= 0;	//0x0000001E;
	m_data.unknown072	= 0;	//0x000032ED;
	m_data.unknown076	= 0x0000d5fe;
	m_data.unknown084	= 0xFFFFFFFF;
}

// Loading object from client dropping item on ground
Object::Object(Client* client, const ItemInst* inst)
 : respawn_timer(0), decay_timer(1800000)
{
	user = NULL;
	
	// Initialize members
	m_id	= 0;
	m_inst	= (inst) ? inst->Clone() : NULL;
	m_type	= OT_DROPPEDITEM;
	m_icon	= 0;
	m_inuse	= false;
	m_ground_spawn = false;
	// Set as much struct data as we can
	memset(&m_data, 0, sizeof(Object_Struct));
	m_data.heading = client->GetHeading();
	m_data.x = client->GetX();
	m_data.y = client->GetY();
	m_data.z = client->GetZ();
	m_data.zone_id = zone->GetZoneID();
	
	decay_timer.Start();
	respawn_timer.Disable();

	// Hardcoded portion for unknown members
	m_data.unknown024	= 0x7f001194;
	m_data.unknown064	= 0;	//0x0000000D;
	m_data.unknown068	= 0;	//0x0000001E;
	m_data.unknown072	= 0;	//0x000032ED;
	m_data.unknown076	= 0x0000d5fe;
	m_data.unknown084	= 0xFFFFFFFF;
	
	// Set object name
	if (inst) {
		const Item_Struct* item = inst->GetItem();
		if (item && item->IDFile) {
			if (strlen(item->IDFile) == 0) {
				strcpy(m_data.object_name, DEFAULT_OBJECT_NAME);
			}
			else {
				// Object name is idfile + _ACTORDEF
				uint32 len_idfile = strlen(inst->GetItem()->IDFile);
				uint32 len_copy = sizeof(m_data.object_name) - len_idfile - 1;
				if (len_copy > sizeof(DEFAULT_OBJECT_NAME_SUFFIX)) {
					len_copy = sizeof(DEFAULT_OBJECT_NAME_SUFFIX);
				}
				
				memcpy(&m_data.object_name[0], inst->GetItem()->IDFile, len_idfile);
				memcpy(&m_data.object_name[len_idfile], DEFAULT_OBJECT_NAME_SUFFIX, len_copy);
			}
		}
		else {
			strcpy(m_data.object_name, DEFAULT_OBJECT_NAME);
		}
	}
}

Object::~Object()
{
	safe_delete(m_inst);
	if(user != NULL) {
		user->SetTradeskillObject(NULL);
	}
}

void Object::SetID(int16 set_id)
{
	// Invoke base class
	Entity::SetID(set_id);
	
	// Store new id as drop_id
	m_data.drop_id = (uint32)this->GetID();
}

// Reset state of object back to zero
void Object::ResetState()
{
	safe_delete(m_inst);
	
	m_id	= 0;
	m_type	= 0;
	m_icon	= 0;
	memset(&m_data, 0, sizeof(Object_Struct));
}

bool Object::Save()
{
	if (m_id) {
		// Update existing
		database.UpdateObject(m_id, m_type, m_icon, m_data, m_inst);
	}
	else {
		// Doesn't yet exist, add now
		m_id = database.AddObject(m_type, m_icon, m_data, m_inst);
	}
	
	return true;
}

// Remove object from database
void Object::Delete(bool reset_state)
{
	if (m_id != 0) {
		database.DeleteObject(m_id);
	}
	
	if (reset_state) {
		ResetState();
	}
}

// Add item to object (only logical for world tradeskill containers
void Object::PutItem(uint8 index, const ItemInst* inst)
{
	if (index > 9) {
		LogFile->write(EQEMuLog::Error, "Object::PutItem: Invalid index specified (%i)", index);
		return;
	}
	
	if (m_inst && m_inst->IsType(ItemClassContainer)) {
		ItemContainerInst* bag = (ItemContainerInst*)m_inst;
		if (inst) {
			bag->PutItem(index, *inst);
		}
		else {
			bag->DeleteItem(index);
		}
		database.SaveWorldContainer(zone->GetZoneID(),m_id,bag);
		// This is _highly_ inefficient, but for now it will work: Save entire object to database
		//Save();
	}
}

void Object::Close() {
	m_inuse = false;
	if(user != NULL) {
		user->SetTradeskillObject(NULL);
	}
	user = NULL;
}

// Remove item from container
void Object::DeleteItem(uint8 index)
{
	if (m_inst && m_inst->IsType(ItemClassContainer)) {
		ItemContainerInst* bag = (ItemContainerInst*)m_inst;
		bag->DeleteItem(index);
		
		// This is _highly_ inefficient, but for now it will work: Save entire object to database
		Save();
	}
}

// Pop item out of container
ItemInst* Object::PopItem(uint8 index)
{
	ItemInst* inst = NULL;
	
	if (m_inst && m_inst->IsType(ItemClassContainer)) {
		ItemContainerInst* bag = (ItemContainerInst*)m_inst;
		inst = bag->PopItem(index);
		
		// This is _highly_ inefficient, but for now it will work: Save entire object to database
		Save();
	}
	
	return inst;
}

void Object::CreateSpawnPacket(EQZonePacket* app)
{
	app->SetOpcode(OP_GroundSpawn);
	app->pBuffer = new uchar[sizeof(Object_Struct)];
	app->size = sizeof(Object_Struct);
	memcpy(app->pBuffer, &m_data, sizeof(Object_Struct));
}

void Object::CreateDeSpawnPacket(EQZonePacket* app)
{
	app->SetOpcode(OP_ClickObject);
	app->pBuffer = new uchar[sizeof(ClickObject_Struct)];
	app->size = sizeof(ClickObject_Struct);
	ClickObject_Struct* co = (ClickObject_Struct*) app->pBuffer;
	co->drop_id = m_data.drop_id;
	co->player_id = 0;
}

bool Object::Process(){
	if(m_type == OT_DROPPEDITEM && decay_timer.Enabled() && decay_timer.Check()) {
		// Send click to all clients (removes entity on client)
		EQZonePacket* outapp = new EQZonePacket(OP_ClickObject, sizeof(ClickObject_Struct));
		ClickObject_Struct* click_object = (ClickObject_Struct*)outapp->pBuffer;
		click_object->drop_id = GetID();
		entity_list.QueueClients(NULL, outapp, false);
		safe_delete(outapp);

		// Remove object
		database.DeleteObject(m_id);
		return false;
	}
	
	if(m_ground_spawn && respawn_timer.Check()){
		RandomSpawn(true);
	}
	return true;
}

void Object::RandomSpawn(bool send_packet) {
	if(!m_ground_spawn)
		return;
	
	m_data.x = MakeRandomFloat(m_min_x, m_max_x);
	m_data.y = MakeRandomFloat(m_min_y, m_max_y);
	respawn_timer.Disable();
	
	if(send_packet) {
		EQZonePacket app;
		CreateSpawnPacket(&app);
		entity_list.QueueClients(NULL, &app, true);
	}
}

bool Object::HandleClick(Client* sender, const ClickObject_Struct* click_object)
{
	if(m_ground_spawn){//This is a Cool Groundspawn
			respawn_timer.Start();
	}
	if (m_type == OT_DROPPEDITEM) {
		if (m_inst && sender) {
			// Transfer item to client
			sender->PutItemInInventory(SLOT_CURSOR, *m_inst, false);
			sender->SendItemPacket(SLOT_CURSOR, m_inst, ItemPacketTrade);
			if(!m_ground_spawn)
				safe_delete(m_inst);
			
			// No longer using a tradeskill object
			sender->SetTradeskillObject(NULL);
			user = NULL;
		}
		
		// Send click to all clients (removes entity on client)
		EQZonePacket* outapp = new EQZonePacket(OP_ClickObject, sizeof(ClickObject_Struct));
		memcpy(outapp->pBuffer, click_object, sizeof(ClickObject_Struct));
		entity_list.QueueClients(NULL, outapp, false);
		safe_delete(outapp);
		
		// Remove object
		database.DeleteObject(m_id);
		if(!m_ground_spawn)
		entity_list.RemoveEntity(this->GetID());
	} else {
		// Tradeskill item
		EQZonePacket* outapp = new EQZonePacket(OP_ClickObjectAck, sizeof(ClickObjectAck_Struct));
		ClickObjectAck_Struct* coa = (ClickObjectAck_Struct*)outapp->pBuffer;
		
		//TODO: there is prolly a better way to do this.
		//if this is not the main user, send them a close and a message
		if(user == NULL || user == sender)
			coa->open		= 0x01;
		else {
			coa->open		= 0x00;
			sender->Message(13, "Somebody is allready using that container.");
		}
		m_inuse			= true;
		coa->type		= m_type;
		coa->unknown16	= 0x0a;	
		
		coa->drop_id	= click_object->drop_id;
		coa->player_id	= click_object->player_id;
		coa->icon		= m_icon;
		
		sender->QueuePacket(outapp);
		safe_delete(outapp);
		
		// Starting to use this object
		sender->SetTradeskillObject(this);
		
		//if the object allready had a user, we are done
		if(user != NULL)
			return(false);
		
		user = sender;
		
		// Send items inside of container

		if (m_inst && m_inst->IsType(ItemClassContainer)) {

			//Clear out no-drop and no-rent items first
			//TODO: should/could only do this if a different player opens it
			ItemContainerInst* container = (ItemContainerInst*)m_inst;
			container->ClearByFlags(byFlagSet, byFlagSet);
			
			EQZonePacket* outapp=new EQZonePacket(OP_ClientReady,0);
			sender->QueuePacket(outapp);
			safe_delete(outapp);
			for (uint8 i=0; i<10; i++) {
				const ItemInst* inst = container->GetItem(i);
				if (inst) {
					//sender->GetInv().PutItem(i+4000,inst);
					sender->SendItemPacket(i, inst, ItemPacketWorldContainer);
				}
			}
		}
	}
	
	return true;
}

// Add new Zone Object (theoretically only called for items dropped to ground)
uint32 Database::AddObject(uint32 type, uint32 icon, const Object_Struct& object, const ItemInst* inst)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = 0;
	
	uint32 database_id = 0;
	uint32 item_id = 0;
	sint8 charges = 0;
	
	if (inst && inst->GetItem()) {
		item_id = inst->GetItem()->ID;
		charges = inst->GetCharges();
	}
	
	// SQL Escape object_name
	uint32 len = strlen(object.object_name) * 2 + 1;
	char* object_name = new char[len];
	DoEscapeString(object_name, object.object_name, strlen(object.object_name));
	
	// Construct query
	uint32 len_query = MakeAnyLenString(&query,
		"insert into object (zoneid, xpos, ypos, zpos, heading, itemid, charges, objectname, "
		"type, icon) values (%i, %f, %f, %f, %f, %i, %i, '%s', %i, %i)",
		object.zone_id, object.x, object.y, object.z, object.heading,
		item_id, charges, object_name, type, icon);
	
	// Save new record for object
	if (!RunQuery(query, len_query, errbuf, NULL, NULL, &database_id)) {
		LogFile->write(EQEMuLog::Error, "Unable to insert object: %s", errbuf);
	}
	else {
		// Save container contents, if container
		if (inst && inst->IsType(ItemClassContainer)) {
			SaveWorldContainer(object.zone_id, database_id, (const ItemContainerInst*)inst);
		}
	}
	
	safe_delete_array(object_name);
	safe_delete_array(query);
	return database_id;
}

// Update information about existing object in database
void Database::UpdateObject(uint32 id, uint32 type, uint32 icon, const Object_Struct& object, const ItemInst* inst)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = 0;
	
	uint32 item_id = 0;
	sint8 charges = 0;
	
	if (inst && inst->GetItem()) {
		item_id = inst->GetItem()->ID;
		charges = inst->GetCharges();
	}
	
	// SQL Escape object_name
	uint32 len = strlen(object.object_name) * 2 + 1;
	char* object_name = new char[len];
	DoEscapeString(object_name, object.object_name, strlen(object.object_name));
	
	// Construct query
	uint32 len_query = MakeAnyLenString(&query,
		"update object set zoneid=%i, xpos=%f, ypos=%f, zpos=%f, heading=%f, "
		"itemid=%i, charges=%i, objectname='%s', type=%i, icon=%i where id=%i",
		object.zone_id, object.x, object.y, object.z, object.heading,
		item_id, charges, object_name, type, icon, id);
	
	// Save new record for object
	if (!RunQuery(query, len_query, errbuf)) {
		LogFile->write(EQEMuLog::Error, "Unable to update object: %s", errbuf);
	}
	else {
		// Save container contents, if container
		if (inst && inst->IsType(ItemClassContainer)) {
			SaveWorldContainer(object.zone_id, id, (const ItemContainerInst*)inst);
		}
	}
	
	safe_delete_array(object_name);
	safe_delete_array(query);
}
Ground_Spawns*	Database::LoadGroundSpawns(int32 zone_id,Ground_Spawns* gs){
	char errbuf[MYSQL_ERRMSG_SIZE];
    char *query = 0;
    MYSQL_RES *result;
    MYSQL_ROW row;
	
	if (RunQuery(query, MakeAnyLenString(&query, "SELECT max_x,max_y,max_z,min_x,min_y,heading,name,item,max_allowed,respawn_timer from ground_spawns where zoneid=%i limit 50", zone_id), errbuf, &result))
	{
		safe_delete_array(query);
		int i=0;
		while( (row=mysql_fetch_row(result) ) ) {
			gs->spawn[i].max_x=atof(row[0]);
			gs->spawn[i].max_y=atof(row[1]);
			gs->spawn[i].max_z=atof(row[2]);
			gs->spawn[i].min_x=atof(row[3]);
			gs->spawn[i].min_y=atof(row[4]);
			gs->spawn[i].heading=atof(row[5]);
			strcpy(gs->spawn[i].name,row[6]);
			gs->spawn[i].item=atoi(row[7]);
			gs->spawn[i].max_allowed=atoi(row[8]);
			gs->spawn[i].respawntimer=atoi(row[9]);
			i++;
		}
		mysql_free_result(result);
	}
	else {
		cerr << "Error in LoadGroundSpawns query '" << query << "' " << errbuf << endl;
		safe_delete_array(query);
	}
	return gs;
}
void Database::DeleteObject(uint32 id)
{
	char errbuf[MYSQL_ERRMSG_SIZE];
    char* query = 0;
	
	// Construct query
	uint32 len_query = MakeAnyLenString(&query,
		"delete from object where id=%i", id);
	
	// Save new record for object
	if (!RunQuery(query, len_query, errbuf)) {
		LogFile->write(EQEMuLog::Error, "Unable to delete object: %s", errbuf);
	}
	//else {
		// Delete contained items, if any
	//	DeleteWorldContainer(id);
	//}
	
	safe_delete_array(query);
}




