#!/bin/sh

xsubpp -typemap class.typemap class.xs
