/* 
	Copyright (C) 2005 Michael S. Finger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef _EQMAILPACKET_H
#define _EQMAILPACKET_H

#include "EQPacket.h"

using namespace std;

class OpcodeManager;
extern OpcodeManager *MailOpcodeManager;

class EQMailPacket : public EQApplicationPacket {
	friend class EQProtocolPacket;		//for constructor access
	friend class EQStream;
public:
	virtual ~EQMailPacket() {}
	EQMailPacket() : EQApplicationPacket(&MailOpcodeManager) { app_opcode_size=1; }
	EQMailPacket(const EmuOpcode op) : EQApplicationPacket(&MailOpcodeManager,op) { app_opcode_size=1; }
	EQMailPacket(const EmuOpcode op, const uint32 len) : EQApplicationPacket(&MailOpcodeManager,op,len) { app_opcode_size=1; }
	EQMailPacket(const EmuOpcode op, const unsigned char *buf, const uint32 len) : EQApplicationPacket(&MailOpcodeManager, op, buf, len) { app_opcode_size=1; }
	virtual EQApplicationPacket *Copy() const {
		EQMailPacket *it = new EQMailPacket;
		it->pBuffer= new unsigned char[size];
		memcpy(it->pBuffer,pBuffer,size);
		it->size=size;
		it->opcode = opcode;
		it->emu_opcode = emu_opcode;
		return(it);
	}
	virtual EQStreamType GetPacketType() const { return(MailStream); }
	
private:
	//this constructor should only be used by EQProtocolPacket, as it
	//assumes the first two bytes of buf are the opcode.
	EQMailPacket(const unsigned char *buf, uint32 len);
	EQMailPacket(const EQMailPacket &p) : EQApplicationPacket(&MailOpcodeManager,p.emu_opcode,p.pBuffer,p.size) { app_opcode_size=1; }

};

#endif
