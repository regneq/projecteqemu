/* 
	Copyright (C) 2005 Michael S. Finger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef _EQCHATPACKET_H
#define _EQCHATPACKET_H

#include "EQPacket.h"

using namespace std;

class OpcodeManager;
extern OpcodeManager *ChatOpcodeManager;

class EQChatPacket : public EQApplicationPacket {
	friend class EQProtocolPacket;
	friend class EQStream;
public:
	virtual ~EQChatPacket() {}
	EQChatPacket() : EQApplicationPacket(&ChatOpcodeManager) { app_opcode_size=1; }
	EQChatPacket(const EmuOpcode op) : EQApplicationPacket(&ChatOpcodeManager,op) { app_opcode_size=1; }
	EQChatPacket(const EmuOpcode op, const uint32 len) : EQApplicationPacket(&ChatOpcodeManager,op,len) { app_opcode_size=1; }
	EQChatPacket(const EmuOpcode op, const unsigned char *buf, const uint32 len) : EQApplicationPacket(&ChatOpcodeManager, op, buf, len) { app_opcode_size=1; }
	virtual EQApplicationPacket *Copy() const {
		EQChatPacket *it = new EQChatPacket;
		it->pBuffer= new unsigned char[size];
		memcpy(it->pBuffer,pBuffer,size);
		it->size=size;
		it->opcode = opcode;
		it->emu_opcode = emu_opcode;
		return(it);
	}
	virtual EQStreamType GetPacketType() const { return(ChatStream); }
	
private:
	//this constructor should only be used by EQProtocolPacket, as it
	//assumes the first two bytes of buf are the opcode.
	EQChatPacket(const unsigned char *buf, uint32 len);
	EQChatPacket(const EQChatPacket &p) : EQApplicationPacket(&ChatOpcodeManager,p.emu_opcode,p.pBuffer,p.size) { app_opcode_size=1; }

};

#endif
