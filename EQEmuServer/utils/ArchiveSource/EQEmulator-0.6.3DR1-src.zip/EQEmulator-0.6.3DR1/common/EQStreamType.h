#ifndef _EQSTREAMTYPE_H
#define _EQSTREAMTYPE_H

typedef enum {
	UnknownStream=0,
	LoginStream,
	WorldStream,
	ZoneStream,
	ChatOrMailStream,
	ChatStream,
	MailStream
} EQStreamType;


#endif
