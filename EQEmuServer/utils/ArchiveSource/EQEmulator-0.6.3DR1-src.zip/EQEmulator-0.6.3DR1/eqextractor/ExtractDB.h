#ifndef EXTRACTDB_H
#define EXTRACTDB_H

#include "../common/types.h"
#include "../common/dbcore.h"

#include <stdio.h>

class ExtractorDB : public DBcore {
public:
	ExtractorDB();
};



#endif


