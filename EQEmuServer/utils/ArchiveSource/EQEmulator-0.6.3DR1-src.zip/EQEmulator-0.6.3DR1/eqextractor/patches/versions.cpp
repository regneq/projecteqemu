#include <string.h>
#include "patches/versions.h"
#include "../common/opcodemgr.h"
#include "../common/buildfile.h"
//Must include all valid version headers
#include "patches/patch_current.h"
#include "patches/patch_local.h"
#include "patches/patch_021505.h"
#include "patches/patch_121504.h"
#include "patches/patch_051105.h"

ExtractorAbstractFactory::ExtractorAbstractFactory(const char *opcodes_file) {
	opcodeManager = new RegularOpcodeManager();
	
	//we dont care how this turns out, worst case it falls
	//back to a NULL manager and dosent do anything.
	opcodeManager->LoadOpcodes(opcodes_file, false);
}

ExtractorAbstractFactory::~ExtractorAbstractFactory() {
	safe_delete(opcodeManager);
}

void ExtractorAbstractFactory::ListExtractorFactories() {
	printf("Avaliable Patches:\n"
		"\tcurrent\t- The current eqemu code\n"
		"\tlocal\t- The current structures in patches/patch_local.h\n"
		"\tDated:\n"
		"\t051105 - The May 11th 2005 patch\n"
		"\t021505 - The Febuary 15 2005 patch, DoN release, new net code\n"
		"\t121504 - The December 15th 2004 patch.\n"
		"\n"
	);
}

ExtractorAbstractFactory *ExtractorAbstractFactory::GetExtractorFactoryByName(const char *patch_name, const char *filename) {
	if(!strcasecmp(patch_name, "current")) {
		return(new EQE_Patch_Current::ExtractorConcreteFactory(filename));
	}
	if(!strcasecmp(patch_name, "local")) {
		return(new EQE_Patch_Local::ExtractorConcreteFactory(filename));
	}
	if(!strcasecmp(patch_name, "021505")) {
		return(new EQE_Patch_021505::ExtractorConcreteFactory(filename));
	}
	if(!strcasecmp(patch_name, "121504")) {
		return(new EQE_Patch_121504::ExtractorConcreteFactory(filename));
	}
	if(!strcasecmp(patch_name, "051105")) {
		return(new EQE_Patch_051105::ExtractorConcreteFactory(filename));
	}
	return(NULL);
}

//second constants to make patch dates easier
#define YEAR_2004 1072935480
#define YEAR_2005 1104492410
#define MONTH 2629743
#define DAY 86400

ExtractorAbstractFactory *ExtractorAbstractFactory::GetExtractorFactoryByDate(uint32 stamp, const char *filename) {
	//dated patches
	if(stamp < (YEAR_2004 + 11*MONTH + 14*DAY)) {
		fprintf(stderr, "# Detected Patch before our known history. Unable to process.\n");
		return(NULL);
	} else if(stamp < (YEAR_2005 + 1*MONTH + 14*DAY)) {
		// patch 12-15-04 to 02-15-05
		fprintf(stderr, "# Auto-detected patch date of 12-15-04\n");
		return(new EQE_Patch_121504::ExtractorConcreteFactory(filename));
	} else if(stamp < (YEAR_2005 + 4*MONTH + 10*DAY)) {
		// patch after 02-15-05 to 05-11-05
		fprintf(stderr, "# Auto-detected patch date of 02-15-05\n");
		return(new EQE_Patch_021505::ExtractorConcreteFactory(filename));
	} else if(stamp < (YEAR_2005 + 6*MONTH + 10*DAY)) {
		// patch after 05-11-05 to 07-11-05
		fprintf(stderr, "# Auto-detected patch date of 05-15-05\n");
		return(new EQE_Patch_051105::ExtractorConcreteFactory(filename));
	} //current patch on: 
	
	fprintf(stderr, "# Time Stamp is after any known patch, using current structs.\n");
	//if its not one of the past patches, assume its the most recent.
	return(new EQE_Patch_Current::ExtractorConcreteFactory(filename));
}






