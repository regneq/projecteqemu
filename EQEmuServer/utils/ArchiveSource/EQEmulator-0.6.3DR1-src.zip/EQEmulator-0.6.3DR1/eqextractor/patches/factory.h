//no macro guard on purpose!

//this is a single implementation with a single name, but is included
//into many different namespaces which yeilds many different concrete factories
class ExtractorConcreteFactory : public ExtractorAbstractFactory {
public:
	ExtractorConcreteFactory(const char *filename);
	
	//this patch's zone info extractor, for use by anybody who needs it.
	ZoneInfoExtractor zone_info;
	
	//Abstract Factory methods:
	virtual EQExtractor::ExtractBase *getZoneInfoExtractor() { return(&zone_info); }
	virtual EQExtractor::ExtractBase *newDoorExtractor() { return(new DoorExtractor(&zone_info)); }
	virtual EQExtractor::ExtractBase *newFuzzyDoorExtractor() { return(new FuzzyDoorExtractor(&zone_info)); }
	virtual EQExtractor::ExtractBase *newAAExtractor() { return(new AAExtractor()); }
	virtual EQExtractor::ExtractBase *newZoneHeaderExtractor() { return(new ZoneHeaderExtractor(&zone_info)); }
	virtual EQExtractor::ExtractBase *newZonePointExtractor() { return(new ZonePointExtractor(&zone_info)); }
	virtual EQExtractor::ExtractBase *newObjectExtractor() { return(new ObjectExtractor()); }
	virtual EQExtractor::ExtractBase *newFuzzyObjectExtractor() { return(new FuzzyObjectExtractor()); }
	virtual EQExtractor::ExtractBase *newTributeExtractor() { return(new TributeExtractor()); }
	virtual EQExtractor::ExtractBase *newTributeTextExtractor() { return(new TributeTextExtractor()); }
	virtual EQExtractor::ExtractBase *newBookTextExtractor() { return(new BookTextExtractor()); }
	virtual EQExtractor::ExtractBase *newTitleExtractor() { return(new TitleExtractor()); }
	virtual EQExtractor::ExtractBase *newRecipeExtractor() { return(new RecipeExtractor()); }
	virtual EQExtractor::ExtractBase *newTaskExtractor() { return(NULL/*new TaskExtractor()*/); }
	virtual EQExtractor::ExtractBase *newTaskHistoryExtractor() { return(new TaskHistoryExtractor()); }
	virtual EQExtractor::ExtractBase *newSpawnExtractor() { return(new SpawnExtractor(&zone_info)); }
	virtual EQExtractor::ExtractBase *newSpawnListExtractor() { return(new SpawnListExtractor()); }
	virtual PatchBuildFileWriterInterface *newBuildFileWriter() { return(new PatchBuildFileWriter()); }
};



