#ifndef EQE_VERSIONS_H
#define EQE_VERSIONS_H

//here for convenience as its used by all patches
#include "../common/MiscFunctions.h"
#include "../common/misc.h"
#include "../common/packet_dump.h"

class OpcodeManager;
class PatchBuildFileWriterInterface;
namespace EQExtractor {
	class ExtractBase;
};

class ExtractorAbstractFactory {
	//acts as an interface for concrete factories for each patch
	//acts as a factory itself to instantiate the concrete factories
public:
	ExtractorAbstractFactory(const char *opcodes_file);
	virtual ~ExtractorAbstractFactory();
	
	//Factory methods:
	static ExtractorAbstractFactory *GetExtractorFactoryByName(const char *patch_name, const char *filename);
	static ExtractorAbstractFactory *GetExtractorFactoryByDate(uint32 unix_timestamp, const char *filename);
	
	static void ListExtractorFactories();
	
	//Abstract Factory methods:
	virtual EQExtractor::ExtractBase *getZoneInfoExtractor() = 0;
	virtual EQExtractor::ExtractBase *newDoorExtractor() = 0;
	virtual EQExtractor::ExtractBase *newFuzzyDoorExtractor() = 0;
	virtual EQExtractor::ExtractBase *newAAExtractor() = 0;
	virtual EQExtractor::ExtractBase *newZoneHeaderExtractor() = 0;
	virtual EQExtractor::ExtractBase *newZonePointExtractor() = 0;
	virtual EQExtractor::ExtractBase *newObjectExtractor() = 0;
	virtual EQExtractor::ExtractBase *newFuzzyObjectExtractor() = 0;
	virtual EQExtractor::ExtractBase *newTributeExtractor() = 0;
	virtual EQExtractor::ExtractBase *newTributeTextExtractor() = 0;
	virtual EQExtractor::ExtractBase *newBookTextExtractor() = 0;
	virtual EQExtractor::ExtractBase *newTitleExtractor() = 0;
	virtual EQExtractor::ExtractBase *newRecipeExtractor() = 0;
	virtual EQExtractor::ExtractBase *newTaskExtractor() = 0;
	virtual EQExtractor::ExtractBase *newTaskHistoryExtractor() = 0;
	virtual EQExtractor::ExtractBase *newSpawnExtractor() = 0;
	virtual EQExtractor::ExtractBase *newSpawnListExtractor() = 0;
	virtual PatchBuildFileWriterInterface *newBuildFileWriter() = 0;
	
	OpcodeManager *opcodeManager;
};



#endif

