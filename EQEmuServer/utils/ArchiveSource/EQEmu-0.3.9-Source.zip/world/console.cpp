/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"

#ifdef WIN32
	#include <iostream>
	#include <string>
	#include <cstdio>
	#include <windows.h>
	#include <winsock.h>
#else
	#include <iostream.h>
	#include <string.h>
	#include <stdio.h>	
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <errno.h>
	#include <stdlib.h>
	#include <pthread.h>

	#include "../common/unix.h"

	#define SOCKET_ERROR -1
	#define INVALID_SOCKET -1

	extern int errno;
#endif

#include "../common/version.h"
#include "console.h"
#include "net.h"
#include "zoneserver.h"
#include "../common/database.h"
#include "../common/packet_dump.h"
#include "../common/seperator.h"
#include "../common/eq_packet_structs.h"
#include "LoginServer.h"
#include "../common/serverinfo.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp

	using namespace std;
#endif

extern Database database;
extern NetConnection net;
extern ZSList	zoneserver_list;
extern volatile bool RunLoops;
extern uint32	numzones;
extern LoginServer loginserver;
volatile bool ConsoleLoopRunning = false;

int listening_socketTCP;
ConsoleList console_list;

bool InitTCP()
{
#ifdef WIN32
	SOCKADDR_IN address;
#else
	struct sockaddr_in address;
#endif
	int reuse_addr = 1;
	unsigned long nonblocking = 1;
#ifdef WIN32
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;

	WSAStartup (version, &wsadata);
#endif		

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up TCP port for new TCP connections */
	listening_socketTCP = socket(AF_INET, SOCK_STREAM, 0);
	if (listening_socketTCP == INVALID_SOCKET) 
 	{
		return false;
	}

// Quag: dont think following is good stuff for TCP, good for UDP
// Mis: SO_REUSEADDR shouldn't be a problem for tcp--allows you to restart
// without waiting for conns in TIME_WAIT to die
	setsockopt(listening_socketTCP, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse_addr, sizeof(reuse_addr));


	if (bind(listening_socketTCP, (struct sockaddr *) &address, sizeof(address)) < 0) 
	{
#ifdef WIN32
		closesocket(listening_socketTCP);
#else
		close(listening_socketTCP);
#endif
		return false;
	}

#ifdef WIN32
	ioctlsocket (listening_socketTCP, FIONBIO, &nonblocking);
#else
	fcntl(listening_socketTCP, F_SETFL, O_NONBLOCK);
#endif

	if (listen (listening_socketTCP, SOMAXCONN) == SOCKET_ERROR) 
	{
#ifdef WIN32
		cout << "Listening TCP socket failed. Error: " << WSAGetLastError() << endl;
                closesocket (listening_socketTCP);
#else
		cout << "Listening TCP socket failed. Error: " << strerror(errno) << endl;
                close(listening_socketTCP);
#endif
		return false;
	}

	return true;
}

void ListenNewTCP()
{
    int		tmpsock;
    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;
    unsigned short	port;
	Console* con;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	// Check for pending connects
#ifdef WIN32
	tmpsock = accept(listening_socketTCP, (struct sockaddr*) &from, (int *) &fromlen);
#else
	tmpsock = accept(listening_socketTCP, (struct sockaddr*) &from, &fromlen);
#endif
	if (!(tmpsock == INVALID_SOCKET))
	{
		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		// New TCP connection
		con = new Console(in.s_addr, ntohs(from.sin_port), tmpsock);
		cout << "New TCP connection: " << inet_ntoa(in) << ":" << con->GetPort() << endl;
		send(tmpsock, "Username: ", 10, 0);
		console_list.Add(con);
	}
}

#ifdef WIN32
void ConsoleLoop(void *tmp) {
#else
void *ConsoleLoop(void *tmp) {
#endif
	ConsoleLoopRunning = true;
	while(RunLoops) {
		ListenNewTCP();
		console_list.ReceiveData();
		Sleep(1);
	}
	ConsoleLoopRunning = false;
}

Console::Console(int32 in_ip, int16 in_port, int in_send_socket) : WorldTCPConnection() {
	ip = in_ip;
	port = in_port;
	send_socket = in_send_socket;
	timeout_timer = new Timer(CONSOLE_TIMEOUT);
	state = 0;
	ClearBuffer();
	paccountid = 0;
	memset(paccountname, 0, sizeof(paccountname));
	admin = 0;
	#ifndef WIN32
		fcntl(in_send_socket, F_SETFL, O_NONBLOCK);
	#endif
}

Console::~Console() {
	delete timeout_timer;
}

void Console::ClearBuffer() {
	bufindex = 0;
	memset(textbuf, 0, sizeof(textbuf));
}

void Console::Die() {
	if (state != CONSOLE_STATE_ZS) {
		state = CONSOLE_STATE_CLOSED;
		struct in_addr  in;
		in.s_addr = ip;
		cout << "Removing console from ip: " << inet_ntoa(in) << " port:" << port << endl;
#ifdef WIN32
		closesocket(send_socket);
#else
		close(send_socket);
#endif
	}
}

void Console::SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);
	SendMessage(1, buffer);
}

void Console::SendExtMessage(const char* message, ...) {
	va_list argptr;
	char buffer[256];

	va_start(argptr, message);
	vsnprintf(buffer, 256, message, argptr);
	va_end(argptr);

	SendMessage(1, 0);
	SendMessage(1, buffer);
	ClearBuffer();
	SendPrompt();
}

void Console::SendMessage(int8 newline, const char* message, ...) {
	LockMutex lock(&MOutPacketLock);
	if (message != 0) {
		va_list argptr;
		char buffer[256];

		va_start(argptr, message);
		vsnprintf(buffer, 256, message, argptr);
		va_end(argptr);

		send(send_socket, buffer, strlen(buffer), 0);
	}

	if (newline) {
		char outbuf[2];
		memset(&outbuf[0], 13, 1);
		memset(&outbuf[1], 10, 1);
		for (int i=0; i < newline; i++)
			send(send_socket, outbuf, 2, 0);
	}
}

void ConsoleList::Add(Console* con) {
	list.Insert(con);
}

void ConsoleList::ReceiveData() {
	LinkedListIterator<Console*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (!iterator.GetData()->ReceiveData()) {
			iterator.GetData()->Die();
			iterator.RemoveCurrent();
		}
		else {
			iterator.Advance();
		}
	}
}

bool Console::ReceiveData() {
	if (state == CONSOLE_STATE_ZS || state == CONSOLE_STATE_CLOSED)
		return false;

    uchar		buffer[1024];
	
    int			status;
    unsigned short	port;

    struct in_addr	in;

    status = recv(send_socket, (char *) &buffer, sizeof(buffer), 0);

    if (status >= 1)
    {
		timeout_timer->Start();
//DumpPacket(buffer, status);
		if ((bufindex + status) > 1020) {
			// buffer overflow, kill client
			SendMessage(1, 0);
			SendMessage(1, "Buffer overflow, disconnecting");
			return false;
		} else {
			memcpy(&textbuf[bufindex], &buffer, status);
			bufindex += status;
			if (state != CONSOLE_STATE_PASSWORD) {
				MOutPacketLock.lock();
#ifdef WIN32
				send(send_socket, (char *) buffer, status, 0);
#else
				send(send_socket, buffer, status, 0);
#endif
				MOutPacketLock.unlock();
			}
			CheckBuffer();
		}
	} else if (status == SOCKET_ERROR) {
#ifdef WIN32
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
#else
		if (!(errno == EWOULDBLOCK)) {
#endif
			struct in_addr  in;
			in.s_addr = GetIP();
			cout << "TCP connection lost: " << inet_ntoa(in) << ":" << GetPort() << endl;
			return false;
		}
	}

    if (timeout_timer->Check())
    {
		SendMessage(1, 0);
		SendMessage(1, "Timeout, disconnecting...");
		struct in_addr  in;
		in.s_addr = GetIP();
		cout << "TCP connection timeout: " << inet_ntoa(in) << ":" << GetPort() << endl;
		return false;
    }

	return true;
}

void Console::CheckBuffer() {
	for (int i=0; i < bufindex; i++) {
		if (textbuf[i] < 8 || textbuf[i] == 11 || textbuf[i] == 12 || (textbuf[i] > 13 && textbuf[i] < 32) || textbuf[i] >= 127) {
			cout << "Illegal character in TCP string, disconnecting at " << i << " 0x" << hex << textbuf[i] << dec << endl;
			SendMessage(1, 0);
			SendMessage(1, "Illegal character in stream, disconnecting.");
			state = CONSOLE_STATE_CLOSED;
			return;
		}
		switch(textbuf[i]) {
			case 10:
			case 13: // newline marker
			{
				if (i==0) { // empty line
					memcpy(textbuf, &textbuf[1], 1023);
					textbuf[1023] = 0;
					bufindex--;
					i = -1;
				} else {
					char* line = new char[i+1];
					memset(line, 0, i+1);
					memcpy(line, textbuf, i);
					line[i] = 0;
					uchar backup[sizeof(textbuf)];
					memcpy(backup, textbuf, sizeof(textbuf));
					memset(textbuf, 0, sizeof(textbuf));
					memcpy(textbuf, &backup[i+1], (sizeof(textbuf) - i) - 1);
					bufindex -= i+1;
					if (strlen(line) > 0)
						ProcessCommand(line);
					delete line;
					i = -1;
				}
				break;
			}
			case 8: // backspace
			{
				if (i==0) { // nothin to backspace
					memcpy(textbuf, &textbuf[1], 1023);
					textbuf[1023] = 0;
					bufindex -= 1;
					i = -1;
				} else {
					uchar backup[1024];
					memcpy(backup, textbuf, 1024);
					memset(textbuf, 0, sizeof(textbuf));
					memcpy(textbuf, backup, i-1);
					memcpy(&textbuf[i-1], &backup[i+1], 1022-i);
					bufindex -= 2;
					i -= 2;
				}
				break;
			}
		}
	}
	if (bufindex < 0)
		bufindex = 0;
}

void ConsoleList::SendConsoleWho(const char* to, int8 admin, WorldTCPConnection* connection) {
	LinkedListIterator<Console*> iterator(list);
	iterator.Reset();
	struct in_addr  in;
	int x = 0;

	while(iterator.MoreElements())
	{
		in.s_addr = iterator.GetData()->GetIP();
		connection->SendEmoteMessage(to, 0, 10, "  Console: %s:%i AccID: %i AccName: %s", inet_ntoa(in), iterator.GetData()->GetPort(), iterator.GetData()->AccountID(), iterator.GetData()->AccountName());
		x++;
		iterator.Advance();
	}
		connection->SendEmoteMessage(to, 0, 10, "%i consoles connected", x);
}

Console* ConsoleList::FindByAccountName(const char* accname) {
	LinkedListIterator<Console*> iterator(list);
	iterator.Reset();

	while(iterator.MoreElements()) {
		if (strcasecmp(iterator.GetData()->AccountName(), accname) == 0)
			return iterator.GetData();

		iterator.Advance();
	}
	return 0;
}

void Console::ProcessCommand(const char* command) {
	switch(state)
	{
		case CONSOLE_STATE_USERNAME:
		{
			if (strcmp(command, "*ZONESERVER*") == 0) {
				struct in_addr	in;
				in.s_addr = GetIP();
				if (!database.CheckZoneserverAuth(inet_ntoa(in))) {
					// not auth
					cout << "Zoneserver auth failed: " << inet_ntoa(in) << ":" << port << endl;
					SendMessage(0, "Not Authorized.");
					state = CONSOLE_STATE_CLOSED;
				} else {
					ZoneServer* zs = new ZoneServer(ip, port, send_socket);
					cout << "New zoneserver: #" << zs->GetID() << " " << inet_ntoa(in) << ":" << port << endl;
					zoneserver_list.Add(zs);
					numzones++;
					SendMessage(0, "ZoneServer Mode");
					state = CONSOLE_STATE_ZS;
				}
				return;
			} else {
				if (strlen(command) >= 16) {
					SendMessage(1, 0);
					SendMessage(2, "Username buffer overflow.");
					SendMessage(1, "Bye Bye.");
					state = CONSOLE_STATE_CLOSED;
					return;
				}
				strcpy(paccountname, command);
				state = CONSOLE_STATE_PASSWORD;
				SendMessage(0, "Password: ");
			}
			break;
		}
		case CONSOLE_STATE_PASSWORD:
		{
			if (strlen(command) >= 16) {
				SendMessage(1, 0);
				SendMessage(2, "Password buffer overflow.");
				SendMessage(1, "Bye Bye.");
				state = CONSOLE_STATE_CLOSED;
				return;
			}
//		cout << "TCP command: Password=\"" << command << "\"" << endl;
			// check UN/PW here
			paccountid = database.CheckLogin(paccountname,command);
			if (paccountid == 0) {
				SendMessage(1, 0);
				SendMessage(2, "Login failed.");
				SendMessage(1, "Bye Bye.");
				state = CONSOLE_STATE_CLOSED;
				return;
			}
			database.GetAccountName(paccountid, paccountname); // fixes case and stuff
			admin = database.CheckStatus(paccountid);
			if (!(admin >= 100)) {
				SendMessage(1, 0);
				SendMessage(2, "Access denied.");
				SendMessage(1, "Bye Bye.");
				state = CONSOLE_STATE_CLOSED;
				return;
			}
			cout << "TCP console authenticated: Username=" << paccountname << ", Admin=" << (int16) admin << endl;
			SendMessage(1, 0);
			SendMessage(2, "Login accepted.");
			state = CONSOLE_STATE_CONNECTED;
			SendPrompt();
			break;
		}
		case CONSOLE_STATE_CONNECTED:
		{
			cout << "TCP command: " << paccountname << ": \"" << command << "\"" << endl;
			Seperator sep(command);
			if (strcasecmp(sep.arg[0], "help") == 0 || strcmp(sep.arg[0], "?") == 0) {
				SendMessage(1, "  who");
				SendMessage(1, "  zonestatus");
				SendMessage(1, "  broadcast [message]");
				SendMessage(1, "  emote [zonename or charname or world] [type] [message]");
				if (admin >= 150) {
					SendMessage(1, "  kick [charname]");
					SendMessage(1, "  lock/unlock");
					SendMessage(1, "  zoneshutdown [zonename or ZoneServerID]");
					SendMessage(1, "  zonebootup [ZoneServerID] [zonename]");
				}
				if (admin >= 200) {
					SendMessage(1, "  version");
					SendMessage(1, "  worldshutdown");
				}
			}
			else if (strcasecmp(sep.arg[0], "broadcast") == 0) {
				char tmpname[64];
				tmpname[0] = '*';
				strcpy(&tmpname[1], paccountname);
				zoneserver_list.SendChannelMessage(tmpname, 0, 6, 0, sep.argplus[1]);
			}
			else if (strcasecmp(sep.arg[0], "emote") == 0) {
				if (strcasecmp(sep.arg[1], "world") == 0)
					zoneserver_list.SendEmoteMessage(0, 0, atoi(sep.arg[2]), sep.argplus[3]);
				else {
					ZoneServer* zs = zoneserver_list.FindByName(sep.arg[1]);
					if (zs != 0)
						zs->SendEmoteMessage(0, 0, atoi(sep.arg[2]), sep.argplus[3]);
					else
						zoneserver_list.SendEmoteMessage(sep.arg[1], 0, atoi(sep.arg[2]), sep.argplus[3]);
				}
			}
			else if (strcasecmp(sep.arg[0], "kick") == 0 && admin >= 150) {
				char tmpname[64];
				tmpname[0] = '*';
				strcpy(&tmpname[1], paccountname);
				ServerPacket* pack = new ServerPacket;
				pack->opcode = ServerOP_KickPlayer;
				pack->size = sizeof(ServerKickPlayer_Struct);
				pack->pBuffer = new uchar[pack->size];
				ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
				strcpy(skp->adminname, tmpname);
				strcpy(skp->name, sep.arg[1]);
				skp->adminrank = this->Admin();
				zoneserver_list.SendPacket(pack);
				delete pack;
			}
			else if (strcasecmp(sep.arg[0], "who") == 0) {
				Who_All_Struct* whom = new Who_All_Struct;
				memset(whom, 0, sizeof(Who_All_Struct));
				whom->firstlvl = 0xFFFF;
				whom->secondlvl = 0xFFFF;
				whom->wclass = 0xFFFF;
				whom->wrace = 0xFFFF;
				whom->gmlookup = 0xFFFF;
				zoneserver_list.SendWhoAll(0, admin, whom, this);
				delete whom;
			}
			else if (strcasecmp(sep.arg[0], "zonestatus") == 0) {
				zoneserver_list.SendZoneStatus(0, admin, this);
			}
			else if (strcasecmp(sep.arg[0], "exit") == 0 || strcasecmp(sep.arg[0], "quit") == 0) {
				SendMessage(1, "Bye Bye.");
				state = CONSOLE_STATE_CLOSED;
			}
			else if (strcasecmp(sep.arg[0], "zoneshutdown") == 0 && admin >= 150) {
				if (sep.arg[1][0] == 0) {
					SendMessage(1, "Usage: zoneshutdown zoneshortname");
				} else {
					char tmpname[64];
					tmpname[0] = '*';
					strcpy(&tmpname[1], paccountname);

					ServerPacket* pack = new ServerPacket;
					pack->size = sizeof(ServerZoneStateChange_struct);
					pack->pBuffer = new uchar[pack->size];
					memset(pack->pBuffer, 0, sizeof(ServerZoneStateChange_struct));
					ServerZoneStateChange_struct* s = (ServerZoneStateChange_struct *) pack->pBuffer;
					pack->opcode = ServerOP_ZoneShutdown;
					strcpy(s->adminname, tmpname);
					if (sep.arg[1][0] >= '0' && sep.arg[1][0] <= '9')
						s->ZoneServerID = atoi(sep.arg[1]);
					else
						s->zoneid = database.GetZoneID(sep.arg[1]);

					ZoneServer* zs = 0;
					if (s->ZoneServerID != 0)
						zs = zoneserver_list.FindByID(s->ZoneServerID);
					else if (s->zoneid != 0)
						zs = zoneserver_list.FindByName(database.GetZoneName(s->zoneid));
					else
						SendMessage(1, "Error: ZoneShutdown: neither ID nor name specified");

					if (zs == 0)
						SendMessage(1, "Error: ZoneShutdown: zoneserver not found");
					else
						zs->SendPacket(pack);

					delete pack;
				}
			}
			else if (strcasecmp(sep.arg[0], "zonebootup") == 0 && admin >= 150) {
				if (sep.arg[2][0] == 0 || !sep.IsNumber(1)) {
					SendMessage(1, "Usage: zonebootup ZoneServerID# zoneshortname");
				} else {
					char tmpname[64];
					tmpname[0] = '*';
					strcpy(&tmpname[1], paccountname);

					cout << "Console ZoneBootup: " << tmpname << ", " << sep.argplus[2] << ", " << sep.arg[1] << endl;
					ZSList::SOPZoneBootup(tmpname, atoi(sep.arg[1]), sep.argplus[2]);
				}
			}
			else if (strcasecmp(sep.arg[0], "worldshutdown") == 0 && admin >= 200) {
				ServerPacket* pack = new ServerPacket(ServerOP_ShutdownAll);
				zoneserver_list.SendPacket(pack);
				delete pack;
				zoneserver_list.Process();
				SendMessage(1, "Sending shutdown packet... goodbye.");
				CatchSignal(0);
			}
			else if (strcasecmp(sep.arg[0], "lock") == 0) {
				net.world_locked = true;
				if (loginserver.Connected()) {
					loginserver.SendStatus();
					SendMessage(1, "World locked.");
				}
				else {
					SendMessage(1, "World locked, but login server not connected.");
				}
			}
			else if (strcasecmp(sep.arg[0], "unlock") == 0) {
				net.world_locked = false;
				if (loginserver.Connected()) {
					loginserver.SendStatus();
					SendMessage(1, "World unlocked.");
				}
				else {
					SendMessage(1, "World unlocked, but login server not connected.");
				}
			}
			else if (strcasecmp(sep.arg[0], "version") == 0 && admin >= 200) {
			SendMessage(1, "Current version information.");
			SendMessage(1, "  %s", CURRENT_WORLD_VERSION);
			SendMessage(1, "  Compiled on: %s at %s", COMPILE_DATE, COMPILE_TIME);
			SendMessage(1, "  Last modified on: %s", LAST_MODIFIED);
			}
			else if (strcasecmp(sep.arg[0], "serverinfo") == 0 && admin >= 200) {
				if (strcasecmp(sep.arg[1], "os") == 0)	{
				#ifdef WIN32
					GetOS();
					char intbuffer [sizeof(unsigned long)];
					SendMessage(1, "Operating system information.");
					SendMessage(1, "  %s", Ver_name);
					SendMessage(1, "  Build number: %s", ultoa(Ver_build, intbuffer, 10));
					SendMessage(1, "  Minor version: %s", ultoa(Ver_min, intbuffer, 10));
					SendMessage(1, "  Major version: %s", ultoa(Ver_maj, intbuffer, 10));
					SendMessage(1, "  Platform Id: %s", ultoa(Ver_pid, intbuffer, 10));
				#else
					char os_string[100];
					SendMessage(1, "Operating system information.");
					SendMessage(1, "  %s", GetOS(os_string));
				#endif
				}
				else {
					SendMessage(1, "Usage: Serverinfo [type]");
					SendMessage(1, "  OS - Operating system version information.");
				}
			}
			else {
				SendMessage(1, "Command unknown.");
			}
			if (state == CONSOLE_STATE_CONNECTED)
				SendPrompt();
			break;
		}
		default: {
			break;
		}
	}
}

void Console::SendPrompt() {
	SendMessage(0, "%s> ", paccountname);
}
