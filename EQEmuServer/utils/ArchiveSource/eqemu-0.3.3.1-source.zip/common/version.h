#ifndef VERSION_H
#define VERSION_H

#define CURRENT_CHAT_VERSION	"EqEmu 0.3.3.1 Chat Server - [Alptraum-Ende]"
#define CURRENT_ZONE_VERSION	"EqEmu 0.3.3.1 Zoneserver - [Alptraum-Ende]"
#define CURRENT_WORLD_VERSION   "EqEmu 0.3.3.1 Worldserver - [Alptraum-Ende]"
#define CURRENT_VERSION			"0.3.3.1"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
	#define LAST_MODIFIED	__TIME__
#else
	#define LAST_MODIFIED	__TIMESTAMP__
#endif

#endif

