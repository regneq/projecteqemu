#ifndef TCP_CONNECTION_H
#define TCP_CONNECTION_H
/*
  Parent classes for interserver TCP Communication.
  -Quagmire
*/

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp

	#include <process.h>
#else
	#include <pthread.h>
        #include <sys/socket.h>
        #include <netinet/in.h>
        #include <arpa/inet.h>
        #include <netdb.h>
        #include <unistd.h>
        #include <errno.h>
        #include <fcntl.h>
	#define INVALID_SOCKET -1
	#define SOCKET_ERROR -1
	#include "../common/unix.h"

#endif

#include "../common/types.h"
#include "../common/Mutex.h"
#include "../common/linked_list.h"
#include "../common/queue.h"

class Timer;
class ServerPacket;
struct SPackSendQueue;

class TCPConnection;

#define TCPConnection_ErrorBufferSize 1024

#define TCPS_Ready			0
#define TCPS_Connecting		1
#define TCPS_Connected		100
#define TCPS_Disconnecting	200
#define TCPS_Disconnected	201
#define TCPS_Closing		250
#define TCPS_DeleteMe		255

int32 ResolveIP(const char* hostname, char* errbuf = 0);
#ifdef WIN32
	void TCPListenerLoop(void* tmp);
	void TCPOutgoingLoop(void* tmp);
#else
	void* TCPListenerLoop(void* tmp);
	void* TCPOutgoingLoop(void* tmp);
#endif

/*
  TCPListener:
    Sets up and handels everything associated with incomming TCP connections.
	Expects to be worked from 2 seperate yet equally important threads,
	the NProcess which sends and and receives the packets, and the PProcess
	which Processes the packets.
	These are their functions.

    While based in part on true TCP servers, the functions and variables
	presented here do not represent any actual server or code.


    The template class is expected to be TCPConnection or a child class thereof.
*/

class TCPListener2 {
public:
	TCPListener2(int16 in_port);
	virtual ~TCPListener2();

	void Process(); // Call this in the main application loop

	bool	Init(int16 in_port = 0, char* errbuf = 0);	// open listening socket
	bool	IsInit()	{ return (listeningsocket != 0); }
	void	Close();					// close listening socket
	void	KillAll();					// Disconnect everybody
	void	SendPacket(ServerPacket* pack);
protected:
	// Functions and variables for use by TCPListenerLoop
	#ifdef WIN32
	friend void TCPListenerLoop(void* tmp);
	#else
        friend void* TCPListenerLoop(void* tmp);
	#endif
	
	void	NetProcess();
	bool	RunLoop();
	Mutex	MLoopRunning;

	// Functions for the child class TCPListener
#ifdef WIN32
	virtual TCPConnection* MakeNewConn(int32 in_ID, SOCKET in_socket, int32 in_ip, int16 in_port) { return 0; }
#else
	virtual TCPConnection* MakeNewConn(int32 in_ID, int in_socket, int32 in_ip, int16 in_port) { return 0; }
#endif
private:
	Mutex	MRunLoop;
	bool	pRunLoop;

	void	ListenNewConnections();
	int32	GetNextID() { return NextID++; }

	int32	NextID;
	int16	listenport;
	LinkedList<TCPConnection*> list;
	Mutex	MListModLock;
#ifdef WIN32
	SOCKET	listeningsocket;
#else
	int		listeningsocket;
#endif
};

template<class T> 
class TCPListener : public TCPListener2 {
// Was having an assload of trouble with the templates, so did this
public:
	TCPListener(int16 in_port = 0);
protected:
#ifdef WIN32
	virtual TCPConnection* MakeNewConn(int32 in_ID, SOCKET in_socket, int32 in_ip, int16 in_port) { return new T(in_ID, in_socket, in_ip, in_port); }
#else
	virtual TCPConnection* MakeNewConn(int32 in_ID, int in_socket, int32 in_ip, int16 in_port) { return new T(in_ID, in_socket, in_ip, in_port); }
#endif
};

template<class T> 
TCPListener<T>::TCPListener(int16 in_port) 
 : TCPListener2(in_port) {
}


/*
  TCPConnection:
    Expected to be the parent class for your actual objects.

    SendRecvData() is expected to be called from the TCPListenerLoop thread.
    Process() is expected to be called from TCPListner::Process() from a different thread.
    SendPacket() should be safe to call from any thread.
*/
enum eConnectionType {Incomming, Outgoing};
class TCPConnection {
public:
	// to be used from TCPListener
#ifdef WIN32
	TCPConnection(int32 in_ID, SOCKET in_socket, int32 in_ip, int16 in_port);
#else
	TCPConnection(int32 in_ID, int in_socket, int32 in_ip, int16 in_port);
#endif

	// to be used for outgoing connections
	TCPConnection();

	virtual ~TCPConnection();

	int32		GetIP()		{ return ip; }
	int16		GetPort()	{ return port; }

	int8		GetState();
	inline bool	Connected()	{ return (GetState() == TCPS_Connected); }
	bool		NetConnected();
	bool		SendPacket(ServerPacket* pack);
	bool		SendRawData(uchar* data, int32 size);

	bool		Connect(int32 in_ip, int16 in_port, char* errbuf = 0);
	void		Disconnect();

	virtual	bool	Process();
	// Functions for TCPListener to call
	bool	NetProcess();
	void	SetState(int8 in_state);
protected:
	// Functions for child classes
	ServerPacket* ServerRecvQueuePop();
#ifdef WIN32
	void	SetSocket(SOCKET sock)	{ connection_socket = sock; }
	SOCKET	GetSocket()				{ return connection_socket; }
#else
	void	SetSocket(int sock)		{ connection_socket = sock; }
	int		GetSocket()				{ return connection_socket; }
#endif

	// Stuff for threading, only used when in Outgoing mode
	#ifdef WIN32
	friend	void TCPOutgoingLoop(void* tmp);
	#else
	friend	void* TCPOutgoingLoop(void* tmp);
	#endif

	bool	RunLoop();
	Mutex	MLoopRunning;
private:
	Mutex	MRunLoop;
	bool	pRunLoop;

	virtual void	ProcessReceivedData();
	bool	RecvData();
	bool	SendData(char* errbuf = 0);

	Mutex	MConnectionState;
	int8	connection_state;

	eConnectionType ConnectionType;
	int32	ID;
	int32	ip;
	int16	port;
#ifdef WIN32
	SOCKET	connection_socket;
#else
	int		connection_socket;
#endif
	Timer*	keepalive_timer;
	int8	timeout_counter;

	uchar*	recvbuf;
	int32	recvbuf_size;
	int32	recvbuf_used;

	uchar*	sendbuf;
	int32	sendbuf_size;
	int32	sendbuf_used;

	Mutex					MRecvQueue;
	MyQueue<ServerPacket>	ServerRecvQueue;
	void					ServerRevcQueuePush(ServerPacket* pack);

	Mutex	MSendQueue;
	bool	ServerSendQueuePop(uchar** data, int32* size);
	void	ServerSendQueuePushEnd(uchar* data, int32 size);
	void	ServerSendQueuePushFront(uchar* data, int32 size);
};

#endif
