#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "LoginServer.h"
#include "zoneserver.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];
extern ZSList zoneserver_list;
extern LoginServer loginserver;
extern uint32 numclients;

Client::Client(EQNetworkConnection* ieqnc) {
	eqnc = ieqnc;
	ip = eqnc->GetrIP();
	port = ntohs(eqnc->GetrPort());

	autobootup_timeout = new Timer(10000);
	autobootup_timeout->Disable();
	
	account_id = 0;

	memset(zone_name, 0, sizeof(zone_name));
	char_name[0] = 0;
	pwaitingforbootup = 0;
	numclients++;
}

Client::~Client() {
	eqnc->Delete();
	safe_delete(autobootup_timeout);
	numclients--;
}

void Client::SendCharInfo() {
	APPLAYER *outapp;
	outapp = new APPLAYER(OP_SendCharInfo, sizeof(CharacterSelect_Struct));
	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(account_id, cs_struct);

	QueuePacket(outapp);
	delete outapp;
}

bool Client::Process() {
	bool ret = true;
	bool sendguilds = true;
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;

	if (autobootup_timeout->Check()) {
		ZoneUnavail();
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(ret && (app = eqnc->PopPacket()))
	{
		switch(app->opcode)
		{
		case OP_SendLoginInfo:
		{

			// Quagmire - max len for name is 18, pass 15
			char name[19];
			char password[16];
			memset(name, 0, sizeof(name));
			memset(password, 0, sizeof(password));

			strncpy(name, (char*)app->pBuffer, 18);
			if (app->size < strlen(name)+2) {
				ret = false;
				break;
			}
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 15);

//cerr << "u='" << name << "', p='" << password << "'" << endl;
			if (strncasecmp(name, "LS#", 3) == 0) {
				if (loginserver.Connected() == false) {
					cout << "Error: Login server login while not connected to login server." << endl;
					ret = false;
					break;
				}
				LSAuth_Struct* lsa = 0;
				if (lsa = loginserver.CheckAuth(atoi(&name[3]), password)) {
//cout << "Client from LS: id=" << lsa->lsaccount_id << ", n=" << lsa->name << ", k=" << lsa->key << endl;
					account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
					if (account_id == 0) {
						database.CreateAccount(lsa->name, "", 0, lsa->lsaccount_id);
						account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
						if (account_id == 0) {
							// TODO: Find out how to tell the client wrong username/password
							cerr << "Error adding local account for LS login: '" << lsa->name << "', duplicate name?" << endl;
							ret = false;
							break;
						}
					}
					sendguilds = lsa->firstconnect;
					lsa->firstconnect = false;
//					loginserver.RemoveAuth(lsa->lsaccount_id);
//cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << ", k=" << password << endl;
					cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << endl;
				}
				else {
					// TODO: Find out how to tell the client wrong username/password
//cerr << "Bad/expired session key: " << name << ", k=" << password << endl;
					cerr << "Bad/expired session key: " << name << endl;
					ret = false;
					break;
				}
			}
			else if (strlen(password) <= 1) {
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Login without a password" << endl;
				ret = false;
				break;
			}
			else {
				account_id = database.CheckLogin(name,password);
				if (account_id == 0)
				{
					// TODO: Find out how to tell the client wrong username/password
					struct in_addr	in;
					in.s_addr = ip;
					cerr << inet_ntoa(in) << ": Wrong name/pass: name='" << name << "'" << endl;
					ret = false;
					break;
				}
cout << "Logged in: Local: " << name << endl;
			}
			admin = database.CheckStatus(account_id);

			APPLAYER *outapp;

#if FALSE
			int8 blah[544] = {	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x67, 0x5D, 0xBC, 0x21, 0x18, 0x4E, 0x5A, 0x25, 0x87, 0x1A, 0x7A, 0xE1, 0x54, 0x73, 0xD3, 0x9C, 0xDB, 0x01, 0xBB, 0xF0, 0xF9, 0x2A, 0xA2, 0xFE, 0x9D, 0x86, 0x2A, 0xF3, 0xC9, 0x7D, 0x2E, 0x42, 0x17, 0x51, 0x58, 0xB6, 0x06, 0xCE, 0xE0, 0x38, 0x01, 0xCB, 0x0F, 0xF5, 0x45, 0xE8, 0xF1, 0xBF, 0x30, 0xE7, 0x31, 0x1E, 0x1F, 0xEC, 0xC7, 0xDC, 
								0x77, 0x6F, 0x7E, 0xF5, 0xEC, 0x45, 0x35, 0x6D, 0xD2, 0x7B, 0x5D, 0xEA, 0xA8, 0xCC, 0xE0, 0x1E, 0xE3, 0xCD, 0xEA, 0x1B, 0x4A, 0xA3, 0x02, 0xC3, 0x0A, 0x11, 0x0B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x51, 0xC3, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
								0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00 };
			outapp = new APPLAYER(0xe521, sizeof(blah));
			memcpy(outapp->pBuffer, blah, sizeof(blah));
			QueuePacket(outapp);
			delete outapp;
#endif

			outapp = new APPLAYER(0x0710, 1);
			QueuePacket(outapp);
			delete outapp;

			outapp = new APPLAYER(0x0180, 1);
			QueuePacket(outapp);
			delete outapp;

			// Quagmire - Enabling expansions. Pretty sure this is bitwise
			outapp = new APPLAYER(OP_ExpansionInfo, 4);
			char tmp[4];
			outapp->pBuffer[0] = 7;
			if (database.GetVariable("Expansions", tmp, 3)) {
				outapp->pBuffer[0] = atoi(tmp);
			}
			QueuePacket(outapp);
			delete outapp;

			if (sendguilds) {
cout << "Sending list of guilds" << endl;
				// Quagmire - tring to send list of guilds
				outapp = new APPLAYER(OP_GuildsList, sizeof(GuildsList_Struct));
				GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

				for (int i=0; i < 512; i++) {
					gl->Guilds[i].guildID = 0xFFFFFFFF;
					gl->Guilds[i].unknown1[0] = 0xFF;
					gl->Guilds[i].unknown1[1] = 0xFF;
					gl->Guilds[i].unknown1[2] = 0xFF;
					gl->Guilds[i].unknown1[3] = 0xFF;
					gl->Guilds[i].exists = 0;
					gl->Guilds[i].unknown3[0] = 0xFF;
					gl->Guilds[i].unknown3[1] = 0xFF;
					gl->Guilds[i].unknown3[2] = 0xFF;
					gl->Guilds[i].unknown3[3] = 0xFF;
					if (guilds[i].databaseID != 0) {
						gl->Guilds[i].guildID = i;
						strcpy(gl->Guilds[i].name, guilds[i].name);
						gl->Guilds[i].exists = 1;
					}
				}
				
				QueuePacket(outapp);
				delete outapp;
			}

			// We are logging in and want to see character select
			SendCharInfo();
		    break;
		}
		case 0x8B20: //Name approval
		{
			if (account_id == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				ret = false;
				break;
			}
		    char name[64];
			snprintf(name, 64, "%s", (char*)app->pBuffer);
		    uchar race = app->pBuffer[32];
		    uchar clas = app->pBuffer[36];

		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = 0x8B20;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.CheckNameFilter(name)) {
				outapp->pBuffer[0] = 0;
			}
			else if (database.ReserveName(account_id, name)) {
				outapp->pBuffer[0] = 1;
			}
			else {
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;
		    break;			
		}
		case OP_CharacterCreate: //Char create
		{
			if (account_id == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				ret = false;
				break;
			}
			// Quag: This packet seems to be the PlayerProfile struct w/o the space for the checksum at the beginning
			// Scruffy: And some of the end data. *shrug*
			if (app->size != sizeof(PlayerProfile_Struct) - 8) {
				cout << "Wrong size on OP_CharacterCreate. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) - 8 << endl;
				//break;
			}
			// TODO: Sanity check in data
			PlayerProfile_Struct cc;
			memset(&cc, 0, sizeof(PlayerProfile_Struct));
			memcpy((char*) &cc.unknown0004, app->pBuffer, sizeof(PlayerProfile_Struct) - 8);
			//These defines do not exist in PlayerProfile anymore...
			//memset(cc.invitemproperties,0,sizeof(cc.invitemproperties));
			//memset(cc.bagitemproperties,0,sizeof(cc.bagitemproperties));
			//memset(cc.cursorbagitemproperties,0,sizeof(cc.cursorbagitemproperties));
			//memset(cc.bankinvitemproperties,0,sizeof(cc.bankinvitemproperties));
			//memset(cc.bankbagitemproperties,0,sizeof(cc.bankbagitemproperties));

			/* Clearing Unknown Variables */
			memset(cc.unknown0004, 0, sizeof(cc.unknown0004));
			cc.unknown0141 = 0;
			memset(cc.unknown0145, 0, sizeof(cc.unknown0145));
			cc.unknown0147 = 0;
			cc.unknown0149 = 0;
			memset(cc.unknown0150, 0, sizeof(cc.unknown0150));
			memset(cc.unknown0178, 0, sizeof(cc.unknown0178));
			memset(cc.unknown0180, 0, sizeof(cc.unknown0180));
			memset(cc.unknown0310, 0, sizeof(cc.unknown0310));
			memset(cc.unknown2374, 0, sizeof(cc.unknown2374));
			memset(cc.unknown2920, 0, sizeof(cc.unknown2920));
			memset(cc.unknown2956, 0, sizeof(cc.unknown2956));
			memset(cc.unknown3134, 0, sizeof(cc.unknown3134));
			memset(cc.unknown3448, 0, sizeof(cc.unknown3448));
			memset(cc.unknown3656, 0, sizeof(cc.unknown3656));
			memset(cc.unknown4736, 0, sizeof(cc.unknown4736));
			memset(cc.unknown4740, 0, sizeof(cc.unknown4740));
			cc.unknown4756 = 0;
			cc.unknown4756 = 0;
			//cc.unknown4758 = 0;
			memset(cc.unknown4760, 0, sizeof(cc.unknown4760));
			memset(cc.unknown5225, 0, sizeof(cc.unknown5225));
			/* ************************** */

			//Lyenu - This is the call to add starting items
			database.SetStartingItems(&cc, (int16)cc.race, (int8)cc.class_, (char*)&cc.name, (int)admin); 


			//If the player has a 100+ avatar level, flag the character GM automagically.
			if(admin>=100) {
				cc.gm=1;
			}

			//If server is PVP by default, make all character set to it.
			if(database.GetServerType() == 1)
				cc.pvp = 1;
			else
				cc.pvp = 0;

/*		    char name[64];
		    strncpy(name, cc->name, 16);

			int16 gender = cc->gender;
			int16 race = cc->race;
			int16 class_ = cc->class_;
			int8 face = cc->face;
			int8 str = cc->STR;
			int8 sta = cc->STA;
			int8 cha = cc->CHA;
			int8 dex = cc->DEX;
			int8 int_ = cc->INT;
			int8 agi = cc->AGI;
			int8 wis = cc->WIS; // TODO: Find out where deity,face and starting location is located
*/
//			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			if (!database.CreateCharacter(account_id, &cc))
			{
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp = new APPLAYER(0x8B20, 1);
				outapp->pBuffer[0] = 0;
				QueuePacket(outapp);
				delete outapp;
				ret = false;
				break;
			}

			cout << "Char create:" << cc.name << endl;
			SendCharInfo();

		    break;
		}
		case 0x0180: // Enter world
		{
			if (account_id == 0)
			{
				cerr << "Enter world with no logged in account" << endl;
				eqnc->Close();
				QueuePacket(0);
				break;
			}
            strncpy(char_name,(char*)app->pBuffer,64);

			// Make sure this account owns this character
			if (database.GetAccountIDByChar(char_name) != account_id)
			{
				cerr << "This account does not own this character" << endl;
				eqnc->Close();
				QueuePacket(0);
				break;
			}

			PlayerProfile_Struct pp;
			if (database.GetPlayerProfile(account_id, char_name, &pp) == 0)
			{
				cerr << "Could not get PlayerProfile for " << char_name << endl;
				eqnc->Close();
				QueuePacket(0);
				break;
			}
			if (pp.current_zone == 0 || !database.GetSafePoints(pp.current_zone)) {
				// This is to save people in an invalid zone, once it's removed from the DB
				pp.current_zone = database.GetZoneID("arena");
				pp.x = -1;
				pp.y = -1;
				pp.z = -1;
				database.SetPlayerProfile(account_id, char_name, &pp);
			}
			strcpy(zone_name, database.GetZoneName(pp.current_zone));

			APPLAYER *outapp;
			outapp = new APPLAYER(0xdd21); // This is message of the day?
			char tmp[500];
			if (database.GetVariable("MOTD", tmp, 500)) {
				outapp->size = strlen(tmp)+1;
				outapp->pBuffer = new uchar[outapp->size];
				strcpy((char*)outapp->pBuffer, tmp);
			} else {
				//char DefaultMOTD[] = "Welcome to EQ Emu(tm)!";
				//outapp->size = strlen(DefaultMOTD) + 1;
				//outapp->pBuffer = new uchar[outapp->size];
				//strcpy((char*)outapp->pBuffer, DefaultMOTD);
				// Null Message of the Day. :)
				outapp->size = 1;
				outapp->pBuffer = new uchar[outapp->size];
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;

			EnterWorld();
			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
				ret = false;
				break;
			}
			SendCharInfo();
			break;
		}
		case 0x3521:
		case 0x3921: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			break;
		}
		default: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app);
			break;
		}
		}

		delete app;
	}    

	if (!eqnc->CheckActive()) {
		cout << "Client disconnected" << endl;
		return false;
	}

	return ret;
}

void Client::EnterWorld(bool TryBootup) {
	int16 zone_port;
	char zone_address[255];

	if (strlen(zone_name) == 0)
		return;

	ZoneServer* zs = zoneserver_list.FindByName(zone_name);
	if (zs) {
		// warn the world we're comming, so it knows not to shutdown
		zs->TriggerBootup();
	}
	else {
		if (TryBootup) {
			int32 x = database.CommandRequirement("$MAXCLIENTS");
			printf("Maxclients: %i\n",x);
			if(numclients >= x && x != -1 && x != 255) {
				ZoneUnavail();
			}
			else {
				autobootup_timeout->Start();
				cout << "Attempting autobootup of '" << zone_name << "' for " << char_name << endl;
				if (!(pwaitingforbootup = zoneserver_list.TriggerBootup(zone_name))) {
					cout << "Error: No zoneserver to bootup '" << zone_name << "' for " << char_name << endl;
					ZoneUnavail();
				}
			}
			return;
		}
		else {
			cout << "Error: Player '" << char_name << "' requested zone status for '" << zone_name << "' but it's not up." << endl;
			ZoneUnavail();
			return;
		}
	}
	pwaitingforbootup = 0;
	cout << "Enter world: " << char_name << ": " << zone_name << endl;
	database.SetAuthentication(account_id, char_name, zone_name, ip);

	APPLAYER* outapp = new APPLAYER;
	outapp->opcode = OP_ZoneServerInfo;//0x0480;
	outapp->pBuffer = new uchar[130];
	outapp->size = 130;
//	strcpy((char*) outapp->pBuffer,     zone_address);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	strcpy((char*)&outapp->pBuffer[75], zone_name);
	int16 *temp = (int16*)&outapp->pBuffer[128];
//	*temp = ntohs(zone_port);
	*temp = ntohs(zs->GetCPort());

	QueuePacket(outapp);
	delete outapp;
}

void Client::ZoneUnavail() {
	memset(zone_name, 0, sizeof(zone_name));
	pwaitingforbootup = 0;
	autobootup_timeout->Disable();
	APPLAYER* outapp = new APPLAYER(OP_ZoneUnavail, sizeof(ZoneUnavail_Struct));
	ZoneUnavail_Struct* ua = (ZoneUnavail_Struct*)outapp->pBuffer;
	strcpy(ua->zonename, zone_name);
	QueuePacket(outapp);
	delete outapp;
}

void Client::QueuePacket(APPLAYER* app, bool ack_req) {
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size >= 31500) {
			cout << "WARNING: abnormal packet size. o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	eqnc->QueuePacket(app, ack_req);
}

ClientList::ClientList() {
}

ClientList::~ClientList() {
}

void ClientList::Add(Client* client) {
	list.Insert(client);
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			Client* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

void ClientList::Process() {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << iterator.GetData()->GetPort() << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

void ClientList::ZoneBootup(ZoneServer* zs) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->WaitingForBootup()) {
			if (strcasecmp(iterator.GetData()->GetZoneName(), zs->GetZoneName()) == 0) {
				iterator.GetData()->EnterWorld(false);
			}
			else if (iterator.GetData()->WaitingForBootup() == zs->GetID()) {
				iterator.GetData()->ZoneUnavail();
			}
		}
		iterator.Advance();
	}
}

bool Database::SetStartingItems(PlayerProfile_Struct *cc, int16 si_race, int8 si_class, char* si_name, int GM_FLAG) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	int i = 22;
	MYSQL_RES *result;
	MYSQL_ROW row;
	
	if(GM_FLAG < 100) {
//cout<< "Loading starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 2 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while(row = mysql_fetch_row(result)) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	else {
//cout<< "Loading *GM* starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 0 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while(row = mysql_fetch_row(result)) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
}