#include "../common/debug.h"
#include <iostream.h>
#include <math.h>
#include "../common/moremath.h"
#include <stdio.h>

#ifdef WIN32
	#define snprintf	_snprintf
#else
	#include <stdlib.h>
	#include <pthread.h>
#endif

#include "npc.h"
#include "client.h"
#include "map.h"
#include "entity.h"
#include "spdat.h"

//#define SPELLQUEUE //Use only if you want to be spammed by spell testing

extern Database database;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern EntityList entity_list;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];

NPC::NPC(const NPCType* d, Spawn2* in_respawn, float x, float y, float z, float heading, bool IsCorpse)
: Mob(d->name,
	  d->lastname,
	  d->max_hp,
	  d->max_hp,
	  d->gender,
	  d->race,
	  d->class_,
	  d->deity,
	  d->level,
	  d->npc_id, // rembrant, Dec. 20, 2001
	  d->skills, // socket 12-29-01
	  d->size,
	  d->walkspeed,
	  d->runspeed,
	  heading,
	  x,
	  y,
	  z,
	  d->light,
	  d->equipment,
	  d->texture,
	  d->helmtexture,
	  d->AC,
	  d->ATK,
	  d->STR,
	  d->STA,
	  d->DEX,
	  d->AGI,
	  d->INT,
	  d->WIS,
	  d->CHA,
	  d->haircolor,
	  d->beardcolor,
	  d->eyecolor1,
	  d->eyecolor2,
	  d->hairstyle,
	  d->title,
	  d->luclinface,
	  d->fixedZ,
	  d->d_meele_texture1,
	  d->d_meele_texture2)
{
	NPCTypedata = new NPCType;
	memcpy(NPCTypedata, d, sizeof(NPCType));
	respawn2 = in_respawn;
	
	itemlist = new ItemList();
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
	banishcapability=d->banish;
	max_dmg=d->max_dmg;
	min_dmg=d->min_dmg;
	NPCSpecialAttacks(d->npc_attacks,0);
	NPCDatabaseSpells(d->npc_spells);
	for(int i=0;i < 20; i++)
	{
		NPCSpellTime[i] = 0;
	}
	
	MerchantType=d->merchanttype; // Yodason: merchant stuff
	movement_timer = new Timer(100);
	walking_timer = 0;
	HastePercentage = 0;
	if (zone->map != 0)
		walking_timer  = new Timer(5000);
	org_x = x;
	org_y = y;
	org_z = z;
	org_heading = heading;	
	EntityList::RemoveNumbers(name);
	entity_list.MakeNameUnique(name);
	p_depop = false;
	loottable_id = d->loottable_id;	
	sint32 tmp;
	database.GetNPCPrimaryFaction(this->npctype_id, &faction_id, &tmp);
	ignore_target = 0;
	//spelllimit = 8; // 20 is crashing zone.exe on my box
	ismovinghome = false;
	rooted = false;
	scanarea_timer = new Timer(500);
	spells_timer = new Timer(RandomTimer(12000,65000));
	gohome_timer   = new Timer(5000);
	gohome_timer->Disable();
}

NPC::~NPC()
{
	delete scanarea_timer;
	delete gohome_timer;
	delete movement_timer;
	delete spells_timer;
	safe_delete(walking_timer);
	safe_delete(itemlist);
	safe_delete(NPCTypedata);
}

ServerLootItem_Struct* NPC::GetItem(int slot_id) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	while(iterator.MoreElements())
	{
		ServerLootItem_Struct* item = iterator.GetData();
		if (item->equipSlot == slot_id)
		{
			return item;
		}
		iterator.Advance();
	}
	cout << "no item found for slot: " << slot_id << endl;
	return 0;
}

void NPC::AddItem(const Item_Struct* item, int8 charges, uint8 slot) {
    //cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = item->item_nr;
	(*itemlist).Append(item_data);
}

void NPC::AddItem(int32 itemid, int8 charges, uint8 slot)
{
    //cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = itemid;
	(*itemlist).Append(item_data);
}

void NPC::AddLootTable() {
	if (npctype_id != 0) { // check if it's a GM spawn
		database.AddLootTableToNPC(loottable_id, itemlist, &copper, &silver, &gold, &platinum);
	}
}

void NPC::RemoveItem(uint16 item_id)
{
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->item_nr == item_id)
		{
			const Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}
	
	return;
}

void NPC::ClearItemList() {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	while(iterator.MoreElements()) {
		iterator.RemoveCurrent();
	}
}

void NPC::QueryLoot(Client* to) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	
	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements())
	{
		const Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
		to->Message(0, "  %d: %s", item->item_nr, item->name);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void NPC::AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum)
{
	copper = in_copper;
	silver = in_silver;
	gold = in_gold;
	platinum = in_platinum;
}

void NPC::AddCash()
{
	copper = (rand() % 100)+1;
	silver = (rand() % 50)+1;
	gold = (rand() % 10)+1;
	platinum = (rand() % 5)+1;
}

void NPC::RemoveCash()
{
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
}

int32 NPC::RandomTimer(int min,int max)
{
	int r = 14000;
	if(min != 0 && max != 0 && min < max)
	{
		r = (rand()  % (max - min)) + min;
	}
	return r;
}

bool NPC::Process()
{
	adverrorinfo = 1;
	if (IsStunned() && stunned_timer->Check()) {
		this->stunned = false;
		this->stunned_timer->Disable();
	}
	if (p_depop) {
		Mob* owner = entity_list.GetMob(this->ownerid);
		if (owner != 0) {
			owner->CastToNPC()->SetPetID(0);
			
			this->ownerid = 0;
			this->petid = 0;
		}
		return false;
	}
	adverrorinfo = 2;
	SpellProcess();
	if (tic_timer->Check()) {
		TicProcess();
		if (target == 0)
			this->CheckBuffs();
	}
	
	if (IsStunned()||IsMezzed())
		return true;
	adverrorinfo = 3;
	if ((!this->IsEngaged()) && scanarea_timer->Check() &&(!zone->AggroLimitReached())){  // Merkur 03/11
		if(entity_list.AddHateToCloseMobs(this,160,0))
			zone->AddAggroMob();
	}
	adverrorinfo = 4;
	SetTarget(hate_list.GetTop());
	if (gohome_timer->Check()) {	
		gohome_timer->Disable();
		if (!IsEngaged())
			ismovinghome = true;
	}
	adverrorinfo = 5;	
	if (IsEngaged()){
		if((GetHateTop()->GetLevel() >= banishcapability) && (banishcapability != 0) && GetHateTop()->IsClient())
		{
			GetHateTop()->Message(4,"I shall not fight you, but I shall banish you!");
			GetHateTop()->GoToBind();
			this->RemoveFromHateList(GetHateTop());
		}
	}
	adverrorinfo = 6;
	if((spells_timer->Check() || (IsEngaged() && spells_timer->GetRemainingTime() > 14000)) && !(gohome_timer->Enabled()||ismovinghome))
	{
		if(!IsEngaged()) {
			spells_timer->Start(RandomTimer(100000,240000), true);
			CheckFriendlySpellStatus();
		}
		if(IsEngaged()) {
			spells_timer->Start(RandomTimer(7000,14000), true);
			CheckEnemySpellStatus();
		}
	}
	adverrorinfo = 7;	
	if (target == 0 && this->ownerid != 0) {
		Mob* obc = entity_list.GetMob(this->ownerid);
		SetTarget(obc);
	}
	
	if (casting_spell_id == 0) {
#define NPC_MOVEMENT_PER_TIC		10
		if (target != 0)
		{
			if (movement_timer->Check() && !rooted) 
			{
					adverrorinfo = 8;
				//			movement_timer->Start();
				// NPC can move per "think", this number should be an EQ distance squared				
				float total_move_dist = (float) DistNoRootNoZ(target);
				appearance = 0;
				if (total_move_dist > 75) 
				{
					appearance = 5; 
					total_move_dist -= 50;
					if (total_move_dist > NPC_MOVEMENT_PER_TIC)
						total_move_dist = NPC_MOVEMENT_PER_TIC;
					float x2 = (float) pow(target->GetX() - x_pos, 2);
					float y2 = (float) pow(target->GetY() - y_pos, 2);
					// divide by zero "should" be impossible here because of the DistNoRootNoZ check
					float x_move = (float) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
					float y_move = (float) (total_move_dist - x_move);
					x_pos += (float) sqrt((double)x_move) * sign(target->GetX() - x_pos);
					y_pos += (float) sqrt((double)y_move) * sign(target->GetY() - y_pos);
					// since we don't use maps, we don't know the correct z nut this should do for now
					if (this->IsEngaged())
						z_pos = this->GetHateTop()->GetZ();
					pLastChange = Timer::GetCurrentTime();
				}
				FaceTarget();
				
			}
			if (target->GetID() != this->ownerid && attack_timer->Check() && this->GetHPRatio() > 0) 
			{
				adverrorinfo = 9;
				if(GetHPRatio() >= 51) {
					if(SpecialNPCAttacks[1] == 2)
					{
						SpecialNPCAttacks[1] = 1;
						SpecialNPCCounts[1] = 0;
					}
					if(SpecialNPCAttacks[2] == 2)
					{
						SpecialNPCAttacks[2] = 1;
						SpecialNPCCounts[2] = 0;
					}
					if(SpecialNPCAttacks[3] == 2)
					{
						SpecialNPCAttacks[3] = 1;
						SpecialNPCCounts[3] = 0;
						SpecialNPCCountstwo[3] = 0;
					}
				}
				
				if(GetHPRatio() <= 49) {
					if(SpecialNPCAttacks[1] == 1)
					{
						SpecialNPCCounts[1] += 1;
						if(SpecialNPCCounts[1] >= 2)
						{
							HateSummon();
							SpecialNPCCounts[1] = 0;
						}
					}
				}
				
				if(GetHPRatio() <= 35) {
					if(SpecialNPCAttacks[3] == 1)
					{
						if(SpecialNPCCountstwo[3] == 0)
						{
							entity_list.MessageClose(this,true,800,13,"%s Rampages!",this->GetName());
						}
						SpecialNPCCounts[3] = 1;
						if(SpecialNPCCounts[3] == 1)
						{
							Attack(hate_list.GetRandom());
							SpecialNPCCountstwo[3] += 1;
						}
					}
					if(SpecialNPCCountstwo[3] >= 15)
					{
						entity_list.MessageClose(this,true,800,13,"%s loses the rampage.",this->GetName());
						SpecialNPCAttacks[3] = 2;
						SpecialNPCCountstwo[3] = 0;
					}
				}
				
				if(GetHPRatio() <= 17) {
					if(SpecialNPCAttacks[2] == 1)
					{
						if(SpecialNPCCounts[2] == 0)
						{
							SpecialNPCAttacks[2] = 1;
							entity_list.MessageClose(this,true,800,13,"%s is filled with enragement.",this->GetName());
						}
						SpecialNPCCounts[2] += 1;
						if(SpecialNPCCounts[2] >= 24)
						{
							entity_list.MessageClose(this,true,800,13,"%s enragement subsides.",this->GetName());
							SpecialNPCAttacks[2] = 2;
						}
					}
				}
				adverrorinfo = 10;
				Attack(target);
				pLastChange = Timer::GetCurrentTime();
			}
		}
		else if (ismovinghome)//Go back to bindpoint.. wonder why SendTo don't work for this? - Merkur
		{
			adverrorinfo = 11;
			if (movement_timer->Check()) 
			{
				float total_move_dist = (float) (org_x-x_pos)*(org_x-x_pos)+(org_y-y_pos)*(org_y-y_pos);
				appearance = 0;
				if (total_move_dist > 75)  {
					appearance = 5;
					total_move_dist -= 50;
					if (total_move_dist > NPC_MOVEMENT_PER_TIC/2) // go a bit slower
						total_move_dist = NPC_MOVEMENT_PER_TIC/2;
					float x2 = (float) pow(org_x - x_pos, 2);
					float y2 = (float) pow(org_y - y_pos, 2);
					float x_move = (float) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
					float y_move = (float) (total_move_dist - x_move);
					x_pos += (float) sqrt((double)x_move) * sign(org_x - x_pos);
					y_pos += (float) sqrt((double)y_move) * sign(org_y - y_pos);
					z_pos = org_z;
					float angle;
					if (org_x-x_pos > 0)
						angle = - 90 + atan((double)(org_y-y_pos) / (double)(org_x-x_pos)) * 180 / M_PI;
					else {
						if (org_x-x_pos < 0)	
							angle = + 90 + atan((double)(org_y-y_pos) / (double)(org_x-x_pos)) * 180 / M_PI;
						else { // Added?
							if (org_y-y_pos > 0)
								angle = 0;
							else
								angle = 180;
						}
					}
					if (angle < 0)
						angle += 360;
					if (angle > 360	)
						angle -= 360;
					
					heading	= 256*(360-angle)/360.0f;
					pLastChange = Timer::GetCurrentTime();
				} 
				else {
					appearance = 0;			
					ismovinghome = false;
					pLastChange = Timer::GetCurrentTime();
				}
			}
			
		}
		
		else {
			if (walking_timer && walking_timer->Check()) {
				float delta_x = (rand()%100) - 50;
				float delta_y = (rand()%100) - 50;
				SendTo(org_x + delta_x, org_y + delta_y);
			}
			
		}
	}
	adverrorinfo = 0;
    return true;
}

void NPC::HateSummon() {
	if (IsEngaged()){
		if(SpecialNPCAttacks[1] == 1 && GetHateTop()->IsClient()) {
			GetHateTop()->CastToClient()->Message(15,"You have been summoned!");
			entity_list.MessageClose(this,true,800,13,"%s shouts,'You will not evade me, %s!' ",GetName(),GetHateTop()->GetName()); //Shawn319: Fixed typo
			GetHateTop()->CastToClient()->GMMove(x_pos, y_pos, z_pos, heading); //summon someone
			Attack(GetHateTop()); //Add a little spice to his anger to make it seem serious
			Attack(GetHateTop());
			Attack(GetHateTop());
		}
	}
}

void NPC::FaceTarget(Mob* MobToFace) {
	if (MobToFace == 0)
		MobToFace = target;
	if (MobToFace == 0 || MobToFace == this)
		return;
	// TODO: Simplify?
	
	float angle;
	
	if (MobToFace->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(MobToFace->GetY()-y_pos) / (double)(MobToFace->GetX()-x_pos)) * 180 / M_PI;
	else if (MobToFace->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(MobToFace->GetY()-y_pos) / (double)(MobToFace->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (MobToFace->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
	//cout << "dX:" << MobToFace->GetX()-x_pos;
	//cout << "dY:" << MobToFace->GetY()-y_pos;
	//cout << "Angle:" << angle;
	
	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;
	
	heading = (sint8) (256*(360-angle)/360.0f);
	//	return angle;
	
	//cout << "Heading:" << (int)heading << endl;
}

void NPC::RemoveFromHateList(Mob* mob) {
	appearance = 0;
	if (this->IsEngaged())
	{
		hate_list.RemoveEnt(mob);	
		if  (!this->IsEngaged()){
			this->gohome_timer->Start(5000);
			zone->DelAggroMob();
			cout << "Mobs currently Aggro: " << zone->MobsAggroCount() << endl; 
		}
	}		
}

int32 NPC::CountLoot() {
	if (itemlist == 0)
		return 0;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	int32 count = 0;
	
	iterator.Reset();
	while(iterator.MoreElements())	
	{
		count++;
		iterator.Advance();
	}
	return count;
}

void NPC::DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex) {
	if (itemlist == 0)
		return;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	int32 count = 0;
	
	iterator.Reset();
	while(iterator.MoreElements())	
	{
		npclootdump[*NPCLootindex].npc_dump_index = npcdump_index;
		npclootdump[*NPCLootindex].itemid = iterator.GetData()->item_nr;
		npclootdump[*NPCLootindex].charges = iterator.GetData()->charges;
		npclootdump[*NPCLootindex].equipSlot = iterator.GetData()->equipSlot;
		(*NPCLootindex)++;
		iterator.RemoveCurrent();
	}
}

void NPC::Depop(bool StartSpawnTimer) {
	p_depop = true;
	if (StartSpawnTimer) {
		if (respawn2 != 0) {
			respawn2->Reset();
		}
	}
}

bool NPC::AddQueuedSpell(int spell_id) {
	
	int a = 0;
	for(int i = 0; i < 20; i++) {
		if(NPCSpellTime[i] == spell_id)
			NPCSpellTime[i] = 0;
		
		if(NPCSpellTime[i] == 0 && a == 0 && !FindBuff(spell_id)) {
			NPCSpellTime[i] = spell_id;
#ifdef SPELLQUEUE
			printf("%s: Queue Spell Added: %d\n",GetName(),NPCSpellTime[i]);
#endif
			spells_timer->Start(RandomTimer(14000,35000), true);
			a = 1;
			return true;
		}
	}
	return false;
}

void NPC::NPCUnharmSpell(int spell_id) {
	
	if(FindBuff(spell_id)) {
#ifdef SPELLQUEUE
		printf("NPC already has this buff! (%d)\n",spell_id);
#endif
	}
	else {
		if(casting_spell_id != 0)
			int queue = AddQueuedSpell(spell_id);	
		else {
			if(DatabaseCastAccepted(spell_id)) {
				CastSpell(spell_id,GetID());
#ifdef SPELLQUEUE
				printf("%s is casting spell: %d(%d)\n",GetName(),spell_id,spells[spell_id].unknown_4[1]);
#endif
			}
		}
	}
}

bool NPC::DatabaseCastAccepted(int spell_id) {
	for (int i=0; i < 12; i++) {
		switch(spells[spell_id].effectid[i]) {
		case SE_Stamina: {
			if(IsEngaged() && GetHPRatio() < 100)
				return true;
			else
				return false;
			break;
		}
		case SE_HealOverTime: {
			if(this->GetHPRatio() < 100)
				return true;
			else
				return false;
			break;
		}
		case SE_NecPet:
		case SE_SummonPet: {
			if(GetPetID() != 0){
#ifdef SPELLQUEUE
				printf("%s: Attempted to make a second pet, denied.\n",GetName());
#endif
				return false;
			}
			break;
						   }
		case ST_Corpse: {
			return false; //Pfft, npcs don't need to summon corpses/locate corpses!
			break;
						}
		default:
			if(spells[spell_id].goodEffect == 1 && !spells[spell_id].badEffect && !(spells[spell_id].buffduration == 0 && this->GetHPRatio() == 100))
				return true;
			return false;
		}
	}
}

void NPC::NPCDatabaseSpells(const char* parse) {
	spelllimit = database.CommandRequirement("@NPCSPELLS");
	if(spelllimit <= 0)
		spelllimit = 8;

	if(spelllimit > 20)
		spelllimit = 20;

	Seperator sep(parse, ' ', spelllimit);

#ifdef SPELLQUEUE
	printf("Spells for: %s\n",GetName());
#endif
	for(int i=0; i < spelllimit; i++) {
		NPCSpells[i] = atoi(sep.arg[i]);
		if(atoi(sep.arg[i]) != 0) {
#ifdef SPELLQUEUE
			printf("Spell: %d; ",atoi(sep.arg[i]));
#endif
		}
	}
#ifdef SPELLQUEUE
	printf("\n");
#endif
}

void NPC::NPCHarmSpell(int target,int type) {
	int32* HarmfulSpells = new int32[spelllimit];
	int z = 0;
	for(int i=0; i < spelllimit; i++) {
		int spellid = NPCSpells[i];
		if(spells[spellid].badEffect  && spellid > 0) {
			z++;
			HarmfulSpells[z] = spellid;
#ifdef SPELLQUEUE
			printf("%s: Harmful Spell Added (HarmfulSpells[%d]).\n",GetName(),z);
#endif
		}
	}
	
	//Add types later, just make it pick a random spell...
	if(z != 0) {
		int r = (rand() % z);
#ifdef SPELLQUEUE
		printf("Random: %d\n",r);
#endif	
		if(HarmfulSpells[r] != 0 && r != 0 && casting_spell_id == 0)
			CastSpell(HarmfulSpells[r],target);
	}
	delete [] HarmfulSpells;
}

void NPC::CheckEnemySpellStatus(){
	Mob* hate = hate_list.GetRandom();
#ifdef SPELLQUEUE
	printf("%s: My random hate is %s\n",GetName(),hate->GetName());
#endif
	NPCHarmSpell(hate->GetID(),1);
}

void NPC::CheckFriendlySpellStatus()
{
	int x = 1;
	int a = 1;
	for (int z=0; z < 12; z++) {
		if(NPCSpellTime[z] != 0 && a == 1 && casting_spell_id == 0 && !FindBuff(NPCSpellTime[z])) {
			int id = NPCSpellTime[z];
			NPCSpellTime[z] = 0;
#ifdef SPELLQUEUE
			printf("%s: Queue Spell Removed: %d\n",GetName(),id);
#endif
			NPCUnharmSpell(id);
			x = 0;
			a = 0;
		}
		if(NPCSpellTime[z] != 0) {
			a = 2;
			spells_timer->Start(RandomTimer(14000,35000), true);
		}
	}
	if(a == 0)
	{
#ifdef SPELLQUEUE
		printf("%s: Timer has been reset to 2 minute timer (No more remaining in queue)\n",GetName());
#endif
		spells_timer->Start(RandomTimer(100000,240000),true);
	}
	if(x == 1 && a == 1) {
		for(int i=0; i < spelllimit; i++) {
			int spellid = NPCSpells[i];
			if(spellid > 0)
				NPCUnharmSpell(spellid);
		} 
	}
}

void NPC::NPCSpecialAttacks(const char* parse, int permtag)
{
	switch(*parse) {
	case 'A':
		SpecialNPCAttacks[1] = 1;
		
		SpecialNPCCounts[1] = 0;
		break;
	case 'B':
		SpecialNPCAttacks[2] = 1;
		
		SpecialNPCCounts[2] = 0;
		break;
	case 'C':
		SpecialNPCAttacks[3] = 1;
		
		SpecialNPCCounts[3] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'D':
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[4] = 0;
		break;
	case 'E':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[3] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[3] = 0;
		SpecialNPCCounts[4] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'F':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[2] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[2] = 0;
		break;
	case 'G':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[3] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[3] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'H':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[4] = 0;
		break;
	case 'I':
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[3] = 1;
		
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[3] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'J':
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[4] = 0;
		break;
	case 'K':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[3] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[3] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'L':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[4] = 0;
		break;
	case 'M':
		SpecialNPCAttacks[1] = 1;
		SpecialNPCAttacks[3] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[1] = 0;
		SpecialNPCCounts[3] = 0;
		SpecialNPCCounts[4] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	case 'N':
		SpecialNPCAttacks[2] = 1;
		SpecialNPCAttacks[3] = 1;
		SpecialNPCAttacks[4] = 1;
		
		SpecialNPCCounts[2] = 0;
		SpecialNPCCounts[3] = 0;
		SpecialNPCCounts[4] = 0;
		
		SpecialNPCCountstwo[3] = 0;
		break;
	default:
		for(int i=0 ; i < 4 ; i++)
		{
			SpecialNPCAttacks[i] = 0;
			SpecialNPCCounts[i] = 0;
			SpecialNPCCountstwo[i] = 0;
		}
		break;
	}

	if(permtag == 1 && this->GetNPCTypeID() > 0){
		if(database.SetSpecialAttkFlag(this->GetNPCTypeID(),parse)) {
			printf("NPCTypeID: %i flagged to '%s' for Special Attacks.\n",this->GetNPCTypeID(),parse);
		}
	}
}

void NPC::SendTo(float new_x, float new_y) {
	if (zone->map == 0)
		return;
	
	float angle;
	float dx = new_x-x_pos;
	float dy = new_y-y_pos;
	// 0.09 is a perfect magic number for a human pnj's
	walking_timer->Start((int32) ( sqrt( dx*dx + dy*dy ) * 0.09f ) * 1000 );
	
	if (new_x-x_pos > 0)
		angle = - 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
	else {
		if (new_x-x_pos < 0)	
			angle = + 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
		else { // Added?
			if (new_y-y_pos > 0)
				angle = 0;
			else
				angle = 180;
		}
	}
	if (angle < 0)
		angle += 360;
	if (angle > 360	)
		angle -= 360;
	
	heading	= 256*(360-angle)/360.0f;
	appearance = 5;
	//	SendPosUpdate();
	x_pos = new_x;
	y_pos = new_y;
	
	PNODE pnode  = zone->map->SeekNode( zone->map->GetRoot(), x_pos, y_pos );
	// Quagmire - Not sure if this is the right thing to do, but it stops the crashing
	if (pnode == 0) return;
	
	int  *iface  = zone->map->SeekFace( pnode, x_pos, y_pos );
	while(*iface != -1)
	{
		z_pos = zone->map->GetFaceHeight( *iface, x_pos, y_pos );
		iface++;
	}
}

NPC* NPC::SpawnNPC(const char* spawncommand, float in_x, float in_y, float in_z, float in_heading, Client* client) {
	if(spawncommand == 0 || spawncommand[0] == 0) {
		return 0;
	}
	else {
		Seperator sep(spawncommand);
		//Lets see if someone didn't fill out the whole #spawn function properly 
		sep.arg[0][29] = 0;
		if (!sep.IsNumber(1))
			sprintf(sep.arg[1],"1"); 
		if (!sep.IsNumber(2))
			sprintf(sep.arg[2],"1"); 
		if (!sep.IsNumber(3))
			sprintf(sep.arg[3],"0");
		if (atoi(sep.arg[4]) > 2100000000 || atoi(sep.arg[4]) <= 0)
			sprintf(sep.arg[4],"");
		if (!strcmp(sep.arg[5],"-"))
			sprintf(sep.arg[5],""); 
		if (!sep.IsNumber(5))
			sprintf(sep.arg[5],""); 
		if (!sep.IsNumber(6))
			sprintf(sep.arg[6],"1");
		if (!sep.IsNumber(8))
			sprintf(sep.arg[8],"0");
		if (!sep.IsNumber(9))
			sprintf(sep.arg[9], "0");
		if (!sep.IsNumber(7))
			sprintf(sep.arg[7],"0");
		if (!strcmp(sep.arg[4],"-"))
			sprintf(sep.arg[4],""); 
		//Calc MaxHP if client neglected to enter it...
		if (!sep.IsNumber(4)) {
			//Stolen from Client::GetMaxHP...
			int8 multiplier = 0;
			int tmplevel = atoi(sep.arg[2]);
			switch(atoi(sep.arg[5]))
			{
				case WARRIOR:
					if (tmplevel < 20)
						multiplier = 22;
					else if (tmplevel < 30)
						multiplier = 23;
					else if (tmplevel < 40)
						multiplier = 25;
					else if (tmplevel < 53)
						multiplier = 27;
					else if (tmplevel < 57)
						multiplier = 28;
					else 
						multiplier = 30;
					break;

				case DRUID:
				case CLERIC:
				case SHAMAN:
					multiplier = 15;
					break;

				case PALADIN:
				case SHADOWKNIGHT:
					if (tmplevel < 35)
						multiplier = 21;
					else if (tmplevel < 45)
						 multiplier = 22;
					else if (tmplevel < 51)
						 multiplier = 23;
					else if (tmplevel < 56)
						 multiplier = 24;
					else if (tmplevel < 60)
						 multiplier = 25;
					else
						 multiplier = 26;
					break;

				case MONK:
				case BARD:
				case ROGUE:
		//		case BEASTLORD:
					if (tmplevel < 51)
						multiplier = 18;
					else if (tmplevel < 58)
						multiplier = 19;
					else
						multiplier = 20;				
					break;

				case RANGER:
					if (tmplevel < 58)
						multiplier = 20;
					else
						multiplier = 21;			
					break;

				case MAGICIAN:
				case WIZARD:
				case NECROMANCER:
				case ENCHANTER:
					multiplier = 12;
					break;

				default:
					if (tmplevel < 35)
						multiplier = 21;
					else if (tmplevel < 45)
						multiplier = 22;
					else if (tmplevel < 51)
						multiplier = 23;
					else if (tmplevel < 56)
						multiplier = 24;
					else if (tmplevel < 60)
						multiplier = 25;
					else
						multiplier = 26;
					break;
			}
			sprintf(sep.arg[4],"%i",5+multiplier*atoi(sep.arg[2])+multiplier*atoi(sep.arg[2])*75/300);
		}

		// Autoselect NPC Gender... (Scruffy)
		if (sep.arg[5][0] == 0) {
			sprintf(sep.arg[5], "%i", (int) Mob::GetDefaultGender(atoi(sep.arg[1])));
		}

		if (client) {
			// Well we want everyone to know what they spawned, right? 
			client->Message(0, "New spawn:");
			client->Message(0, "Name: %s",sep.arg[0]);
			client->Message(0, "Race: %s",sep.arg[1]);
			client->Message(0, "Level: %s",sep.arg[2]);
			client->Message(0, "Material: %s",sep.arg[3]);
			client->Message(0, "Current/Max HP: %s",sep.arg[4]);
			client->Message(0, "Gender: %s",sep.arg[5]);
			client->Message(0, "Class: %s",sep.arg[6]);

			client->Message(0, "Weapon Item Number: %s",sep.arg[7]);
			client->Message(0, "MerchantID: %s",sep.arg[8]);
		}
		//Time to create the NPC!! 
		NPCType* npc_type = new NPCType;
		memset(npc_type, 0, sizeof(NPCType));
		strcpy(npc_type->name,sep.arg[0]);
		npc_type->cur_hp = atoi(sep.arg[4]); 
		npc_type->max_hp = atoi(sep.arg[4]); 
		npc_type->race = atoi(sep.arg[1]); 
		npc_type->gender = atoi(sep.arg[5]); 
		npc_type->class_ = atoi(sep.arg[6]); 
		npc_type->deity= 1;
		npc_type->level = atoi(sep.arg[2]);
		npc_type->npc_id = 0;
		npc_type->loottable_id = 0;
		npc_type->texture = atoi(sep.arg[3]);
		npc_type->light = 0;
		npc_type->fixedZ = 1;
		// Weapons are broke!!
		//npc_type->equipment[13] = atoi(sep.arg[7]);
		//npc_type->equipment[14] = atoi(sep.arg[8]);
		npc_type->merchanttype = atoi(sep.arg[9]);	
		//for (int i=0; i<9; i++)
		//	npc_type->equipment[i] = atoi(sep.arg[7]);

		npc_type->STR = 75;
		npc_type->STA = 75;
		npc_type->DEX = 75;
		npc_type->AGI = 75;
		npc_type->INT = 75;
		npc_type->WIS = 75;
		npc_type->CHA = 75;

		NPC* npc = new NPC(npc_type, 0, in_x, in_y, in_z, in_heading);
		delete npc_type;

		entity_list.AddNPC(npc);
		return npc;
	}
}
