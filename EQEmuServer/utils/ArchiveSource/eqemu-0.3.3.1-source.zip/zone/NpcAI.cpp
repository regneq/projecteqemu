#include <iostream.h>
#ifdef WIN32
	#define snprintf	_snprintf
#endif

#include "NpcAI.h"
#include "entity.h"
#include "npc.h"
#include "client.h"
#include "faction.h"

////////////////////////////////////////////// MOB AI /////////////////////////////////////
// 03/09   - Merkur
// Adds Hate to close Mobs depending on faction,level, appearence and target
//////////////////////////////////////////////////////////////////////////////////////////
bool EntityList::AddHateToCloseMobs(NPC* sender, float dist, int social) {
	if (sender == 0) {
		return false;
	}
	if(dist <= 0) {
		dist = 100;
	}
	float dist2 = dist * dist;	
	LinkedListIterator<Entity*> iterator(list);	
	iterator.Reset();					
	
	while(iterator.MoreElements()) 
	{
		if (iterator.GetData() != sender)
		{
			Mob* currentmob = iterator.GetData()->CastToMob();
			if (iterator.GetData()->IsClient())
			{
				if (currentmob->CastToClient()->Connected())
				{
					int8 lbc = currentmob->CastToClient()->GetFactionLevel(currentmob->GetID(),sender->GetNPCTypeID(), currentmob->GetRace(), currentmob->GetClass(), DEITY_AGNOSTIC,sender->GetFactionID());
					if (!(lbc == FACTION_THREATENLY||lbc == FACTION_SCOWLS) || (currentmob->CastToClient()->GetGM() == 1))
					{
						iterator.Advance();
						continue;		// Client is not KOS for this MoB - ignore
					}
					switch(GetLevelCon(currentmob->GetLevel(),sender->GetLevel())) 
						// Decrease attackradius based on leveldifference and faction
					{
					case CON_GREEN:	// Appearance seems not to work yet
						if (lbc == FACTION_SCOWLS)
							dist2 = (currentmob->GetAppearance() == 1) ? (dist * dist)/2:0;
						else  // FACTION_THREATENLY
							dist2 = (currentmob->GetAppearance() == 1) ? (dist * dist)/4:0;
						break;
					case CON_BLUE2:
						if (lbc == FACTION_SCOWLS)
							dist2 = (dist * dist)/2;
						else // FACTION_THREATENLY
							dist2 = (dist * dist)/4;
						break;
					case CON_BLUE:
						{
							if (lbc == FACTION_SCOWLS)
								dist2 = (dist * dist)/2;
							else // FACTION_THREATENLY
								dist2 = (dist * dist)/4;
							break;
						}
					default: //all other factions
						{
							if (lbc == FACTION_SCOWLS)
								dist2 = (dist) * (dist);
							else // FACTION_THREATENLY
								dist2 = (dist * dist)/2;
							break;
						}
					}
					if(currentmob->CastToClient()->DistNoRoot(sender) <= dist2) {
						if (!sender->IsEngaged())
							// Mob not engaged, kos to client, and client is fully connected
						{
							sender->AddToHateList(currentmob,1);				
							//char buffer[200];
							//_snprintf(buffer,200,"%s says: 'I shall attack you %s, because I hate you!'",sender->GetName(),currentmob->GetName());
							//currentmob->Message(0,buffer);
							cout << sender->GetName() << ": Aggro Added! Calculated aggrorange: " << dist2 << endl;						
							return true; // Only aggro first player
						}
						
					}
				}
			}
			else if(iterator.GetData()->IsNPC())
			{
				if (social == 0)	
					social = 4000;				
				NPC* currentnpc= iterator.GetData()->CastToNPC();				
				if (currentnpc->IsEngaged())
				{
					if (sender->GetFactionID() == currentnpc->GetFactionID() && currentmob->DistNoRoot(sender) <= 4000)
						// ok now we have a npc, same faction and engaged
					{
						if ((sender->GetIgnoreTarget() != currentnpc->GetHateTop()) && currentnpc->GetHateTop()->IsClient()) 
							// TODO Use a better way than IgnoreTarget? Its currently need to avoid doing a new random every 500 ms for same player			
						{
							sint32 tmp= (currentnpc->GetHateTop()->GetLevel() - sender->GetLevel());
							if (tmp <= 0)
								tmp = 0;
#ifndef WIN32
							//Weird compilation issues on Linux.
							if (60 > (float)tmp*tmp*0.51)	// Chance that he will join, exponential based on level Not much tested yet, may need to tune it
#else
							if ((float)rand()/RAND_MAX*100 > (float)tmp*tmp*0.51)	// Chance that he will join, exponential based on level Not much tested yet, may need to tune it
#endif
							{
								sender->AddToHateList(currentnpc->GetHateTop(),1);
								//char buffer[250];
								//_snprintf(buffer,250,"%s says: 'I shall attack you %s, because I have to help my friend %s!'",sender->GetName(),currentnpc->GetHateTop()->GetName(),currentnpc->GetName());
								//currentnpc->GetHateTop()->Message(0,buffer);
								cout << sender->GetName() << ": Aggro Added! Helping friend" << endl;
								return true;
							}		
							else
							{
								sender->SetIgnoreTarget(currentnpc->GetHateTop());
							}
						}
					}
					//not in the same faction - maybe protect the victim? lets see
					else if (currentmob->DistNoRoot(sender) <= 10000 && currentnpc->GetHateTop()->IsClient())
					{
						// is the victim allied with me?
						if (currentnpc->GetHateTop()->CastToClient()->GetFactionLevel(currentnpc->GetHateTop()->GetID(),sender->GetNPCTypeID(), currentnpc->GetHateTop()->GetRace(), currentnpc->GetHateTop()->GetClass(), DEITY_AGNOSTIC, sender->GetFactionID()) == FACTION_ALLY)
						{
							sender->AddToHateList(currentnpc,1);
							//char buffer[250];
							//_snprintf(buffer,250,"%s says: 'Fear not %s, i'll help you to defeat %s!'",sender->GetName(),currentnpc->GetHateTop()->GetName(),currentnpc->GetName());
							//currentnpc->GetHateTop()->Message(0,buffer);
							cout << sender->GetName() << ": Aggro Added! Guarding player" << endl;
							return true;
						}
						
					}
				}
				else // not engaged
				{
					// Here he could cast Buffs, Healspells etc on his friend
				}				
				
			}
			
		}
		iterator.Advance();		
	} // while
	return false;
}

int32 GetLevelCon(int8 PlayerLevel, int8 NPCLevel)
{
	sint8 tmp = NPCLevel - PlayerLevel;
	int32 conlevel;
	if (PlayerLevel <= 12)
	{
		conlevel =  (tmp <= -4) ? 0x02:
	(tmp >=-3 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:			
	(tmp >= 1 && tmp <= 2) ?0x0F:    
	0x0D;							
	}
	else if (PlayerLevel >= 13 && PlayerLevel <= 24)
	{
		conlevel =  (tmp <= -6) ? 0x02:			
	(tmp >=-5 && tmp <= -4) ? 0x12:
	(tmp >=-3 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 25 && PlayerLevel <= 40)
	{
								conlevel =  (tmp <= -11) ? 0x02:
	(tmp >=-10 && tmp <= -8) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 41 && PlayerLevel <= 48)
	{
								conlevel =  (tmp <= -12) ? 0x02:
	(tmp >=-11 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	}
	else if (PlayerLevel >= 50)
	{
								conlevel =  (tmp <= -14) ? 0x02:
	(tmp >=-13 && tmp <= -1) ? 0x04:
	(tmp == 0) ? 0x00:
	(tmp >= 1 && tmp <= 2) ?0x0F:
	0x0D;
	};
	return conlevel;
	
};