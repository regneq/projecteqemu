#include "../common/debug.h"

#include <iostream.h>
#include <string.h>
#include <stdio.h>

#include "TCPConnection.h"
#include "../common/servertalk.h"
#include "../common/timer.h"

TCPConnection::TCPConnection() {
	ConnectionType = Outgoing;
	connection_state = TCPS_Ready;
	pFree = false;
	connection_socket = 0;
	ID = 0;
	ip = 0;
	port = 0;
	keepalive_timer = new Timer(SERVER_TIMEOUT);
	timeout_counter = 0;
	recvbuf = 0;
	sendbuf = 0;
#ifdef WIN32
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;

	WSAStartup (version, &wsadata);
#endif
	pRunLoop = false;
}

#ifdef WIN32
TCPConnection::TCPConnection(int32 in_ID, SOCKET in_socket, int32 in_ip, int16 in_port) {
#else
TCPConnection::TCPConnection(int32 in_ID, int in_socket, int32 in_ip, int16 in_port) {
#endif
	ConnectionType = Incomming;
	connection_state = TCPS_Connected;
	pFree = false;
	connection_socket = in_socket;
	ID = in_ID;
	ip = in_ip;
	port = in_port;
	keepalive_timer = new Timer(SERVER_TIMEOUT);
	timeout_counter = 0;
	recvbuf = 0;
	sendbuf = 0;
	pRunLoop = false;
}

TCPConnection::~TCPConnection() {
	Disconnect();
	safe_delete(keepalive_timer);
	safe_delete(recvbuf);
	safe_delete(sendbuf);
	if (ConnectionType == Outgoing) {
		MRunLoop.lock();
		pRunLoop = false;
		MRunLoop.unlock();
		MLoopRunning.lock();
		MLoopRunning.unlock();
#ifdef WIN32
		WSACleanup();
#endif
	}
}

void TCPConnection::SetState(int8 in_state) {
	MConnectionState.lock();
	connection_state = in_state;
	MConnectionState.unlock();
}

int8 TCPConnection::GetState() {
	int8 ret;
	MConnectionState.lock();
	ret = connection_state;
	MConnectionState.unlock();
	return ret;
}

void TCPConnection::Free() {
	if (ConnectionType != Incomming) {
		ThrowError("TCPConnection::Free() called on an Outgoing connection");
	}
	pFree = true;
}

bool TCPConnection::SendPacket(ServerPacket* pack) {
	if (!Connected())
		return false;

	SPackSendQueue* spsq = (SPackSendQueue*) new uchar[sizeof(SPackSendQueue) + pack->size + 4];
	if (pack->pBuffer != 0 && pack->size != 0)
		memcpy((char *) &spsq->buffer[4], (char *) pack->pBuffer, pack->size);
	memcpy((char *) &spsq->buffer[0], (char *) &pack->opcode, 2);
	spsq->size = pack->size+4;
	memcpy((char *) &spsq->buffer[2], (char *) &spsq->size, 2);
	ServerSendQueuePushEnd(spsq->buffer, spsq->size);
	delete spsq;
	return true;
}

bool TCPConnection::SendRawData(uchar* data, int32 size) {
	if (!Connected())
		return false;

	ServerSendQueuePushEnd(data, size);
	return true;
}

void TCPConnection::ServerSendQueuePushEnd(uchar* data, int32 size) {
	MSendQueue.lock();
	if (sendbuf == 0) {
		sendbuf = new uchar[size];
		sendbuf_size = size;
		sendbuf_used = 0;
	}
	else if (size > (sendbuf_size - sendbuf_used)) {
		sendbuf_size += size;
		uchar* tmp = new uchar[sendbuf_size];
		memcpy(tmp, sendbuf, sendbuf_used);
		delete sendbuf;
		sendbuf = tmp;
	}
	memcpy(&sendbuf[sendbuf_used], data, size);
	sendbuf_used += size;
	MSendQueue.unlock();
}

void TCPConnection::ServerSendQueuePushFront(uchar* data, int32 size) {
	MSendQueue.lock();
	if (sendbuf == 0) {
		sendbuf = new uchar[size];
		sendbuf_size = size;
		sendbuf_used = 0;
	}
	else if (size > (sendbuf_size - sendbuf_used)) {
		sendbuf_size += size;
		uchar* tmp = new uchar[sendbuf_size];
		memcpy(&tmp[size], sendbuf, sendbuf_used);
		delete sendbuf;
		sendbuf = tmp;
	}
	memcpy(sendbuf, data, size);
	sendbuf_used += size;
	MSendQueue.unlock();
}

bool TCPConnection::ServerSendQueuePop(uchar** data, int32* size) {
	bool ret;
	MSendQueue.lock();
	if (sendbuf) {
		*data = sendbuf;
		*size = sendbuf_used;
		sendbuf = 0;
		ret = true;
	}
	else {
		ret = false;
	}
	MSendQueue.unlock();
	return ret;
}

ServerPacket* TCPConnection::ServerRecvQueuePop() {
	ServerPacket* ret;
	MRecvQueue.lock();
	ret = ServerRecvQueue.pop();
	MRecvQueue.unlock();
	return ret;
}

void TCPConnection::ServerRevcQueuePush(ServerPacket* pack) {
	MRecvQueue.lock();
	ServerRecvQueue.push(pack);
	MRecvQueue.unlock();
}

/*
  This function should be overriden by child classes.
  aka: if this code every actually gets executed something's really fucked up.
*/
bool TCPConnection::Process() {
	ThrowError("TCPConnection class: Process() called!");
	return false;
}

void TCPConnection::Disconnect() {
	if (connection_socket != INVALID_SOCKET && connection_socket != 0) {
		MConnectionState.lock();
		if (connection_state == TCPS_Connected || connection_state == TCPS_Disconnecting || connection_state == TCPS_Disconnected)
			SendData();
		connection_state = TCPS_Closing;
		MConnectionState.unlock();
		shutdown(connection_socket, 0x01);
		shutdown(connection_socket, 0x00);
#ifdef WIN32
		closesocket(connection_socket);
#else
		close(connection_socket);
#endif
		connection_socket = 0;
		ip = 0;
		port = 0;
	}
	SetState(TCPS_Ready);
}

bool TCPConnection::Connect(int32 in_ip, int16 in_port, char* errbuf) {
	if (errbuf)
		errbuf[0] = 0;
	if (ConnectionType != Outgoing) {
		// If this code runs, we got serious problems
		// Crash and burn.
		ThrowError("TCPConnection::Connect() call on a Incomming connection object!");
		return false;
	}
	MConnectionState.lock();
	if (connection_state == TCPS_Ready) {
		connection_state = TCPS_Connecting;
	}
	else {
		MConnectionState.unlock();
		return false;
	}
	MConnectionState.unlock();
	if (!pRunLoop) {
		pRunLoop = true;
#ifdef WIN32
		_beginthread(TCPOutgoingLoop, 0, this);
#else
		pthread_t thread;
		pthread_create(&thread, NULL, TCPOutgoingLoop, this);
#endif
	}

	connection_socket = INVALID_SOCKET;
	unsigned long nonblocking = 1;
    struct sockaddr_in	server_sin;
    struct in_addr	in;

	if ((connection_socket = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET || connection_socket == 0) {
#ifdef WIN32
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::Connect(): Allocating socket failed. Error: %i", WSAGetLastError());
#else
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::Connect(): Allocating socket failed. Error: %s", strerror(errno));
#endif
		SetState(TCPS_Ready);
		return false;
	}
	server_sin.sin_family = AF_INET;
	server_sin.sin_addr.s_addr = in_ip;
	server_sin.sin_port = htons(in_port);

	// Establish a connection to the server socket.
#ifdef WIN32
	if (connect(connection_socket, (PSOCKADDR) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::Connect(): connect() failed. Error: %i", WSAGetLastError());
		closesocket(connection_socket);
#else
	if (connect(connection_socket, (struct sockaddr *) &server_sin, sizeof (server_sin)) == SOCKET_ERROR) {
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::Connect(): connect() failed. Error: %s", strerror(errno));
		close(connection_socket);
#endif
		connection_socket = 0;
		SetState(TCPS_Ready);
		return false;
	}	
#ifdef WIN32
	ioctlsocket(connection_socket, FIONBIO, &nonblocking);
#else
	fcntl(connection_socket, F_SETFL, O_NONBLOCK);
#endif

	ip = in_ip;
	port = in_port;
	keepalive_timer->Start();
	timeout_counter = 0;
	SetState(TCPS_Connected);
	return true;
}

bool TCPConnection::NetConnected() {
	MConnectionState.lock();
	if (connection_state == TCPS_Connected || connection_state == TCPS_Disconnecting) {
		MConnectionState.unlock();
		return true;
	}
	MConnectionState.unlock();
	return false;
}

bool TCPConnection::NetProcess() {
	char errbuf[TCPConnection_ErrorBufferSize];
	if (!NetConnected()) {
		if (GetState() == TCPS_Connecting)
			return true;
		else
			return false;
	}
	if (!SendData(errbuf)) {
	    struct in_addr	in;
		in.s_addr = GetIP();
		cout << inet_ntoa(in) << ":" << GetPort() << ": " << errbuf << endl;
		return false;
	}
	if (!Connected() || !RecvData()) {
		return false;
	}
	return true;
}

bool TCPConnection::RecvData() {
	if (!Connected()) {
		return false;
	}

	int	status = 0;
	if (recvbuf == 0) {
		recvbuf = new uchar[5120];
		recvbuf_size = 5120;
		recvbuf_used = 0;
	}
	else if ((recvbuf_size - recvbuf_used) < 2048) {
		uchar* tmpbuf = new uchar[recvbuf_size + 5120];
		memcpy(tmpbuf, recvbuf, recvbuf_used);
		recvbuf_size += 5120;
		delete recvbuf;
		recvbuf = tmpbuf;
	}

    status = recv(connection_socket, (char *) &recvbuf[recvbuf_used], (recvbuf_size - recvbuf_used), 0);

    if (status >= 1) {
		recvbuf_used += status;
		timeout_counter = 0;
		ProcessReceivedData();
    }
	else if (status == SOCKET_ERROR) {
#ifdef WIN32
		if (!(WSAGetLastError() == WSAEWOULDBLOCK)) {
#else
		if (!(errno == EWOULDBLOCK)) {
#endif
			return false;
		}
	}

	return true;
}

void TCPConnection::ProcessReceivedData() {
	int32 base = 0;
	int32 size = 4;
	uchar* buffer;
	ServerPacket* pack = 0;
	while ((recvbuf_used - base) >= size) {
		buffer = &recvbuf[base];
		memcpy(&size, &buffer[2], 2);
		if ((recvbuf_used - base) >= size) {
			// ok, we got enough data to make this packet!
			pack = new ServerPacket;
			memcpy(&pack->opcode, &buffer[0], 2);
			pack->size = size - 4;
/*			if () { // TODO: Checksum or size check or something similar
				// Datastream corruption, get the hell outta here!
				delete pack;
				return false;
			}*/
			if (pack->size > 0) {
				pack->pBuffer = new uchar[pack->size];
				memcpy(pack->pBuffer, &buffer[4], pack->size);
			}
			if (pack->opcode == 0) {
				// keepalive, no need to process
				delete pack;
			}
			else {
				ServerRevcQueuePush(pack);
			}
			base += size;
			size = 4;
		}
	}
	if (base != 0) {
		if (base >= recvbuf_used) {
			safe_delete(recvbuf);
		}
		else {
			uchar* tmpbuf = new uchar[recvbuf_size - base];
			memcpy(tmpbuf, &recvbuf[base], recvbuf_used - base);
			delete recvbuf;
			recvbuf = tmpbuf;
			recvbuf_used -= base;
			recvbuf_size -= base;
		}
	}
}

bool TCPConnection::SendData(char* errbuf) {
	if (errbuf)
		errbuf[0] = 0;
	/************ Get first send packet on queue and send it! ************/
	uchar* data = 0;
	int32 size = 0;
	int status = 0;
	if (ServerSendQueuePop(&data, &size)) {
#ifdef WIN32
		status = send(connection_socket, (const char *) data, size, 0);
#else
		status = send(connection_socket, data, size, MSG_NOSIGNAL);
		if(errno==EPIPE) status = SOCKET_ERROR;
#endif
		if (status >= 1) {
			if (status < size) {
				// If there's network congestion, the number of bytes sent can be less than
				// what we tried to give it... Push the extra back on the queue for later
				ServerSendQueuePushFront(&data[status], size - status);
			}
			else if (status > size) {
				ThrowError("TCPConnection::SendData(): WTF! status > size");
				return false;
			}
			// else if (status == size) {}
		}
		else {
			ServerSendQueuePushFront(data, size);
		}

		delete data;
		if (status == SOCKET_ERROR) {
#ifdef WIN32
			if (WSAGetLastError() != WSAEWOULDBLOCK) {
#else
			if (errno != EWOULDBLOCK) {
#endif
				if (errbuf) {
#ifdef WIN32
					snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::SendData(): send(): Errorcode: %i", WSAGetLastError());
#else
					snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::SendData(): send(): Errorcode: %s", strerror(errno));
#endif
				}
				return false;
			}
		}
	}
    if (keepalive_timer->Check()) {
		ServerPacket* pack = new ServerPacket(0, 0);
		SendPacket(pack);
		delete pack;
		timeout_counter++;
    }
	if (timeout_counter >= 3) {
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "TCPConnection::SendData(): Connection timeout");
		return false;
	}
	return true;
}

#ifdef WIN32
void TCPOutgoingLoop(void* tmp)
#else
void* TCPOutgoingLoop(void* tmp)
#endif
{
	if (tmp == 0) {
		ThrowError("TCPOutgoingLoop(): tmp = 0!");
#ifdef WIN32
		return;
#else
		return 0;
#endif
	}
	TCPConnection* tcpc = (TCPConnection*) tmp;
	tcpc->MLoopRunning.lock();
	while (tcpc->RunLoop()) {
		Sleep(1);
		if (!tcpc->NetProcess()) {
			tcpc->Disconnect();
		}
	}
	tcpc->MLoopRunning.unlock();
#ifdef WIN32
	_endthread();
#else
	return 0;
#endif
}

bool TCPConnection::RunLoop() {
	bool ret;
	MRunLoop.lock();
	ret = pRunLoop;
	MRunLoop.unlock();
	return ret;
}





TCPListener2::TCPListener2(int16 in_port) {
	NextID = 1;
	listenport = in_port;
	listeningsocket = 0;
//	LoopRunning = false;
	pRunLoop = true;
#ifdef WIN32
	WORD version = MAKEWORD (1,1);
	WSADATA wsadata;

	WSAStartup (version, &wsadata);
#endif		
#ifdef WIN32
	_beginthread(TCPListenerLoop, 0, this);
#else
	pthread_t thread;
	pthread_create(&thread, NULL, &TCPListenerLoop, this);
#endif
}

TCPListener2::~TCPListener2() {
	MRunLoop.lock();
	pRunLoop = false;
	MRunLoop.unlock();
	MLoopRunning.lock();
	MLoopRunning.unlock();
#ifdef WIN32
	WSACleanup();
#endif
}

bool TCPListener2::RunLoop() {
	bool ret;
	MRunLoop.lock();
	ret = pRunLoop;
	MRunLoop.unlock();
	return ret;
}

#ifdef WIN32
	void TCPListenerLoop(void* tmp)
#else
	void* TCPListenerLoop(void* tmp)
#endif
{
	if (tmp == 0) {
		ThrowError("TCPListenerLoop(): tmp = 0!");
#ifdef WIN32
		return;
#else
		return 0;
#endif
	}
	TCPListener2* tcpl = (TCPListener2*) tmp;
	tcpl->MLoopRunning.lock();
	while (tcpl->RunLoop()) {
		Sleep(1);
		tcpl->NetProcess();
	}
	tcpl->MLoopRunning.unlock();
}

void TCPListener2::Process() {
	LinkedListIterator<TCPConnection*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->GetState() == TCPS_DeleteMe) {
		    struct in_addr	in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Dropping Connection: " << inet_ntoa(in) << ":" << iterator.GetData()->GetPort() << endl;
			MListModLock.lock();
			iterator.RemoveCurrent();
			MListModLock.unlock();
		}
		else {
			if (!(iterator.GetData()->Connected() && iterator.GetData()->Process())) {
				iterator.GetData()->SetState(TCPS_Disconnected);
				iterator.Advance();
			}
			iterator.Advance();
		}
	}
}

void TCPListener2::NetProcess() {
	LockMutex lock(&MListModLock);
	ListenNewConnections();
	LinkedListIterator<TCPConnection*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (!iterator.GetData()->NetProcess()) {
			if (iterator.GetData()->NetConnected())
				iterator.GetData()->Disconnect();
			iterator.GetData()->SetState(TCPS_DeleteMe);
		}
		iterator.Advance();
	}
}

void TCPListener2::ListenNewConnections() {
    int		tmpsock;
    struct sockaddr_in	from;
    struct in_addr	in;
    unsigned int	fromlen;
    unsigned short	port;
	TCPConnection* con;

    from.sin_family = AF_INET;
    fromlen = sizeof(from);

	// Check for pending connects
#ifdef WIN32
	while ((tmpsock = accept(listeningsocket, (struct sockaddr*) &from, (int *) &fromlen)) != INVALID_SOCKET)
#else
	while ((tmpsock = accept(listeningsocket, (struct sockaddr*) &from, &fromlen)) != INVALID_SOCKET)
#endif
	{
		port = from.sin_port;
		in.s_addr = from.sin_addr.s_addr;

		// New TCP connection
		con = MakeNewConn(GetNextID(), tmpsock, in.s_addr, ntohs(from.sin_port));
		cout << "New TCP connection: " << inet_ntoa(in) << ":" << con->GetPort() << endl;
		MListModLock.lock();
		list.Insert(con);
		MListModLock.unlock();
	}
}

bool TCPListener2::Init(int16 in_port, char* errbuf) {
	if (errbuf)
		errbuf[0] = 0;
	if (listeningsocket != 0) {
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "Listening socket already open");
		return false;
	}
	if (in_port != 0) {
		listenport = in_port;
	}

#ifdef WIN32
	SOCKADDR_IN address;
#else
	struct sockaddr_in address;
#endif
	int reuse_addr = 1;
	unsigned long nonblocking = 1;

  /* Setup internet address information.  
     This is used with the bind() call */
	memset((char *) &address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(listenport);
	address.sin_addr.s_addr = htonl(INADDR_ANY);

	/* Setting up TCP port for new TCP connections */
	listeningsocket = socket(AF_INET, SOCK_STREAM, 0);
	if (listeningsocket == INVALID_SOCKET) {
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "socket(): INVALID_SOCKET");
		return false;
	}

// Quag: dont think following is good stuff for TCP, good for UDP
// Mis: SO_REUSEADDR shouldn't be a problem for tcp--allows you to restart
// without waiting for conns in TIME_WAIT to die
	setsockopt(listeningsocket, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse_addr, sizeof(reuse_addr));


	if (bind(listeningsocket, (struct sockaddr *) &address, sizeof(address)) < 0) {
#ifdef WIN32
		closesocket(listeningsocket);
#else
		close(listeningsocket);
#endif
		listeningsocket = 0;
		if (errbuf)
			sprintf(errbuf, "bind(): <0");
		return false;
	}

#ifdef WIN32
	ioctlsocket (listeningsocket, FIONBIO, &nonblocking);
#else
	fcntl(listeningsocket, F_SETFL, O_NONBLOCK);
#endif

	if (listen(listeningsocket, SOMAXCONN) == SOCKET_ERROR) {
#ifdef WIN32
		closesocket(listeningsocket);
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "listen() failed, Error: %d", WSAGetLastError());
#else
		close(listeningsocket);
		if (errbuf)
			snprintf(errbuf, TCPConnection_ErrorBufferSize, "listen() failed, Error: %s", strerror(errno));
#endif
		listeningsocket = 0;
		return false;
	}

	return true;
}

void TCPListener2::Close() {
#ifdef WIN32
	closesocket(listeningsocket);
#else
	close(listeningsocket);
#endif
	listeningsocket = 0;
}

void TCPListener2::KillAll() {
	LockMutex lock(&MListModLock);
	LinkedListIterator<TCPConnection*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		iterator.GetData()->SetState(TCPS_Disconnected);
	}
}

void TCPListener2::SendPacket(ServerPacket* pack) {
	LockMutex lock(&MListModLock);
	LinkedListIterator<TCPConnection*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements()) {
		iterator.GetData()->SendPacket(pack);
		iterator.Advance();
	}
}


