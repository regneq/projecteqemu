#ifdef _DEBUG
	#ifndef _CRTDBG_MAP_ALLOC
		#define _CRTDBG_MAP_ALLOC
		#include <stdlib.h>
		#include <crtdbg.h>
		#define new \
        new(_NORMAL_BLOCK, __FILE__, __LINE__) 
	#endif
#endif

#ifndef ThrowError
#define ThrowError(errstr)	cout << "Fatal error: " << errstr << " (" << __FILE__ << ", line " << __LINE__ << ")" << endl; throw errstr;
#endif
