#ifndef MYMUTEX_H
#define MYMUTEX_H
#ifdef WIN32
	#include <windows.h>
#else
	#include <pthread.h>
#endif
#include "../common/types.h"

class Mutex {
public:
	Mutex();
	~Mutex();

	void lock();
	void unlock();
	bool trylock();
protected:
private:
#ifdef WIN32
	CRITICAL_SECTION CSMutex;
#else
	pthread_mutex_t CSMutex;
#endif
};

class LockMutex {
public:
	LockMutex(Mutex* in_mut);
	~LockMutex();
	void unlock();
private:
	bool	locked;
	Mutex*	mut;
};


// Somewhat untested...
// Multi-read, single write mutex -Quagmire
class MRMutex {
public:
	MRMutex();
	~MRMutex();

	void	ReadLock();
	bool	TryReadLock();
	void	UnReadLock();

	void	WriteLock();
	bool	TryWriteLock();
	void	UnWriteLock();

	sint32	ReadLockCount();
	sint32	WriteLockCount();
private:
	sint32	rl;	// read locks in effect
	sint32	wr;	// write lock requests pending
	sint32	wl;	// write locks in effect (should never be more than 1)
	Mutex	MCounters;
};

#endif

