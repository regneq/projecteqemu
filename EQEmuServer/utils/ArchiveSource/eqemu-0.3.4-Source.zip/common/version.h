#ifndef VERSION_H
#define VERSION_H

#define CURRENT_CHAT_VERSION	"EqEmu 0.3.4 Chat Server"
#define CURRENT_ZONE_VERSION	"EqEmu 0.3.4 Zoneserver"
#define CURRENT_WORLD_VERSION   "EqEmu 0.3.4 Worldserver"
#define CURRENT_VERSION			"0.3.4"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
	#define LAST_MODIFIED	__TIME__
#else
	#define LAST_MODIFIED	__TIMESTAMP__
#endif

#endif

