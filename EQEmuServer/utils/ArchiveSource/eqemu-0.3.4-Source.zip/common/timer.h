#ifndef TIMER_H
#define TIMER_H

#include "types.h"

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	int gettimeofday (timeval *tp, ...);
#endif

class Timer
{
public:
	Timer(int32 timer_time);
	~Timer() { }

	bool Check();
	void Disable();
	void Start(int32 set_timer_time=0, bool ChangeResetTimer = true);
	void SetTimer(int32 set_timer_time=0);
	int32 GetRemainingTime();
	void Trigger();
	void SetAtTrigger(int32 set_at_trigger);

	bool Enabled() { return enabled; }

	static void SetCurrentTime();
	static int32 GetCurrentTime();

private:
	int32 start_time;
	int32 timer_time;
	bool enabled;
	int32 set_at_trigger;

//	static int32 current_time;
//	static int32 last_time;
};

#endif
