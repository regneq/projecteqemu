#ifndef MISCFUNCTIONS_H
#define MISCFUNCTIONS_H

#include "types.h"
#include <stdio.h>

#ifndef ERRBUF_SIZE
#define ERRBUF_SIZE		1024
#endif

int		MakeAnyLenString(char** ret, const char* format, ...);
int32	AppendAnyLenString(char** ret, int32* bufsize, int32* strlen, const char* format, ...);
int32	hextoi(char* num);
sint32	filesize(FILE* fp);
int32	ResolveIP(const char* hostname, char* errbuf = 0);

class InitWinsock {
public:
	InitWinsock();
	~InitWinsock();
};

#endif

