#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>

	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <pthread.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/database.h"
#include "../common/packet_functions.h"
#include "../common/packet_dump.h"
#include "worldserver.h"
#include "../common/packet_dump_file.h"
#include "Quest.h"
#include "PlayerCorpse.h"
#include "spdat.h"
#include "petitions.h"
#include "NpcAI.h"
#include "skills.h"
#include "object.h"
#include "groups.h"

extern Database database;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern WorldServer worldserver;
extern GuildRanks_Struct guilds[512];
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];
extern bool spells_loaded;
extern PetitionList petition_list;
extern EntityList entity_list;

bool Client::Process() {
	adverrorinfo = 1;
	bool ret = true;
	if (Connected())
	{
		if (IsStunned() && stunned_timer->Check()) {
			this->stunned = false;
			this->stunned_timer->Disable();
		}
		if (auto_attack && target != 0 && attack_timer->Check() && !IsStunned() && !IsMezzed())
		{
			float size = target->GetSize();
			if(size <= 9)
			{
			size = 10;
			}
			if(target->GetRace() == 49)
			{
			//I just want this here incase the default size has something to do with the model (ex a human is resized to nagafen at maybe 35, nagafen could possibly be default 0 size b/c the model starts that size
			size = 95;
			}
			if (DistNoRootNoZ(target) > size*15)
			{
				Message(13,"Your target is too far away, get closer!");
			}
			else if (target == this)
			{
				Message(13,"Try attacking someone else then yourself!");
			}
/*			else if (CantSee(target))
			{
				Message(13,"You can't see your target from here.");				
			}*/
			else if (!IsNPC() && appearance == 3)
			{
			}
			else if (target->GetHP() > 0)
			{
				Attack(target, 13); 	// Kaiyodo - added attacking hand to arguments

				// Kaiyodo - support for double attack. Chance based on formula from Monkly business
				if(CanThisClassDoubleAttack())
				{
					float DoubleAttackProbability = (GetSkill(DOUBLE_ATTACK) + GetLevel()) / 500.0f; // 62.4 max
					// Check for double attack with main hand assuming maxed DA Skill (MS)
					float random = (float)rand()/RAND_MAX;
					if(random < DoubleAttackProbability)		// Max 62.4 % chance of DA
						if(target && target->GetHP() > 0)
							Attack(target, 13);
				}

			}
		}
		// Kaiyodo - Check offhand attack timer
		if(CanThisClassDuelWield() && auto_attack && target != 0 && attack_timer_dw->Check()&& !IsStunned() && !IsMezzed())
		{
			if(DistNoRootNoZ(target) > 20*20) {}		// Range check
			else if(target == this) {}						// Don't attack yourself
			else if(!IsNPC() && appearance == 3) {}	// ?
			else if(target->GetHP() > 0)
			{
				float DualWieldProbability = (GetSkill(DUEL_WIELD) + GetLevel()) / 400.0f; // 78.0 max

				float random = (float)rand()/RAND_MAX;
				if(random < DualWieldProbability)		// Max 78% of DW
				{
					Attack(target, 14);	// Single attack with offhand

					float DoubleAttackProbability = (GetSkill(DOUBLE_ATTACK) + GetLevel()) / 500.0f; // 62.4 max

					// Check for double attack with off hand assuming maxed DA Skill
					random = (float)rand()/RAND_MAX;
					if(random <= DoubleAttackProbability)	// Max 62.4% chance of DW/DA
						if(target && target->GetHP() > 0)
							Attack(target, 14);
				}
			}
		}
		adverrorinfo = 2;
		if (position_timer->Check())
		{
//			SendPosUpdate();
			// Send position updates, whole zone every 3 seconds, close mobs every 150ms
			if (position_timer_counter > 30) {
				entity_list.SendPositionUpdates(this, pLastUpdate);
				position_timer_counter = 0;
			}
			else
				entity_list.SendPositionUpdates(this, pLastUpdate, 400, target);

			pLastUpdate = Timer::GetCurrentTime();
			position_timer_counter++;
		}
		adverrorinfo = 3;
		SpellProcess();
		adverrorinfo = 4;
		if (tic_timer->Check())
		{
			CalcMaxHP();
			CalcMaxMana();			
			TicProcess();
			if (GetMana() < max_mana)
			{
				// TODOmake manaregen 100% snyc with client
				if (IsSitting()){
					if (GetLevel() > 24)
						medding = true;
					if (medding){
						SetMana(GetMana()+GetLevel()/4+(GetSkill(MEDITATE)/4));
						CheckIncreaseSkill(MEDITATE);
					}
					else
						SetMana(GetMana()+GetLevel()/4+(GetSkill(MEDITATE)/8));
				}
				else{
					medding = false;
					SetMana(GetMana()+(1+GetSkill(MEDITATE)/4));
				}
			}
			//CalcMaxMana();
			if (GetHP() < max_hp) // TODO: Get regen/tick confirmed
			{
				if (IsSitting()) // If we are sitting
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+4);
						else if (GetLevel() < 50)
							SetHP(GetHP()+6);
						else
							SetHP(GetHP()+12);
					}
					else
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+2);
						else if (GetLevel() < 50)
							SetHP(GetHP()+3);
						else if (GetLevel() < 51)
							SetHP(GetHP()+4);
						else
							SetHP(GetHP()+5);
					}
				}
				else
				{
					if (GetRace() == TROLL || GetRace() == IKSAR)
					{
						if (GetLevel() < 20)
							SetHP(GetHP()+1);
						else if (GetLevel() < 50)
							SetHP(GetHP()+2);
						else
							SetHP(GetHP()+4);
					}
					else
					{
						if (GetLevel() < 51)
							SetHP(GetHP()+1);
						else
							SetHP(GetHP()+2);
					}
				}
				if (GetHP() > max_hp)
					SetHP(max_hp);
				SendHPUpdate();
			}
		}
	}
    adverrorinfo = 5;
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(ret && (app = eqnc->PopPacket()))
	{
/*	
cout << " Recvieved opcode: 0x" << app->opcode << endl;
if (app->size > 0) DumpPacket(app);
*/
		if (app->opcode == 0) {
			delete app;
			continue;
		}
		switch(client_state)
		{
			case CLIENT_CONNECTING1:
			{
				if (app->opcode == OP_SetDataRate)
				{
					if (app->size != sizeof(float)) {
						cout << "Wrong size on OP_SetDatarate. Got: " << app->size << ", Expected: " << sizeof(float) << endl;
						break;
					}
					cout << "Login packet 1 (OP_SetDataRate = " << (*(float*) app->pBuffer) << ")" << endl;
					eqnc->SetDataRate(*(float*) app->pBuffer);
//DumpPacket(app);
					client_state = CLIENT_CONNECTING2;
				}
				else {
					cout << "Unexpected packet during CLIENT_CONNECTING1: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					DumpPacket(app);
				}
				break;
			}
			case CLIENT_CONNECTING2: {
				if (app->opcode == OP_ZoneEntry)
				{
					cout << "Login packet 2" << endl;
//DumpPacket(app);

					// Quagmire - Antighost code
					// tmp var is so the search doesnt find this object
					char tmp[64];
					snprintf(tmp, 64, "%s", (char*)&app->pBuffer[4]);
					Client* client = entity_list.GetClientByName(tmp);
					strcpy(name, tmp);
					account_id = database.GetAuthentication(name, zone->GetShortName(), ip);
					if (account_id == 0) {
#ifdef _DEBUG
						if (ip == 16777343) {
							cout << "GetAuthentication = 0, but ignoring for 127.0.0.1 in debug mode." << endl;
							account_id = database.GetAccountIDByChar(name);
						}
						else
#endif
						{
							cout << "Client dropped: GetAuthentication = 0, n=" << tmp << endl;
							ret = false; // TODO: Can we tell the client to get lost in a good way
							break;
						}
					}
					if (client != 0)
						client->Kick();  // Bye Bye ghost

					admin = database.CheckStatus(account_id);
					database.GetAccountName(account_id, account_name);
					database.GetCharacterInfo(name, &character_id, &guilddbid, &guildrank);
					database.LoadFactionValues(&factionvalue_list,character_id);
					memset(&pp, 0, sizeof(PlayerProfile_Struct));
					int32 pplen = database.GetPlayerProfile(account_id, name, &pp);
					if (pplen == 0) {
						cout << "Client dropped: !GetPlayerProfile, name=" << name << endl;
						ret = false;
						break;
					}
					

					cout << "Loaded playerprofile for " << name << " - size: " << pplen << "/" << sizeof(PlayerProfile_Struct) << endl;

				    char temp1[64];
					if (database.GetVariable("Max_AAXP", temp1, sizeof(temp1)-1)) {
						max_AAXP = atoi(temp1);
					}
					  int32 aalen = database.GetPlayerAlternateAdv(account_id, name, &aa);
					  if(aalen == 0)
					  {
						cout << "Client dropped: !GetPlayerAlternateAdv, name=" << name << endl;
						ret = false;
						break;
					  }
					
					cout << "Loaded alt_adv_table for " << name << " - size: " << aalen << "/" << sizeof(PlayerAA_Struct) << endl;

					// Try to find the EQ ID for the guild, if doesnt exist, guild has been deleted.
					// Clear memory, but leave it in the DB (no reason not to, guild might be restored?)
					guildeqid = database.GetGuildEQID(guilddbid);
					if (guildeqid == 0xFFFFFFFF) {
						guilddbid = 0;
						guildrank = GUILD_MAX_RANK;
						pp.guildid = 0xFFFF;
					}
					else {
						pp.guildid = guildeqid;
					}
					strcpy(pp.name, name);
					strcpy(lastname, pp.last_name);
					if((pp.x == -1 && pp.y == -1 && pp.z == -1)||(pp.x == -2 && pp.y == -2 && pp.z == -2)) {
						//Fixed XYZ
						pp.x = zone->safe_x();
						pp.y = zone->safe_y();
						pp.z = zone->safe_z();
					}
					x_pos = pp.x;
					y_pos = pp.y;
					z_pos = pp.z+5;
					heading = pp.heading;
					race = pp.race;
					base_race = pp.race;
					class_ = pp.class_;
					gender = pp.gender;
					base_gender = pp.gender;
					level = pp.level;
					deity = DEITY_AGNOSTIC;
					haircolor = pp.haircolor;
					beardcolor = pp.beardcolor;
					eyecolor1 = pp.eyecolor1;
					eyecolor2 = pp.eyecolor2;
					hairstyle = pp.hairstyle;
					title = pp.title;
					luclinface = pp.luclinface;
					
					if (spells_loaded) {
						for (int i=0; i<15; i++) {
							if (pp.buffs[i].spellid <= SPDAT_RECORDS) {
								buffs[i].spellid = pp.buffs[i].spellid;
								buffs[i].ticsremaining = pp.buffs[i].duration;
								buffs[i].casterlevel = pp.buffs[i].level;
								buffs[i].casterid = 0;
								buffs[i].durationformula = spells[buffs[i].spellid].buffdurationformula;

								pp.buffs[i].b_unknown1 = 1;
							}
							else {
								buffs[i].spellid = 0xFFFF;

								pp.buffs[i].b_unknown1 = 0;
								pp.buffs[i].level = 0;
								pp.buffs[i].b_unknown2 = 0;
								pp.buffs[i].b_unknown3 = 0;
								pp.buffs[i].spellid = 0;
								pp.buffs[i].duration = 0;
							}
						}
					}
					if(this->isgrouped)
					{
					Group* group;
					group = entity_list.GetGroupByClient(this);
					for(int z=0; z<5; z++)
					{
					memset(pp.GMembers[z],0,sizeof(group->members[z]->GetName()));
					}
					}
					else
					{
					for(int z=0; z<5; z++)
					{
					memset(pp.GMembers[z],0,sizeof(pp.GMembers[0]));
					}
					}

					CalcBonuses();
					CalcMaxHP();
					CalcMaxMana();
					SetHP(pp.cur_hp);
					SetMana(pp.mana);

					pp.current_zone = database.GetZoneID(zone->GetFileName());
					APPLAYER *outapp;
					outapp = new APPLAYER;				
					outapp->opcode = OP_PlayerProfile;		
					outapp->pBuffer = new uchar[10000];			
					uint32 tmpbuffer = pp.exp;// well here we need to lie, to get the exp bar sync.
					pp.exp = ((float)330/(GetEXPForLevel(GetLevel()+1)-GetEXPForLevel(GetLevel()))) * (tmpbuffer-GetEXPForLevel(GetLevel()));		
					SetEQChecksum((unsigned char*)&pp, sizeof(PlayerProfile_Struct)-4); 
					outapp->size = DeflatePacket((unsigned char*)&pp, sizeof(PlayerProfile_Struct), outapp->pBuffer, 10000); 
					pp.exp = tmpbuffer; // but keep serverexp correct
					EncryptProfilePacket(outapp);
					QueuePacket(outapp);
					delete outapp;
					pp.current_zone = zone->GetZoneID();

					outapp = new APPLAYER(OP_ZoneEntry, sizeof(ServerZoneEntry_Struct));
					ServerZoneEntry_Struct *sze = (ServerZoneEntry_Struct*)outapp->pBuffer;
					memset(sze, 0, sizeof(ServerZoneEntry_Struct));
					strcpy(sze->name, name);
					strcpy(sze->lastname, lastname);
					sze->zone = zone->GetZoneID();
					sze->class_ = pp.class_;
					sze->race = pp.race;
					sze->gender = pp.gender;
					sze->level = pp.level;
					sze->x = pp.x;
					sze->y = pp.y;
					sze->z = pp.z/10;
					sze->heading = pp.heading;
					if(pp.pvp==1) {
						sze->pvp=1;
					}
					//GM Speed Hack
					if (admin>=100) {
						int8 gmspeed = database.GetGMSpeed(AccountID());
						if (gmspeed == 0) {
							sze->walkspeed = walkspeed;
							sze->runspeed = runspeed;
						}
						else {
							sze->walkspeed = 1.0;
							sze->runspeed = 3.0;
						}
					}
					else {
						sze->walkspeed = walkspeed;
						sze->runspeed = runspeed;
					}
					sze->anon = pp.anon;

					// Disgrace: proper face selection
					sze->face = GetFace();

					// Quagmire - added coder?'s code from messageboard
					const Item_Struct* item = database.GetItem(pp.inventory[2]);
					if (item) {
						sze->helmet = item->common.material;
// FIXME!						sze->helmcolor = item->common.color;
					}
					sze->npc_armor_graphic = 0xFF;  // tell client to display PC's gear

					// Quagmire - Found guild id =)
					// havent found the rank yet tho
					sze->guildeqid = (int16) guildeqid;

					//Grass clipping radius.
					sze->skyradius=500;
					//*shrug*
//					sze->unknown304[0]=255;
					sze->haircolor = haircolor;
					sze->beardcolor = beardcolor;
					sze->eyecolor1 = eyecolor1;
					sze->eyecolor2 = eyecolor2;
					sze->hairstyle = hairstyle;
					sze->title = title;
					sze->luclinface = luclinface;
					//sze->sze_unknown5_2_2[5] = 0xA0;

					SetEQChecksum((unsigned char*)sze, sizeof(ServerZoneEntry_Struct));
					QueuePacket(outapp);
					delete outapp;

					BulkSendInventoryItems(); // don't move this
					entity_list.SendZoneSpawnsBulk(this);

					outapp = new APPLAYER(OP_Weather, 8);
					if (zone->zone_weather == 1)
						outapp->pBuffer[6] = 0x31; // Rain
					if (zone->zone_weather == 2)
					{
						outapp->pBuffer[0] = 0x01;
						outapp->pBuffer[4] = 0x02; 
					}
					QueuePacket(outapp);
					delete outapp;
					//cout << "Sent addplayer... (EQ disconnects here on error)" << endl;


					
					outapp = new APPLAYER(OP_TimeOfDay, sizeof(TimeOfDay_Struct));
					TimeOfDay_Struct* tod = (TimeOfDay_Struct*)outapp->pBuffer;
					//TODO: Make this set itself to worldtime.
					tod->hour=9;
					tod->minute=0;
					tod->dayofmonth=1;
					tod->month=1;
					tod->year=1;
					QueuePacket(outapp);
					delete outapp;				
					//cout << "Sent timeofday... Next stop: Login 3." << endl;

					SetAttackTimer();
					client_state = CLIENT_CONNECTING3;

				}
				else {
					cout << "Unexpected packet during CLIENT_CONNECTING2: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					DumpPacket(app);
				}
				break;
			}
			case CLIENT_CONNECTING3: {
				if (app->opcode == 0x5d20) {
					cout << "Login packet 3" << endl; // Here the client sends tha character name again.. 
                                                      // not sure why, nothing else in this packet
					//SendInventoryItems();

					weapon1 = database.GetItem(pp.inventory[13]);
					weapon2 = database.GetItem(pp.inventory[14]);

					client_state = CLIENT_CONNECTING4;
				}
				else {
					cout << "Unexpected packet during CLIENT_CONNECTING3: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					DumpPacket(app);
				}
				break;
			}
			case CLIENT_CONNECTING4:
			{
				if (app->opcode == 0x0a20) {
					cout << "Zhdr request (Login 4)" << endl; // This packet was empty...

					APPLAYER* outapp;
					outapp = new APPLAYER(OP_NewZone, sizeof(NewZone_Struct));
					memcpy(outapp->pBuffer, &zone->newzone_data, outapp->size);
					QueuePacket(outapp);
					delete outapp;				

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
			   		outapp->size = 0;
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					cout << "Sending zonepoints...";
					if (database.MakeZonepointPacket(zone->GetShortName(),outapp))
					{
						//DumpPacket(outapp);
						QueuePacket(outapp);
						cout << "done" << endl;
					}
					else
						cout << endl << "WARNING: No Zonepoints for this zone in database found" << endl;
					delete outapp;

				// Inform the client about the world
				//	entity_list.SendZoneSpawns(this);
//					
					cout << "Sending objects...";
					entity_list.SendZoneObjects(this);
					cout << "done" << endl;

					client_state = CLIENT_CONNECTING5;
				}
				else {
					cout << "Unexpected packet during CLIENT_CONNECTING4: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					DumpPacket(app);
				}
				break;
			}
			case CLIENT_CONNECTING5:
			{
				if (app->opcode == 0xd820)
				{
					cout << "Enterzone complete (Login 5)" << endl;
					APPLAYER* outapp;
					outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
					SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
					sa->type = 0x10;			// Is 0x10 used to set the player id?
					sa->parameter = GetID();	// Four bytes for this parameter...
					QueuePacket(outapp);
					delete outapp;
					outapp = new APPLAYER;
					// Inform the world about the client
					CreateSpawnPacket(outapp);
					entity_list.QueueClients(this, outapp, false);
					delete outapp;

					outapp = new APPLAYER(OP_SetServerFilterAck, 24);
					QueuePacket(outapp);
					delete outapp;

					outapp = new APPLAYER;
					outapp->opcode = 0xd820; // Unknown
		   			outapp->size = 0;
					QueuePacket(outapp);
					delete outapp;

					SendAAStats();
					SendAATable();

					outapp = new APPLAYER;
					outapp->opcode = OP_Stamina; 
		   			outapp->size = sizeof(Stamina_Struct);
					outapp->pBuffer = new uchar[outapp->size];
					Stamina_Struct* sta = (Stamina_Struct*)outapp->pBuffer;
					sta->food = 127;
					sta->water = 125;
					sta->fatigue = 0;
					QueuePacket(outapp);
					delete outapp;

					// Guild ID is in sze now, rank still using this tho
					if (guilddbid != 0) {
						outapp = new APPLAYER(OP_SpawnAppearance, sizeof(SpawnAppearance_Struct));
						SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
						sa->spawn_id = GetID();
						sa->type = 23;
						if (guilds[guildeqid].rank[guildrank].warpeace || guilds[guildeqid].leader == account_id)
							sa->parameter = 2;
						else if (guilds[guildeqid].rank[guildrank].invite || guilds[guildeqid].rank[guildrank].remove || guilds[guildeqid].rank[guildrank].motd)
							sa->parameter = 1;
						else
							sa->parameter = 0;
						QueuePacket(outapp);
						delete outapp;
					}

					APPLAYER* outapp2 = new APPLAYER;
					cout << "Sending doorspawns...";
					if (database.MakeDoorSpawnPacket(zone->GetShortName(),outapp2))
					{
						//DumpPacket(outapp2);
						QueuePacket(outapp2);
						cout << "done" << endl;
												
					}
					else
						cout << "no doorspawns in DB for this zone" << endl;
					delete outapp2;

					//PP PVP flag doesn't work, setting it manually here...
					if(pp.pvp == 1) {
						SendAppearancePacket(4, 1);
					}
					
					  // Quagmire - Setting GM flag
					if (admin >= 80) {
						//PP GM flag doesn't work, setting it manually here.
						if(pp.gm == 1) {
							SendAppearancePacket(20, 1, false);
						}
						// Deleting all petitions off client *THIS DOESNT WORK AND ITS NOT REQUIRED, EQ CLIENT TAKES CARE OF IT*
						/*APPLAYER* outapp = new APPLAYER(0x0f20,sizeof(PetitionClientUpdate_Struct));
						PetitionClientUpdate_Struct* pet = (PetitionClientUpdate_Struct*) outapp->pBuffer;
						pet->color = 0x00;
						pet->status = 0xFF;
						/*pet->unknown[3] = 0x00;
						pet->unknown[2] = 0x00;
						pet->unknown[1] = 0x00;
						pet->unknown[0] = 0x00;*/
						/*pet->senttime=0;
						strcpy(pet->accountid, "");
						strcpy(pet->gmsenttoo, "");
						pet->quetotal = petition_list.GetMaxPetitionID();
						strcpy(pet->charname, "");
						int x = 0;
						for (x=0;x<5;x++) {
							pet->petnumber = x;
							QueuePacket(outapp);
						}
						delete outapp;*/
						petition_list.UpdateGMQueue();
					}
				

					position_timer->Start();
					UpdateWho(false);
					//SendAAPoints();


					//Tell them how many messages they have...
					Message(0, "You have %i messages. Type #msg list to show a list of your messages.", database.GetMessageNum(pp.name));


					// We are now fully connected and ready to play					
					client_state = CLIENT_CONNECTED;
				}
				else {
					//cout << "Unexpected packet during CLIENT_CONNECTING4: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					cout << "Unexpected packet during CLIENT_CONNECTING5: OpCode: 0x" << hex << setw(4) << setfill('0') << app->opcode << dec << ", size: " << app->size << endl;
					DumpPacket(app);
				}
				break;
			}
			case CLIENT_CONNECTED:
			{
				adverrorinfo = app->opcode; 
				switch(app->opcode)
				{
					case OP_AutoAttack:
					{
						if (app->size == 4)
						{
							if (app->pBuffer[0] == 0)
								auto_attack = false;
							else if (app->pBuffer[0] == 1)
								auto_attack = true;
						}
						else
						{
							cerr << "Wrong size " << app->size << " on OP_AutoAttack, should be 4" << endl; 
						}
						break;
					}
					case OP_ClientUpdate:
					{
						SpawnPositionUpdate_Struct* cu=(SpawnPositionUpdate_Struct*)app->pBuffer;
						if (app->size == sizeof(SpawnPositionUpdate_Struct))
						{
//							DumpPacketHex(app);
							appearance = cu->anim_type;
							if (casting_spell_id != 0 && (x_pos != (float)cu->x_pos || y_pos != (float)cu->y_pos || z_pos != (float)cu->z_pos) && GetClass() != BARD){
								int16 channelchance = (30+((float)this->GetSkill(13)/400)*100);
								if (((float)rand()/RAND_MAX)*100 > channelchance){
									this->isattacked = true;
									this->isinterrupted = true;
								}
								else
									this->isattacked = true;
							}
							x_pos = (float) cu->x_pos;
							y_pos = (float) cu->y_pos;
							z_pos = (float)cu->z_pos;
							delta_x = cu->delta_x/125;
							delta_y = cu->delta_y/125;
							delta_z = cu->delta_z;
							heading = cu->heading;
							delta_heading = cu->delta_heading;
/*
							cout << "X:"  << x_pos << " ";
							cout << "Y:"  << y_pos << " ";
							cout << "Z:"  << z_pos << " ";
							cout << "dX:" << delta_x << " ";
							cout << "dY:" << delta_y << " ";
							cout << "dZ:" << delta_z << " ";
							cout << "H:"  << (int)heading << " ";
							cout << "dH:" << (int)delta_heading << " ";
							cout << "Heading hex 0x" << hex << (int)heading << dec;




							cout << endl;
*/
//							SendPosUpdate(); // TODO: Move this outside this case
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(SpawnPositionUpdate_Struct) << " on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_ClientTarget: {
						if (app->size != sizeof(ClientTarget_Struct)) {
							cout << "Wrong size on OP_ClientTarget. Got: " << app->size << ", Expected: " << sizeof(ClientTarget_Struct) << endl;
							break;
						}
						ClientTarget_Struct* ct=(ClientTarget_Struct*)app->pBuffer;	
						target = entity_list.GetMob(ct->new_target);
						break;
					}
					case OP_Jump: {
//						cout << name << " jumped." << endl;
						break; 
					}
					case OP_Consider:     //03/09   -Merkur
					{
						Consider_Struct* conin = (Consider_Struct*)app->pBuffer;
						if (conin->targetid == GetID())
							break;		// don't consider yourself
						Mob* tmob = entity_list.GetMob(conin->targetid);
						if (tmob == 0)
							break;		
						APPLAYER* outapp = new APPLAYER(OP_Consider, sizeof(Consider_Struct));
						Consider_Struct* con = (Consider_Struct*)outapp->pBuffer;
						con->playerid = GetID();
						con->targetid = conin->targetid;
						con->faction = GetFactionLevel(character_id,tmob->GetNPCTypeID(), race, class_, DEITY_AGNOSTIC,(tmob->IsNPC()) ? tmob->CastToNPC()->GetFactionID():0); // rembrant, Dec. 20, 2001; TODO: Send the players proper deity								
						con->level = GetLevelCon(this->GetLevel(),tmob->GetLevel());
						QueuePacket(outapp);
						delete outapp;			
						break;
					}
					case OP_Surname:
					{
						Surname_Struct* surname = (Surname_Struct*) app->pBuffer;
						surname->s_unknown1 = 0;
						surname->s_unknown2 = 1;
						surname->s_unknown3 = 1;
						surname->s_unknown4 = 1;
						printf("Test: %s %s\n",surname->name,surname->lastname);
						this->CastToClient()->ChangeLastName(surname->lastname);
						APPLAYER* outapp = new APPLAYER(OP_GMLastName, sizeof(GMLastName_Struct));
						GMLastName_Struct* lnc = (GMLastName_Struct*) outapp->pBuffer;
						strcpy(lnc->name, surname->name);
						strcpy(lnc->lastname, surname->lastname);
						strcpy(lnc->gmname, "SurnameOP");
						lnc->unknown[0] = 1;
						lnc->unknown[1] = 1;
						printf("Test: %s %s\n",lnc->name,lnc->lastname);
						entity_list.QueueClients(this, outapp, false);
						QueuePacket(app);
						break;
					}
					case OP_YellForHelp: // Pyro
					{
						cout << name << " yells for help." << endl;
						entity_list.QueueCloseClients(this,app, true, 100.0);
						// TODO: write a msg send routine
						break;
					}
					case OP_SafePoint: // Pyro
					{
						cout << name << "is beneath the world. Packet:" << endl;
						DumpPacket(app);
						//Underworld_Struct* uw = (Underworld_Struct*)app;
						//cout << name << " is beneath the world at " << uw->x << " " << uw->y << " " << uw->z << ". Speed=" << uw->speed << endl;
						// This is handled clientside
						break;
					}
					case OP_SpawnAppearance:
					{
						if (app->size != sizeof(SpawnAppearance_Struct)) {
							cout << "Wrong size on OP_SpawnAppearance. Got: " << app->size << ", Expected: " << sizeof(SpawnAppearance_Struct) << endl;
							break;
						}
						SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)app->pBuffer;
						if (sa->type == 0x0e)
						{
							if (sa->parameter == 0x64)
							{
//								cout << "Client " << name << " standing" << endl;
								appearance = 0;
								playeraction = 0;
							}
							else if (sa->parameter == 0x6e)
							{
//								cout << "Client " << name << " sitting" << endl;
								appearance = 1;
								playeraction = 1;
								InterruptSpell();
							}
							else if (sa->parameter == 0x6f)
							{
//								cout << "Client " << name << " ducking" << endl;
								appearance = 2;
								playeraction = 2;
								InterruptSpell();
							}
							else if (sa->parameter == 0x73)
							{
//								cout << "Client " << name << " unconscious" << endl;
								appearance = 3;
								playeraction = 3;
								InterruptSpell();
							}
							else if (sa->parameter == 105)
							{
//								cout << "Client " << name << " looting" << endl;
								appearance = 3;
								playeraction = 4;
							}
							else
							{
								cerr << "Client " << name << " unknown apperance " << (int)sa->parameter << endl;
								break;
							}
							APPLAYER* outapp = new APPLAYER;;
							outapp->opcode = OP_SpawnAppearance;
							outapp->size = sizeof(SpawnAppearance_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							memset(outapp->pBuffer, 0, outapp->size);
							SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
							sa_out->spawn_id = GetID();
							sa_out->type = 0x0e;
							sa_out->parameter = sa->parameter;
							entity_list.QueueClients(this, app, true);
							delete outapp;
						}
						else if (sa->type == 0x15) { // For Anon/Roleplay
							if (sa->parameter == 1) { // This is Anon
								cout << "Client " << name << " Going Anon" << endl;
								pp.anon = 1;
							}
							else if (sa->parameter == 2 || sa->parameter == 3) { // This is Roleplay, or anon+rp
								cout << "Client " << name << " Going Roleplay" << endl;
								pp.anon = 2;
							}
							else if (sa->parameter == 0) { // This is Non-Anon
								cout << "Client " << name << " Going Un-Anon/Roleplay" << endl;
								pp.anon = 0;
							}
							else {
								cerr << "Client " << name << " unknown Anon/Roleplay Switch " << (int)sa->parameter << endl;
								break;
							}
/*							APPLAYER* outapp = new APPLAYER;;
							outapp->opcode = OP_SpawnAppearance;
							outapp->size = sizeof(SpawnAppearance_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							memset(outapp->pBuffer, 0, outapp->size);
							SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
							sa_out->spawn_id = GetID();
							sa_out->type = 0x15;
							sa_out->parameter = sa->parameter;*/
							entity_list.QueueClients(this, app, true);
							UpdateWho();
//							delete outapp;
						}
						else if (sa->type = 0x11) { // this is the client notifing the server of a hp regen tic
							// ok, this didnt work so well.
//							SetHP(sa->parameter);
//							SendHPUpdate();
						}
						else if (sa->type == 0x03) { // This should be normal invisibility
							if (sa->parameter == 0) // Visible
								cout << "Visible" << endl;
							if (sa->parameter == 1) // Invisi
								cout << "Invisi" << endl;
							else cout << "Unknown Invisi" << endl;
						}
						else {
cout << "Unknown SpawnAppearance type: 0x" << hex << setw(4) << setfill('0') << sa->type << dec << " value: 0x" << hex << setw(8) << setfill('0') << sa->parameter << dec << endl;
						}
						break;
					}
					case OP_Death:
					{
						Death(0, 0);
						break;
					}
					case 0x2921:
					{
						break;
					}
					case OP_MoveCoin: 
					{
						MoveCoin_Struct* mc = (MoveCoin_Struct*)app->pBuffer;
						if (mc->from_slot == 1) {
							switch (mc->cointype1)
							{
							case 0:
								if ((pp.copper - mc->amount) < 0) {
									cout << "Error in OP_MoveCoin: negative value)" << endl;
										pp.copper = 0;
								}
								pp.copper = pp.copper - mc->amount;
								break;
							case 1:
								if ((pp.silver - mc->amount) < 0) {
									cout << "Error in OP_MoveCoin: negative value)" << endl;
										pp.silver = 0;
								}
								pp.silver = pp.silver - mc->amount;
								break;
							case 2:
								if ((pp.gold - mc->amount) < 0) {
									cout << "Error in OP_MoveCoin: negative value)" << endl;
										pp.gold = 0;
								}
								pp.gold = pp.gold - mc->amount;
								break;
							case 3:
								if ((pp.platinum - mc->amount) < 0) {
									cout << "Error in OP_MoveCoin: negative value)" << endl;
										pp.platinum = 0;
								}
								pp.platinum = pp.platinum - mc->amount;
								break;
							}
						}
						if (mc->to_slot == 1) {
							switch (mc->cointype1)
							{
							case 0:
								AddMoneyToPP(mc->amount,0,0,0);
								break;
							case 1:
								AddMoneyToPP(0,mc->amount,0,0);
								break;
							case 2:
								AddMoneyToPP(0,0,mc->amount,0);
								break;
							case 3:
								AddMoneyToPP(0,0,0,mc->amount);
								break;
							}
						}
						// slot 3 = trading
						break;
					}
					case OP_MoveItem: 
					{
						if (app->size != sizeof(MoveItem_Struct)) {
							cout << "Wrong size on OP_MoveItem. Got: " << app->size << ", Expected: " << sizeof(MoveItem_Struct) << endl;
							break;
						}
						MoveItem_Struct* mi = (MoveItem_Struct*)app->pBuffer; 
						uint16* to_slot = 0;
						uint16* to_bag_slots = 0;
						uint16* from_slot = 0;
						uint16* from_bag_slots = 0;
						uint8*	from_charges = 0;
						uint8*	to_charges	= 0;
						ItemProperties_Struct*	from_bag_charges = 0;
						ItemProperties_Struct*	to_bag_charges	= 0;
						uint8	chargesmoved = 0;
						uint8	chargesreplaced	= 0;
						uint16 itemmoved = 0xFFFF;
						uint16 itemreplaced = 0xFFFF;
						if (mi->to_slot == 0 || (mi->to_slot >= 22 && mi->to_slot <= 29)) {
							to_slot = &(pp.inventory[mi->to_slot]);
							to_charges =&(pp.invitemproperties[mi->to_slot].charges);
							if (mi->to_slot == 0){
								to_bag_slots = &pp.cursorbaginventory[0];
								to_bag_charges =&(pp.cursorbagitemproperties[0]);
							}
							else{
								to_bag_slots = &pp.containerinv[(mi->to_slot-22)*10];
								to_bag_charges =&(pp.bagitemproperties[(mi->to_slot-22)*10]);
							}
						}
						else if (mi->to_slot >= 1 && mi->to_slot <= 21){ // Worn items and main inventory
							to_charges =&(pp.invitemproperties[mi->to_slot].charges);
							to_slot = &(pp.inventory[mi->to_slot]);
						}
						else if (mi->to_slot >= 250 && mi->to_slot <= 329){ // Main inventory's containers
							to_slot = &(pp.containerinv[mi->to_slot-250]);
							to_charges =&(pp.bagitemproperties[mi->to_slot-250].charges);
						}
						else if (mi->to_slot >= 2000 && mi->to_slot <= 2007) { // Bank slots
							to_slot = &(pp.bank_inv[mi->to_slot-2000]);
							to_bag_slots = &pp.bank_cont_inv[(mi->to_slot-2000)*10];
							to_bag_charges = &pp.bankbagitemproperties[(mi->to_slot-2000)*10];
							to_charges =&(pp.bankinvitemproperties[mi->to_slot-2000].charges);
						}
						else if (mi->to_slot >= 2030 && mi->to_slot <= 2109){ // Bank's containers
							to_slot = &(pp.bank_cont_inv[mi->to_slot-2030]);
							to_charges =&(pp.bankbagitemproperties[mi->to_slot-2030].charges);
						}
						else if (mi->to_slot >= 3000 && mi->to_slot < 3016) {
							cout << "trade item" << endl;
							TradeList[mi->to_slot-3000] = GetItemAt(0);
							TradeCharges[mi->to_slot-3000] = pp.invitemproperties[0].charges;
							for (int j = 0;j != 10;j++)
							{
								TradeList[((mi->to_slot-2999)*10)+j] = pp.cursorbaginventory[j];

								TradeCharges[((mi->to_slot-2999)*10)+j] = pp.cursorbagitemproperties[j].charges;

							}
							to_slot = 0;
							if (this->TradeWithEnt != 0 && entity_list.GetID(this->TradeWithEnt)->IsClient()){
								APPLAYER* outapp = new APPLAYER(OP_ItemToTrade,sizeof(ItemToTrade_Struct));
								ItemToTrade_Struct* ti = (ItemToTrade_Struct*)outapp->pBuffer;
								memset(outapp->pBuffer,0,outapp->size);
								memcpy(&ti->item,database.GetItem(GetItemAt(mi->from_slot)),sizeof(Item_Struct));
								ti->item.common.charges = pp.invitemproperties[0].charges;
								ti->toslot = mi->to_slot-3000;
								ti->playerid = this->TradeWithEnt;
								entity_list.GetID(this->TradeWithEnt)->CastToClient()->QueuePacket(outapp);
							
							}
							
							cout << "Item is " << TradeList[mi->to_slot-3000] << endl;

						}
						else if (mi->to_slot == 0xFFFFFFFF) // destroy button
							to_slot = 0;
						else {
							Message(0, "Error: OP_MoveItem: Unknown to_slot: 0x%04x", mi->to_slot);
							to_slot = 0;
						}

						if (mi->from_slot == 0 || (mi->from_slot >= 22 && mi->from_slot <= 29)) {
							from_slot = &(pp.inventory[mi->from_slot]);
							from_charges =&(pp.invitemproperties[mi->from_slot].charges);
							if (mi->from_slot == 0)
							{
								from_bag_slots = &pp.cursorbaginventory[0];
								from_bag_charges =&(pp.cursorbagitemproperties[0]);
							}
							else {
								from_bag_slots = &pp.containerinv[(mi->from_slot-22)*10];
								from_bag_charges =&(pp.bagitemproperties[(mi->from_slot-22)*10]);
							}
						}
						else if (mi->from_slot >= 1 && mi->from_slot <= 21){ // Worn items and main inventory
							from_slot = &(pp.inventory[mi->from_slot]);
							from_charges =&(pp.invitemproperties[mi->from_slot].charges);
						}
						else if (mi->from_slot >= 250 && mi->from_slot <= 329){ // Main inventory's containers
							from_slot = &(pp.containerinv[mi->from_slot-250]);
							from_charges =&(pp.bagitemproperties[mi->from_slot-250].charges);
						}
						else if (mi->from_slot >= 2000 && mi->from_slot <= 2007) { // Bank slots
							from_slot = &(pp.bank_inv[mi->from_slot-2000]);
							from_bag_slots = &pp.bank_cont_inv[(mi->from_slot-2000)*10];
							from_bag_charges = &pp.bankbagitemproperties[(mi->from_slot-2000)*10];
							from_charges =&(pp.bankinvitemproperties[mi->from_slot-2000].charges);
						}
						else if (mi->from_slot >= 2030 && mi->from_slot <= 2109){ // Bank's containers
							from_slot = &(pp.bank_cont_inv[mi->from_slot-2030]);
							from_charges =&(pp.bankbagitemproperties[mi->from_slot-2030].charges);
						}
						else {
							Message(0, "Error: OP_MoveItem: Unknown from_slot: 0x%04x", mi->from_slot);
							from_slot = 0;
						}

						int i = 0;
						const Item_Struct* tmp = database.GetItem(*from_slot);

						if (tmp != 0 && tmp->common.normal.stackable == 1)
							cout << "Item is stackable" << endl;
						else if (tmp != 0)
							cout << "Item is not stackable" << endl;
						else
							cout << "Item is invalid!" << endl;

						if (tmp != 0 && tmp->common.normal.stackable == 1 && from_slot != 0 && to_slot != 0 && from_slot != to_slot && *from_slot==*to_slot) {
							//stacks
							*to_charges += (mi->number_in_stack == 0) ? *from_charges:mi->number_in_stack;
							if (*to_charges <= 20){
								*from_slot = 0xFFFF;
								*from_charges -= (mi->number_in_stack == 0) ? 1:mi->number_in_stack;
							}
							else
								*from_charges = *to_charges-20;
						}
						else
						{
							if (from_slot != 0)
							{
								itemmoved = *from_slot;
								chargesmoved = (mi->number_in_stack == 0) ? 1:mi->number_in_stack;
							}
							if (to_slot != 0)
							{
								itemreplaced = *to_slot;
								*to_slot = itemmoved;
								if (to_charges != 0){
									chargesreplaced = *to_charges;
									*to_charges = (mi->number_in_stack == 0) ? *from_charges:mi->number_in_stack;
								}
							}
							
							if (from_slot != 0)
							{
								if (from_charges != 0)
								{	
									*from_charges = (mi->number_in_stack == 0) ? chargesreplaced:*from_charges-mi->number_in_stack;
									if (*from_charges == 0 || itemreplaced != 0xFFFF)
										*from_slot = itemreplaced;
								}		
							}
						}
						const Item_Struct* item;
						Item_Struct* outitem = 0;
						for (i=0; i<10; i++) {
							itemmoved = 0xFFFF;
							itemreplaced = 0xFFFF;
							chargesmoved = 0;
							chargesreplaced = 0;

							if (from_bag_charges != 0)
								chargesmoved = from_bag_charges[i].charges;
							if (to_bag_charges != 0)
								chargesreplaced = to_bag_charges[i].charges;
							if (to_bag_charges != 0)
								to_bag_charges[i].charges = chargesmoved;
							if (from_bag_charges != 0)
								from_bag_charges[i].charges = chargesreplaced;

							if (from_bag_slots != 0)
								itemmoved = from_bag_slots[i];
							if (to_bag_slots != 0)
								itemreplaced = to_bag_slots[i];
							if (to_bag_slots != 0)
								to_bag_slots[i] = itemmoved;
							if (from_bag_slots != 0)
								from_bag_slots[i] = itemreplaced;
							
							if (pp.cursorbaginventory[i] != 0xFFFF && mi->to_slot == 0 && mi->from_slot == 0) {
							item = database.GetItem(pp.cursorbaginventory[i]);				
								APPLAYER* app2 = new APPLAYER;
								app2->opcode = 0x3120;
								app2->size = sizeof(Item_Struct);
								app2->pBuffer = new uchar[app2->size];
								memcpy(app2->pBuffer, item, sizeof(Item_Struct));
								outitem = (Item_Struct*) app2->pBuffer;
								outitem->equipSlot = (mi->to_slot-22)*10+250 + i;
								outitem->common.charges = pp.cursorbagitemproperties[i].charges;
								QueuePacket(app2);
								delete app2; 
								
							}
							if (pp.cursorbaginventory[i] != 0xFFFF && mi->to_slot != 0){
								pp.cursorbaginventory[i] = 0xFFFF;
								pp.cursorbagitemproperties[i].charges =0;
							}
							// end
						}
						
					/*	if (mi->to_slot == 0xFFFFFFFF)
							cout << "Moved " << itemmoved << " from: " << mi->from_slot << " to: destroy button" << endl;
						else
							cout << "Moved " << itemmoved << " from: " << mi->from_slot << " to: " << mi->to_slot << " qty: " << mi->number_in_stack << endl;
						*/
						sint16 tx1 = (to_charges == 0) ? 0:(sint8)*to_charges;
						sint16 tx2 = (from_charges == 0) ? 0:(sint8)*from_charges;
						cout << "toCharges: " << tx1 << " from_charges: " << tx2 << endl;

						if ((mi->from_slot >= 1 && mi->from_slot <= 21) || (mi->to_slot >= 1 && mi->to_slot <= 21))
							this->CalcBonuses(); // Update item/spell bonuses
						if (mi->from_slot == 13 || mi->to_slot == 14) {
							SetAttackTimer();
						}
						if(mi->to_slot == 13 || mi->from_slot == 13) {
							uint16 item_id = pp.inventory[13];
							weapon1 = database.GetItem(item_id);
						}
						if (mi->to_slot == 14 || mi->from_slot == 14) {
							uint16 item_id = pp.inventory[14];
							weapon2 = database.GetItem(item_id);
						}
						break; 
					} 
					case OP_Camp:
					{
						Save();
						if (admin >= 100) {
							APPLAYER* outapp;
							outapp = new APPLAYER;
							outapp->opcode = OP_SpawnAppearance; 
		   					outapp->size = sizeof(SpawnAppearance_Struct);
							outapp->pBuffer = new uchar[outapp->size];
							memset(outapp->pBuffer, 0, outapp->size);
							SpawnAppearance_Struct* sa = (SpawnAppearance_Struct*)outapp->pBuffer;
							sa->type = 0x10;			// Is 0x10 used to set the player id?
							sa->parameter = 0;	// Four bytes for this parameter...
							QueuePacket(outapp);
							delete outapp;
							eqnc->Close();
						}
						// TODO: Implement camp, LD and all that
						// camp_timer->Start(30000);
						break;
					}
					case OP_Sneak:
					{
						// TODO: Implement sneak
						ChannelMessageSend(0,0,7,0,"Sneak not implemented");
						break;
					}
					case OP_Hide:
					{
						// TODO: Implement hide
						ChannelMessageSend(0,0,7,0,"Hide not implemented");
						break;
					}
					case OP_ChannelMessage:
					{
						ChannelMessage_Struct* cm=(ChannelMessage_Struct*)app->pBuffer;

						if (app->size > sizeof(ChannelMessage_Struct))
						{
							ChannelMessageReceived(cm->chan_num, cm->language, &cm->message[0], &cm->targetname[0]);
						}
						else
						{
							cout << "Wrong size " << app->size << ", should be " << sizeof(ChannelMessage_Struct) << "+ on 0x" << hex << setfill('0') << setw(4) << app->opcode << dec << endl;
						}
						break;
					}
					case OP_WearChange:
					{
						if (app->size != sizeof(WearChange_Struct)) {
							cout << "Wrong size: OP_WearChange, size=" << app->size << ", expected " << sizeof(WearChange_Struct) << endl;
							DumpPacket(app);
							break;
						}
						WearChange_Struct* wc=(WearChange_Struct*)app->pBuffer;
						entity_list.QueueClients(this, app, true);
						break;
					}
					case OP_ZoneChange: {
						if (app->size != sizeof(ZoneChange_Struct)) {
							cout << "Wrong size: OP_ZoneChange, size=" << app->size << ", expected " << sizeof(ZoneChange_Struct) << endl;
							DumpPacket(app);
							break;
						}
						if (this->isgrouped && entity_list.GetGroupByClient(this) != 0)	
							entity_list.GetGroupByClient(this)->DelMember(this);

						ZoneChange_Struct* zc=(ZoneChange_Struct*)app->pBuffer;
						float tarx = -1, tary = -1, tarz = -1;
						int8 minstatus = 0;
						int8 minlevel = 0;
						char tarzone[32];
						if (zc->zoneID == 0)
							strcpy(tarzone, zonesummon_name);
						else if (database.GetZoneName(zc->zoneID))
							strcpy(tarzone, database.GetZoneName(zc->zoneID));
						else
							tarzone[0] = 0;
						cout << "Zone request for:" << zc->char_name << " to: " << tarzone << "(" << database.GetZoneID(tarzone) << ")" << endl;
				
						// this both loads the safe points and does a sanity check on zone name
						if (!database.GetSafePoints(tarzone, &tarx, &tary, &tarz, &minstatus, &minlevel)) {
							tarzone[0] = 0;

						}
						if (zonesummon_ignorerestrictions) {
							minstatus = 0;
							minlevel = 0;
						}
						zonesummon_ignorerestrictions = false;

						cout << "Player at x:" << x_pos << " y:" << y_pos << " z:" << z_pos << endl;
						ZonePoint* zone_point = zone->GetClosestZonePoint(x_pos, y_pos, z_pos, zc->zoneID);
						
						tarx=zonesummon_x;
						tary=zonesummon_y;
						tarz=zonesummon_z;
			
						// -1, -1, -1 = code for zone safe point
						if ((x_pos == -1 && y_pos == -1 && (z_pos == -1 || z_pos == -10)) ||
							(zonesummon_x == -1 && zonesummon_y == -1 && zonesummon_z == -1)) {
							cout << "Zoning to safe coords: " << tarzone << " (" << database.GetZoneID(tarzone) << ")" << endl;
							tarx=-1;
							tary=-1;
							tarz=-1;
							zonesummon_x = -2;
							zonesummon_y = -2;
							zonesummon_z = -2;
						} // -3 -3 -3 = bind point
						else if (x_pos == -3 && y_pos == -3 && (z_pos == -3 || z_pos == -30) && database.GetZoneName(pp.bind_point_zone)) {
							strcpy(tarzone, database.GetZoneName(pp.bind_point_zone)); //copy bindzone to target
							tarx=pp.bind_location[0][0]; //copy bind cords to target
							tary=pp.bind_location[1][0];
							tarz=pp.bind_location[2][0];
							cout << "Zoning: Death, zoning to bind point: " << tarzone << " (" << database.GetZoneID(tarzone) << ")" << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
							zonesummon_x = -2;
							zonesummon_y = -2;
							zonesummon_z = -2;
							minstatus = 0;
							minlevel = 0;
						} // if not -2 -2 -2, zone to these coords. -2, -2, -2 = not a zonesummon zonerequest
						else if (!(zonesummon_x == -2 && zonesummon_y == -2 && (zonesummon_z == -2 || zonesummon_z == -20))) {
							tarx = zonesummon_x;
							tary = zonesummon_y;
							tarz = zonesummon_z;
							cout << "Zoning to specified cords: " << tarzone << " (" << database.GetZoneID(tarzone) << ")" << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
							zonesummon_x = -2;
							zonesummon_y = -2;
							zonesummon_z = -2;
						}
						else if (zone_point != 0) {
							cout << "Zone point found at x:" << zone_point->x << " y:" << zone_point->y << " z:" << zone_point->z << endl;
							tarx = zone_point->target_x;
							tary = zone_point->target_y;
							tarz = zone_point->target_z;
						}
						else
						{
							cout << "WARNING: No target coords for this zone in DB found" << endl;
							cout << "Zoning to safe coords: " << tarzone << " (" << database.GetZoneID(tarzone) << ")" << ", x=" << tarx << ", y=" << tary << ", z=" << tarz << endl;
							tarx=-1;
							tary=-1;
							tarz=-1;
							zonesummon_x = -2;
							zonesummon_y = -2;
							zonesummon_z = -2;
						}
						/*else
						{
							cout << "Zoning to coords x = " << tarx << "; y = " << tary << "; z = " << tarz << endl;
						}*/

						if (admin < minstatus)
							Message(13, "Your not awesome enough to enter %s.", tarzone);
						else if (GetLevel() < minlevel)
							Message(13, "Your will is not strong enough to enter %s", tarzone);

						//Message(13, "Zone request to %s (%i).", tarzone, database.GetZoneID(tarzone));

						APPLAYER* outapp;
						if (tarzone[0] != 0 && admin >= minstatus && GetLevel() >= minlevel)
						{
							cout << "Zoning player to:" << tarzone << " (" << database.GetZoneID(tarzone) << ")" << " x:" << tarx << " y:" << tary << " z:" << tarz << endl;

/*								outapp = new APPLAYER;
							outapp->opcode = 0xdb20;
							outapp->size = 0;
							QueuePacket(outapp);
							delete outapp;
							
							outapp = new APPLAYER;
							outapp->opcode = 0x1020;
							outapp->size = 0;
							QueuePacket(outapp);					
							delete outapp;*/
							
							outapp = new APPLAYER(OP_ZoneChange, sizeof(ZoneChange_Struct));
							ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
							strcpy(zc2->char_name, zc->char_name);
							zc2->zoneID = database.GetZoneID(tarzone);
							zc2->success = 1;

							// The client seems to dump this profile on us, but I ignore it for now. Saving is client initiated?
							x_pos = tarx; // Hmm, these coordinates will now be saved when ~client is called
							y_pos = tary;
							z_pos = tarz;
							pp.current_zone = database.GetZoneID(tarzone);
							Save();

							database.SetAuthentication(account_id, zc->char_name, tarzone, ip); // We have to tell the world server somehow?
							QueuePacket(outapp);
							delete outapp;
							cout << "Zoning complete" << endl;
						}
						else
						{
							cerr << "Zone " << zc->zoneID << " is not available" << endl;

/*								outapp = new APPLAYER;
							outapp->opcode = 0xdb20;
					   		outapp->size = 0;
							QueuePacket(outapp);
							delete outapp;

							outapp = new APPLAYER;
							outapp->opcode = 0x1020;
					   		outapp->size = 0;
							QueuePacket(outapp);					
							delete outapp;*/

							outapp = new APPLAYER(OP_ZoneChange, sizeof(ZoneChange_Struct));
							ZoneChange_Struct *zc2 = (ZoneChange_Struct*)outapp->pBuffer;
							strcpy(zc2->char_name, zc->char_name);
							zc2->zoneID = zc->zoneID;
							zc2->success = 0;
							QueuePacket(outapp);
							delete outapp;
						}
						break;
					}
					case OP_DeleteSpawn:
					{
						// The client will send this with his id when he zones, maybe when he disconnects too?
						// When zoning he seems to want 5921 and finish flag
						cout << "Player attempting to delete spawn: " << name << endl;
						APPLAYER* outapp;
						outapp = new APPLAYER;
						outapp->opcode = 0x5921;
	   					outapp->size = 0;
						QueuePacket(outapp);
						delete outapp;

						eqnc->Close();

						break;
					}
					case 0x5521: { // Client dumps player profile on zoning, is this same opcode as saving?
						if (app->size != sizeof(PlayerProfile_Struct)) { //							DumpPacket(app);
							cout << "Wrong size on 0x5521. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) << endl;
							Save();
							break;
						}
						cout << "Got a player save request (0x5521)" << endl;
						PlayerProfile_Struct* in_pp = (PlayerProfile_Struct*) app->pBuffer;
						x_pos = in_pp->x;
						y_pos = in_pp->y;
						z_pos = in_pp->z;
						heading = in_pp->heading;
						Save();
						break;
					}
					case OP_Save: {
#ifdef _DEBUG
//FileDumpPacket("playerprofile.txt", app);
#endif
//DumpPacket(app);
						if (app->size != sizeof(PlayerProfile_Struct)) {
							cout << "Wrong size on OP_Save. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) << endl;
							break;
						}
						cout << "Got a player save request (OP_Save)" << endl;
						PlayerProfile_Struct* in_pp = (PlayerProfile_Struct*) app->pBuffer;
						x_pos = in_pp->x;
						y_pos = in_pp->y;
						z_pos = in_pp->z;
						heading = in_pp->heading;
						/*cout << "***************************************" << endl;
						cout << "*NEW PLAYERPROFILE * NEW PLAYERPROFILE*" << endl;
						cout << "***************************************" << endl;
						cout << "Got PlayerProfileSave... PLAYERPROFILE=" << endl; 
						DumpPacket(app);*/
/*						memcpy(&pp, app->pBuffer, app->size);
		if (!database.SetPlayerProfile(account_id, name, &pp)) {
			cerr << "Failed to update player profile" << endl;
		}
		int tmp = 50;
		tmp = tmp / 0;
*/
/*						const Item_Struct* item = 0;
						int i;
						for (i=0; i < 8; i++) {
							item = database.GetItem(in_pp->bank_inv[i]);
							if (item != 0)
								cout << 3980 + (i * 2) << ": Slot " << i << ": " << item->name << endl;
							else
								cout << 3980 + (i * 2) << ": Slot " << i << ": empty" << endl;
						}
						for (i=0; i < 80; i++) {
							item = database.GetItem(in_pp->bank_cont_inv[i]);
							if (item != 0)
								cout << 3980 + (i * 2) << ": Bag: " << i/10 << ", Slot " << i%10 << ": " << item->name << endl;
							else
								cout << 3980 + (i * 2) << ": Bag: " << i/10 << ", Slot " << i%10 << ": empty" << endl;
						}*/

						Save();
						break;
					}
					case OP_AutoAttack2: // Why 2
					{
						break;
					}
					case OP_WhoAll: { // Pyro
						if (app->size != sizeof(Who_All_Struct)) {
							cout << "Wrong size on OP_WhoAll. Got: " << app->size << ", Expected: " << sizeof(Who_All_Struct) << endl;
							DumpPacket(app);
							break;
						}
						Who_All_Struct* whoall = (Who_All_Struct*) app->pBuffer;
						WhoAll(whoall);
						break;
					}
					case OP_GMZoneRequest: { // Quagmire
						DumpPacket(app);

						if (app->size != sizeof(GMZoneRequest_Struct)) {
							cout << "Wrong size on OP_GMZoneRequest. Got: " << app->size << ", Expected: " << sizeof(GMZoneRequest_Struct) << endl;
							break;
						}
						GMZoneRequest_Struct* gmzr = (GMZoneRequest_Struct*) app->pBuffer;
						/*BEGIN CODE FROM ZoneChange - Slightly modified to work with the GMZR struct...*/
						float tarx = -1, tary = -1, tarz = -1;
						int8 minstatus = 0;
						int8 minlevel = 0;
						char tarzone[32];
						if (gmzr->zoneID == 0)
							strcpy(tarzone, zonesummon_name);
						else if (database.GetZoneName(gmzr->zoneID))
							strcpy(tarzone, database.GetZoneName(gmzr->zoneID));
						else
							tarzone[0] = 0;
						cout << "GMZone request for:" << name << " to: " << tarzone << "(" << database.GetZoneID(tarzone) << ")" << endl;
				
						// this both loads the safe points and does a sanity check on zone name
						if (!database.GetSafePoints(tarzone, &tarx, &tary, &tarz, &minstatus, &minlevel)) {
							tarzone[0] = 0;
						}
						/*END CODE FROM ZoneChange*/
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_GMZoneRequest;
						outapp->size = sizeof(GMZoneRequest_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						memset(outapp->pBuffer, 0, outapp->size);
						GMZoneRequest_Struct* gmzr2 = (GMZoneRequest_Struct*) outapp->pBuffer;
						strcpy(gmzr2->charname, this->GetName());
						gmzr2->zoneID = gmzr->zoneID;
						//Next line stolen from ZoneChange as well... - This gives us a nicer message than the normal "zone is down" message...
						if (tarzone[0] != 0 && admin >= minstatus && GetLevel() >= minlevel)
							gmzr2->success = 1;
						else {
							cout << "GetZoneSafeCoords failed. zoneid = " << gmzr->zoneID << "; czone = " << zone->GetZoneID() << endl;
							gmzr2->success = 0;
						}
						//In case of fire, break glass...
						//this->MovePC(gmzr->zoneID, -1, -1, -1);
						QueuePacket(outapp);
						delete outapp;
						break;
					}
					case OP_GMZoneRequest2: {
						int32 zonereq = (int32)*app->pBuffer;
						cout << "OP_GMZoneRequest2: size=" << app->size << "; data = " << zonereq << "; czone = " << zone->GetZoneID() << endl;
						//DumpPacket(app);
						//if (strcasecmp((char*) app->pBuffer, zone->GetShortName()) == 0)
						if(zonereq == zone->GetZoneID())
						{
							//Fixed XYZ
							this->MovePC(zonereq, zone->safe_x(), zone->safe_y(), zone->safe_z(), false, false);
						}
						else
							this->MovePC(zonereq, -1, -1, -1, false, false);
						break;
					}
					case OP_EndLootRequest:
					{
						if (app->size != sizeof(int16)) {
							cout << "Wrong size: OP_EndLootRequest, size=" << app->size << ", expected " << sizeof(int16) << endl;
							break;
						}
						cout << "got end loot request" << endl;

						APPLAYER* outapp = 0;
						Entity* entity = entity_list.GetID(*((int16*)app->pBuffer));
						if (entity == 0)
						{
							DumpPacket(app);
							Message(13, "Error: OP_EndLootRequest: Corpse not found (ent = 0)");
							Corpse::SendEndLootErrorPacket(this);
							break;
						}
						if (!entity->IsCorpse()) {
							DumpPacket(app);
							Message(13, "Error: OP_EndLootRequest: Corpse not found (!entity->IsCorpse())");
							Corpse::SendEndLootErrorPacket(this);
							break;
						}
						entity->CastToCorpse()->EndLoot(this, app);
						break;
					}
					case OP_LootRequest:
					{
						if (app->size != sizeof(int16)) {
							cout << "Wrong size: OP_LootRequest, size=" << app->size << ", expected " << sizeof(int16) << endl;
							break;
						}
						Entity* ent = entity_list.GetID(*((int16*)app->pBuffer));
						if (ent == 0) {
							DumpPacket(app);
							Message(13, "Error: OP_LootRequest: Corpse not found (ent = 0)");
							Corpse::SendLootReqErrorPacket(this);
							break; // Quagmire - crash bug fix
						}
						if (ent->IsCorpse()) {
							ent->CastToCorpse()->MakeLootRequestPackets(this, app);
							break;
						}
						else {
							cout << "npc == 0 LOOTING FOOKED3" << endl;
							Message(13, "Error: OP_LootRequest: Corpse not a corpse?");
							Corpse::SendLootReqErrorPacket(this);
						}
						break;
					}
					case OP_LootItem:
					{	
						DumpPacket(app);
						if (app->size != sizeof(LootingItem_Struct)) {
							cout << "Wrong size: OP_LootItem, size=" << app->size << ", expected " << sizeof(LootingItem_Struct) << endl;
							break;
						}
						/*
						** Disgrace: 
						**	fixed the looting code so that it sends the correct opcodes

						**	and now correctly removes the looted item the player selected
						**	as well as gives the player the proper item.
						**	Also fixed a few UI lock ups that would occur.
						*/
						cout << "looting item" << endl;

						APPLAYER* outapp = 0;
						Entity* entity = entity_list.GetID(*((int16*)app->pBuffer));
						if (entity == 0) {
							DumpPacket(app);
							Message(13, "Error: OP_LootItem: Corpse not found (ent = 0)");
							outapp = new APPLAYER(OP_LootComplete, 0);
							QueuePacket(outapp);
							delete outapp;
							break;
						}

						if (entity->IsCorpse()) {
							entity->CastToCorpse()->LootItem(this, app);
							break;
						}
						else {
							Message(13, "Error: Corpse not found! (!ent->IsCorpse())");
							Corpse::SendEndLootErrorPacket(this);
						}

						break;
					}							
					case OP_GuildMOTD:
					{
//						app->pBuffer[0] = name of me
//						app->pBuffer[36] = new motd
						char tmp[255];
						if (guilddbid == 0) {
// client calls for a motd on login even if they arent in a guild
//							Message(0, "Error: You arent in a guild!");
						}
						else if (guilds[guildeqid].rank[guildrank].motd && !(strlen((char*) &app->pBuffer[36]) == 0)) {
							if (strcasecmp((char*) &app->pBuffer[36+strlen((char*) &app->pBuffer[0])], " - none") == 0)
								strcpy(tmp, "");
							else
								strncpy(tmp, (char*) &app->pBuffer[36], sizeof(tmp)); // client includes the "name - "

							if (!database.SetGuildMOTD(guilddbid, tmp)) {
								Message(0, "Motd update failed.");
							}
							worldserver.SendEmoteMessage(0, guilddbid, MT_Guild, "Guild MOTD: %s", tmp);
						}
						else {
							database.GetGuildMOTD(guilddbid, tmp);
							if (strlen(tmp) != 0)
								Message(14, "Guild MOTD: %s", tmp);
						}

						break;
					}
					case OP_GuildPeace:
					case OP_GuildWar:
					{
						Message(0, "Guildwars arent implemented. Stupid idea anyways. =P");
						break;
					}
					case OP_GuildLeader: {
						if (app->size <= 1)
							break;
						app->pBuffer[app->size-1] = 0;
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!(guilds[guildeqid].leader == account_id))
							Message(0, "Error: You arent the guild leader!");
						else if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildLeader;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, (char*) app->pBuffer);
							worldserver.SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildInvite:
					{
						if (app->size != sizeof(GuildCommand_Struct)) {
							cout << "Wrong size: OP_GuildInvite, size=" << app->size << ", expected " << sizeof(GuildCommand_Struct) << endl;
							break;
						}
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!guilds[guildeqid].rank[guildrank].invite)
							Message(0, "You dont have permission to invite.");
						else if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else {
							GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildInvite;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, gc->othername);
							worldserver.SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildRemove:
					{
						if (app->size != sizeof(GuildCommand_Struct)) {
							cout << "Wrong size: OP_GuildRemove, size=" << app->size << ", expected " << sizeof(GuildCommand_Struct) << endl;
							break;
						}
						GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
						if (guilddbid == 0)
							Message(0, "Error: You arent in a guild!");
						else if (!(guilds[guildeqid].rank[guildrank].remove || strcasecmp(gc->othername, this->GetName()) == 0))
							Message(0, "You dont have permission to remove.");
						else if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GuildRemove;
							pack->size = sizeof(ServerGuildCommand_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGuildCommand_Struct* sgc = (ServerGuildCommand_Struct*) pack->pBuffer;
							sgc->guilddbid = guilddbid;
							sgc->guildeqid = guildeqid;
							sgc->fromrank = guildrank;
							sgc->fromaccountid = account_id;
							sgc->admin = admin;
							strcpy(sgc->from, name);
							strcpy(sgc->target, gc->othername);
							worldserver.SendPacket(pack);
							delete pack;
						}
						break;
					}
					case OP_GuildInviteAccept:
					{
						if (app->size != sizeof(GuildCommand_Struct)) {
							cout << "Wrong size: OP_GuildInviteAccept, size=" << app->size << ", expected " << sizeof(GuildCommand_Struct) << endl;
							break;
						}
						GuildCommand_Struct* gc = (GuildCommand_Struct*) app->pBuffer;
						if (gc->guildeqid == 0) {
							int32 tmpeq = database.GetGuildEQID(this->PendingGuildInvite);
							if (guilddbid != 0)
								Message(0, "Error: You're already in a guild!");
							else if (!worldserver.Connected())
								Message(0, "Error: World server disconnected");
							else if (this->PendingGuildInvite == 0)
								Message(0, "Error: No guild invite pending.");
							else {
								this->PendingGuildInvite = 0;
								if (this->SetGuild(guilds[tmpeq].databaseID, GUILD_MAX_RANK))
									worldserver.SendEmoteMessage(0, guilds[tmpeq].databaseID, MT_Guild, "%s has joined the guild. Rank: %s.", this->GetName(), guilds[tmpeq].rank[GUILD_MAX_RANK].rankname);
								else {
									worldserver.SendEmoteMessage(gc->othername, 0, 0, "Guild invite accepted, but failed.");
									Message(0, "Guild invite accepted, but failed.");
								}
							}
						}
						else if (gc->guildeqid == 4) {
							this->PendingGuildInvite = 0;
							worldserver.SendEmoteMessage(gc->othername, 0, 0, "%s's guild invite window timed out.", this->GetName());
						}
						else if (gc->guildeqid == 5) {
							this->PendingGuildInvite = 0;
							worldserver.SendEmoteMessage(gc->othername, 0, 0, "%s has declined to join the guild.", this->GetName());
						}
						else {
							this->PendingGuildInvite = 0;
							worldserver.SendEmoteMessage(gc->othername, 0, 0, "Unknown response from %s to guild invite.", this->GetName());
						}
						break;
					}
					case OP_MemorizeSpell: 
					{
						MemorizeSpell_Struct memspell; 
						MoveItem_Struct spellmoveitem; 

						memcpy(&memspell, app->pBuffer, sizeof(MemorizeSpell_Struct)); 

						QueuePacket(app); 
						DumpPacketHex(app); 
						printf("Spell Scribe/Mem: %i(spellID) %i(slot) %i(scribing)\n",memspell.spell_id,memspell.slot,memspell.scribing);
						if (memspell.scribing == 0) 
						{ 
							pp.spell_book[memspell.slot] = memspell.spell_id; 
							APPLAYER* outapp = new APPLAYER; 
							outapp->opcode = OP_MoveItem; 
							outapp->size = sizeof(MoveItem_Struct); 
							outapp->pBuffer = new uchar[outapp->size]; 
							spellmoveitem.from_slot = 0; 
							spellmoveitem.to_slot = 0xffffffff; 
							spellmoveitem.number_in_stack = 0; 
							memcpy(outapp->pBuffer, &spellmoveitem, sizeof(MoveItem_Struct)); 
							QueuePacket(outapp); 
							delete outapp;
							pp.inventory[0] = 0xFFFF;
						} 
						else if (memspell.scribing == 1) 
						{ 
						APPLAYER *outapp;
						outapp = new APPLAYER(OP_MemorizeSpell, sizeof(MemorizeSpell_Struct));
						MemorizeSpell_Struct* mem = (MemorizeSpell_Struct*)outapp->pBuffer;
						mem->spell_id = memspell.spell_id;
						mem->slot = memspell.slot;
						mem->scribing = memspell.scribing;
						QueuePacket(outapp);
						delete outapp;
							pp.spell_memory[memspell.slot] = memspell.spell_id; 
						} 
						else if (memspell.scribing == 2) 
						{ 
							pp.spell_memory[memspell.slot] = 0xffff; 
						} 

						break; 
					}
					case OP_SwapSpell: 
					{
						if (app->size != sizeof(SwapSpell_Struct)) {
							cout << "Wrong size on OP_SwapSpell. Got: " << app->size << ", Expected: " << sizeof(SwapSpell_Struct) << endl;
							break;
						}
						SwapSpell_Struct swapspell; 
						short swapspelltemp; 

						memcpy(&swapspell, app->pBuffer, sizeof(SwapSpell_Struct)); 

						swapspelltemp = pp.spell_book[swapspell.from_slot]; 
						pp.spell_book[swapspell.from_slot] = pp.spell_book[swapspell.to_slot]; 
						pp.spell_book[swapspell.to_slot] = swapspelltemp; 

						QueuePacket(app); 

						break; 
					}
					case OP_CastSpell:
					{
						if (app->size != sizeof(CastSpell_Struct)) {
							cout << "Wrong size: OP_CastSpell, size=" << app->size << ", expected " << sizeof(CastSpell_Struct) << endl;
							break;
						}
						CastSpell_Struct* castspell = (CastSpell_Struct*)app->pBuffer;
//DumpPacketHex(app);
						cout << this->GetName() << " casting #" << castspell->spell_id << ", slot=" << castspell->slot << ", invslot=" << castspell->inventoryslot << endl;
						if (castspell->slot == 10) { // this means right-click
							if (castspell->inventoryslot < 30) { // santity check
								const Item_Struct* item = database.GetItem(pp.inventory[castspell->inventoryslot]);
								if (item == 0) {
									Message(0, "Error: item==0 for inventory slot #%i", castspell->inventoryslot);
								}
								else if (item->common.effecttype == 1 || item->common.effecttype == 3 || item->common.effecttype == 4 || item->common.effecttype == 5) {
									this->DecreaseCharges(castspell->inventoryslot);
									if (item->common.casttime == 0)
										SpellFinished(item->common.spellId, castspell->target_id, castspell->slot, 0);

									else
										CastSpell(item->common.spellId, castspell->target_id, castspell->slot, item->common.casttime);
								}
								else {
									Message(0, "Error: unknown item->common.effecttype (0x%02x)", item->common.effecttype);
								}
							}
							else
								Message(0, "Error: castspell->inventoryslot >= 30 (0x%04x)", castspell->inventoryslot);
						}
						else {
							CastSpell(castspell->spell_id, castspell->target_id, castspell->slot);
						}
						break;
					}
					//heko: replaced the MonkAtk, renamed Monk_Attack_Struct
					case OP_CombatAbility:
					{
						if (app->size != sizeof(CombatAbility_Struct)) {
							cout << "Wrong size on OP_CombatAbility. Got: " << app->size << ", Expected: " << sizeof(CombatAbility_Struct) << endl;
							break;
						}
						CombatAbility_Struct* ca_atk = (CombatAbility_Struct*) app->pBuffer;
						if (target != 0)
						{
							switch(GetClass())
							{
								case WARRIOR:
								case RANGER:
								case PALADIN:
								case SHADOWKNIGHT:
									if (target!=this) {
										if (target->IsNPC()){
											sint32 dmg=(sint32) ((level/10)  * 3  * (GetSkill(KICK) + GetSTR() + level) / (700-GetSkill(KICK)));
												cout << "Dmg:"<<dmg;
											target->CastToNPC()->Damage(this, dmg, 0xffff, 0x1e);
											DoAnim(1);
										}
									}			
									break;

								case MONK:
									MonkSpecialAttack(target->CastToMob(), ca_atk->m_type);
									break;
								case ROGUE:
									if (ca_atk->m_atk == 100)
									{
										if (BehindMob(target, GetX(), GetY())) // Player is behind target
										{
											RogueBackstab(target, weapon1, GetSkill(BACKSTAB));
											if ((level > 54) && (target != 0))
											{
												float DoubleAttackProbability = (GetSkill(DOUBLE_ATTACK) + GetLevel()) / 500.0f; // 62.4 max
				
												// Check for double attack with main hand assuming maxed DA Skill (MS)
												float random = (float)rand()/RAND_MAX;
												if(random < DoubleAttackProbability)		// Max 62.4 % chance of DA
													if(target && target->GetHP() > 0)
														RogueBackstab(target, weapon1, GetSkill(BACKSTAB));	
											}
										}
										else	// Player is in front of target
										{
											Attack(target, 13);
											if ((level > 54) && (target != 0))
											{
												float DoubleAttackProbability = (GetSkill(DOUBLE_ATTACK) + GetLevel()) / 500.0f; // 62.4 max
				
												// Check for double attack with main hand assuming maxed DA Skill (MS)
												float random = (float)rand()/RAND_MAX;
												if(random < DoubleAttackProbability)		// Max 62.4 % chance of DA
													if(target && target->GetHP() > 0)
														Attack(target, 13);													
											}

										}

									}
									break;
							}

						}
						break;
					}
					//heko: 
					//Packet length 4
					//0000: 00 00		NPC ID
					case OP_Taunt:
					{
						if (this->GetTarget() == 0)
							break;
						if (!this->GetTarget()->IsNPC())
							break;
						sint32 newhate, tauntvalue;
						if (app->size != sizeof(ClientTarget_Struct)) {
							cout << "Wrong size on OP_Taunt. Got: " << app->size << ", Expected: "<< sizeof(ClientTarget_Struct) << endl;
							break;
						}
						ClientTarget_Struct* taunt_npc_id = (ClientTarget_Struct*) app->pBuffer;
						//cout << "Taunting NPC number: " << taunt_npc_id << endl;

						// Check to see if we're already at the top of the target's hate list
						if ((target->CastToNPC()->GetHateTop() != this) && (target->GetLevel() < level))
						{
							// no idea how taunt success is actually calculated
							// TODO: chance for level 50+ mobs should be lower
							float tauntchance;
							int level_difference = level - target->GetLevel();
							if (level_difference <= 5)
							{
								tauntchance = 25.0;	// minimum
								tauntchance += tauntchance * (float)GetSkill(TAUNT) / 200.0;	// skill modifier
								if (tauntchance > 65.0)
										tauntchance = 65.0;
								}
								else if (level_difference <= 10)
								{
									tauntchance = 30.0;	// minimum
									tauntchance += tauntchance * (float)GetSkill(TAUNT) / 200.0;	// skill modifier
									if (tauntchance > 85.0)
										tauntchance = 85.0;

								}
								else if (level_difference <= 15)
								{
									tauntchance = 40.0;	// minimum
									tauntchance += tauntchance * (float)GetSkill(TAUNT) / 200.0;	// skill modifier
									if (tauntchance > 90.0)
										tauntchance = 90.0;
								}
								else
								{
									tauntchance = 50.0;	// minimum
									tauntchance += tauntchance * (float)GetSkill(TAUNT) / 200.0;	// skill modifier
									if (tauntchance > 95.0)
										tauntchance = 95.0;
								}
								if (tauntchance > ((float)rand()/(float)RAND_MAX)*100.0)
								{
									// this is the max additional hate added per succesfull taunt
									tauntvalue = (sint32) ((float)level * 10.0 * (float)rand()/(float)RAND_MAX + 1);
									// new hate: find diff of player's hate and whoever's at top of list, add that plus tauntvalue to players hate
									newhate = target->CastToNPC()->GetNPCHate(target->CastToNPC()->GetHateTop()) - target->CastToNPC()->GetNPCHate(this) + tauntvalue;
									// add the hate
									target->CastToNPC()->AddToHateList(this, 0, newhate);
								}							
						}
						break;
					}

					case OP_InstillDoubt:
					{
//						Fear Spell not yet implemented
						Instill_Doubt_Struct* iatk = (Instill_Doubt_Struct*) app->pBuffer;
						if (iatk->i_atk == 0x2E) {
							Message(4, "You\'re not scaring anyone.");
						}
						break;
					}
					case OP_RezzAnswer:
					{
						if (!pendingrezzexp)
							break;
						Resurrect_Struct* ra = (Resurrect_Struct*) app->pBuffer;
						if (ra->action == 1){
							cout << "Player " << this->name << " got a " << (int16)spells[ra->spellid].base[0] << "% Rezz" << endl;
							this->BuffFade(0xFFFe);
							SetMana(0);
							SetHP(GetMaxHP()/5);
							app->opcode = OP_RezzComplete;
							worldserver.RezzPlayer(app,0,OP_RezzComplete);
							cout << "pe: " << pendingrezzexp << endl;
							SetEXP(GetEXP()+(float)pendingrezzexp/100*spells[ra->spellid].base[0],GetAAXP(),true);
							pendingrezzexp = 0;
							if (strcmp(ra->zone,zone->GetShortName()) != 0){
								SetZoneSummonCoords(ra->x,ra->y,ra->z*10);
							}
							this->QueuePacket(app);
						}
						break;
					}
					case OP_GMSummon: {
						if (app->size != sizeof(GMSummon_Struct)) {
							cout << "Wrong size on OP_GMSummon. Got: " << app->size << ", Expected: " << sizeof(GMSummon_Struct) << endl;
							break;
						}
						if(admin<100) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						DumpPacket(app);
						GMSummon_Struct* gms = (GMSummon_Struct*) app->pBuffer;
						Mob* st = entity_list.GetMob(gms->charname);
						if (admin >= 100) {
							int8 tmp = gms->charname[strlen(gms->charname)-1];
							if (st != 0) {

								this->Message(0, "Local: Summoning %s to %i, %i, %i", gms->charname, gms->x, gms->y, gms->z);
								if (st->IsClient() && (st->CastToClient()->GetAnon() != 1 || this->Admin() >= st->CastToClient()->Admin()))
									st->CastToClient()->MovePC((char*) 0, gms->x, gms->y, gms->z, true, true);
								else
									st->GMMove(gms->x, gms->y, gms->z);
							}
							else if (!worldserver.Connected())
								Message(0, "Error: World server disconnected");
							else if (tmp < '0' || tmp > '9') { // dont send to world if it's not a player's name
								ServerPacket* pack = new ServerPacket;
								pack->opcode = ServerOP_ZonePlayer;
								pack->size = sizeof(ServerZonePlayer_Struct);
								pack->pBuffer = new uchar[pack->size];
								memset(pack->pBuffer, 0, pack->size);
								ServerZonePlayer_Struct* szp = (ServerZonePlayer_Struct*) pack->pBuffer;
								strcpy(szp->adminname, this->GetName());
								szp->adminrank = this->Admin();
								strcpy(szp->name, gms->charname);
								strcpy(szp->zone, zone->GetShortName());
								szp->x_pos = gms->x;
								szp->y_pos = gms->y;
								szp->z_pos = gms->z;
								szp->ignorerestrictions = true;
								worldserver.SendPacket(pack);
								delete pack;
							}
							else {
								Message(13, "Error: '%s' not found.", gms->charname);


							}
						}
						else if (st->IsCorpse()) {
							st->CastToCorpse()->Summon(this, true);
						}
						break;
					}
					case OP_TradeRequest:
					{
						Trade_Window_Struct* msg = (Trade_Window_Struct*) app->pBuffer; 
						Mob* tmp = entity_list.GetMob(msg->fromid);
						for(int x=0; x != 80; x++){
							TradeList[x]=0;
							TradeCharges[x]=0;
						}
						if (tmp != 0) {
							if (tmp->IsClient()) {
								tmp->CastToClient()->QueuePacket(app);
							}
							else
							{	//npcs always accept
								APPLAYER* outapp = new APPLAYER(OP_TradeAccepted,4);
								Trade_Window_Struct* acc = (Trade_Window_Struct*) outapp->pBuffer;
								acc->fromid = msg->toid;
								acc->toid	= msg->fromid;
								QueuePacket(outapp);
								InTrade = 1;
								this->TradeWithEnt = msg->fromid;
							}
						}
						break;

					}
					case OP_TradeAccepted:
					{

						Trade_Window_Struct* msg = (Trade_Window_Struct*) app->pBuffer; 
						InTrade= 1;
						this->TradeWithEnt = msg->fromid;
						Mob* tmp = entity_list.GetMob(msg->fromid);
						if (tmp != 0) {
							if (tmp->IsClient()) {
								for(int x=0; x != 80; x++){
									TradeList[x]=0;
									TradeCharges[x]=0;
								}	
								tmp->CastToClient()->QueuePacket(app);
								tmp->CastToClient()->TradeWithEnt=GetID();
								tmp->CastToClient()->InTrade=1;
							}
						}
						break;
					}
					case OP_CancelTrade:
						{
							CancelTrade_Struct* msg = (CancelTrade_Struct*) app->pBuffer;
							Mob* tmp = entity_list.GetMob(TradeWithEnt);
							if (tmp != 0) {
								msg->fromid = this->GetID();
								QueuePacket(app);
								this->FinishTrade(this);
								cout << "deal canceld" << endl;
								InTrade = 0;
								TradeWithEnt = 0;
								if (tmp->IsClient()) {	
									tmp->CastToClient()->QueuePacket(app);	
									tmp->CastToClient()->FinishTrade(tmp->CastToClient());									
									tmp->CastToClient()->InTrade = 0;										
									tmp->CastToClient()->TradeWithEnt = 0;									
								}
							}
							
							break;
						}
						
					case OP_Click_Give:
						{
							DumpPacket(app);
							this->InTrade = 2;
							Mob* tmp = entity_list.GetMob(TradeWithEnt);
							if (tmp != 0) {
								if (tmp->IsClient()) {
									
									if (tmp->CastToClient()->InTrade == 2)
									{
										cout << "deal ended" << endl;
										tmp->CastToClient()->QueuePacket(app);
										this->FinishTrade(tmp->CastToClient());
										tmp->CastToClient()->FinishTrade(this);
										APPLAYER* outapp = new APPLAYER(OP_CloseTrade,0);
										tmp->CastToClient()->QueuePacket(outapp);
										QueuePacket(outapp);
										tmp->CastToClient()->InTrade = 0;
										InTrade = 0;
										tmp->CastToClient()->TradeWithEnt = 0;
										TradeWithEnt = 0;
										delete outapp;
										
									}
									else
										tmp->CastToClient()->QueuePacket(app); 				
								}
								else {
									APPLAYER* outapp = new APPLAYER(OP_CloseTrade,0);
									QueuePacket(outapp);
									cout << "npc deal ended" << endl;
									InTrade = 0;
									TradeWithEnt = 0;
									delete outapp;
									if (tmp->IsNPC()) { 
										CheckQuests(zone->GetShortName(), "%%item%%", tmp->CastToNPC()->GetNPCTypeID(), TradeList[0]); 
									} 									
								}
							}
							
						break;
					} 
					case OP_Random: {
						Random_Struct* rndq = (Random_Struct*) app->pBuffer;
						if (rndq->low == rndq->high)
							break; // This stops a Zone Crash.
						unsigned int rndqa = 0;
						if (rndq->low > rndq->high) // They did Big number first.
						{
							rndqa = rndq->low;
							rndq->low = rndq->high;
							rndq->high = rndqa;
						}
						if (rndq->low == 0) 
							rndqa = 2;
						else
							rndqa = rndq->low;
						srand( (Timer::GetCurrentTime() * Timer::GetCurrentTime()) / rndqa);
						rndqa = (rand()  % (rndq->high - rndq->low)) + rndq->low;
						entity_list.Message(0, 8, "%s rolled their dice and got a %d out of %d to %d!", this->GetName(), rndqa, rndq->low, rndq->high);

						break;
					}
					case OP_Buff: {
//						if (app->size != sizeof(SpellBuffFade_Struct)) {
						if (app->size != sizeof(Buff_Struct)) {
							cout << "Wrong size on OP_Buff. Got: " << app->size << ", Expected: " << sizeof(SpellBuffFade_Struct) << endl;
							break;
						}
						SpellBuffFade_Struct* sbf = (SpellBuffFade_Struct*) app->pBuffer;
						BuffFade(sbf->spellid);
						break;
					}
					case OP_GMHideMe: {
//cout << "OP_GMHideMe" << endl;
//DumpPacket(app);
						if(admin<100) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_SpawnAppearance;
						outapp->size = sizeof(SpawnAppearance_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						memset(outapp->pBuffer, 0, outapp->size);
						SpawnAppearance_Struct* sa_out = (SpawnAppearance_Struct*)outapp->pBuffer;
						sa_out->spawn_id = GetID();
						sa_out->type = 0x03;
						if (this->invisible == false) {
							this->invisible = true;
							sa_out->parameter = 1;
						}
						else {
							this->invisible = false;
							sa_out->parameter = 0;
						}
						
						entity_list.QueueClients(this, outapp, true);
						delete outapp;
						break;
					}
					case OP_GMNameChange: {
						if(admin<100) {
							Message(13, "Your not awesome enough to use this command!");
							break;

						}
						GMName_Struct* gmn = (GMName_Struct *)app->pBuffer;
						Client* client = entity_list.GetClientByName(gmn->oldname);
						printf("%s %s\n",gmn->oldname,gmn->newname);
						bool usedname = database.CheckUsedName((char*) gmn->newname);
						if(client==0) {
							Message(13, "%s not found for name change. Operation failed!", gmn->oldname);
							break;
						}
						if((strlen(gmn->newname) > 63) || (strlen(gmn->newname) == 0)) {
							Message(13, "Invalid number of characters in new name (%s).", gmn->newname);
							break;
						}
						if (!usedname) {
							Message(13, "%s is already in use.  Operation failed!", gmn->newname);
							break;
						}
						UpdateWho(true);
						database.UpdateName(gmn->oldname, gmn->newname);
						strcpy(client->name, gmn->newname);
						client->Save();

						if(gmn->badname==1) {
							database.AddToNameFilter(gmn->oldname);
						}
						gmn->unknown[0] = 1;
						gmn->unknown[1] = 1;
						gmn->unknown[2] = 1;
						entity_list.QueueClients(this, app, false);
						UpdateWho(false);
						break;
					}
					case OP_GMKill: {
						if(admin<100) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						GMKill_Struct* gmk = (GMKill_Struct *)app->pBuffer;
						Mob* obj = entity_list.GetMob(gmk->name);
						Client* client = entity_list.GetClientByName(gmk->name);
						if(obj!=0) {
							if(client!=0) {
								entity_list.QueueClients(this,app);
							}
							else {
								obj->Kill();
							}
						}
						else {
							if (!worldserver.Connected())
								Message(0, "Error: World server disconnected");
							else {
								ServerPacket* pack = new ServerPacket;
								pack->opcode = ServerOP_KillPlayer;
								pack->size = sizeof(ServerKillPlayer_Struct);
								pack->pBuffer = new uchar[pack->size];
								ServerKillPlayer_Struct* skp = (ServerKillPlayer_Struct*) pack->pBuffer;
								strcpy(skp->gmname, gmk->gmname);
								strcpy(skp->target, gmk->name);
								skp->admin = this->Admin();
								worldserver.SendPacket(pack);
								delete pack;
							} 
						}
						break;
					}
					case OP_GMLastName: {
//cout << "OP_GMLastName" << endl;
//DumpPacket(app);
						if (app->size != sizeof(GMLastName_Struct)) {
							cout << "Wrong size on OP_GMLastName. Got: " << app->size << ", Expected: " << sizeof(GMLastName_Struct) << endl;
							break;
						}
						GMLastName_Struct* gmln = (GMLastName_Struct*) app->pBuffer;
						if (strlen(gmln->lastname) >= 20) {
							Message(13, "/LastName: New last name too long. (max=19)");
						}
						else {
							Client* client = entity_list.GetClientByName(gmln->name);
							if (client == 0) {
								Message(13, "/LastName: %s not found", gmln->name);
							}
							else {
								client->ChangeLastName(gmln->lastname);
							}
							gmln->unknown[0] = 1;
							gmln->unknown[1] = 1;
							entity_list.QueueClients(this, app, false);
						}
						break;
					}
					case OP_GMToggle: {
						if (app->size != 68) {
							cout << "Wrong size on OP_GMToggle. Got: " << app->size << ", Expected: " << 36 << endl;
							break;
						}
						if (app->pBuffer[64] == 0) {
							Message(0, "Turning tells OFF");
							tellsoff = true;
						}
						else if (app->pBuffer[64] == 1) {
							Message(0, "Turning tells ON");
							tellsoff = false;
						}
						else {
							Message(0, "Unkown value in /toggle packet");
						}
						UpdateWho();
						break;
					}
					case OP_LFG: {
						if (app->size != sizeof(LFG_Struct)) {
							cout << "Wrong size on OP_LFG. Got: " << app->size << ", Expected: " << sizeof(LFG_Struct) << endl;
							break;
						}
						LFG_Struct* lfg = (LFG_Struct*) app->pBuffer;
						if (lfg->value == 1) {
//cout << this->GetName() << " turning LFG on." << endl;
							LFG = true;
						}
						else if (lfg->value == 0) {
//cout << this->GetName() << " turning LFG off." << endl;
							LFG = false;
						}
						else
							Message(0, "Error: unknown LFG value");
						UpdateWho();
						break;
					}
					case OP_GMGoto: {
						if (app->size != sizeof(GMSummon_Struct)) {
							cout << "Wrong size on OP_GMGoto. Got: " << app->size << ", Expected: " << sizeof(GMSummon_Struct) << endl;
							break;
						}
						if (admin < 100) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						GMSummon_Struct* gmg = (GMSummon_Struct*) app->pBuffer;
						Mob* gt = entity_list.GetMob(gmg->charname);
						if (gt != 0) {
							this->MovePC((char*) 0, gt->GetX(), gt->GetY(), gt->GetZ()/10);
						}
						else if (!worldserver.Connected())
							Message(0, "Error: World server disconnected.");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->opcode = ServerOP_GMGoto;
							pack->size = sizeof(ServerGMGoto_Struct);
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							ServerGMGoto_Struct* wsgmg = (ServerGMGoto_Struct*) pack->pBuffer;
							strcpy(wsgmg->myname, this->GetName());
							strcpy(wsgmg->gotoname, gmg->charname);
							wsgmg->admin = admin;
							worldserver.SendPacket(pack);
							delete pack;
						}
						break;
					}
/*
0 is e7 from 01 to
1 is 03
2 is 00
3 is 00
4 is ??
5 is ??
6 is 00 from a0 to
7 is 00 from 3f to */			
						case OP_ShopRequest: {
/* this works*/			Merchant_Click_Struct* mc=(Merchant_Click_Struct*)app->pBuffer;
						if (app->size == sizeof(Merchant_Click_Struct)) {
							// Send back opcode OP_ShopRequest - tells client to open merchant window.
							APPLAYER* outapp = new APPLAYER(OP_ShopRequest, sizeof(Merchant_Click_Struct));
							Merchant_Click_Struct* mco=(Merchant_Click_Struct*)outapp->pBuffer;
							mco->npcid = mc->npcid;
							mco->playerid = mc->playerid;
							mco->unknown[0] = 0x01;
							mco->unknown[1] = 0x03;
							mco->unknown[2] = 0x00;
							mco->unknown[3] = 0x00;
							mco->unknown[6] = 0xa0;
							mco->unknown[7] = 0x3f;
							DumpPacketHex(outapp);
							QueuePacket(outapp);
							delete outapp;
							int merchantid;
							Mob* tmp = entity_list.GetMob(mc->npcid);
							if (tmp != 0)
								merchantid=tmp->CastToNPC()->MerchantType;

							for(int x=0; x < database.GetMerchantListNumb(merchantid) && x < 29; x++)
							{
							uint16 item_nr = database.GetMerchantData(merchantid,x+1);
							const Item_Struct* item = database.GetItem(item_nr);
							cout << "merchant is selling: " << item->name << endl;
							// Send this item to the client.
							outapp = new APPLAYER(OP_ShopItem, sizeof(Item_Shop_Struct));
							Item_Shop_Struct* iss = (Item_Shop_Struct*)outapp->pBuffer;



							iss->merchantid = mc->npcid;
							iss->itemtype = item->type;			// TODO: needs to be parsed from item.
							memcpy(&iss->item, item, sizeof(Item_Struct));
							iss->item.equipSlot = x;			// this needs to be incremented in loop.
							iss->item.common.charges = 1;
							iss->iss_unknown001[0] = 0;
							QueuePacket(outapp);
							delete outapp;
							}	
						} 
						break;
					}
					case OP_ShopPlayerBuy: { // Edited Merkur  03/12								
						cout << name << " is attempting to purchase an item..  " << endl;
						Merchant_Purchase_Struct* mp=(Merchant_Purchase_Struct*)app->pBuffer;
						int merchantid;
						Mob* tmp = entity_list.GetMob(mp->npcid);
						if (tmp != 0)
							merchantid=tmp->CastToNPC()->MerchantType;
						else 
							break;
						uint16 item_nr = database.GetMerchantData(merchantid, mp->itemslot+1);
						if (item_nr == 0)
							break;
						const Item_Struct* item = database.GetItem(item_nr);				
						APPLAYER* outapp = new APPLAYER(OP_ShopPlayerBuy, sizeof(Merchant_Purchase_Struct));
						Merchant_Purchase_Struct* mpo=(Merchant_Purchase_Struct*)outapp->pBuffer;							
						mpo->quantity = mp->quantity;
						mpo->playerid = mp->playerid;
						mpo->npcid = mp->npcid;
						mpo->itemslot = mp->itemslot;													
						mpo->IsSold = 0x00;
						mpo->unknown001 = 0x00;
						mpo->unknown002 = 0x00;
						mpo->unknown003 = 0x00;
						mpo->unknown004 = 0x00; 
						mpo->unknown005 = 0x00;
						// need to find the formula to calculate sell prices -Merkur
						mpo->itemcost = item->cost*mp->quantity*1.2;
						cout << "taking " << item->cost*mp->quantity*1.2 << " copper from " << name << "." << endl;
						TakeMoneyFromPP(item->cost*mp->quantity*1.2);
						//	DumpPacketHex(app);
						QueuePacket(outapp);
						delete outapp;						
						PutItemInInventory(FindFreeInventorySlot(0, (item->type==0x01), false), item, mp->quantity);
						Save();
						break;
					}
					case OP_ShopPlayerSell: {
						cout << name << " is trying to sell an item." << endl;
						Merchant_Purchase_Struct* mp=(Merchant_Purchase_Struct*)app->pBuffer;																				
						//cout << mp->itemslot << endl;
						if ((mp->itemslot > 29 || mp->itemslot < 22) && mp->itemslot != 0){
							this->Message(0,"Sorry, selling item in bags is bugged atm, please use your main inventory to sell");
							mp->itemslot = 0;
							mp->quantity = 0;
							mp->IsSold = 1;
							QueuePacket(app);
							break;
						}
						pp.invitemproperties[mp->itemslot].charges = (mp->quantity == 0) ? 0: pp.invitemproperties[mp->itemslot].charges - mp->quantity;
						cout << "left: " <<(int16) pp.invitemproperties[mp->itemslot].charges<< endl;
						cout << "slot: " <<(int16) mp->itemslot << endl;
						
						AddMoneyToPP(database.GetItem(pp.inventory[mp->itemslot])->cost*((mp->quantity == 0) ? 1:mp->quantity) *0.8);
						QueuePacket(app);
						
						if (pp.invitemproperties[mp->itemslot].charges == 0){
							this->DeleteItemInInventory(mp->itemslot,false);
						}

						 // Just send it back to accept the deal
						//DumpPacket(app);
						Save();
						cout << "response from sell action.." << endl;
						break;
					}
					case OP_ShopEnd: {
						cout << name << " is ending merchant interaction." << endl;

						APPLAYER* outapp = new APPLAYER;
						outapp->opcode = OP_ShopEndConfirm;
						outapp->pBuffer = new uchar[2];
						outapp->size = 2;
						outapp->pBuffer[0] = 0x0a;
						outapp->pBuffer[1] = 0x66;
						QueuePacket(outapp);
						delete outapp;
						Save();
						break; 
					}
					case OP_ClickObject: {
						ClickObject_Struct* co = (ClickObject_Struct*)app->pBuffer;
						entity_list.GetID(co->objectID)->CastToObject()->HandleClick(this,app);
						break; 
					}
					case OP_ClickDoor: {
						ClickDoor_Struct* cd = (ClickDoor_Struct*)app->pBuffer;
						if (IsSettingGuildDoor){
							if (database.SetGuildDoor(cd->doorid,SetGuildDoorID,zone->GetShortName())){
								cout << SetGuildDoorID << endl;
								if (SetGuildDoorID)
									Message(0,"This is now a guilddoor of '%s'",guilds[SetGuildDoorID].name);
								else
									Message(0,"Guildoor deleted");
								Message(0,"This change will work after zoning");
							}
							else
								Message(0,"Failed to edit guilddoor!");
							IsSettingGuildDoor = false;
							break;
						}
									
						if (cd->doorid >= 128){
							if(!database.CheckGuildDoor(cd->doorid,GuildEQID(),zone->GetShortName())){
								// heh hope grammer on this is right lol
								this->Message(0,"A magic barrier protects this hall against intruders!");
								break;	
							}
							else
								this->Message(0,"The magic barrier disappears and you open the door!");

						}
						
						APPLAYER* outapp = new APPLAYER(OP_MoveDoor, sizeof(MoveDoor_Struct));
						MoveDoor_Struct* md=(MoveDoor_Struct*)outapp->pBuffer;										
						//DumpPacket(app);
						md->doorid = cd->doorid;
						md->action = 0x02;
						entity_list.QueueClients(this,outapp,false);
						//DumpPacket(outapp);
						delete outapp;
						break; 
					}
					case OP_CreateObject: {
						//DumpPacket(app);
						Object_Struct* co = (Object_Struct*)app->pBuffer;
						Object* no = new Object(OT_DROPPEDITEM,co->itemid,co->ypos,co->xpos,co->zpos,co->heading,co->objectname,pp.invitemproperties[0].charges);
						for (int i = 0;i != 10;i++) {
							if (co->itemsinbag[i] != 0xFFFF){
								no->SetBagItems(i,co->itemsinbag[i],pp.cursorbagitemproperties[i].charges);
							}
						}
						entity_list.AddObject(no,true);
						for (int j=0;j != 10;j++){
							pp.cursorbaginventory[j] = 0xFFFF;
							pp.cursorbagitemproperties[j].charges = 0;
						}
						pp.inventory[0] = 0xFFFF;
						break; 
										  }
					case 0x2522: { // When client changes their face & stuff
						/*cout << "OP: 0x2522" << endl;
						DumpPacket(app);*/
						entity_list.QueueClients(this, app, false);
						ChangeLooks_Struct* cl = (ChangeLooks_Struct*)app->pBuffer;
						pp.haircolor=cl->haircolor;
						pp.beardcolor=cl->beardcolor;
						pp.eyecolor1=cl->eyecolor1;
						pp.eyecolor2=cl->eyecolor2;
						pp.hairstyle=cl->hairstyle;
						pp.title=cl->title;
						pp.luclinface=cl->face;
						Save();
						Message(13, "Facial features updated.");
						break;
					}
					case OP_GroupInvite: {
						this->GetTarget()->CastToClient()->QueuePacket(app);
						break;
					}
					case OP_CancelInvite: {
						GroupGeneric_Struct* gf = (GroupGeneric_Struct*) app->pBuffer;
						Client* inviter = entity_list.GetClientByName(gf->name1);
						inviter->QueuePacket(app);
						break;
					}
					case OP_GroupFollow: {
						GroupGeneric_Struct* gf = (GroupGeneric_Struct*) app->pBuffer;
						Client* inviter = entity_list.GetClientByName(gf->name1);
						inviter->QueuePacket(app);
						if (!inviter->isgrouped){
							Group* ng = new Group(inviter);
							entity_list.AddGroup(ng);
							cout << "New group created" << endl;
						}
						entity_list.GetGroupByClient(inviter)->AddMember(this);
						break;
						
					}
					case OP_GroupDisband: {
						cout << "Member Disband Request" << endl;
						GroupGeneric_Struct* gd = (GroupGeneric_Struct*) app->pBuffer;
						if (this->isgrouped && entity_list.GetGroupByClient(this) != 0)	
							entity_list.GetGroupByClient(this)->DelMember(entity_list.GetClientByName(gd->name2));
						break;
					}
					case OP_GroupDelete: {
						cout << "Group Delete Request" << endl;
						if (this->isgrouped && entity_list.GetGroupByClient(this) != 0)						
							entity_list.GetGroupByClient(this)->DisbandGroup();
						break;
					}
					case OP_GMEmoteZone: {
						if(admin<80) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						GMEmoteZone_Struct* gmez = (GMEmoteZone_Struct*)app->pBuffer;
						entity_list.Message(0, 0, gmez->text);
						break;
					}
					case OP_InspectRequest: { // 03/09 - Merkur 
						Inspect_Struct* ins = (Inspect_Struct*) app->pBuffer; 
						Mob* tmp = entity_list.GetMob(ins->TargetID); 
						tmp->CastToClient()->QueuePacket(app); // Send request to target 
						break; 
					}  
					case OP_InspectAnswer: { 
						Inspect_Struct* ins = (Inspect_Struct*) app->pBuffer; 
						Mob* tmp = entity_list.GetMob(ins->TargetID); 
						tmp->CastToClient()->QueuePacket(app); // Send answer to requester 
						break; 
					}
					case OP_Medding: { 
						if (app->pBuffer[0])
							medding = true;
						else
							medding = false;
						break; 
					} 
					case OP_Petition: {
						if (app->size <= 1)
							break;
						app->pBuffer[app->size - 1] = 0;
						if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else
						{
							Petition* pet = new Petition;
							pet->SetAName(this->AccountName());
							pet->SetClass(this->GetClass());
							pet->SetLevel(this->GetLevel());
							pet->SetCName(this->GetName());
							pet->SetRace(this->GetRace());
							pet->SetLastGM("");
							pet->SetCName(this->GetName());
							pet->SetPetitionText((char*) app->pBuffer);
							pet->SetZone(zone->GetZoneID());
							pet->SetUrgency(0);
							petition_list.AddPetition(pet);
							database.InsertPetitionToDB(pet);
							petition_list.UpdateGMQueue();
							petition_list.UpdateZoneListQueue();
						}
						break;
					}
					case OP_PetitionCheckIn: {
						Petition_Struct* inpet = (Petition_Struct*) app->pBuffer;
						Petition* pet = petition_list.GetPetitionByID(inpet->petnumber);
						if (inpet->urgency != pet->GetUrgency())
							pet->SetUrgency(inpet->urgency);
						pet->SetLastGM(this->GetName());
						pet->SetCheckedOut(false);
						petition_list.UpdatePetition(pet);
						petition_list.UpdateGMQueue();
						petition_list.UpdateZoneListQueue();
						break;
					}
					case OP_PetitionDelete: {
						APPLAYER* outapp = new APPLAYER(0x0f20,sizeof(PetitionClientUpdate_Struct));
						PetitionClientUpdate_Struct* pet = (PetitionClientUpdate_Struct*) outapp->pBuffer;
						pet->petnumber = *((int*) app->pBuffer);
						pet->color = 0x00;
						pet->status = 0xFFFFFFFF;
						/*pet->unknown[3] = 0x00;
						pet->unknown[2] = 0x00;
						pet->unknown[1] = 0x00;
						pet->unknown[0] = 0x00;*/
						pet->senttime = 0;
						strcpy(pet->accountid, "");
						strcpy(pet->gmsenttoo, "");
						pet->quetotal = petition_list.GetMaxPetitionID();
						strcpy(pet->charname, "");
						QueuePacket(outapp);
						
						if (petition_list.DeletePetition(pet->petnumber) == -1) cout << "Something is borked with: " << pet->petnumber << endl;
						petition_list.ClearPetitions();
						petition_list.UpdateGMQueue();
						petition_list.ReadDatabase();
						petition_list.UpdateZoneListQueue();
						delete outapp;
						break;
					}
					case OP_PetitionCheckout: {
						if (app->size != sizeof(int32)) {
							cout << "Wrong size: OP_PetitionCheckout, size=" << app->size << ", expected " << sizeof(int32) << endl;
							break;
						}
						if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else {
							int32 getpetnum = *((int32*) app->pBuffer);
							Petition* getpet = petition_list.GetPetitionByID(getpetnum);
							if (getpet != 0) {
								getpet->AddCheckout();
								getpet->SetCheckedOut(true);
								getpet->SendPetitionToPlayer(this->CastToClient());
								petition_list.UpdatePetition(getpet);
								petition_list.UpdateGMQueue();
								petition_list.UpdateZoneListQueue();
							}
							else Message(0, "Automated System Message: Your client is bugged.  Please camp to the login server to fix!");
						}
						break;
					}
					case OP_PetitionRefresh: {
						// This is When Client Asks for Petition Again and Again...
						// break is here because it floods the zones and causes lag if it
						// Were to actually do something:P  We update on our own schedule now.
						break;
					}
					case OP_TradeSkillCombine: {
						cout << " TradeskillCombine Request" << endl;
						Combine_Struct* combin = (Combine_Struct*) app->pBuffer;
						int16 skillneeded = 0;
						int16 product = 0;
						int16 tradeskill = 0;
						float chance = 0;
						// statbonus 20%/10% with 200 + 0.05% / 0.025% per point above 200
						float wisebonus =  (pp.WIS > 200) ? 20 + ((pp.WIS - 200) * 0.05) : pp.WIS * 0.1;
						float intbonus =  (pp.INT > 200) ? 10 + ((pp.INT - 200) * 0.025) : pp.INT * 0.05;
						
						switch(combin->tradeskill)
						{
						case 0x10:	//Tailoring
							tradeskill = 61;
							break;
						case 0x12:	//Fletching
							tradeskill = 64;
							break;
						case 0x14:	//Jewelry Making
							tradeskill = 68;
							break;
						case 0x0F: // baking
							tradeskill = 60;
							break;

						default:
							this->Message(4,"This tradeskill will be implemented soon - really");
						}
						if (tradeskill == 0)
							break;
						


						if (database.GetTradeRecipe(combin,tradeskill,&product,&skillneeded))
						{
							if ((int)pp.skills[tradeskill] - skillneeded > 0)
							{
								chance = 80+wisebonus-10; // 80% basechance + max 20% stats
								this->Message(4,"This item is trivial to make at your level");
							}
							else
							{
								if (skillneeded - (int)pp.skills[tradeskill] < 20)
									 // 40 base chance success + max 40% skill + 20% max stats
									chance = 40+ wisebonus + 40-((skillneeded - (int)pp.skills[tradeskill])*2);
									else
										 // 0 base chance success + max 30% skill + 10% max stats
										chance = 0 + (wisebonus/2) + 30 - (((skillneeded - (int)pp.skills[tradeskill]) * (skillneeded - (int)pp.skills[tradeskill]))*0.01875);
								//skillincrease
								if ((55-(pp.skills[tradeskill]*0.236))+intbonus > (float)rand()/RAND_MAX*100)
									this->SetSkill(tradeskill,++pp.skills[tradeskill]);
							}
							if ((pp.gm==1) || (chance > ((float)rand()/RAND_MAX*100))){
								this->Message(4,"You have fashioned the items together to create something new!");
								PutItemInInventory(0,product,1);
								for (int k=0; k<10; k++) 
									if (pp.containerinv[(((int16)combin->containerslot-22)*10) + k] != 0xFFFF) 
										DeleteItemInInventory(((combin->containerslot-22)*10) + k + 250);			
							}
							else
							{
								this->Message(4,"You lacked the skills to fashion the items together.");
								for (int k=0; k<10; k++) 
									if (pp.containerinv[(((int16)combin->containerslot-22)*10) + k] != 0xFFFF) 
										DeleteItemInInventory(((combin->containerslot-22)*10) + k + 250);							
							}
							
						}
						else
						{
							this->Message(4,"You cannot combine these items in this container type!");
						}
						cout << "Chance: " << chance << endl;
						QueuePacket(app);
						break;
					}
					case OP_ReadBook: {
						BookRequest_Struct* book = (BookRequest_Struct*) app->pBuffer;
						ReadBook(book->txtfile);
						break;
					}
					case OP_Social_Text: {
		                cout << "Social Text: " << app->size << endl;		//DumpPacket(app);
						APPLAYER *outapp = new APPLAYER;
						outapp->opcode = app->opcode;
						outapp->size = sizeof(Emote_Text);
						outapp->pBuffer = new uchar[outapp->size];
						outapp->pBuffer[0] = app->pBuffer[0];
						outapp->pBuffer[1] = app->pBuffer[1];
						uchar *cptr = outapp->pBuffer + 2;
						cptr += sprintf((char *)cptr, "%s", GetName());
						cptr += sprintf((char *)cptr, "%s", app->pBuffer + 2);
						cout << "Check target" << endl;
						if(target != NULL && target->IsClient())
						{
							cout << "Client targeted" << endl;
							entity_list.QueueCloseClients(this, outapp, true, 100, target);
							//cptr += sprintf((char *)cptr, " Special message for you, the target");
							cptr = outapp->pBuffer + 2;
		
                            // not sure if live does this or not.  thought it was a nice feature, but would take a lot to clean up grammatical and other errors.  Maybe with a regex parser...
/*
		replacestr((char *)cptr, target->GetName(), "you");
		replacestr((char *)cptr, " he", " you");
		replacestr((char *)cptr, " she", " you");
		replacestr((char *)cptr, " him", " you");
		replacestr((char *)cptr, " her", " you");
*/
							entity_list.GetMob(target->GetName())->CastToClient()->QueuePacket(outapp);
						}
						else
		                	entity_list.QueueCloseClients(this, outapp, true, 100);
						delete outapp;
						break;
					}
					case OP_Social_Action: {
						cout << "Social Action:  " << app->size << endl;
						//DumpPacket(app);
						entity_list.QueueCloseClients(this, app, true);
						break;
					}
					case OP_SetServerFilter: {
					/*	APPLAYER* outapp = new APPLAYER;
 						outapp = new APPLAYER;
 						outapp->opcode = OP_SetServerFilterAck;
						outapp->size = sizeof(SetServerFilterAck_Struct);
						outapp->pBuffer = new uchar[outapp->size];
						memset(outapp->pBuffer, 0, outapp->size);
						QueuePacket(outapp);
						delete outapp;*/
						break;
					}
					//Broke
					case OP_GMDelCorpse: {
						if(admin<100) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}		
						GMDelCorpse_Struct* dc = (GMDelCorpse_Struct *)app->pBuffer;
						Mob* corpse = entity_list.GetMob(dc->corpsename);
						if(corpse==0) {
							break;
						}
						if(corpse->IsCorpse() != true) {
							break;
						}
						corpse->CastToCorpse()->Delete();
						cout << name << " deleted corpse " << dc->corpsename << endl;
						Message(13, "Corpse %s deleted.", dc->corpsename);
						break;
					}
					case OP_GMKick: {
						if(admin<150) {
							Message(13, "Your not awesome enough to use this command!");
							break;
						}
						GMKick_Struct* gmk = (GMKick_Struct *)app->pBuffer;
						Client* client = entity_list.GetClientByName(gmk->name);
						if(client==0) {
							if (!worldserver.Connected())
								Message(0, "Error: World server disconnected");
							else {
								ServerPacket* pack = new ServerPacket;
								pack->opcode = ServerOP_KickPlayer;
								pack->size = sizeof(ServerKickPlayer_Struct);
								pack->pBuffer = new uchar[pack->size];
								ServerKickPlayer_Struct* skp = (ServerKickPlayer_Struct*) pack->pBuffer;
								strcpy(skp->adminname, gmk->gmname);
								strcpy(skp->name, gmk->name);
								skp->adminrank = this->Admin();
								worldserver.SendPacket(pack);
								delete pack;
							}
						}
						else {
							entity_list.QueueClients(this,app);
							//client->Kick();
						}
						break;
					}
					case OP_GMServers: {
						if (!worldserver.Connected())
							Message(0, "Error: World server disconnected");
						else {
							ServerPacket* pack = new ServerPacket;
							pack->size = strlen(this->GetName())+2;
							pack->pBuffer = new uchar[pack->size];
							memset(pack->pBuffer, 0, pack->size);
							pack->opcode = ServerOP_ZoneStatus;
							memset(pack->pBuffer, (int8) admin, 1);
							strcpy((char *) &pack->pBuffer[1], this->GetName());
							worldserver.SendPacket(pack);
							delete pack;
						}
						break;
				   }
					case OP_Illusion: {
						Illusion_Struct* bnpc = (Illusion_Struct*)app->pBuffer;
						texture=bnpc->texture;
						helmtexture=bnpc->helmtexture;
						luclinface=bnpc->luclinface;
						race=bnpc->race;
						size=bnpc->size;
						entity_list.QueueClients(this,app);
						break;
					}
					case OP_BecomeNPC: {
						if(admin<80) {
							Message(13, "Your not awesome enough to use this command.");
							break;
						}
						entity_list.QueueClients(this, app, false);
						BecomeNPC_Struct* bnpc = (BecomeNPC_Struct*)app->pBuffer;
						Mob* cli = (Mob*) entity_list.GetMob(bnpc->id);
						if(cli==0)
							break;

						cli->SendAppearancePacket(30, 1, true);
						cli->CastToClient()->SetBecomeNPC(true);
						cli->CastToClient()->SetBecomeNPCLevel(bnpc->maxlevel);
						//TODO: Make this toggle a BecomeNPC flag so that it gets updated when people zone in as well; Make combat work with this.
						//DumpPacket(app);
						break;
					}
					case OP_SafeFallSuccess: {
						break;
					}
					case OP_Forage:
					{
					/**************************************************
****
						An interesting problem is determining in advance what the qualifications
						are for a given piece of food for even if you were to 
						select from the database items table for edible food (if there is a flag)
						you would need to still sort the item by skill and the like. Thus, 
						I would argue a food table is necessary. Until one is constructed
						or a better method built, this will work.
						
						  --MV

 						********************************************
***********/
						
#define MAX_POSSIBLE_FOOD_IDS 5
						uint32 possible_food_ids[MAX_POSSIBLE_FOOD_IDS];

						possible_food_ids[0] = 13977; /* Carrot */
						possible_food_ids[1] = 14912; /* Mill Carrot */
						possible_food_ids[2] = 14920; /* Wild Raddish */
						possible_food_ids[3] = 12845; /* Creeper Cabbage */
						possible_food_ids[4] = 14913; /* Wild Cabbage */
						possible_food_ids[5] = 1429;  /* Snow Griffin Egg */

						/**************************************************
****
						My rational: The higher your skill in forage, the more 
						likely you are to forage something. With a slight chance that 
						even at 255 you will fail
						/ **************************************************
***/
						if (rand()%265<GetSkill(FORAGE)){						
							uint32  food_id=possible_food_ids[rand()%MAX_POSSIBLE_FOOD_IDS];
							const Item_Struct* food_item = database.GetItem(food_id);
							if (food_item->name!=0) {
								this->Message(MT_Emote, "You forage a %s",food_item->name);												
								this->PutItemInInventory(0,food_item);
							}
						} else {
							if (rand()%4==1){
								this->Message(MT_Emote, "You failed to find anything worthwhile.");
							} else {
								this->Message(MT_Emote, "You fail to find anything to forage.");
							}
						}
						//See if the player increases their skill
						float wisebonus =  (pp.WIS > 200) ? 20 + ((pp.WIS - 200) * 0.05) : pp.WIS * 0.1;
						if ((55-(GetSkill(FORAGE)*0.236))+wisebonus > (float)rand()/RAND_MAX*100)
								this->SetSkill(FORAGE,++pp.skills[FORAGE]);

						break;
					}

					case OP_Mend:
					{
						int mendhp = GetMaxHP() / 4;
						int noadvance = (rand()%200);
						int currenthp = GetHP();
						if (rand()%100 <= GetSkill(MEND)) {
					    	SetHP(GetHP() + mendhp);
						    SendHPUpdate();
							Message(4, "You mend your wounds and heal some damage");
						}
						else if (noadvance > 175 && currenthp > mendhp) {
					    	SetHP(GetHP() - mendhp);
						    SendHPUpdate();
							Message(4, "You fail to mend your wounds and damage yourself!");
						}
						else if (noadvance > 175 && currenthp <= mendhp) {
					    	SetHP(1);
						    SendHPUpdate();
							Message(4, "You fail to mend your wounds and damage yourself!");
						}
						else	{
							Message(4, "You fail to mend your wounds");
						}
						if ((GetSkill(MEND) < noadvance) && (rand()%100 < 35) && (GetSkill(MEND) < 101))
							this->SetSkill(MEND,++pp.skills[MEND]);
						break;
					}
					case OP_Drink: {
						cout << "Drinking packet" << endl;
						DumpPacket(app);
						break;
					}
					case OP_ControlBoat: {
						cout << "ControlBoat packet" << endl;
						DumpPacket(app);
						break;
					}
					case OP_SetRunMode: {
						break;
					}
					//This needs to be handled better...
					case OP_EnvDamage: {
						EnvDamage2_Struct* ed = (EnvDamage2_Struct*)app->pBuffer;
						if(admin>=100 && pp.gm==1) {
							Message(13, "Your GM status protects you from %i points of type %i environmental damage.", ed->damage, ed->dmgtype);
						}
						if(pp.gm!=1) {
							SetHP(GetHP()-ed->damage);
						}
						SendHPUpdate();
						break;
					}
					case OP_EnvDamage2: {
						//Broadcast to other clients...
						entity_list.QueueClients(this, app, false);
						break;
					}
					case OP_Report: {
						cout << "Report packet" << endl;
						DumpPacket(app);
						break;
					}
					case OP_UpdateAA: {
						if(strncmp((char *)app->pBuffer,"on ",3) == 0) {
						  // turn on percentage
						  pp.perAA = atoi((char *)&app->pBuffer[3]);
						  // send an update
						  SendAAStats();
						  SendAATable();
						  cout << "UpdateAA packet: ON. Percent: " << (int)pp.perAA << endl;
						} else if(strcmp((char *)app->pBuffer,"off") == 0) {
						  // set percentage to 0%
						  pp.perAA = 0;
						  // send an update
						  SendAAStats();
						  SendAATable();
						  cout << "UpdateAA packet: OFF." << endl;
						} else if(strncmp((char *)app->pBuffer,"buy ",4) == 0) {
						  char item_name[128];
						  int buy_item = atoi((char *)&app->pBuffer[4]);
						  int item_cost = 1;
						  int max_level = 1;
						  int bought = 0;
						  if(database.GetAASkillVars(buy_item,item_name,&item_cost,&max_level)) {
							uint8 *aa_item = &(((uint8 *)&aa)[buy_item]);
							int cur_level = (*aa_item)+1;
							int cost = buy_item <= 17 ? item_cost : item_cost * cur_level;
							//Disabled for now due to problems...
							//if(pp.unspentAA >= cost && cur_level <= max_level) {
							  *aa_item = cur_level;
							  pp.aapoints -= cost;
							  database.SetPlayerAlternateAdv(account_id, pp.name, &aa);
							  Message(15,"Skill \'%s\' (%d) purchased for the cost of %d ability point(s)",item_name,cur_level,cost);
							  bought = 1;
							//}
							SendAATable();
							SendAAStats();
							cout << "UpdateAA packet: BUY. Item: " << buy_item << " Cost: " << item_cost;
							cout << (bought ? " (bought)" : " (not enough points)") << endl;
						  }
						} else {
									  cout << "Unknown command in UpdateAA opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
									  cout << " size:" << app->size << endl;
									  DumpPacket(app->pBuffer, app->size);
						}
						break;
					}
					default:
					{
						cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
						cout << " size:" << app->size << endl;
//						DumpPacket(app->pBuffer, app->size);  						break;
					}
				}
				break;
			}
			case CLIENT_KICKED:
			case DISCONNECTED:
				break;
			default:
			{
				cerr << "Unknown client_state:" << (int16) client_state << endl;
				break; 
			}
		}
		delete app;
	}    

	if (client_state == CLIENT_KICKED) {
		eqnc->Close();
	}

	if (client_state == DISCONNECTED) {
		cout << "Client disconnected (cs=d): " << GetName() << endl;
		return false;
	}

	if (!eqnc->CheckActive()) {
		cout << "Client disconnected: " << name << endl;
		return false;
	}

	return ret;
}

void Client::SendInventoryItems() {
	this->RepairInventory();
	int i;
	const Item_Struct* item = 0;
	Item_Struct* outitem = 0;
	for (i=0;i<pp_inventory_size; i++) {
		item = database.GetItem(pp.inventory[i]);
		if (item) {
//							cout << "Sending inventory slot:" << i << endl;
			APPLAYER* app = new APPLAYER;
			app->opcode = 0x3120;
			app->size = sizeof(Item_Struct);
			app->pBuffer = new uchar[app->size];
			memcpy(app->pBuffer, item, sizeof(Item_Struct));
			outitem = (Item_Struct*) app->pBuffer;
			outitem->equipSlot = i;
			outitem->common.charges = pp.invitemproperties[i].charges;
			QueuePacket(app);
			delete app;
		}
	}

/*	// TODO: Find out the "equipSlot" numbers for this!
	for (i=0;i<pp_cursorbaginventory_size; i++) {
		item = database.GetItem(pp.cursorbaginventory[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = i;
			if (item->type != 0x02)
				cpi->packets[cpi->count].item.common.charges = 0; // TODO: make this read from PP
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}*/

	// Coder_01's container code
	for (i=0; i < pp_containerinv_size; i++) {
		item = database.GetItem(pp.containerinv[i]);
		if (item) {
//							cout << "Sending inventory slot:" << 250+j << endl;
			APPLAYER* app = new APPLAYER;
			app->opcode = 0x3120;
			app->size = sizeof(Item_Struct);
			app->pBuffer = new uchar[app->size];
			memcpy(app->pBuffer, item, sizeof(Item_Struct));
			outitem = (Item_Struct*) app->pBuffer;
			outitem->equipSlot = 250 + i;
			outitem->common.charges = pp.bagitemproperties[i].charges;
			QueuePacket(app);
			delete app;
		}
	}

	// Quagmire - Bank code, these should be the proper pp locs too
	for (i=0; i < pp_bank_inv_size; i++) {
		item = database.GetItem(pp.bank_inv[i]);
		if (item) {
			APPLAYER* app = new APPLAYER;
			app->opcode = 0x3120;
			app->size = sizeof(Item_Struct);
			app->pBuffer = new uchar[app->size];
			memcpy(app->pBuffer, item, sizeof(Item_Struct));
			outitem = (Item_Struct*) app->pBuffer;
			outitem->equipSlot = 2000 + i;
			outitem->common.charges = pp.bankinvitemproperties[i].charges;
			QueuePacket(app);
			delete app;

		}
	}
	for (i=0; i < pp_bank_cont_inv_size; i++) {
		item = database.GetItem(pp.bank_cont_inv[i]);
		if (item) {
			APPLAYER* app = new APPLAYER;
			app->opcode = 0x3120;
			app->size = sizeof(Item_Struct);
			app->pBuffer = new uchar[app->size];
			memcpy(app->pBuffer, item, sizeof(Item_Struct));
			outitem = (Item_Struct*) app->pBuffer;
			outitem->equipSlot = 2030 + i;
			outitem->common.charges = pp.bankbagitemproperties[i].charges;
			QueuePacket(app);
			delete app;
		}
	}
}

void Client::BulkSendInventoryItems() {
	this->RepairInventory();
	int i;
	const Item_Struct* item = 0;
	int cpisize = sizeof(CPlayerItems_Struct) + (250 * sizeof(CPlayerItems_packet_Struct));
	CPlayerItems_Struct* cpi = (CPlayerItems_Struct*) new uchar[cpisize];
	memset(cpi, 0, cpisize);
	for (i=0;i<pp_inventory_size; i++) {
		item = database.GetItem(pp.inventory[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = i;
			cpi->packets[cpi->count].item.common.charges = pp.invitemproperties[i].charges;
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}

/*	// TODO: Find out the "equipSlot" numbers for this!
	for (i=0;i<pp_cursorbaginventory_size; i++) {
		item = database.GetItem(pp.cursorbaginventory[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = i;
			if (item->type != 0x02)
				cpi->packets[cpi->count].item.common.charges = 0; // TODO: make this read from PP
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}*/

	// Coder_01's container code
	for (i=0; i < pp_containerinv_size; i++) {
		item = database.GetItem(pp.containerinv[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = 250+i;
			cpi->packets[cpi->count].item.common.charges = pp.bagitemproperties[i].charges;
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}

	// Quagmire - Bank code, these should be the proper pp locs too
	for (i=0; i < pp_bank_inv_size; i++) {
		item = database.GetItem(pp.bank_inv[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = 2000+i;
			cpi->packets[cpi->count].item.common.charges = pp.bankinvitemproperties[i].charges;
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}
	for (i=0; i < pp_bank_cont_inv_size; i++) {
		item = database.GetItem(pp.bank_cont_inv[i]);
		if (item) {
			cpi->packets[cpi->count].opcode = ntohs(OP_CPlayerItem);
			memcpy(&cpi->packets[cpi->count].item, item, sizeof(Item_Struct));
			cpi->packets[cpi->count].item.equipSlot = 2030+i;
			cpi->packets[cpi->count].item.common.charges = pp.bankbagitemproperties[i].charges;
			cpi->count++;
			if (cpi->count >= 250) {
				cout << "ERROR: cpi->count>=250 in BulkSendInventoryItems()" << endl;
				return;
			}
		}
	}
	APPLAYER* outapp = new APPLAYER(OP_CPlayerItems, 5000);
	outapp->size = 2 + DeflatePacket((uchar*) cpi->packets, cpi->count * sizeof(CPlayerItems_packet_Struct), &outapp->pBuffer[2], 5000-2);
	CPlayerItems_Struct* cpi2 = (CPlayerItems_Struct*) outapp->pBuffer;
	cpi2->count = cpi->count;
	QueuePacket(outapp);
//FileDumpPacket("BulkItem.txt", (uchar*) cpi, sizeof(CPlayerItems_Struct) + (cpi->count * sizeof(CPlayerItems_packet_Struct)));
//FileDumpPacket("BulkItem.txt", outapp);
	delete outapp;
	delete cpi;
}

