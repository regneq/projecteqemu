#include "../common/database.h"
#include "entity.h"
#include "mob.h"
#include "client.h"

class Corpse : public Mob
{
public:
	static void Corpse::SendEndLootErrorPacket(Client* client);
	static void Corpse::SendLootReqErrorPacket(Client* client, int8 response = 2);
	static Corpse* Corpse::LoadFromDBData(int32 in_corpseid, int32 in_charid, char* in_charname, uchar* in_data, int32 in_datasize, float in_x, float in_y, float in_z, float in_heading, char* time);

	Corpse::Corpse(NPC* in_npc, ItemList** in_itemlist, int32 in_npctypeid, NPCType** in_npctypedata, int32 in_decaytime = 600000);
	Corpse::Corpse(Client* client, PlayerProfile_Struct* pp,sint32 in_rezexp);
	Corpse::Corpse(int32 in_corpseid, int32 in_charid, char* in_charname, ItemList* in_itemlist, int32 in_copper, int32 in_silver, int32 in_gold, int32 in_plat, float in_x, float in_y, float in_z, float in_heading, float in_size, int8 in_gender, int8 in_race, int8 in_class, int8 in_deity, int8 in_level, int8 in_texture, int8 in_helmtexture,int32 in_rezexp);
	Corpse::~Corpse();

	bool	IsCorpse()			{ return true; }
	bool	IsPlayerCorpse()	{ return p_PlayerCorpse; }
	bool	IsNPCCorpse()		{ return !p_PlayerCorpse; }
	bool	Process();
	bool	Save();
	int32	GetCharID()			{ return charid; }
	int32	GetDBID()			{ return dbid; }
	int32	GetDecayTime()		{ if (corpse_decay_timer == 0) return 0xFFFFFFFF; else return corpse_decay_timer->GetRemainingTime(); }
	char*	GetOwnerName()		{ return orgname;}
	void	CalcCorpseName();

	void	SetDecayTimer(int32 decaytime);
	bool	IsEmpty();
	void	AddItem(int16 itemnum, int8 charges, int16 slot = 0);
	int16	GetWornItem(int16 equipSlot);
	ServerLootItem_Struct* GetItem(int16 lootslot);
	void	RemoveItem(int16 lootslot);
	void	AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum);
	void	RemoveCash();
	void	QueryLoot(Client* to);
	int32	CountItems();
	void	Delete();
	virtual void	Depop(bool StartSpawnTimer = true);

	uint32	GetCopper()		{ return copper; }
	uint32	GetSilver()		{ return silver; }
	uint32	GetGold()		{ return gold; }
	uint32	GetPlatinum()	{ return platinum; }

	void	FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho);
	void	MakeLootRequestPackets(Client* client, APPLAYER* app);
	void	LootItem(Client* client, APPLAYER* app);
	void	EndLoot(Client* client, APPLAYER* app);
	void	Summon(Client* client,bool spell);
	void	CastRezz(int16 spellid, Mob* Caster);
	void	CompleteRezz();
protected:
private:
	bool		p_PlayerCorpse;
	char		orgname[64];
	int32		dbid;
	int32		charid;
	ItemList*	itemlist;
	uint32		copper;
	uint32		silver;
	uint32		gold;
	uint32		platinum;
	bool		p_depop;
	int32		BeingLootedBy;
	int32		rezzexp;
	bool		isrezzed;
	Timer*	corpse_decay_timer;
};

