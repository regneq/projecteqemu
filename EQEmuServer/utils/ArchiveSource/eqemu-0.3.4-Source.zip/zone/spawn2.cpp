#include "../common/debug.h"
#include <stdlib.h>
#include "spawn2.h"
#include "entity.h"
#include "npc.h"
#include "zone.h"
#include "spawngroup.h"
#include "../common/database.h"

extern EntityList entity_list;
extern Zone* zone;
extern Database database;


Spawn2::Spawn2(int32 in_spawn2_id, int32 spawngroup_id, float in_x, float in_y, float in_z, float in_heading, int32 respawn, int32 variance, int32 timeleft)
{
	spawn2_id = in_spawn2_id;
	spawngroup_id_ = spawngroup_id;
	x = in_x;
	y = in_y;
	z = in_z;
	heading = in_heading;
    respawn_ = respawn;
	variance_ = variance;
	if (spawn2_id == 1720) {
		uint32 i = 0;
	}

	timer = new Timer( resetTimer() );
	if (timeleft == 0xFFFFFFFF) {
		timer->Disable();
	}
	else if (timeleft == 0) {
		timer->Trigger();
	}
	else {
		timer->Start(timeleft);
	}
}

Spawn2::~Spawn2()
{
	delete timer;
}

int32 Spawn2::resetTimer()
{
	int32 rspawn = respawn_ * 1000;

	if (variance_ != 0) {
		int32 vardir = (rand()%50);
		int32 variance = (rand()%variance_);
		float varper = variance*0.01;
		float varvalue = varper*(rspawn);
		if (vardir < 50)
		{
		  varvalue = varvalue * -1;
		}

		rspawn += (int32) varvalue;
	}

	return (rspawn);

}

bool Spawn2::Process() {
	if (timer->Check())	{
		timer->Disable();

		SpawnGroup* sg = zone->spawn_group_list->GetSpawnGroup(spawngroup_id_);
		if (sg == 0)
			return false;

		int32 npcid = sg->GetNPCType();
		if (npcid) {
			const NPCType* tmp = database.GetNPCType(npcid);
			if (tmp) {
				NPC* npc = new NPC(tmp, this, x, y, z, heading);
				npc->AddLootTable();
				entity_list.AddNPC(npc);
			}
		}
		else {
			Reset();
		}
	}
	return true;
}

void Spawn2::Reset()
{
	timer->Start(resetTimer());
}

void Spawn2::Depop() {
	timer->Disable();
}

void Spawn2::Repop(int32 delay) {
	if (delay == 0)
		timer->Trigger();
	else
		timer->Start(delay);
}

