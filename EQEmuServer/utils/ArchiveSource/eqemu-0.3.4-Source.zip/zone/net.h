#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
	#include <netdb.h>
#endif


#include <errno.h>
#include <fcntl.h>
#include "../common/types.h"

void CatchSignal(int);
void UpdateWindowTitle();

class NetConnection
{
public:
	NetConnection::~NetConnection();
	NetConnection::NetConnection() { ZonePort = 0; ZoneAddress = 0; WorldAddress = 0; };

	int32	GetIP();
	int32	GetIP(char* name);
	void	SaveInfo(char* address, int32 port, char* waddress,char* filename);
	char*	GetWorldAddress() { return WorldAddress; }
	char*	GetZoneAddress() { return ZoneAddress; }
	char*	GetZoneFileName() { return ZoneFileName; }
	int32	GetZonePort() { return ZonePort; }
private:
	int16 ZonePort;
	char* ZoneAddress;
	char* WorldAddress;
	char ZoneFileName[50];
};
