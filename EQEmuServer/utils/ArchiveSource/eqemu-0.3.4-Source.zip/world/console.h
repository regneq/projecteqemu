#ifndef CONSOLE_H
#define CONSOLE_H
#define CONSOLE_TIMEOUT 600000
#define CONSOLE_STATE_USERNAME 0
#define CONSOLE_STATE_PASSWORD 1
#define CONSOLE_STATE_CONNECTED 2
#define CONSOLE_STATE_CLOSED 3
#define CONSOLE_STATE_ZS 4

#include "../common/linked_list.h"
#include "../common/timer.h"
#include "../common/queue.h"
#include "../common/servertalk.h"
#include "WorldTCPConnection.h"
#include "../common/Mutex.h"

bool InitTCP();
#ifdef WIN32
void ConsoleLoop(void *tmp);
#else
void *ConsoleLoop(void *tmp);
#endif

class Console : public WorldTCPConnection {
public:
	Console(int32 in_ip, int16 in_port, int in_send_socket);
	~Console();
	bool Process();
	bool ReceiveData();
	void Send(const char* message);
	int8 Admin() { return admin; }
	int32 GetIP() { return ip; }
	int16 GetPort() { return port; }
	void ProcessCommand(const char* command);
	void Die();

	void SendEmoteMessage(const char* to, int32 to_guilddbid, int32 type, const char* message, ...);
	void SendExtMessage(const char* message, ...);
	void SendMessage(int8 newline, const char* message, ...);

	const char* AccountName() { return paccountname; }
	int32 AccountID() { return paccountid; }

private:
	Mutex	MOutPacketLock;
	int send_socket;
	int32 ip;
	int16 port;

	Timer* timeout_timer;

	void ClearBuffer();
	void SendPrompt();
	void CheckBuffer();

	int32 paccountid;
	char paccountname[30];

	int8 state;

	int8 admin;
	uchar textbuf[1024];
	int bufindex;
};

class ConsoleList
{
public:
	ConsoleList() {}
	~ConsoleList() {}
		
	void Add(Console* con);
	void ReceiveData();

	void SendConsoleWho(const char* to, int8 admin, WorldTCPConnection* connection);
	Console* FindByAccountName(const char* accname);
private:
	LinkedList<Console*> list;
};
#endif
