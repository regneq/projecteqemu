#ifdef _DEBUG
	#ifndef _CRTDBG_MAP_ALLOC
		#define _CRTDBG_MAP_ALLOC
		#include <stdlib.h>
		#include <crtdbg.h>
		#define new \
        new(_NORMAL_BLOCK, __FILE__, __LINE__) 
	#endif
#endif

#define CURRENT_CHAT_VERSION	"EqEmu 0.3.1-Release Chat Server - [Porky]"
#define CURRENT_ZONE_VERSION	"EqEmu 0.3.1-Release Zoneserver - [Porky]"
#define CURRENT_WORLD_VERSION   "EqEmu 0.3.1-Release Worldserver - [Porky]"
#define CURRENT_VERSION			"0.3.1"
#define COMPILE_DATE	__DATE__
#define COMPILE_TIME	__TIME__
#ifndef WIN32
#define LAST_MODIFIED	__TIME__
#else
#define LAST_MODIFIED	__TIMESTAMP__
#endif
