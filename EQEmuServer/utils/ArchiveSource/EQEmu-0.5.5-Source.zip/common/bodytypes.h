/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef BODYTYPES_H
#define BODYTYPES_H

#define BT_Undead 3
#define BT_SummonedUndead 8
#define BT_Giant 9
#define BT_NoTarget 11	// can't target this bodytype
#define BT_Undead2 12
#define BT_Animal 21
#define BT_Summoned 24
#define BT_Summoned2 27
#define BT_Summoned3 28
#define BT_Dragon 30
#define BT_NoTarget2 60
/* bodytypes above 64 make the mob not show up */

#endif
