#include "InteractivePC.h"
#include <math.h>
#include <iostream.h>
#include <stdio.h>
#include "../common/moremath.h"

extern Database database;

InteractivePC::InteractivePC(NPCType* npc)
: NPC(npc, 0, 0, 0, 0, 0, 0)
{


}

InteractivePC::~InteractivePC()
{


}

bool InteractivePC::Process()
{

return true;
}