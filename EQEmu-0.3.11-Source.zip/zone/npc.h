/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef NPC_H
#define NPC_H

class NPC;
#include "../common/database.h"
#include "mob.h"
//#include "spawn.h"
#include "spawn2.h"
#include "hate_list.h"
#include "loottable.h"
#include "zonedump.h"

#ifdef WIN32
	#define  M_PI	3.141592
#endif

//typedef LinkedList<Item_Struct*> ItemList;

class NPC : public Mob
{
public:
	static NPC* SpawnNPC(const char* spawncommand, float in_x, float in_y, float in_z, float in_heading = 0, Client* client = 0);

	NPC(const NPCType* data, Spawn2* respawn, float x, float y, float z, float heading, bool IsCorpse = false);
	virtual ~NPC();

	virtual bool IsNPC() { return true; }

	virtual bool Process();

	void	AddToHateList(Mob* other, sint32 damage = 0, sint32 hate = 0xFFFFFFFF);
	// Kaiyodo - added attacking hand as a param
	void	Attack(Mob* other, int Hand = 13);
	void	Damage(Mob* other, sint32 damage, int16 spell_id, int8 attack_skill = 0x04);
	void	Death(Mob* other, sint32 damage, int16 spell_id = 0xFFFF, int8 attack_skill = 0x04);
	Mob*	GetHateTop()  {return hate_list.GetTop();}
	Mob*	GetHateRandom()  {return hate_list.GetRandom();}
	bool	IsEngaged()   {return (hate_list.GetTop() == 0) ? false:true; }
	bool	DatabaseCastAccepted(int spell_id);
	bool	AddQueuedSpell(int16 spell_id);
	int32	RandomTimer(int min, int max);
	int32	spelllimit;

	void	FaceTarget(Mob* MobToFace = 0);
	void	RemoveFromHateList(Mob* mob);
	void	WhipeHateList() { hate_list.Whipe(); }
	void	GoToBind()	{ GMMove(org_x, org_y, org_z, org_heading); }

	void	AddItem(const Item_Struct* item, int8 charges, int8 slot = 0);
	void	AddItem(int32 itemid, int8 charges, int8 slot = 0);
	void	AddLootTable();
	void	NPCSpecialAttacks(const char* parse, int permtag);
	void	NPCDatabaseSpells(const char* parse);
	void	NPCUnharmSpell(int spell_id);
	void	CheckFriendlySpellStatus();
	void	CheckEnemySpellStatus();
	void	NPCHarmSpell(int target,int type);
	void    HateSummon();
	void	RemoveItem(uint16 item_id);
	void	ClearItemList();
	ServerLootItem_Struct*	GetItem(int slot_id);
	void	AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum);
	void	AddCash();
	void	RemoveCash();
	ItemList*	GetItemList() { return itemlist; }
	void	QueryLoot(Client* to);
	int32	CountLoot();
	int32 SpecialNPCAttacks[4]; //1 = Summon, 2 = Enrage, 3 = Rampage, 4 = Flury
	int32 SpecialNPCCounts[4];
	int32 SpecialNPCCountstwo[4];
	int32 NPCSpells[20]; //Maximum of 20 spells...
	int32 NPCSpellTime[20];
	void	DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex);
	int32	GetLoottableID()	{ return loottable_id; }
	void	SetPetType(int8 in_type)	{ typeofpet = in_type; } // put this here because only NPCs can be anything but charmed pets

	uint32	GetCopper()		{ return copper; }
	uint32	GetSilver()		{ return silver; }
	uint32	GetGold()		{ return gold; }
	uint32	GetPlatinum()	{ return platinum; }
	uint32	MerchantType;
	void	SendTo(float new_x, float new_y);
	void	Depop(bool StartSpawnTimer = true);
	void	Stun(int16 duration);
	bool	IsStunned() { return stunned; }
	bool	IsRooted() { return rooted; }
	bool	IsInteractive() { return interactive; }
	int8	HasBanishCapability() { return banishcapability; }

	int32   GetFactionID()  { return faction_id; } // Merkur 03/11
	Mob*	GetIgnoreTarget() { return ignore_target; }
	void	SetIgnoreTarget(Mob* mob) {ignore_target = mob; }
	sint32	GetNPCHate(Mob* in_ent)  {return hate_list.GetEntHate(in_ent);}

	void	SetFactionID(int32 newfactionid) { faction_id=newfactionid; }

	Timer*	gohome_timer;

protected:
	friend class EntityList;
	HateList hate_list;
//	Spawn*	respawn;
	Spawn2*	respawn2;
	Mob*	ignore_target;
	uint32	copper;
	uint32	silver;
	uint32	gold;
	uint32	platinum;
	ItemList*	itemlist;

	int32	faction_id;
	
	Timer*	scanarea_timer; 
	Timer*	spells_timer; 
	
	Timer*	movement_timer;
	Timer*	walking_timer;
	Timer*	npcroam_timer;

	Timer*	tics_timer;
		
	float   org_x, org_y, org_z, org_heading;

	bool	ishome;
	bool	ismovinghome;
	bool	reallygohome;
	bool	evader;
	bool	interactive;
	int8	banishcapability;
	int8	max_dmg;
	int8	min_dmg;
	sint32	hp_regen;
	sint32	mana_regen;
private:
	int32	loottable_id;
	bool	p_depop;
};

#endif

