/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef DATABASE_H
#define DATABASE_H

#define AUTHENTICATION_TIMEOUT	60

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
#endif
#include <mysql.h>

#include "types.h"
#include "linked_list.h"
#include "eq_packet_structs.h"
#include "EQNetwork.h"
#include "../common/guilds.h"
#include "../common/MiscFunctions.h"
#include "../common/Mutex.h"
#include "../zone/loottable.h"
#include "../zone/faction.h"
#include "../zone/message.h"

//class Spawn;
class Spawn2;
class SpawnGroupList;
class Petition;
class Client;
struct Combine_Struct;
//struct Faction;
//struct FactionMods;
//struct FactionValue;
struct ZonePoint;
struct NPCType;

// Added By Hogie 
// INSERT into variables (varname,value) values('decaytime [minlevel] [maxlevel]','[number of seconds]');
// IE: decaytime 1 54 = Levels 1 through 54
//     decaytime 55 100 = Levels 55 through 100
// It will always put the LAST time for the level (I think) from the Database
struct npcDecayTimes_Struct {
	int16 minlvl;
	int16 maxlvl;
	int32 seconds;
};
// Added By Hogie -- End

class Database
{
public:
	Database();
	Database(const char* host, const char* user, const char* passwd, const char* database);
	~Database();

	char	commands[200][200];
	sint16	commandslevels[200];
	int		maxcommandlevel;

	bool	MoveCharacterToZone(char* charname, char* zonename);
	bool	SetGMSpeed(int32 account_id, int8 gmspeed);
	int8	GetGMSpeed(int32 account_id);
	void	DeletePetitionFromDB(Petition* wpet);
	void	ExtraOptions();
	sint16	CommandRequirement(const char* commandname);
	void	UpdatePetitionToDB(Petition* wpet);
	void	InsertPetitionToDB(Petition* wpet);
	void	RefreshPetitionsFromDB();
	bool	GetDecayTimes(npcDecayTimes_Struct* npcCorpseDecayTimes);
	int8	CheckWorldVerAuth(char* version);
	bool	PopulateZoneLists(const char* zone_name, LinkedList<ZonePoint*>* zone_point_list, SpawnGroupList* spawn_group_list);
	bool	PopulateZoneSpawnList(const char* zone_name, LinkedList<Spawn2*> &spawn2_list, int32 repopdelay = 0);
	Spawn2*	LoadSpawn2(LinkedList<Spawn2*> &spawn2_list, int32 spawn2id, int32 timeleft);
	bool	DumpZoneState();
	sint8	LoadZoneState(const char* zonename, LinkedList<Spawn2*>& spawn2_list);
	int32	CreatePlayerCorpse(int32 charid, const char* charname, const char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading);
	int32	UpdatePlayerCorpse(int32 dbid, int32 charid, const char* charname, const char* zonename, uchar* data, int32 datasize, float x, float y, float z, float heading);
	bool	DeletePlayerCorpse(int32 dbid);
	bool	LoadPlayerCorpses(const char* zonename);
	bool	GetZoneLongName(const char* short_name, char** long_name, char* file_name = 0, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0);
	int32	GetAuthentication(const char* char_name, const char* zone_name, int32 ip);
	bool	SetAuthentication(int32 account_id, const char* char_name, const char* zone_name, int32 ip);
	bool	GetAuthentication(int32 account_id, char* char_name, char* zone_name, int32 ip);
	bool	UpdateItem(int32 item_id,Item_Struct* is);
	bool	ClearAuthentication(int32 account_id);
	int8	GetServerType();

	bool	UpdateTempPacket(char* packet,int32 lsaccount_id);
	bool	UpdateLiveChar(char* charname,int32 lsaccount_id);
	bool	GetLiveChar(int32 lsaccount_id, char* cname);
	bool	GetTempPacket(int32 lsaccount_id, char* packet);

	bool	SetServerFilters(char* name, ServerSideFilters_Struct *ssfs);
	int32	GetServerFilters(char* name, ServerSideFilters_Struct *ssfs);


    bool	SaveItemToDatabase(Item_Struct* ItemToSave);
	int32	CheckLogin(const char* name, const char* password);
	sint16	CheckStatus(int32 account_id);
	bool	CreateAccount(const char* name, const char* password, sint16 status, int32 lsaccount_id = 0);
	bool	DeleteAccount(const char* name);
	bool	SetGMFlag(const char* name, sint16 status);
	bool	SetSpecialAttkFlag(int8 id, const char* flag);
	bool	CheckZoneserverAuth(const char* ipaddr);
	bool	UpdateName(const char* oldname, const char* newname);
	bool	SetHackerFlag(const char* accountname, const char* charactername, const char* hacked);
    bool	SetItemAtt(char* att, char * value, unsigned int ItemIndex);
	void	GetCharSelectInfo(int32 account_id, CharacterSelect_Struct*);
	int32	GetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp, char* current_zone = 0);
	bool	SetPlayerProfile(int32 account_id, char* name, PlayerProfile_Struct* pp, char* current_zone = 0);
	bool	CreateSpawn2(int32 spawngroup, const char* zone, float heading, float x, float y, float z, int32 respawn, int32 variance);
	bool	CheckNameFilter(const char* name);
	bool	AddToNameFilter(const char* name);
	bool	CheckUsedName(char* name);
	bool	ReserveName(int32 account_id, char* name);
	bool	CreateCharacter(int32 account_id, char* name, int16 gender, int16 race, int16 class_, int8 str, int8 sta, int8 cha, int8 dex, int8 int_, int8 agi, int8 wis, int8 face);
	bool	CreateCharacter(int32 account_id, PlayerProfile_Struct* pp);
	bool	DeleteCharacter(char* name);
	bool    SetStartingItems(PlayerProfile_Struct *cc, int16 si_race, int8 si_class, char* si_name, int GM_FLAG);

	int32	GetAccountIDByChar(const char* charname);
	int32	GetAccountIDByName(const char* accname);
	void	GetAccountName(int32 accountid, char* name);
	void	GetCharacterInfo(const char* name, int32* charid, int32* guilddbid, int8* guildrank);

	bool	OpenQuery(char* zonename);
	bool	GetVariable(const char* varname, char* varvalue, int16 varvalue_len);
	bool	SetVariable(const char* varname, const char* varvalue);
	bool	LoadGuilds(GuildRanks_Struct* guilds);
	bool	GetGuildRanks(int32 guildeqid, GuildRanks_Struct* gr);
	int32	GetGuildEQID(int32 guilddbid);
	bool	SetGuild(int32 charid, int32 guilddbid, int8 guildrank);
	int32	GetFreeGuildEQID();
	int32	CreateGuild(const char* name, int32 leader);
	bool	DeleteGuild(int32 guilddbid);
	bool	RenameGuild(int32 guilddbid, const char* name);
	bool	EditGuild(int32 guilddbid, int8 ranknum, GuildRankLevel_Struct* grl);
	int32	GetGuildDBIDbyLeader(int32 leader);
	bool	SetGuildLeader(int32 guilddbid, int32 leader);
	bool	SetGuildMOTD(int32 guilddbid, const char* motd);
	bool	GetGuildMOTD(int32 guilddbid, char* motd);
	int32	GetMerchantData(int32 merchantid, int32 slot);
	int32	GetMerchantListNumb(int32 merchantid);
	bool	GetSafePoints(const char* short_name, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0, sint16* minstatus = 0, int8* minlevel = 0);
	bool	GetSafePoints(int32 zoneID, float* safe_x = 0, float* safe_y = 0, float* safe_z = 0, sint16* minstatus = 0, int8* minlevel = 0) { return GetSafePoints(GetZoneName(zoneID), safe_x, safe_y, safe_z, minstatus, minlevel); }
	sint32	GetItemsCount(int32* oMaxID = 0);
	sint32	GetNPCTypesCount(int32* oMaxID = 0);
	bool	LoadItems();
#ifdef SHAREMEM
	bool	DBLoadItems(int16 iItemCount, int16 iMaxItemID);
	bool	DBLoadNPCTypes(int32 iNPCTypeCount, int32 iMaxNPCTypeID);
#endif
	bool	LoadNPCTypes();
	bool	LoadZoneNames();
	inline int32		GetMaxItem()			{ return max_item; }
	const Item_Struct*	GetItem(uint32 id);
	const NPCType*		GetNPCType(uint32 id);
	int32	GetZoneID(const char* zonename);
	const char*	GetZoneName(int32 zoneID, bool ErrorUnknown = false);

	bool	GetNPCFactionList(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetNPCPrimaryFaction(int32 npc_id, int32* faction_id, sint32* value); // rembrant, needed for factions Dec, 16 2001
	bool	GetFactionData(FactionMods* fd, sint32 class_mod, sint32 race_mod, sint32 deity_mod, int32 faction_id); //rembrant, needed for factions Dec, 16 2001
	bool	GetFactionName(int32 faction_id, char* name); // rembrant, needed for factions Dec, 16 2001
	bool	SetCharacterFactionLevel(int32 char_id, int32 faction_id, sint32 value,LinkedList<FactionValue*>* val_list); // rembrant, needed for factions Dec, 16 2001
	bool	LoadFactionData();
	bool	LoadFactionValues(LinkedList<FactionValue*>* val_list, int32 char_id);

	int32	GetAccountIDFromLSID(int32 lsaccount_id);

	bool	SetLSAuthChange(int32 account_id, const char* ip);
	bool	UpdateLSAccountAuth(int32 account_id, int8* auth);
	int32	GetLSLoginInfo(char* iUsername, char* oPassword = 0);
//	int32	GetLSLoginInfo(char* iUsername, char* oPassword = 0, char* md5pass = 0);
	int32	GetLSAuthentication(int8* auth);
	int32	GetLSAuthChange(const char* ip);
	bool	AddLoginAccount(char* stationname, char* password, char* chathandel, char* cdkey, char* email);
	int8	ChangeLSPassword(int32 accountid, const char* newpassword, const char* oldpassword = 0);
	bool	ClearLSAuthChange();
	bool	RemoveLSAuthChange(int32 account_id);
	bool	GetLSAccountInfo(int32 account_id, char* name, int8* lsadmin, int* status, bool* verified);
	bool	MD5Auth(char* oPassword, char* md5check)	;
	sint8	CheckWorldAuth(const char* account, const char* password, int32* account_id, int32* admin_id, bool* GreenName, bool* ShowDown);
	bool	UpdateWorldName(int32 accountid, const char* name);
	char*	GetBook(char txtfile[14]);
	void	LoadWorldList();

	void	ping();

	bool	GetTradeRecipe(Combine_Struct* combin,int16 tradeskill, int16* product, int16* skillneeded);
	bool	MakeDoorSpawnPacket(const char* zone,APPLAYER* app);
	bool	CheckGuildDoor(int8 doorid,int16 guildid, const char* zone);
	bool	SetGuildDoor(int8 doorid,int16 guildid, const char* zone);
	bool	MakeZonepointPacket(const char* zone,APPLAYER* app);
	bool	InsertStats(int32 in_players, int32 in_zones, int32 in_servers);

	void	AddLootTableToNPC(int32 loottable_id, ItemList* itemlist, int32* copper, int32* silver, int32* gold, int32* plat);
	bool	UpdateZoneSafeCoords(const char* zonename, float x, float y, float z);
	int8	GetUseCFGSafeCoords();
	int8	CopyCharacter(const char* oldname, const char* newname, int8 acctid);
	int32	GetPlayerAlternateAdv(int32 account_id, char* name, PlayerAA_Struct* aa);
	int32	GetAASkillVars(int32 skill_id, char* name_buf, int *cost, int *max_level);
	bool	SetPlayerAlternateAdv(int32 account_id, char* name, PlayerAA_Struct* aa);
	bool	SetLSAdmin(int32 account_id, int8 in_status);
	void	FindAccounts(char* whom, Client* from);

#ifndef SHAREMEM
	void Database::LoadAItem(int item_id,unsigned int * texture,unsigned int* color);
#endif
protected:
	void	AddLootDropToNPC(int32 lootdrop_id, ItemList* itemlist);
	bool	RunQuery(const char* query, int32 querylen, char* errbuf = 0, MYSQL_RES** result = 0, int32* affected_rows = 0, int32* errnum = 0, bool retry = true);
	int32	DoEscapeString(char* tobuf, const char* frombuf, int32 fromlen);
private:
	MYSQL	mysql;
	Mutex	MDatabase;

	int32	max_zonename;
	char**	zonename_array;
	uint32			max_item;
	uint32			max_npc_type;
#ifndef SHAREMEM
	Item_Struct**	item_array;
	NPCType**		npc_type_array;
#endif
	uint32			max_faction;
	Faction**		faction_array;
};
#endif

