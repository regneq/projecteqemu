/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <stdio.h>

#include "packet_dump.h"
#include "EQNetwork.h"
#include "../common/servertalk.h"

#ifdef WIN32
void DumpPacketAscii(uchar* buf, int32 size, int32 cols, int32 skip)
#else
void DumpPacketAscii(uchar* buf, int32 size, int32 cols=16, int32 skip=0)
#endif
{
	// Output as ASCII
	for(int i=skip; i<size; i++)
	{
		if ((i-skip)%cols==0)
		{
			cout << endl << setw(3) << setfill(' ') << i-skip << ":";
		}
		else if ((i-skip)%(cols/2)==0)
		{
			cout << " - ";
		}
		if (buf[i] > 32 && buf[i] < 127)
		{
			cout << buf[i];
		}
		else
		{
			cout << '.';
		}
	}
	cout << endl << endl;
}

#ifdef WIN32
void DumpPacketHex(uchar* buf, int32 size, int32 cols, int32 skip)
#else
void DumpPacketHex(uchar* buf, int32 size, int32 cols=16, int32 skip=0)
#endif
{
	if (size == 0)
		return;
	// Output as HEX
	char output[4];
	int j = 0; char* ascii = new char[cols+1]; memset(ascii, 0, cols+1);
	int i;
    for(i=skip; i<size; i++)
    {
		if ((i-skip)%cols==0) {
			if (i != skip)
				cout << " | " << ascii << endl;
			cout << setw(4) << setfill(' ') << i-skip << ": ";
			memset(ascii, 0, cols+1);
			j = 0;
		}
		else if ((i-skip)%(cols/2) == 0) {
			cout << "- ";
		}
		sprintf(output, "%02X ", (unsigned char)buf[i]);
		cout << output;

		if (buf[i] >= 32 && buf[i] < 127) {
			ascii[j++] = buf[i];
		}
		else {
			ascii[j++] = '.';
		}
//		cout << setfill(0) << setw(2) << hex << (int)buf[i] << " ";
    }
	int k = ((i-skip)-1)%cols;
	if (k < 8)
		cout << "  ";
	for (int h = k+1; h < cols; h++) {
		cout << "   ";
	}
	cout << " | " << ascii << endl;
	delete ascii;
}

void DumpPacketHex(APPLAYER* app)
{
	DumpPacketHex(app->pBuffer, app->size);
}

void DumpPacketAscii(APPLAYER* app)
{
	DumpPacketAscii(app->pBuffer, app->size);
}

void DumpPacket(uchar* buf, int32 size)
{
	DumpPacketHex(buf, size);
//	DumpPacketAscii(buf,size);
}

void DumpPacket(APPLAYER* app)
{
	DumpPacketHex(app->pBuffer, app->size);
//	DumpPacketAscii(app->pBuffer, app->size);
}

void DumpPacket(ServerPacket* pack)
{
	DumpPacketHex(pack->pBuffer, pack->size);
}

void DumpPacketBin(APPLAYER* app) {
	DumpPacketBin(app->pBuffer, app->size);
}

void DumpPacketBin(ServerPacket* pack) {
	DumpPacketBin(pack->pBuffer, pack->size);
}

void DumpPacketBin(int32 data) {
	DumpPacketBin((uchar*)&data, sizeof(int32));
}

void DumpPacketBin(int16 data) {
	DumpPacketBin((uchar*)&data, sizeof(int16));
}

void DumpPacketBin(int8 data) {
	DumpPacketBin((uchar*)&data, sizeof(int8));
}


void DumpPacketBin(const void* iData, int32 len) {
	int8* data = (int8*) iData;
	for (int k=0; k<len; k++) {
		if (k % 4 == 0)
			cout << endl << setw(4) << setfill('0') << k << ":";
		else if (k % 2 == 0)
			cout << " ";
		cout << " ";
		if (data[k] & 1)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 2)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 4)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 8)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 16)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 32)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 64)
			cout << "1";
		else
			cout << "0";
		if (data[k] & 128)
			cout << "1";
		else
			cout << "0";
	}
	cout << endl;
}
