#include "../common/debug.h"
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Disgrace: for windows compile
#ifdef WIN32
	#include <windows.h>
	#include <winsock.h>
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#else
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <unistd.h>
#endif

#include "client.h"
#include "../common/eq_opcodes.h"
#include "../common/eq_packet_structs.h"
#include "../common/packet_dump.h"
#include "../common/database.h"
#include "LoginServer.h"
#include "zoneserver.h"
#include "net.h"

extern Database database;
extern const char* ZONE_NAME;
extern GuildRanks_Struct guilds[512];
extern ZSList zoneserver_list;
extern LoginServer loginserver;
extern uint32 numclients;
extern NetConnection net;

Client::Client(EQNetworkConnection* ieqnc) {
	eqnc = ieqnc;
	ip = eqnc->GetrIP();
	port = ntohs(eqnc->GetrPort());

	autobootup_timeout = new Timer(10000);
	autobootup_timeout->Disable();
	
	account_id = 0;

	memset(zone_name, 0, sizeof(zone_name));
	char_name[0] = 0;
	pwaitingforbootup = 0;
	numclients++;
}

Client::~Client() {
	eqnc->Free();
	safe_delete(autobootup_timeout);
	numclients--;
}

void Client::SendCharInfo() {
	APPLAYER *outapp;
	outapp = new APPLAYER(OP_SendCharInfo, sizeof(CharacterSelect_Struct));
	CharacterSelect_Struct* cs_struct = (CharacterSelect_Struct*)outapp->pBuffer;

	database.GetCharSelectInfo(account_id, cs_struct);

	QueuePacket(outapp);
	delete outapp;
}

bool Client::Process() {
	bool ret = true;
	bool sendguilds = true;
	bool firstlogin = true;
    sockaddr_in to;

	memset((char *) &to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_port = port;
    to.sin_addr.s_addr = ip;

	if (autobootup_timeout->Check()) {
		ZoneUnavail();
	}
    
	/************ Get all packets from packet manager out queue and process them ************/
	APPLAYER *app = 0;
	while(ret && (app = eqnc->PopPacket()))
	{
		switch(app->opcode)
		{
		case OP_SendLoginInfo:
		{

			// Quagmire - max len for name is 18, pass 15
			char name[19];
			char password[16];
			memset(name, 0, sizeof(name));
			memset(password, 0, sizeof(password));

			strncpy(name, (char*)app->pBuffer, 18);
			if (app->size < strlen(name)+2) {
				ret = false;
				break;
			}
			strncpy(password, (char*)&app->pBuffer[strlen(name)+1], 15);

//cerr << "u='" << name << "', p='" << password << "'" << endl;
			if (strncasecmp(name, "LS#", 3) == 0) {
				if (loginserver.Connected() == false) {
					cout << "Error: Login server login while not connected to login server." << endl;
					ret = false;
					break;
				}
				LSAuth_Struct* lsa = 0;
				if (lsa = loginserver.CheckAuth(atoi(&name[3]), password)) {
//cout << "Client from LS: id=" << lsa->lsaccount_id << ", n=" << lsa->name << ", k=" << lsa->key << endl;
					account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
					if (account_id == 0) {
						database.CreateAccount(lsa->name, "", net.GetDefaultStatus(), lsa->lsaccount_id);
						account_id = database.GetAccountIDFromLSID(lsa->lsaccount_id);
						if (account_id == 0) {
							// TODO: Find out how to tell the client wrong username/password
							cerr << "Error adding local account for LS login: '" << lsa->name << "', duplicate name?" << endl;
							ret = false;
							break;
						}
					}
					sendguilds = lsa->firstconnect;
					firstlogin = lsa->firstconnect;
					lsa->firstconnect = false;
//					loginserver.RemoveAuth(lsa->lsaccount_id);
//cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << ", k=" << password << endl;
					cout << "Logged in: LS#" << lsa->lsaccount_id << ": " << lsa->name << endl;
				}
				else {
					// TODO: Find out how to tell the client wrong username/password
//cerr << "Bad/expired session key: " << name << ", k=" << password << endl;
					cerr << "Bad/expired session key: " << name << endl;
					ret = false;
					break;
				}
			}
			else if (strlen(password) <= 1) {
				// TODO: Find out how to tell the client wrong username/password
				cerr << "Login without a password" << endl;
				ret = false;
				break;
			}
			else {
				account_id = database.CheckLogin(name,password);
				if (account_id == 0)
				{
					// TODO: Find out how to tell the client wrong username/password
					struct in_addr	in;
					in.s_addr = ip;
					cerr << inet_ntoa(in) << ": Wrong name/pass: name='" << name << "'" << endl;
					ret = false;
					break;
				}
			cout << "Logged in: Local: " << name << endl;
			}
			admin = database.CheckStatus(account_id);

			APPLAYER *outapp;
			outapp = new APPLAYER(0x5941, 0);
			QueuePacket(outapp);
			delete outapp;

	/*		outapp = new APPLAYER(0xc341, 180);
			QueuePacket(outapp);
			delete outapp;*/

			outapp = new APPLAYER(0x0710, 1);
			QueuePacket(outapp);
			delete outapp;
if(!firstlogin)
{
	/*		outapp = new APPLAYER(0xe541, 544);
			QueuePacket(outapp);
			delete outapp;		*/

				APPLAYER *outapp;
			char cname[64];
			database.GetLiveChar(account_id, cname);
			outapp = new APPLAYER(OP_EnterWorld, strlen(cname)+1);
			memcpy(outapp->pBuffer,cname,strlen(cname));
//printf("%s\n",outapp->pBuffer);
			QueuePacket(outapp);
			delete outapp;	

			outapp = new APPLAYER(0x3441,8);
			outapp->pBuffer[0] = 0x01;
			QueuePacket(outapp);
			delete outapp;
}
if(firstlogin)
{
			outapp = new APPLAYER(OP_EnterWorld, 1);
			QueuePacket(outapp);
			delete outapp;

			// Quagmire - Enabling expansions. Pretty sure this is bitwise
			outapp = new APPLAYER(OP_ExpansionInfo, 4);
			char tmp[4];
			outapp->pBuffer[0] = 15;
			if (database.GetVariable("Expansions", tmp, 3)) {
				outapp->pBuffer[0] = atoi(tmp);
			}
			QueuePacket(outapp);
			delete outapp;
}

		/*	if (sendguilds) {
cout << "Sending list of guilds" << endl;
				// Quagmire - tring to send list of guilds

			}*/

			// We are logging in and want to see character select

		    break;
		}
		case 0x2340:
			{
			QueuePacket(app);
			break;
			}
		case OP_GuildsList:
			{
				APPLAYER *outapp;
			printf("Guild Send Request...\n");
				outapp = new APPLAYER(OP_GuildsList, sizeof(GuildsList_Struct));
				GuildsList_Struct* gl = (GuildsList_Struct*) outapp->pBuffer;

				for (int i=0; i < 512; i++) {
					gl->Guilds[i].guildID = 0xFFFFFFFF;
					gl->Guilds[i].guildIDx = 0xFFFFFFFF;
					gl->Guilds[i].unknown6[0] = 0xFF;
					gl->Guilds[i].unknown6[1] = 0xFF;
					gl->Guilds[i].unknown6[2] = 0xFF;
					gl->Guilds[i].unknown6[3] = 0xFF;
					gl->Guilds[i].exists = 0;
					gl->Guilds[i].unknown10[0] = 0xFF;
					gl->Guilds[i].unknown10[1] = 0xFF;
					gl->Guilds[i].unknown10[2] = 0xFF;
					gl->Guilds[i].unknown10[3] = 0xFF;
					if (guilds[i].databaseID != 0) {
						gl->Guilds[i].guildID = i;
						gl->Guilds[i].guildIDx = i;
						gl->Guilds[i].unknown4[1] = 0x75;
						gl->Guilds[i].unknown4[2] = 0x5B;
						gl->Guilds[i].unknown4[3] = 0xF6;
						gl->Guilds[i].unknown4[4] = 0x77;
						gl->Guilds[i].unknown4[5] = 0x5C;
						gl->Guilds[i].unknown4[6] = 0xEC;
						gl->Guilds[i].unknown4[7] = 0x12;
						gl->Guilds[i].unknown4[9] = 0xD4;
						gl->Guilds[i].unknown4[10] = 0x2C;
						gl->Guilds[i].unknown4[11] = 0xF9;
						gl->Guilds[i].unknown4[12] = 0x77;
						gl->Guilds[i].unknown4[13] = 0x90;
						gl->Guilds[i].unknown4[14] = 0xD7;
						gl->Guilds[i].unknown4[15] = 0xF9;
						gl->Guilds[i].unknown4[16] = 0x77;
						gl->Guilds[i].regguild[1] = 0xFF;
						gl->Guilds[i].regguild[2] = 0xFF;
						gl->Guilds[i].regguild[3] = 0xFF;
						gl->Guilds[i].regguild[4] = 0xFF;
						gl->Guilds[i].regguild[5] = 0x6C;
						gl->Guilds[i].regguild[6] = 0xEC;
						gl->Guilds[i].regguild[7] = 0x12;
						strcpy(gl->Guilds[i].name, guilds[i].name);
						gl->Guilds[i].exists = 1;
					}
				}
				
				QueuePacket(outapp);
				delete outapp;

				printf("Sending character information.\n");

				SendCharInfo();
			}
		case 0xe541:
			{
			
			break;
		}
		case OP_ApproveName: //Name approval
		{
			if (account_id == 0)
			{
				cerr << "Name approval with no logged in account" << endl;
				ret = false;
				break;
			}
		    char name[64];
			snprintf(name, 64, "%s", (char*)app->pBuffer);
		    uchar race = app->pBuffer[64];
		    uchar clas = app->pBuffer[68];
			
		    cout << "Name approval request for:" << name; 
		    cout << " race:" << (int)race;
		    cout << " class:" << (int)clas << endl;

			APPLAYER *outapp;
			outapp = new APPLAYER;
			outapp->opcode = OP_ApproveName;
		   	outapp->pBuffer = new uchar[1];
		   	outapp->size = 1;
			if (database.CheckNameFilter(name)) {
				outapp->pBuffer[0] = 0;
			}
			else if (database.ReserveName(account_id, name)) {
				outapp->pBuffer[0] = 1;
			}
			else {
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;
		    break;			
		}
		case OP_CharacterCreate: //Char create
		{
			if (account_id == 0)
			{
				cerr << "Char create with no logged in account" << endl;
				ret = false;
				break;
			}
			// Quag: This packet seems to be the PlayerProfile struct w/o the space for the checksum at the beginning
			// Scruffy: And some of the end data. *shrug*
			// T7g: But some of the values are messed up now, For example-> in PP face is 162, in CC it's 174...
			if (app->size != sizeof(PlayerProfile_Struct)-8) {
				cout << "Wrong size on OP_CharacterCreate. Got: " << app->size << ", Expected: " << sizeof(PlayerProfile_Struct) - 8 << endl;
				break;
			}
			// TODO: Sanity check in data
			PlayerProfile_Struct cc;
			memset(&cc, 0, sizeof(PlayerProfile_Struct));
			memcpy((char*) &cc.unknown0004, app->pBuffer, sizeof(PlayerProfile_Struct)-8); //test -8
			//These defines do not exist in PlayerProfile anymore...
			//memset(cc.invitemproperties,0,sizeof(cc.invitemproperties));
			//memset(cc.bagitemproperties,0,sizeof(cc.bagitemproperties));
			//memset(cc.cursorbagitemproperties,0,sizeof(cc.cursorbagitemproperties));
			//memset(cc.bankinvitemproperties,0,sizeof(cc.bankinvitemproperties));
			//memset(cc.bankbagitemproperties,0,sizeof(cc.bankbagitemproperties));
			
			/* Clearing Unknown Variables */
			memset(cc.unknown0004, 0, sizeof(cc.unknown0004));
			cc.unknown0141 = 0;
//			memset(cc.unknown0145, 0, sizeof(cc.unknown0145));
			cc.unknown0147 = 0;
			cc.unknown0149 = 0;
			memset(cc.unknown0150, 0, sizeof(cc.unknown0150));
			memset(&cc.unknown0178, 0, sizeof(cc.unknown0178));
			memset(&cc.unknown0179, 0, sizeof(cc.unknown0179));
			memset(cc.unknown0180, 0, sizeof(cc.unknown0180));
			memset(cc.unknown0310, 0, sizeof(cc.unknown0310));
			memset(cc.unknown2374, 0, sizeof(cc.unknown2374));
			memset(cc.unknown2920, 0, sizeof(cc.unknown2920));
			memset(cc.unknown2956, 0, sizeof(cc.unknown2956));
			memset(cc.unknown3134, 0, sizeof(cc.unknown3134));
			memset(cc.unknown3448, 0, sizeof(cc.unknown3448));
			memset(cc.unknown3656, 0, sizeof(cc.unknown3656));
			//memset(cc.unknown4736, 0, sizeof(cc.unknown4736));
			memset(cc.unknown4740, 0, sizeof(cc.unknown4740));
			cc.unknown4756 = 0;
			cc.unknown4756 = 0;
			//cc.unknown4758 = 0;
			memset(cc.unknown4760, 0, sizeof(cc.unknown4760));
			memset(cc.unknown5225, 0, sizeof(cc.unknown5225));
			/* ************************** */

			//Lyenu - This is the call to add starting items
			database.SetStartingItems(&cc, (int16)cc.race, (int8)cc.class_, (char*)&cc.name, (int)admin); 


			//If the player has a 100+ avatar level, flag the character GM automagically.
			if(admin>=100) {
				cc.gm=1;
			}

			//If server is PVP by default, make all character set to it.
			if(database.GetServerType() == 1)
				cc.pvp = 1;
			else
				cc.pvp = 0;
	
			// T7g - Face fix, this fixes faces so the face you choose on character creation is the face thats stored in player profile.
			cc.face = app->pBuffer[174];
			// Luclin Eye Color
			cc.eyecolor1 = app->pBuffer[5424];
			cc.eyecolor2 = app->pBuffer[5425];
			// Luclin Hair Type
			cc.hairstyle = app->pBuffer[5426];
			// Luclin Hair Color
			cc.haircolor = app->pBuffer[5422];
			// Luclin Beard Type
			cc.beard_t = app->pBuffer[5427];
			// Luclin Beard Color
			cc.beardcolor = app->pBuffer[5423];


/*		    char name[64];
		    strncpy(name, cc->name, 16);

			int16 gender = cc->gender;
			int16 race = cc->race;
			int16 class_ = cc->class_;
			int8 face = cc->face;
			int8 str = cc->STR;
			int8 sta = cc->STA;
			int8 cha = cc->CHA;
			int8 dex = cc->DEX;
			int8 int_ = cc->INT;
			int8 agi = cc->AGI;
			int8 wis = cc->WIS; // TODO: Find out where deity,face and starting location is located
*/

//			if (!database.CreateCharacter(account_id,name,gender,race,class_,str,sta,cha,dex,int_,agi,wis, face))
			if (!database.CreateCharacter(account_id, &cc))
			{
				cerr << "database.CreateCharacter failed" << endl;
				APPLAYER *outapp = new APPLAYER(OP_ApproveName, 1);
				outapp->pBuffer[0] = 0;
				QueuePacket(outapp);
				delete outapp;
				ret = false;
				break;
			}

			cout << "Char create:" << cc.name << endl;
			SendCharInfo();

		    break;
		}
		case OP_EnterWorld: // Enter world
		{
			if (account_id == 0)
			{
				cerr << "Enter world with no logged in account" << endl;
				eqnc->Close();
				break;
			}
            strncpy(char_name,(char*)app->pBuffer,64);

			APPLAYER *outapp;

			// Make sure this account owns this character
			if (database.GetAccountIDByChar(char_name) != account_id)
			{
				cerr << "This account does not own this character" << endl;
				eqnc->Close();
				break;
			}

			PlayerProfile_Struct pp;
			if (database.GetPlayerProfile(account_id, char_name, &pp) == 0)
			{
				cerr << "Could not get PlayerProfile for " << char_name << endl;
				eqnc->Close();
				break;
			}
			if (pp.current_zone == 0 || !database.GetSafePoints(pp.current_zone)) {
				// This is to save people in an invalid zone, once it's removed from the DB
				pp.current_zone = database.GetZoneID("arena");
				pp.x = -1;
				pp.y = -1;
				pp.z = -1;
				database.SetPlayerProfile(account_id, char_name, &pp);
			}
			strcpy(zone_name, database.GetZoneName(pp.current_zone));
if(firstlogin)
{
			outapp = new APPLAYER(OP_MOTD); // This is message of the day?
			char tmp[500];memset(tmp,0,500);
			if (database.GetVariable("MOTD", tmp, 500)) {
				outapp->size = strlen(tmp)+1;
				outapp->pBuffer = new uchar[outapp->size]; memset(outapp->pBuffer,0,outapp->size);
				strcpy((char*)outapp->pBuffer, tmp);
			} else {
				//char DefaultMOTD[] = "Welcome to EQ Emu(tm)!";
				//outapp->size = strlen(DefaultMOTD) + 1;
				//outapp->pBuffer = new uchar[outapp->size];
				//strcpy((char*)outapp->pBuffer, DefaultMOTD);
				// Null Message of the Day. :)
				outapp->size = 1;
				outapp->pBuffer = new uchar[outapp->size];
				outapp->pBuffer[0] = 0;
			}
			QueuePacket(outapp);
			delete outapp;
}
			firstlogin = false;

			EnterWorld();
			break;
		}
		case OP_DeleteCharacter:
		{
			cout << "Delete character:" << app->pBuffer << endl;
			if(!database.DeleteCharacter((char*)app->pBuffer))
			{
				ret = false;
				break;
			}
			SendCharInfo();
			break;
		}
		case 0x3541:
		case 0x3941: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			break;
		}
		default: {
			cout << "Unknown opcode: 0x" << hex << setfill('0') << setw(4) << app->opcode << dec;
			cout << " size:" << app->size << endl;
			DumpPacket(app);
			break;
		}
		}

		delete app;
	}    

	if (!eqnc->CheckActive()) {
		cout << "Client disconnected" << endl;
		return false;
	}

	return ret;
}

void Client::EnterWorld(bool TryBootup) {
	int16 zone_port;
	char zone_address[255];

	if (strlen(zone_name) == 0)
		return;

	ZoneServer* zs = zoneserver_list.FindByName(zone_name);
	if (zs) {
		// warn the world we're comming, so it knows not to shutdown
		zs->TriggerBootup();
	}
	else {
		if (TryBootup) {
			int32 x = database.CommandRequirement("$MAXCLIENTS");
			printf("Maxclients: %i\n",x);
			if(numclients >= x && x != -1 && x != 255) {
				ZoneUnavail();
			}
			else {
				autobootup_timeout->Start();
				cout << "Attempting autobootup of '" << zone_name << "' for " << char_name << endl;
				if (!(pwaitingforbootup = zoneserver_list.TriggerBootup(zone_name))) {
					if(strlen(net.GetUnavailZone())!=0)
					{
						zs= zoneserver_list.FindByName("arena"); strncpy(zone_name,net.GetUnavailZone(),25);
						database.MoveCharacterToZone(char_name,zone_name);
					}
					else 
					{
						cout << "Error: No zoneserver to bootup '" << zone_name << "' for " << char_name << endl;
						ZoneUnavail();
					}
				}
			}
			return;
		}
		else {
			cout << "Error: Player '" << char_name << "' requested zone status for '" << zone_name << "' but it's not up." << endl;
			ZoneUnavail();
			return;
		}
	}
	pwaitingforbootup = 0;

				printf("Charlogin: %s\n",char_name);
			database.UpdateLiveChar(char_name,account_id);
	cout << "Enter world: " << char_name << ": " << zone_name << endl;
	database.SetAuthentication(account_id, char_name, zone_name, ip);


	
	APPLAYER* outapp;
	/*outapp = new APPLAYER(0x0980,41);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	QueuePacket(outapp);
	delete outapp;*/

	outapp = new APPLAYER(OP_ZoneServerInfo,130); //no memste = BAD -kathgar
	//outapp->opcode = OP_ZoneServerInfo;//0x0480;
	//outapp->pBuffer = new uchar[130];
	//outapp->size = 130;
//	strcpy((char*) outapp->pBuffer,     zone_address);
	strcpy((char*) outapp->pBuffer,     zs->GetCAddress());
	strcpy((char*)&outapp->pBuffer[75], zone_name);
	/*for(int i=75;i<128;i++)
	{
	outapp->pBuffer[i] = 1;
	}*/
	int16 *temp = (int16*)&outapp->pBuffer[128];
//	*temp = ntohs(zone_port);
	*temp = ntohs(zs->GetCPort());

	QueuePacket(outapp);
	delete outapp;
}

void Client::ZoneUnavail() {
	memset(zone_name, 0, sizeof(zone_name));
	pwaitingforbootup = 0;
	autobootup_timeout->Disable();
	APPLAYER* outapp = new APPLAYER(OP_ZoneUnavail, sizeof(ZoneUnavail_Struct));
	ZoneUnavail_Struct* ua = (ZoneUnavail_Struct*)outapp->pBuffer;
	strcpy(ua->zonename, zone_name);
	QueuePacket(outapp);
	delete outapp;
}

bool Client::GenPassKey(char* key) {
char* passKey;
*passKey += ((char)('A'+((int)(rand()%26))));
*passKey += ((char)('A'+((int)(rand()%26))));
printf("PassKey: %s\n",passKey);
memcpy(key, passKey, strlen(passKey));
return true;
}

void Client::QueuePacket(APPLAYER* app, bool ack_req) {
	ack_req = true;	// It's broke right now, dont delete this line till fix it. =P
	if (app != 0) {
		if (app->size > 49156) {
			cout << "WARNING: abnormal packet size. o=0x" << hex << app->opcode << dec << ", s=" << app->size << endl;
		}
	}
	eqnc->QueuePacket(app, ack_req);
}

ClientList::ClientList() {
}

ClientList::~ClientList() {
}

void ClientList::Add(Client* client) {
	list.Insert(client);
}

Client* ClientList::Get(int32 ip, int16 port)
{
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->GetIP() == ip && iterator.GetData()->GetPort() == port)
		{
			Client* tmp = iterator.GetData();
			return tmp;
		}
		iterator.Advance();
	}
	return 0;
}

void ClientList::Process() {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (!iterator.GetData()->Process())
		{
			struct in_addr  in;
			in.s_addr = iterator.GetData()->GetIP();
			cout << "Removing client from ip:" << inet_ntoa(in) << " port:" << iterator.GetData()->GetPort() << endl;
			iterator.RemoveCurrent();
		}
		else
		{
			iterator.Advance();
		}
	}
}

void ClientList::ZoneBootup(ZoneServer* zs) {
	LinkedListIterator<Client*> iterator(list);

	iterator.Reset();
	while(iterator.MoreElements())
	{
		if (iterator.GetData()->WaitingForBootup()) {
			if (strcasecmp(iterator.GetData()->GetZoneName(), zs->GetZoneName()) == 0) {
				iterator.GetData()->EnterWorld(false);
			}
			else if (iterator.GetData()->WaitingForBootup() == zs->GetID()) {
				iterator.GetData()->ZoneUnavail();
			}
		}
		iterator.Advance();
	}
}

bool Database::SetStartingItems(PlayerProfile_Struct *cc, int16 si_race, int8 si_class, char* si_name, int GM_FLAG) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char* query = 0;
	int i = 22;
	MYSQL_RES *result;
	MYSQL_ROW row;
	
	if(GM_FLAG < 100) {
//cout<< "Loading starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 2 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while(row = mysql_fetch_row(result)) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
	else {
//cout<< "Loading *GM* starting items for: Race: " << (int16)si_race << " Class: " << (int8)si_class << " onto " << si_name << endl;
		if(RunQuery(query, MakeAnyLenString(&query, "SELECT itemid FROM starting_items WHERE race = %i AND class = %i AND gm != 0 ORDER BY id", si_race, si_class), errbuf, &result)) {
			while(row = mysql_fetch_row(result)) {
				cc->inventory[i] = atoi(row[0]);
				cc->invitemproperties[i].charges = 1;
				i++;
			}
			mysql_free_result(result);
			delete[] query;
			return true;
		}
		cerr << "Error in SetStartingItems query '" << query << "' " << errbuf << endl;
		delete[] query;
		return false;
	}
}