#include <iostream.h>
#include "../common/types.h"

#include "EMuShareMem.h"

#ifdef WIN32
	#define snprintf	_snprintf
	#define vsnprintf	_vsnprintf
	#define strncasecmp	_strnicmp
	#define strcasecmp  _stricmp
#endif

LoadEMuShareMemDLL EMuShareMemDLL;

LoadEMuShareMemDLL::LoadEMuShareMemDLL() {
	hDLL = 0;
	Items.GetItem = 0;
	Items.IterateItems = 0;
	Items.cbAddItem = 0;
	Items.DLLLoadItems = 0;
	NPCTypes.GetNPCType = 0;
	NPCTypes.cbAddNPCType = 0;
	NPCTypes.DLLLoadNPCTypes = 0;
	Doors.GetDoor = 0;
	Doors.cbAddDoor = 0;
	Doors.DLLLoadDoors = 0;
}

LoadEMuShareMemDLL::~LoadEMuShareMemDLL() {
	Unload();
}

bool LoadEMuShareMemDLL::Load() {
	if (Loaded())
		return true;
	hDLL = LoadLibrary("EMuShareMem");
	if (Loaded()) {
		Items.GetItem = (DLLFUNC_GetItem) GetProcAddress(hDLL, "GetItem");
		Items.IterateItems = (DLLFUNC_IterateItems) GetProcAddress(hDLL, "IterateItems");
		Items.cbAddItem = (DLLFUNC_AddItem) GetProcAddress(hDLL, "AddItem");
		Items.DLLLoadItems = (DLLFUNC_DLLLoadItems) GetProcAddress(hDLL, "DLLLoadItems");
		NPCTypes.GetNPCType = (DLLFUNC_GetNPCType) GetProcAddress(hDLL, "GetNPCType");
		NPCTypes.cbAddNPCType = (DLLFUNC_AddNPCType) GetProcAddress(hDLL, "AddNPCType");
		NPCTypes.cbSetNPCFaction = (DLLFUNC_SetNPCFaction) GetProcAddress(hDLL, "SetNPCFaction");
		NPCTypes.DLLLoadNPCTypes = (DLLFUNC_DLLLoadNPCTypes) GetProcAddress(hDLL, "DLLLoadNPCTypes");
		Doors.GetDoor = (DLLFUNC_GetDoor) GetProcAddress(hDLL, "GetDoor");
		Doors.cbAddDoor = (DLLFUNC_AddDoor) GetProcAddress(hDLL, "AddDoor");
		Doors.DLLLoadDoors = (DLLFUNC_DLLLoadDoors) GetProcAddress(hDLL, "DLLLoadDoors");
		if ((!Items.GetItem)
			|| (!Items.IterateItems)
			|| (!Items.cbAddItem)
			|| (!Items.DLLLoadItems)
			|| (!NPCTypes.GetNPCType)
			|| (!NPCTypes.cbAddNPCType)
			|| (!NPCTypes.cbSetNPCFaction)
			|| (!NPCTypes.DLLLoadNPCTypes)
			|| (!Doors.GetDoor)
			|| (!Doors.cbAddDoor)
			|| (!Doors.DLLLoadDoors)
			) {
			DWORD le = GetLastError();
			Unload();
			cout << "Error importing functions from EMuShareMem.dll." << endl;
			return false;
		}
		cout << "EMuShareMem.dll loaded." << endl;
		return true;
	}
	else {
		cout << "Error loading EMuShareMem.dll." << endl;
	}
	return false;
}

void LoadEMuShareMemDLL::Unload() {
	Items.GetItem = 0;
	Items.IterateItems = 0;
	Items.cbAddItem = 0;
	Items.DLLLoadItems = 0;
	NPCTypes.GetNPCType = 0;
	NPCTypes.cbAddNPCType = 0;
	NPCTypes.DLLLoadNPCTypes = 0;
	Doors.GetDoor = 0;
	Doors.cbAddDoor = 0;
	Doors.DLLLoadDoors = 0;
	FreeLibrary(hDLL);
	hDLL = 0;
}
