#ifndef MD5_H
#define MD5_H
#include "types.h"


class MD5 {
public:
	struct MD5Context {
		uint32 hash[4];
		uint32 bytes[2];
		uint32 input[16];
	};
	void Generate(const int8* buf, uint32 len, int8 digest[16]);
	
	void Init(struct MD5Context *context);
	void Update(struct MD5Context *context, const int8 *buf, uint32 len);
	void Final(int8 digest[16], struct MD5Context *context);
private:
	void byteSwap(uint32 *buf, uint32 words);
	void Transform(uint32 hash[4], const int32 input[16]);
};
#endif
