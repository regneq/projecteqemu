#include "../common/debug.h"
#include <windows.h>
#include <memory.h>
#include <iostream.h>
#include "NPCTypes.h"
#include "../common/timer.h"

HANDLE hMapObjectNPCTypes = NULL;
LPVOID lpvMemNPCTypes = 0;
MMFNPCTypes_Struct* MMFNPCTypes = 0;
bool AddNPCTypeAllowed = false;

extern "C" __declspec(dllexport) const NPCType* GetNPCType(uint32 id) {
	return pGetNPCType(id);
};

extern "C" __declspec(dllexport) bool AddNPCType(uint32 id, const NPCType* npctype) {
	return pAddNPCType(id, npctype);
};

extern "C" __declspec(dllexport) bool DLLLoadNPCTypes(CALLBACK_DBLoadNPCTypes cbDBLoadNPCTypes, int32 iNPCTypeStructSize, sint32* iNPCTypesCount, int32* iMaxNPCTypeID, int8 iMaxNPCFactions) {
	return pDLLLoadNPCTypes(cbDBLoadNPCTypes, iNPCTypeStructSize, iNPCTypesCount, iMaxNPCTypeID, iMaxNPCFactions);
};

extern "C" __declspec(dllexport) bool SetNPCFaction(int32 id, uint32* factionid, sint32* factionvalue, sint8 primaryfaction) {
	return pSetNPCFaction(id, factionid, factionvalue, primaryfaction);
}

bool pAddNPCType(uint32 id, const NPCType* npctype) {
	if (!AddNPCTypeAllowed)
		return false;
	if (MMFNPCTypes->NPCTypeIndex[id] != 0xFFFFFFFF)
		return false;
	
	MMFNPCTypes->NPCTypeIndex[id] = MMFNPCTypes->NextFreeIndex++;
	memcpy(&MMFNPCTypes->NPCTypes[MMFNPCTypes->NPCTypeIndex[id]], npctype, sizeof(NPCType));

	return true;
}

bool pSetNPCFaction(int32 id, uint32* factionid, sint32* factionvalue, sint8 primaryfaction) {
	if (!AddNPCTypeAllowed)
		return false;
	if (MMFNPCTypes->NPCTypeIndex[id] == 0xFFFFFFFF)
		return false;
	
	for (int i=0; i<MAX_NPC_FACTIONS; i++) {
		MMFNPCTypes->NPCTypes[MMFNPCTypes->NPCTypeIndex[id]].factionid[i] = factionid[i];
		MMFNPCTypes->NPCTypes[MMFNPCTypes->NPCTypeIndex[id]].factionvalue[i] = factionvalue[i];
		MMFNPCTypes->NPCTypes[MMFNPCTypes->NPCTypeIndex[id]].primaryfaction = primaryfaction;
	}
	return true;
}

bool pDLLLoadNPCTypes(CALLBACK_DBLoadNPCTypes cbDBLoadNPCTypes, int32 iNPCTypeStructSize, sint32* iNPCTypesCount, int32* iMaxNPCTypeID, int8 iMaxNPCFactions) {
	if (iNPCTypeStructSize != sizeof(NPCType)) {
		cout << "Error: EMuShareMem: DLLLoadNPCTypes: iNPCTypeStructSize != sizeof(NPCType)" << endl;
		cout << "NPCType struct has changed, EMuShareMem.dll needs to be recompiled." << endl;
		return false;
	}
	if (iMaxNPCFactions != MAX_NPC_FACTIONS) {
		cout << "Error: EMuShareMem: DLLLoadNPCTypes: iMaxNPCFactions != MAX_NPC_FACTIONS" << endl;
		cout << "NPCType struct has changed, EMuShareMem.dll needs to be recompiled." << endl;
		return false;
	}
	int8 ret = OpenNPCTypesMMF(*iNPCTypesCount);
	if (ret == 2) {
		AddNPCTypeAllowed = true;
		MMFNPCTypes->MaxNPCTypeID = *iMaxNPCTypeID;
		MMFNPCTypes->NPCTypeCount = *iNPCTypesCount;
		// use a callback so the DB functions are done in the main exe
		// this way the DLL doesnt have to open a connection to mysql
		cbDBLoadNPCTypes(MMFNPCTypes->NPCTypeCount, MMFNPCTypes->MaxNPCTypeID);
		AddNPCTypeAllowed = false;
		MMFNPCTypes->Loaded = true;
		return true;
	}
	else if (ret == 1) {
		if (!MMFNPCTypes->Loaded) {
			Timer::SetCurrentTime();
			int32 starttime = Timer::GetCurrentTime();
			while ((!MMFNPCTypes->Loaded) && ((Timer::GetCurrentTime() - starttime) < 300000)) {
				Sleep(10);
				Timer::SetCurrentTime();
			}
			if (!MMFNPCTypes->Loaded)
				return false;
		}
		*iMaxNPCTypeID = MMFNPCTypes->MaxNPCTypeID;
		*iNPCTypesCount = MMFNPCTypes->NPCTypeCount;
		return true;
	}
	else {
		cout << "Error Loading NPCTypes: NPCTypes.cpp: pDLLLoadNPCTypes: ret == 0" << endl;
		return false;
	}
	return false;
};

/*
  OpenNPCTypeMMF opens the Memory-Mapped File handel and sets the global MMFNPCTypes pointer to it.
  If we were the First Process and had to create the MMF, it also memsets() the memory to 0;
  Return: 0=Error, 1=Sucess, 2=FirstProcess
*/
int8 OpenNPCTypesMMF(int32 iNPCTypesCount) {
	HANDLE hMutex;
	hMutex = CreateMutex( 
	NULL,                       // no security attributes
	FALSE,                      // initially not owned
	"MutexToProtectOpenNPCTypesMMF");  // name of mutex

	if (hMutex == NULL) {
		cout << "Error Loading NPCTypes: NPCTypes.cpp: OpenNPCTypesMMF: hMutex == Null" << endl;
		return 0;
	}

	DWORD dwWaitResult;
    // Request ownership of mutex.
	dwWaitResult = WaitForSingleObject( 
		hMutex,   // handle to mutex
		2000L);   // two-second time-out interval

	if (dwWaitResult != WAIT_OBJECT_0) {
		// Mutex not aquired, crap out
		cout << "Error Loading NPCTypes: NPCTypes.cpp: OpenNPCTypesMMF: dwWaitResult != WAIT_OBJECT_0" << endl;
		return 0;
	}

	// Finally, ready to rock.
	bool fInit = false;
	int32 tmpMemSize = sizeof(MMFNPCTypes_Struct) + 256 + (sizeof(NPCType) * iNPCTypesCount);
	__try {
		hMapObjectNPCTypes = CreateFileMapping( 
			INVALID_HANDLE_VALUE,		// use paging file
			NULL,						// default security attributes
			PAGE_READWRITE,				// read/write access
			0,							// size: high 32-bits
			tmpMemSize,					// size: low 32-bits
			"dllnpctypesmemfilemap");	// name of map object
		if (hMapObjectNPCTypes == NULL) {
			cout << "Error Loading NPCTypes: NPCTypes.cpp: OpenNPCTypesMMF: hMapObject == Null" << endl;
			return 0;
		}
 
		// The first process to attach initializes memory.

		fInit = (bool) (GetLastError() != ERROR_ALREADY_EXISTS); 

		// Get a pointer to the file-mapped shared memory.

		lpvMemNPCTypes = MapViewOfFile( 
			hMapObjectNPCTypes,			// object to map view of
			FILE_MAP_WRITE,				// read/write access
			0,							// high offset:  map from
			0,							// low offset:   beginning
			0);							// default: map entire file
		if (lpvMemNPCTypes == NULL) {
			cout << "Error Loading NPCTypes: NPCTypes.cpp: OpenNPCTypesMMF: lpvMem == Null" << endl;
			return 0;
		}
 
		// Initialize memory if this is the first process.
 		if (fInit) 
			memset(lpvMemNPCTypes, 0, tmpMemSize);

		MMFNPCTypes = (MMFNPCTypes_Struct*) lpvMemNPCTypes;

		if (fInit) {
			MMFNPCTypes->Loaded = false;
			for(int i=0; i<MMF_MAX_NPCTYPE_ID; i++)
				MMFNPCTypes->NPCTypeIndex[i] = 0xFFFFFFFF;
		}
	} // end of try block

	__finally {
		// Clean up the Mutex stuff
		if (!ReleaseMutex(hMutex)) {
			cout << "Error Loading NPCTypes: NPCTypes.cpp: OpenNPCTypesMMF: !ReleaseMutex(hMutex)" << endl;
			return 0;
		}
	}
	CloseHandle(hMutex);

	if (fInit)
		return 2;
	return 1;
}

void CloseNPCTypesMMF() {
	if (lpvMemNPCTypes == 0)
		return;
	MMFNPCTypes = 0;
	// Unmap shared memory from the process's address space.
	UnmapViewOfFile(lpvMemNPCTypes); 
	lpvMemNPCTypes = 0;
 
	// Close the process's handle to the file-mapping object.
	CloseHandle(hMapObjectNPCTypes);
	hMapObjectNPCTypes = NULL;
}

const NPCType* pGetNPCType(uint32 id) {
	if (MMFNPCTypes == 0 || (!MMFNPCTypes->Loaded))
		return 0;
	if (MMFNPCTypes->NPCTypeIndex[id] == 0xFFFFFFFF)
		return 0;
	return &MMFNPCTypes->NPCTypes[MMFNPCTypes->NPCTypeIndex[id]];
}
