#include "../common/debug.h"
#include <windows.h>
#include <memory.h>
#include <iostream.h>
#include "Doors.h"
#include "../common/timer.h"

HANDLE hMapObjectDoors = NULL;
LPVOID lpvMemDoors = 0;
MMFDoors_Struct* MMFDoors = 0;
bool AddDoorAllowed = false;

extern "C" __declspec(dllexport) const Door* GetDoor(uint32 id) {
	return pGetDoor(id);
};

extern "C" __declspec(dllexport) bool AddDoor(uint32 id, const Door* door) {
	return pAddDoor(id, door);
};

extern "C" __declspec(dllexport) bool DLLLoadDoors(CALLBACK_DBLoadDoors cbDBLoadDoors, int32 iDoorstructSize, sint32* iDoorsCount, int32* iMaxDoorID) {
	return pDLLLoadDoors(cbDBLoadDoors, iDoorstructSize, iDoorsCount, iMaxDoorID);
};

bool pAddDoor(uint32 id, const Door* door) {
	if (!AddDoorAllowed)
		return false;
	if (MMFDoors->DoorIndex[id] != 0xFFFFFFFF)
		return false;

	MMFDoors->DoorIndex[id] = MMFDoors->NextFreeIndex++;
	memcpy(&MMFDoors->Doors[MMFDoors->DoorIndex[id]], door, sizeof(Door));

	return true;
}

bool pDLLLoadDoors(CALLBACK_DBLoadDoors cbDBLoadDoors, int32 iDoorstructSize, sint32* iDoorsCount, int32* iMaxDoorID) {
	if (iDoorstructSize != sizeof(Door)) {
		cout << "Error: EMuShareMem: DLLLoadDoors: iDoorstructSize != sizeof(Door)" << endl;
		cout << "Door struct has changed, EMuShareMem.dll needs to be recompiled." << endl;
		return false;
	}
	int8 ret = OpenDoorsMMF(*iDoorsCount);
	if (ret == 2) {
		AddDoorAllowed = true;
		// use a callback so the DB functions are done in the main exe
		// this way the DLL doesnt have to open a connection to mysql
		MMFDoors->MaxDoorID = *iMaxDoorID;
		MMFDoors->DoorCount = *iDoorsCount;
		cbDBLoadDoors(*iDoorsCount, *iMaxDoorID);
		AddDoorAllowed = false;
		MMFDoors->Loaded = true;
		return true;
	}
	else if (ret == 1) {
		if (!MMFDoors->Loaded) {
			Timer::SetCurrentTime();
			int32 starttime = Timer::GetCurrentTime();
			while ((!MMFDoors->Loaded) && ((Timer::GetCurrentTime() - starttime) < 300000)) {
				Sleep(10);
				Timer::SetCurrentTime();
			}
			if (!MMFDoors->Loaded)
				return false;
		}
		*iMaxDoorID = MMFDoors->MaxDoorID;
		*iDoorsCount = MMFDoors->DoorCount;
		return true;
	}
	else {
		cout << "Error Loading Doors: Doors.cpp: pDLLLoadDoors: ret == 0" << endl;
		return false;
	}
	return false;
};

/*
  OpenDoorMMF opens the Memory-Mapped File handel and sets the global MMFDoors pointer to it.
  If we were the First Process and had to create the MMF, it also memsets() the memory to 0;
  Return: 0=Error, 1=Sucess, 2=FirstProcess
*/
int8 OpenDoorsMMF(sint32 iDoorsCount) {
	HANDLE hMutex;
	hMutex = CreateMutex( 
	NULL,                       // no security attributes
	FALSE,                      // initially not owned
	"MutexToProtectOpenDoorsMMF");  // name of mutex

	if (hMutex == NULL) {
		cout << "Error Loading Doors: Doors.cpp: OpenDoorsMMF: hMutex == Null" << endl;
		return 0;
	}

	DWORD dwWaitResult;
    // Request ownership of mutex.
	dwWaitResult = WaitForSingleObject( 
		hMutex,   // handle to mutex
		2000L);   // two-second time-out interval

	if (dwWaitResult != WAIT_OBJECT_0) {
		// Mutex not aquired, crap out
		cout << "Error Loading Doors: Doors.cpp: OpenDoorsMMF: dwWaitResult != WAIT_OBJECT_0" << endl;
		return 0;
	}

	// Finally, ready to rock.
	bool fInit = false;
	int32 tmpMemSize = sizeof(MMFDoors_Struct) + 256 + (sizeof(Door) * iDoorsCount);
	__try {
		hMapObjectDoors = CreateFileMapping( 
			INVALID_HANDLE_VALUE,		// use paging file
			NULL,						// default security attributes
			PAGE_READWRITE,				// read/write access
			0,							// size: high 32-bits
			tmpMemSize,					// size: low 32-bits
			"dllDoorsmemfilemap");	// name of map object
		if (hMapObjectDoors == NULL) {
			cout << "Error Loading Doors: Doors.cpp: OpenDoorsMMF: hMapObject == Null" << endl;
			return 0;
		}
 
		// The first process to attach initializes memory.

		fInit = (bool) (GetLastError() != ERROR_ALREADY_EXISTS); 

		// Get a pointer to the file-mapped shared memory.

		lpvMemDoors = MapViewOfFile( 
			hMapObjectDoors,			// object to map view of
			FILE_MAP_WRITE,				// read/write access
			0,							// high offset:  map from
			0,							// low offset:   beginning
			0);							// default: map entire file
		if (lpvMemDoors == NULL) {
			cout << "Error Loading Doors: Doors.cpp: OpenDoorsMMF: lpvMem == Null" << endl;
			return 0;
		}
 
		// Initialize memory if this is the first process.
 		if (fInit) 
			memset(lpvMemDoors, 0, tmpMemSize);

		MMFDoors = (MMFDoors_Struct*) lpvMemDoors;

		if (fInit) {
			MMFDoors->Loaded = false;
			for(int i=0; i<MMF_MAX_Door_ID; i++)
				MMFDoors->DoorIndex[i] = 0xFFFFFFFF;
		}
	} // end of try block

	__finally {
		// Clean up the Mutex stuff
		if (!ReleaseMutex(hMutex)) {
			cout << "Error Loading Doors: Doors.cpp: OpenDoorsMMF: !ReleaseMutex(hMutex)" << endl;
			return 0;
		}
	}
	CloseHandle(hMutex);

	if (fInit)
		return 2;
	return 1;
}

void CloseDoorsMMF() {
	if (lpvMemDoors == 0)
		return;
	MMFDoors = 0;
	// Unmap shared memory from the process's address space.
	UnmapViewOfFile(lpvMemDoors); 
	lpvMemDoors = 0;
 
	// Close the process's handle to the file-mapping object.
	CloseHandle(hMapObjectDoors);
	hMapObjectDoors = NULL;
}

const Door* pGetDoor(uint32 id) {
	if (MMFDoors == 0 || (!MMFDoors->Loaded))
		return 0;
	if (MMFDoors->DoorIndex[id] == 0xFFFFFFFF)
		return 0;
	return &MMFDoors->Doors[MMFDoors->DoorIndex[id]];
}
