/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef NPCAI_H
#define NPCAI_H
#include "../common/types.h"



#define CON_GREEN		0x02
#define CON_BLUE		0x04
#define CON_LIGHTBLUE	0x12	
#define CON_WHITE		0x00
#define CON_YELLOW		0x0F
#define CON_RED			0x0D

#define DEFAULT_AGGRORADIUS 70
#define DEFAULT_FRENYRADIUS 70
#define MAX_SHIELDRADIUS    20

int32 GetLevelCon(int8 PlayerLevel, int8 NPCLevel);

#endif
