/*  EQEMu:  Everquest Server Emulator
Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
	
	  You should have received a copy of the GNU General Public License
	  along with this program; if not, write to the Free Software
	  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../common/debug.h"
#include <iostream.h>
#include <math.h>
#include "../common/moremath.h"
#include <stdio.h>
#include "../common/packet_dump_file.h"

#ifdef WIN32
#define snprintf	_snprintf
#define strncasecmp	_strnicmp
#define strcasecmp  _stricmp
#else
#include <stdlib.h>
#include <pthread.h>
#endif

#include "npc.h"
#include "client.h"
#include "map.h"
#include "entity.h"
#include "spdat.h"
#include "groups.h"

//#define SPELLQUEUE //Use only if you want to be spammed by spell testing

extern Database database;
extern Zone* zone;
extern volatile bool ZoneLoaded;
extern EntityList entity_list;
extern SPDat_Spell_Struct spells[SPDAT_RECORDS];

NPC::NPC(const NPCType* d, Spawn2* in_respawn, float x, float y, float z, float heading, bool IsCorpse)
: Mob(d->name,
	  d->lastname,
	  d->max_hp,
	  d->max_hp,
	  d->gender,
	  d->race,
	  d->class_,
      d->bodytype,
	  d->deity,
	  d->level,
	  d->npc_id, // rembrant, Dec. 20, 2001
	  d->skills, // socket 12-29-01
	  d->size,
	  d->walkspeed,
	  d->runspeed,
	  heading,
	  x,
	  y,
	  z,
	  d->light,
	  d->equipment,
	  d->texture,
	  d->helmtexture,
	  d->AC,
	  d->ATK,
	  d->STR,
	  d->STA,
	  d->DEX,
	  d->AGI,
	  d->INT,
	  d->WIS,
	  d->CHA,
	  d->haircolor,
	  d->beardcolor,
	  d->eyecolor1,
	  d->eyecolor2,
	  d->hairstyle,
	  d->title,
	  d->luclinface,
	  d->fixedZ,
	  d->d_meele_texture1,
	  d->d_meele_texture2)
{
	Mob* mob = entity_list.GetMob(name);
	if(mob != 0)
		entity_list.RemoveEntity(mob->GetID());

	int moblevel=GetLevel();
	SetGuildOwner(0);
    interactive = false;
    citycontroller = false;
    guildbank = false;
	
	NPCTypedata = new NPCType;
	memcpy(NPCTypedata, d, sizeof(NPCType));
	respawn2 = in_respawn;
	
	itemlist = new ItemList();
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
	banishcapability=d->banish;
	max_dmg=d->max_dmg;
	min_dmg=d->min_dmg;
    memset( RampageArray, 0, sizeof(RampageArray));
	//Wandering
   /* for (int l=0;l<50;l++)
	{
		wp_x[l] = 0;
		wp_y[l] = 0;
		wp_z[l] = 0;
		wp_s[l] = 0;
		if (l < 6)
			wp_a[l] = 0;
	}*/
	roamer = false;
	
	aggroradius = d->aggroradius;
		if(aggroradius == 0)
		aggroradius = 70;
	mana_regen=d->mana_regen;

    // neotokyo: fix for lazy db-updaters
    if (GetCasterClass() != 'N' && mana_regen == 0)
        mana_regen = (GetLevel() / 10) + 4;
	hp_regen=d->hp_regen;
	
	//Trumpcard:  Gives low end monsters no regen if set to 0 in database. Should make low end monsters killable
	//Might want to lower this to /5 rather than 10.
	if(hp_regen == 0)
		hp_regen = (int)( moblevel / 10 );
	
    CalcMaxMana();
    SetMana(GetMaxMana());

    int32 guild = 0;
    if (zone->IsGuildWars())
	{
        guild = zone->GetGuildOwned();
		int32 npcid = GetNPCTypeID();
    	if (guild > 0)
        {
    	    if(IsCityController() || IsGuildBank())
    	    {
	    	    //zone->SetGuildOwned(guild);
    	    	SetGuildOwner(guild);
    	    }
	        else if(npcid > 0 && database.CityDefense(zone->GetZoneID(),npcid))
    	    {
	    	    SetGuildOwner(guild);
    	    }
	    	else
		    	SetGuildOwner(0);
	    }
	}

	d_meele_texture1=d->equipment[7];
	d_meele_texture2=d->equipment[8];
	NPCSpecialAttacks(d->npc_attacks,0);
	NPCDatabaseSpells(d->npc_spells);
	
    m_Status = S_SPAWNING;
    m_RememberStatus = S_UNKNOWN;
	if(IsInteractive())
	{
		tiredmax = RandomTimer(45,135);
		pvp = false;
		
		for(int i = 0 ; i < 9; i++) // neotokyo: out of bounds again :-/
			equipment[i] = RandomTimer(1000,12000);
	}
	for(int i=0;i < 20; i++)
	{
		NPCSpellTime[i] = 0;
	}
	
	MerchantType=d->merchanttype; // Yodason: merchant stuff
	movement_timer = new Timer(100); /*new Timer(500);*/
	walking_timer = new Timer(30000);
	HastePercentage = 0;
	org_x = x;
	org_y = y;
	org_z = z;
	org_heading = heading;	
	EntityList::RemoveNumbers(name);
	if(!IsInteractive())
		entity_list.MakeNameUnique(name);
	p_depop = false;
	loottable_id = d->loottable_id;	
	sint32 tmp;
	database.GetNPCPrimaryFaction(this->npctype_id, &faction_id, &tmp);
	database.GetFactionIdsForNPC(this->npctype_id, &faction_list);
	ignore_target = 0;
//	rooted = false;
	delaytimer = false;
	scanarea_timer = new Timer(1000);
	spells_timer = new Timer(RandomTimer(12000,65000));
	tics_timer = new Timer(6000);
	interactive_timer = new Timer(1000);
	feign_memory = "0";
	forget_timer = new Timer(500);
	forgetchance = 0;
	randombuff_timer = NULL;

    m_MR = d->MR;
    m_CR = d->CR;
    m_DR = d->DR;
    m_FR = d->FR;
    m_PR = d->PR;

    if (!m_MR)
        m_MR = (int16)( moblevel * 1.5f);
    if (!m_CR)
        m_CR = (int16)( moblevel * 1.5f);
    if (!m_DR)
        m_DR = (int16)( moblevel * 1.5f);
    if (!m_FR)
        m_FR = (int16)( moblevel * 1.5f);
    if (!m_PR)
        m_PR = (int16)( moblevel * 1.5f);
}
	  
NPC::~NPC()
{
    delete scanarea_timer;
	delete movement_timer;
	delete spells_timer;
	safe_delete(walking_timer);
	safe_delete(itemlist);
	safe_delete(NPCTypedata);
	safe_delete(tics_timer);
	safe_delete(interactive_timer);
	safe_delete(forget_timer);
		  
	if(IsInteractive())
	{
	    Group* group = entity_list.GetGroupByMob(this);
		if(group != 0)
		{
		    group->DelMember(this);
	    }
    }
}

bool NPC::IsFactionListAlly(int32 other_faction)
{
LinkedListIterator<struct NPCFaction*> fac_iteratorcur(faction_list);
fac_iteratorcur.Reset();

bool factionally = false;
while(fac_iteratorcur.MoreElements() && !factionally)
{
if( (int32)fac_iteratorcur.GetData()->factionID == (int32)other_faction && fac_iteratorcur.GetData()->value_mod <= 0)
factionally = true;

fac_iteratorcur.Advance();
}
return factionally;
}

// we need this for charmed NPCs
void NPC::SaveSpawnSpot()
{
    spawn_x = x_pos;
    spawn_y = y_pos;
    spawn_z = z_pos;
    spawn_heading = heading;
}

void NPC::SaveGuardSpot()
{
    guard_x = x_pos;
    guard_y = y_pos;
    guard_z = z_pos;
    guard_heading = heading;
}

ServerLootItem_Struct* NPC::GetItem(int slot_id) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	iterator.Reset();
	while(iterator.MoreElements()) {
		ServerLootItem_Struct* item = iterator.GetData();
		if (item->equipSlot == slot_id) {
			return item;
		}
		iterator.Advance();
	}
	cout << "no item found for slot: " << slot_id << endl;
	return 0;
}
	  
void NPC::AddItem(const Item_Struct* item, int8 charges, uint8 slot) {
	//cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = item->item_nr;
	(*itemlist).Append(item_data);
}

void NPC::AddItem(int32 itemid, int8 charges, uint8 slot) {
	//cout << "[adding to spawn] item:" << item->name << " lore:" << item->lore << " id:" << item->item_nr << endl;
	ServerLootItem_Struct* item_data = new ServerLootItem_Struct;
	item_data->charges = charges;
	item_data->equipSlot = slot;
	item_data->item_nr = itemid;
	(*itemlist).Append(item_data);
}
	  
void NPC::AddLootTable() {
	if (npctype_id != 0) { // check if it's a GM spawn
	  database.AddLootTableToNPC(loottable_id, itemlist, &copper, &silver, &gold, &platinum);
	}
}
	  
void NPC::RemoveItem(uint16 item_id) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);

	iterator.Reset();
	while(iterator.MoreElements()) {
		if (iterator.GetData()->item_nr == item_id) {
			iterator.RemoveCurrent();
			return;
		}
		iterator.Advance();
	}

	return;
}
	  
void NPC::ClearItemList() {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);

	iterator.Reset();
	while(iterator.MoreElements()) {
		iterator.RemoveCurrent();
	}
}
	  
void NPC::QueryLoot(Client* to) {
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);

	iterator.Reset();
	int x = 0;
	to->Message(0, "Coin: %ip %ig %is %ic", platinum, gold, silver, copper);
	while(iterator.MoreElements()) {
		const Item_Struct* item = database.GetItem(iterator.GetData()->item_nr);
		to->Message(0, "  %d: %s", item->item_nr, item->name);
		x++;
		iterator.Advance();
	}
	to->Message(0, "%i items on %s.", x, this->GetName());
}

void NPC::AddCash(int16 in_copper, int16 in_silver, int16 in_gold, int16 in_platinum) {
	copper = in_copper;
	silver = in_silver;
	gold = in_gold;
	platinum = in_platinum;
}
	  
void NPC::AddCash() {
	copper = (rand() % 100)+1;
	silver = (rand() % 50)+1;
	gold = (rand() % 10)+1;
	platinum = (rand() % 5)+1;
}
	  
void NPC::RemoveCash() {
	copper = 0;
	silver = 0;
	gold = 0;
	platinum = 0;
}
	  
int32 NPC::RandomTimer(int min,int max) {
    int r = 14000;
	if(min != 0 && max != 0 && min < max)
	{
	    r = (rand()  % (max - min)) + min;
	}
	return r;
}

bool NPC::Process()
{
    if(IsInteractive())
	{
	    if(IsEngaged() && CurrentPosition() != 0)
		    TakenAction(0,0);

        if(interactive_timer->Check())
        {
		    tired++;
			if(tired >= tiredmax && CurrentPosition() != 1 && !IsEngaged())
			{
			    TakenAction(1,0);
            }
			if(tired >= tiredmax)
			    tired = 0;
		}
    }
	if(tics_timer->Check() && !IsCorpse())
	{
	    if(IsInteractive() || IsCityController())
		    SendPosUpdate();
			  
        int32 bonus = 0;
		if(IsInteractive() && CurrentPosition() == 1)
		    bonus+=3;
        if(GetHP() < GetMaxHP())
		    SetHP(GetHP()+hp_regen+bonus);
		if(GetMana() < GetMaxMana())
		    SetMana(GetMana()+mana_regen+bonus);
    }
		  
    adverrorinfo = 1;
	if (IsStunned() && stunned_timer->Check())
    {
        this->stunned = false;
        this->stunned_timer->Disable();
    }

	if (walking_timer->Check())
		walking_timer->Disable();

    if (p_depop)
    {
        Mob* owner = entity_list.GetMob(this->ownerid);
        if (owner != 0)
        {
            owner->CastToNPC()->SetPetID(0);
			this->ownerid = 0;
            this->petid = 0;
        }
        return false;
    }

    adverrorinfo = 2;
    SpellProcess();
    if (tic_timer->Check())
    {
        TicProcess();
    }
		  
    if (IsStunned()||IsMezzed())
	    return true;

	//Feign Death Memory
	if (forget_timer->Check() && strstr(GetFeignMemory(),"0") == NULL) {
		Client* remember_client = entity_list.GetClientByName(GetFeignMemory());
		if (remember_client != 0)
		{
			if (!remember_client->CastToClient()->GetFeigned())
			{
				AddToHateList(remember_client,1);
				SetFeignMemory("0");
				forgetchance = 0;
			}
			else if (rand()%100 <= forgetchance)
			{
				SetFeignMemory("0");
				forgetchance = 0;
			}
			else
			{
				forgetchance += 1;
			}
		}
		else
		{
			SetFeignMemory("0");
		}
	}
	adverrorinfo = 3;
    return ProcessAI();

/*

    adverrorinfo = 3;

    // neotokyo: moved the call for selfbuffing after mez and stun
    if( !IsEngaged() )
	    this->CheckSelfBuffs();

    if (scanarea_timer->Check() &&(!zone->AggroLimitReached()))
    {
		if(entity_list.AddHateToCloseMobs(this))
            zone->AddAggroMob();
        entity_list.CheckSupportCloseMobs(this);
    }

    // neotokyo: check frenzy
    this->hate_list.CheckFrenzyHate();

    adverrorinfo = 4;
	if(IsEngaged())
	    SetTarget(hate_list.GetTop());
    else
    {
        target = 0;
    }
		  
    if (gohome_timer->Check())
    {	
	    gohome_timer->Disable();
        if (!IsEngaged())
	        ismovinghome = true;
    }

    adverrorinfo = 5;	
    if (IsEngaged())
    {
        if(banishcapability != 101 && (GetHateTop()->GetLevel() >= banishcapability) && (banishcapability != 0) && GetHateTop()->IsClient())
        {
            GetHateTop()->Message(4,"I shall not fight you, but I shall banish you!");
            GetHateTop()->GoToBind();
            this->RemoveFromHateList(GetHateTop());
            }
        }
        adverrorinfo = 15;
        if(rooted && IsEngaged())
        {
            int disttest = (int)(this->GetSize() * 2);
            if(disttest <= 9)
            {
                disttest = 10;
            }
            if(this->GetRace() == 49)
            {
                disttest = 85;
            }

			  if (DistNoRootNoZ(GetHateTop()) > disttest * 40)
			  {
				  Mob* closehate = hate_list.GetClosest(this->CastToMob());
				  if(closehate != 0 && closehate != target)
					  SetTarget(closehate);
				  if(closehate != 0 && closehate == target)
				  {
					  SetTarget(closehate);
					  evader = true;
				  }
			  }
		  }
		  
		  if(evader == true && !rooted && !IsEngaged())
			  evader = false;
		  
		  adverrorinfo = 6;
		  if((spells_timer->Check() || (IsEngaged() && spells_timer->GetRemainingTime() > 14000)) && !(gohome_timer->Enabled()||ismovinghome))
		  {
			  if(!IsEngaged()) {
				  spells_timer->Start(RandomTimer(100000,240000), true);
				  CheckFriendlySpellStatus();
			  }
			  if(IsEngaged()) {
				  if(target->GetHPRatio() <= 25 || evader == true)
					  spells_timer->Start(RandomTimer(5000,10000), true);
				  else
					  spells_timer->Start(RandomTimer(7000,14000), true);
				  
				  if(GetHPRatio() < 60 && RandomTimer(0,7) == 0)
					  CheckFriendlySpellStatus();
				  else
					  CheckEnemySpellStatus();
			  }
		  }
		  
		  adverrorinfo = 7;	
		  if (target == 0 && this->ownerid != 0) {
			  Mob* obc = entity_list.GetMob(this->ownerid);
			  if(obc == 0)
				  return false;
			  
			  SetTarget(obc);
		  }
		  adverrorinfo = 14;
		  if (casting_spell_id == 0) {
#define NPC_MOVEMENT_PER_TIC		10
			  //		bool pvp_protection=0;
			  if (target != 0)
			  {
				  if (GetOwnerID() != target->GetID() && !IsAttackAllowed(target))
				  {
					  if(IsInteractive())
					  {
						  RemoveFromHateList(target);
						  return true;
					  }
					  
					  char temp[200];
					  snprintf(temp, 200, "%s says, 'That is not a legal target master.'", this->GetName());
					  entity_list.MessageClose(this, 1, 200, 10, temp);
					  RemoveFromHateList(target);
					  return true;
				  }
				  
				  if(this->IsEngaged() && GetOwner() != 0 && GetOwner()->IsNPC() && GetOwnerID() != target->GetID())
				  {
					  if(GetOwner()->CastToNPC()->hate_list.GetEntHate(GetHateTop()) == 0)
						  GetOwner()->CastToNPC()->AddToHateList(GetHateTop(),1);
				  }
				  
				  
				  if (movement_timer->Check() && !rooted) 
				  {
					  adverrorinfo = 8;
					  //			movement_timer->Start();
					  // NPC can move per "think", this number should be an EQ distance squared				
					  float total_move_dist = (float) DistNoRootNoZ(target);
					  appearance = 0;
					  if (total_move_dist > 75) 
					  {
						  appearance = 5; 
						  total_move_dist -= 50;
						  if (total_move_dist > NPC_MOVEMENT_PER_TIC)
							  total_move_dist = NPC_MOVEMENT_PER_TIC;
						  float x2 = (float) pow(target->GetX() - x_pos, 2);
						  float y2 = (float) pow(target->GetY() - y_pos, 2);
						  // divide by zero "should" be impossible here because of the DistNoRootNoZ check
						  float x_move = (float) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
						  float y_move = (float) (total_move_dist - x_move);
						  x_pos += (float) sqrt((double)x_move) * sign(target->GetX() - x_pos);
						  y_pos += (float) sqrt((double)y_move) * sign(target->GetY() - y_pos);
						  // since we don't use maps, we don't know the correct z nut this should do for now
						  
                          // lets try this and see how it works for pets
                          // neotokyo: 14. Dec. 2002
                          z_pos = (z_pos + target->GetZ()) / 2;
                          
                          //if (this->IsEngaged())
							//  z_pos = this->GetHateTop()->GetZ();
						  pLastChange = Timer::GetCurrentTime();
					  }
					  FaceTarget();
					  
				  }
				  if (target->GetID() != this->ownerid && attack_timer->Check() && this->GetHPRatio() > 0) 
				  {
					  adverrorinfo = 9;
					  if(GetHPRatio() >= 51) {
						  if(SpecialNPCAttacks[1] == 2)
						  {
							  SpecialNPCAttacks[1] = 1;
							  SpecialNPCCounts[1] = 0;
						  }
						  if(SpecialNPCAttacks[2] == 2)
						  {
							  SpecialNPCAttacks[2] = 1;
							  SpecialNPCCounts[2] = 0;
						  }
						  if(SpecialNPCAttacks[3] == 2)
						  {
							  SpecialNPCAttacks[3] = 1;
							  SpecialNPCCounts[3] = 0;
							  SpecialNPCCountstwo[3] = 0;
						  }
					  }
					  
					  if(GetHPRatio() <= 49  && GetHPRatio() > 0 && target->GetID() != this->GetID()) {
						  if(SpecialNPCAttacks[1] == 1)
						  {
							  SpecialNPCCounts[1] += 1;
							  if(SpecialNPCCounts[1] >= 2)
							  {
								  HateSummon();
								  SpecialNPCCounts[1] = 0;
							  }
						  }
					  }
					  
					  if(GetHPRatio() <= 35 && GetHPRatio() > 0 && target->GetID() != this->GetID()) {
						  if(SpecialNPCAttacks[3] == 1)
						  {
							  if(SpecialNPCCountstwo[3] == 0)
							  {
								  entity_list.MessageClose(this,true,800,13,"%s Rampages!",this->GetName());
							  }
							  SpecialNPCCounts[3] = 1;
							  if(SpecialNPCCounts[3] == 1)
							  {
								  Attack(hate_list.GetRandom());
								  SpecialNPCCountstwo[3] += 1;
							  }
						  }
						  if(SpecialNPCCountstwo[3] >= 15)
						  {
							  entity_list.MessageClose(this,true,800,13,"%s loses the rampage.",this->GetName());
							  SpecialNPCAttacks[3] = 2;
							  SpecialNPCCountstwo[3] = 0;
						  }
					  }
					  
					  if(GetHPRatio() <= 17 && GetHPRatio() > 0 && target->GetID() != this->GetID()) {
						  if(SpecialNPCAttacks[2] == 1)
						  {
							  if(SpecialNPCCounts[2] == 0)
							  {
								  SpecialNPCAttacks[2] = 1;
								  entity_list.MessageClose(this,true,800,13,"%s is filled with enragement.",this->GetName());
							  }
							  SpecialNPCCounts[2] += 1;
							  if(SpecialNPCCounts[2] >= 24)
							  {
								  entity_list.MessageClose(this,true,800,13,"%s enragement subsides.",this->GetName());
								  SpecialNPCAttacks[2] = 2;
							  }
						  }
					  }
					  
					  adverrorinfo = 10;
					  if(target != 0 && target->GetID() != this->GetOwnerID())
					  {
						  Attack(target);
						  if(evader == true)
							  evader = false;
						  
						  if(IsInteractive())
						  {
							  tired = 0;
						  }
						  ishome = false;
					  }
					  pLastChange = Timer::GetCurrentTime();
				  }
		}
		else if (ismovinghome)//Go back to bindpoint.. wonder why SendTo don't work for this? - Merkur
		{
			adverrorinfo = 11;
			if (movement_timer->Check()) 
			{
				if (reallygohome) {
					//	cout << "Really Go Home Code exec" << endl;
					float total_move_dist = (float) (org_x-x_pos)*(org_x-x_pos)+(org_y-y_pos)*(org_y-y_pos);
					appearance = 0;
					if (total_move_dist > 75)  {
						appearance = 5;
						total_move_dist -= 50;
						if (total_move_dist > NPC_MOVEMENT_PER_TIC/2) // go a bit slower
							total_move_dist = NPC_MOVEMENT_PER_TIC/2;
						float x2 = (float) pow(org_x - x_pos, 2);
						float y2 = (float) pow(org_y - y_pos, 2);
						float x_move = (float) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
						float y_move = (float) (total_move_dist - x_move);
						x_pos += (float) sqrt((double)x_move) * sign(org_x - x_pos);
						y_pos += (float) sqrt((double)y_move) * sign(org_y - y_pos);
						z_pos = org_z;
						float angle;
						if (org_x-x_pos > 0)
							angle = - 90 + atan((double)(org_y-y_pos) / (double)(org_x-x_pos)) * 180 / M_PI;
						else {
							if (org_x-x_pos < 0)	
								angle = + 90 + atan((double)(org_y-y_pos) / (double)(org_x-x_pos)) * 180 / M_PI;
							else { // Added?
								if (org_y-y_pos > 0)
									angle = 0;
								else
									angle = 180;
							}
						}
						if (angle < 0)
							angle += 360;
						if (angle > 360	)
							angle -= 360;
						
						heading	= 256*(360-angle)/360.0f;
						pLastChange = Timer::GetCurrentTime();
					} // if total_move_distance
					else {
						appearance = 0;			
						ismovinghome = false;
						ishome = true;
						pLastChange = Timer::GetCurrentTime();
					}
				} // if !reallygohome
				else {
					//				cout << "Not Really Going Home Code exec" << endl;
					float delta_x = (rand()%100) - 50;
					float delta_y = (rand()%100) - 50;
					SendTo(org_x + delta_x, org_y + delta_y);
				}
			} // if movemement_timer
			
		} // if !ismovinghome
		else { 
						float delta_x = (rand()%100) - 50;
		float delta_y = (rand()%100) - 50;
		float total_move_dist = (float) (delta_x-x_pos)*(delta_x-x_pos)+(delta_y-y_pos)*(delta_y-y_pos);
		appearance = 0;
		if (total_move_dist > 10)  {
		appearance = 5;
		total_move_dist -= 50;
		if (total_move_dist > NPC_MOVEMENT_PER_TIC/2) // go a bit slower
		total_move_dist = NPC_MOVEMENT_PER_TIC/2;
		float x2 = (float) pow(delta_x - x_pos, 2);
		float y2 = (float) pow(delta_y - y_pos, 2);
		float x_move = (float) (total_move_dist * ((double)x2/(x2+y2))); // should be already abs()'d from the square
		float y_move = (float) (total_move_dist - x_move);
		x_pos += (float) sqrt((double)x_move) * sign(delta_x - x_pos);
		y_pos += (float) sqrt((double)y_move) * sign(delta_y - y_pos);
		z_pos = z_pos;
		float angle;
		if (delta_x-x_pos > 0)
		angle = - 90 + atan((double)(delta_y-y_pos) / (double)(delta_x-x_pos)) * 180 / M_PI;
		else {
		if (delta_x-x_pos < 0)	
		angle = + 90 + atan((double)(delta_y-y_pos) / (double)(delta_x-x_pos)) * 180 / M_PI;
		else { // Added?
		if (delta_y-y_pos > 0)
								angle = 0;
								else
								angle = 180;
								}
								}
								if (angle < 0)
								angle += 360;
								if (angle > 360	)
								angle -= 360;
								
								  heading	= 256*(360-angle)/360.0f;
								  pLastChange = Timer::GetCurrentTime();
								  } // if total_move_distance
								  //			if (walking_timer && walking_timer->Check()) {
								  //				float delta_x = (rand()%100) - 50;
								  //				float delta_y = (rand()%100) - 50;
								  //				SendTo(org_x + delta_x, org_y + delta_y);
			//			}
		}
	}*/
	adverrorinfo = 0;
    return true;
}

void NPC::HateSummon() {
    // check if mob has ability to summon
    // we need to be hurt and level 51+ or ability checked to continue
    if (GetHPRatio() == 100 || (GetLevel() < 51 && SpecAttacks[SPECATK_SUMMON] == false))
        return;

    // now validate the timer
    if (!SpecAttackTimers[SPECATK_SUMMON])
    {
        SpecAttackTimers[SPECATK_SUMMON] = new Timer(6000);
        SpecAttackTimers[SPECATK_SUMMON]->Start();
    }

    // now check the timer
    if (!SpecAttackTimers[SPECATK_SUMMON]->Check())
        return;

    // get summon target
    target = GetHateTop();
    if( target)
    {
        if (target->IsClient())
	        target->CastToClient()->Message(15,"You have been summoned!");
		entity_list.MessageClose(this, true, 500, 10, "%s says,'You will not evade me, %s!' ", GetName(), GetHateTop()->GetName() );
		GetHateTop()->GMMove(x_pos, y_pos, z_pos, target->GetHeading());
	}
}

void NPC::FaceTarget(Mob* MobToFace, bool update) {
	if (MobToFace == 0)
		MobToFace = target;
	if (MobToFace == 0 || MobToFace == this)
		return;
	// TODO: Simplify?
	
	float angle;
	
	if (MobToFace->GetX()-x_pos > 0)
		angle = - 90 + atan((double)(MobToFace->GetY()-y_pos) / (double)(MobToFace->GetX()-x_pos)) * 180 / M_PI;
	else if (MobToFace->GetX()-x_pos < 0)
		angle = + 90 + atan((double)(MobToFace->GetY()-y_pos) / (double)(MobToFace->GetX()-x_pos)) * 180 / M_PI;
	else // Added?
	{
		if (MobToFace->GetY()-y_pos > 0)
			angle = 0;
		else
			angle = 180;
	}
	//cout << "dX:" << MobToFace->GetX()-x_pos;
	//cout << "dY:" << MobToFace->GetY()-y_pos;
	//cout << "Angle:" << angle;
	
	if (angle < 0)
		angle += 360;
	if (angle > 360)
		angle -= 360;
	
	heading = (sint8) (256*(360-angle)/360.0f);
	//	return angle;
	
	//cout << "Heading:" << (int)heading << endl;
	if (update)
		pLastChange = Timer::GetCurrentTime();
}

bool NPC::RemoveFromHateList(Mob* mob) {
	appearance = 0;
    bool bFound = false;
	if (this->IsEngaged())
	{
		bFound = hate_list.RemoveEnt(mob);	
		if  (!this->IsEngaged()){
			this->walking_timer->Start(RandomTimer(3000,20000));
			zone->DelAggroMob();
			//			cout << "Mobs currently Aggro: " << zone->MobsAggroCount() << endl; 
		}
	}
    return bFound;
}

int32 NPC::CountLoot() {
	if (itemlist == 0)
		return 0;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	int32 count = 0;
	
	iterator.Reset();
	while(iterator.MoreElements())	
	{
		count++;
		iterator.Advance();
	}
	return count;
}

void NPC::DumpLoot(int32 npcdump_index, ZSDump_NPC_Loot* npclootdump, int32* NPCLootindex) {
	if (itemlist == 0)
		return;
	LinkedListIterator<ServerLootItem_Struct*> iterator(*itemlist);
	//int32 count = 0;
	
	iterator.Reset();
	while(iterator.MoreElements())	
	{
		npclootdump[*NPCLootindex].npc_dump_index = npcdump_index;
		npclootdump[*NPCLootindex].itemid = iterator.GetData()->item_nr;
		npclootdump[*NPCLootindex].charges = iterator.GetData()->charges;
		npclootdump[*NPCLootindex].equipSlot = iterator.GetData()->equipSlot;
		(*NPCLootindex)++;
		iterator.RemoveCurrent();
	}
}

void NPC::Depop(bool StartSpawnTimer) {
	p_depop = true;
	if (StartSpawnTimer) {
		if (respawn2 != 0) {
			respawn2->Reset();
		}
	}
}

bool NPC::AddQueuedSpell(int16 spell_id) {
	
	int a = 0;
	for(int i = 0; i < 20; i++) {
		if(NPCSpellTime[i] == spell_id)
			NPCSpellTime[i] = 0;
		
		if(NPCSpellTime[i] == 0 && a == 0 && !FindBuff(spell_id)) {
			NPCSpellTime[i] = spell_id;
#ifdef SPELLQUEUE
			printf("%s: Queue Spell Added: %d\n",GetName(),NPCSpellTime[i]);
#endif
			spells_timer->Start(RandomTimer(14000,35000), true);
			a = 1;
			return true;
		}
	}
	return false;
}

void NPC::NPCUnharmSpell(int spell_id) {
	
	if(FindBuff(spell_id)) {
#ifdef SPELLQUEUE
		printf("NPC already has this buff! (%d)\n",spell_id);
#endif
	}
	else {
		if(casting_spell_id != 0)
			AddQueuedSpell(spell_id);	
		else {
			if(DatabaseCastAccepted(spell_id)) {
				CastSpell(spell_id,GetID());
#ifdef SPELLQUEUE
				printf("%s is casting spell: %d(%d)\n",GetName(),spell_id,spells[spell_id].goodEffect);
#endif
			}
		}
	}
}

bool NPC::DatabaseCastAccepted(int spell_id) {
	for (int i=0; i < 12; i++) {
		switch(spells[spell_id].effectid[i]) {
		case SE_Stamina: {
			if(IsEngaged() && GetHPRatio() < 100)
				return true;
			else
				return false;
			break;
						 }
		case SE_CurrentHPOnce:
		case SE_CurrentHP: {
			if(this->GetHPRatio() < 100 && spells[spell_id].buffduration == 0)
				return true;
			else
				return false;
			break;
						   }
			
		case SE_HealOverTime: {
			if(this->GetHPRatio() < 100)
				return true;
			else
				return false;
			break;
							  }
		case SE_DamageShield: {
			return true;
							  }
		case SE_NecPet:
		case SE_SummonPet: {
			if(GetPetID() != 0){
#ifdef SPELLQUEUE
				printf("%s: Attempted to make a second pet, denied.\n",GetName());
#endif
				return false;
			}
			break;
						   }
		case ST_Corpse: {
			return false; //Pfft, npcs don't need to summon corpses/locate corpses!
			break;
						}
		default:
			if(spells[spell_id].goodEffect == 1 && !(spells[spell_id].buffduration == 0 && this->GetHPRatio() == 100) && !IsEngaged())
				return true;
			return false;
		}
	}
	return false;
}

void NPC::NPCDatabaseSpells(const char* parse) {
	spelllimit = database.CommandRequirement("@NPCSPELLS");
	if(spelllimit <= 0)
		spelllimit = 8;
	
	if(spelllimit > 20)
		spelllimit = 20;
	
	Seperator sep(parse, ' ', spelllimit);
	
#ifdef SPELLQUEUE
	printf("Spells for: %s\n",GetName());
#endif
	for(unsigned int i=0; i < spelllimit; i++) {
		NPCSpells[i] = atoi(sep.arg[i]);
		if(atoi(sep.arg[i]) != 0) {
#ifdef SPELLQUEUE
			printf("Spell: %d; ",atoi(sep.arg[i]));
#endif
		}
	}
#ifdef SPELLQUEUE
	printf("\n");
#endif
}

void NPC::NPCHarmSpell(int target,int type) {
	int32* HarmfulSpells = new int32[spelllimit];
	int z = 0;
	for(unsigned int i=0; i < spelllimit; i++) {
		int spellid = NPCSpells[i];
		if(spells[spellid].goodEffect == 0  && spellid > 0) {
			z++;
			HarmfulSpells[z] = spellid;
#ifdef SPELLQUEUE
			printf("%s: Harmful Spell Added (HarmfulSpells[%d]).\n",GetName(),z);
#endif
		}
	}
	
	//Add types later, just make it pick a random spell...
	if(z != 0) {
		int r = (rand() % z+1);
#ifdef SPELLQUEUE
		printf("Random: %d\n",r);
#endif	
		if(HarmfulSpells[r] != 0 && r != 0 && casting_spell_id == 0)
			CastSpell(HarmfulSpells[r],target);
	}
	delete [] HarmfulSpells;
}

void NPC::CheckEnemySpellStatus(){
	Mob* hate = hate_list.GetRandom();
#ifdef SPELLQUEUE
	printf("%s: My random hate is %s\n",GetName(),hate->GetName());
#endif
	NPCHarmSpell(hate->GetID(),1);
}

void NPC::CheckFriendlySpellStatus()
{
	int x = 1;
	int a = 1;
	for (int z=0; z < 12; z++) {
		if(NPCSpellTime[z] != 0 && a == 1 && casting_spell_id == 0 && !FindBuff(NPCSpellTime[z])) {
			int id = NPCSpellTime[z];
			NPCSpellTime[z] = 0;
#ifdef SPELLQUEUE
			printf("%s: Queue Spell Removed: %d\n",GetName(),id);
#endif
			NPCUnharmSpell(id);
			x = 0;
			a = 0;
		}
		if(NPCSpellTime[z] != 0) {
			a = 2;
			spells_timer->Start(RandomTimer(14000,35000), true);
		}
	}
	if(a == 0)
	{
#ifdef SPELLQUEUE
		printf("%s: Timer has been reset to 2 minute timer (No more remaining in queue)\n",GetName());
#endif
		spells_timer->Start(RandomTimer(100000,240000),true);
	}
	if(x == 1 && a == 1) {
		for(unsigned int i=0; i < spelllimit; i++) {
			int spellid = NPCSpells[i];
			if(spellid > 0)
				NPCUnharmSpell(spellid);
		} 
	}
}

void NPC::NPCSpecialAttacks(const char* parse, int permtag)
{
    for(int i = 0; i < SPECATK_MAXNUM; i++)
	{
	    SpecAttacks[i] = false;
        SpecAttackTimers[i] = NULL;
    }

    while (*parse)
    {
        switch(*parse)
        {
        case 'Z':
    		interactive = true;
            break;
        case 'X':
    		citycontroller = true;
            break;
        case 'Y':
    		guildbank = true;
            break;
	    case 'E':
    	    SpecAttacks[SPECATK_ENRAGE] = true;
    		break;
	    case 'F':
    	    SpecAttacks[SPECATK_FLURRY] = true;
    		break;
	    case 'R':
    	    SpecAttacks[SPECATK_RAMPAGE] = true;
    		break;
	    case 'S':
    	    SpecAttacks[SPECATK_SUMMON] = true;
            SpecAttackTimers[SPECATK_SUMMON] = new Timer(6000);
            SpecAttackTimers[SPECATK_SUMMON]->Start();
    		break;
	    case 'T':
            SpecAttacks[SPECATK_TRIPLE] = true;
            break;
	    case 'Q':
            SpecAttacks[SPECATK_QUAD] = true;
            break;
        default:
            break;
        }
        parse++;
    }
	
	if(permtag == 1 && this->GetNPCTypeID() > 0){
		if(database.SetSpecialAttkFlag(this->GetNPCTypeID(),parse)) {
			g_LogFile.write("NPCTypeID: %i flagged to '%s' for Special Attacks.\n",this->GetNPCTypeID(),parse);
		}
	}
}

void NPC::SendTo(float new_x, float new_y) {
	if (zone->map == 0)
		return;
	
	float angle;
	float dx = new_x-x_pos;
	float dy = new_y-y_pos;
	// 0.09 is a perfect magic number for a human pnj's
	walking_timer->Start((int32) ( sqrt( dx*dx + dy*dy ) * 0.09f ) * 1000 );
	
	if (new_x-x_pos > 0)
		angle = - 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
	else {
		if (new_x-x_pos < 0)	
			angle = + 90 + atan((double)(new_y-y_pos) / (double)(new_x-x_pos)) * 180 / M_PI;
		else { // Added?
			if (new_y-y_pos > 0)
				angle = 0;
			else
				angle = 180;
		}
	}
	if (angle < 0)
		angle += 360;
	if (angle > 360	)
		angle -= 360;
	
	heading	= 256*(360-angle)/360.0f;
	appearance = 5;
	//	SendPosUpdate();
	x_pos = new_x;
	y_pos = new_y;
	
	PNODE pnode  = zone->map->SeekNode( zone->map->GetRoot(), x_pos, y_pos );
	// Quagmire - Not sure if this is the right thing to do, but it stops the crashing
	if (pnode == 0) return;
	
	int  *iface  = zone->map->SeekFace( pnode, x_pos, y_pos );
	while(*iface != -1)
	{
		z_pos = zone->map->GetFaceHeight( *iface, x_pos, y_pos );
		iface++;
	}
}

NPC* NPC::SpawnNPC(const char* spawncommand, float in_x, float in_y, float in_z, float in_heading, Client* client) {
	if(spawncommand == 0 || spawncommand[0] == 0) {
		return 0;
	}
	else {
		Seperator sep(spawncommand);
		//Lets see if someone didn't fill out the whole #spawn function properly 
		sep.arg[0][29] = 0;
		if (!sep.IsNumber(1))
			sprintf(sep.arg[1],"1"); 
		if (!sep.IsNumber(2))
			sprintf(sep.arg[2],"1"); 
		if (!sep.IsNumber(3))
			sprintf(sep.arg[3],"0");
		if (atoi(sep.arg[4]) > 2100000000 || atoi(sep.arg[4]) <= 0)
			sprintf(sep.arg[4]," ");
		if (!strcmp(sep.arg[5],"-"))
			sprintf(sep.arg[5]," "); 
		if (!sep.IsNumber(5))
			sprintf(sep.arg[5]," "); 
		if (!sep.IsNumber(6))
			sprintf(sep.arg[6],"1");
		if (!sep.IsNumber(8))
			sprintf(sep.arg[8],"0");
		if (!sep.IsNumber(9))
			sprintf(sep.arg[9], "0");
		if (!sep.IsNumber(7))
			sprintf(sep.arg[7],"0");
		if (!strcmp(sep.arg[4],"-"))
			sprintf(sep.arg[4]," "); 
		//Calc MaxHP if client neglected to enter it...
		if (!sep.IsNumber(4)) {
			//Stolen from Client::GetMaxHP...
			int8 multiplier = 0;
			int tmplevel = atoi(sep.arg[2]);
			switch(atoi(sep.arg[5]))
			{
			case WARRIOR:
				if (tmplevel < 20)
					multiplier = 22;
				else if (tmplevel < 30)
					multiplier = 23;
				else if (tmplevel < 40)
					multiplier = 25;
				else if (tmplevel < 53)
					multiplier = 27;
				else if (tmplevel < 57)
					multiplier = 28;
				else 
					multiplier = 30;
				break;
				
			case DRUID:
			case CLERIC:
			case SHAMAN:
				multiplier = 15;
				break;
				
			case PALADIN:
			case SHADOWKNIGHT:
				if (tmplevel < 35)
					multiplier = 21;
				else if (tmplevel < 45)
					multiplier = 22;
				else if (tmplevel < 51)
					multiplier = 23;
				else if (tmplevel < 56)
					multiplier = 24;
				else if (tmplevel < 60)
					multiplier = 25;
				else
					multiplier = 26;
				break;
				
			case MONK:
			case BARD:
			case ROGUE:
				//		case BEASTLORD:
				if (tmplevel < 51)
					multiplier = 18;
				else if (tmplevel < 58)
					multiplier = 19;
				else
					multiplier = 20;				
				break;
				
			case RANGER:
				if (tmplevel < 58)
					multiplier = 20;
				else
					multiplier = 21;			
				break;
				
			case MAGICIAN:
			case WIZARD:
			case NECROMANCER:
			case ENCHANTER:
				multiplier = 12;
				break;
				
			default:
				if (tmplevel < 35)
					multiplier = 21;
				else if (tmplevel < 45)
					multiplier = 22;
				else if (tmplevel < 51)
					multiplier = 23;
				else if (tmplevel < 56)
					multiplier = 24;
				else if (tmplevel < 60)
					multiplier = 25;
				else
					multiplier = 26;
				break;
			}
			sprintf(sep.arg[4],"%i",5+multiplier*atoi(sep.arg[2])+multiplier*atoi(sep.arg[2])*75/300);
		}
		
		// Autoselect NPC Gender... (Scruffy)
		if (sep.arg[5][0] == 0) {
			sprintf(sep.arg[5], "%i", (int) Mob::GetDefaultGender(atoi(sep.arg[1])));
		}
		
		if (client) {
			// Well we want everyone to know what they spawned, right? 
			client->Message(0, "New spawn:");
			client->Message(0, "Name: %s",sep.arg[0]);
			client->Message(0, "Race: %s",sep.arg[1]);
			client->Message(0, "Level: %s",sep.arg[2]);
			client->Message(0, "Material: %s",sep.arg[3]);
			client->Message(0, "Current/Max HP: %s",sep.arg[4]);
			client->Message(0, "Gender: %s",sep.arg[5]);
			client->Message(0, "Class: %s",sep.arg[6]);
			
			client->Message(0, "Weapon Item Number: %s",sep.arg[7]);
			client->Message(0, "MerchantID: %s",sep.arg[8]);
		}
		//Time to create the NPC!! 
		NPCType* npc_type = new NPCType;
		memset(npc_type, 0, sizeof(NPCType));
		strcpy(npc_type->name,sep.arg[0]);
		npc_type->cur_hp = atoi(sep.arg[4]); 
		npc_type->max_hp = atoi(sep.arg[4]); 
		npc_type->race = atoi(sep.arg[1]); 
		npc_type->gender = atoi(sep.arg[5]); 
		npc_type->class_ = atoi(sep.arg[6]); 
		npc_type->deity= 1;
		npc_type->level = atoi(sep.arg[2]);
		npc_type->npc_id = 0;
		npc_type->loottable_id = 0;
		npc_type->texture = atoi(sep.arg[3]);
		npc_type->light = 0;
		npc_type->fixedZ = 1;
		// Weapons are broke!!
		npc_type->equipment[7] = atoi(sep.arg[7]);
		npc_type->equipment[8] = atoi(sep.arg[8]);
		npc_type->merchanttype = atoi(sep.arg[9]);	
		//for (int i=0; i<9; i++)
		//	npc_type->equipment[i] = atoi(sep.arg[7]);
		
		npc_type->STR = 75;
		npc_type->STA = 75;
		npc_type->DEX = 75;
		npc_type->AGI = 75;
		npc_type->INT = 75;
		npc_type->WIS = 75;
		npc_type->CHA = 75;
		
		NPC* npc = new NPC(npc_type, 0, in_x, in_y, in_z, in_heading);
		delete npc_type;
		
		entity_list.AddNPC(npc);
		return npc;
	}
}



/*Interactive NPC Stuff*/

void NPC::InteractiveChat(int8 chan_num, int8 language, const char * message, const char* targetname,Mob* sender)
{
	char* tmp = new char[strlen(message)+1];
	strcpy(tmp,message);
	strupr(tmp);
	
	printf("%i %s",chan_num,message);
	
	if(sender == 0)
		return;
	
	switch(chan_num)
	{
	case 2:
		{
			Group* group = entity_list.GetGroupByMob(this);
			if(group == 0)
				return;
			if(strstr(strupr(tmp),"ATTACK") && strstr(strupr(tmp),"HELP") && strstr(strupr(tmp),"ME"))
			{
				SetTarget(sender->GetTarget());
				if(target != 0)
				{
					AddToHateList(target,1);
					group->GroupMessage(this,"Im helping ya!");
				}
			}
			break;
		}
	case 8:
		{
			if(strstr(strupr(tmp),"HAIL") && sender->GetTarget() == this)
				entity_list.ChannelMessage(this,1,0,"Hiya, this is a test!");
			break;
		}
	}
	
	delete tmp;
}

void NPC::TakenAction(int8 action,Mob* actiontaker)
{
	switch(action)
	{
	case 0:
		{
			tired = 0;
			position = 0;
			SendAppearancePacket(0x0e,0x64);
			break;
		}
	case 1:
		{
			if(GetHPRatio() <= 80 && actiontaker != this)
				entity_list.ChannelMessage(this,1,0,"I need to get some HP back, im going to sit.");
			
			if(actiontaker != this && GetHPRatio() > 80)
				entity_list.ChannelMessage(this,1,0,"Im tired...");
			position = 1;
			SendAppearancePacket(0x0e,0x6e);
			break;
		}
	case 2:
		{
			position = 2;
			SendAppearancePacket(0x0e,0x6f);
			break;
		}
	case 3:
		{
			position = 3;
			SendAppearancePacket(0x0e,0x64);
			break;
		}
	case 4:
		{
			position = 4;
			SendAppearancePacket(0x0e,105);
			break;
		}
	case 20: // Inspected
		{
			if(CurrentPosition() == 1)
				FaceTarget(actiontaker);
			break;
		}
	case 21: // Healed
		{
			if(IsEngaged())
				return;
			
			if(CurrentPosition() != 1)
			{
				TakenAction(0,0);
			}
			FaceTarget(actiontaker);
			entity_list.ChannelMessage(this,1,0,"Thanks for the heal!");
			if(GetHPRatio() < 100)
				TakenAction(1,this);
			break;
		}
	case 22://groupinvite
		{
			Group* group = entity_list.GetGroupByMob(this->CastToMob());
			if(group != 0 && actiontaker != 0)
			{
				isgrouped = true;
				group->GroupMessage(this,"Hey hey! Thanks for the invite :D");
				ownerid = actiontaker->GetID();
				SetTarget(actiontaker);
			}
			break;
		}
	case 23://groupdisband
		{
			Group* group = entity_list.GetGroupByMob(this);
			if(group == 0)
			{
				target = 0;
				isgrouped = false;
				ownerid = 0;
			}
			break;
		}
	}
}

void NPC::AssignWaypoints(int16 grid)
{
#ifdef _DEBUG
	cout<<"Assigning waypoints for grid "<<grid<<" to "<<name<<"...";
#endif
	char wpstructempty[100];
	if (!database.GetWaypoints(grid, 1, wpstructempty))
		return;

	adverrorinfo = 7561;
	wp_a[4] = grid; //Assign grid number
	roamer = true; //This is a roamer
	for (int i=0; i < 52; i++) {
		adverrorinfo = 7562;
		char wpstruct[100];
		if (!database.GetWaypoints(grid, i, wpstruct))
			i=53;
		else {
			if (i < 2) {
				adverrorinfo = 7563;
				wp_a[i+1] = atoi(wpstruct); //Assign wandering type and pause type
			}
			else { //Retrieve a waypoint
				adverrorinfo = 7564;
				Seperator sep(wpstruct, ' ', 4);
				wp_x[i-2] = atof(sep.arg[0]);
				wp_y[i-2] = atof(sep.arg[1]);
				wp_z[i-2] = atof(sep.arg[2]);
				wp_s[i-2] = atoi(sep.arg[3]);
				if (atof(sep.arg[0]) == 0 && atof(sep.arg[1]) == 0 && wp_a[0] == 0)
					wp_a[0] = i-3; //Assign amount of waypoints
			}
		}
	}
#ifdef _DEBUG
	cout<<" done."<<endl;
#endif
			adverrorinfo = 7565;
	if (wp_a[1] == 1 || wp_a[1] == 2)
		CalculateNewWaypoint();
}

void NPC::StartEnrage()
{
    // dont continue if already enraged
    if (bEnraged)
        return;
    if (SpecAttackTimers[SPECATK_ENRAGE] && !SpecAttackTimers[SPECATK_ENRAGE]->Check())
        return;
    // see if NPC has possibility to enrage
    if (!SpecAttacks[SPECATK_ENRAGE])
        return;
    // check if timer exists (should be true at all times)
    if (SpecAttackTimers[SPECATK_ENRAGE])
    {
		safe_delete(SpecAttackTimers[SPECATK_ENRAGE]);
        SpecAttackTimers[SPECATK_ENRAGE] = NULL;
    }

    if (!SpecAttackTimers[SPECATK_ENRAGE])
    {
        SpecAttackTimers[SPECATK_ENRAGE] = new Timer(10000);
    }
    // start the timer. need to call IsEnraged frequently since we dont have callback timers :-/
    SpecAttackTimers[SPECATK_ENRAGE]->Start();
    bEnraged = true;
    entity_list.MessageClose(this, true, 600, 13, "%s has become ENRAGED.", GetName());
}

bool NPC::IsEnraged()
{
    // check the timer and set to false if time is up
    if (bEnraged && SpecAttackTimers[SPECATK_ENRAGE] && SpecAttackTimers[SPECATK_ENRAGE]->Check())
    {
        entity_list.MessageClose(this, true, 600, 13, "%s is no longer enraged.", GetName());
        safe_delete(SpecAttackTimers[SPECATK_ENRAGE]);
        SpecAttackTimers[SPECATK_ENRAGE] = new Timer(360000);
        SpecAttackTimers[SPECATK_ENRAGE]->Start();
        bEnraged = false;
    }
    return bEnraged;
}

bool NPC::Flurry()
{
    // perhaps get the values from the db?
    if (rand()%100 < 80)
        return false;
    // attack the most hated target, regardless of range or whatever
    Mob *target = GetHateTop();
    entity_list.MessageClose(this, true, 600, 13, "%s executes a FLURRY of attacks on %s!", GetName(), target->GetName());
    for (int i = 0; i < MAX_FLURRY_HITS; i++)
        Attack(target);
    return true;
}

bool NPC::AddRampage(Mob *mob)
{
    if (!SpecAttacks[SPECATK_RAMPAGE])
        return false;
    for (int i = 0; i < MAX_RAMPAGE_TARGETS; i++)
    {
        // if name is already on the list dont add it again
        if (strcasecmp(mob->GetName(), RampageArray[i]) == 0)
            return false;
        strcpy(RampageArray[i], mob->GetName());
        g_LogFile.write("Adding %s to Rampage List in slot %d", RampageArray[i], i);
        return true;
    }
    return false;
}

bool NPC::Rampage()
{
    // perhaps get the values from the db?
    if (rand()%100 < 80)
        return false;

    entity_list.MessageClose(this, true, 600, 13, "%s goes on a RAMPAGE!", GetName());
    for (int i = 0; i < MAX_RAMPAGE_TARGETS; i++)
    {
        // range is important
        if (strlen(RampageArray[i]) > 0 && entity_list.GetMob(RampageArray[i]) )
        {
            Mob *target = entity_list.GetMob(RampageArray[i]);
            if (CombatRange(target))
                Attack(target);
        }
    }
    return true;
}

bool Database::DBSpawn(int8 command, const char* zone, NPC* spawn) {
	char errbuf[MYSQL_ERRMSG_SIZE];
	char *query = 0;
	MYSQL_RES *result;
    MYSQL_ROW row;
	int32 tmp = 0;
	int32 tmp2 = 0;
	switch (command) {
		case 1: {
			char* tmpname = new char[strlen(spawn->GetName())]; strcpy(tmpname, spawn->GetName()); for (int32 i=strlen(spawn->GetName()); i>(strlen(spawn->GetName())-4); i--) tmpname[i] = 0;
			RunQuery(query, MakeAnyLenString(&query, "INSERT INTO npc_types (name, level, race, class, hp, gender, texture, helmtexture, size, loottable_id, merchant_id, face, walkspeed, runspeed) values(\"%s\",%i,%i,%i,%i,%i,%i,%i,%f,%i,%i,%i,%f,%f)", tmpname, spawn->GetLevel(), spawn->GetRace(), spawn->GetClass(), spawn->GetMaxHP(), spawn->GetGender(), spawn->GetTexture(), spawn->GetHelmTexture(), spawn->GetSize(), spawn->GetLoottableID(), spawn->MerchantType, 0, spawn->GetWalkspeed(), spawn->GetRunspeed()), errbuf, 0);
			delete tmpname;
			RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM npc_types ORDER BY id DESC"), errbuf, &result);
			if ((row = mysql_fetch_row(result)))
				tmp2 = atoi(row[0]);
			RunQuery(query, MakeAnyLenString(&query, "INSERT INTO spawn2 (zone, x, y, z, respawntime, heading) values('%s', %f, %f, %f, %i, %f)", zone, spawn->GetX(), spawn->GetY(), spawn->GetZ(), 180, spawn->GetHeading()), errbuf, 0);
			RunQuery(query, MakeAnyLenString(&query, "SELECT id FROM spawn2 WHERE zone='%s' AND spawngroupID=0", zone), errbuf, &result);
			if ((row = mysql_fetch_row(result)))
				tmp = atoi(row[0]);
			RunQuery(query, MakeAnyLenString(&query, "UPDATE spawn2 SET spawngroupID=%i WHERE id=%i", tmp, tmp), errbuf, 0);
			RunQuery(query, MakeAnyLenString(&query, "INSERT INTO spawnentry (spawngroupID, npcID, chance) values(%i, %i, %i)", tmp, tmp2, 100), errbuf, 0);
			char tmpstr[30]; sprintf(tmpstr, "%s%i", zone, tmp);
			RunQuery(query, MakeAnyLenString(&query, "INSERT INTO spawngroup (id, name) values(%i, '%s')", tmp, tmpstr), errbuf, 0);
			mysql_free_result(result);
			cout << flush;
			delete[] query;
			return true;
			break;
		}
		case 2: {
			if (RunQuery(query, MakeAnyLenString(&query, "UPDATE npc_types SET name='%s', level=%i, race=%i, class=%i, hp=%i, gender=%i, texture=%i, helmtexture=%i, size=%i, loottable_id=%i, merchant_id=%i, face=%i, WHERE id=%i", spawn->GetName(), spawn->GetLevel(), spawn->GetRace(), spawn->GetClass(), spawn->GetMaxHP(), spawn->GetGender(), spawn->GetTexture(), spawn->GetHelmTexture(), spawn->GetSize(), spawn->GetLoottableID(), spawn->MerchantType, spawn->GetNPCTypeID()), errbuf, 0)) {
				delete[] query;
				return true;
			}
			else {
				delete[] query;
				return false;
			}
			break;
		}
		case 3: {
			break;
		}
		case 4: {
			break;
		}
		delete[] query;
		return false;
	}
	return false;
}
