/*  EQEMu:  Everquest Server Emulator
    Copyright (C) 2001-2002  EQEMu Development Team (http://eqemu.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY except by those people which sell it, which
	are required to give you total support for your newly bought product;
	without even the implied warranty of MERCHANTABILITY or FITNESS FOR
	A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef MOB_H
#define MOB_H

/* solar: macros for IsAttackAllowed, also used by spells.cpp */
#define _CLIENT(x) (x && x->IsClient() && !x->CastToClient()->IsBecomeNPC())
#define _NPC(x) (x && x->IsNPC() && !x->CastToMob()->GetOwnerID())
#define _BECOMENPC(x) (x && x->IsClient() && x->CastToClient()->IsBecomeNPC())
#define _CLIENTPET(x) (x && x->CastToMob()->GetOwner() && x->CastToMob()->GetOwner()->IsClient())
#define _NPCPET(x) (x && x->IsNPC() && x->CastToMob()->GetOwner() && x->CastToMob()->GetOwner()->IsNPC())
#define _BECOMENPCPET(x) (x && x->CastToMob()->GetOwner() && x->CastToMob()->GetOwner()->IsClient() && x->CastToMob()->GetOwner()->CastToClient()->IsBecomeNPC())

#include "entity.h"
#include "spdat.h"

enum FindSpellType { SPELLTYPE_SELF, SPELLTYPE_OFFENSIVE, SPELLTYPE_OTHER };

struct Buffs_Struct {
	int16	spellid;
	int8	casterlevel;
	int16	casterid;		// Maybe change this to a pointer sometime, but gotta make sure it's 0'd when it no longer points to anything
	int8	durationformula;
	sint32	ticsremaining;
};

struct StatBonuses {
	sint16	AC;
	sint32	HP;
	sint16	Mana;
	sint16	ATK;
	sint16	STR;
	sint16	STA;
	sint16	DEX;
	sint16	AGI;
	sint16	INT;
	sint16	WIS;
	sint16	CHA;
	sint16	MR;
	sint16	FR;
	sint16	CR;
	sint16	PR;
	sint16	DR;
	sint16	DamageShield;
	int8	DamageShieldType;
    sint16  movementspeed;
    sint16  haste;
	sint32 aggroradius; // when calculate just replace original value with this
    int8 skillmod[76];
};

typedef struct
{
    int16 spellID;
    int8 chance;
    Timer *pTimer;
} tProc;

class Mob : public Entity
{
public:
	static int8 Mob::GetDefaultGender(int16 in_race, int8 in_gender = 0xFF);
	static sint32 CalcPetHp(int8 levelb, int8 classb, int8 STA = 75);
	static void CreateSpawnPacket(APPLAYER* app, NewSpawn_Struct* ns);

	void RogueBackstab(Mob* other, const Item_Struct *weapon1, int8 bs_skill);
	void RogueAssassinate(Mob* other); // solar
	bool BehindMob(Mob* other, float playerx, float playery);

	Mob(const char*   in_name,
	    const char*   in_lastname,
	    sint32  in_cur_hp,
	    sint32  in_max_hp,
	    int8    in_gender,
	    int16    in_race,
	    int8    in_class,
        int8    in_bodytype,
	    int8    in_deity,
	    int8    in_level,
		int32   in_npctype_id, // rembrant, Dec. 20, 2001
		const int8*	in_skills, // socket 12-29-01
		float	in_size,
		float	in_walkspeed,
		float	in_runspeed,
	    float   in_heading,
	    float	in_x_pos,
	    float	in_y_pos,
	    float	in_z_pos,

	    int8    in_light,
	    const int8*   in_equipment,
		int8	in_texture,
		int8	in_helmtexture,
		int16	in_ac,
		int16	in_atk,
		int8	in_str,
		int8	in_sta,
		int8	in_dex,
		int8	in_agi,
		int8	in_int,
		int8	in_wis,
		int8	in_cha,
		int8	in_haircolor,
		int8	in_beardcolor,
		int8	in_eyecolor1, // the eyecolors always seem to be the same, maybe left and right eye?
		int8	in_eyecolor2,
		int8	in_hairstyle,
		int8	in_title, //Face Overlay? (barbarian only)
		int8	in_luclinface, // and beard);
		float	in_fixedZ,
		int16	in_d_meele_texture1,
		int16	in_d_meele_texture2
	);
	virtual ~Mob();

	inline virtual bool IsMob() { return true; }

	void	TicProcess();
	virtual void SetLevel(uint8 in_level, bool command = false) { level = in_level; }

	inline virtual void SetSkill(int in_skill_num, int8 in_skill_id) { // socket 12-29-01
		skills[in_skill_num + 1] = in_skill_id; }
	inline virtual int8 GetSkill(int skill_num) { return skills[skill_num + 1]; } // socket 12-29-01
	inline int8 GetEquipment(int item_num) { return equipment[item_num]; } // socket 12-30-01

	virtual void GoToBind() = 0;
	virtual bool Attack(Mob* other, int Hand = 13, bool FromRiposte = false) = 0;		// 13 = Primary (default), 14 = secondary
	virtual void Damage(Mob* from, sint32 damage, int16 spell_id, int8 attack_skill = 0x04) = 0;
	virtual void Heal() = 0;
	virtual void Death(Mob* killer, sint32 damage, int16 spell_id = 0xFFFF, int8 attack_skill = 0x04) = 0;
	
	inline virtual void SetHP(sint32 hp) { if (hp >= max_hp) cur_hp = max_hp; else cur_hp = hp;} 
	
	void ChangeHP(Mob* other, sint32 amount, int16 spell_id = 0);
	void MonkSpecialAttack(Mob* other, int8 type);
	void DoAnim(const int animnum);
	bool IsLifetapSpell(int16 spell_id);

	void ChangeSize(float in_size, bool bNoRestriction = false);
	virtual void GMMove(float x, float y, float z, float heading = 0.01);
	void SendPosUpdate(bool SendToSelf = false);
	void MakeSpawnUpdate(SpawnPositionUpdate_Struct* spu);
	
	void CreateDespawnPacket(APPLAYER* app);
	void CreateHorseSpawnPacket(APPLAYER* app, const char* ownername, uint16 ownerid, Mob* ForWho = 0);
	void CreateSpawnPacket(APPLAYER* app, Mob* ForWho = 0);
	virtual void FillSpawnStruct(NewSpawn_Struct* ns, Mob* ForWho);
	void CreateHPPacket(APPLAYER* app);
    
	int16 CalcBuffDuration(int8 level, int16 formula, int16 duration);

    enum { SPECATK_NONE = 0, SPECATK_SUMMON = 1, SPECATK_ENRAGE = 2, SPECATK_RAMPAGE = 3, SPECATK_FLURRY = 4,
           SPECATK_TRIPLE = 5, SPECATK_QUAD = 6,
           SPECATK_MAXNUM = 7 /*need maxnum to be 1 greater than last special attack */ };

	virtual void StartEnrage() = 0;
	virtual bool IsEnraged() = 0;
	virtual bool Flurry() = 0;
	virtual bool Rampage() = 0;

	bool AddProcToWeapon(int16 spell_id, bool bPerma = false);
	bool RemoveProcFromWeapon(int16 spell_id, bool bAll = false);
	bool HasProcs();

	bool SeeInvisible();
	bool SeeInvisibleUndead();

	bool AttackAnimation(int &attack_skill, int &skillinuse, int Hand, const Item_Struct* weapon);
	bool AvoidDamage(sint32 &damage, int16 spell_id, int8 attack_skill);

	void			DamageShield(Mob* other);
	bool			FindBuff(int16 spellid);
	bool FindType(int8 type, bool bOffensive = false, int16 threshold = 100);
	sint8           GetBuffSlotFromType(int8 type);
	int16			CalcPetLevel(int16 nlevel, int16 nclass);
	void			MakePet(char* pettype);
	void			MakePet(int8 in_level, int8 in_class, int16 in_race, int8 in_texture = 0, int8 in_pettype = 0, float in_size = 0, int8 type = 0);
	char*		GetRandPetName();

	bool			CombatRange(Mob* other);
	int8			flag[60];

	inline int16			GetRace()			{ return race; }
	inline int8			GetGender()			{ return gender; }
	inline virtual int8	GetBaseRace()		{ return base_race; }
	inline virtual	int8	GetBaseGender()		{ return base_gender; }
	inline int8			GetDeity()			{ return deity; }
	inline int8			GetTexture()		{ return texture; }
	inline int8			GetHelmTexture()	{ return helmtexture; }
	inline int8			GetClass()			{ return class_; }
	inline int8			GetLevel()			{ return level; }
	inline const char*		GetName()			{ return name; }
	inline Mob*			GetTarget()			{ return target; }
	inline void			SetTarget(Mob* mob)	{ target = mob; }
	inline int32			GetHPRatio()		{ return (int32)((float)cur_hp/max_hp*100); }
	
	bool IsWarriorClass();
	bool IsAttackAllowed(Mob *target);
	
	inline virtual sint32	GetHP()			{ return cur_hp; }
	inline virtual sint32	GetMaxHP()		{ return max_hp; }
	inline virtual sint32	CalcMaxHP()		{ return max_hp = (base_hp  + itembonuses->HP + spellbonuses->HP); }
	// need those cause SoW or Snare didnt work for mobs
	virtual float GetWalkspeed();
	virtual float GetRunspeed();
	virtual bool IsRooted();
	void BuffFadeBySlot(int slot);
	sint32 CalcSpellValue(int8 formula, sint16 base, sint16 max, int8 caster_level, int16 spell_id);
	void ApplySpellsBonuses(int16 spell_id, int8 casterlevel, StatBonuses* newbon);


	inline virtual sint32	SetMana(sint32 amount)  { if (amount < 0)  cur_mana = 0; else if (amount > GetMaxMana()) cur_mana = GetMaxMana();else cur_mana = amount; return cur_mana; }
	inline virtual sint32	GetMaxMana()	{ return max_mana; }
	inline virtual sint32	GetMana()		{ return cur_mana; }
	void			SetZone(int32 zone_id);
	
	// neotokyo: moved from client to use in NPC too
	char GetCasterClass();
	virtual sint32 CalcMaxMana();

	inline virtual int16	GetAC()		{ return AC + itembonuses->AC + spellbonuses->AC; } // Quagmire - this is NOT the right math
	inline virtual int16	GetATK()	{ return ATK + itembonuses->ATK + spellbonuses->ATK; }
	inline virtual sint16	GetSTR()	{ return STR + itembonuses->STR + spellbonuses->STR; }
	inline virtual sint16	GetSTA()	{ return STA + itembonuses->STA + spellbonuses->STA; }
	inline virtual sint16	GetDEX()	{ return DEX + itembonuses->DEX + spellbonuses->DEX; }
	inline virtual sint16	GetAGI()	{ return AGI + itembonuses->AGI + spellbonuses->AGI; }
	inline virtual sint16	GetINT()	{ return INT + itembonuses->INT + spellbonuses->INT; }
	inline virtual sint16	GetWIS()	{ return WIS + itembonuses->WIS + spellbonuses->WIS; }
	inline virtual sint16	GetCHA()	{ return CHA + itembonuses->CHA + spellbonuses->CHA; }
	virtual sint16	GetMR()	= 0;
	virtual sint16	GetFR()	= 0;
	virtual sint16	GetDR()	= 0;
	virtual sint16	GetPR()	= 0;
	virtual sint16	GetCR()	= 0;

	inline virtual sint16  GetMaxSTR() { return GetSTR(); }
	inline virtual sint16  GetMaxSTA() { return GetSTA(); }
	inline virtual sint16  GetMaxDEX() { return GetDEX(); }
	inline virtual sint16  GetMaxAGI() { return GetAGI(); }
	inline virtual sint16  GetMaxINT() { return GetINT(); }
	inline virtual sint16  GetMaxWIS() { return GetWIS(); }
	inline virtual sint16  GetMaxCHA() { return GetCHA(); }

	virtual sint32 GetActSpellRange(int16 spell_id, sint32 range){ return range;}
	virtual sint32 GetActSpellValue(int16 spell_id, sint32 value){ return value;}
	virtual sint32 GetActSpellCost(int16 spell_id, sint32 cost){ return cost;}
	virtual sint32 GetActSpellDuration(int16 spell_id, sint32 duration){ return duration;}
	virtual sint32 GetActSpellCasttime(int16 spell_id, sint32 casttime){ return casttime;}
	int16 ResistSpell(int16 spell_id, Mob* caster);

	void ShowStats(Client* client);
	void ShowBuffs(Client* client);
	int32 GetNPCTypeID()			{ return npctype_id; } // rembrant, Dec. 20, 2001

	//Trumpcard:  Inlined these calculations.
	float Dist(Mob*);
	float DistNoZ(Mob* other);
	float DistNoRoot(Mob*);
	float DistNoRootNoZ(Mob*);

	inline float	GetX()				{ return x_pos; }
	inline float	GetY()				{ return y_pos; }
	inline float	GetZ()				{ return z_pos; }
	inline float	GetHeading()		{ return heading; }
	inline float	GetSize()			{ return size; }
	inline int32	LastChange() { return pLastChange; }

	virtual void Message(int32 type, const char* message, ...) {} // fake so dont have to worry about typecasting
	void SpellProcess();
	bool CheckFizzle(int16 spell_id);
	void InterruptSpell();
	void InterruptSpell(int16, int16);
	virtual void	CastSpell(int16 spell_id, int16 target_id, int16 slot = 10, int32 casttime = 0xFFFFFFFF);
	void SpellFinished(int16 spell_id, int32 target_id, int16 slot = 10, int16 mana_used = 0, bool ZeroCastTime = false);
	void SpellOnTarget(int16 spell_id, Mob* spelltar);
	void SpellEffect(Mob* caster, int16 spell_id, int8 caster_level, sint16 ticsremaining = -1, int16 partial = 100);
	void DoBuffTic(int16 spell_id, int32 ticsremaining, int8 caster_level, Mob* caster = 0);
	void BuffFade(int16 spell_id, int8 unknown = 0);
	void SendIllusionPacket(int16 in_race, int8 in_gender = 0xFF, int16 in_texture = 0xFFFF, int16 in_helmtexture = 0xFFFF, int8 in_haircolor = 0xFF, int8 in_beardcolor = 0xFF, int8 in_eyecolor1 = 0xFF, int8 in_eyecolor2 = 0xFF, int8 in_hairstyle = 0xFF, int8 in_title = 0xFF, int8 in_luclinface = 0xFF);
	void SendAppearancePacket(int32 type, int32 value, bool WholeZone = true);
	inline int8	GetAppearance()				{ return appearance; }
	inline void	SetAppearance(int8 app)		{ appearance = app; }
	Mob*	GetPet();
	Mob*	GetFamiliar();
	void	SetPet(Mob* newpet);
	Mob*	GetOwner();
	inline void	SetPetID(int16 NewPetID)	{ petid = NewPetID; }
	inline int16	GetPetID()					{ return petid;  }
	inline void	SetFamiliarID(int16 NewPetID)	{ familiarid = NewPetID; }
	inline int16	GetFamiliarID()					{ return familiarid;  }
	void	SetOwnerID(int16 NewOwnerID);
	inline int16	GetOwnerID()				{ return ownerid; }
	inline int16	GetPetType()				{ return typeofpet; }
    	inline int8	GetBodyType()				{ return bodytype; }
    	int16   FindSpell(int16 classp, int16 level, int type, FindSpellType spelltype, float distance, sint32 mana_avail);
	int16	CanUse(int16 spellid, int16 classa, int16 level);
	void	CheckBuffs();
	bool	CheckSelfBuffs();
	void	CheckPet();

 	void    SendSpellBarDisable(bool);
	bool    IsBardSong(int16);

	bool	invulnerable;
	bool	invisible, invisible_undead;
	void	Spin();
	void	Kill();

	void	SetAttackTimer();
	inline void	SetHaste(int Haste) { HastePercentage = Haste; }
	inline int		GetHaste(void) { return spellbonuses->haste; }
	inline void	SetItemHaste(int Haste) { ItemHastePercentage = Haste; }
	inline int		GetItemHaste(void) { return itembonuses->haste; }
	// Kaiyodo - new function prototypes for damage system
	int		GetWeaponDamageBonus(const Item_Struct *Weapon);
	int		GetMonkHandToHandDamage(void);
	

	bool	CanThisClassDoubleAttack(void);
	bool	CanThisClassDuelWield(void);
	bool	CanThisClassRiposte(void);
	bool	CanThisClassDodge(void);
	bool	CanThisClassParry(void);
	
	int	GetMonkHandToHandDelay(void);
	int8	GetClassLevelFactor();
	void	Mesmerize();
	bool    IsMezzable(int16 spell_id);
	inline bool	IsMezzed()	{ return mezzed;}
	inline bool	IsStunned() { return stunned; }
	void	BuffFadeByEffect(int8 effect);
	inline int16	GetErrorNumber()	{return adverrorinfo;}
	
	inline int16	GetRune() { return rune; }
	inline void	SetRune(int16 in_rune) { rune = in_rune; }
	
	sint16	ReduceDamage(sint16 damage, int16 in_rune);
	sint16  ReduceMagicalDamage(sint16 damage, int16 in_rune);

    	int16	inline GetMagicRune() { return magicrune; }
	void	SetMagicRune(int16 in_rune) { magicrune = in_rune; }

	// calculate interruption of spell via movement of mob
	void SaveSpellLoc() {spell_x = x_pos; spell_y = y_pos; spell_z = z_pos; }
	inline float GetSpellX() {return spell_x;}
	inline float GetSpellY() {return spell_y;}
	inline float GetSpellZ() {return spell_z;}
protected:
	int32 pLastChange;
	void CalcSpellBonuses(StatBonuses* newbon);
	void CalcBonuses();

    enum {MAX_PROCS = 4};
    tProc PermaProcs[MAX_PROCS];
    tProc SpellProcs[MAX_PROCS];

	char    name[64];
	char    lastname[70];

    bool bEnraged;
    Timer *SpecAttackTimers[SPECATK_MAXNUM];

	sint32  cur_hp;
	sint32  max_hp;
	sint32	base_hp;
	sint32	cur_mana;
	sint32	max_mana;
	Buffs_Struct	buffs[15];
	StatBonuses*	itembonuses;
	StatBonuses*	spellbonuses;
	NPCType*		NPCTypedata;
	int16			petid;
    int16           familiarid;
	int16			ownerid;
	int16			typeofpet; // 0xFF = charmed

	int16	AC;
	int16	ATK;
	int8	STR;
	int8	STA;
	int8	DEX;
	int8	AGI;
	int8	INT;
	int8	WIS;
	int8	CHA;

	int8    gender;
	int16	race;
	int8	base_gender;
	int16	base_race;
	int8    class_;
    int8    bodytype;
	int16	deity;
	int8    level;
	int32   npctype_id; // rembrant, Dec. 20, 2001
	int8    skills[75];
	float	x_pos;
	float	y_pos;
	float	z_pos;
	float	heading;
	float	size;
	float	walkspeed;
	float	runspeed;
//	sint8   delta_x;
//	sint8   delta_y;
//	sint8   delta_z;
	sint8   delta_heading;
    sint32 delta_y:10,
           spacer1:1,
           delta_z:10,
           spacer2:1,
           delta_x:10;
	int32	guildeqid; // guild's EQ ID, 0-511, 0xFFFFFFFF = none

	int8    light;
	int16   equipment[9];
	int8	texture;
	int8	helmtexture;
	float	fixedZ;
	int8    appearance; // 0 standing, 1 sitting, 2 ducking

	Mob*	target;
	Timer*	attack_timer;
	Timer*	tic_timer;
	Timer*	mana_timer;

	// Kaiyodo - Timer added for dual wield
	Timer * attack_timer_dw;

	Timer* spellend_timer;
	int16 casting_spell_id;

    float spell_x, spell_y, spell_z;

	bool	isinterrupted;
	bool	isattacked;
	bool	delaytimer;
	int16 casting_spell_targetid;
	int16 casting_spell_slot;
	int16 casting_spell_mana;
	int16	bardsong;
	int8	haircolor;
	int8	beardcolor;
	int8	eyecolor1; // the eyecolors always seem to be the same, maybe left and right eye?
	int8	eyecolor2;
	int8	hairstyle;
	int8	title; //Face Overlay? (barbarian only)
	int8	luclinface; // and beard

	int16	rune;
	int16	magicrune;
	int16	d_meele_texture1;
	int16	d_meele_texture2;
	int HastePercentage;
	int ItemHastePercentage;
	bool	mezzed;
	bool	stunned;
	//bool	rooted;
	Timer* mezzed_timer;
	Timer*  stunned_timer;
	Timer*	bardsong_timer;
	int16	adverrorinfo;
};

#endif

